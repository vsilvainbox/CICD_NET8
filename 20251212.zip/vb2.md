# MAPEO EXHAUSTIVO DE NAVEGACION - TR Contabilidad VB6

## Documento de Referencia: Todas las Secuencias y Relaciones entre Formularios

Este documento mapea **ABSOLUTAMENTE TODAS** las interacciones del sistema, tanto las provocadas por navegacion del usuario como las redirecciones automaticas del codigo.

---

## INDICE GENERAL

1. [Puntos de Entrada de la Aplicacion](#1-puntos-de-entrada-de-la-aplicacion)
2. [Modulo Administrador - Mapeo Completo](#2-modulo-administrador---mapeo-completo)
3. [Modulo HyperContabilidad - Mapeo Completo](#3-modulo-hypercontabilidad---mapeo-completo)
4. [Flujos de Creacion de Empresa - Detalle Exhaustivo](#4-flujos-de-creacion-de-empresa---detalle-exhaustivo)
5. [Flujos de Gestion de Usuarios](#5-flujos-de-gestion-de-usuarios)
6. [Flujos de Comprobantes](#6-flujos-de-comprobantes)
7. [Flujos de Documentos](#7-flujos-de-documentos)
8. [Flujos de Configuracion](#8-flujos-de-configuracion)
9. [Convenciones de Parametros y Retornos](#9-convenciones-de-parametros-y-retornos)
10. [Estructuras Globales](#10-estructuras-globales)
11. [ORQUESTACION AUTOMATICA DEL SISTEMA](#11-orquestacion-automatica-del-sistema) **NUEVO**
12. [Flujo de Configuracion Post-Creacion de Empresa](#12-flujo-de-configuracion-post-creacion-de-empresa) **NUEVO**
13. [Catalogo de Formularios](#13-catalogo-de-formularios)

---

## 1. PUNTOS DE ENTRADA DE LA APLICACION

### 1.1 Modulo ADMINISTRADOR

**Archivo de Entrada:** `Administrador.bas` - `Sub Main()`

```
Sub Main()
│
├── PamInit()                           ' Inicializacion base
├── gDebug = GetDebug()                 ' Modo debug
├── ChkSystem(True)                     ' Verificacion del sistema
├── InitLexComun()                      ' Inicializacion comun
├── FwInit("", 8725387)                 ' Inicializacion framework
│
├── gDbPath = GetCmdParam("DbPath")     ' Obtener ruta BD
│   └── Si vacio: gDbPath = W.AppPath & "\Datos"
│   └── Si APP_DEMO: gDbPath = W.AppPath & "\DatosDemo"
│
├── InscribPC()                         ' Verificar inscripcion PC
├── CheckInscPC()                       ' Validar licencia
│
├── gDbType = IIf(DB_MSSQL, SQL_SERVER, SQL_ACCESS)
│
├── [SI DATACON=1 (Access)]
│   └── OpenDbAdm() = False? → End
├── [SI DATACON=2 (SQL Server)]
│   └── OpenMsSql() = False? → End
│
├── ReadOficina()                       ' Leer datos oficina
├── CorrigeBaseAdm/CorrigeBaseAdmSQLServer()  ' Corregir estructura BD
├── CampoImportEmpresas()               ' Campos de importacion
├── IniAdmin()                          ' Inicializar administrador
│
├── FrmStart.Show vbModeless            ' SPLASH SCREEN
├── Sleep 1500                          ' Esperar 1.5 segundos
│
├── FrmidUsuario.FShow() = vbCancel?    ' LOGIN ADMINISTRADOR
│   ├── Si vbCancel → DbMain.Close → End
│   └── Si vbOK → Continua
│
├── Set Frm = New FrmMain               ' CREAR FORMULARIO PRINCIPAL
├── Frm.Show vbModeless                 ' MOSTRAR MENU PRINCIPAL
├── Unload FrmStart                     ' CERRAR SPLASH
└── [Fin de Sub Main]
```

### 1.2 Modulo HYPERCONTABILIDAD

**Archivo de Entrada:** `LpContMain.bas` - `Sub Main()`

```
Sub Main()
│
├── PamInit(), PamRandomize()           ' Inicializacion base
├── GenInstanceKey()                    ' Generar clave de instancia
├── CheckInstance()                     ' Verificar instancia unica
│   └── Si App.PrevInstance → End
│
├── OpenDbAdm() / OpenMsSql()           ' Abrir base de datos
│   └── Si False → End
│
├── ReadOficina()                       ' Leer datos oficina
├── CorrigeBaseAdm/CorrigeBaseAdmSQLServer()
├── ContRegisterPc()                    ' Registrar licencia
│
├── FrmStart.Show vbModeless            ' SPLASH SCREEN
├── Sleep 500
│
├── FrmIdUser.Show vbModal              ' LOGIN HYPERCONTABILIDAD
│   ├── Si gUsuario.Rc = vbCancel → ContUnregisterPc(3) → End
│   └── Si gUsuario.Rc = vbOK → Continua
│
├── IniHyperCont()                      ' Inicializar HyperContabilidad
├── IniHyperContFca()                   ' Inicializar modulo financiero
│
├── [LOOP] Mientras BoolIniEmpresa = False
│   │
│   ├── FrmSelEmpresas.FSelect()        ' SELECCION DE EMPRESA
│   │   ├── Si vbCancel → ContUnregisterPc(3) → End
│   │   └── Si vbOK → Establece gEmpresa.*
│   │
│   ├── Si gEmprSeparadas → CloseDb(DbMain)
│   │
│   └── BoolIniEmpresa = IniEmpresa()   ' INICIALIZAR EMPRESA
│       ├── Abre BD de empresa
│       ├── Carga configuracion empresa
│       └── Retorna True si exitoso
│
├── CreatePrtFormats()                  ' Crear formatos impresion
├── SetPrtData()                        ' Configurar datos impresora
│
├── FrmMain.Show vbModeless             ' MENU PRINCIPAL HYPERCONTABILIDAD
├── Unload FrmStart                     ' CERRAR SPLASH
└── [Fin de Sub Main]
```

---

## 2. MODULO ADMINISTRADOR - MAPEO COMPLETO

### 2.1 FrmMain (Administrador) - Todos los Eventos

#### Form_Load (Linea 499)
```
Form_Load()
│
├── Set gFrmMain = Me                   ' Referencia global
├── Call SetCaption()                   ' Titulo ventana
│
├── FEd2Grid1.TextMatrix(0,0) = "$1#2°P"  ' Inicializar grids
├── FEd3Grid1.TextMatrix(0,0) = "$7#3?F#"
│
├── M_RemoveEmpAno.Enabled = ChkPriv(PRV_ADM_SIS)
│
├── [SI DATACON=2 (SQL Server)]
│   ├── MC_MantDB.Visible = False
│   ├── M_Backup.Visible = False
│   └── MH_Export.Visible = False
├── [SI DATACON=1 (Access)]
│   └── MC_ActTxtTilde.Visible = False
│
├── Lb_Version = "Version X.X Access/SQL Server"
│
├── Si gAppCode.Demo → Mostrar mensaje demo
├── La_demo.Visible = APP_DEMO
│
├── Si gDbType = SQL_ACCESS
│   ├── Pc_SQLServer.Visible = False
│   ├── Pc_Access.Visible = True
│   └── M_ImpEmpFromAccess.Visible = False
├── Si gDbType = SQL_SERVER
│   ├── Pc_SQLServer.Visible = True
│   ├── Pc_Access.Visible = False
│   ├── Call AtributosAdic()
│   └── Call CreaTablasAuditoria()
│
├── Usfis = GetIniString(gIniFile, "Config", "UFIS", "")
│   └── Si Usfis <> 1218 → Deshabilitar TODOS los botones/menus
│
└── [Fin Form_Load]
```

#### Form_Unload (Linea 628)
```
Form_Unload(Cancel)
│
├── Call CloseDb(DbMain)                ' Cerrar base de datos
├── Call CheckRs(True)                  ' Verificar recordsets
└── End                                 ' TERMINAR APLICACION
```

### 2.2 Todos los Menus y sus Destinos

#### Menu EMPRESAS

| Item Menu | Evento Click | Formulario Destino | Metodo Llamado | Modo | Parametros |
|-----------|--------------|-------------------|----------------|------|------------|
| Mantencion | M_MantEmpresas_Click (1193) | FrmEmpresas | .Show | vbModal | - |
| Listado de Empresas | M_ListEmpresas_Click (1182) | FrmPrtEmpresas | .Show | vbModal | - |
| Control de Empresas | M_ContEmpresas_Click (1151) | FrmRepContEmpresas | .Show | vbModal | - |
| Capturar desde HR | M_ImpEmpHR_Click (855) | FrmEmpHR → FrmMantEmpresa | .FSelect → .FNew | vbModal | gEmprHR.EmpConta.Rut, NombreCorto |
| Importar desde Access | M_ImpEmpFromAccess_Click (660) | FrmSelEmpresasNivelEmpresa | .FSelect | vbModal | - |
| Capturar desde LPRemu | M_ImpEmpLpRemuFromAccess_Click (874) | FrmEmpLpRemu | .Show | vbModeless | - |
| Capturar desde Archivo | M_ImpEmpArchivo_Click (642) | FrmEmpArchivo | .FSelect | vbModal | - |
| Eliminar Empresa-Ano | M_RemoveEmpAno_Click (893) | FrmResetEmprAno | .Show | vbModal | - |
| Reporte Auditoria Cuentas | M_RepAudCuentasDefinidas_Click (902) | FrmRepAudCuentasDefinidas | .Show | vbModal | - |
| Reporte Control Empresas | M_RepControlEmpresas_Click (912) | FrmReporteControlEmpresas | .Show | vbModal | - |
| Salir | M_Salir_Click (1242) | - | Unload Me | - | - |

#### Menu VALORES

| Item Menu | Evento Click | Formulario Destino | Metodo Llamado | Modo | Parametros |
|-----------|--------------|-------------------|----------------|------|------------|
| Monedas > Equivalencias | M_Equivalencias_Click (1164) | FrmEquivalencias | .FEdit | vbModeless | 0 |
| Monedas > Configuracion | M_ConfigMonedas_Click (1142) | FrmMonedas | .Show | vbModal | - |
| Valores e Indices | M_Indices_Click (1173) | FrmIPC | .Show | vbModal | - |

#### Menu CONFIGURACION

| Item Menu | Evento Click | Formulario Destino | Metodo Llamado | Modo | Parametros |
|-----------|--------------|-------------------|----------------|------|------------|
| Datos Oficina | MC_Oficina_Click (1080) | FrmOficina | .Show | vbModal | - |
| Razones Financieras | MC_RazonesFin_Click (1089) | FrmRazones | .FDefinir | vbModeless | - |
| Usuarios | MC_Usuarios_Click (1277) | FrmUsuarios | .Show | vbModal | - |
| Perfiles | MC_Perfiles_Click (1224) | FrmPerfiles | .ShowPerfiles | vbModal | True |
| Import Datos SII | MC_ImpDatosSII_Click (1072) | FrmIntegracionDatosSII | .Show | vbModal | - |
| Privilegios de Usuarios | MC_Privilegios_Click (1233) | FrmUsuarioPriv | .Show | vbModal | - |
| Cambiar clave admin | MC_CambiarClave_Click (1358) | FrmCambioClave | .Show | vbModal | - |
| Crear Fiscalizadores | MC_CrearUsrFisc_Click (959) | FrmCrearUsrFiscalizador | .Show | vbModal | - |
| Habilitar Rec SQL | MC_HabilitarRecSql_Click (1012) | - | UPDATE PARAM | - | - |

#### Menu SISTEMA

| Item Menu | Evento Click | Formulario Destino | Metodo Llamado | Modo | Parametros |
|-----------|--------------|-------------------|----------------|------|------------|
| Preparar Impresora | M_SetupPrt_Click (1246) | [Dialogo Windows] | PrepararPrt | - | Cm_PrtDlg |
| Respaldos | M_Backup_Click (1133) | FrmGenBackup | .Show | vbModal | - |
| Desbloquear Conexion | MC_Desbloquear_Click (1003) | FrmDesbloquear | .Show | vbModal | - |
| Licenciar Producto | MC_SolicCod_Click (1263) | FrmEquiposAut | .Solicitud | vbModeless | - |
| Desactivar Licencia | MC_Desactivar_Click (968) | - | [Inline code] | - | - |
| Mantencion > Reparar | MC_Reparar_Click (1098) | - | RepairDb | - | DbPath |
| Mantencion > Compactar | MC_Compactar_Click (934) | - | CompactDb2 | - | DbMain |
| Actualizar Textos | MC_ActTxtTilde_Click (922) | - | CorrigeTextosConAcentos | - | - |

#### Menu AYUDA

| Item Menu | Evento Click | Formulario Destino | Metodo Llamado | Modo | Parametros |
|-----------|--------------|-------------------|----------------|------|------------|
| Manual | MH_Manual_Click (1325) | [PDF externo] | ShellExecute | - | Manual_LP_Administrador.pdf |
| Ayuda de Respaldo | MH_HlpBackup_Click (1315) | FrmBackup | .Show | vbModal | - |
| Exportar Empresa | MH_Export_Click (1379) | FrmExportEmp | .Show | vbModal | - |
| Descargar actualizacion | MH_DownLast_Click (1288) | - | FwDownLast | - | Me, Cm_FileDlg |
| Reporte de problema | MH_RepError_Click (1349) | FrmRepError | .Show | vbModal | - |
| Acerca de | MH_AcercaDe_Click (1124) | FrmAbout | .Show | vbModal | - |

### 2.3 Todos los Botones de Toolbar

| Boton | Evento Click | Redirige a Menu |
|-------|--------------|-----------------|
| Bt_Emp | Bt_Emp_Click (476) | M_MantEmpresas_Click |
| Bt_Indices | Bt_Indices_Click (480) | M_Indices_Click |
| Bt_DefRazonesFin | Bt_DefRazonesFin_Click (472) | MC_RazonesFin_Click |
| bt_Perfiles | bt_Perfiles_Click (484) | MC_Perfiles_Click |
| bt_Usuarios | bt_Usuarios_Click (493) | MC_Usuarios_Click |
| bt_UsuarioPrv | bt_UsuarioPrv_Click (489) | MC_Privilegios_Click |

---

## 3. MODULO HYPERCONTABILIDAD - MAPEO COMPLETO

### 3.1 FrmMain (HyperContabilidad) - Estructura de Menus

#### Menu ARCHIVO / EMPRESA

| Item Menu | Evento Click | Formulario Destino | Metodo | Parametros |
|-----------|--------------|-------------------|--------|------------|
| Seleccionar Empresa | M_SelEmp_Click | FrmSelEmpresas | .FSelect() | - |
| Editar Empresa | M_EditEmp_Click | FrmEmpresa | .FEdit(gEmpresa.Id) | IdEmpresa |
| Control Empresa | M_ContEmpresa_Click | FrmContEmpresa | .Show vbModal | - |
| Configuracion | M_Config_Click | FrmConfig | .Show vbModal | - |
| Salir | M_Salir_Click | - | Unload Me | - |

#### Menu COMPROBANTES

| Item Menu | Evento Click | Formulario Destino | Metodo | Parametros |
|-----------|--------------|-------------------|--------|------------|
| Nuevo Comprobante | M_NewComprob_Click | FrmComprobante | .FNew(False) | CompTipo=False |
| Listar/Editar | M_EditComprob_Click | FrmLstComp | .FView() | - |
| Imprimir | M_PrtComprob_Click | FrmLstComp | .FPrint() | - |

#### Menu DOCUMENTOS

| Item Menu | Evento Click | Formulario Destino | Metodo | Parametros |
|-----------|--------------|-------------------|--------|------------|
| Nuevo Documento | M_NewDoc_Click | FrmSelLibDocs | .FSelectMes(TipoLib, Mes, Ano, False) | Libro, Periodo |
| Listar Documentos | M_LstDocs_Click | FrmSelLibDocs | .FSelect(TipoLib, True) | Libro |
| Cheques Emitidos | M_LstChequesEmit_Click | FrmLstDoc | .FView(LIB_OTROS, CHE, ED_PENDIENTE, mes, ano) | Filtros |
| Cheques a Fecha | M_LstChequesaFecha_Click | FrmLstDoc | .FView(LIB_OTROS, CHF, 0, mes, ano) | Filtros |
| Cheques Anulados | M_LstChequesAnula_Click | FrmLstDoc | .FView(LIB_OTROS, CHE, ED_ANULADO, mes, ano) | Filtros |

#### Menu MAESTROS

| Item Menu | Evento Click | Formulario Destino | Metodo | Parametros |
|-----------|--------------|-------------------|--------|------------|
| Plan de Cuentas | M_Plan_Click | FrmPlanCuentas | .FEdit() | - |
| Entidades | M_EntRel_Click | FrmEntidades | .FEdit() | - |
| Glosas | M_Glosas_Click | FrmGlosas | .Show vbModal | - |
| Areas de Negocio | M_AreaNeg_Click | FrmAreaNeg | .Show vbModal | - |
| Centros de Costo | M_CCosto_Click | FrmCentrosCosto | .Show vbModal | - |
| Sucursales | M_Sucursales_Click | FrmSucursales | .Show vbModal | - |

#### Menu LIBROS

| Item Menu | Evento Click | Formulario Destino | Metodo | Parametros |
|-----------|--------------|-------------------|--------|------------|
| Libro Diario | M_LibDiario_Click | FrmLibDiario | .Show vbModal | - |
| Libro Mayor | M_LibMayor_Click | FrmLibMayor | .Show vbModal | - |
| Libro Caja | M_LibroCaja_Click | FrmLibroCaja | .Show vbModal | - |
| Libro Retenciones | M_LibRetenciones_Click | FrmLibRetenciones | .FView() | - |
| Libro Compras SII | M_LibCompSII_Click | FrmCompraVenta | .FViewLibroLeg(LIB_COMPRAS) | TipoLib |
| Libro Ventas SII | M_LibVentasSII_Click | FrmCompraVenta | .FViewLibroLeg(LIB_VENTAS) | TipoLib |

#### Menu BALANCES

| Item Menu | Evento Click | Formulario Destino | Metodo | Parametros |
|-----------|--------------|-------------------|--------|------------|
| Balance Clasificado | M_BalClasif_Click | FrmBalClasif | .FViewBalClasif() | - |
| Balance Comprobacion | M_BalComprob_Click | FrmBalComprobacion | .FView() | - |
| Balance Tributario | M_BalTrib_Click | FrmBalTributario | .FView() | - |
| Estado de Resultados | M_ResClasificado_Click | FrmBalClasif | .FViewEstResultClasif() | - |
| Estado Comparativo | M_ResComparativo_Click | FrmBalClasifCompar | .FViewEstResultClasif() | - |

#### Menu INFORMES

| Item Menu | Evento Click | Formulario Destino | Metodo | Parametros |
|-----------|--------------|-------------------|--------|------------|
| Informe Analitico | M_InfAnalitico_Click | FrmInfAnalitico | .FViewPorCuenta() | - |
| Por Entidad | M_InfPorEntidad_Click | FrmInfAnalitico | .FViewPorEntidad() | - |
| Capital Propio | M_CapitalPropio_Click | FrmCapitalPropio | .Show vbModal | - |

#### Menu ACTIVO FIJO

| Item Menu | Evento Click | Formulario Destino | Metodo | Parametros |
|-----------|--------------|-------------------|--------|------------|
| Mantencion | M_ActFijo_Click | FrmLstActFijo | .FEdit() | - |
| Reporte | M_RepActFijo_Click | FrmRepActivoFijo | .FView() | - |

#### Menu UTILIDADES

| Item Menu | Evento Click | Formulario Destino | Metodo | Parametros |
|-----------|--------------|-------------------|--------|------------|
| Cambiar Clave | M_CambiarClave_Click | FrmCambioClave | .Show vbModal | - |
| Estado Meses | M_AbrirCerrarMes_Click | FrmEstadoMeses | .Show vbModal | - |
| Cierre Anual | M_CerrarPer_Click | FrmCierreAnual | .Show vbModal | - |
| Compactar BD | M_Compactar_Click | - | CompactDb2(DbMain) | - |

### 3.2 Botones de Barra Izquierda

| Boton | Evento Click | Redirige a | Destino Final |
|-------|--------------|------------|---------------|
| Bt_Emp | Bt_Emp_Click | M_EditEmp_Click | FrmEmpresa.FEdit |
| Bt_Plan | Bt_Plan_Click | M_Plan_Click | FrmPlanCuentas.FEdit |
| Bt_NewComprob | Bt_NewComprob_Click | M_NewComprob_Click | FrmComprobante.FNew |
| Bt_LstComp | Bt_LstComp_Click | M_PrtComprob_Click | FrmLstComp.FPrint |
| Bt_NewDoc | Bt_NewDoc_Click | M_NewDoc_Click | FrmSelLibDocs.FSelectMes |
| Bt_LstDoc | Bt_LstDoc_Click | M_LstDocs_Click | FrmSelLibDocs.FSelect |

### 3.3 Botones de Utilidades (Barra Inferior)

| Boton | Evento Click | Destino | Modo |
|-------|--------------|---------|------|
| Bt_Calendar | Bt_Calendar_Click | FrmCalendar | vbModal |
| Bt_ConvMoneda | Bt_ConvMoneda_Click | FrmConverMoneda | vbModal |
| Bt_Equivalencia | Bt_Equivalencia_Click | FrmEquivalencias | vbModal |
| Bt_Indices | Bt_Indices_Click | FrmIPC | vbModal |
| Bt_Calc | Bt_Calc_Click | [Windows Calculator] | ShellExecute |

---

## 4. FLUJOS DE CREACION DE EMPRESA - DETALLE EXHAUSTIVO

### 4.1 Flujo Completo: Crear Nueva Empresa

```
[USUARIO] Abre Administrador.exe
│
├── Sub Main() [Administrador.bas]
│   ├── PamInit()
│   ├── ChkSystem(True)
│   ├── InitLexComun()
│   ├── OpenDbAdm() / OpenMsSql()
│   ├── ReadOficina()
│   ├── CorrigeBaseAdm()
│   │
│   ├── FrmStart.Show vbModeless          [SPLASH - 1.5 seg]
│   │   └── Form_Load: Muestra logo, version
│   │
│   └── FrmidUsuario.FShow()              [LOGIN MODAL]
│       │
│       ├── Form_Load [Linea 148]
│       │   ├── lRc = vbCancel
│       │   ├── Tx_Nombre = GetLastUser(gIniFile, gAdmUser)
│       │   ├── Posicionar sobre FrmStart
│       │   └── La_demo.Visible = gAppCode.Demo
│       │
│       ├── [USUARIO] Ingresa nombre y clave
│       │
│       └── Bt_Aceptar_Click [Linea 107]
│           │
│           ├── ValidaUsuario() [Linea 191]
│           │   │
│           │   ├── DbMainDate = GetDbNow(DbMain)
│           │   ├── gUsuario.Nombre = LCase(Trim(Tx_Nombre))
│           │   │
│           │   ├── Q1 = "SELECT IdUsuario, Clave, PrivAdm, Activo,
│           │   │         HabilitadoHasta FROM Usuarios
│           │   │         WHERE Usuario = '{nombre}'"
│           │   │
│           │   ├── Si Rs.EOF = True → "Usuario desconocido" → Exit
│           │   │
│           │   ├── Si Clave <> GenClave() → "Clave incorrecta" → Exit
│           │   │
│           │   ├── Si PrivAdm <> PRV_ADM And nombre <> gAdmUser
│           │   │   └── "No tiene privilegio de administrador" → Exit
│           │   │
│           │   ├── Si Activo = 0 → "Usuario no activo" → Exit
│           │   │
│           │   ├── Si HabilitadoHasta > 0 And Now > HabilitadoHasta
│           │   │   └── "Usuario no activo" → UPDATE → Exit
│           │   │
│           │   ├── gUsuario.IdUsuario = Rs("idUsuario")
│           │   ├── gUsuario.ClaveActual = Rs("Clave")
│           │   └── Return True
│           │
│           ├── SetLastUser(gIniFile, gUsuario.Nombre)
│           ├── SetIniString(gIniFile, "Config", "LinkAdm", Ck_Link)
│           │
│           ├── Si Ck_Link → CreateLnk("$Desktop\" & gAppCode.Title)
│           │
│           ├── lRc = vbOK
│           └── Unload Me
│
├── Set Frm = New FrmMain                 [MENU PRINCIPAL ADMIN]
├── Frm.Show vbModeless
├── Unload FrmStart
│
└── [USUARIO] Menu: Empresas → Mantencion
    │
    └── M_MantEmpresas_Click [Linea 1193]
        │
        ├── Set Frm = New FrmEmpresas
        └── Frm.Show vbModal              [LISTA EMPRESAS]
            │
            ├── Form_Load [Linea 411]
            │   ├── SetUpGrid()
            │   │   ├── FGrSetup(Grid)
            │   │   ├── Grid.ColWidth(C_RUT) = 1500
            │   │   ├── Grid.ColWidth(C_NOMBRECORTO) = 2500
            │   │   ├── Grid.ColWidth(C_ID) = 0 [oculto]
            │   │   ├── Grid.ColWidth(C_ESTADO) = 1000
            │   │   └── Encabezados: "RUT", "Nombre Corto", "Activa"
            │   │
            │   ├── LoadAll()
            │   │   ├── Q1 = "SELECT IdEmpresa, Rut, NombreCorto, Estado
            │   │   │         FROM Empresas"
            │   │   ├── Si gAppCode.Demo → WHERE RUT IN ('1','2','3')
            │   │   ├── ORDER BY NombreCorto / Rut
            │   │   └── Poblar Grid con resultados
            │   │
            │   └── La_demo.Visible = gAppCode.Demo
            │
            └── [USUARIO] Click boton "Nueva"
                │
                └── Bt_New_Click [Linea 328]
                    │
                    ├── VALIDACION DE LICENCIA:
                    │   ├── n = 0
                    │   ├── Si gAppCode.NivProd <> VER_ILIM
                    │   │   └── For cada fila: Si C_ID <> "" → n++
                    │   │
                    │   ├── Si gAppCode.NivProd = VER_DEMO And n >= 3
                    │   │   └── "Ya tiene cantidad permitidas para demo" → Exit
                    │   │
                    │   └── Si n >= gMaxEmpLicencia
                    │       └── "Ya tiene cantidad permitidas por licencia" → Exit
                    │
                    ├── Set Frm = New FrmMantEmpresa
                    │
                    └── Frm.FNew(id, Rut, NCorto) [Linea 226]
                        │
                        ├── lOper = OPER_NEW
                        ├── lId = id, lRut = Rut, lNCorto = NCorto
                        │
                        └── Me.Show vbModal       [NUEVA EMPRESA MODAL]
                            │
                            ├── Form_Load [Linea 257]
                            │   ├── lRc = vbCancel
                            │   │
                            │   ├── Si lOper = OPER_NEW
                            │   │   ├── Me.Caption = "Nueva empresa"
                            │   │   ├── Ch_NoActivo.Visible = False
                            │   │   └── Si lRut <> "" → Tx_RUT = FmtCID(lRut)
                            │   │
                            │   └── Si lOper = OPER_EDIT
                            │       ├── Me.Caption = "Modificar Empresa"
                            │       ├── Tx_RUT.Enabled = False
                            │       └── Cargar datos existentes
                            │
                            ├── [USUARIO] Ingresa RUT
                            │   │
                            │   └── Tx_Rut_LostFocus [Linea 288]
                            │       ├── Si Tx_RUT = "" → Exit
                            │       ├── Si vFmtCID(Tx_RUT) = 0 → Limpiar, SetFocus
                            │       └── Tx_RUT = FmtCID(vFmtCID(Tx_RUT))
                            │
                            ├── Tx_RUT_Validate [Linea 310]
                            │   ├── Si Tx_RUT = "" → Exit
                            │   ├── Si Trim(Tx_RUT) = "0-0" → "RUT Invalido" → Cancel
                            │   └── Si Not MsgValidRut → SetFocus → Cancel
                            │
                            ├── [USUARIO] Ingresa Nombre Corto
                            │
                            └── [USUARIO] Click "Aceptar"
                                │
                                └── Bt_OK_Click [Linea 175]
                                    │
                                    ├── Valida() [Linea 107]
                                    │   │
                                    │   ├── Si Rut = "" → "Debe ingresar RUT" → False
                                    │   │
                                    │   ├── Si Rut <> "" And Tx_NCorto = ""
                                    │   │   └── "Debe ingresar nombre corto" → False
                                    │   │
                                    │   ├── Si gAppCode.Demo = True
                                    │   │   └── Si Rut NOT IN ('1-9','2-7','3-5')
                                    │   │       └── "En DEMO solo RUTs: 1-9, 2-7, 3-5" → False
                                    │   │
                                    │   ├── Si ValidaNivel(1, "", 1) → False
                                    │   │
                                    │   ├── Q1 = "SELECT Rut FROM Empresas
                                    │   │         WHERE Rut='{rut_formateado}'"
                                    │   │   └── Si existe And lOper = OPER_NEW
                                    │   │       └── "Ya existe empresa con este RUT" → False
                                    │   │
                                    │   ├── Q1 = "SELECT idEmpresa FROM Empresas
                                    │   │         WHERE NombreCorto='{nombre}'"
                                    │   │   └── Si existe And (NEW Or EDIT otro)
                                    │   │       └── "Ya existe nombre corto" → False
                                    │   │
                                    │   └── Return True
                                    │
                                    ├── Si lOper = OPER_NEW
                                    │   │
                                    │   ├── FldArray(0).FldName = "Rut"
                                    │   ├── FldArray(0).FldValue = vFmtCID(Tx_RUT)
                                    │   ├── FldArray(0).FldIsNum = False
                                    │   │
                                    │   ├── FldArray(1).FldName = "NombreCorto"
                                    │   ├── FldArray(1).FldValue = ParaSQL(Tx_NCorto)
                                    │   ├── FldArray(1).FldIsNum = False
                                    │   │
                                    │   └── lId = AdvTbAddNewMult(DbMain, "Empresas",
                                    │                             "IdEmpresa", FldArray)
                                    │       │
                                    │       └── [En PamDb.bas Linea 4720]
                                    │           ├── Rs.AddNew
                                    │           ├── lId = Rs(FldId) [autonumerico]
                                    │           ├── Rs("Rut") = valor
                                    │           ├── Rs("NombreCorto") = valor
                                    │           ├── Rs.Update
                                    │           └── Return lId
                                    │
                                    ├── Estado = IIf(Ch_NoActivo.Visible,
                                    │                IIf(Ch_NoActivo=0, 0, 1), 0)
                                    │
                                    ├── Q1 = "UPDATE Empresas SET
                                    │         NombreCorto='{nombre}', Estado={estado}
                                    │         WHERE IdEmpresa={lId}"
                                    ├── ExecSQL(DbMain, Q1)
                                    │
                                    ├── lRut = Tx_RUT
                                    ├── lNCorto = Tx_NCorto
                                    ├── lRc = vbOK
                                    ├── lEstado = Estado
                                    │
                                    └── Unload Me
                                        │
                                        └── [RETORNA A FrmEmpresas]

                    [CONTINUA EN Bt_New_Click despues de FNew]
                    │
                    ├── Si Frm.FNew() = vbOK
                    │   │
                    │   ├── Row = FGrAddRow(Grid)
                    │   ├── Grid.TextMatrix(Row, C_NOMBRECORTO) = NCorto
                    │   ├── Grid.TextMatrix(Row, C_ID) = id
                    │   ├── Grid.TextMatrix(Row, C_RUT) = FmtCID(Rut)
                    │   ├── Grid.TextMatrix(Row, C_ESTADO) = "Si"
                    │   │
                    │   └── Auditoria_Empresas(id, Rut, NCorto, "Crea",
                    │                          "Estado=Si", "Nueva Empresa")
                    │       │
                    │       └── [En HyperComun.bas Linea 4307]
                    │           └── INSERT INTO Auditoria_Empresas
                    │               (idEmpresa, Rut, Nombre_Empresa, Annio,
                    │                Tipo_Evento, Descripcion, Modulo,
                    │                Fecha_Evento, Usuario)
                    │               VALUES (...)
                    │
                    └── Set Frm = Nothing
```

### 4.2 Flujo Alternativo: Crear Empresa desde HyperRenta

```
M_ImpEmpHR_Click [Linea 855]
│
├── Set Frm = New FrmEmpHR
├── Rc = Frm.FSelect()
│   │
│   └── [SELECCION DE EMPRESA EN HYPERRENTA]
│       ├── Muestra lista de empresas HR
│       ├── Usuario selecciona
│       ├── Popula gEmprHR.EmpConta.Rut
│       ├── Popula gEmprHR.EmpConta.NombreCorto
│       └── Return vbOK
│
├── Set Frm = Nothing
│
└── Si Rc = vbOK
    │
    ├── Set FrmE = New FrmMantEmpresa
    │
    ├── FrmE.FNew(0, gEmprHR.EmpConta.Rut, gEmprHR.EmpConta.NombreCorto)
    │   │
    │   └── Form_Load prepopula:
    │       ├── Tx_RUT = FmtCID(lRut)  [RUT de HR]
    │       └── Tx_NCorto = lNCorto     [Nombre de HR]
    │
    ├── Auditoria_Empresas(0, Rut, NCorto, "Crear", "Estado=Si",
    │                      "Capturar Empresas desde HR")
    │
    └── Set FrmE = Nothing
```

### 4.3 Flujo: Modificar Empresa

```
[En FrmEmpresas]
│
├── [USUARIO] Selecciona fila en Grid
├── [USUARIO] Click "Modificar" O doble-click en Grid
│
└── Bt_Ren_Click [Linea 367] / Grid_DblClick [Linea 486]
    │
    ├── Row = Grid.Row
    ├── Si Row < Grid.FixedRows → Exit
    ├── Si Trim(Grid.TextMatrix(Row, C_RUT)) = "" → Exit
    │
    ├── id = Grid.TextMatrix(Row, C_ID)
    ├── Rut = Grid.TextMatrix(Row, C_RUT)
    ├── NCorto = Grid.TextMatrix(Row, C_NOMBRECORTO)
    │
    ├── Set Frm = New FrmMantEmpresa
    ├── Estado = IIf(LCase(Grid.TextMatrix(Row, C_ESTADO)) = "si", 0, 1)
    │
    └── Frm.FEdit(id, Rut, NCorto, Estado) [Linea 242]
        │
        ├── lOper = OPER_EDIT
        ├── lId = id, lRut = Rut, lNCorto = NCorto, lEstado = Estado
        │
        └── Me.Show vbModal
            │
            ├── Form_Load
            │   ├── Me.Caption = "Modificar Empresa"
            │   ├── Tx_RUT.Enabled = False    [NO editable]
            │   ├── Tx_RUT = lRut
            │   ├── Tx_NCorto = lNCorto
            │   └── Ch_NoActivo = lEstado
            │
            ├── [USUARIO] Modifica datos permitidos
            │
            └── Bt_OK_Click
                ├── Valida()
                ├── UPDATE Empresas SET NombreCorto, Estado
                ├── lRc = vbOK
                └── Unload Me

        [RETORNA A FrmEmpresas]
        │
        ├── Si FEdit = vbOK
        │   ├── Actualizar Grid
        │   └── Auditoria_Empresas(..., "Modifica" o "Inactiva", ...)
        │
        └── Set Frm = Nothing
```

### 4.4 Flujo: Eliminar Empresa

```
[En FrmEmpresas]
│
└── Bt_Del_Click [Linea 181]
    │
    ├── Row = Grid.Row
    ├── Si Row < Grid.FixedRows → Exit
    ├── Si Trim(Grid.TextMatrix(Row, C_RUT)) = "" → Exit
    │
    ├── id = Grid.TextMatrix(Row, C_ID)
    ├── Rut = Grid.TextMatrix(Row, C_RUT)
    ├── NCorto = Grid.TextMatrix(Row, C_NOMBRECORTO)
    │
    ├── Auditoria_Empresas(id, Rut, NCorto, "Elimina",
    │                      "Se Elimino Empresa", "Eliminar Empresa")
    │
    ├── MsgBox: "ATENCION! Se eliminaran todos los datos de {NCorto}
    │            y no podra recuperarlos. ¿Desea continuar?"
    │   └── Si vbNo → Exit
    │
    ├── SeDel = True
    ├── MousePointer = vbHourglass
    │
    ├── [SI DATACON=1 - Access con BD separadas]
    │   │
    │   ├── Q1 = "SELECT Ano FROM EmpresasAno WHERE IdEmpresa={id}"
    │   │
    │   └── Para cada Ano:
    │       ├── DbName = gDbPath & "\Empresas\" & Ano & "\" & Rut & ".mdb"
    │       ├── Si ExistFile(DbName)
    │       │   └── Si Not KillFile(DbName)
    │       │       ├── "No puede eliminar ano {Ano}, esta abierta"
    │       │       ├── SeDel = False
    │       │       └── Exit Do
    │       ├── DbName backup = gDbPath & "\Empresas\" & Ano & "\B_" & Rut & ".mdb"
    │       ├── Si ExistFile → KillFile
    │       └── DELETE FROM EmpresasAno WHERE IdEmpresa={id} AND Ano={ano}
    │
    ├── [SI DATACON=2 - SQL Server]
    │   │
    │   ├── sWhere = " WHERE IdEmpresa = " & id
    │   │
    │   └── DELETE FROM cada tabla:
    │       ├── ActFijoCompsFicha, ActFijoFicha
    │       ├── AjustesExtLibCaja, AsistImpPrimCat
    │       ├── BaseImponible14Ter, Cartola
    │       ├── Comprobante, ControlEmpresa
    │       ├── CtasAjustesExCont, Cuentas, CuentasBasicas
    │       ├── DetCartola, DetSaldosAp, DocCuotas
    │       ├── Documento, Empresa (WHERE Id={id})
    │       ├── EstadoMes, EmpresasAno
    │       ├── ImpAdic, InfoAnualDJ1847
    │       ├── LibroCaja, LogComprobantes, LogImpreso
    │       ├── MovActivoFijo, MovComprobante, MovDocumento
    │       ├── ParamEmpresa, PropIVA_TotMensual, Socios
    │       ├── AFComponentes, AFGrupos
    │       ├── AreaNegocio, CentroCosto
    │       ├── CT_Comprobante, CT_MovComprobante
    │       ├── CuentasRazon, Entidades, Glosas
    │       ├── Notas, ParamRazon, Sucursales
    │
    ├── Si SeDel
    │   ├── DELETE FROM Empresas WHERE IdEmpresa={id}
    │   ├── DELETE FROM UsuarioEmpresa WHERE IdEmpresa={id}
    │   ├── Grid.RemoveItem(Row)
    │   ├── FGrVRows(Grid)
    │   └── MsgBox "La empresa ha sido eliminada"
    │
    └── MousePointer = vbDefault
```

---

## 5. FLUJOS DE GESTION DE USUARIOS

### 5.1 Crear Usuario

```
MC_Usuarios_Click [Linea 1277]
│
├── Set Frm = New FrmUsuarios
└── Frm.Show vbModal
    │
    ├── Form_Load [Linea 163]
    │   ├── Q1 = "SELECT Usuario, idUsuario FROM Usuarios
    │   │         WHERE Usuario<>'Administ'"
    │   ├── FillCombo(Ls_Usuario, DbMain, Q1, -1)
    │   └── Si gAppCode.Demo → Bt_New.Enabled = False
    │
    └── [USUARIO] Click "Nuevo"
        │
        └── Bt_New_Click [Linea 147]
            │
            ├── MousePointer = vbHourglass
            ├── Set Frm = New FrmMantUsuario
            │
            └── Frm.FNew(Nombre, IdUsuario) [Linea 227]
                │
                ├── Oper = OPER_NEW
                └── Me.Show vbModal
                    │
                    ├── Form_Load [Linea 195]
                    │   ├── lRc = vbCancel
                    │   └── Caption = "Nuevo usuario"
                    │
                    ├── [USUARIO] Ingresa:
                    │   ├── Tx_Nombre (login, max 15)
                    │   ├── Tx_NombreLargo (nombre completo, max 30)
                    │   ├── Tx_Clave1 (clave, max 10)
                    │   ├── Tx_Clave2 (repetir clave)
                    │   ├── Ch_Activo (checkbox activo)
                    │   ├── Ck_PrvAdm (checkbox administrador)
                    │   └── Tx_Hasta (fecha habilitado hasta)
                    │
                    └── Bt_OK_Click [Linea 211]
                        │
                        ├── Valida() [Linea 305]
                        │   ├── Si Tx_Nombre = "" → "Debe ingresar nombre"
                        │   ├── Si Tx_NombreLargo = "" → "Debe ingresar nombre largo"
                        │   ├── Si usuario existe → "Este usuario ya existe"
                        │   └── Si Tx_Clave1 <> Tx_Clave2 → "Las claves son distintas"
                        │
                        ├── MousePointer = vbHourglass
                        ├── SaveAll() [Linea 248]
                        │   │
                        │   ├── t_Nombre = LCase(Trim(Tx_Nombre))
                        │   ├── Clave = LCase(Trim(Tx_Clave1))
                        │   │
                        │   ├── StrClave = " Clave='" & GenClave(t_Nombre & Clave) & "',"
                        │   │
                        │   ├── lidUsuario = AdvTbAddNew(DbMain, "Usuarios",
                        │   │                            "idUsuario", "Usuario", t_Nombre)
                        │   │
                        │   └── Q1 = "UPDATE Usuarios SET " & StrClave &
                        │            "Usuario='{nombre}', NombreLargo='{largo}',
                        │             PrivAdm={priv}, Activo={activo},
                        │             HabilitadoHasta={fecha}
                        │             WHERE IdUsuario={id}"
                        │
                        ├── lRc = vbOK
                        ├── lNombre = Tx_Nombre
                        └── Unload Me

                [RETORNA A FrmUsuarios]
                │
                ├── Si FNew = vbOK
                │   ├── Ls_Usuario.AddItem Nombre
                │   └── Ls_Usuario.ItemData(NewIndex) = IdUsuario
                │
                └── Set Frm = Nothing
```

### 5.2 Modificar Usuario

```
[En FrmUsuarios]
│
├── [USUARIO] Selecciona en lista
├── [USUARIO] Click "Modificar" O doble-click
│
└── Bt_Mod_Click [Linea 116] / Ls_Usuario_DblClick [Linea 174]
    │
    ├── Si Ls_Usuario.ListCount = 0 → Exit
    ├── Si Ls_Usuario.ListIndex = -1 → Exit
    │
    ├── IdUsuario = Ls_Usuario.ItemData(ListIndex)
    ├── Nombre = Ls_Usuario.Text
    │
    ├── Set Frm = New FrmMantUsuario
    │
    └── Frm.FEdit(Nombre, IdUsuario) [Linea 238]
        │
        ├── lidUsuario = IdUsuario
        ├── Oper = OPER_EDIT
        └── Me.Show vbModal
            │
            ├── Form_Load
            │   ├── Caption = "Editar usuario"
            │   └── FillForm() [Linea 381]
            │       ├── Q1 = "SELECT Usuario, Clave, NombreLargo, PrivAdm,
            │       │         Activo, HabilitadoHasta FROM Usuarios
            │       │         WHERE idUsuario={id}"
            │       ├── OldNombre = Rs("Usuario")
            │       ├── Tx_Nombre = Rs("Usuario")
            │       ├── ClaveActual = Rs("Clave")
            │       ├── Tx_NombreLargo = Rs("NombreLargo")
            │       ├── Ck_PrvAdm.Value = Rs("PrivAdm")
            │       ├── Ch_Activo.Value = Rs("Activo")
            │       └── SetTxDate(Tx_Hasta, Rs("HabilitadoHasta"))
            │
            ├── [USUARIO] Modifica campos
            │   └── Si modifica clave → Ch_Clave.Value = 1
            │
            └── Bt_OK_Click
                ├── Valida()
                ├── SaveAll() [solo actualiza si Ch_Clave o campos cambiados]
                ├── lRc = vbOK
                └── Unload Me

        [RETORNA A FrmUsuarios]
        │
        ├── Si FEdit = vbOK
        │   └── Ls_Usuario.List(ListIndex) = Nombre
        │
        └── Set Frm = Nothing
```

### 5.3 Eliminar Usuario

```
Bt_Del_Click [Linea 82]
│
├── Si Ls_Usuario.ListCount = 0 → Exit
├── Si Ls_Usuario.ListIndex = -1 → Exit
│
├── MsgBox: "Esta seguro que desea eliminar al usuario {nombre}?"
│   └── Si <> vbYes → Exit
│
├── DELETE FROM Usuarios WHERE IdUsuario = {id}
├── Ls_Usuario.RemoveItem ListIndex
│
└── Si ListCount > 0 → ListIndex = 0
```

---

## 6. FLUJOS DE COMPROBANTES

### 6.1 Crear Nuevo Comprobante

```
M_NewComprob_Click [Linea 3097]
│
├── Si ValidaIngresoComp() = False → Exit
│
├── MousePointer = vbHourglass
├── Set Frm = New FrmComprobante
│
└── Frm.FNew(False) [CompTipo=False]
    │
    ├── lOper = O_NEW
    ├── SetTblName(CompTipo)    ' Comprobante vs ComprobanteTipo
    ├── lCompTipo = CompTipo
    ├── lidComp = 0
    ├── lCorrelativo = 0
    │
    └── Me.Show vbModal
        │
        ├── Form_Load
        │   ├── Caption segun lOper:
        │   │   ├── O_NEW → "Nuevo Comprobante"
        │   │   ├── O_EDIT → "Modificar Comprobante"
        │   │   └── O_VIEW → "Ver Comprobante"
        │   │
        │   ├── Llenar Cb_Tipo con tipos de comprobante
        │   ├── Llenar Cb_Estado con estados
        │   │
        │   ├── SetUpGrid() - Configurar grid de movimientos:
        │   │   ├── C_IDCUENTA, C_CODIGO, C_CUENTA
        │   │   ├── C_DESCRIPCION, C_DEBE, C_HABER
        │   │   └── 23 filas x 24 columnas
        │   │
        │   ├── Fecha por defecto = DateSerial(gEmpresa.Ano, mes, dia)
        │   │
        │   └── Si gDbType = SQL_SERVER → Configurar paginacion
        │
        ├── [USUARIO] Selecciona Tipo
        ├── [USUARIO] Confirma/modifica Fecha
        ├── [USUARIO] Ingresa Glosa general
        │
        ├── [PARA CADA LINEA DE DETALLE]:
        │   │
        │   ├── [USUARIO] Click en celda de cuenta
        │   │   │
        │   │   └── Bt_Cuentas_Click
        │   │       │
        │   │       ├── Set FrmP = New FrmPlanCuentas
        │   │       │
        │   │       └── FrmP.FSelEdit(IdCuenta, Codigo, Descrip, Nombre)
        │   │           │
        │   │           └── Me.Show vbModal
        │   │               ├── Usuario navega arbol de cuentas
        │   │               ├── Selecciona cuenta
        │   │               └── Return vbOK con datos
        │   │
        │   ├── [USUARIO] Ingresa monto en DEBE o HABER
        │   └── [USUARIO] Ingresa descripcion de linea
        │
        ├── [SISTEMA] Valida: Total DEBE = Total HABER
        │
        └── [USUARIO] Click "Aceptar"
            │
            └── Bt_OK_Click
                │
                ├── valida() - Validaciones completas
                │   ├── Fecha en periodo activo
                │   ├── Al menos un movimiento
                │   ├── Debe = Haber (balanceado)
                │   ├── Cuentas validas
                │   └── Montos > 0
                │
                └── SaveAll()
                    │
                    ├── [SI O_NEW]
                    │   ├── INSERT INTO Comprobante
                    │   │   (IdEmpresa, Ano, Tipo, IdUsuario, FechaCreacion,
                    │   │    Fecha, TipoAjuste, Correlativo)
                    │   │   VALUES (..., -1)
                    │   │
                    │   └── lidComp = @@IDENTITY / LAST_INSERT_ID
                    │
                    ├── Asignar Correlativo:
                    │   ├── Si gTipoCorrComp = TCC_UNICO
                    │   │   └── lCorrelativo = lidComp
                    │   └── Si gTipoCorrComp = TCC_MULTIPLE
                    │       └── lCorrelativo = MAX(Correlativo)+1 por tipo
                    │
                    ├── SaveMovs() - Para cada linea del grid:
                    │   └── INSERT INTO MovComprobante
                    │       (IdComp, NumLinea, IdCuenta, Debe, Haber, Glosa, ...)
                    │
                    ├── UPDATE Comprobante SET
                    │   TotalDebe = {suma}, TotalHaber = {suma},
                    │   Correlativo = {corr}, Estado = {estado}
                    │   WHERE IdComp = {id}
                    │
                    └── SeguimientoComprobantes() - Log de auditoria
```

### 6.2 Listar/Editar Comprobantes

```
M_EditComprob_Click [Linea 2569]
│
├── Set Frm = New FrmLstComp
│
└── Frm.FView()
    │
    └── Me.Show vbModal
        │
        ├── Form_Load
        │   ├── Configurar filtros: Fecha, Tipo, Estado, Glosa, etc.
        │   ├── SetUpGrid() - Grid de comprobantes
        │   └── LoadAll() - Cargar con filtros actuales
        │
        ├── [USUARIO] Configura filtros
        ├── [USUARIO] Click "Buscar"
        │   └── LoadAll() con WHERE construido
        │
        ├── [USUARIO] Selecciona comprobante
        │
        └── [USUARIO] Click "Detalle" o doble-click
            │
            └── Bt_DetComp_Click
                │
                ├── IdComp = Grid.TextMatrix(Row, C_IDCOMP)
                │
                ├── Set FrmC = New FrmComprobante
                │
                └── FrmC.FEdit(IdComp, False)
                    │
                    └── Me.Show vbModal
                        ├── LoadAll() - Cargar datos existentes
                        ├── [USUARIO] Modifica si Estado = Pendiente
                        └── SaveAll() si cambios
```

### 6.3 Cambiar Estado de Comprobantes

```
[En FrmLstComp]
│
├── [USUARIO] Selecciona comprobantes (checkboxes)
│
└── Bt_CambiarEstadoComps_Click [Linea 791]
    │
    ├── Obtener lista de IdComp seleccionados
    │
    ├── FrmCambioEstadoComp.FSelect(NuevoEstado)
    │   └── Usuario selecciona nuevo estado
    │
    └── UPDATE Comprobante SET Estado = {nuevo}
        WHERE IdComp IN ({lista})
```

---

## 7. FLUJOS DE DOCUMENTOS

### 7.1 Nuevo Documento (Compras/Ventas)

```
M_NewDoc_Click [Linea 3114]
│
├── Set Frm = New FrmSelLibDocs
│
└── Frm.FSelectMes(TipoLib, Mes, Ano, False)
    │
    └── Me.Show vbModal
        │
        ├── Form_Load
        │   ├── Mostrar opciones de libro:
        │   │   ├── Op_Libros(0) = "TODOS" (Tag=0)
        │   │   ├── Op_Libros(1) = "Libro de Compras" (Tag=1)
        │   │   ├── Op_Libros(2) = "Libro de Ventas" (Tag=2)
        │   │   ├── Op_Libros(3) = "Libro de Retenciones" (Tag=3)
        │   │   ├── Op_Libros(4) = "Docs. Remuneraciones" (Tag=4)
        │   │   ├── Op_Libros(5) = "Otros Documentos" (Tag=5)
        │   │   └── Op_Libros(6) = "Otros Documentos Full" (Tag=8)
        │   │
        │   ├── Cb_Mes - Meses 1-12
        │   └── Cb_Ano - Anos disponibles
        │
        ├── [USUARIO] Selecciona libro
        ├── [USUARIO] Selecciona mes/ano
        │
        └── Bt_Sel_Click
            │
            ├── TipoLib = Op_Libros(seleccionado).Tag
            │
            ├── [SI LIB_COMPRAS o LIB_VENTAS]
            │   │
            │   ├── Validar: gCtasBas.IdCtaIVACred > 0 AND gCtasBas.IdCtaIVADeb > 0
            │   │   └── Si no → "Debe definir cuentas de IVA" → Exit
            │   │
            │   ├── Set FrmCV = New FrmCompraVenta
            │   │
            │   └── FrmCV.FEdit(TipoLib, Mes, Ano, IdDoc)
            │       │
            │       └── [VER SECCION 7.2]
            │
            ├── [SI LIB_RETEN]
            │   │
            │   ├── Validar: gCtasBas.IdCtaImpRet > 0 AND gCtasBas.IdCtaNetoHon > 0
            │   │
            │   ├── Set FrmR = New FrmLibRetenciones
            │   │
            │   └── FrmR.FEdit(Mes, Ano, IdDoc)
            │
            └── [SI LIB_OTROS]
                │
                ├── Set FrmD = New FrmLstDoc
                │
                └── FrmD.FEdit(TipoLib, Mes, Ano, True)
```

### 7.2 Ingreso de Documentos Compras/Ventas

```
FrmCompraVenta.FEdit(TipoLib, Mes, Ano, IdDoc)
│
├── lOper = O_EDIT
├── lTipoLib = TipoLib
├── lMes = Mes
├── lAno = Ano
│
└── Me.Show vbModal
    │
    ├── Form_Load
    │   │
    │   ├── SetUpGrid() - Configurar segun TipoLib:
    │   │   │
    │   │   ├── [COMPRAS]
    │   │   │   ├── C_FECHA, C_NUM_DOC, C_RUT, C_PROVEEDOR
    │   │   │   ├── C_MONTO_NETO, C_IVA, C_TOTAL
    │   │   │   ├── C_EXENTO, C_NUM_TIMBRE, C_OTROS_IMP
    │   │   │   └── C_GLOSA
    │   │   │
    │   │   └── [VENTAS]
    │   │       ├── C_FECHA, C_NUM_DOC, C_RUT, C_CLIENTE
    │   │       ├── C_MONTO_NETO, C_IVA, C_TOTAL
    │   │       ├── C_DOC_HASTA, C_MAQ_REG, C_CANT_BOLETAS
    │   │       └── C_GLOSA
    │   │
    │   ├── Configurar opciones visibles:
    │   │   ├── Ch_ViewExento, Ch_ViewDTE
    │   │   ├── Ch_ViewSucursal, Ch_ViewOtrosImp
    │   │   └── Ch_ViewPropIVA (solo compras)
    │   │
    │   └── LoadAll() - Cargar documentos existentes del periodo
    │
    ├── [PARA CADA DOCUMENTO - fila del grid]:
    │   │
    │   ├── [USUARIO] Ingresa FECHA
    │   │   └── Validacion: Dentro del periodo seleccionado
    │   │
    │   ├── [USUARIO] Ingresa NUM_DOC
    │   │   └── Validacion: Unico por proveedor/periodo
    │   │
    │   ├── [USUARIO] Ingresa RUT
    │   │   │
    │   │   └── Grid_LostFocus / Bt_SelEnt_Click
    │   │       │
    │   │       ├── Buscar en Entidades WHERE Rut = {rut}
    │   │       │
    │   │       ├── Si existe → Cargar nombre automaticamente
    │   │       │
    │   │       └── Si no existe
    │   │           ├── Preguntar: "Desea crear entidad?"
    │   │           │
    │   │           └── Si vbYes
    │   │               ├── Set FrmE = New FrmEntidad
    │   │               └── FrmE.FNew(Entidad, Rut)
    │   │
    │   ├── [USUARIO] Ingresa MONTO_NETO
    │   │   └── [SISTEMA] Calcula automaticamente:
    │   │       ├── IVA = MONTO_NETO * 0.19
    │   │       └── TOTAL = MONTO_NETO + IVA
    │   │
    │   ├── [USUARIO] Puede modificar IVA manualmente
    │   │
    │   └── [USUARIO] Ingresa campos opcionales
    │
    └── [USUARIO] Click "Aceptar"
        │
        └── Bt_OK_Click
            │
            ├── valida() - Validar todos los documentos
            │
            └── SaveAll()
                │
                ├── SaveGrid() - Para cada fila:
                │   │
                │   ├── Si es nueva (C_ID = 0)
                │   │   └── INSERT INTO Documento (...)
                │   │
                │   ├── Si modificada
                │   │   └── UPDATE Documento SET ... WHERE IdDoc = {id}
                │   │
                │   └── Si eliminada
                │       └── DELETE FROM Documento WHERE IdDoc = {id}
                │
                └── CalcPropIVALibro() - Recalcular proporcionalidad
```

---

## 8. FLUJOS DE CONFIGURACION

### 8.1 Configuracion Inicial

```
M_Config_Click [Linea 2527]
│
├── Set Frm = New FrmConfig
│
└── Frm.Show vbModal
    │
    ├── Form_Load
    │   ├── Cargar todas las tabs de configuracion
    │   └── Inicializar combos y listas
    │
    ├── [TAB 1: Plan de Cuentas]
    │   │
    │   ├── Bt_GetPlanDef_Click
    │   │   └── GetPlanPreDef(tipo) - Cargar plan predefinido
    │   │
    │   └── Bt_EditPlan_Click
    │       └── FrmPlanCuentas.FViewCuentas()
    │
    ├── [TAB 2: Cuentas Definidas]
    │   │
    │   └── Por cada cuenta basica:
    │       │
    │       └── Bt_SelCuenta_Click
    │           │
    │           ├── Set FrmP = New FrmPlanCuentas
    │           │
    │           └── FrmP.FSelect(IdCuenta, Codigo, Descrip, Nombre)
    │               └── Usuario selecciona cuenta
    │
    ├── [TAB 3: Cuentas Lib Compras/Ventas]
    │   └── FrmPlanCuentas.FSelCuentasBasicas(TipoLib, TipoVal)
    │
    ├── [TAB 4: Impuestos Adicionales]
    │
    ├── [TAB 5: Niveles del Plan]
    │
    └── [TAB 6: Configuracion Informes]
```

### 8.2 Plan de Cuentas

```
M_Plan_Click [Linea 3193]
│
├── Set Frm = New FrmPlanCuentas
│
└── Frm.FEdit()
    │
    └── Me.Show vbModal
        │
        ├── Form_Load
        │   ├── lTblCuentas = "Cuentas"
        │   ├── Habilitar/deshabilitar segun FCierre
        │   ├── FillRoot() - Inicializar arbol
        │   ├── Cb_Buscar: ORDPLAN_DESC, ORDPLAN_COD, ORDPLAN_NOM
        │   └── SetupPriv()
        │
        ├── [EXPANDIR NODO]
        │   │
        │   └── Tr_Plan_Expand(Node)
        │       └── SELECT ... FROM Cuentas WHERE Nivel, IdPadre
        │
        ├── [USUARIO] Click "Nueva"
        │   │
        │   └── Bt_New_Click
        │       │
        │       ├── Set FrmC = New FrmCuenta
        │       │
        │       └── FrmC.FNew(lCuenta)
        │           │
        │           └── Me.Show vbModal
        │               ├── Usuario ingresa: Codigo, Nombre, Nivel, Clasificacion
        │               ├── Selecciona Cuenta Padre si Nivel > 1
        │               ├── Opcional: Codigo IFRS
        │               └── INSERT INTO Cuentas
        │
        ├── [USUARIO] Click "Editar"
        │   │
        │   └── Bt_Edit_Click
        │       │
        │       ├── Set FrmC = New FrmCuenta
        │       │
        │       └── FrmC.FEdit(lCuenta)
        │           └── UPDATE Cuentas SET ...
        │
        ├── [USUARIO] Click "Eliminar"
        │   │
        │   └── Bt_Del_Click
        │       ├── Validar: No tiene movimientos asociados
        │       └── DELETE FROM Cuentas WHERE IdCuenta = {id}
        │
        └── [USUARIO] Click "Buscar"
            │
            └── Bt_Search_Click
                └── Buscar por Codigo, Nombre o Descripcion
```

---

## 9. CONVENCIONES DE PARAMETROS Y RETORNOS

### 9.1 Codigos de Retorno

| Codigo | Constante | Significado | Uso |
|--------|-----------|-------------|-----|
| 1 | vbOK | Exito - confirmo guardar/seleccionar | Mayoría de formularios |
| 2 | vbCancel | Usuario cancelo operacion | Cierre sin accion |
| 4 | vbRetry | Duplicado existe (Entidad) | FrmEntidad.FNew - entidad ya existe |
| 6 | vbYes | Usuario confirmo Si | Dialogos de confirmacion |
| 7 | vbNo | Usuario confirmo No | Dialogos de confirmacion |

### 9.2 Operaciones de Formulario (lOper)

| Valor | Constante | Descripcion | Controles Visibles |
|-------|-----------|-------------|-------------------|
| 1 | O_NEW | Crear nuevo registro | Bt_OK, Bt_Cancel |
| 2 | O_EDIT | Editar existente | Bt_New, Bt_Edit, Bt_Del |
| 3 | O_VIEW | Solo lectura | Bt_Sel (seleccionar) |
| 4 | O_SELECT | Seleccionar de lista | Bt_Sel |
| 5 | O_SELEDIT | Seleccionar con opcion editar | Bt_Sel, Bt_Edit |

### 9.3 Tipos de Libro (TipoLib)

| Valor | Constante | Descripcion |
|-------|-----------|-------------|
| 1 | LIB_COMPRAS | Libro de Compras |
| 2 | LIB_VENTAS | Libro de Ventas |
| 3 | LIB_RETEN | Libro de Retenciones |
| 4 | LIB_OTROS | Otros Documentos |
| 5 | LIB_REMU | Documentos de Remuneraciones |
| 8 | LIB_OTROS_FULL | Otros Documentos Full |

### 9.4 Estados de Documento (EstadoDoc)

| Constante | Descripcion |
|-----------|-------------|
| ED_PENDIENTE | Pendiente |
| ED_CENTRALIZADO | Centralizado |
| ED_PAGADO | Pagado |
| ED_ANULADO | Anulado |
| ED_CENTPAG | Centralizado o Pagado |

### 9.5 Clasificacion de Entidades

| Valor | Constante | Descripcion |
|-------|-----------|-------------|
| 0 | ENT_CLIENTE | Cliente |
| 1 | ENT_PROVEEDOR | Proveedor |
| 2 | ENT_EMPLEADO | Empleado |
| 3 | ENT_SOCIO | Socio |
| 4 | ENT_DISTRIBUIDOR | Distribuidor |
| 5 | ENT_OTRO | Otro |

---

## 10. ESTRUCTURAS GLOBALES

### 10.1 gEmpresa (Empresa Activa)

```vb
Type Empresa_t
   Id As Long              ' ID en base de datos
   Rut As String           ' RUT de la empresa
   NombreCorto As String   ' Nombre corto
   RazonSocial As String   ' Razon social completa
   Direccion As String     ' Direccion
   Telefono As String      ' Telefono
   Ano As Integer          ' Ano fiscal activo
   FCierre As Long         ' Fecha de cierre (0=abierto)
   FApertura As Long       ' Fecha de apertura
   RutDisp As String       ' RUT para mostrar en reportes
   TipoContrib As Integer  ' Tipo de contribuyente
   Franq14Ter As Boolean   ' Franquicia 14 ter
   ' ... otros campos
End Type
```

### 10.2 gUsuario (Usuario Autenticado)

```vb
Type Usuario_t
   IdUsuario As Long       ' ID del usuario
   Nombre As String        ' Nombre de login
   NombreLargo As String   ' Nombre completo
   ClaveActual As String   ' Clave encriptada
   idPerfil As Long        ' ID del perfil asignado
   Priv As Long            ' Bitmap de privilegios
   PrivaAdm As Integer     ' Nivel de administrador
   Rc As Integer           ' Resultado del login
End Type
```

### 10.3 gCtasBas (Cuentas Basicas Definidas)

```vb
Type CtasBas_t
   IdCtaIVACred As Long    ' Cuenta IVA Credito
   IdCtaIVADeb As Long     ' Cuenta IVA Debito
   IdCtaPatrim As Long     ' Cuenta Patrimonio
   IdCtaResEje As Long     ' Cuenta Resultado Ejercicio
   IdCtaImpRet As Long     ' Cuenta Impuesto Retenido
   IdCtaNetoHon As Long    ' Cuenta Neto Honorarios
   ' ... otras cuentas basicas
End Type
```

### 10.4 Variables Globales de Configuracion

| Variable | Tipo | Descripcion |
|----------|------|-------------|
| DbMain | Database/Connection | Conexion principal a BD |
| gDbType | Integer | SQL_ACCESS o SQL_SERVER |
| gDbPath | String | Ruta a carpeta de datos |
| gAppCode | AppCode_t | Info de aplicacion (Demo, NivProd, etc.) |
| gMaxEmpLicencia | Integer | Maximo empresas por licencia |
| gEmprSeparadas | Boolean | BD separada por empresa |
| gAdmUser | String | Nombre del usuario admin ("administ") |
| gIniFile | String | Ruta al archivo INI |
| gLicFile | String | Ruta al archivo de licencia |

---

## APENDICE: LISTADO COMPLETO DE FORMULARIOS

### Modulo Administrador (29 formularios)

| Formulario | Proposito Principal |
|------------|-------------------|
| FrmMain | Menu principal administrador |
| FrmEmpresas | Lista de empresas |
| FrmMantEmpresa | Crear/editar empresa |
| FrmUsuarios | Lista de usuarios |
| FrmMantUsuario | Crear/editar usuario |
| FrmPerfiles | Lista de perfiles |
| FrmUsuarioPriv | Privilegios por empresa |
| FrmEmpHR | Capturar desde HyperRenta |
| FrmEmpArchivo | Capturar desde archivo |
| FrmEmpLpRemu | Capturar desde LPRemu |
| FrmSelEmpresasNivelEmpresa | Seleccionar empresas para traspaso |
| FrmSelEmpresasTras | Traspasar empresas |
| FrmResetEmprAno | Eliminar empresa-ano |
| FrmGenBackup | Generar respaldo |
| FrmRepAudCuentasDefinidas | Reporte auditoria cuentas |
| FrmReporteControlEmpresas | Reporte control empresas |
| FrmRepContEmpresas | Reporte empresas |
| FrmPrtEmpresas | Imprimir empresas |
| FrmOficina | Datos de oficina |
| FrmRazones | Razones financieras |
| FrmMonedas | Configuracion monedas |
| FrmEquivalencias | Equivalencias moneda |
| FrmIPC | Valores e indices |
| FrmDesbloquear | Desbloquear conexion |
| FrmIntegracionDatosSII | Importar datos SII |
| FrmCrearUsrFiscalizador | Crear fiscalizadores |
| FrmEquiposAut | Licenciamiento |
| FrmCambioClave | Cambiar clave |
| FrmAbout | Acerca de |

### Modulo HyperContabilidad (100+ formularios)

| Categoria | Formularios |
|-----------|-------------|
| **Navegacion** | FrmIdUser, FrmSelEmpresas, FrmMain, FrmStart |
| **Comprobantes** | FrmComprobante, FrmLstComp, FrmCambioEstadoComp |
| **Documentos** | FrmDoc, FrmDocLib, FrmDocCuotas, FrmCompraVenta, FrmLibRetenciones |
| **Plan Cuentas** | FrmPlanCuentas, FrmCuenta, FrmCuentaDef |
| **Entidades** | FrmEntidades, FrmEntidad |
| **Activo Fijo** | FrmActivoFijo, FrmAFFicha, FrmAFCompsFicha, FrmLstActFijo |
| **Balances** | FrmBalClasif, FrmBalComprobacion, FrmBalTributario, FrmBalEjecIFRS |
| **Libros** | FrmLibDiario, FrmLibMayor, FrmLibroCaja |
| **Configuracion** | FrmConfig, FrmConfigActFijo, FrmConfigCtasDef, FrmConfigInformes |
| **Utilidades** | FrmCalendar, FrmConverMoneda, FrmSumSimple, FrmPrintPreview |
| **Cierre** | FrmEstadoMeses, FrmCierreAnual, FrmApertura |
| **Informes** | FrmInfAnalitico, FrmCapitalPropio, FrmBaseImponible |

---

## 11. ORQUESTACION AUTOMATICA DEL SISTEMA

Esta seccion documenta todas las **redirecciones automaticas**, **validaciones obligatorias** y **flujos forzados** que el sistema ejecuta sin intervencion directa del usuario. Estos flujos son criticos porque **obligan** al usuario a completar ciertas acciones antes de continuar.

### 11.1 Tipos de Orquestacion Detectados

| Tipo | Descripcion | Patron en Codigo |
|------|-------------|------------------|
| **Flujo de Inicio** | Secuencia obligatoria al abrir la aplicacion | `Sub Main()` con `Show vbModal` secuenciales |
| **Validacion en Activate** | Verificaciones automaticas al activar formulario | `Form_Activate` con `If...Then...Show vbModal` |
| **Bucles Obligatorios** | Repeticion hasta completar accion correctamente | `Do While...Loop` con `Show vbModal` |
| **Bloqueos por Configuracion** | MsgBox + redireccion cuando falta configuracion | `MsgBox` + `Show vbModal` condicional |
| **Cierres Forzados** | Terminacion del programa por cancelacion | `If vbCancel Then End` |

### 11.2 Flujo de Inicio - Modulo HyperContabilidad

**Archivo:** `LpContMain.bas` - `Sub Main()` (linea 4)

```
Sub Main()
|
+-- PamInit(), PamRandomize()           ' Inicializacion base
+-- GenInstanceKey()                    ' Generar clave de instancia
+-- CheckInstance()                     ' Verificar instancia unica
|   +-- Si App.PrevInstance = True --> End (CIERRE)
|
+-- OpenDbAdm() / OpenMsSql()           ' Abrir base de datos
|   +-- Si False --> End (CIERRE)
|
+-- ReadOficina()                       ' Leer datos oficina
+-- CorrigeBaseAdm()                    ' Corregir estructura BD
+-- ContRegisterPc()                    ' Registrar licencia
|
+-- FrmStart.Show vbModeless            ' SPLASH SCREEN (no bloquea)
+-- Sleep 500
|
+-- ======================================
|   BLOQUEO #1: AUTENTICACION OBLIGATORIA
|   ======================================
+-- FrmIdUser.Show vbModal              ' LOGIN (linea 279)
|   |
|   +-- Si gUsuario.Rc = vbCancel:
|       +-- ContUnregisterPc(3)
|       +-- CloseDb(DbMain)
|       +-- End                         ' CIERRE DEL PROGRAMA
|
+-- IniHyperCont()                      ' Inicializar HyperContabilidad
+-- IniHyperContFca()                   ' Inicializar modulo financiero
|
+-- ======================================
|   BLOQUEO #2: SELECCION DE EMPRESA (BUCLE)
|   ======================================
+-- Do While BoolIniEmpresa = False     ' BUCLE OBLIGATORIO (linea 297)
|   |
|   +-- FrmSelEmpresas.FSelect()        ' Seleccion empresa/ano (linea 299)
|   |   |
|   |   +-- Si vbCancel:
|   |       +-- ContUnregisterPc(3)
|   |       +-- CloseDb(DbMain)
|   |       +-- End                     ' CIERRE DEL PROGRAMA
|   |
|   +-- BoolIniEmpresa = IniEmpresa()   ' Intentar inicializar
|       +-- Si False: REPITE EL BUCLE (vuelve a mostrar FrmSelEmpresas)
|       +-- Si True: SALE DEL BUCLE
|
+-- FrmMain.Show vbModeless             ' MENU PRINCIPAL (linea 333)
+-- Unload FrmStart                     ' Cerrar splash
|
+-- [Fin de Sub Main - Sistema operativo]
```

### 11.3 Validacion Automatica de Plan de Cuentas

**Archivo:** `FrmMain.frm` - `Form_Activate` (linea 1508)

**CRITICO:** Esta validacion se ejecuta **automaticamente** cada vez que FrmMain obtiene el foco. Si el plan de cuentas esta vacio, **OBLIGA** al usuario a configurarlo.

```
Private Sub Form_Activate()
|
+-- [Linea 1545-1546] Verificar modo demo
|   If ExitDemo() Then
|       Unload Me                       ' CIERRE DE FrmMain
|   End If
|
+-- [Linea 1553-1555] Evitar repeticion
|   If FrmActivate = True Then
|       Exit Sub                        ' Ya procesado, salir
|   End If
|
+-- [Linea 1570-1574] CONSULTA DE PLAN DE CUENTAS
|   Q1 = "SELECT IdCuenta FROM Cuentas"
|   Q1 = Q1 & " WHERE IdEmpresa = " & gEmpresa.Id & " AND Ano = " & gEmpresa.Ano
|   Set Rs = OpenRs(DbMain, Q1)
|   PlanVacio = (Rs.EOF = True)         ' True si NO hay cuentas
|   Call CloseRs(Rs)
|
+-- [Linea 1578-1603] ======================================
|                     BLOQUEO #3: CONFIGURACION OBLIGATORIA
|                     ======================================
|   If PlanVacio Then
|   |
|   +-- [Linea 1580-1592] Intenta obtener datos de HyperRenta
|   |   If GetDatosEmpHR(gEmpresa.Rut) Then
|   |       Set FrmEmp = New FrmEmpresa
|   |       Rc = FrmEmp.FEdit(gEmpresa.Id, True)  ' MODAL
|   |       Set FrmEmp = Nothing
|   |       If Rc = vbOK Then Call FillDatosEmp
|   |   End If
|   |
|   +-- [Linea 1595] MENSAJE OBLIGATORIO (bloquea hasta aceptar)
|   |   MsgBox1 "Se ha detectado que no esta definido el Plan de Cuentas
|   |           para esta empresa." & vbNewLine & vbNewLine &
|   |           "La ventana de Configuracion Inicial le permitira definir
|   |           el Plan de Cuentas y otros elementos basicos para trabajar
|   |           con el sistema.", vbInformation + vbOKOnly
|   |
|   +-- [Linea 1596-1598] REDIRECCION OBLIGATORIA A FrmConfig
|   |   Set Frm = New FrmConfig
|   |   Frm.Show vbModal                ' MODAL - No puede cerrar sin atender
|   |   Set Frm = Nothing
|   |
|   +-- [Linea 1600-1602] MENSAJE ADICIONAL
|       If Tipo_Plan <> "PERSONALIZADO" Then
|           MsgBox1 "Recuerde configurar las Razones Financieras para esta
|                   empresa, utilizando la opcion que provee el sistema,
|                   bajo el menu 'Configuracion'", vbOKOnly + vbInformation
|       End If
|   End If
```

### 11.4 Cambio de Empresa con Validacion

**Archivo:** `FrmMain.frm` - `M_SelEmp_Click` (linea 3525)

Cuando el usuario cambia de empresa desde el menu, se ejecuta la misma validacion de plan de cuentas:

```
Private Sub M_SelEmp_Click()
|
+-- BoolIniEmpresa = False
|
+-- ======================================
|   BLOQUEO #4: BUCLE DE SELECCION
|   ======================================
+-- Do While BoolIniEmpresa = False     ' BUCLE OBLIGATORIO (linea 3544)
|   |
|   +-- Set Frm = New FrmSelEmpresas
|   +-- Rc = Frm.FSelect                ' MODAL
|   +-- Set Frm = Nothing
|   |
|   +-- If Rc = vbOK Then
|   |   +-- BoolIniEmpresa = IniEmpresa()
|   |   +-- Si False: REPITE BUCLE
|   +-- Else
|       +-- BoolIniEmpresa = True       ' Salir sin cambiar
|   End If
+-- Loop
|
+-- [Linea 3586-3615] Si Rc = vbOK (cambio exitoso):
    |
    +-- Verificar PlanVacio (misma logica que Form_Activate)
    |
    +-- ======================================
    |   BLOQUEO #5: CONFIGURACION SI PLAN VACIO
    |   ======================================
    +-- If PlanVacio Then
        +-- [Intenta cargar datos HR]
        +-- MsgBox "Se ha detectado que no esta definido el Plan..."
        +-- FrmConfig.Show vbModal      ' OBLIGATORIO
        +-- MsgBox "Recuerde configurar las Razones Financieras..."
    End If
```

### 11.5 Variables de Control de Flujo

Estas variables globales controlan la orquestacion del sistema:

| Variable | Tipo | Valores | Uso |
|----------|------|---------|-----|
| `gUsuario.Rc` | Integer | vbOK (0), vbCancel (-1) | Resultado de autenticacion |
| `BoolIniEmpresa` | Boolean | True/False | Empresa inicializada correctamente |
| `PlanVacio` | Boolean | True/False | Plan de cuentas vacio (dispara FrmConfig) |
| `FrmActivate` | Boolean | True/False | Evita repetir validaciones en Form_Activate |
| `gEmpresa.Id` | Long | ID empresa | Empresa actualmente seleccionada |
| `gEmpresa.Ano` | Integer | Ano | Ano contable activo |

### 11.6 Puntos de Cierre Forzado

El sistema tiene puntos donde **cierra la aplicacion** si el usuario cancela:

| Ubicacion | Archivo | Linea | Condicion | Accion |
|-----------|---------|-------|-----------|--------|
| Login cancelado | LpContMain.bas | 282-286 | gUsuario.Rc = vbCancel | End |
| Seleccion empresa cancelada | LpContMain.bas | 299-302 | FSelect = vbCancel | End |
| Demo expirado | FrmMain.frm | 1545-1546 | ExitDemo() = True | Unload Me |
| Login Administrador cancelado | Administrador.bas | 264-267 | FShow = vbCancel | End |

### 11.7 Diagrama de Orquestacion Completa

```
[INICIO APLICACION]
        |
        v
+---------------+
|  FrmStart     | (splash - modeless, no bloquea)
+---------------+
        |
        v
+---------------+     vbCancel
|  FrmIdUser    |-------------------> [END - Cierra App]
|  (vbModal)    |
|  BLOQUEO #1   |
+---------------+
        | vbOK
        v
+----------------------------------+
| BUCLE: Do While IniEmpresa=False |<-----------+
|            BLOQUEO #2            |            |
+----------------------------------+            |
        |                                       |
        v                                       |
+-------------------+   vbCancel               |
| FrmSelEmpresas    |------------> [END]       |
| (vbModal)         |                          |
+-------------------+                          |
        | vbOK                                  |
        v                                       |
+-------------------+                          |
| IniEmpresa()      |-------- False -----------+
+-------------------+
        | True
        v
+---------------+
|  FrmMain      | (modeless - menu principal)
+---------------+
        |
        v (Form_Activate)
+-------------------+
| Validar PlanVacio |
+-------------------+
        | PlanVacio = True
        v
+-------------------+
| MsgBox            | "No esta definido el Plan de Cuentas..."
| (bloquea)         |
+-------------------+
        |
        v
+-------------------+
| FrmConfig         | (vbModal - OBLIGATORIO)
| BLOQUEO #3        |
| Configurar Plan   |
+-------------------+
        |
        v
+-------------------+
| MsgBox            | "Recuerde configurar Razones Financieras..."
+-------------------+
        |
        v
[SISTEMA OPERATIVO NORMALMENTE]
        |
        v (Usuario hace click en Menu > Cambiar Empresa)
+----------------------------------+
| M_SelEmp_Click                   |
| BUCLE: Do While IniEmpresa=False |<-----------+
|            BLOQUEO #4            |            |
+----------------------------------+            |
        |                                       |
        v                                       |
+-------------------+                          |
| FrmSelEmpresas    |                          |
| (vbModal)         |                          |
+-------------------+                          |
        | vbOK                                  |
        v                                       |
+-------------------+                          |
| IniEmpresa()      |-------- False -----------+
+-------------------+
        | True
        v
+-------------------+
| Validar PlanVacio |
+-------------------+
        | PlanVacio = True
        v
+-------------------+
| FrmConfig         | (vbModal - BLOQUEO #5)
+-------------------+
```

### 11.8 Tabla Resumen de Redirecciones Automaticas

| # | Evento/Funcion | Archivo | Linea | Formulario Destino | Modal | Condicion | Accion si Cancela |
|---|----------------|---------|-------|-------------------|-------|-----------|-------------------|
| 1 | Sub Main | LpContMain.bas | 279 | FrmIdUser | SI | Autenticacion | End (cierra app) |
| 2 | Sub Main Loop | LpContMain.bas | 297-320 | FrmSelEmpresas | SI | Seleccion empresa | End (cierra app) |
| 3 | Form_Activate | FrmMain.frm | 1545 | - | - | ExitDemo()=True | Unload Me |
| 4 | Form_Activate | FrmMain.frm | 1578-1603 | FrmEmpresa + FrmConfig | SI | PlanVacio=True | MsgBox obligatorio |
| 5 | M_SelEmp_Click | FrmMain.frm | 3544-3579 | FrmSelEmpresas | SI | Cambio empresa | Mantiene empresa actual |
| 6 | M_SelEmp_Click | FrmMain.frm | 3592-3615 | FrmConfig | SI | PlanVacio=True | MsgBox obligatorio |
| 7 | Sub Main (Adm) | Administrador.bas | 264-267 | FrmidUsuario | SI | Autenticacion | End (cierra app) |

---

## 12. FLUJO DE CONFIGURACION POST-CREACION DE EMPRESA

Esta seccion documenta el **proceso completo** que debe seguir un usuario despues de crear una empresa, combinando los pasos **obligatorios del sistema** con los pasos **requeridos por el negocio**.

### 12.1 Pasos Obligatorios (Forzados por el Sistema)

Estos pasos son **obligatorios** porque el sistema los fuerza mediante redirecciones automaticas:

| Paso | Modulo | Formulario | Obligatorio Por |
|------|--------|------------|-----------------|
| 1. Asignar usuario a empresa | Administrador | FrmUsuarioPriv | Sin esto, usuario no puede ver la empresa en FrmSelEmpresas |
| 2. Seleccionar empresa/ano | Contabilidad | FrmSelEmpresas | Bucle en Sub Main (linea 297) |
| 3. Configurar plan de cuentas | Contabilidad | FrmConfig | Validacion en Form_Activate (linea 1578) |

### 12.2 Pasos Requeridos por el Negocio (No Forzados)

Estos pasos son **necesarios** para operar pero el sistema **no los fuerza**:

| Paso | Formulario | Por que es necesario |
|------|------------|---------------------|
| 4. Definir cuentas basicas | FrmConfigCtasDef | Sin esto, no se pueden generar comprobantes de apertura |
| 5. Configurar comprobantes | FrmConfigCorrComp | Sin esto, no hay numeracion de comprobantes |
| 6. Ingresar saldos apertura | FrmSaldoApertura | Requerido si empresa tiene saldos previos |
| 7. Generar comp. apertura | FrmApertura | Requerido para iniciar contabilidad |

### 12.3 Flujo Detallado Paso a Paso

#### FASE 1: MODULO ADMINISTRADOR

**Paso 1: Crear Empresa** (Ya documentado en seccion 4)
- FrmEmpresas → Bt_New_Click → FrmMantEmpresa.FNew()
- INSERT INTO SisEmpresa

**Paso 2: Asignar Usuario a Empresa**
```
Donde ir: Menu Mantenimiento → Usuarios/Privilegios
Formulario: FrmUsuarioPriv
Que hacer:
  1. Seleccionar usuario en combo Cb_Usuario
  2. En la grilla, hacer doble clic en celda empresa/perfil
  3. Se marca con "X" el permiso
Tabla modificada: UsuarioEmpresa (INSERT)
```

#### FASE 2: MODULO CONTABILIDAD

**Paso 3: Seleccionar Empresa y Crear Ano** (OBLIGATORIO - Sistema lo fuerza)
```
Donde: Al abrir LPContabilidad.exe
Formulario: FrmSelEmpresas (aparece automaticamente por bucle en Sub Main)
Que sucede:
  1. Usuario selecciona empresa en combo
  2. Usuario ingresa ano (ej: 2024)
  3. Click "Seleccionar"
  4. Sistema ejecuta CrearNuevoAno() si el ano no existe
Tabla modificada: EmpresasAno (INSERT si es ano nuevo)
```

**Paso 4: Configurar Plan de Cuentas** (OBLIGATORIO - Sistema lo fuerza)
```
Donde: Se abre AUTOMATICAMENTE si PlanVacio=True (Form_Activate linea 1596)
Formulario: FrmConfig
Mensaje previo: "Se ha detectado que no esta definido el Plan de Cuentas..."

Opciones disponibles:
  - Boton "Plan Basico": Carga plan predefinido minimo
  - Boton "Plan Intermedio": Carga plan con mas detalle
  - Boton "Plan Avanzado": Carga plan completo
  - Boton "Plan IFRS": Carga plan para normas internacionales
  - Boton "Copiar de Otra Empresa": Abre FrmCopyPlan
  - Boton "Importar desde Archivo": Importa plan exportado

Tablas modificadas:
  - Cuentas (INSERT de todas las cuentas del plan)
  - CuentasBasicas (INSERT de cuentas especiales)
  - ParamEmpresa (INSERT tipo='PLAN', valor='BASICO'|'INTERMEDIO'|etc)
```

**Paso 5: Definir Cuentas Basicas** (Requerido por negocio)
```
Donde ir: FrmConfig → Boton "Definir Cuentas Basicas"
Formulario: FrmConfigCtasDef
Que configurar:
  - Cuenta Resultado/Patrimonio (para comprobante apertura)
  - Cuenta Credito IVA (para arrastre entre anos)
  - Otras cuentas especiales segun fiscal
Tabla modificada: ParamEmpresa (INSERT tipo='CTARESULT', 'CTACREDIVA', etc)
```

**Paso 6: Configurar Comprobantes** (Requerido por negocio)
```
Donde ir: FrmConfig → Boton "Configurar Comprobantes"
Formulario: FrmConfigCorrComp
Que configurar:
  - Tipos de comprobantes (Boleta, Factura, NC, ND, etc.)
  - Numeracion: correlativo unico o por tipo
  - Numero inicial
Tabla modificada: CT_Comprobante (INSERT tipos de comprobantes)
```

**Paso 7: Ingresar Saldos de Apertura** (Segun caso)
```
Donde ir: FrmConfig → Boton "Saldos de Apertura"
Formulario: FrmSaldoApertura
Cuando es necesario:
  - Empresa nueva que inicia contabilidad con saldos previos
  - Empresa que migra de otro sistema
Que hacer:
  - Ingresar saldos iniciales por cuenta (Debito/Credito)
  - Verificar que cuadren (Total Debitos = Total Creditos)
Tabla modificada: DetSaldosAp (INSERT por cada cuenta con saldo)
```

**Paso 8: Generar Comprobante de Apertura** (Requerido para operar)
```
Donde ir: FrmConfig → Boton "Generar Comprobante de Apertura"
Formulario: FrmApertura
Que ingresar:
  1. Numero de comprobante (ej: 1)
  2. Cuenta de patrimonio/resultado (seleccionar del plan)
  3. Cuenta de credito IVA (seleccionar del plan)
  4. Remanente IVA ano anterior (UTM) si aplica
Que genera:
  - Comprobante tipo APERTURA (cerrado automaticamente)
  - Movimientos: Debito en Activos = Credito en Pasivos/Patrimonio
Tablas modificadas:
  - Comprobante (INSERT tipo=TC_APERTURA)
  - MovComprobante (INSERT movimientos)
  - EmpresasAno (UPDATE IdCompAper, NCompAper)
  - ParamEmpresa (UPDATE parametros de apertura)
```

### 12.4 Diagrama del Flujo Completo

```
+=====================================================+
|              MODULO ADMINISTRADOR                   |
+=====================================================+
|                                                     |
| [1] CREAR EMPRESA                                   |
|     FrmEmpresas → FrmMantEmpresa.FNew()            |
|     INSERT INTO SisEmpresa                         |
|                      |                              |
|                      v                              |
| [2] ASIGNAR USUARIOS                                |
|     FrmUsuarioPriv (matriz usuario-empresa-perfil) |
|     INSERT INTO UsuarioEmpresa                     |
|                                                     |
+=====================================================+
                       |
                       v
+=====================================================+
|              MODULO CONTABILIDAD                    |
+=====================================================+
|                                                     |
| [3] SELECCIONAR EMPRESA Y ANO                       |
|     FrmSelEmpresas (AUTOMATICO - bucle Sub Main)   |
|     INSERT INTO EmpresasAno (si ano nuevo)         |
|                      |                              |
|                      v                              |
| [4] CONFIGURAR PLAN DE CUENTAS                      |
|     FrmConfig (AUTOMATICO - Form_Activate)         |
|     "Se ha detectado que no esta definido..."      |
|     INSERT INTO Cuentas, CuentasBasicas            |
|                      |                              |
|                      v                              |
| [5] DEFINIR CUENTAS BASICAS (Manual)               |
|     FrmConfigCtasDef                               |
|     INSERT INTO ParamEmpresa                       |
|                      |                              |
|                      v                              |
| [6] CONFIGURAR COMPROBANTES (Manual)               |
|     FrmConfigCorrComp                              |
|     INSERT INTO CT_Comprobante                     |
|                      |                              |
|                      v                              |
| [7] INGRESAR SALDOS APERTURA (Si aplica)           |
|     FrmSaldoApertura                               |
|     INSERT INTO DetSaldosAp                        |
|                      |                              |
|                      v                              |
| [8] GENERAR COMPROBANTE APERTURA (Manual)          |
|     FrmApertura                                    |
|     INSERT INTO Comprobante, MovComprobante        |
|                                                     |
+=====================================================+
                       |
                       v
           +---------------------+
           | EMPRESA LISTA PARA  |
           | OPERAR              |
           | - Comprobantes      |
           | - Documentos        |
           | - Informes          |
           +---------------------+
```

### 12.5 Resumen de Obligatoriedad

| Paso | Descripcion | Obligatorio Sistema | Obligatorio Negocio |
|------|-------------|---------------------|---------------------|
| 1 | Crear empresa | - | SI |
| 2 | Asignar usuarios | NO (pero sin esto no ve empresa) | SI |
| 3 | Seleccionar empresa/ano | SI (bucle Sub Main) | SI |
| 4 | Configurar plan cuentas | SI (Form_Activate) | SI |
| 5 | Definir cuentas basicas | NO | SI (para apertura) |
| 6 | Configurar comprobantes | NO | SI (para numerar) |
| 7 | Ingresar saldos apertura | NO | Segun caso |
| 8 | Generar comp. apertura | NO | SI (para operar) |

---

## 13. CATALOGO DE FORMULARIOS

### Modulo Administrador (29 formularios)

| Formulario | Proposito Principal |
|------------|-------------------|
| FrmMain | Menu principal administrador |
| FrmEmpresas | Lista de empresas |
| FrmMantEmpresa | Crear/editar empresa |
| FrmUsuarios | Lista de usuarios |
| FrmMantUsuario | Crear/editar usuario |
| FrmPerfiles | Lista de perfiles |
| FrmUsuarioPriv | Privilegios por empresa |
| FrmEmpHR | Capturar desde HyperRenta |
| FrmEmpArchivo | Capturar desde archivo |
| FrmEmpLpRemu | Capturar desde LPRemu |
| FrmSelEmpresasNivelEmpresa | Seleccionar empresas para traspaso |
| FrmSelEmpresasTras | Traspasar empresas |
| FrmResetEmprAno | Eliminar empresa-ano |
| FrmGenBackup | Generar respaldo |
| FrmRepAudCuentasDefinidas | Reporte auditoria cuentas |
| FrmReporteControlEmpresas | Reporte control empresas |
| FrmRepContEmpresas | Reporte empresas |
| FrmPrtEmpresas | Imprimir empresas |
| FrmOficina | Datos de oficina |
| FrmRazones | Razones financieras |
| FrmMonedas | Configuracion monedas |
| FrmEquivalencias | Equivalencias moneda |
| FrmIPC | Valores e indices |
| FrmDesbloquear | Desbloquear conexion |
| FrmIntegracionDatosSII | Importar datos SII |
| FrmCrearUsrFiscalizador | Crear fiscalizadores |
| FrmEquiposAut | Licenciamiento |
| FrmCambioClave | Cambiar clave |
| FrmAbout | Acerca de |

### Modulo HyperContabilidad (100+ formularios)

| Categoria | Formularios |
|-----------|-------------|
| **Navegacion** | FrmIdUser, FrmSelEmpresas, FrmMain, FrmStart |
| **Comprobantes** | FrmComprobante, FrmLstComp, FrmCambioEstadoComp |
| **Documentos** | FrmDoc, FrmDocLib, FrmDocCuotas, FrmCompraVenta, FrmLibRetenciones |
| **Plan Cuentas** | FrmPlanCuentas, FrmCuenta, FrmCuentaDef |
| **Entidades** | FrmEntidades, FrmEntidad |
| **Activo Fijo** | FrmActivoFijo, FrmAFFicha, FrmAFCompsFicha, FrmLstActFijo |
| **Balances** | FrmBalClasif, FrmBalComprobacion, FrmBalTributario, FrmBalEjecIFRS |
| **Libros** | FrmLibDiario, FrmLibMayor, FrmLibroCaja |
| **Configuracion** | FrmConfig, FrmConfigActFijo, FrmConfigCtasDef, FrmConfigInformes |
| **Utilidades** | FrmCalendar, FrmConverMoneda, FrmSumSimple, FrmPrintPreview |
| **Cierre** | FrmEstadoMeses, FrmCierreAnual, FrmApertura |
| **Informes** | FrmInfAnalitico, FrmCapitalPropio, FrmBaseImponible |

---

## 14. SISTEMA DE PRIVILEGIOS (PRV_*)

El sistema implementa control de acceso granular mediante privilegios bitwise que deshabilitan funcionalidades segun el perfil del usuario.

### 14.1 Definicion de Privilegios

**Archivo:** `HyperComun.bas` lineas 861-874

| Constante | Valor Hex | Valor Dec | Descripcion |
|-----------|-----------|-----------|-------------|
| `PRV_ADM_SIS` | &H1 | 1 | Administrar Sistema |
| `PRV_CFG_EMP` | &H2 | 2 | Configurar empresa (Config, comp tipo) |
| `PRV_ADM_EMPRESA` | &H4 | 4 | Administrar periodos contables (crear, abrir, cerrar) |
| `PRV_ADM_CTAS` | &H8 | 8 | Administrar Plan Cuentas y def. cuentas basicas |
| `PRV_ING_COMP` | &H10 | 16 | Ingresar Comprobantes |
| `PRV_ADM_COMP` | &H20 | 32 | Administrar Comprobantes (anular, eliminar) |
| `PRV_ING_DOCS` | &H40 | 64 | Ingresar Documentos |
| `PRV_ADM_DOCS` | &H80 | 128 | Administrar Docs (centralizar, pago automatico) |
| `PRV_ADM_DEF` | &H100 | 256 | Administrar Entidades, Areas de Negocio |
| `PRV_VER_INFO` | &H200 | 512 | Ver informes, reportes y libros |
| `PRV_IMP_LIBOF` | &H400 | 1024 | Imprimir Libros Oficiales |
| `PRV_ADM_TIMB` | &H800 | 2048 | Administrar folios timbraje |
| `PRV_ADM_CONCIL` | &H1000 | 4096 | Realizar conciliacion bancaria |
| `PRV_ADM_ACTFIJOS` | &H2000 | 8192 | Administrar Activos Fijos |
| `PRV_ADMIN` | &H1FFFFF | 131071 | Todos los privilegios (Administrador) |

### 14.2 Funcion de Verificacion

```vb
' HyperComun.bas linea 1039
Public Function ChkPriv(Priv As Long) As Boolean
   ChkPriv = ((Priv And gUsuario.Priv) <> 0)
End Function
```

### 14.3 Carga de Privilegios

**Flujo de carga:**
```
[Login FrmIdUser]
    |
    v
Si es Administrador:
    gUsuario.Priv = PRV_ADMIN (todos)
    |
    v
[Seleccion Empresa FrmSelEmpresas]
    |
    v
SELECT Perfiles.Privilegios FROM Perfiles
INNER JOIN UsuarioEmpresa ON idPerfil
WHERE IdUsuario = X AND IdEmpresa = Y
    |
    v
gUsuario.Priv = Privilegios del perfil
```

### 14.4 Efectos por Privilegio

#### PRV_ING_COMP (Sin privilegio para Ingresar Comprobantes)
```
FrmMain:
├── M_NewComprob.Enabled = False
├── M_ImpComprobantes.Enabled = False
└── Usuario NO puede crear comprobantes
```

#### PRV_ADM_COMP (Sin privilegio para Administrar Comprobantes)
```
FrmMain:
├── M_Renum.Enabled = False (Renumeracion)
├── M_Auditoria.Enabled = False
└── Usuario NO puede anular/eliminar comprobantes
```

#### PRV_CFG_EMP (Sin privilegio para Configurar Empresa)
```
FrmMain:
├── M_Config.Enabled = False
├── M_ConfigCtasFUT.Enabled = False
├── M_TipoDocs.Enabled = False
└── Todos los menus de configuracion deshabilitados

FrmConfig:
├── Bt_PlanPreDef(1,2,3).Enabled = False
├── Bt_CopyPlanEmp.Enabled = False
├── Bt_ImportPlan.Enabled = False
└── Solo puede VER configuracion, no modificar
```

#### PRV_VER_INFO (Sin privilegio para Ver Informes)
```
FrmMain:
├── M_Libros.Enabled = False
├── M_Balances.Enabled = False
├── M_InfoAnalit.Enabled = False
├── M_EstadoRes.Enabled = False
├── Bt_Libros.Enabled = False
├── Bt_Balances.Enabled = False
└── NO puede ver ningun informe ni reporte
```

#### PRV_IMP_LIBOF (Sin privilegio para Imprimir Libros Oficiales)
```
Multiples formularios de reportes:
├── Ch_LibOficial = 0
├── Ch_LibOficial.Enabled = False
└── Opcion de impresion oficial deshabilitada
```

### 14.5 Formularios con SetupPriv()

54 formularios implementan verificacion de privilegios mediante `SetupPriv()`:

| Categoria | Formularios |
|-----------|-------------|
| **Principal** | FrmMain, FrmMainSQLServer |
| **Comprobantes** | FrmComprobante, FrmLstComp, FrmLstCompTipo, FrmRenum |
| **Documentos** | FrmDoc, FrmDocCuotas, FrmDocLib, FrmLstDoc |
| **Plan Cuentas** | FrmPlanCuentas, FrmCuenta, FrmNiveles, FrmCopyPlan |
| **Configuracion** | FrmConfig, FrmConfigActFijo, FrmConfigCtasDef, FrmConfigCorrComp |
| **Balances** | FrmBalClasif, FrmBalComprobacion, FrmBalTributario |
| **Libros** | FrmLibDiario, FrmLibMayor, FrmLibInvBal |
| **Entidades** | FrmEntidad, FrmEntidades, FrmSucursal |
| **Activo Fijo** | FrmActivoFijo, FrmLstActFijo, FrmAFFicha |
| **Otros** | FrmConciliacion, FrmFoliacion, FrmSaldoApertura |

### 14.6 Matriz de Impacto por Modulo

| Modulo | PRV_ING_COMP | PRV_ADM_COMP | PRV_ING_DOCS | PRV_CFG_EMP | PRV_VER_INFO |
|--------|--------------|--------------|--------------|-------------|--------------|
| Comprobantes | Crear | Anular/Eliminar | - | - | - |
| Documentos | - | - | Crear | - | - |
| Configuracion | - | - | - | Todo | - |
| Informes | - | - | - | - | Ver |
| Plan Cuentas | - | - | - | Solo ver | - |

---

## 15. SISTEMA DE ESTADO DE MESES (EM_*)

El sistema controla apertura/cierre de meses contables, bloqueando operaciones en meses cerrados.

### 15.1 Estados Posibles

**Archivo:** `HyperCont.bas` lineas 81-85

| Constante | Valor | Descripcion |
|-----------|-------|-------------|
| `EM_NOEXISTE` | 0 | Mes no existe en base de datos |
| `EM_ABIERTO` | 1 | Mes abierto - permite operaciones |
| `EM_CERRADO` | 2 | Mes cerrado - bloquea operaciones |
| `EM_ERRONEO` | 3 | Mes no esta cuadrado |

### 15.2 Funciones de Control

#### GetEstadoMes(Mes)
```vb
' HyperCont.bas linea 3950
SELECT Estado FROM EstadoMes
WHERE Mes = X AND IdEmpresa = Y AND Ano = Z
Retorna: EM_ABIERTO, EM_CERRADO, EM_ERRONEO o EM_NOEXISTE
```

#### GetMesActual()
```vb
' HyperCont.bas linea 4163
SELECT Max(Mes) FROM EstadoMes WHERE Estado = EM_ABIERTO
Retorna: 1-12 (mes abierto) o 0 (ningun mes abierto)
```

### 15.3 Formulario de Control: FrmEstadoMeses

**Acceso:** Menu Archivo → Estado de Meses
**Privilegio requerido:** PRV_ADM_EMPRESA

**Funcionalidades:**
- Ver estado de 12 meses en grid
- Boton "Abrir Mes" → AbrirMes(Mes)
- Boton "Cerrar Mes" → CerrarMes(Mes)

### 15.4 Validaciones al Cerrar Mes

```
ValidaCierreMes(Mes)
    |
    +-- 1. ¿Estado = EM_ABIERTO?
    |      NO → Error "Este mes no esta abierto"
    |
    +-- 2. ¿Libros oficiales impresos?
    |      NO → Pregunta "¿Desea continuar?"
    |
    +-- 3. ¿Comprobantes pendientes?
    |      SI → Pregunta "Tiene comprobantes pendientes. ¿Continuar?"
    |
    +-- 4. ¿Documentos sin centralizar?
    |      SI → Pregunta "Tiene documentos sin centralizar. ¿Continuar?"
    |
    +-- 5. ¿Debe = Haber? (Mes cuadrado)
    |      NO → Error BLOQUEANTE "No esta cuadrado. No es posible cerrar."
    |           + Marca comprobantes desbalanceados como EC_ERRONEO
    |
    +-- Todo OK → UPDATE EstadoMes SET Estado = EM_CERRADO
```

### 15.5 Efecto en Formularios

#### FrmComprobante (linea 2488)
```vb
FrmEnable = (gEmpresa.FCierre = 0) And
            ((lOper = O_NEW And MesActual > 0) Or
             (lOper = O_EDIT And GetEstadoMes(month(Fecha)) = EM_ABIERTO))
```

**Condiciones para habilitar:**
- Ano NO cerrado (FCierre = 0)
- Para NUEVO: Debe haber mes abierto (MesActual > 0)
- Para EDITAR: Mes de la fecha debe estar ABIERTO

#### Mensaje de Error Tipico
```
"El mes correspondiente a la fecha del comprobante no esta abierto."
```

### 15.6 Restriccion de Paralelismo

```vb
' Variable global
Global gAbrirMesesParalelo As Boolean  ' Default: False

' Si False: Solo 1 mes puede estar abierto simultaneamente
' Si True: Permite multiples meses abiertos
```

---

## 16. SISTEMA DE CIERRE ANUAL (gEmpresa.FCierre)

El cierre anual bloquea TODAS las operaciones de edicion para el ano fiscal.

### 16.1 Variable de Control

```vb
gEmpresa.FCierre
├── = 0          → Ano ABIERTO (permite operaciones)
└── <> 0 (fecha) → Ano CERRADO (solo lectura)
```

**Almacenamiento:** Tabla `EmpresasAno`, campo `FCierre` (tipo Long - fecha serial)

### 16.2 Formulario de Cierre: FrmCierreAnual

**Acceso:** Menu Archivo → Cerrar Periodo
**Privilegio requerido:** PRV_ADM_EMPRESA

### 16.3 Proceso de Cierre Anual

```
Bt_CerrarAno_Click()
    |
    +-- 1. Validar libros oficiales impresos
    |      LibAnualesImpresos(True)
    |      - Libro Diario (12 meses)
    |      - Libro Mayor (12 meses)
    |      - Libro Compras (12 meses)
    |      - Libro Ventas (12 meses)
    |      - Libro Retenciones (12 meses)
    |      - Inventario y Balance
    |      - Libro Tributario
    |      - Libro Clasificado
    |
    +-- 2. Advertencia al usuario
    |      "Recuerde que al hacer cierre anual no podra
    |       volver a modificar datos de este ano. ¿Continuar?"
    |
    +-- 3. Cerrar todos los meses abiertos
    |      For cada mes con Estado = EM_ABIERTO
    |          CerrarMes(Mes)
    |
    +-- 4. Calcular remanente IVA para ano siguiente
    |      RemIVAUTM = calculo acumulado 12 meses
    |
    +-- 5. Calcular saldo libro de caja
    |      SaldoLibroCaja = Ingresos - Egresos
    |
    +-- 6. UPDATE EmpresasAno
    |      SET FCierre = Now(), RemIVAUTM = X, SaldoLibroCaja = Y
    |
    +-- 7. gEmpresa.FCierre = fecha actual
    |
    +-- 8. Registrar auditoria
           SeguimientoCierreApertura(2, "Cierre Anual")
```

### 16.4 Formularios Bloqueados por Cierre Anual

Cuando `gEmpresa.FCierre <> 0`:

| Formulario | Efecto |
|------------|--------|
| FrmCierreAnual | EnableForm(Me, False) |
| FrmActivoFijo | EnableForm(Me, False) |
| FrmPlanCuentas | EnableForm(Me, False) |
| FrmEstadoMeses | EnableForm(Me, False) |
| FrmSaldoApertura | EnableForm(Me, False) |
| FrmConfigCtasDef | EnableForm(Me, False) |
| FrmCentrosCosto | EnableForm(Me, False) |
| FrmEntidades | EnableForm(Me, False) |
| FrmConciliacion | EnableForm(Me, False) |
| +20 formularios mas | Completamente deshabilitados |

### 16.5 Menus Deshabilitados

```
FrmMain cuando FCierre <> 0:
├── M_NewComp → Mensaje "Este periodo esta cerrado"
├── M_EditComprob → Bloqueado
├── M_NewDoc → Mensaje "Este periodo esta cerrado"
├── M_EditDoc → Bloqueado
├── M_LibCompSII → Bloqueado
└── M_LibRetenSII → Bloqueado
```

### 16.6 Reapertura de Ano

**Es posible reabrir un ano cerrado:**

```vb
' FrmMain → M_ReabrirPer_Click
UPDATE EmpresasAno SET FCierre = 0
WHERE idEmpresa = X AND Ano = Y

gEmpresa.FCierre = 0
```

**Efectos de reapertura:**
- Recupera todas las funcionalidades de edicion
- Registra auditoria: SeguimientoCierreApertura(1, "Reabrir")

### 16.7 Relacion con Apertura del Siguiente Ano

```
Para abrir ano N+1:
├── Ano N DEBE estar cerrado (FCierre <> 0)
├── Si FCierre = 0 → Error "El ano anterior aun no ha sido cerrado"
└── RemIVAUTM se traslada automaticamente al ano siguiente
```

---

## 17. INTERRUPCION POR MSGBOX CON DECISIONES

El sistema usa MsgBox con vbYesNo para interrumpir flujos y requerir decision del usuario.

### 17.1 Patrones Principales

#### Confirmacion de Eliminacion
```vb
If MsgBox1("¿Esta seguro que desea eliminar?", vbYesNo) = vbNo Then
   Exit Sub
End If
```

#### Advertencia con Continuacion Opcional
```vb
If MsgBox1("Hay comprobantes pendientes. ¿Desea continuar?",
           vbYesNo + vbDefaultButton2) = vbNo Then
   Exit Sub
End If
```

#### Confirmacion de Operacion Critica
```vb
Msg = "Recuerde que al hacer cierre anual no podra volver a modificar..."
If MsgBox1(Msg, vbYesNo + vbDefaultButton2) <> vbYes Then
   Exit Sub
End If
```

### 17.2 Ubicaciones Criticas

| Operacion | Mensaje | Archivo:Linea |
|-----------|---------|---------------|
| Cierre anual | "No podra volver a modificar datos" | FrmCierreAnual:127 |
| Eliminar cuenta | "¿Esta seguro que desea eliminar?" | FrmPlanCuentas:748 |
| Abrir mes impreso | "Ya fue impreso. ¿Desea abrirlo?" | HyperCont:3814 |
| Cerrar con pendientes | "Tiene comprobantes pendientes. ¿Continuar?" | HyperCont:3876 |
| Cerrar sin centralizar | "Documentos sin centralizar. ¿Continuar?" | HyperCont:3891 |
| Desbloquear conexion | "¿Desea desbloquear?" | FrmUnlock:99 |
| Exportar F29 | "Advertencia antes de exportar" | FrmExpF29:119 |

### 17.3 Efecto en el Flujo

```
Usuario ejecuta accion
    |
    v
Sistema muestra MsgBox vbYesNo
    |
    +-- SI (vbYes) → Continua con la operacion
    |
    +-- NO (vbNo) → Exit Sub (cancela operacion)
                    Retorna al formulario sin cambios
```

---

## 18. RESUMEN DE MECANISMOS DE ORQUESTACION

| # | Mecanismo | Tipo | Alcance | Reversible |
|---|-----------|------|---------|------------|
| 1 | Flujo de inicio (Sub Main) | Redireccion obligatoria | Login → Seleccion | N/A |
| 2 | PlanVacio (Form_Activate) | Redireccion automatica | Empresa nueva | N/A |
| 3 | Privilegios (PRV_*) | Control de acceso | Por usuario/perfil | Si (cambiar perfil) |
| 4 | Estado de meses (EM_*) | Control temporal | Por mes | Si (reabrir mes) |
| 5 | Cierre anual (FCierre) | Bloqueo total | Por ano | Si (reabrir ano) |
| 6 | MsgBox decisiones | Interrupcion | Por operacion | N/A |

### Diagrama de Interaccion de Mecanismos

```
[Usuario intenta operacion]
         |
         v
    +---------+
    | Login   |←── Si no autenticado → FrmIdUser
    +---------+
         |
         v
    +-----------+
    | Empresa   |←── Si no seleccionada → FrmSelEmpresas
    +-----------+
         |
         v
    +-----------+
    | PlanVacio |←── Si plan vacio → FrmConfig (obligatorio)
    +-----------+
         |
         v
    +-------------+
    | Privilegios |←── ChkPriv(PRV_XXX) → Deshabilita si no tiene
    +-------------+
         |
         v
    +---------------+
    | FCierre (Ano) |←── Si <> 0 → Bloquea formulario completo
    +---------------+
         |
         v
    +---------------+
    | EstadoMes     |←── Si <> EM_ABIERTO → Bloquea operacion
    +---------------+
         |
         v
    +---------------+
    | MsgBox YesNo  |←── Si vbNo → Cancela operacion
    +---------------+
         |
         v
    [Operacion ejecutada]
```

---

*Documento generado: Diciembre 2024*
*Sistema: TR Contabilidad VB6*
*Version: Mapeo Exhaustivo de Navegacion v5.0*
*Total de relaciones mapeadas: 500+*
*Incluye: Orquestacion automatica, flujos obligatorios, privilegios, estados de meses, cierre anual*
