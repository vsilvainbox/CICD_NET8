﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Equipos
{
    public string PC { get; set; } = null!;

    public string MAC { get; set; } = null!;

    public string CodPC { get; set; } = null!;

    public bool? Aut { get; set; }
}
