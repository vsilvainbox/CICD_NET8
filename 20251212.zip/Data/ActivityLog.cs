using System;

namespace App.Data;

/// <summary>
/// Modelo para registro de actividad de usuarios en el sistema
/// Captura todas las peticiones HTTP para auditoría
/// </summary>
public partial class ActivityLog
{
    public int IdActivity { get; set; }

    public DateTime Timestamp { get; set; }

    public int? UsuarioId { get; set; }

    public string? UserName { get; set; }

    public int? EmpresaId { get; set; }

    public string? IpAddress { get; set; }

    public string? Host { get; set; }

    public string Url { get; set; } = null!;

    public string Method { get; set; } = null!;

    public int? StatusCode { get; set; }

    public int? Duration { get; set; }

    public string? RequestBody { get; set; }

    public string? UserAgent { get; set; }
}
