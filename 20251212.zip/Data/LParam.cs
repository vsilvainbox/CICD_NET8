﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class LParam
{
    public short Codigo { get; set; }

    public string? Valor { get; set; }
}
