﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Tracking_MovComprobante
{
    public int IdMov { get; set; }

    public DateTime FechaHora { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public int? IdComp { get; set; }

    public int? IdDoc { get; set; }

    public int? Orden { get; set; }

    public int? IdCuenta { get; set; }

    public double? Debe { get; set; }

    public double? Haber { get; set; }

    public string? Glosa { get; set; }

    public int? idCCosto { get; set; }

    public int? idAreaNeg { get; set; }

    public int? IdCartola { get; set; }

    public bool? DeCentraliz { get; set; }

    public bool? DePago { get; set; }

    public bool? DeRemu { get; set; }

    public string? Nota { get; set; }

    public int? IdDocCuota { get; set; }

    public string? Origen { get; set; }

    public string? Query { get; set; }

    public int? Vigente { get; set; }

    public int? FormaIngreso { get; set; }

    public int? Ajuste { get; set; }
}
