﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class AFGrupos
{
    public int IdGrupo { get; set; }

    public int? IdEmpresa { get; set; }

    public string? NombGrupo { get; set; }
}
