﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class PlanBasico
{
    public int idCuenta { get; set; }

    public int? idPadre { get; set; }

    public string? Codigo { get; set; }

    public string? Nombre { get; set; }

    public string? Descripcion { get; set; }

    public string? CodFECU { get; set; }

    public byte? Nivel { get; set; }

    public byte? Estado { get; set; }

    public byte? Clasificacion { get; set; }

    public double? Debe { get; set; }

    public double? Haber { get; set; }

    public short? MarcaApertura { get; set; }

    public int? TipoCapPropio { get; set; }

    public short? CodF22 { get; set; }

    public byte? Atrib1 { get; set; }

    public byte? Atrib2 { get; set; }

    public byte? Atrib3 { get; set; }

    public byte? Atrib4 { get; set; }

    public byte? Atrib5 { get; set; }

    public byte? Atrib6 { get; set; }

    public byte? Atrib7 { get; set; }

    public byte? Atrib8 { get; set; }

    public byte? Atrib9 { get; set; }

    public byte? Atrib10 { get; set; }

    public string? CodIFRS_EstRes { get; set; }

    public string? CodIFRS_EstFin { get; set; }

    public string? CodIFRS { get; set; }

    public byte? TipoPartida { get; set; }

    public string? CodCtaPlanSII { get; set; }
}
