﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class DetCartola
{
    public int IdDetCartola { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public int? IdCartola { get; set; }

    public int? Fecha { get; set; }

    public string? Detalle { get; set; }

    public decimal? NumDoc { get; set; }

    public double? Cargo { get; set; }

    public double? Abono { get; set; }

    public int? IdMov { get; set; }
}
