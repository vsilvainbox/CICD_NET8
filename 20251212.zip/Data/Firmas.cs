﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Firmas
{
    public string? Patch { get; set; }

    public decimal? IdEmpresa { get; set; }

    public string? Tipo { get; set; }

    public string? ano { get; set; }
}
