﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class ConfiguraSincronizacionSII
{
    public int Id { get; set; }

    public int? IdEmpresa { get; set; }

    public string? Tipo_Libro { get; set; }

    public int? Contador { get; set; }

    public DateTime? Fecha_Sincroniza { get; set; }

    public DateTime? Fecha_Ejecucion { get; set; }

    public DateTime? Fecha_Creacion { get; set; }

    public int? IdUsuario { get; set; }
}
