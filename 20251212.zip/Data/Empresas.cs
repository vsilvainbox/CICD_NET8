﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Empresas
{
    public int IdEmpresa { get; set; }

    public string? Rut { get; set; }

    public string? NombreCorto { get; set; }

    public byte? Estado { get; set; }

    public string? RutDisp { get; set; }

    public int? Import { get; set; }

    public string? ClaveSII { get; set; }
}
