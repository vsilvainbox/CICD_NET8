﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class ControlEmpresa
{
    public int IdEmpresa { get; set; }

    public short Ano { get; set; }

    public string? RazonSocial { get; set; }

    public string? RUT { get; set; }

    public byte? Mes1 { get; set; }

    public byte? Mes2 { get; set; }

    public byte? Mes3 { get; set; }

    public byte? Mes4 { get; set; }

    public byte? Mes5 { get; set; }

    public byte? Mes6 { get; set; }

    public byte? Mes7 { get; set; }

    public byte? Mes8 { get; set; }

    public byte? Mes9 { get; set; }

    public byte? Mes10 { get; set; }

    public byte? Mes11 { get; set; }

    public byte? Mes12 { get; set; }

    public byte? AF_Depreciacion { get; set; }

    public byte? AF_CM { get; set; }

    public byte? AF_33BisLir { get; set; }

    public byte? CM_Activos { get; set; }

    public byte? CM_Pasivos { get; set; }

    public byte? BalDefinitivo { get; set; }

    public byte? CPT_Municip { get; set; }

    public byte? F22Renta { get; set; }

    public byte? AjustesIFRS { get; set; }

    public byte? CalcPropIVA { get; set; }
}
