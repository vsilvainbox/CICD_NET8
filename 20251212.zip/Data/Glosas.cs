﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Glosas
{
    public int idGlosa { get; set; }

    public int? IdEmpresa { get; set; }

    public string? Glosa { get; set; }
}
