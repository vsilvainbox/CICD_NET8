﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class BaseImponible14D
{
    public int IdBaseImponible14D { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public byte? Tipo { get; set; }

    public byte? Nivel { get; set; }

    public short? Codigo { get; set; }

    public int? Fecha { get; set; }

    public double? Valor { get; set; }
}
