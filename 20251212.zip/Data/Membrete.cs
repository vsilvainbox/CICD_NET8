﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Membrete
{
    public string? TituloMembrete1 { get; set; }

    public string? TituloMembrete2 { get; set; }

    public string? Texto1 { get; set; }

    public string? Texto2 { get; set; }

    public decimal? IdEmpresa { get; set; }
}
