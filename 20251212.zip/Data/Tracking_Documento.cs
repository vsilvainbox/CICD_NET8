﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Tracking_Documento
{
    public int IdDoc { get; set; }

    public DateTime FechaHora { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public int? IdCompCent { get; set; }

    public int? IdCompPago { get; set; }

    public byte? TipoLib { get; set; }

    public byte? TipoDoc { get; set; }

    public string? NumDoc { get; set; }

    public string? NumDocHasta { get; set; }

    public int? IdEntidad { get; set; }

    public short? TipoEntidad { get; set; }

    public string? RutEntidad { get; set; }

    public string? NombreEntidad { get; set; }

    public int? FEmision { get; set; }

    public int? FVenc { get; set; }

    public string? Descrip { get; set; }

    public short? Estado { get; set; }

    public double? Exento { get; set; }

    public int? IdCuentaExento { get; set; }

    public double? Afecto { get; set; }

    public int? IdCuentaAfecto { get; set; }

    public double? IVA { get; set; }

    public int? IdCuentaIVA { get; set; }

    public double? OtroImp { get; set; }

    public int? IdCuentaOtroImp { get; set; }

    public double? Total { get; set; }

    public int? IdCuentaTotal { get; set; }

    public int? IdUsuario { get; set; }

    public int? FechaCreacion { get; set; }

    public int? FEmisionOri { get; set; }

    public int? CorrInterno { get; set; }

    public double? SaldoDoc { get; set; }

    public int? FExported { get; set; }

    public int? OldIdDoc { get; set; }

    public bool? DTE { get; set; }

    public byte? PorcentRetencion { get; set; }

    public byte? TipoRetencion { get; set; }

    public bool? MovEdited { get; set; }

    public double? OtrosVal { get; set; }

    public int? FImporF29 { get; set; }

    public string? NumDocRef { get; set; }

    public int? IdCtaBanco { get; set; }

    public short? TipoRelEnt { get; set; }

    public int? IdSucursal { get; set; }

    public double? TotPagadoAnoAnt { get; set; }

    public int? FImportSuc { get; set; }

    public bool? Giro { get; set; }

    public bool? FacCompraRetParcial { get; set; }

    public short? IVAIrrecuperable { get; set; }

    public bool? DocOtrosEnAnalitico { get; set; }

    public int? OldIdDocTmp { get; set; }

    public string? NumFiscImpr { get; set; }

    public string? NumInformeZ { get; set; }

    public int? CantBoletas { get; set; }

    public double? VentasAcumInfZ { get; set; }

    public int? IdDocAsoc { get; set; }

    public short? PropIVA { get; set; }

    public double? ValIVAIrrec { get; set; }

    public bool? IVAInmueble { get; set; }

    public int? FImpFacturacion { get; set; }

    public short? CodSIIDTEIVAIrrec { get; set; }

    public short? TipoDocAsoc { get; set; }

    public double? IVAActFijo { get; set; }

    public bool? EntRelacionada { get; set; }

    public short? NumCuotas { get; set; }

    public bool? CompraBienRaiz { get; set; }

    public string? NumDocAsoc { get; set; }

    public bool? DTEDocAsoc { get; set; }

    public string? IdANegCCosto { get; set; }

    public string? UrlDTE { get; set; }

    public string? CodCtaAfectoOld { get; set; }

    public string? CodCtaExentoOld { get; set; }

    public string? CodCtaTotalOld { get; set; }

    public byte? DocOtroEsCargo { get; set; }

    public double? ValRet3Porc { get; set; }

    public int? IdCuentaRet3Porc { get; set; }

    public double? Tratamiento { get; set; }

    public string? Origen { get; set; }

    public string? Query { get; set; }

    public int? Vigente { get; set; }

    public int? FormaIngreso { get; set; }

    public int? Ajuste { get; set; }
}
