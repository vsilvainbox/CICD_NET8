﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Auditoria_Empresas
{
    public int id { get; set; }

    public int? idEmpresa { get; set; }

    public string? Rut { get; set; }

    public string? Nombre_Empresa { get; set; }

    public int? Annio { get; set; }

    public string? Tipo_Evento { get; set; }

    public string? Descripcion { get; set; }

    public string? Modulo { get; set; }

    public DateTime? Fecha_Evento { get; set; }

    public string? Usuario { get; set; }
}
