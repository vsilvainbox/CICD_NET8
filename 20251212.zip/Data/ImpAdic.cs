﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class ImpAdic
{
    public int IdImpAdic { get; set; }

    public int? IdEmpresa { get; set; }

    public short Ano { get; set; }

    public short? TipoLib { get; set; }

    public short? TipoValor { get; set; }

    public int? IdCuenta { get; set; }

    public float? Tasa { get; set; }

    public bool? EsRecuperable { get; set; }

    public string? CodCuenta { get; set; }
}
