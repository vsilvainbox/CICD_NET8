﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class PlanCuentasSII
{
    public int IdPlanCuentasSII { get; set; }

    public string? CodigoSII { get; set; }

    public string? DescripSII { get; set; }

    public string? FmtCodigoSII { get; set; }

    public byte? Clasificacion { get; set; }

    public short? AnoDesde { get; set; }
}
