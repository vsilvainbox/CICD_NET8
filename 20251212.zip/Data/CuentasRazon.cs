﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class CuentasRazon
{
    public int? IdRazon { get; set; }

    public int? IdEmpresa { get; set; }

    public short? NumDenom { get; set; }

    public string? CodCuenta { get; set; }

    public string? Operador { get; set; }
}
