﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class MovDocumento
{
    public int IdMovDoc { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public int? IdDoc { get; set; }

    public int? IdCompCent { get; set; }

    public int? IdCompPago { get; set; }

    public byte? Orden { get; set; }

    public int? IdCuenta { get; set; }

    public double? Debe { get; set; }

    public double? Haber { get; set; }

    public string? Glosa { get; set; }

    public short? IdTipoValLib { get; set; }

    public bool? EsTotalDoc { get; set; }

    public int? IdCCosto { get; set; }

    public int? IdAreaNeg { get; set; }

    public float? Tasa { get; set; }

    public bool? EsRecuperable { get; set; }

    public string? CodSIIDTE { get; set; }

    public string? CodCuentaOld { get; set; }
}
