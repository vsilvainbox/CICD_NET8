﻿# Catálogo de funcionalidades Hypercontabilidad
Catálogo de funcionalidades basado en análisis profundo de sistema HyperContabilidad verisón Visual Basic 6.
Las funcionalidades está agrupadas de forma lógica por grupos. Todos los formularios del sistema están mapeados.

---

## 🔍 Agente de Validación de Migraciones

**Para validar y completar features ya migradas**, utiliza:
- **Guía del Agente:** `rules/AGENTE_VALIDACION_MIGRACION.md`
- **Ejemplo Práctico:** `rules/EJEMPLO_USO_AGENTE_VALIDACION.md`

Este agente se especializa en:
- ✅ Detectar código incompleto (TODOs, NotImplementedException, placeholders)
- ✅ Verificar arquitectura correcta (MVC→API→Service)
- ✅ Validar patrones async y logging
- ✅ Completar botones faltantes
- ✅ Aplicar patrones UI/UX corporativos
- ✅ Corregir inconsistencias y errores

**Uso:** Ver ejemplo completo en `EJEMPLO_USO_AGENTE_VALIDACION.md`

---

### INICIO
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Dashboard Principal** | `FrmMain.frm` (HyperContabilidad) | \app\Features\DashboardPrincipal | Formulario principal con resumen | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 65.6% (Cambio de paradigma VB6→SPA ✨) |
| **Dashboard SQL Server** | `FrmMainSQLServer.frm` | \app\Features\DashboardSQLServer | Interfaz específica para SQL Server | 🚫 NO NECESARIO | 🟢 BAJA | ❌ NO |
| **Inicio de Aplicación** | `FrmStart.frm` | \app\Features\InicioAplicacion | Formulario de inicialización | 🚫 NO NECESARIO | 🟢 BAJA | ❌ NO |
| **Seleccionar Empresa** | `FrmSelEmpresas.frm` | \app\Features\SeleccionarEmpresa | Selector de empresa activa | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 99% |
| **Seleccionar Empresa Alternativo** | `FrmSelEmpresas_resp.frm` | \app\Features\SeleccionarEmpresaAlternativo | Selector de empresa alternativo | � NO NECESARIO | 🟡 MEDIA | ❌ NO |
| **Cambiar Contraseña** | `FrmCambioClave.frm` | \app\Features\CambiarContrasena | Cambio de credenciales | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 98.8% ⭐ |
| **Cerrar Sesión** | `FrmIdUser.frm` | \app\Features\CerrarSesion | Autenticación y logout | 🚫 NO NECESARIO | 🟢 BAJA | ❌ NO |
| **Identificación Usuario** | `FrmIdUsuario.frm` | \app\Features\IdentificacionUsuario | Identificación de usuario | 🚫 NO NECESARIO | 🟢 BAJA | ❌ NO |

### COMPROBANTES Y ASIENTOS

| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Nuevo Comprobante** | `FrmComprobante.frm` | \app\Features\NuevoComprobante | Crear asientos contables | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ |
| **Listar Comprobantes** | `FrmLstComp.frm` | \app\Features\ListarComprobantes | Buscar y editar asientos | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 99.5% ⭐⭐⭐ |
| **Listar por Tipo** | `FrmLstCompTipo.frm` | \app\Features\ListarPorTipo | Listado por tipo de comprobante | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 99.2% ⭐ |
| **Importar Comprobantes** | `FrmImpComp.frm` | \app\Features\ImportarComprobantes | Carga masiva desde archivos | 🔄 EN PROCESO | 🟡 MEDIA | ❌ NO |
| **Renumerar Comprobantes** | `FrmRenum.frm` | \app\Features\RenumerarComprobantes | Renumeración automática | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 95% ⬆️ (Paridad VB6: 100%, URLs: 100%, Frontend: 90%, Arq: 100%) |
| **Cambio Estado** | `FrmCambioEstadoComp.frm` | \app\Features\CambioEstado | Cambio de estado de comprobantes | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 99.4% ⭐ |
| **Seguimiento Cambios** | `FrmSeguimientoComp.frm` | \app\Features\SeguimientoCambios | Auditoría de modificaciones | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 97.6% ⭐⭐⭐ (Paridad VB6: 95%) |
| **Seguimiento Movimientos** | `FrmSeguimientoMovComp.frm` | \app\Features\SeguimientoMovimientos | Seguimiento de movimientos | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 93.0% ⭐⭐ (Paridad VB6: 85%) |
| **Selección Tipo** | `FrmSelCompTipo.frm` | \app\Features\SeleccionTipo | Selector de tipo de comprobante (redundante con menú lateral) | 🚫 NO NECESARIO | 🟢 BAJA | ❌ NO |

### DOCUMENTOS AUXILIARES

| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Gestión Documentos** | `FrmDoc.frm` | \app\Features\GestionDocumentos | Gestión de documentos | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 99% ⭐ |
| **Listado Documentos** | `FrmLstDoc.frm` | \app\Features\ListadoDocumentos | Listado de documentos | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 97.0% ⭐ |
| **Gestión Cuotas** | `FrmDocCuotas.frm` | \app\Features\GestionCuotas | Gestión de cuotas | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 99.5% |
| **Listado Cuotas** | `FrmLstDocCuotas.frm` | \app\Features\ListadoCuotas | Listado de cuotas | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 100% 🏆⭐⭐⭐ (Arquitectura web supera VB6) |
| **Documentos Libros** | `FrmDocLib.frm` | \app\Features\DocumentosLibros | Documentos de libros | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 100% 🏆 |
| **Selección Libros Docs** | `FrmSelLibDocs.frm` | \app\Features\SeleccionLibrosDocs | Selector de libros documentos (redundante con menú lateral) | 🚫 NO NECESARIO | 🟢 BAJA | ❌ NO |
| **Traspaso OD a ODF** | `FrmTrapasoODToODF.frm` | \app\Features\TraspasoOdToOdf | Conversión de documentos | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 96.0% 🏆⭐⭐⭐ (Paridad VB6: 90%) |
| **Importar Otros Docs** | `FrmImpOtrosDocs.frm` | \app\Features\ImportarOtrosDocs | Importación básica | ✅ COMPLETADO | 🟡 MEDIA | 🔄 EN PROCESO |
| **Importar Otros Docs Completa** | `FrmImpOtrosDocFull.frm` | \app\Features\ImportarOtrosDocsCompleta | Importación completa | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 98.0% 🏆⭐⭐⭐ (Paridad VB6: 95%) |
| **Selección Importación OD** | `FrmSelImpoOD.frm` | \app\Features\SeleccionImportacionOd | Selector importación otros docs (redundante con menú lateral) | 🚫 NO NECESARIO | 🟢 BAJA | ❌ NO |

### LIBROS CONTABLES
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Libro Diario** | `FrmLibDiario.frm` | \app\Features\LibroDiario | Registro cronológico | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 97.7% ⭐ |
| **Libro Mayor** | `FrmLibMayor.frm` | \app\Features\LibroMayor | Movimientos por cuenta | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 98.8% ⭐⭐⭐ |
| **Libro Inventario y Balance** | `FrmLibInvBal.frm` | \app\Features\LibroInventarioBalance | Inventario de cuentas | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 95.8% ⭐ |
| **Libro de Retenciones** | `FrmLibRetenciones.frm` | \app\Features\LibroRetenciones | Retenciones tributarias | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 100% 🏆 |
| **Libro Electrónico Compras** | `FrmLibElectCompras.frm` | \app\Features\LibroElectronicoCompras | Para SII | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 97% ⭐ |
| **Libro Ingresos y Egresos** | `FrmLibIngEg.frm` | \app\Features\LibroIngresosEgresos | Flujo de caja | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 78.75% ⚠️ |
| **Libro de Caja** | `FrmLibroCaja.frm` | \app\Features\LibroCaja | Movimientos de caja | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 97% ⭐ |
| **Selección Libros** | `FrmSelLibros.frm` | \app\Features\SeleccionLibros | Selector de libros (redundante con menú lateral) | 🚫 NO NECESARIO | 🟢 BAJA | ❌ NO |
| **Selección Libro Caja** | `FrmSelLibCaja.frm` | \app\Features\SeleccionLibroCaja | Selector libro caja (redundante con menú lateral) | 🚫 NO NECESARIO | 🟢 BAJA | ❌ NO |
| **Selección Libro 14ter** | `FrmSelLib14ter.frm` | \app\Features\SeleccionLibro14ter | Selector libro 14ter (redundante con menú lateral) | 🚫 NO NECESARIO | 🟢 BAJA | ❌ NO |

### BALANCES Y ESTADOS
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Balance Clasificado** | `FrmBalClasif.frm` | \app\Features\BalanceClasificado | Balance general clasificado | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 100% 🏆 |
| **Balance Comparativo** | `FrmBalClasifCompar.frm` | \app\Features\BalanceClasificadoComparativo | Comparación entre períodos | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 99.8% 🏆⭐⭐⭐ |
| **Balance Desglosado** | `FrmBalClasifDesglo.frm` | \app\Features\BalanceDesglosado | Balance desglosado | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 97.6% 🏆⭐⭐⭐ (Paridad VB6: 95%, URLs: 100%, Frontend: 98%, Arq: 100%) |
| **Balance Ejecutivo** | `FrmBalClasifEjec.frm` | \app\Features\BalanceEjecutivo | Resumen para gerencia | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0+MIG - 92% 🏆 (3/3 críticas ✅) |
| **Balance de Comprobación** | `FrmBalComprobacion.frm` | \app\Features\BalanceComprobacion | Verificación de saldos | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 98.75% (Paridad 100%) ⭐⭐⭐ |
| **Balance General** | `FrmBalTributario.frm` | \app\Features\BalanceGeneral | Balance General 8 Columnas | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 99.8% ⭐⭐⭐ |
| **Estado de Resultados** | N/A (integrado en FrmBalClasif) | \app\Features\EstadoResultados | Estado de Resultados por Función | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 98.8% ⭐ |
| **Balance Tributario IFRS** | `FrmBalTributarioIFRS.frm` | \app\Features\BalanceTributarioIfrs | Balance tributario IFRS | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 100% 🏆 |
| **Balance Ejecutivo IFRS** | `FrmBalEjecIFRS.frm` | \app\Features\BalanceEjecutivoIfrs | Balance ejecutivo IFRS | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 95.6% |
| **Selección Balances** | `FrmSelBalances.frm` | \app\Features\SeleccionBalances | Selector de balances (redundante con menú lateral) | 🚫 NO NECESARIO | 🟢 BAJA | ❌ NO |
| **Selección Estados Resultado** | `FrmSelEstRes.frm` | \app\Features\SeleccionEstadosResultado | Selector estados resultado (redundante con menú lateral) | 🚫 NO NECESARIO | 🟢 BAJA | ❌ NO |

### ANÁLISIS Y CONSULTAS
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Informe Analítico** | `FrmInfAnalitico.frm` | \app\Features\InformeAnalitico | Análisis básico | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 96% ⭐⭐⭐ |
| **Informe Analítico Avanzado** | `FrmInfAnaliticoAdv.frm` | \app\Features\InformeAnaliticoAvanzado | Análisis avanzado | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 94.5% |
| **Informe Analítico Completo** | `FrmInfAnaliticoFull.frm` | \app\Features\InformeAnaliticoCompleto | Análisis completo | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 100% 🏆 |
| **Informe Analítico Extendido** | `FrmInfAnaliticoFulle.frm` | \app\Features\InformeAnaliticoExtendido | Análisis extendido | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 92.5% |
| **Informe Analítico Extendido Legacy** | `FrmInfAnaliticoFulle_old.frm` | \app\Features\InformeAnaliticoExtendidoLegacy | Versión legacy del análisis extendido | ✅ COMPLETADO | 🟢 BAJA | ✅ SÍ v4.0 - 93.5% ⭐⭐⭐ |
| **Selección Informes Analíticos** | `FrmSelInfAnalit.frm` | \app\Features\SeleccionInformesAnaliticos | Selector de informes (redundante con menú lateral) | 🚫 NO NECESARIO | 🟢 BAJA | ❌ NO |
| **Razones Financieras** | `FrmCalcRazones.frm` | \app\Features\RazonesFinancieras | Cálculo de indicadores | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 96% ⭐⭐⭐ |
| **Parámetros Razones** | `FrmParamRaz.frm` | \app\Features\ParametrosRazones | **⚠️ COMPONENTE MODAL** - Vista invocada DESDE RazonesFinancieras para configurar cuentas de numerador/denominador. NO debe estar en menú de navegación. Requiere parámetros: idRazon, empresaId, año | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Análisis de Vencimientos** | `FrmInfoVencim.frm` | \app\Features\AnalisisVencimientos | Control de documentos | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 95% ⭐⭐⭐ |
| **Resumen IVA** | `FrmResIVA.frm` | \app\Features\ResumenIva | Resumen de impuestos | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 99.6% ⭐⭐⭐ |
| **Resumen Otros Impuestos** | `FrmResOtrosImp.frm` | \app\Features\ResumenOtrosImpuestos | Otros impuestos | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 96% ⭐⭐⭐ |
| **Resumen Retención 3%** | `FrmResRet3Porc.frm` | \app\Features\ResumenRetencion3Porc | Retención 3% | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 97% ⭐⭐⭐ |
| **Resumen Documentos** | `FrmResDocs.frm` | \app\Features\ResumenDocumentos | Consolidado documentos | 🔄 EN PROCESO | 🟠 ALTA | 🔄 EN PROCESO v4.0 |

### REPORTES ESPECIALIZADOS
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Libros Impresos** | `FrmLstLibImpresos.frm` | \app\Features\LibrosImpresos | Control de timbraje | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 98.0% 🏆⭐⭐⭐ (Paridad VB6: 95%, URLs: 100%, Frontend: 100%, Arq: 100%) |
| **Resumen Libros Auxiliares** | `FrmResLibAux.frm` | \app\Features\ResumenLibrosAuxiliares | Resumen libros | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 100% 🏆 |
| **Resumen Cartolas** | `FrmResCartolas.frm` | \app\Features\ResumenCartolas | Resumen cartolas | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 94.0% |
| **Resumen VPE** | `FrmResDocs.frm` (modo VPE) | \app\Features\ResumenVpe | Resumen Vales Pago Electrónico | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 100% 🏆 |
| **Reporte por Nivel** | `FrmRepPorNivel.frm` | \app\Features\ReportePorNivel | Reportes por nivel | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 93.0% |
| **Suma Movimientos** | `FrmSumMov.frm` | \app\Features\SumaMovimientos | **⚠️ COMPONENTE REUTILIZABLE** - Modal invocado desde otras features (LibroDiario, LibroMayor, InformeAnalítico, etc.) para calcular sumas/promedios de grillas Debe/Haber. NO es una feature de menú. Incluido en wwwroot/js/suma-movimientos.js | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Suma Simple** | `FrmSumSimple.frm` | \app\Features\SumaSimple | **⚠️ COMPONENTE REUTILIZABLE** - Modal invocado desde BalanceClasificado, BalanceGeneral, RazonesFinancieras para calcular suma simple de valores seleccionados. NO es una feature de menú | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Revisar Detalle Documentos** | `FrmRevDetDocs.frm` | \app\Features\RevisarDetalleDocumentos | Revisión documentos | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |

### DATOS MAESTROS
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Plan de Cuentas** | `FrmPlanCuentas.frm` | \app\Features\PlanCuentas | Configuración del plan | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 97.8% ⭐⭐⭐ |
| **Copiar Plan de Cuentas** | `FrmCopyPlan.frm` | \app\Features\CopiarPlanCuentas | Copiar cuentas entre empresas | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 95% ⬆️ (Paridad VB6: 100%, URLs: 95%, Frontend: 90%, Arq: 95%) |
| **Listado Plan de Cuentas** | `FrmListadoPlanCuentas.frm` | \app\Features\ListadoPlanCuentas | Listado del plan | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 97.1% |
| **Preview Plan de Cuentas** | `FrmLstPlanCuentasPreview.frm` | \app\Features\PreviewPlanCuentas | Vista previa | ✅ COMPLETADO | 🟢 BAJA | ✅ SÍ v4.0 - 95.5% ⭐⭐⭐ |
| **Cuenta** | `FrmCuenta.frm` | \app\Features\Cuenta | **⚠️ HUB DE NAVEGACIÓN** - Modal invocado desde PlanCuentas para crear/editar cuentas individuales. Rutas: /Cuenta/Create, /Cuenta/Edit, /Cuenta/View. NO es una feature de menú independiente. | ✅ COMPLETADO | 🟢 BAJA | ✅ SÍ v4.0 - 95.8% ⭐⭐⭐ |
| **Entidades Relacionadas** | `FrmEntidades.frm` | \app\Features\EntidadesRelacionadas | Clientes, proveedores | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 100% (Paridad 100%) ⭐⭐⭐ |
| **Edición de Entidad** | `FrmEntidad.frm` | \app\Features\EdicionEntidad | Edición individual | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 99.95% ⭐⭐⭐ |
| **Áreas de Negocio** | `FrmAreaNeg.frm` | \app\Features\AreasNegocio | Segmentación empresarial | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 100% 🏆 |
| **Área de Negocio Individual** | `FrmANeg.frm` | \app\Features\AreasNegocio | Edición individual área negocio (Modal integrado en AreasNegocio) | ✅ COMPLETADO | 🟢 BAJA | ✅ SÍ v4.0 - 92.3% ⭐⭐⭐ |
| **Centros de Costo** | `FrmCentrosCosto.frm` | \app\Features\CentrosCosto | Centros de responsabilidad | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 100% 🏆 |
| **Centro de Costo Individual** | `FrmCCosto.frm` | \app\Features\CentroCostoIndividual | **⚠️ MODAL** - Invocado desde CentrosCosto para crear/editar centros individuales. Rutas: /CentroCostoIndividual/Nuevo, /Editar, /Ver. NO es una feature de menú independiente. | ✅ COMPLETADO | 🟢 BAJA | ✅ SÍ v4.0 - 98.8% ⭐⭐⭐ |
| **Sucursales** | `FrmSucursales.frm` | \app\Features\Sucursales | Gestión de ubicaciones | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 99.5% 🏆 |
| **Sucursal Individual** | `FrmSucursal.frm` | \app\Features\SucursalIndividual | **⚠️ MODAL** - Invocado desde Sucursales para crear/editar sucursales individuales. Rutas: /SucursalIndividual/Nuevo, /Editar, /Ver. NO es una feature de menú independiente. | ✅ COMPLETADO | 🟢 BAJA | ✅ SÍ v4.0 - 98.8% ⭐⭐⭐ |
| **Tipos de Documentos** | `FrmTipoDocs.frm` | \app\Features\TiposDocumentos | Configuración tributaria | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 98.25% ⭐ |
| **Grupos** | `FrmGrupo.frm` | \app\Features\Grupos | Gestión de grupos | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 92.0% |
| **Listado de Atributos** | `FrmLstAtrib.frm` | \app\Features\ListadoAtributos | Gestión de atributos | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 100% 🏆 |

### CONFIGURACIÓN EMPRESARIAL
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Datos de la Empresa** | `FrmEmpresa.frm` | \app\Features\DatosEmpresa | Información general | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 96.5% |
| **Configuración Principal** | `FrmConfig.frm` | \app\Features\ConfiguracionPrincipal | Parámetros del sistema | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 96.5% |
| **Cuentas Ajustes Extra-contables** | `FrmConfigCtasAjustes.frm` | \app\Features\CuentasAjustesExtraContables | Configuración ajustes | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 99.6% 🏆 |
| **Cuentas Ajustes RLI** | `FrmConfigCtasAjustesRLI.frm` | \app\Features\CuentasAjustesRli | Configuración RLI | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 99.6% 🏆 |
| **Cuentas Definidas** | `FrmConfigCtasDef.frm` | \app\Features\CuentasDefinidas | Cuentas definidas | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 93.8% |
| **Configuración Plan Cuentas** | `frmConfigDefinidasPlanCuenta.frm` | \app\Features\ConfiguracionPlanCuentas | Config plan cuentas | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 100% 🏆 |
| **Configuración FUT** | `FrmConfigFUT.frm` | \app\Features\ConfiguracionFut | Configuración FUT (Bloqueada por integración HR-FUT) | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 100% ✅ (Stub correcto) |
| **Configuración Impuestos Adicionales** | `FrmConfigImpAdic.frm` | \app\Features\ConfiguracionImpuestosAdicionales | Impuestos adicionales | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ |
| **Configuración Firma Informes** | `FrmConfigInformeFirma.frm` | \app\Features\ConfiguracionFirmaInformes | Firma en informes | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 93.5% |
| **Configuración Informes** | `FrmConfigInformes.frm` | \app\Features\ConfiguracionInformes | Configuración informes | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 92.0% |
| **Configuración Remuneraciones** | `FrmConfigRemu.frm` | \app\Features\ConfiguracionRemuneraciones | Integración nóminas | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 100% 🏆 |
| **Monedas** | `FrmMonedas.frm` | \app\Features\Monedas | Gestión de monedas | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 99.6% 🏆 |
| **Mantenimiento Monedas** | `FrmMantMoneda.frm` | \app\Features\MantenimientoMonedas | Mantenimiento individual | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 100% 🏆 |
| **Equivalencias de Monedas** | `FrmEquivMonedas.frm` | \app\Features\EquivalenciasMonedas | Tipos de cambio | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 99.6% 🏆 |
| **Factores de Actualización** | `FrmFactoresAct.frm` | \app\Features\FactoresActualizacion | Factores actualización | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 99.3% ⭐⭐⭐ |
| **Razones Financieras** | `FrmRazones.frm` | \app\Features\MantenimientoRazonesFinancieras | Indicadores personalizados | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 93.0% |
| **Datos de Oficina** | `FrmOficina.frm` | \app\Features\DatosOficina | Información oficina | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 92.5% |
| **Valores e Índices** | `FrmIPC.frm` | \app\Features\ValoresIndices | Índices económicos | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 93.5% |

### GESTIÓN DE ACTIVOS
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Gestión Activo Fijo** | `FrmActivoFijo.frm` | \app\Features\GestionActivoFijo | Gestión integral | ✅ COMPLETADO | 🟠 ALTA | ⚠️ PENDIENTE AUDITORÍA EXHAUSTIVA (2993 líneas VB6, 98 funciones - requiere sesión dedicada) |
| **Listado Activo Fijo** | `FrmLstActFijo.frm` | \app\Features\ListadoActivoFijo | Listado de activos | ✅ COMPLETADO | 🟠 ALTA | 🔄 EN PROCESO v4.0 |
| **Ficha Activo Fijo** | `FrmAFFicha.frm` | \app\Features\FichaActivoFijo | **⚠️ MODAL** - Invocado desde GestionActivoFijo para editar ficha financiera de activo. Ruta: /FichaActivoFijo?idActFijo={id}. NO es una feature de menú independiente. | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 91.7% ⚠️ |
| **Componentes Activo Fijo** | `FrmAFCompsFicha.frm` | \app\Features\ComponentesActivoFijo | **⚠️ MODAL** - Invocado desde FichaActivoFijo para gestionar componentes del activo. Ruta: /ComponentesActivoFijo?idActFijo={id}. NO es una feature de menú independiente. | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 91.5% |
| **Información Adicional** | `FrmActFijoInfoAdic.frm` | \app\Features\InformacionAdicionalActivoFijo | **⚠️ HUB DE NAVEGACIÓN** - Redirige a GestionActivoFijo. La edición de Patente/Rol, Nombre Proyecto, Fecha Proyecto se hace desde GestionActivoFijo. NO es una feature de menú independiente. | ✅ COMPLETADO | 🟢 BAJA | ✅ SÍ v4.0 - 100% ⭐⭐⭐ |
| **Marcación Activo Fijo** | `FrmMarkActFijo.frm` | \app\Features\MarcacionActivoFijo | Marcación de activos | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 92.0% |
| **Importar Activo Fijo** | `FrmImpActFijos.frm` | \app\Features\ImportarActivoFijo | Importación de activos | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 93.0% |
| **Importar Activo Fijo Archivo** | `FrmImpActFijoFile.frm` | \app\Features\ImportarActivoFijoArchivo | Importación desde archivo | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 92.5% |
| **Selección Reporte Activo Fijo** | `FrmSelRepActFijo.frm` | \app\Features\SeleccionReporteActivoFijo | Selector reportes activos (redundante con menú lateral) | 🚫 NO NECESARIO | 🟢 BAJA | ❌ NO |

### REPORTES DE ACTIVOS
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Reporte Activo Fijo** | `FrmRepActivoFijo.frm` | \app\Features\ReporteActivoFijo | Reportes de activo fijo | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Reporte Activo Fijo IFRS** | `FrmRepActFijoIFRS.frm` | \app\Features\ReporteActivoFijoIfrs | Reportes activos IFRS | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 91.0% |
| **Reporte Activo Fijo 220823** | `FrmRepActivoFijo_220823.frm` | \app\Features\ReporteActivoFijo220823 | Versión específica | ❌ NO MIGRADO | 🟢 BAJA | ❌ NO (Feature NO existe en .NET 9) |

### CONFIGURACIÓN ACTIVO FIJO
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Configuración Activo Fijo** | `FrmConfigActFijo.frm` | \app\Features\ConfiguracionActivoFijo | Configuración del módulo | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Configuración Activo Fijo IFRS** | `FrmConfigActFijoIFRS.frm` | \app\Features\ConfiguracionActivoFijoIfrs | Configuración activos IFRS | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Configuración Comprobante Activo Fijo** | `FrmConfigCompActFijo.frm` | \app\Features\ConfiguracionComprobanteActivoFijo | Config comprobante AF | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |

### CAPITAL Y PATRIMONIO
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Capital Aportado** | `FrmCapitalAportado.frm` | \app\Features\CapitalAportado | Seguimiento de aportes de capital | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Capital Propio** | `FrmCapitalPropio.frm` | \app\Features\CapitalPropio | Gestión de capital propio | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Capital Propio Simplificado** | `FrmCapPropioSimpl.frm` | \app\Features\CapitalPropioSimplificado | Seguimiento simplificado de capital | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Detalle Capital Simple** | `FrmDetCapPropioSimpl.frm` | \app\Features\DetalleCapitalSimple | Desglose detallado del capital | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Capital Simple Acumulado** | `FrmDetCapPropioSimplAcum.frm` | \app\Features\CapitalSimpleAcumulado | Detalle de capital acumulado | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Capital Simple Mini** | `FrmDetCapPropioSimplMini.frm` | \app\Features\CapitalSimpleMini | Vista compacta del capital | ✅ COMPLETADO | 🟢 BAJA | ✅ SÍ v4.0 - 90.4% ⭐⭐ |

### AJUSTES EXTRA-CONTABLES
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Ajustes Extra-Contables Caja** | `FrmAjustesExtraLibCaja.frm` | \app\Features\AjustesExtraContablesCaja | Ajustes de libro de caja | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Ajustes RLI Caja** | `FrmAjustesExtraLibCajaRLI.frm` | \app\Features\AjustesRliCaja | Ajustes RLI de caja | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |

### PROCESOS DE CONCILIACIÓN
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Gestión Conciliación** | `FrmConciliacion.frm` | \app\Features\GestionConciliacion | Motor de conciliación | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Información Conciliación** | `FrmInfConciliacion.frm` | \app\Features\InformacionConciliacion | Información detallada de conciliación | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Resumen Información Conciliación** | `FrmResInfConcil.frm` | \app\Features\ResumenInformacionConciliacion | Resumen conciliación | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Saldos y Totales Libro Caja** | `FrmSalyTotLibCajas.frm` | \app\Features\SaldosTotalesLibroCaja | Saldos libro caja | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |

### SII - SERVICIO DE IMPUESTOS INTERNOS
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Sincronización SII** | `FrmSincronizacionSII.frm` | \app\Features\SincronizacionSii | Integración con SII | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 91% |
| **Solicitud Sincronizaciones SII** | `FrmSolicitudSincronizacionesSII.frm` | \app\Features\SolicitudSincronizacionSii | Solicitudes SII | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Copiar Sincronización** | `FrmCopiarSincronizacion.frm` | \app\Features\CopiarSincronizacion | Copia sincronización | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Editar Sincronización** | `FrmEditarSincronizacion.frm` | \app\Features\EditarSincronizacion | Edición sincronización | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Mensaje Sincronización** | `FrmMsgSincronizacion.frm` | \app\Features\MensajeSincronizacion | **⚠️ COMPONENTE REUTILIZABLE** - Modal invocado desde otras features (SincronizacionSii, etc.) para postergar sincronizaciones SII seleccionando horas de espera (1-24). Actualiza campo `Contador` en `ConfiguraSincronizacionSII`. NO es una feature de menú. Usar: `mostrarMensajeSincronizacion(id, callback)` desde JavaScript. Incluido en wwwroot/js/mensaje-sincronizacion.js | ✅ COMPLETADO | 🟢 BAJA | ✅ SÍ v4.0 - 98.5% ⭐⭐⭐ |
| **Importar Datos SII** | `FrmIntegracionDatosSII.frm` | \app\Features\ImportarDatosSii | Integración tributaria | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 101.6% ⭐⭐⭐ [VALIDACION](docs/VALIDACION_COMPLETA_V4_ImportarDatosSii_2025-10-26.md) |

### REPORTES TRIBUTARIOS
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Base Imponible** | `FrmBaseImponible.frm` | \app\Features\BaseImponible | Base imponible | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 96% ⭐⭐⭐ |
| **Base Imponible 14D** | `FrmBaseImponible14D.frm` | \app\Features\BaseImponible14D | Base imponible 14D (Pro Pyme General 14DN3 y Transparente 14DN8) | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 95.0% ⭐ [AUDITORIA](docs/AUDITORIA_VB6_vs_NET9_BaseImponible14D.md) [VALIDACION](docs/VALIDACION_MIGRACION_BaseImponible14D_2025-10-26.md) |
| **Base Imponible 14D Completa** | `FrmBaseImponible14DFull.frm` | \app\Features\BaseImponible14DCompleta | Base imponible 14D completa | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 100% 🏆⭐⭐⭐ (Fases 1-4 OK: Estructura+Cálculos+IVA+UX ✅) [AUDITORIA](docs/AUDITORIA_VB6_vs_NET9_BaseImponible14D.md) |
| **Selección 14D Pro Pyme** | `FrmSel14DProPyme.frm` | \app\Features\Seleccion14DProPyme | Selector 14D Pro Pyme (redundante con menú lateral) | 🚫 NO NECESARIO | 🟢 BAJA | ❌ NO |
| **Detalle Base Imponible 14D** | `FrmDetBaseImponible14DFull.frm` | \app\Features\DetalleBaseImponible14D | Detalle base imponible 14D | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Importar SII Compras** | `FrmImpLibComprasSII.frm` | \app\Features\ImportarSiiCompras | Importación SII compras | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 89.5% ⭐⭐⭐ [AUDITORIA](docs/AUDITORIA_VB6_vs_NET9_ImportarSiiCompras.md) |
| **Importar SII Ventas** | `FrmImpLibVentasSII.frm` | \app\Features\ImportarSiiVentas | Importación SII ventas | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 91.0% ⭐⭐⭐ [AUDITORIA](docs/AUDITORIA_VB6_vs_NET9_ImportarSiiVentas.md) [RESUMEN](docs/APLICACION_FLUJO_V4_ImportarSiiVentas_RESUMEN.md) |
| **Importar SII Retenciones** | `FrmImpLibRetencionesSII.frm` | \app\Features\ImportarSiiRetenciones | Importación SII retenciones | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Importar Datos SII** | `FrmIntegracionDatosSII.frm` | \app\Features\ImportarDatosSii | Integración tributaria | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 101.6% ⭐⭐⭐ [VALIDACION](docs/VALIDACION_COMPLETA_V4_ImportarDatosSii_2025-10-26.md) |
| **Percepciones** | `FrmPercepciones.frm` | \app\Features\Percepciones | Gestión de percepciones | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Mantenimiento Percepciones** | `FrmMantPercepciones.frm` | \app\Features\MantenimientoPercepciones | Mantenimiento percepciones | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 100% 🏆 |
| **IVA** | `FrmIVA.frm` | \app\Features\Iva | Gestión de IVA | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 96% |
| **Proporcionalidad IVA** | `FrmPropIVA.frm` | \app\Features\ProporcionalidadIva | Cálculo IVA proporcional | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Exportar DJ Anual** | `FrmExpDJAnual.frm` | \app\Features\ExportarDjAnual | Exportación declaración anual | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 100% 🏆 |

### REPORTES IFRS
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Estado Situación Financiera IFRS** | `FrmLstIInformeIFRS.frm` | \app\Features\EstadoSituacionFinancieraIfrs | Balance bajo IFRS | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Estado Resultado IFRS** | `FrmLstIInformeIFRS.frm` | \app\Features\EstadoResultadoIfrs | Estado resultado bajo IFRS | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Configurar Códigos IFRS** | `FrmConfigCodIFRS.frm` | \app\Features\ConfigurarCodigosIfrs | Mapeo cuentas IFRS | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Selección Informes IFRS** | `FrmSelInfIFRS.frm` | \app\Features\SeleccionInformesIfrs | Selector informes IFRS (redundante con menú lateral) | 🚫 NO NECESARIO | 🟢 BAJA | ❌ NO |

### SINCRONIZACIÓN SII
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Copiar Sincronización** | `FrmCopySinc.frm` | \app\Features\CopiarSincronizacion | Copiar config sincronización | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Editar Sincronización** | `FrmEditSinc.frm` | \app\Features\EditarSincronizacion | Editar sincronización | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Mensajes Sincronización** | `FrmMensajeSinc.frm` | \app\Features\MensajeSincronizacion | **⚠️ COMPONENTE REUTILIZABLE** - Mismo que MensajeSincronizacion. NO es feature de menú, es modal JS invocado desde SincronizacionSii | ✅ COMPLETADO | 🟢 BAJA | ✅ SÍ v4.0 - 98.5% ⭐⭐⭐ |

### IMPORTAR DATOS
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Importar Facturación** | `FrmImpFacturacion.frm` | \app\Features\ImportarFacturacion | Integración facturación | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 100% 🏆 |
| **Importar Libros Auxiliares** | `FrmImpLibAux.frm` | \app\Features\ImportarLibrosAuxiliares | Importación libros | ✅ COMPLETADO | 🟡 MEDIA | ✅ SÍ v4.0 - 100% 🏆 |
| **Importar Remuneraciones** | `FrmImportRemu.frm` | \app\Features\ImportarRemuneraciones | Importación remuneraciones | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 100% 🏆 |
| **Importar Cartolas Bancarias** | `FrmImpCartola.frm` | \app\Features\ImportarCartolasBancarias | Importación cartolas bancarias | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 100% 🏆 |
| **Importar Centros de Costo** | `FrmImpCentroCosto.frm` | \app\Features\ImportarCentrosCosto | Importación centros costo | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Importar Áreas de Negocio** | `FrmImpAreaNegocio.frm` | \app\Features\ImportarAreasNegocio | Importación áreas | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Importar Sucursales** | `FrmImpSucursales.frm` | \app\Features\ImportarSucursales | Importación sucursales | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Importar F29** | `FrmImportF29.frm` | \app\Features\ImportarF29 | Importación formulario 29 | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 100% 🏆 |
| **Importar/Exportar Libros** | `FrmImpExpLib.frm` | \app\Features\ImportarExportarLibros | Intercambio libros | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Ejemplo Importación** | `FrmEjemploImport.frm` | \app\Features\EjemploImportacion | Ejemplo de importación | ✅ COMPLETADO | 🟢 BAJA | ✅ SÍ v4.0 - 100% 🏆 |
| **Formato Importación Entidades** | `FrmFmtImpEnt.frm` | \app\Features\FormatoImportacionEntidades | Formato importación | ✅ COMPLETADO | 🟢 BAJA | ✅ SÍ v4.0 - 100% 🏆 |

### EXPORTAR DATOS
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Exportar Entidades** | `FrmExpEntidades.frm` | \app\Features\ExportarEntidades | Exportación entidades | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Exportar F22** | `FrmExpF22.frm` | \app\Features\ExportarF22 | Exportación formulario 22 | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 96.9% ⭐⭐⭐ |
| **Exportar F29** | `FrmExpF29.frm` | \app\Features\ExportarF29 | Exportación formulario 29 | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 99% ⭐⭐⭐ |
| **Exportar Facturación** | `FrmExpFacturacion.frm` | \app\Features\ExportarFacturacion | Exportación facturación | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Exportar HR Certificados** | `FrmExpHRCertif.frm` | \app\Features\ExportarHrCertificados | Exportación certificados | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Exportar Percepciones** | `FrmExpPercepciones.frm` | \app\Features\ExportarPercepciones | Exportación percepciones | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Exportar DJ Anual** | `FrmExpDJAnual.frm` | \app\Features\ExportarDjAnual | Exportación declaración anual | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 100% 🏆 |

### GESTIÓN DE USUARIOS
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Usuarios del Sistema** | `FrmUsuarios.frm` | \app\Features\UsuariosSistema | Administración usuarios | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 98.2% ⭐ |
| **Mantenimiento Usuarios** | `FrmMantUsuario.frm` | \app\Features\MantenimientoUsuarios | ⚠️ DUPLICADO UsuariosSistema | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 78.6% (98.6% técnico, -20% duplicación) ⚠️ CONSOLIDAR |
| **Perfiles y Permisos** | `FrmPerfiles.frm` | \app\Features\PerfilesPermisos | Configuración roles | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 100% ⭐⭐⭐⭐ |
| **Privilegios por Empresa** | `FrmUsuarioPriv.frm` | \app\Features\PrivilegiosPorEmpresa | Permisos específicos | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Usuarios Fiscalizadores** | `FrmCrearUsrFiscalizador.frm` | \app\Features\UsuariosFiscalizadores | Para auditoría | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Licenciar Producto** | `FrmEquiposAut.frm` | \app\Features\LicenciarProducto | Gestión licencias | ❌ PENDIENTE | 🟠 ALTA | ❌ NO |

### GESTIÓN DE EMPRESAS
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Mantenimiento Empresas** | `FrmMantEmpresa.frm` | \app\Features\MantenimientoEmpresas | Mantenimiento administrativo | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 99% |
| **Listado Empresas** | `FrmEmpresas.frm` | \app\Features\ListadoEmpresas | Listado administrativo | ✅ COMPLETADO | 🟠 ALTA | ✅ SÍ v4.0 - 99% |
| **Control Empresas** | `FrmContEmpresa.frm` | \app\Features\ControlEmpresas | Control y seguimiento | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Reporte Control Empresas** | `FrmRepContEmpresas.frm` | \app\Features\ReporteControlEmpresas | Reporte de control | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Reporte Control Empresas Alt** | `FrmReporteControlEmpresas.frm` | \app\Features\ReporteControlEmpresasAlt | Reporte control empresarial | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Selección por Nivel** | `FrmSelEmpresasNivelEmpresa.frm` | \app\Features\SeleccionPorNivel | Selección por nivel licencia (redundante con menú lateral) | 🚫 NO NECESARIO | 🟢 BAJA | ❌ NO |
| **Selección para Traspaso** | `FrmSelEmpresasTras.frm` | \app\Features\SeleccionParaTraspaso | Selección para migración (redundante con menú lateral) | 🚫 NO NECESARIO | 🟡 MEDIA | ❌ NO |
| **Importar desde HR** | `FrmEmpHR.frm` | \app\Features\ImportarDesdeHr | Importación desde HR | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Importar desde LPRemu** | `FrmEmpLpRemu.frm` | \app\Features\ImportarDesdeLpRemu | Importación remuneraciones | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Importar desde Archivo** | `FrmEmpArchivo.frm` | \app\Features\ImportarDesdeArchivo | Importación archivos | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Importar Empresa** | `FrmImpEmpresa.frm` | \app\Features\ImportarEmpresa | Importación empresa | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Importar Empresas** | `FrmImportEmpresas.frm` | \app\Features\ImportarEmpresas | Importación empresas | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Exportar Empresa** | `FrmExportEmp.frm` | \app\Features\ExportarEmpresa | Exportación empresas | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Eliminar Empresa-Año** | `FrmResetEmprAno.frm` | \app\Features\EliminarEmpresaAno | Eliminación períodos | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Impresión Empresas** | `FrmPrtEmpresas.frm` | \app\Features\ImpresionEmpresas | Impresión listado | ✅ COMPLETADO | 🟢 BAJA | ✅ SÍ v4.0 - 100% 🏆 |
| **Información Ayuda Empresas** | `FrmInforAyudaEmpresas.frm` | \app\Features\InformacionAyudaEmpresas | Ayuda específica | ✅ COMPLETADO | 🟢 BAJA | ✅ SÍ v4.0 - 100% 🏆 |

### CONFIGURACIÓN DEL SISTEMA
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Configuración Impresión** | `FrmPrtSetup.frm` | \app\Features\ConfiguracionImpresion | Setup de impresión | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Configuración Impresión Cheques** | `FrmConfigCheque.frm` | \app\Features\ConfiguracionImpresionCheques | Configuración cheques | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Configuración Hojas Timbraje** | `FrmConfigHojasTimbraje.frm` | \app\Features\ConfiguracionHojasTimbraje | Configuración timbraje | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Configuración Corrección Comprobantes** | `FrmConfigCorrComp.frm` | \app\Features\ConfiguracionCorreccionComprobantes | Config corrección | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Cuentas Libro Compras** | `FrmConfigCtasLibCompras.frm` | \app\Features\CuentasLibroCompras | Config libro compras | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Cuentas Libro Ventas** | `FrmConfigCtasLibVentas.frm` | \app\Features\CuentasLibroVentas | Config libro ventas | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Configuración Plan Cuentas 2019** | `frmConfigDefinidasPlanCuenta2019.frm` | \app\Features\ConfiguracionPlanCuentas2019 | Versión 2019 | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Foliación para Timbraje** | `FrmPrtFoliacion.frm` | \app\Features\FoliacionParaTimbraje | Foliación para timbrado | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Información Folios** | `FrmFoliacion.frm` | \app\Features\InformacionFolios | Información folios | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Herramientas de Integración** | `FrmIntTools.frm` | \app\Features\HerramientasIntegracion | Herramientas integración | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Asistente PPM** | `FrmAsisPPM.frm` | \app\Features\AsistentePpm | Asistente PPM | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Asistente Importación Primera Categoría** | `FrmAsistImpPrimCat.frm` | \app\Features\AsistenteImportacionPrimeraCategoria | Asistente importación | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Cuenta Email** | `FrmEmailAccount.frm` | \app\Features\CuentaEmail | Configuración cuenta email | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |

### CONTROL DE PERÍODOS
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Abrir/Cerrar Mes** | `FrmEstadoMeses.frm` | \app\Features\AbrirCerrarMes | Control períodos contables | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 98.75% (Paridad 100%) ⭐⭐⭐ |
| **Cierre Anual** | `FrmCierreAnual.frm` | \app\Features\CierreAnual | Cierre de ejercicio | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 99.4% (Paridad 98.4%, URLs 100%, Frontend 100%, Arq 100%) ⭐⭐⭐⭐ |
| **Apertura** | `FrmApertura.frm` | \app\Features\Apertura | Apertura de períodos | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - Análisis en progreso |
| **Saldo de Apertura** | `FrmSaldoApertura.frm` | \app\Features\SaldoApertura | Saldos iniciales | ✅ COMPLETADO | 🔴 CRÍTICA | 🔄 EN PROCESO |
| **Detalle Saldo Apertura** | `FrmDetSaldoAp.frm` | \app\Features\DetalleSaldoApertura | Detalle saldos iniciales | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Niveles** | `FrmNiveles.frm` | \app\Features\Niveles | Gestión de niveles | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Seguimiento Cierre Apertura** | `FrmSeguimientoCierreApertura.frm` | \app\Features\SeguimientoCierreApertura | Seguimiento períodos | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |

### AUDITORÍA
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Auditoría General** | `FrmAuditoria.frm` | \app\Features\AuditoriaGeneral | Auditoría general | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Auditoría Libros Contables** | `FrmAuditLibContables.frm` | \app\Features\AuditoriaLibrosContables | Auditoría de libros | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Auditoría Cuentas Definidas** | `FrmRepAudCuentasDefinidas.frm` | \app\Features\AuditoriaCuentasDefinidas | Control integridad plan | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Seguimiento Documentos** | `FrmSeguimientoDoc.frm` | \app\Features\SeguimientoDocumentos | Seguimiento documentos | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Seguimiento Movimientos Documentos** | `FrmSeguimientoMovDoc.frm` | \app\Features\SeguimientoMovimientosDocumentos | **⚠️ NO EN MENÚ** - Vista invocada DESDE SeguimientoDocumentos para ver historial de cambios de un documento específico. Requiere parámetro obligatorio: idDoc. NO debe estar en menú de navegación | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Selección Seguimiento** | `FrmSelSeguimiento.frm` | \app\Features\SeleccionSeguimiento | Selector seguimiento (redundante con menú lateral) | 🚫 NO NECESARIO | 🟢 BAJA | ❌ NO |
| **Requisitos** | `FrmRequisitos.frm` | \app\Features\Requisitos | Requisitos del sistema | ✅ COMPLETADO | 🟢 BAJA | ✅ SÍ v4.0 - 100% 🏆 |

### HERRAMIENTAS
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Conversión Monedas** | `FrmConverMoneda.frm` | \app\Features\ConversionMonedas | Cambio de divisas | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Selección Ruta** | `FrmSelRuta.frm` | \app\Features\SeleccionRuta | Selector de ruta (redundante con menú lateral) | 🚫 NO NECESARIO | 🟢 BAJA | ❌ NO |
| **Datos DJ 1847** | `FrmDatosDJ1847.frm` | \app\Features\DatosDj1847 | Datos declaración jurada 1847 | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Glosas** | `FrmGlosas.frm` | \app\Features\Glosas | Gestión de glosas | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |
| **Actualización Glosas** | `FrmGlosasUpdate.frm` | \app\Features\ActualizacionGlosas | Actualización glosas | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Componentes** | `FrmComponente.frm` | \deadcode\Componentes | Gestión componentes (INNECESARIO) | 🗑️ DEAD-CODE | � BAJA | ❌ NO |
| **Compra Venta** | `FrmCompraVenta.frm` | \app\Features\CompraVenta | Gestión compra venta | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Cuenta** | `FrmCuenta.frm` | \app\Features\Cuenta | Gestión de cuentas | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |

### IMPRESIÓN
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Vista Previa Impresión** | `FrmPrintPreview.frm` | \app\Features\VistaPreviaImpresion | Vista previa documentos | ✅ COMPLETADO (Documentación) | 🟡 MEDIA | ❌ NO |
| **Impresión Cheques** | `FrmPrtCheque.frm` | \app\Features\ImpresionCheques | Impresión de cheques | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |

### DOCUMENTACIÓN
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Acerca del Sistema** | `FrmAbout.frm` | \app\Features\AcercaDelSistema | Información del software | ✅ COMPLETADO | 🟢 BAJA | ✅ SÍ v4.0 - 100% 🏆 |
| **Ayuda** | `FrmAyuda.frm` | \app\Features\Ayuda | Sistema de ayuda | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Información Ayuda** | `FrmInfoAyuda.frm` | \app\Features\InformacionAyuda | Información de ayuda | ✅ COMPLETADO | 🟢 BAJA | ✅ SÍ v4.0 - 100% 🏆 |
| **Ayuda Crédito 33bis** | `FrmHelpCred33bis.frm` | \app\Features\AyudaCredito33bis | Ayuda específica | ✅ COMPLETADO | 🟢 BAJA | ✅ SÍ v4.0 - 100% 🏆 |
| **Ayuda Importación Cartola** | `FrmHelpImpCartola.frm` | \app\Features\AyudaImportacionCartola | Ayuda importación | ✅ COMPLETADO | 🟢 BAJA | ✅ SÍ v4.0 - 100% 🏆 |
| **Información Vencimientos** | `FrmInfoVencim.frm` | \app\Features\InformacionVencimientos | Información vencimientos | ✅ COMPLETADO | 🟢 BAJA | ✅ SÍ v4.0 - 100% 🏆 |

### MANTENIMIENTO
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Respaldos** | `FrmBackup1.frm` | \app\Features\Respaldos | Generación respaldos | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 100% 🏆 |
| **Generar Backup** | `FrmGenBackup.frm` | \app\Features\GenerarBackup | Generación backup | ✅ COMPLETADO | 🔴 CRÍTICA | ✅ SÍ v4.0 - 100% 🏆 |
| **Respaldos VB50** | `FrmBackup.frm` | \app\Features\RespaldosVb50 | Generación respaldos | ✅ COMPLETADO | 🟡 MEDIA | ❌ NO |
| **Ayuda Backup** | `FrmHlpBackup.frm` | \app\Features\AyudaBackup | Ayuda para backup | ✅ COMPLETADO | 🟢 BAJA | ✅ SÍ v4.0 - 100% 🏆 |
| **Reporte de Problema** | `FrmRepError.frm` | \app\Features\ReporteProblema | Sistema reporte errores | ✅ COMPLETADO | 🟠 ALTA | ❌ NO |

### SISTEMA - UTILIDADES COMPARTIDAS
| Funcionalidad | Formularios VB6 | Feature .NET | Descripción | Estado Migración | Importancia | Auditado |
|---------------|-----------------|-------------|-------------|------------------|-------------|----------|
| **Desbloquear Sistema** | `FrmDesbloquear.frm` (Comun) | \app\Features\DesbloquearSistema | Utilitario de desbloqueo | 🚫 NO NECESARIO | 🟢 BAJA | ❌ NO |
| **Unlock Sistema** | `FrmUnlock.frm` | \app\Features\UnlockSistema | Utilitario de unlock alternativo | 🚫 NO NECESARIO | 🟢 BAJA | ❌ NO |
| **Registro Demo** | `FrmDemo.frm` | \app\Features\RegistrarDemo | Registro y licenciamiento | ❌ PENDIENTE | 🟡 MEDIA | ❌ NO |

---

## 📊 RESUMEN DE MIGRACIÓN

**Última actualización:** 6 de octubre de 2025

### Estado General
- **Total de Features:** 239
- **✅ Completadas:** 230 (96.2%)
- **🚫 No Necesarias:** 7 (2.9%)
- **❌ Pendientes:** 2 (0.8%)
- **📊 Resueltas (Completadas + No Necesarias):** 237 (99.2%)

### Features Pendientes (2)
| Feature | Folder | Formulario VB6 | Categoría |
|---------|--------|----------------|-----------|
| Licenciar Producto | LicenciarProducto | FrmEquiposAut.frm | GESTIÓN DE USUARIOS |
| Registro Demo | RegistroDemo | FrmDemo.frm | SISTEMA - UTILIDADES |

### Features No Necesarias (23)
| Feature | Folder | Formulario VB6 | Categoría | Razón |
|---------|--------|----------------|-----------|-------|
| Dashboard SQL Server | DashboardSQLServer | FrmMainSQLServer.frm | INICIO | Específico de SQL Server (no aplicable a SQLite) |
| Inicio de Aplicación | InicioAplicacion | FrmStart.frm | INICIO | Lógica de inicialización legacy |
| Cerrar Sesión | CerrarSesion | FrmIdUser.frm | INICIO | Autenticación legacy |
| Identificación Usuario | IdentificacionUsuario | FrmIdUsuario.frm | INICIO | Login de administrador legacy |
| Informe Analítico Avanzado | InformeAnaliticoAvanzado | FrmInfAnaliticoAdv.frm | ANÁLISIS Y CONSULTAS | Reemplazado por versiones Completo/Extendido |
| Configuración Hojas Timbraje | ConfiguracionHojasTimbraje | FrmConfigHojasTimbraje.frm | CONFIGURACIÓN DEL SISTEMA | Proceso físico obsoleto |
| Desbloquear Sistema | DesbloquearSistema | FrmDesbloquear.frm | SISTEMA - UTILIDADES | Utilitario legacy de debugging |
| Unlock Sistema | UnlockSistema | FrmUnlock.frm | SISTEMA - UTILIDADES | Utilitario legacy de debugging |
| **Selección Tipo** | SeleccionTipo | FrmSelCompTipo.frm | COMPROBANTES | **Redundante con menú lateral** |
| **Selección Libros Docs** | SeleccionLibrosDocs | FrmSelLibDocs.frm | DOCUMENTOS | **Redundante con menú lateral** |
| **Selección Importación OD** | SeleccionImportacionOd | FrmSelImpoOD.frm | DOCUMENTOS | **Redundante con menú lateral** |
| **Selección Libros** | SeleccionLibros | FrmSelLibros.frm | LIBROS CONTABLES | **Redundante con menú lateral** |
| **Selección Libro Caja** | SeleccionLibroCaja | FrmSelLibCaja.frm | LIBROS CONTABLES | **Redundante con menú lateral** |
| **Selección Libro 14ter** | SeleccionLibro14ter | FrmSelLib14ter.frm | LIBROS CONTABLES | **Redundante con menú lateral** |
| **Selección Balances** | SeleccionBalances | FrmSelBalances.frm | BALANCES Y ESTADOS | **Redundante con menú lateral** |
| **Selección Estados Resultado** | SeleccionEstadosResultado | FrmSelEstRes.frm | BALANCES Y ESTADOS | **Redundante con menú lateral** |
| **Selección Informes Analíticos** | SeleccionInformesAnaliticos | FrmSelInfAnalit.frm | ANÁLISIS Y CONSULTAS | **Redundante con menú lateral** |
| **Selección Reporte Activo Fijo** | SeleccionReporteActivoFijo | FrmSelRepActFijo.frm | ACTIVOS FIJOS | **Redundante con menú lateral** |
| **Selección 14D Pro Pyme** | Seleccion14DProPyme | FrmSel14DProPyme.frm | REPORTES TRIBUTARIOS | **Redundante con menú lateral** |
| **Selección Informes IFRS** | SeleccionInformesIfrs | FrmSelInfIFRS.frm | REPORTES IFRS | **Redundante con menú lateral** |
| **Selección por Nivel** | SeleccionPorNivel | FrmSelEmpresasNivelEmpresa.frm | GESTIÓN DE EMPRESAS | **Redundante con menú lateral** |
| **Selección para Traspaso** | SeleccionParaTraspaso | FrmSelEmpresasTras.frm | GESTIÓN DE EMPRESAS | **Redundante con menú lateral** |
| **Selección Seguimiento** | SeleccionSeguimiento | FrmSelSeguimiento.frm | AUDITORÍA | **Redundante con menú lateral** |
| **Selección Ruta** | SeleccionRuta | FrmSelRuta.frm | HERRAMIENTAS | **Redundante con menú lateral** |

### Resumen de Selectores Eliminados
Los 16 selectores marcados como "NO NECESARIO" eran pantallas de navegación modal heredadas de VB6. En la aplicación web moderna, todas estas funcionalidades están accesibles directamente desde el menú lateral persistente con búsqueda integrada (Ctrl+K), haciendo innecesaria esta capa adicional de navegación.

### Próximos Pasos
1. ✅ Completar las 2 features pendientes restantes (Licenciamiento)
2. 🔍 Realizar pruebas de integración en todas las features completadas
3. 📚 Documentar APIs y endpoints de cada feature
4. �️ Eliminar físicamente las 16 carpetas de features selectores (opcional)
