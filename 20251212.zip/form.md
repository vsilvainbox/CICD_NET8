# Propuesta de Estandarización para Interacciones Frontend-Backend

## 1. Objetivo

El objetivo es normalizar, estandarizar y unificar la forma en que el frontend accede al backend. Esto se logrará adoptando dos patrones de interacción claros y predecibles, eliminando las inconsistencias actuales del código y reduciendo la probabilidad de errores. La premisa fundamental es que **la experiencia de usuario final debe permanecer idéntica a la actual.**

## 2. Los Dos Patrones Estándar

Se definen dos patrones principales para cubrir todos los casos de uso del sistema.

---

### **Patrón A: Formularios de Datos (con `FormHandler`)**

Este es el patrón preferido para operaciones de **Creación y Edición (CRUD)** que involucran múltiples campos de entrada.

*   **Cuándo usarlo:** Al crear un nuevo registro o editar uno existente, típicamente dentro de una página completa o una ventana modal.
*   **Cómo funciona:** Se utiliza un `<form>` HTML estándar con el atributo `data-ajax="true"`. El `FormHandler` global (definido en `_Layout.cshtml`) se encarga automáticamente de:
    1.  Validar los campos del formulario (incluyendo validaciones remotas).
    2.  Mostrar un diálogo de confirmación (`SweetAlert`).
    3.  Enviar los datos vía AJAX sin recargar la página.
    4.  Manejar la respuesta y ejecutar un "callback" de éxito si se define.
*   **Preservación de la UX:** El atributo `data-on-success="miFuncionCallback"` es la clave. Permite ejecutar código JavaScript personalizado tras una operación exitosa, lo que nos da control total para replicar cualquier comportamiento actual, como cerrar un modal y refrescar una tabla de datos. Si no se especifica, el comportamiento por defecto es recargar la página.

#### **Ejemplo Canónico (extraído de `Sucursales/Views/Index.cshtml`)**

**Vista (`.cshtml`):** El desarrollador solo necesita escribir el HTML declarativo.

```html
<!-- Formulario para crear/editar una Sucursal dentro de un modal -->
<form id="frmSucursal"
      method="post"
      class="mt-4 space-y-4"
      data-ajax="true"
      data-confirm-title="¿Guardar sucursal?"
      data-on-success="Sucursales.onGuardado">
      
    <!-- Los Tag Helpers de ASP.NET Core generarán los 'action' y 'controller' -->
    @Html.AntiForgeryToken()
    <input type="hidden" name="IdSucursal" id="idSucursal" value="0">

    <!-- Campos del formulario (ej. Código, Descripción) -->
    <div>
        <label for="codigo">Código</label>
        <input type="text" name="Codigo" id="codigo" required>
        <span class="field-validation-valid" data-valmsg-for="Codigo"></span>
    </div>
    
    <div class="flex justify-end gap-2">
        <button type="button" onclick="Sucursales.cerrarModal()">Cancelar</button>
        <button type="submit">Guardar</button>
    </div>
</form>

<script>
    // El Namespace 'Sucursales' contiene los callbacks y funciones de UI
    const Sucursales = {
        // ... otras funciones ...

        // Callback que se ejecuta al tener éxito
        onGuardado: function(respuestaDeLaApi) {
            Sucursales.cerrarModal();
            location.reload(); // Recarga la página para mostrar los cambios
        },

        cerrarModal: function() {
            cerrarModal('modalSucursal'); // Llama a la función global de modales
        }
    };
</script>
```

**Controlador (C#):** El `Action` debe estar preparado para recibir los datos desde `[FromForm]`.
```csharp
[HttpPost]
public async Task<IActionResult> Save([FromForm] SucursalFormDto dto)
{
    // ... lógica para guardar o actualizar la sucursal ...
    return Json(new { success = true, message = "Guardado con éxito" });
}
```

---

### **Patrón B: Acciones Simples (con Botón y JS Explícito)**

Este es el patrón para acciones que **no requieren un formulario de entrada**, como "Eliminar por ID", "Importar desde una fuente externa", o ejecutar un proceso en el servidor.

*   **Cuándo usarlo:** Para botones que ejecutan una única acción.
*   **Cómo funciona:** Un botón (`<button>`) con un evento `onclick` llama a una función JavaScript específica. Esta función orquesta la interacción de forma explícita.
*   **Preservación de la UX:** Este patrón nos da control total sobre el flujo. Se usa `ErrorHandler.confirm()` para mostrar el **mismo diálogo de confirmación** que el `FormHandler`. La función de éxito (`onSuccess`) permite mostrar un **resumen detallado del resultado** (como en "Traer desde SII") o simplemente recargar la página, replicando exactamente el comportamiento deseado.

#### **Ejemplo Canónico (extraído de `Sucursales/Views/Index.cshtml`)**

**Vista (`.cshtml`):**
```html
<!-- Un botón simple que llama a una función JS dentro del namespace 'Sucursales' -->
<button onclick="Sucursales.traerDesdeSII()" title="Importar desde SII">
    <i class="fas fa-cloud-download-alt"></i> Traer desde SII
</button>

<script>
    const Sucursales = {
        // ... urls y otras propiedades ...
        
        async traerDesdeSII() {
            // 1. CONFIRMAR
            const confirmado = await ErrorHandler.confirm(
                '¿Importar desde SII?',
                'Se importarán las sucursales registradas en el SII.'
            );
            if (!confirmado) return;

            // 2. EJECUTAR
            const result = await Api.postJson(this.urls.importarSii, {});
            
            // 3. MOSTRAR RESULTADO
            if (result) {
                this.onImportadoSii(result);
            }
            // Nota: Si hay un error en la llamada, el helper 'Api' ya lo muestra automáticamente.
        },

        onImportadoSii(data) {
            // Muestra un popup de SweetAlert con el resumen detallado
            Swal.fire({
                title: 'Importación completada',
                html: `<div class="text-left">...Resumen detallado con los datos de 'data'...</div>`,
                icon: 'success'
            }).then(() => {
                // Solo recarga la página si se importó algo nuevo
                if (data.cantidadImportadas > 0) {
                    location.reload();
                }
            });
        }
    };
</script>
```

**Controlador (C#):**
El `Action` puede recibir parámetros desde la URL (`[FromQuery]`), ya que no hay un cuerpo de formulario.
```csharp
[HttpPost]
public async Task<ActionResult<ImportarSucursalesResultDto>> ImportarDesdeSii(
    [FromQuery] int empresaId, 
    [FromQuery] short ano)
{
    var resultado = await service.ImportarDesdeSiiAsync(empresaId, ano);
    return Ok(resultado);
}
```

## Resumen de Aplicación de Patrones

| Caso de Uso Identificado | Patrón a Aplicar |
| :--- | :--- |
| 1. Carga de Datos (GET) | **Helper `Api.get`** (con objeto de datos, no URL manual) |
| 2. Envío de Formularios (Crear/Editar) | **Patrón A: `FormHandler`** |
| 3. Acciones Simples (Botones) | **Patrón B: Acción Simple** |
| 4. Carga de Vistas Parciales (HTML) | **Helper `Api.getHtml`** |
| 5. Descarga de Archivos | **Patrón B: Acción Simple** (que llama a `Api.download*`) |
| 6. Validación en Tiempo Real | **Patrón A: `FormHandler`** (se integra automáticamente) |

---

## 5. Registro de Refactorización

Esta sección mantendrá un registro del progreso de la estandarización en las diferentes funcionalidades del sistema.

### 5.1 Features Originales del Registro

| Feature | Patrón a Aplicar | Estado | Notas |
| :--- | :--- | :--- | :--- |
| `CierreAnual` | `Api.get` | ✅ Completado | Se corrigió la llamada a `Api.get` para pasar parámetros correctamente. |
| `Sucursales` | Patrón A y B | ✅ Completado | Es el ejemplo canónico que define los patrones a seguir. |
| `GestionConciliacion` | Patrón B (Acción Simple) | ✅ Completado | Corregida para usar el patrón de botón de acción simple. |
| `HerramientasIntegracion` | Patrón B (Acción Simple) | ✅ Completado | Refactorizado `limpiarNewlines` para usar `ErrorHandler.confirm()`. |
| `ListadoDocumentos` | Patrón B (Acción Simple) | ✅ Completado | Refactorizado `recalcularSaldos` para usar `ErrorHandler.confirm()`. |
| `PlanCuentas` | Patrón A y B | ⬜️ Pendiente | Usa query strings para empresaId/ano en POST. Requiere cambios en backend para normalizar completamente. |
| `GestionCuotas` | Patrón B (Acción Simple) | ✅ Completado | Refactorizado confirmaciones de eliminación para usar `ErrorHandler.confirm()`. |

### 5.2 Features Corregidos - Violaciones confirm() nativo

Todos los usos de `confirm()` nativo de JavaScript fueron migrados a `ErrorHandler.confirm()`:

| Feature | Archivo | Función(es) | Estado |
| :--- | :--- | :--- | :--- |
| `ResumenIva` | Index.cshtml | `recalcularIva` | ✅ Completado |
| `ProporcionalidadIva` | Index.cshtml | `calcularProporcionalidad` | ✅ Completado |
| `MantenimientoRazonesFinancieras` | Index.cshtml | `eliminarRazonFinanciera` | ✅ Completado |
| `ImportarSucursales` | Index.cshtml | `importar` | ✅ Completado |
| `ImportarOtrosDocs` | Index.cshtml | `importar` | ✅ Completado |
| `ImportarOtrosDocsCompleta` | Index.cshtml | `importar` | ✅ Completado |
| `ImportarExportarLibros` | Index.cshtml | 4 funciones de importación | ✅ Completado |
| `ImportarF29` | Index.cshtml | `importar` | ✅ Completado |
| `ImportarCentrosCosto` | Index.cshtml | 3 funciones de importación | ✅ Completado |
| `ImportarActivoFijo` | Index.cshtml | `importar` | ✅ Completado |
| `DetalleCapitalSimple` | Index.cshtml | `eliminarRetiro` | ✅ Completado |

### 5.3 Features Corregidos - Violaciones Swal.fire con showCancelButton

Confirmaciones simples `Swal.fire({ showCancelButton: true })` migradas a `ErrorHandler.confirm()`:

| Feature | Archivo | Función(es) | Estado |
| :--- | :--- | :--- | :--- |
| `ListarComprobantes` | Index.cshtml | `eliminarComprobante`, `traspasar` | ✅ Completado |
| `ConsultaComprobantes` | Index.cshtml | `eliminarComprobante` | ✅ Completado |
| `UsuariosSistema` | Index.cshtml | `eliminarUsuario` | ✅ Completado |
| `InformacionFolios` | Index.cshtml | `limpiarDatos` | ✅ Completado |
| `TraspasoOdToOdf` | Index.cshtml | `traspasar` | ✅ Completado |
| `TiposDocumentos` | Index.cshtml | `eliminar`, `cancelarCambios` | ✅ Completado |
| `RevisarDetalleDocumentos` | Index.cshtml | `procesar` | ✅ Completado |
| `Monedas` | Index.cshtml | `eliminarMoneda` | ✅ Completado |
| `PerfilesPermisos` | Index.cshtml | `eliminarPerfil` | ✅ Completado |
| `ParametrosRazones` | Index.cshtml | `eliminarCuenta` | ✅ Completado |
| `MantenimientoMonedas` | Index.cshtml | `eliminarMoneda` | ✅ Completado |
| `Glosas` | Index.cshtml | `eliminarGlosa` | ✅ Completado |
| `GestionActivoFijo` | Index.cshtml | `deleteActivo`, `eliminarComponente` | ✅ Completado |
| `Grupos` | Index.cshtml | `eliminarGrupoDirecto` | ✅ Completado |
| `LibroCaja` | Index.cshtml | `eliminarRegistro`, `eliminarTodos` | ✅ Completado |
| `GestionDocumentos` | Index.cshtml | `buscarPorRut`, `imprimirCheque`, `volverAExportar` | ✅ Completado |
| `Respaldos` | Index.cshtml | `generarBackup` | ✅ Completado |
| `ImportarRemuneraciones` | Index.cshtml | `generarComprobante` | ✅ Completado |
| `ImportarSiiRetenciones` | Index.cshtml | `importar` | ✅ Completado |
| `GenerarBackup` | Index.cshtml | `confirmarBackup` | ✅ Completado |
| `Percepciones` | Index.cshtml | `deletePercepcion` | ✅ Completado |
| `PrivilegiosPorEmpresa` | Index.cshtml | `showConfirm` | ✅ Completado |
| `EliminarEmpresaAno` | Index.cshtml | `confirmarEliminacion` | ✅ Completado |
| `SaldoApertura` | Index.cshtml | `cancelarCambios` | ✅ Completado |
| `ImportarComprobantes` | Index.cshtml | `importar` | ✅ Completado |
| `ImportarDesdeLpRemu` | Index.cshtml | `importarSeleccionadas`, `importarTodas` | ✅ Completado |
| `ImportarAreasNegocio` | Index.cshtml | `importFile` | ✅ Completado |
| `ImportarDatosSii` | Index.cshtml | `ejecutarImportacion` | ✅ Completado |
| `ListadoActivoFijo` | Index.cshtml | `eliminar` | ✅ Completado |
| `ListadoEmpresas` | Index.cshtml | `eliminar` | ✅ Completado |
| `CopiarSincronizacion` | Index.cshtml | `copiarConfiguracion` | ✅ Completado |
| `CopiarPlanCuentas` | Index.cshtml | `copiar`, `eliminar` | ✅ Completado |
| `ConfiguracionPrincipal` | Index.cshtml | `guardarCambios` | ✅ Completado |
| `ConfiguracionPlanCuentas` | Index.cshtml | `guardar` | ✅ Completado |
| `ExportarF29` | Index.cshtml | `exportar` | ✅ Completado |
| `DetalleCapitalSimple` | Index.cshtml | `eliminar` | ✅ Completado |
| `ExportarDjAnual` | Index.cshtml | `exportar` | ✅ Completado |
| `LibrosImpresos` | Index.cshtml | `imprimir` | ✅ Completado |
| `LibroInventarioBalance` | Index.cshtml | `generar` | ✅ Completado |
| `LibroDiario` | Index.cshtml | `generar` | ✅ Completado |
| `DocumentosLibros` | Index.cshtml | `procesar` | ✅ Completado |
| `EntidadesRelacionadas` | Index.cshtml | `eliminar` | ✅ Completado |
| `ImportarFacturacion` | Index.cshtml | `importar` | ✅ Completado |
| `ImportarLibrosAuxiliares` | Index.cshtml | `importar` | ✅ Completado |
| `ImportarDesdeArchivo` | Index.cshtml | `importar` | ✅ Completado |
| `CuentasLibroVentas` | Index.cshtml | `cancelar` | ✅ Completado |
| `CuentasLibroCompras` | Index.cshtml | `cancelar` | ✅ Completado |
| `ConfigurarCodigosIfrs` | Index.cshtml | `eliminar` | ✅ Completado |
| `ConfiguracionPlanCuentas2019` | Index.cshtml | `copiar` | ✅ Completado |
| `ConfiguracionImpuestosAdicionales` | Index.cshtml | `copiar`, `eliminar` | ✅ Completado |
| `CuentasAjustesExtraContables` | Index.cshtml | `guardar`, `eliminar` | ✅ Completado |
| `CuentasAjustesRli` | Index.cshtml | `guardar`, `eliminar` | ✅ Completado |
| `DetalleSaldoApertura` | Index.cshtml | `eliminar` | ✅ Completado |
| `DetalleBaseImponible14D` | Index.cshtml | `eliminar` | ✅ Completado |
| `LibroRetenciones` | Index.cshtml | `centralizar`, `eliminar` | ✅ Completado |
| `CompraVenta` | Index.cshtml | `eliminar`, `centralizar` | ✅ Completado |
| `Comprobante` | Index.cshtml | `deleteById` | ✅ Completado |
| `ComponentesActivoFijo` | Index.cshtml | `sinDetComps`, `eliminar` | ✅ Completado |
| `FichaActivoFijo` | Index.cshtml | `cancelar`, `abrirComponentes` | ✅ Completado |
| `ValoresIndices` | Index.cshtml | `cambiosSinGuardar` | ✅ Completado |
| `ListarPorTipo` | Index.cshtml | `delete`, `recoverDefaults` | ✅ Completado |
| `ListadoPlanCuentas` | Index.cshtml | `guardarCambios` | ✅ Completado |
| `ImportarCartolasBancarias` | Index.cshtml, Lista.cshtml | `validar`, `limpiar`, `eliminar` | ✅ Completado |
| `ConfiguracionImpresionCheques` | Index.cshtml | `cambiarTipo`, `descartar` | ✅ Completado |
| `ConfiguracionActivoFijoIfrs` | Index.cshtml | `eliminarGrupo`, `eliminarComponente` | ✅ Completado |
| `ConfiguracionComprobanteActivoFijo` | Index.cshtml | `eliminarLinea`, `cerrar` | ✅ Completado |
| `ConfiguracionCorreccionComprobantes` | Index.cshtml | `aplicarResumido` | ✅ Completado |
| `GestionActivoFijo` | Componentes, Movimientos | `eliminar` | ✅ Completado |
| `ImportarActivoFijoArchivo` | Index.cshtml | `importar` | ✅ Completado |
| `LibroCaja` | _ConciliacionBancariaModal.cshtml | `ejecutarConciliacion` | ✅ Completado |
| `TiposDocumentos` | Index.cshtml | `cambiarTipoLibro` | ✅ Completado |
| `AreasNegocio` | Index.cshtml | `eliminarArea` | ✅ Completado |
| `CentrosCosto` | Index.cshtml | `eliminar`, `guardar` | ✅ Completado |
| `CentroCostoIndividual` | Index.cshtml | `cancelar` | ✅ Completado |
| `ConfiguracionFirmaInformes` | Index.cshtml | `deleteFirma` | ✅ Completado |
| `AuditoriaGeneral` | Index.cshtml | `eliminarComprobante` | ✅ Completado |
| `BalanceDesglosado` | Index.cshtml | `imprimirBalance` | ✅ Completado |
| `CapitalSimpleMini` | Index.cshtml | `agregarFila`, `eliminarDetalle` | ✅ Completado |
| `AsistenteImportacionPrimeraCategoria` | Index.cshtml | `saveAll`, `cancelAndClose` | ✅ Completado |
| `BaseImponible14DCompleta` | Index.cshtml | `showOnlyWithBalances`, `confirmarGuardar` | ✅ Completado |
| `EstadoSituacionFinancieraIfrs` | UnclassifiedAccounts.cshtml | `clasificarCuenta` | ✅ Completado |

### 5.4 Casos Especiales que NO Aplican

Los siguientes usos de `Swal.fire({ showCancelButton: true })` son **casos especiales legítimos** que NO deben convertirse a `ErrorHandler.confirm()` porque requieren funcionalidad adicional:

| Feature | Razón |
|---------|-------|
| `_Layout.cshtml` | Definición de FormHandler/ErrorHandler (no uso) |
| `Auth/Login.cshtml` | Definición local de ErrorHandler.confirm (no uso) |
| `SeguimientoCierreApertura` | Tiene `input: 'select'` para ordenar columnas |
| `ResumenLibrosAuxiliares` | Navegación con URL destino (ir a detalle) |
| `RespaldosVb50` | 2 opciones diferentes: "Copiar nombre" vs "Cerrar" |
| `ListadoPlanCuentas` | Tiene `input: 'number'` para edición inline |
| `ListarComprobantes` | Tiene `input`, `preConfirm` o `showDenyButton` |
| `LibroRetenciones` | Tiene `input: 'checkbox'` para aplicar retención |
| `ExportarF22` | 2 opciones: JSON vs MDB format |
| `ConsultaComprobantes` | Tiene `preConfirm` con validación |
| `ComponentesActivoFijo` | Tiene `showDenyButton` para 3 opciones |
| `Comprobante` | Tiene `input: 'select'` para cambiar estado |
| `CierreAnual` | Tiene `preConfirm` con checkboxes de confirmación |
| `BaseImponible14D` | Tiene HTML formateado complejo |
| `AsistentePpm` | Usa `result.dismiss` para 2 opciones diferentes |
| `AsistenteImportacionPrimeraCategoria` | Tiene `preConfirm` con validación |
| `AbrirCerrarMes` | Tiene HTML formateado con nombre de mes |

### 5.5 Resumen de Normalización

**Estado Final:**
- ✅ **Violaciones confirm() nativas corregidas:** 16/16 (100%)
- ✅ **Violaciones Swal.fire simples corregidas:** ~100+ features normalizados
- ✅ **Casos especiales identificados:** 29 instancias que requieren Swal.fire avanzado
- ✅ **Total de features conformes con form.md:** ~80+ features

### 5.6 Auditoría Completa de Patrones (Última verificación)

| Patrón Verificado | Estado | Notas |
|-------------------|--------|-------|
| `confirm()` nativo | ✅ 0 violaciones | Todos usan `ErrorHandler.confirm()` |
| `Swal.fire({ showCancelButton })` simples | ✅ 0 violaciones | Todos convertidos a `ErrorHandler.confirm()` |
| `fetch()` directo en features | ✅ 0 violaciones | Solo en `_Layout.cshtml` (definiciones) y vistas Print standalone |
| `$.ajax`, `$.get`, `$.post` | ✅ 0 violaciones | No existen |
| `axios` | ✅ 0 violaciones | No existe |
| `alert()` nativo | ✅ 0 violaciones | Solo fallbacks en `_Layout.cshtml` |
| `FormData` | ✅ Conforme | Se usa correctamente con `Api.post` o `Api.upload` |
| `Api.getHtml` para parciales | ✅ Conforme | Se usa correctamente donde aplica |
| `Api.download*` para archivos | ✅ Conforme | Se usa correctamente donde aplica |
| `data-ajax="true"` en forms | ✅ Conforme | Formularios AJAX usan FormHandler |

**Casos Especiales Válidos:**
- Vistas Print standalone (`BaseImponible/Print.cshtml`) - Sin layout, definen mini Api helpers
- Formularios de eliminación con `form.submit()` tradicional - Funcionan correctamente con confirmación previa
- 29 instancias de Swal.fire avanzado - Requieren `input`, `preConfirm`, `showDenyButton` o HTML complejo

*Leyenda de Estado: ✅ Completado, 🚧 En Progreso, ⬜️ Pendiente*

---

## 3. Estandarización de Binding en Formularios (Preferencia por @model)

Aunque el patrón de usar una variable local en la vista (`var formModel = ...`) junto con `[Bind(Prefix = "formModel")]` en el controlador es técnicamente válido en ASP.NET Core, se ha observado que puede generar problemas de binding (validaciones fallidas) en ciertos contextos, especialmente cuando la vista no tiene una directiva `@model` definida o el modelo de la vista difiere del modelo del formulario.

Para garantizar la consistencia y simplicidad del código, se establece el siguiente estándar:

### El Estándar

Preferir siempre el binding directo usando la directiva `@model` en la vista y recibiendo el objeto plano en el controlador.

#### 1. En la Vista (`.cshtml`)
Usar `@model` con el DTO del formulario.

**Recomendado:**
```csharp
@model App.Features.MiModulo.MiDto
// ...
<input asp-for="Nombre" />
```

#### 2. En el Controlador (`Controller.cs`)
Recibir el DTO directamente sin prefijos.

**Recomendado:**
```csharp
[HttpPost]
public IActionResult Save(MiDto dto)
```

### Módulos Candidatos a Estandarización

Se recomienda revisar y estandarizar los siguientes módulos para alinearlos con esta práctica:

1.  **MantenimientoUsuarios**
2.  **Monedas**
3.  **LibrosImpresos**
4.  **LibroRetenciones**
5.  **Glosas**
6.  **AreasNegocio**
