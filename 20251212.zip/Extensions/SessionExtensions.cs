using System.Text.Json;

namespace App.Extensions;

/// <summary>
/// Extensiones genéricas para ISession (serialización JSON).
/// Para datos de empresa/usuario, usar ClaimsExtensions o SessionHelper.
/// </summary>
public static class SessionExtensions
{
    /// <summary>
    /// Guarda un objeto en sesión serializado como JSON
    /// </summary>
    public static void SetObject<T>(this ISession session, string key, T value)
    {
        var json = JsonSerializer.Serialize(value);
        session.SetString(key, json);
    }

    /// <summary>
    /// Obtiene un objeto de la sesión deserializando desde JSON
    /// </summary>
    public static T? GetObject<T>(this ISession session, string key) where T : class
    {
        var json = session.GetString(key);
        if (string.IsNullOrEmpty(json))
            return null;

        return JsonSerializer.Deserialize<T>(json);
    }
}
