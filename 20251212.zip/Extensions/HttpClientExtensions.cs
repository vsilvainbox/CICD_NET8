using System.Text.Json;
using App.Exceptions;
using App.Models;

namespace App.Extensions;

/// <summary>
/// Extension methods para HttpClient con manejo de errores y deserialización automática
/// </summary>
public static class HttpClientExtensions
{
    /// <summary>
    /// Procesa errores de API y lanza la excepción apropiada
    /// - HTTP 4xx con "errors" -> BusinessException (validación de negocio)
    /// - HTTP 5xx -> HttpRequestException (error de sistema)
    /// </summary>
    private static void ThrowApiException(System.Net.HttpStatusCode statusCode, string errorContent)
    {
        // HTTP 4xx = error de validación (BusinessException)
        if ((int)statusCode >= 400 && (int)statusCode < 500)
        {
            try
            {
                using var doc = JsonDocument.Parse(errorContent);
                var root = doc.RootElement;

                var errors = new List<string>();

                // Buscar campo "errors" (array de strings)
                if (root.TryGetProperty("errors", out var errorsElement) &&
                    errorsElement.ValueKind == JsonValueKind.Array)
                {
                    foreach (var error in errorsElement.EnumerateArray())
                    {
                        errors.Add(error.GetString() ?? "Error desconocido");
                    }
                }
                // Fallback: buscar campo "message"
                else if (root.TryGetProperty("message", out var messageElement))
                {
                    errors.Add(messageElement.GetString() ?? "Error desconocido");
                }

                if (errors.Count > 0)
                {
                    throw new BusinessException(errors);
                }
            }
            catch (BusinessException)
            {
                throw;
            }
            catch
            {
                // Si no se puede parsear, lanzar BusinessException genérica
                throw new BusinessException("Error de validación");
            }
        }

        // HTTP 5xx = error de sistema
        throw new HttpRequestException(
            $"API returned {statusCode}: {errorContent}",
            null,
            statusCode
        );
    }

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    /// <summary>
    /// Valida que el contenido sea JSON válido antes de intentar parsearlo.
    /// Lanza BusinessException con mensaje claro si recibe HTML u otro contenido.
    /// </summary>
    private static void ValidateJsonContent(string content, string requestUri)
    {
        if (string.IsNullOrWhiteSpace(content))
            return;

        var trimmed = content.TrimStart();
        
        // Si comienza con '<', es HTML (página de error, login, etc.)
        if (trimmed.StartsWith('<'))
        {
            // Intentar extraer mensaje de error del HTML
            var errorMsg = "La API devolvió una respuesta HTML en lugar de JSON";
            
            // Buscar si es una página de error conocida
            if (trimmed.Contains("<!DOCTYPE", StringComparison.OrdinalIgnoreCase) ||
                trimmed.Contains("<html", StringComparison.OrdinalIgnoreCase))
            {
                if (trimmed.Contains("login", StringComparison.OrdinalIgnoreCase))
                    errorMsg = "Sesión expirada o no autenticado en la API externa";
                else if (trimmed.Contains("error", StringComparison.OrdinalIgnoreCase) ||
                         trimmed.Contains("500", StringComparison.OrdinalIgnoreCase))
                    errorMsg = "La API externa devolvió una página de error";
                else if (trimmed.Contains("404", StringComparison.OrdinalIgnoreCase) ||
                         trimmed.Contains("not found", StringComparison.OrdinalIgnoreCase))
                    errorMsg = "El endpoint de la API no fue encontrado";
            }
            
            throw new BusinessException($"{errorMsg}. URL: {requestUri}");
        }
    }

    /// <summary>
    /// GET con deserialización automática y manejo de errores
    /// Soporta tanto ApiResponse{T} como respuestas directas (legacy)
    /// </summary>
    public static async Task<T> GetFromApiAsync<T>(this HttpClient client, string requestUri)
    {
        var request = new HttpRequestMessage(HttpMethod.Get, requestUri);
        request.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        var response = await client.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            ThrowApiException(response.StatusCode, errorContent);
        }

        var content = await response.Content.ReadAsStringAsync();

        // Manejar contenido vacío
        if (string.IsNullOrWhiteSpace(content))
        {
            return default!;
        }

        // Validar que sea JSON antes de parsear
        ValidateJsonContent(content, requestUri);

        // Detectar si es ApiResponse (tiene campo "success")
        using var doc = JsonDocument.Parse(content);
        var root = doc.RootElement;

        // Si es un array, deserializar directamente (no es ApiResponse)
        if (root.ValueKind == JsonValueKind.Array)
        {
            return JsonSerializer.Deserialize<T>(content, JsonOptions) ?? default!;
        }

        // Si es un string JSON puro y T es string, extraer el valor directamente
        if (root.ValueKind == JsonValueKind.String && typeof(T) == typeof(string))
        {
            return (T)(object)root.GetString()!;
        }

        // Si es un booleano JSON puro y T es bool, extraer el valor directamente
        if ((root.ValueKind == JsonValueKind.True || root.ValueKind == JsonValueKind.False) && typeof(T) == typeof(bool))
        {
            return (T)(object)root.GetBoolean();
        }

        // Si es un número JSON puro y T es un tipo numérico, extraer el valor directamente
        if (root.ValueKind == JsonValueKind.Number)
        {
            if (typeof(T) == typeof(int)) return (T)(object)root.GetInt32();
            if (typeof(T) == typeof(long)) return (T)(object)root.GetInt64();
            if (typeof(T) == typeof(double)) return (T)(object)root.GetDouble();
            if (typeof(T) == typeof(decimal)) return (T)(object)root.GetDecimal();
        }

        // Si es un objeto y tiene propiedad "success", es ApiResponse
        if (root.ValueKind == JsonValueKind.Object && root.TryGetProperty("success", out var successProp))
        {
            var apiResponse = JsonSerializer.Deserialize<ApiResponse<T>>(content, JsonOptions);
            if (apiResponse?.Success == true)
            {
                return apiResponse.Data ?? default!;
            }
            // Si success es false, lanzar BusinessException
            if (apiResponse?.Errors?.Count > 0)
            {
                throw new BusinessException(apiResponse.Errors);
            }
            // Si success es false pero sin errores, retornar default
            return default!;
        }

        // No es ApiResponse, deserializar directamente como T (legacy)
        return JsonSerializer.Deserialize<T>(content, JsonOptions) ?? default!;
    }

    /// <summary>
    /// POST con deserialización automática y manejo de errores
    /// Soporta tanto ApiResponse{T} como respuestas directas (legacy)
    /// </summary>
    public static async Task<TResponse> PostToApiAsync<TRequest, TResponse>(
        this HttpClient client,
        string requestUri,
        TRequest data)
    {
        var json = JsonSerializer.Serialize(data);
        var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

        var request = new HttpRequestMessage(HttpMethod.Post, requestUri) { Content = content };
        request.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        var response = await client.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            ThrowApiException(response.StatusCode, errorContent);
        }

        var responseContent = await response.Content.ReadAsStringAsync();

        // Manejar contenido vacío (ej: API devuelve Ok() sin body)
        if (string.IsNullOrWhiteSpace(responseContent))
        {
            return default!;
        }

        // Validar que sea JSON antes de parsear
        ValidateJsonContent(responseContent, requestUri);

        // Detectar si es ApiResponse (tiene campo "success")
        using var doc = JsonDocument.Parse(responseContent);
        var root = doc.RootElement;

        if (root.TryGetProperty("success", out _))
        {
            var apiResponse = JsonSerializer.Deserialize<ApiResponse<TResponse>>(responseContent, JsonOptions);
            if (apiResponse?.Success == true)
            {
                return apiResponse.Data ?? throw new InvalidOperationException("ApiResponse.Data es null");
            }
            if (apiResponse?.Errors?.Count > 0)
            {
                throw new BusinessException(apiResponse.Errors);
            }
            throw new InvalidOperationException("ApiResponse sin datos ni errores");
        }

        // No es ApiResponse, deserializar directamente (legacy)
        return JsonSerializer.Deserialize<TResponse>(responseContent, JsonOptions)
            ?? throw new InvalidOperationException("Deserialización devolvió null");
    }

    /// <summary>
    /// POST sin respuesta (para endpoints que devuelven 204 No Content)
    /// </summary>
    public static async Task PostToApiAsync<TRequest>(
        this HttpClient client,
        string requestUri,
        TRequest data)
    {
        var json = JsonSerializer.Serialize(data);
        var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

        var request = new HttpRequestMessage(HttpMethod.Post, requestUri) { Content = content };
        request.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        var response = await client.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            ThrowApiException(response.StatusCode, errorContent);
        }
    }

    /// <summary>
    /// PUT con deserialización automática y manejo de errores
    /// </summary>
    public static async Task<TResponse> PutToApiAsync<TRequest, TResponse>(
        this HttpClient client,
        string requestUri,
        TRequest data)
    {
        var json = JsonSerializer.Serialize(data);
        var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

        var request = new HttpRequestMessage(HttpMethod.Put, requestUri) { Content = content };
        request.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        var response = await client.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            ThrowApiException(response.StatusCode, errorContent);
        }

        var responseContent = await response.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<TResponse>(responseContent, new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        }) ?? throw new InvalidOperationException("Deserialización devolvió null");
    }

    /// <summary>
    /// PUT sin respuesta - solo ejecuta y lanza excepción si falla
    /// </summary>
    public static async Task PutToApiAsync<TRequest>(
        this HttpClient client,
        string requestUri,
        TRequest data)
    {
        var json = JsonSerializer.Serialize(data);
        var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

        var request = new HttpRequestMessage(HttpMethod.Put, requestUri) { Content = content };
        request.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        var response = await client.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            ThrowApiException(response.StatusCode, errorContent);
        }
    }

    /// <summary>
    /// DELETE con manejo de errores
    /// </summary>
    public static async Task DeleteFromApiAsync(this HttpClient client, string requestUri)
    {
        var request = new HttpRequestMessage(HttpMethod.Delete, requestUri);
        request.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        var response = await client.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            ThrowApiException(response.StatusCode, errorContent);
        }
    }

    /// <summary>
    /// DELETE con body y deserialización de respuesta
    /// Útil para endpoints DELETE que requieren body (como EliminarDocumento)
    /// </summary>
    public static async Task<TResponse> DeleteToApiAsync<TRequest, TResponse>(
        this HttpClient client,
        string requestUri,
        TRequest data)
    {
        var json = JsonSerializer.Serialize(data);
        var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

        var request = new HttpRequestMessage(HttpMethod.Delete, requestUri) { Content = content };
        request.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        var response = await client.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            ThrowApiException(response.StatusCode, errorContent);
        }

        var responseContent = await response.Content.ReadAsStringAsync();

        // Manejar contenido vacío (ej: API devuelve Ok() sin body)
        if (string.IsNullOrWhiteSpace(responseContent))
        {
            return default!;
        }

        // Validar que sea JSON antes de parsear
        ValidateJsonContent(responseContent, requestUri);

        // Detectar si es ApiResponse (tiene campo "success")
        using var doc = JsonDocument.Parse(responseContent);
        var root = doc.RootElement;

        if (root.TryGetProperty("success", out _))
        {
            var apiResponse = JsonSerializer.Deserialize<ApiResponse<TResponse>>(responseContent, JsonOptions);
            if (apiResponse?.Success == true)
            {
                return apiResponse.Data ?? throw new InvalidOperationException("ApiResponse.Data es null");
            }
            if (apiResponse?.Errors?.Count > 0)
            {
                throw new BusinessException(apiResponse.Errors);
            }
            throw new InvalidOperationException("ApiResponse sin datos ni errores");
        }

        // No es ApiResponse, deserializar directamente (legacy)
        return JsonSerializer.Deserialize<TResponse>(responseContent, JsonOptions)
            ?? throw new InvalidOperationException("Deserialización devolvió null");
    }

    /// <summary>
    /// Método proxy - reenvía la respuesta tal cual (para JavaScript)
    /// Útil cuando el frontend necesita manejar el status code
    /// </summary>
    public static async Task<(int StatusCode, string Content)> ProxyRequestAsync(
        this HttpClient client,
        string requestUri,
        object? data = null,
        HttpMethod? method = null)
    {
        method ??= HttpMethod.Get;

        var request = new HttpRequestMessage(method, requestUri);
        request.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

        if (data != null && (method == HttpMethod.Post || method == HttpMethod.Put))
        {
            var json = JsonSerializer.Serialize(data);
            request.Content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
        }

        var response = await client.SendAsync(request);
        var content = await response.Content.ReadAsStringAsync();

        return ((int)response.StatusCode, content);
    }

    /// <summary>
    /// Sobrecarga específica para JsonElement - reenvía la respuesta tal cual
    /// </summary>
    public static async Task<(int StatusCode, string Content)> ProxyRequestAsync(
        this HttpClient client,
        string requestUri,
        System.Text.Json.JsonElement data,
        HttpMethod? method = null)
    {
        method ??= HttpMethod.Get;

        var request = new HttpRequestMessage(method, requestUri);
        request.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

        if (method == HttpMethod.Post || method == HttpMethod.Put)
        {
            // JsonElement ya está en formato JSON, usarlo directamente
            var json = data.GetRawText();
            request.Content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
        }

        var response = await client.SendAsync(request);
        var content = await response.Content.ReadAsStringAsync();

        return ((int)response.StatusCode, content);
    }

    /// <summary>
    /// Descarga de archivos (Excel, PDF, etc.)
    /// </summary>
    public static async Task<(byte[] FileBytes, string ContentType)> DownloadFileAsync(
        this HttpClient client,
        string requestUri,
        HttpMethod method,
        object? data = null)
    {
        var (fileBytes, contentType, _) = await client.DownloadFileWithNameAsync(requestUri, method, data);
        return (fileBytes, contentType);
    }

    /// <summary>
    /// Descarga de archivos con nombre del archivo (Excel, PDF, etc.)
    /// Retorna el nombre del archivo desde Content-Disposition header
    /// </summary>
    public static async Task<(byte[] FileBytes, string ContentType, string? FileName)> DownloadFileWithNameAsync(
        this HttpClient client,
        string requestUri,
        HttpMethod method,
        object? data = null,
        string? defaultFileName = null)
    {
        var request = new HttpRequestMessage(method, requestUri);
        request.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

        if (data != null && (method == HttpMethod.Post || method == HttpMethod.Put))
        {
            var json = JsonSerializer.Serialize(data);
            request.Content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
        }

        var response = await client.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            ThrowApiException(response.StatusCode, errorContent);
        }

        var fileBytes = await response.Content.ReadAsByteArrayAsync();
        var contentType = response.Content.Headers.ContentType?.ToString()
            ?? "application/octet-stream";
        var fileName = response.Content.Headers.ContentDisposition?.FileName?.Trim('"')
            ?? defaultFileName;

        return (fileBytes, contentType, fileName);
    }
}
