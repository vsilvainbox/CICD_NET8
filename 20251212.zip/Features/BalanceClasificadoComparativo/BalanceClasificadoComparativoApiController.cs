using Microsoft.AspNetCore.Mvc;

namespace App.Features.BalanceClasificadoComparativo;

[ApiController]
[Route("[controller]/[action]")]
public class BalanceClasificadoComparativoApiController(
    IBalanceClasificadoComparativoService service,
    ILogger<BalanceClasificadoComparativoApiController> logger) : ControllerBase
{
    /// <summary>
    /// Genera el Balance Clasificado Comparativo o Estado de Resultado Comparativo
    /// POST /api/BalanceClasificadoComparativo/generar
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<BalanceClasificadoComparativoResponseDto>> Generar(
        [FromBody] BalanceClasificadoComparativoRequestDto request,
        CancellationToken cancellationToken = default)
    {
        logger.LogInformation(
            "Generando Balance Clasificado Comparativo para Empresa {EmpresaId}, Modo: {Modo}",
            request.EmpresaId,
            request.Modo);

        var resultado = await service.GenerarAsync(request, cancellationToken);
        return Ok(resultado);
    }

    /// <summary>
    /// Obtiene las opciones de filtros (niveles, áreas, centros de costo)
    /// GET /api/BalanceClasificadoComparativo/opciones
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<BalanceClasificadoComparativoOpcionesDto>> GetOpciones(
        [FromQuery] int empresaId,
        CancellationToken cancellationToken = default)
    {
        logger.LogInformation("Obteniendo opciones de filtros para Empresa {EmpresaId}", empresaId);

        var opciones = await service.ObtenerOpcionesAsync(empresaId, cancellationToken);
        return Ok(opciones);
    }

    /// <summary>
    /// Exporta el Balance Clasificado Comparativo a Excel (Form POST - R20)
    /// POST /BalanceClasificadoComparativoApi/ExportarExcel
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> ExportarExcel(
        [FromForm] BalanceClasificadoComparativoExportRequestDto request,
        CancellationToken cancellationToken = default)
    {
        logger.LogInformation("Exportando Balance a Excel para Empresa {EmpresaId}", request.EmpresaId);

        var resultado = await service.ExportarAsync(request, cancellationToken);
        var fileName = service.GenerarNombreArchivoExportacion(request.NombreArchivo, request.EmpresaId, "xlsx");

        return File(resultado.Content, resultado.ContentType, fileName);
    }

    /// <summary>
    /// Genera vista previa para impresión (PDF)
    /// POST /api/BalanceClasificadoComparativo/preview
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> GenerarPreview(
        [FromBody] BalanceClasificadoComparativoPreviewRequestDto request,
        CancellationToken cancellationToken = default)
    {
        logger.LogInformation("Generando preview para Empresa {EmpresaId}", request.EmpresaId);

        var resultado = await service.GenerarPreviewAsync(request, cancellationToken);

        return File(
            resultado.Content,
            resultado.ContentType,
            resultado.FileName);
    }

    /// <summary>
    /// Registra una impresión oficial del balance
    /// POST /api/BalanceClasificadoComparativo/registrar-impresion
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> RegistrarImpresion(
        [FromBody] BalanceClasificadoComparativoRegistroImpresionRequestDto request,
        CancellationToken cancellationToken = default)
    {
        logger.LogInformation(
            "Registrando impresión oficial para Empresa {EmpresaId}, Libro {LibroOficialCodigo}",
            request.EmpresaId,
            request.LibroOficialCodigo);

        await service.RegistrarImpresionAsync(request, cancellationToken);
        return Ok();
    }

    /// <summary>
    /// Verifica si existe un registro de impresión oficial previo
    /// GET /api/BalanceClasificadoComparativo/verificar-impresion
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<BalanceClasificadoComparativoRegistroImpresionDto?>> VerificarImpresion(
        [FromQuery] int empresaId,
        [FromQuery] int libroOficialCodigo,
        [FromQuery] DateTime fechaDesde,
        [FromQuery] DateTime fechaHasta,
        [FromQuery] BalanceClasificadoComparativoMode modo,
        CancellationToken cancellationToken = default)
    {
        logger.LogInformation(
            "Verificando impresión previa para Empresa {EmpresaId}, Libro {LibroOficialCodigo}",
            empresaId,
            libroOficialCodigo);

        var registro = await service.VerificarImpresionPreviaAsync(empresaId, libroOficialCodigo, fechaDesde, fechaHasta, modo, cancellationToken);

        return Ok(registro);
    }

    /// <summary>
    /// Obtiene fechas por defecto para el periodo comparativo
    /// GET /api/BalanceClasificadoComparativo/fechas-default
    /// </summary>
    [HttpGet]
    public async Task<ActionResult> GetFechasDefault(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        CancellationToken cancellationToken = default)
    {
        logger.LogInformation("Obteniendo fechas por defecto para Empresa {EmpresaId}, año {Ano}", empresaId, ano);

        var fechas = await service.GetFechasDefaultAsync(empresaId, ano, cancellationToken);
        return Ok(fechas);
    }
}