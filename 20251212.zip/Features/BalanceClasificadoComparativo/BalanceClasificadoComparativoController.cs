using Microsoft.AspNetCore.Mvc;
using App.Helpers;

namespace App.Features.BalanceClasificadoComparativo;

public class BalanceClasificadoComparativoController(
    ILogger<BalanceClasificadoComparativoController> logger) : Controller
{
    /// <summary>
    /// Vista principal del Balance Clasificado Comparativo
    /// GET /BalanceClasificadoComparativo
    /// </summary>
    [HttpGet]
    public IActionResult Index(
        [FromQuery] BalanceClasificadoComparativoMode modo = BalanceClasificadoComparativoMode.BalanceClasificado)
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder al Balance Clasificado Comparativo";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        var empresaId = SessionHelper.EmpresaId;
        var ano = (short)SessionHelper.Ano;

        logger.LogInformation(
            "Balance Clasificado Comparativo: Index called with empresaId: {EmpresaId}, año: {Ano}, modo: {Modo}",
            empresaId,
            ano,
            modo);

        var viewModel = new BalanceClasificadoComparativoViewModel
        {
            EmpresaId = empresaId,
            Ano = ano,
            Modo = modo,
            WindowTitle = GetWindowTitle(modo, empresaId, ano)
        };

        return View(viewModel);
    }

    /// <summary>
    /// Vista del Balance Clasificado (Activo/Pasivo/Patrimonio)
    /// GET /BalanceClasificadoComparativo/balance
    /// </summary>
    [HttpGet]
    public IActionResult BalanceClasificado()
    {
        var empresaId = SessionHelper.EmpresaId;
        var ano = (short)SessionHelper.Ano;

        logger.LogInformation("Opening Balance Clasificado view");

        var viewModel = new BalanceClasificadoComparativoViewModel
        {
            EmpresaId = empresaId,
            Ano = ano,
            Modo = BalanceClasificadoComparativoMode.BalanceClasificado,
            WindowTitle = GetWindowTitle(BalanceClasificadoComparativoMode.BalanceClasificado, empresaId, ano)
        };

        return View("Index", viewModel);
    }

    /// <summary>
    /// Vista del Estado de Resultado Comparativo
    /// GET /BalanceClasificadoComparativo/estado-resultado
    /// </summary>
    [HttpGet]
    public IActionResult EstadoResultado()
    {
        var empresaId = SessionHelper.EmpresaId;
        var ano = (short)SessionHelper.Ano;

        logger.LogInformation("Opening Estado de Resultado view");

        var viewModel = new BalanceClasificadoComparativoViewModel
        {
            EmpresaId = empresaId,
            Ano = ano,
            Modo = BalanceClasificadoComparativoMode.EstadoResultado,
            WindowTitle = GetWindowTitle(BalanceClasificadoComparativoMode.EstadoResultado, empresaId, ano)
        };

        return View("Index", viewModel);
    }

    private string GetWindowTitle(BalanceClasificadoComparativoMode modo, int empresaId, short ano)
    {
        var tipoBalance = modo == BalanceClasificadoComparativoMode.BalanceClasificado
            ? "Balance Clasificado Comparativo"
            : "Estado de Resultado Comparativo";

        return $"{tipoBalance} - Empresa {empresaId} - año {ano}";
    }
}

/// <summary>
/// ViewModel para la vista del Balance Clasificado Comparativo
/// </summary>
public class BalanceClasificadoComparativoViewModel
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public BalanceClasificadoComparativoMode Modo { get; set; }
    public string WindowTitle { get; set; } = string.Empty;
}