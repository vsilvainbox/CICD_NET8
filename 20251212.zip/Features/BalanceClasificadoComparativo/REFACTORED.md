# ✅ Feature Refactorizada

**Fecha:** 2025-12-07  
**Guía aplicada:** refactor.md  
**Feature:** BalanceClasificadoComparativo

## Resumen de Cambios

Esta refactorización corrige la violación R20 pendiente, eliminando el uso de `fetch` manual para la descarga de archivos Excel.

## Violaciones Detectadas y Corregidas

### R20: fetch manual → Form POST (1 corrección)

**Archivo modificado:** `Views/Index.cshtml`

**Cambio realizado:**

Se eliminó el `fetch` manual en la función `exportarExcel()` y se reemplazó por un Form POST directo.

```javascript
// ❌ ANTES - fetch manual con blob (violación R20)
async function exportarExcel() {
    const request = { ... };
    
    const response = await fetch(URL_ENDPOINTS.exportarExcel, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(request)
    });
    
    const blob = await response.blob();
    // ... descarga manual del blob
}

// ✅ DESPUÉS - Form POST directo (R20 cumplida)
function exportarExcel() {
    // Llenar el formulario oculto con los valores actuales
    $('#export_EmpresaId').val(empresaId);
    $('#export_FechaDesdeActual').val($('#FechaDesdeActual').val());
    // ... otros campos
    
    // Enviar el formulario (el navegador manejará la descarga)
    $('#exportExcelForm').submit();
}
```

**Formulario oculto agregado:**
```html
<!-- R20: Form POST oculto para exportar Excel (apunta directamente a ApiController) -->
<form id="exportExcelForm" asp-action="ExportarExcel" asp-controller="BalanceClasificadoComparativoApi" method="post" style="display: none;">
    <input type="hidden" name="EmpresaId" id="export_EmpresaId" />
    <input type="hidden" name="AnoActual" id="export_AnoActual" />
    <input type="hidden" name="FechaDesdeActual" id="export_FechaDesdeActual" />
    <!-- ... otros campos -->
</form>
```

### ApiController: [FromBody] → [FromForm]

**Archivo modificado:** `BalanceClasificadoComparativoApiController.cs`

**Cambio realizado:**

Se modificó el endpoint `ExportarExcel` para aceptar `[FromForm]` en lugar de `[FromBody]`, permitiendo el uso de Form POST directo desde la vista.

```csharp
// ❌ ANTES
[HttpPost]
public async Task<IActionResult> ExportarExcel(
    [FromBody] BalanceClasificadoComparativoExportRequestDto request,
    CancellationToken cancellationToken = default)

// ✅ DESPUÉS
[HttpPost]
public async Task<IActionResult> ExportarExcel(
    [FromForm] BalanceClasificadoComparativoExportRequestDto request,
    CancellationToken cancellationToken = default)
```

## Reglas Verificadas

### Vista
- [x] R04 - URLs con @Url.Action
- [x] R19 - JavaScript llama a ApiController directo
- [x] **R20 - SOLO Form POST o Api.* (fetch manual eliminado)** ✅

### ApiController
- [x] R02 - Sin try-catch
- [x] R06 - No duplica endpoints

## Archivos Modificados

1. **Views/Index.cshtml**
   - Agregado formulario oculto `exportExcelForm` con campos para exportación
   - Función `exportarExcel()` modificada: `async function` → `function` (ya no usa await)
   - Eliminado uso de `fetch` manual con blob
   - Eliminada URL `exportarExcel` del objeto `URL_ENDPOINTS` (ya no es necesaria)

2. **BalanceClasificadoComparativoApiController.cs**
   - Endpoint `ExportarExcel`: `[FromBody]` → `[FromForm]`
   - Comentario actualizado en documentación del endpoint

## Verificación

```powershell
# R20: No debe encontrar fetch manual
Select-String -Path "Features/BalanceClasificadoComparativo/Views/*.cshtml" -Pattern "await\s+fetch\("
# Resultado esperado: 0 coincidencias
```

## Notas Técnicas

### Por qué Form POST en lugar de fetch para descargas

1. **Cumple R20**: La regla prohíbe explícitamente `fetch` manual
2. **Descarga nativa**: El navegador maneja automáticamente la descarga del archivo
3. **Sin procesamiento JavaScript**: No requiere convertir blob, crear URLs temporales, etc.
4. **Mejor manejo de errores**: Si hay error, el servidor puede redirigir o mostrar página de error

### Compatibilidad del DTO

El DTO `BalanceClasificadoComparativoExportRequestDto` ya tenía propiedades públicas con getters/setters, por lo que funciona tanto con `[FromBody]` (JSON) como con `[FromForm]` (form-urlencoded).

## Resultado Final

- **Violaciones R20:** 0 (corregida 1)
- **fetch manual eliminados:** 1
- **Form POST agregados:** 1

La feature ahora cumple completamente con la regla R20.