using Microsoft.AspNetCore.Mvc;

namespace App.Features.BalanceEjecutivoIfrs;

/// <summary>
/// API Controller para Balance Ejecutivo IFRS.
/// Proporciona endpoints REST para generar y validar balances ejecutivos IFRS.
/// </summary>
[ApiController]
[Route("[controller]/[action]")]
public class BalanceEjecutivoIfrsApiController(
    IBalanceEjecutivoIfrsService service,
    ILogger<BalanceEjecutivoIfrsApiController> logger) : ControllerBase
{
    /// <summary>
    /// Genera el Balance Ejecutivo IFRS.
    /// </summary>
    /// <param name="request">ParÃ¡metros de generaciÃ³n</param>
    /// <returns>Balance ejecutivo con secciones de Activos, Pasivos y Patrimonio</returns>
    [HttpPost]
    [ProducesResponseType(typeof(BalanceEjecutivoIfrsResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<ActionResult<BalanceEjecutivoIfrsResponseDto>> Generar(
        [FromBody] BalanceEjecutivoIfrsRequestDto request)
    {
        var resultado = await service.GenerarAsync(request);
        return Ok(resultado);
    }

    /// <summary>
    /// Valida que el plan de cuentas tenga cÃ³digos IFRS configurados.
    /// </summary>
    /// <returns>Resultado de validaciÃ³n con nombre del plan</returns>
    [HttpGet]
    [ProducesResponseType(typeof(object), StatusCodes.Status200OK)]
    public async Task<ActionResult> ValidarPlanCuentas()
    {
        var (esValido, planActual) = await service.ValidarPlanCuentasAsync();

        return Ok(new
        {
            esValido,
            planActual,
            mensaje = esValido
                ? $"Plan de cuentas IFRS configurado correctamente: {planActual}"
                : "No se encontró un plan de cuentas con códigos IFRS configurados"
        });
    }

    /// <summary>
    /// Verifica si existen cuentas sin clasificaciÃ³n IFRS.
    /// </summary>
    /// <param name="fechaHasta">Fecha hasta la cual verificar (formato: yyyy-MM-dd)</param>
    /// <returns>Indicador de existencia de cuentas sin clasificaciÃ³n</returns>
    [HttpGet]
    [ProducesResponseType(typeof(object), StatusCodes.Status200OK)]
    public async Task<ActionResult> ValidarClasificacion([FromQuery] DateTime fechaHasta)
    {
        var existenSinClasificacion = await service.ExistenCuentasSinClasificacionIfrsAsync(fechaHasta);

        return Ok(new
        {
            existenSinClasificacion,
            mensaje = existenSinClasificacion
                ? "Existen cuentas con movimientos sin clasificación IFRS. Revise el plan de cuentas."
                : "Todas las cuentas con movimientos tienen clasificación IFRS"
        });
    }

    /// <summary>
    /// Obtiene lista de Ã¡reas de negocio para dropdowns.
    /// </summary>
    [HttpGet]
    [ProducesResponseType(typeof(List<Shared.ComboItemDto>), StatusCodes.Status200OK)]
    public async Task<ActionResult<List<Shared.ComboItemDto>>> GetAreasNegocio()
    {
        var areas = await service.GetAreasNegocioAsync();
        return Ok(areas);
    }

    /// <summary>
    /// Obtiene lista de centros de costo para dropdowns.
    /// </summary>
    [HttpGet]
    [ProducesResponseType(typeof(List<Shared.ComboItemDto>), StatusCodes.Status200OK)]
    public async Task<ActionResult<List<Shared.ComboItemDto>>> GetCentrosCosto()
    {
        var centros = await service.GetCentrosCostoAsync();
        return Ok(centros);
    }
}
