using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using App.Helpers;

namespace App.Features.BalanceEjecutivoIfrs;

/// <summary>
/// MVC Controller para vistas de Balance Ejecutivo IFRS.
/// Patrón: JavaScript + API Directo (form.md)
/// Solo renderiza la vista. JavaScript llama directamente al ApiController.
/// </summary>
[Authorize]
public class BalanceEjecutivoIfrsController : Controller
{
    /// <summary>
    /// Vista principal del Balance Ejecutivo IFRS.
    /// GET /BalanceEjecutivoIfrs
    /// </summary>
    [HttpGet]
    public IActionResult Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder al Balance Ejecutivo IFRS";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        var hoy = DateTime.Today;

        var viewModel = new BalanceEjecutivoIfrsIndexViewModel
        {
            FechaDesde = new DateTime(hoy.Year, hoy.Month, 1),
            FechaHasta = hoy
        };

        return View(viewModel);
    }

    // R19: Los métodos proxy fueron eliminados.
    // JavaScript llama directamente al BalanceEjecutivoIfrsApiController
    // usando URLs con @Url.Action("Action", "BalanceEjecutivoIfrsApi")
}
