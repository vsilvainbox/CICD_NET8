using App.Data;
using App.Helpers;
using App.Exceptions;
using Microsoft.EntityFrameworkCore;
using App.Features.SeguimientoCierreApertura;
using ComprobanteEntity = App.Data.Comprobante;

namespace App.Features.Apertura;

/// <summary>
/// Service implementation for apertura (opening entry) operations
/// Generates opening entry voucher configuration for new accounting periods
/// </summary>
public class AperturaService(
    LpContabContext context,
    ILogger<AperturaService> logger,
    ISeguimientoCierreAperturaService seguimientoService) : IAperturaService
{
    // Default account codes from VB6 constants
    private const string DEFAULT_RESULT_ACCOUNT_CODE = "2031101";
    private const string DEFAULT_RESULT_ACCOUNT_DESC = "Utilidad Neta Retenida";
    private const string DEFAULT_IVA_ACCOUNT_CODE = "1010999";
    private const string DEFAULT_IVA_ACCOUNT_DESC = "Otros Impuestos por Recuperar";
    
    // Comprobante type and state constants (from VB6: HyperComun.bas)
    private const int TC_APERTURA = 4; // Opening voucher type (VB6:300)
    private const int EC_APROBADO = 2; // Approved state
    private const int TAJUSTE_FINANCIERO = 1; // Financial adjustment type

    public async Task<AperturaInitDataDto> GetAperturaInitDataAsync(int empresaId, short ano)
    {
        logger.LogInformation("Getting apertura init data for empresaId: {EmpresaId}, ano: {Ano}",
                              empresaId, ano);

        var result = new AperturaInitDataDto
        {
            EmpresaId = empresaId,
            Ano = ano
        };

        // Get company name
        var empresa = await context.Empresas.FindAsync(empresaId);
        result.NombreEmpresa = empresa?.NombreCorto ?? "N/A";

        // Get existing opening entry info
        var empresaAno = await context.EmpresasAno
            .FirstOrDefaultAsync(ea => ea.idEmpresa == empresaId && ea.Ano == ano);

        if (empresaAno != null)
        {
            result.IdCompAper = empresaAno.IdCompAper;
            result.NumCompAper = await DetermineOpeningVoucherNumberAsync(empresaId, ano);
            result.OpeningEntryExists = empresaAno.IdCompAper.HasValue && empresaAno.IdCompAper.Value > 0;

            if (result.OpeningEntryExists)
            {
                result.WarningMessage = "Se reemplazará Comprobante de Apertura ya existente.";
            }
        }
        else
        {
            result.NumCompAper = 1; // Default for new year
        }

        // Get configured accounts from ParamEmpresa
        var parameters = await context.ParamEmpresa
            .Where(p => p.IdEmpresa == empresaId &&
                       p.Ano == ano &&
                       (p.Tipo == "CTARESULT" || p.Tipo == "CTACREDIVA"))
            .ToListAsync();

        var paramResult = parameters.FirstOrDefault(p => p.Tipo == "CTARESULT");
        var paramIVA = parameters.FirstOrDefault(p => p.Tipo == "CTACREDIVA");

        // Load result account
        if (paramResult != null && int.TryParse(paramResult.Valor, out var idCtaResult))
        {
            result.IdCuentaResul = idCtaResult;
            var cuenta = await context.Cuentas
                .FirstOrDefaultAsync(c => c.idCuenta == idCtaResult &&
                                        c.IdEmpresa == empresaId &&
                                        c.Ano == ano);
            if (cuenta != null)
            {
                result.DescCuentaResul = $"{cuenta.Codigo} - {cuenta.Descripcion}";
            }
        }
        else
        {
            // Try to find default result account
            var defaultResult = await GetDefaultResultAccountAsync(empresaId, ano);
            if (defaultResult != null)
            {
                result.IdCuentaResul = defaultResult.IdCuenta;
                result.DescCuentaResul = defaultResult.FullDescription;
            }
        }

        // Load IVA credit account
        if (paramIVA != null && int.TryParse(paramIVA.Valor, out var idCtaIVA))
        {
            result.IdCuentaCredIVA = idCtaIVA;
            var cuenta = await context.Cuentas
                .FirstOrDefaultAsync(c => c.idCuenta == idCtaIVA &&
                                        c.IdEmpresa == empresaId &&
                                        c.Ano == ano);
            if (cuenta != null)
            {
                result.DescCuentaCredIVA = $"{cuenta.Codigo} - {cuenta.Descripcion}";
            }
        }
        else
        {
            // Try to find default IVA credit account
            var defaultIVA = await GetDefaultIvaAccountAsync(empresaId, ano);
            if (defaultIVA != null)
            {
                result.IdCuentaCredIVA = defaultIVA.IdCuenta;
                result.DescCuentaCredIVA = defaultIVA.FullDescription;
            }
        }

        // Get IVA remainder configuration
        var ivaConfig = await GetIvaRemainderConfigAsync(empresaId, ano);
        result.RemIVAUTM = ivaConfig.RemIVAUTM;
        result.RemIVAReadOnly = ivaConfig.IsReadOnly;
        result.RemIVASource = ivaConfig.Source;
        result.HasPreviousYear = ivaConfig.Source == "PreviousYearClose";

        logger.LogInformation("Apertura init data loaded. Opening entry exists: {Exists}",
                              result.OpeningEntryExists);

        return result;
    }

    public async Task<IEnumerable<AccountDto>> GetAccountsForSelectionAsync(int empresaId, short ano, string? accountType = null, string? searchTerm = null)
    {
        logger.LogInformation("Getting accounts for selection. EmpresaId: {EmpresaId}, Ano: {Ano}, Type: {Type}, SearchTerm: {SearchTerm}",
                              empresaId, ano, accountType ?? "all", searchTerm ?? "none");

        var query = context.Cuentas
            .Where(c => c.IdEmpresa == empresaId && c.Ano == ano);

        // Filter by account type if specified
        if (!string.IsNullOrEmpty(accountType))
        {
            if (accountType.ToLower() == "patrimonio")
            {
                // Clasificación = 5 typically represents patrimonio/equity accounts
                query = query.Where(c => c.Clasificacion == 5);
            }
            else if (accountType.ToLower() == "activo")
            {
                // Clasificación = 1 typically represents activo/asset accounts
                query = query.Where(c => c.Clasificacion == 1);
            }
        }

        // Filter by search term if specified
        if (!string.IsNullOrEmpty(searchTerm))
        {
            var term = searchTerm.ToLower();
            query = query.Where(c => (c.Codigo != null && c.Codigo.ToLower().Contains(term)) ||
                                     (c.Descripcion != null && c.Descripcion.ToLower().Contains(term)) ||
                                     (c.Nombre != null && c.Nombre.ToLower().Contains(term)));
        }

        var accounts = await query
            .OrderBy(c => c.Codigo)
            .Select(c => new AccountDto
            {
                IdCuenta = c.idCuenta,
                Codigo = c.Codigo ?? "",
                Descripcion = c.Descripcion ?? "",
                Nombre = c.Nombre ?? ""
            })
            .ToListAsync();

        logger.LogInformation("Found {Count} accounts", accounts.Count);

        return accounts;
    }

    public async Task<AperturaIvaRemainderDto> GetIvaRemainderConfigAsync(int empresaId, short ano)
    {
        logger.LogInformation("Getting IVA remainder config for empresaId: {EmpresaId}, ano: {Ano}",
                              empresaId, ano);

        // Check if previous year exists
        var hasPreviousYear = await context.EmpresasAno
            .AnyAsync(ea => ea.idEmpresa == empresaId && ea.Ano == (ano - 1));

        if (hasPreviousYear)
        {
            // Load RemIVAUTM from previous year's close (READ-ONLY)
            var previousYearRemIVA = await context.EmpresasAno
                .Where(ea => ea.idEmpresa == empresaId && ea.Ano == (ano - 1))
                .Select(ea => ea.RemIVAUTM)
                .FirstOrDefaultAsync();

            logger.LogInformation("IVA remainder from previous year: {RemIVA} UTM", previousYearRemIVA ?? 0);

            return new AperturaIvaRemainderDto
            {
                RemIVAUTM = previousYearRemIVA ?? 0,
                IsReadOnly = true,
                Source = "PreviousYearClose",
                SourceDescription = $"Remanente IVA desde cierre año {ano - 1}"
            };
        }
        else
        {
            // Load RemIVAUTMAnoAnt from current year (EDITABLE - manual input)
            var currentYearRemIVA = await context.EmpresasAno
                .Where(ea => ea.idEmpresa == empresaId && ea.Ano == ano)
                .Select(ea => ea.RemIVAUTMAnoAnt)
                .FirstOrDefaultAsync();

            logger.LogInformation("IVA remainder from manual input: {RemIVA} UTM", currentYearRemIVA ?? 0);

            return new AperturaIvaRemainderDto
            {
                RemIVAUTM = currentYearRemIVA ?? 0,
                IsReadOnly = false,
                Source = "ManualInput",
                SourceDescription = "Ingreso manual (no hay año anterior)"
            };
        }
    }

    public async Task ValidateAperturaRequestAsync(AperturaRequestDto request)
    {
        logger.LogInformation("Validating apertura request for empresaId: {EmpresaId}, ano: {Ano}",
                              request.EmpresaId, request.Ano);

        var errors = new List<string>();

        // Validate voucher number
        if (request.NumCompAper <= 0)
        {
            errors.Add($"Debe ingresar número de comprobante de apertura para el año {request.Ano}");
        }

        // Validate result account selected
        if (request.IdCuentaResul <= 0)
        {
            errors.Add($"Debe seleccionar una cuenta de patrimonio para el comprobante de apertura año {request.Ano}");
        }
        else
        {
            // Verify account exists
            var exists = await context.Cuentas
                .AnyAsync(c => c.idCuenta == request.IdCuentaResul &&
                             c.IdEmpresa == request.EmpresaId &&
                             c.Ano == request.Ano);
            if (!exists)
            {
                errors.Add("La cuenta de resultado seleccionada no existe");
            }
        }

        // Validate IVA credit account selected
        if (request.IdCuentaCredIVA <= 0)
        {
            errors.Add("Debe seleccionar una cuenta de arrastre de Crédito IVA desde el año anterior");
        }
        else
        {
            // Verify account exists
            var exists = await context.Cuentas
                .AnyAsync(c => c.idCuenta == request.IdCuentaCredIVA &&
                             c.IdEmpresa == request.EmpresaId &&
                             c.Ano == request.Ano);
            if (!exists)
            {
                errors.Add("La cuenta de crédito IVA seleccionada no existe");
            }
        }

        // Validate IVA remainder
        if (request.RemIVAUTM < 0)
        {
            errors.Add("El remanente IVA no puede ser negativo");
        }

        // Check if year is closed
        var empresaAno = await context.EmpresasAno
            .FirstOrDefaultAsync(ea => ea.idEmpresa == request.EmpresaId && ea.Ano == request.Ano);

        if (empresaAno?.FCierre.HasValue == true && empresaAno.FCierre > 0)
        {
            errors.Add($"El año {request.Ano} está cerrado. No se puede generar apertura.");
        }

        if (errors.Any())
        {
            var errorMessage = string.Join("; ", errors);
            logger.LogWarning("Apertura request validation failed: {Errors}", errorMessage);
            throw new BusinessException(errorMessage);
        }
    }

    public async Task<bool> OpeningEntryExistsAsync(int empresaId, short ano)
    {
        var empresaAno = await context.EmpresasAno
            .FirstOrDefaultAsync(ea => ea.idEmpresa == empresaId && ea.Ano == ano);

        return empresaAno?.IdCompAper.HasValue == true && empresaAno.IdCompAper.Value > 0;
    }

    public async Task<int> DetermineOpeningVoucherNumberAsync(int empresaId, short ano)
    {
        logger.LogInformation("Determining opening voucher number for empresaId: {EmpresaId}, ano: {Ano}",
                              empresaId, ano);

        var empresaAno = await context.EmpresasAno
            .FirstOrDefaultAsync(ea => ea.idEmpresa == empresaId && ea.Ano == ano);

        if (empresaAno?.IdCompAper.HasValue != true || empresaAno.IdCompAper.Value == 0)
        {
            // No opening entry exists yet
            logger.LogInformation("No opening entry exists. Defaulting to voucher number 1");
            return 1;
        }

        // Opening entry exists - load existing number
        if (!empresaAno.NCompAper.HasValue || empresaAno.NCompAper.Value == 0)
        {
            // Data integrity fix: IdCompAper exists but NCompAper is 0
            // Query Comprobante table to get correlativo
            logger.LogWarning("Data integrity issue: IdCompAper exists but NCompAper = 0. Fixing...");

            var comprobante = await context.Comprobante
                .FirstOrDefaultAsync(c => c.IdComp == empresaAno.IdCompAper &&
                                         c.Tipo == TC_APERTURA && // 4
                                         c.TipoAjuste == TAJUSTE_FINANCIERO); // 1

            if (comprobante != null && comprobante.Correlativo.HasValue)
            {
                // Update EmpresasAno with found number
                empresaAno.NCompAper = comprobante.Correlativo.Value;
                await context.SaveChangesAsync();

                logger.LogInformation("Fixed NCompAper: {NumCompAper}", comprobante.Correlativo.Value);
                return comprobante.Correlativo.Value;
            }
        }

        var voucherNumber = empresaAno.NCompAper ?? 1;
        logger.LogInformation("Opening voucher number: {NumCompAper}", voucherNumber);

        return voucherNumber;
    }

    public async Task SaveAperturaAccountsAsync(int empresaId, short ano, int idCuentaResul, int idCuentaCredIVA)
    {
        logger.LogInformation("Saving apertura accounts for empresaId: {EmpresaId}, ano: {Ano}",
                              empresaId, ano);

        // Upsert Result Account parameter (CTARESULT)
        var paramResult = await context.ParamEmpresa
            .FirstOrDefaultAsync(p => p.IdEmpresa == empresaId &&
                                     p.Ano == ano &&
                                     p.Tipo == "CTARESULT");

        if (paramResult != null)
        {
            // UPDATE existing parameter using ExecuteSqlRawAsync (R22: ParamEmpresa is HasNoKey)
            await context.Database.ExecuteSqlRawAsync(
                @"UPDATE ParamEmpresa 
                  SET Valor = {0} 
                  WHERE IdEmpresa = {1} AND Ano = {2} AND Tipo = 'CTARESULT'",
                idCuentaResul.ToString(), empresaId, ano);
            logger.LogInformation("Updated CTARESULT parameter");
        }
        else
        {
            // INSERT new parameter using ExecuteSqlRawAsync (R22: ParamEmpresa is HasNoKey)
            await context.Database.ExecuteSqlRawAsync(
                @"INSERT INTO ParamEmpresa (Tipo, Valor, IdEmpresa, Ano, Codigo) 
                  VALUES ('CTARESULT', {0}, {1}, {2}, 0)",
                idCuentaResul.ToString(), empresaId, ano);
            logger.LogInformation("Inserted CTARESULT parameter");
        }

        // Upsert IVA Credit Account parameter (CTACREDIVA)
        var paramIVA = await context.ParamEmpresa
            .FirstOrDefaultAsync(p => p.IdEmpresa == empresaId &&
                                     p.Ano == ano &&
                                     p.Tipo == "CTACREDIVA");

        if (paramIVA != null)
        {
            // UPDATE existing parameter using ExecuteSqlRawAsync (R22: ParamEmpresa is HasNoKey)
            await context.Database.ExecuteSqlRawAsync(
                @"UPDATE ParamEmpresa 
                  SET Valor = {0} 
                  WHERE IdEmpresa = {1} AND Ano = {2} AND Tipo = 'CTACREDIVA'",
                idCuentaCredIVA.ToString(), empresaId, ano);
            logger.LogInformation("Updated CTACREDIVA parameter");
        }
        else
        {
            // INSERT new parameter using ExecuteSqlRawAsync (R22: ParamEmpresa is HasNoKey)
            await context.Database.ExecuteSqlRawAsync(
                @"INSERT INTO ParamEmpresa (Tipo, Valor, IdEmpresa, Ano, Codigo) 
                  VALUES ('CTACREDIVA', {0}, {1}, {2}, 0)",
                idCuentaCredIVA.ToString(), empresaId, ano);
            logger.LogInformation("Inserted CTACREDIVA parameter");
        }

        // No SaveChangesAsync needed - ExecuteSqlRawAsync already committed

        logger.LogInformation("Apertura accounts saved successfully");
    }

    public async Task SaveIvaRemainderAsync(int empresaId, short ano, double remIVAUTM)
    {
        logger.LogInformation("Saving IVA remainder for empresaId: {EmpresaId}, ano: {Ano}, remIVA: {RemIVA}",
                              empresaId, ano, remIVAUTM);

        var empresaAno = await context.EmpresasAno
            .FirstOrDefaultAsync(ea => ea.idEmpresa == empresaId && ea.Ano == ano);

        if (empresaAno != null)
        {
            empresaAno.RemIVAUTMAnoAnt = remIVAUTM;
            await context.SaveChangesAsync();

            logger.LogInformation("IVA remainder saved successfully");
        }
        else
        {
            logger.LogWarning("EmpresasAno record not found. Cannot save IVA remainder");
        }
    }

    public async Task<AperturaResultDto> ExecuteAperturaAsync(AperturaRequestDto request)
    {
        logger.LogInformation("Executing apertura for empresaId: {EmpresaId}, ano: {Ano}",
                              request.EmpresaId, request.Ano);

        // Validate request (throws BusinessException if invalid)
        await ValidateAperturaRequestAsync(request);

        // Save accounts to ParamEmpresa
        await SaveAperturaAccountsAsync(request.EmpresaId, request.Ano,
                                       request.IdCuentaResul, request.IdCuentaCredIVA);

        // Save IVA remainder to EmpresasAno (only if no previous year - manual input scenario)
        var hasPreviousYear = await context.EmpresasAno
            .AnyAsync(ea => ea.idEmpresa == request.EmpresaId && ea.Ano == (request.Ano - 1));

        if (!hasPreviousYear)
        {
            await SaveIvaRemainderAsync(request.EmpresaId, request.Ano, request.RemIVAUTM);
        }

        // Get existing opening entry ID if replacing
        var empresaAno = await context.EmpresasAno
            .FirstOrDefaultAsync(ea => ea.idEmpresa == request.EmpresaId && ea.Ano == request.Ano);

        var result = new AperturaResultDto
        {
            NumCompAper = request.NumCompAper,
            IdCuentaResul = request.IdCuentaResul,
            RemIVAUTM = request.RemIVAUTM,
            IdCompAper = empresaAno?.IdCompAper ?? 0,
            IdCompAperTrib = empresaAno?.IdCompAperTrib ?? 0,
            Message = empresaAno?.IdCompAper.HasValue == true
                ? $"Configuración de apertura guardada. Comprobante de apertura #{request.NumCompAper} será reemplazado."
                : $"Configuración de apertura guardada. Listo para generar comprobante de apertura #{request.NumCompAper}."
        };

        logger.LogInformation("Apertura executed successfully");

        return result;
    }

    public async Task<AccountDto?> GetDefaultResultAccountAsync(int empresaId, short ano)
    {
        logger.LogInformation("Looking for default result account with code: {Code}", DEFAULT_RESULT_ACCOUNT_CODE);

        var defaultAccount = await context.Cuentas
            .Where(c => c.IdEmpresa == empresaId &&
                       c.Ano == ano &&
                       c.Codigo == DEFAULT_RESULT_ACCOUNT_CODE &&
                       c.Descripcion != null &&
                       c.Descripcion.Contains(DEFAULT_RESULT_ACCOUNT_DESC))
            .Select(c => new AccountDto
            {
                IdCuenta = c.idCuenta,
                Codigo = c.Codigo ?? "",
                Descripcion = c.Descripcion ?? "",
                Nombre = c.Nombre ?? ""
            })
            .FirstOrDefaultAsync();

        if (defaultAccount != null)
        {
            logger.LogInformation("Found default result account: {Description}", defaultAccount.FullDescription);
        }
        else
        {
            logger.LogWarning("Default result account not found");
            throw new BusinessException("Cuenta de resultado por defecto no encontrada");
        }

        return defaultAccount;
    }

    public async Task<AccountDto?> GetDefaultIvaAccountAsync(int empresaId, short ano)
    {
        logger.LogInformation("Looking for default IVA account with code: {Code}", DEFAULT_IVA_ACCOUNT_CODE);

        var defaultAccount = await context.Cuentas
            .Where(c => c.IdEmpresa == empresaId &&
                       c.Ano == ano &&
                       c.Codigo == DEFAULT_IVA_ACCOUNT_CODE &&
                       c.Descripcion != null &&
                       c.Descripcion.Contains(DEFAULT_IVA_ACCOUNT_DESC))
            .Select(c => new AccountDto
            {
                IdCuenta = c.idCuenta,
                Codigo = c.Codigo ?? "",
                Descripcion = c.Descripcion ?? "",
                Nombre = c.Nombre ?? ""
            })
            .FirstOrDefaultAsync();

        if (defaultAccount != null)
        {
            logger.LogInformation("Found default IVA account: {Description}", defaultAccount.FullDescription);
        }
        else
        {
            logger.LogWarning("Default IVA account not found");
            throw new BusinessException("Cuenta de crédito IVA por defecto no encontrada");
        }

        return defaultAccount;
    }

    /// <summary>
    /// Generates the actual opening voucher (Comprobante de Apertura) with MovComprobante entries
    /// Implements VB6 GenCompApertura logic from HyperCont.bas lines 5073-5273
    /// </summary>
    public async Task<AperturaResultDto> GenerateOpeningVoucherAsync(AperturaRequestDto request)
    {
        logger.LogInformation("Starting opening voucher generation for empresa: {EmpresaId}, ano: {Ano}",
                              request.EmpresaId, request.Ano);

        // 1. Validate request (throws BusinessException if invalid)
        await ValidateAperturaRequestAsync(request);

        // 2. Save configuration (accounts, IVA remainder)
        await SaveAperturaAccountsAsync(request.EmpresaId, request.Ano,
                                       request.IdCuentaResul, request.IdCuentaCredIVA);

        var hasPreviousYear = await context.EmpresasAno
            .AnyAsync(ea => ea.idEmpresa == request.EmpresaId && ea.Ano == (request.Ano - 1));

        if (!hasPreviousYear)
        {
            await SaveIvaRemainderAsync(request.EmpresaId, request.Ano, request.RemIVAUTM);
        }

        // 3. Calculate total Debe/Haber difference from Cuentas table
        var totals = await context.Cuentas
            .Where(c => c.IdEmpresa == request.EmpresaId && c.Ano == request.Ano)
            .Select(c => new { c.Debe, c.Haber })
            .ToListAsync();

        var totDebe = totals.Sum(c => c.Debe ?? 0);
        var totHaber = totals.Sum(c => c.Haber ?? 0);
        var saldo = totDebe - totHaber;

        logger.LogInformation("Opening balance: TotDebe={TotDebe}, TotHaber={TotHaber}, Saldo={Saldo}",
                              totDebe, totHaber, saldo);

        // 4. If saldo != 0, adjust result account (patrimonio) balance
        if (Math.Abs(saldo) > 0.01) // Use tolerance for floating point comparison
        {
            logger.LogInformation("Adjusting result account {IdCuenta} to balance saldo: {Saldo}",
                                  request.IdCuentaResul, saldo);

            var cuentaResul = await context.Cuentas
                .FirstOrDefaultAsync(c => c.idCuenta == request.IdCuentaResul &&
                                        c.IdEmpresa == request.EmpresaId &&
                                        c.Ano == request.Ano);

            if (cuentaResul == null)
            {
                throw new BusinessException("Cuenta de resultado no encontrada");
            }

            var resDebe = cuentaResul.Debe ?? 0;
            var resHaber = cuentaResul.Haber ?? 0;
            var saldoRes = (resDebe - resHaber) - saldo;

            // Update result account to balance the opening entry
            if (saldoRes > 0)
            {
                cuentaResul.Debe = saldoRes;
                cuentaResul.Haber = 0;
            }
            else
            {
                cuentaResul.Debe = 0;
                cuentaResul.Haber = Math.Abs(saldoRes);
            }

            await context.SaveChangesAsync();

            logger.LogInformation("Result account adjusted: Debe={Debe}, Haber={Haber}",
                                  cuentaResul.Debe, cuentaResul.Haber);
        }

        // 5. Get or create Comprobante record
        var empresaAno = await context.EmpresasAno
            .FirstOrDefaultAsync(ea => ea.idEmpresa == request.EmpresaId && ea.Ano == request.Ano);

        int idCompAper;
        var isReplacing = false;

        if (empresaAno?.IdCompAper.HasValue == true && empresaAno.IdCompAper.Value > 0)
        {
            // Replacing existing opening voucher
            idCompAper = empresaAno.IdCompAper.Value;
            isReplacing = true;

            logger.LogInformation("Replacing existing opening voucher IdComp={IdComp}", idCompAper);

            // Delete existing MovComprobante entries
            var existingMovs = await context.MovComprobante
                .Where(m => m.IdComp == idCompAper &&
                           m.IdEmpresa == request.EmpresaId &&
                           m.Ano == request.Ano)
                .ToListAsync();

            context.MovComprobante.RemoveRange(existingMovs);
            await context.SaveChangesAsync();

            logger.LogInformation("Deleted {Count} existing MovComprobante entries", existingMovs.Count);
        }
        else
        {
            // Create new Comprobante
            logger.LogInformation("Creating new opening voucher");

            var fechaInt = (int)DateTime.Now.ToOADate();
            var nuevoComp = new ComprobanteEntity
            {
                IdEmpresa = request.EmpresaId,
                Ano = request.Ano,
                Correlativo = request.NumCompAper,
                Fecha = fechaInt,
                Tipo = TC_APERTURA,
                Estado = EC_APROBADO,
                Glosa = "Apertura",
                TotalDebe = 0, // Will be updated later
                TotalHaber = 0,
                IdUsuario = SessionHelper.UsuarioId,
                FechaCreacion = fechaInt,
                TipoAjuste = TAJUSTE_FINANCIERO
            };

            context.Comprobante.Add(nuevoComp);
            await context.SaveChangesAsync();

            idCompAper = nuevoComp.IdComp;

            // Update EmpresasAno with IdCompAper
            if (empresaAno == null)
            {
                empresaAno = new EmpresasAno
                {
                    idEmpresa = request.EmpresaId,
                    Ano = request.Ano,
                    IdCompAper = idCompAper,
                    NCompAper = request.NumCompAper
                };
                context.EmpresasAno.Add(empresaAno);
            }
            else
            {
                empresaAno.IdCompAper = idCompAper;
                empresaAno.NCompAper = request.NumCompAper;
            }

            await context.SaveChangesAsync();

            logger.LogInformation("Created new Comprobante IdComp={IdComp}", idCompAper);
        }

        // 6. Generate MovComprobante entries for all accounts with non-zero balance
        var cuentasConSaldo = await context.Cuentas
            .Where(c => c.IdEmpresa == request.EmpresaId &&
                       c.Ano == request.Ano &&
                       (c.Debe ?? 0) - (c.Haber ?? 0) != 0)
            .OrderBy(c => c.Codigo)
            .ToListAsync();

        logger.LogInformation("Generating MovComprobante for {Count} accounts", cuentasConSaldo.Count);

        var orden = 1;
        foreach (var cuenta in cuentasConSaldo)
        {
            var mov = new MovComprobante
            {
                IdComp = idCompAper,
                IdEmpresa = request.EmpresaId,
                Ano = request.Ano,
                Orden = orden++,
                IdCuenta = cuenta.idCuenta,
                Debe = cuenta.Debe ?? 0,
                Haber = cuenta.Haber ?? 0,
                Glosa = "Apertura"
            };

            context.MovComprobante.Add(mov);
        }

        await context.SaveChangesAsync();

        logger.LogInformation("Created {Count} MovComprobante entries", cuentasConSaldo.Count);

        // 7. Update Comprobante totals
        var movTotals = await context.MovComprobante
            .Where(m => m.IdComp == idCompAper &&
                       m.IdEmpresa == request.EmpresaId &&
                       m.Ano == request.Ano)
            .Select(m => new { m.Debe, m.Haber })
            .ToListAsync();

        var finalDebe = movTotals.Sum(m => m.Debe ?? 0);
        var finalHaber = movTotals.Sum(m => m.Haber ?? 0);

        var comprobante = await context.Comprobante.FindAsync(idCompAper);
        if (comprobante != null)
        {
            comprobante.TotalDebe = finalDebe;
            comprobante.TotalHaber = finalHaber;
            comprobante.Estado = EC_APROBADO;
            await context.SaveChangesAsync();

            logger.LogInformation("Updated Comprobante totals: Debe={Debe}, Haber={Haber}",
                                  finalDebe, finalHaber);
        }

        // 8. Register audit: SeguimientoCierreApertura(1, "Apertura Anual") from VB6
        await seguimientoService.RegisterAuditAsync(
            request.EmpresaId,
            request.Ano,
            SessionHelper.UsuarioId,
            1, // TIPO_APERTURA = 1
            "Apertura Anual");

        logger.LogInformation("Opening voucher generation completed successfully");

        // 9. Return result
        return new AperturaResultDto
        {
            IdCompAper = idCompAper,
            NumCompAper = request.NumCompAper,
            IdCuentaResul = request.IdCuentaResul,
            RemIVAUTM = request.RemIVAUTM,
            Message = isReplacing
                ? $"Comprobante de apertura #{request.NumCompAper} reemplazado exitosamente."
                : $"Comprobante de apertura #{request.NumCompAper} generado exitosamente."
        };
    }
}
