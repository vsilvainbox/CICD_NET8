# Apertura - Refactorización Completada

## Fecha: 2025-12-07

## Violaciones Corregidas

### R19 - JavaScript debe llamar directamente al ApiController (1 corrección)

**Archivo:** `Views/Index.cshtml`

**Problema:** El formulario usaba `Api.postForm(form.action, formData)` donde `form.action` apuntaba al MVC Controller (`Apertura/Execute`), creando un patrón proxy innecesario.

**Solución:**
- Agregado endpoint `execute` en `URL_ENDPOINTS` apuntando a `AperturaApi/Execute`
- Cambiado de `Api.postForm` a `Api.postJson` con payload JSON explícito
- Eliminada dependencia del form.action que apuntaba al MVC Controller

```javascript
// ANTES (R19 violación - proxy a través de MVC)
const data = await Api.postForm(form.action, formData);

// DESPUÉS (R19 corregido - directo al ApiController)
const payload = {
    empresaId: parseInt(document.querySelector('input[name="EmpresaId"]').value),
    ano: parseInt(document.querySelector('input[name="Ano"]').value),
    numCompAper: parseInt(document.querySelector('input[name="NumCompAper"]').value),
    idCuentaResul: parseInt(document.querySelector('input[name="IdCuentaResul"]').value),
    idCuentaCredIVA: parseInt(document.querySelector('input[name="IdCuentaCredIVA"]').value),
    remIVAUTM: parseFloat(document.querySelector('input[name="RemIVAUTM"]').value) || 0
};
const data = await Api.postJson(URL_ENDPOINTS.execute, payload);
```

---

### R22 - Entidades HasNoKey no pueden usar Add/Update/Remove (2 correcciones)

**Archivo:** `AperturaService.cs` - método `SaveAperturaAccountsAsync()`

**Problema:** `ParamEmpresa` es una entidad sin clave primaria (`HasNoKey()`) y estaba usando `context.ParamEmpresa.Add()`, lo cual causa error en runtime porque EF Core no puede trackear entidades sin PK.

**Corrección 1 - CTARESULT (línea ~356-374):**

```csharp
// ANTES (R22 violación)
context.ParamEmpresa.Add(new App.Data.ParamEmpresa { Tipo = "CTARESULT", ... });

// DESPUÉS (R22 corregido)
await context.Database.ExecuteSqlRawAsync(
    @"INSERT INTO ParamEmpresa (Tipo, Valor, IdEmpresa, Ano, Codigo) 
      VALUES ('CTARESULT', {0}, {1}, {2}, 0)",
    idCuentaResul.ToString(), empresaId, ano);
```

**Corrección 2 - CTACREDIVA (línea ~382-400):**

```csharp
// ANTES (R22 violación)  
context.ParamEmpresa.Add(new App.Data.ParamEmpresa { Tipo = "CTACREDIVA", ... });

// DESPUÉS (R22 corregido)
await context.Database.ExecuteSqlRawAsync(
    @"INSERT INTO ParamEmpresa (Tipo, Valor, IdEmpresa, Ano, Codigo) 
      VALUES ('CTACREDIVA', {0}, {1}, {2}, 0)",
    idCuentaCredIVA.ToString(), empresaId, ano);
```

---

## Reglas Aplicadas Previamente

### R16 - Eliminar HTTP interno en WebController
- **AperturaController.cs**: Inyecta `IAperturaService` directamente
- Index() usa `service.GetAperturaInitDataAsync()` server-side
- GetAccounts() usa `service.GetAccountsForSelectionAsync()`
- Execute() usa `service.ExecuteAperturaAsync()`

### R19 - JS llama ApiController directamente
- Eliminados métodos proxy del WebController
- El Controller ahora solo tiene: Index(), GetAccounts(), Execute()
- Views llaman directamente a AperturaApiController cuando necesitan JSON

## Estructura Final

```
Features/Apertura/
├── AperturaController.cs      # MVC: Index, GetAccounts (partial), Execute
├── AperturaApiController.cs   # API: Init, GetAccounts, Execute (JSON endpoints)
├── AperturaService.cs         # Lógica de negocio (R22 corregido)
├── IAperturaService.cs        # Interface del servicio
├── AperturaViewModel.cs       # ViewModel para MVC
├── AperturaDto.cs             # DTOs para API
└── Views/
    ├── Index.cshtml           # R19 corregido
    └── _BusquedaCuentas.cshtml
```

## Métodos del Servicio Utilizados
- `GetAperturaInitDataAsync(empresaId, ano)` - Datos iniciales
- `GetAccountsForSelectionAsync(empresaId, ano, type)` - Búsqueda de cuentas
- `ExecuteAperturaAsync(request)` - Ejecutar apertura
- `SaveAperturaAccountsAsync(empresaId, ano, idCuentaResul, idCuentaCredIVA)` - Guardar configuración (R22 corregido)
