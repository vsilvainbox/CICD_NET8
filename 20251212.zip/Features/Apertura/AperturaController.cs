﻿using Microsoft.AspNetCore.Mvc;
using App.Helpers;

namespace App.Features.Apertura;

public class AperturaController(
    IAperturaService service,
    ILogger<AperturaController> logger) : Controller
{
    /// <summary>
    /// Main view for apertura (opening entry generation)
    /// Loads initial data server-side instead of AJAX call
    /// </summary>
    /// <returns>Apertura view with populated ViewModel</returns>
    public async Task<IActionResult> Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Apertura";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        logger.LogInformation("Loading Apertura index for empresaId: {EmpresaId}, ano: {Ano}",
            SessionHelper.EmpresaId, SessionHelper.Ano);

        // Load initial data server-side using Service
        var initData = await service.GetAperturaInitDataAsync(SessionHelper.EmpresaId, SessionHelper.Ano);

        // Map to ViewModel (server-side state management)
        var model = new AperturaViewModel
        {
            EmpresaId = initData.EmpresaId,
            Ano = initData.Ano,
            NombreEmpresa = initData.NombreEmpresa,
            NumCompAper = initData.NumCompAper,
            IdCompAper = initData.IdCompAper,
            OpeningEntryExists = initData.OpeningEntryExists,
            WarningMessage = initData.WarningMessage,
            IdCuentaResul = initData.IdCuentaResul ?? 0,
            DescCuentaResul = initData.DescCuentaResul,
            IdCuentaCredIVA = initData.IdCuentaCredIVA ?? 0,
            DescCuentaCredIVA = initData.DescCuentaCredIVA,
            RemIVAUTM = initData.RemIVAUTM,
            RemIVAReadOnly = initData.RemIVAReadOnly,
            RemIVASource = initData.RemIVASource,
            HasPreviousYear = initData.HasPreviousYear
        };

        return View(model);
    }

    /// <summary>
    /// Get accounts by type and return as Partial View (HTML)
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetAccounts(int empresaId, short ano, string type, string? searchTerm = null)
    {
        logger.LogInformation("MVC: GetAccounts - empresaId: {EmpresaId}, ano: {Ano}, type: {Type}, search: {Search}",
            empresaId, ano, type, searchTerm);

        var accounts = await service.GetAccountsForSelectionAsync(empresaId, ano, type);

        // Create ViewModel for partial view
        var searchMode = type == "patrimonio" ? "result" : "iva";
        var modalTitle = type == "patrimonio"
            ? "Seleccionar Cuenta de Resultado"
            : "Seleccionar Cuenta de Crédito IVA";

        var viewModel = new AccountSearchViewModel
        {
            SearchMode = searchMode,
            ModalTitle = modalTitle,
            Accounts = accounts.ToList(),
            SearchTerm = searchTerm ?? string.Empty
        };

        // Return server-rendered HTML instead of JSON
        return PartialView("_BusquedaCuentas", viewModel);
    }

    /// <summary>
    /// Execute apertura (opening entry) with automatic model validation
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Execute(AperturaViewModel model)
    {
        logger.LogInformation("MVC: Execute apertura - empresaId: {EmpresaId}, ano: {Ano}",
            model.EmpresaId, model.Ano);

        // Model validation is automatic via DataAnnotations
        if (!ModelState.IsValid)
        {
            var errors = ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage)
                .ToList();

            return BadRequest(new
            {
                success = false,
                message = "Error de validación",
                errors = errors
            });
        }

        // Map ViewModel to DTO for Service
        var request = new AperturaRequestDto
        {
            EmpresaId = model.EmpresaId,
            Ano = model.Ano,
            NumCompAper = model.NumCompAper,
            IdCuentaResul = model.IdCuentaResul,
            IdCuentaCredIVA = model.IdCuentaCredIVA,
            RemIVAUTM = model.RemIVAUTM
        };

        await service.ExecuteAperturaAsync(request);
        return Ok(new { success = true, message = "Apertura ejecutada correctamente" });
    }
}