using Microsoft.AspNetCore.Mvc;

namespace App.Features.Apertura;

[ApiController]
[Route("[controller]/[action]")]
public class AperturaApiController(IAperturaService service, ILogger<AperturaApiController> logger) : ControllerBase
{
    /// <summary>
    /// Gets initialization data for apertura form
    /// </summary>
    /// <param name="empresaId">Company ID</param>
    /// <param name="ano">Year</param>
    /// <returns>Initialization data</returns>
    [HttpGet]
    public async Task<ActionResult<AperturaInitDataDto>> Init([FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: Init called with empresaId: {EmpresaId}, ano: {Ano}",
                              empresaId, ano);

        var initData = await service.GetAperturaInitDataAsync(empresaId, ano);
        return Ok(initData);
    }

    /// <summary>
    /// Gets accounts available for selection
    /// </summary>
    /// <param name="empresaId">Company ID</param>
    /// <param name="ano">Year</param>
    /// <param name="type">Account type filter: "patrimonio", "activo", or null for all</param>
    /// <param name="searchTerm">Search term to filter accounts by code or name</param>
    /// <returns>List of accounts</returns>
    [HttpGet]
    public async Task<ActionResult<IEnumerable<AccountDto>>> GetAccounts(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        [FromQuery] string? type = null,
        [FromQuery] string? searchTerm = null)
    {
        logger.LogInformation("API: GetAccounts called with empresaId: {EmpresaId}, ano: {Ano}, type: {Type}, searchTerm: {SearchTerm}",
                              empresaId, ano, type ?? "all", searchTerm ?? "none");

        var accounts = await service.GetAccountsForSelectionAsync(empresaId, ano, type, searchTerm);
        return Ok(accounts);
    }

    /// <summary>
    /// Gets IVA remainder configuration
    /// </summary>
    /// <param name="empresaId">Company ID</param>
    /// <param name="ano">Year</param>
    /// <returns>IVA remainder configuration</returns>
    [HttpGet]
    public async Task<ActionResult<AperturaIvaRemainderDto>> GetIvaRemainder(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        logger.LogInformation("API: GetIvaRemainder called with empresaId: {EmpresaId}, ano: {Ano}",
                              empresaId, ano);

        var ivaConfig = await service.GetIvaRemainderConfigAsync(empresaId, ano);
        return Ok(ivaConfig);
    }


    /// <summary>
    /// Checks if opening entry already exists
    /// </summary>
    /// <param name="empresaId">Company ID</param>
    /// <param name="ano">Year</param>
    /// <returns>True if exists</returns>
    [HttpGet]
    public async Task<ActionResult<bool>> CheckExists([FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: CheckExists called with empresaId: {EmpresaId}, ano: {Ano}",
                              empresaId, ano);

        var exists = await service.OpeningEntryExistsAsync(empresaId, ano);
        return Ok(exists);
    }

    /// <summary>
    /// Executes opening entry generation
    /// </summary>
    /// <param name="request">Apertura request</param>
    /// <returns>Execution result</returns>
    [HttpPost]
    public async Task<ActionResult<AperturaResultDto>> Execute([FromBody] AperturaRequestDto request)
    {
        logger.LogInformation("API: Execute called for empresaId: {EmpresaId}, ano: {Ano}",
                              request.EmpresaId, request.Ano);

        var result = await service.ExecuteAperturaAsync(request);
        return Ok(result);
    }

    /// <summary>
    /// Gets default result account
    /// </summary>
    /// <param name="empresaId">Company ID</param>
    /// <param name="ano">Year</param>
    /// <returns>Default result account if found</returns>
    [HttpGet]
    public async Task<ActionResult<AccountDto?>> GetDefaultResultAccount(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        logger.LogInformation("API: GetDefaultResultAccount called with empresaId: {EmpresaId}, ano: {Ano}",
                              empresaId, ano);

        var account = await service.GetDefaultResultAccountAsync(empresaId, ano);
        return Ok(account);
    }

    /// <summary>
    /// Gets default IVA credit account
    /// </summary>
    /// <param name="empresaId">Company ID</param>
    /// <param name="ano">Year</param>
    /// <returns>Default IVA credit account if found</returns>
    [HttpGet]
    public async Task<ActionResult<AccountDto?>> GetDefaultIvaAccount(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        logger.LogInformation("API: GetDefaultIvaAccount called with empresaId: {EmpresaId}, ano: {Ano}",
                              empresaId, ano);

        var account = await service.GetDefaultIvaAccountAsync(empresaId, ano);
        return Ok(account);
    }
}
