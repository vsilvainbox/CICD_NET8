﻿namespace App.Features.Apertura;

/// <summary>
/// Service interface for apertura (opening entry) operations
/// Generates opening entry voucher configuration for new accounting periods
/// </summary>
public interface IAperturaService
{
    /// <summary>
    /// Gets initialization data for the apertura form
    /// Loads existing opening entry, default accounts, and IVA remainder configuration
    /// </summary>
    /// <param name="empresaId">Company ID</param>
    /// <param name="ano">Year for opening entry</param>
    /// <returns>Initialization data including voucher number, accounts, IVA remainder</returns>
    Task<AperturaInitDataDto> GetAperturaInitDataAsync(int empresaId, short ano);

    /// <summary>
    /// Gets list of accounts for account picker (patrimonio accounts for result, activo for IVA)
    /// </summary>
    /// <param name="empresaId">Company ID</param>
    /// <param name="ano">Year</param>
    /// <param name="accountType">Type filter: "patrimonio", "activo", or null for all</param>
    /// <param name="searchTerm">Search term to filter accounts by code or name</param>
    /// <returns>List of accounts available for selection</returns>
    Task<IEnumerable<AccountDto>> GetAccountsForSelectionAsync(int empresaId, short ano, string? accountType = null, string? searchTerm = null);

    /// <summary>
    /// Gets IVA remainder from previous year's close
    /// Returns configuration indicating if value is read-only or editable
    /// </summary>
    /// <param name="empresaId">Company ID</param>
    /// <param name="ano">Current year</param>
    /// <returns>IVA remainder configuration</returns>
    Task<AperturaIvaRemainderDto> GetIvaRemainderConfigAsync(int empresaId, short ano);

    /// <summary>
    /// Validates opening entry request before execution
    /// Checks: voucher number, accounts selected, year not closed
    /// Throws BusinessException if validation fails
    /// </summary>
    /// <param name="request">Apertura request to validate</param>
    Task ValidateAperturaRequestAsync(AperturaRequestDto request);

    /// <summary>
    /// Checks if opening entry already exists for the year
    /// </summary>
    /// <param name="empresaId">Company ID</param>
    /// <param name="ano">Year</param>
    /// <returns>True if opening entry exists</returns>
    Task<bool> OpeningEntryExistsAsync(int empresaId, short ano);

    /// <summary>
    /// Determines opening voucher number (1 for new, existing number if replacing)
    /// Handles data integrity fix if IdCompAper exists but NCompAper = 0
    /// </summary>
    /// <param name="empresaId">Company ID</param>
    /// <param name="ano">Year</param>
    /// <returns>Voucher number to use</returns>
    Task<int> DetermineOpeningVoucherNumberAsync(int empresaId, short ano);

    /// <summary>
    /// Saves selected accounts to ParamEmpresa (CTARESULT, CTACREDIVA)
    /// Upserts parameters (UPDATE if exists, INSERT if not)
    /// </summary>
    /// <param name="empresaId">Company ID</param>
    /// <param name="ano">Year</param>
    /// <param name="idCuentaResul">Result account ID</param>
    /// <param name="idCuentaCredIVA">IVA credit account ID</param>
    Task SaveAperturaAccountsAsync(int empresaId, short ano, int idCuentaResul, int idCuentaCredIVA);

    /// <summary>
    /// Saves IVA remainder to EmpresasAno.RemIVAUTMAnoAnt
    /// Only for companies without previous year (manual input scenario)
    /// </summary>
    /// <param name="empresaId">Company ID</param>
    /// <param name="ano">Year</param>
    /// <param name="remIVAUTM">IVA remainder in UTM units</param>
    Task SaveIvaRemainderAsync(int empresaId, short ano, double remIVAUTM);

    /// <summary>
    /// Executes opening entry generation
    /// Saves configuration (accounts, IVA remainder) and prepares opening entry data
    /// NOTE: This method does NOT create the actual Comprobante voucher record.
    /// It only saves configuration and returns values for external voucher creation.
    /// </summary>
    /// <param name="request">Apertura request</param>
    /// <returns>Result with voucher info and configuration</returns>
    Task<AperturaResultDto> ExecuteAperturaAsync(AperturaRequestDto request);

    /// <summary>
    /// Gets default result account (patrimonio account for net profit/loss)
    /// Tries code "2031101" with description containing "Utilidad Neta Retenida"
    /// </summary>
    /// <param name="empresaId">Company ID</param>
    /// <param name="ano">Year</param>
    /// <returns>Default result account if found</returns>
    Task<AccountDto?> GetDefaultResultAccountAsync(int empresaId, short ano);

    /// <summary>
    /// Gets default IVA credit account (activo account for IVA carryforward)
    /// Tries code "1010999" with description containing "Otros Impuestos por Recuperar"
    /// </summary>
    /// <param name="empresaId">Company ID</param>
    /// <param name="ano">Year</param>
    /// <returns>Default IVA credit account if found</returns>
    Task<AccountDto?> GetDefaultIvaAccountAsync(int empresaId, short ano);

    /// <summary>
    /// Generates the actual opening voucher (Comprobante de Apertura) with MovComprobante entries
    /// Implements VB6 GenCompApertura logic:
    /// 1. Creates or replaces Comprobante record (TC_APERTURA type)
    /// 2. Generates MovComprobante entries for all accounts with non-zero balances
    /// 3. Adjusts result account (patrimonio) if Debe != Haber
    /// 4. Applies IVA remainder to IVA credit account
    /// 5. Updates EmpresasAno with IdCompAper
    /// </summary>
    /// <param name="request">Apertura request with configuration</param>
    /// <returns>Result with generated voucher information</returns>
    Task<AperturaResultDto> GenerateOpeningVoucherAsync(AperturaRequestDto request);
}
