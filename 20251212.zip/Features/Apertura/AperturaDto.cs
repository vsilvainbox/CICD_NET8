using System.ComponentModel.DataAnnotations;

namespace App.Features.Apertura;

/// <summary>
/// DTO for initialization data when loading the apertura form
/// </summary>
public class AperturaInitDataDto
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public string NombreEmpresa { get; set; } = string.Empty;

    // Opening Entry Info
    public int? IdCompAper { get; set; }
    public int NumCompAper { get; set; } = 1;
    public bool OpeningEntryExists { get; set; }
    public string WarningMessage { get; set; } = string.Empty;

    // Result Account (Cuenta de Resultado - where net profit/loss is posted)
    public int? IdCuentaResul { get; set; }
    public string DescCuentaResul { get; set; } = string.Empty;

    // IVA Credit Account (Cuenta de Crédito IVA - where IVA carryforward is posted)
    public int? IdCuentaCredIVA { get; set; }
    public string DescCuentaCredIVA { get; set; } = string.Empty;

    // IVA Remainder (Remanente IVA in UTM units)
    public double RemIVAUTM { get; set; }
    public bool RemIVAReadOnly { get; set; }
    public string RemIVASource { get; set; } = string.Empty; // "PreviousYearClose" or "ManualInput"

    public bool HasPreviousYear { get; set; }
}

/// <summary>
/// DTO for submitting apertura execution request
/// </summary>
public class AperturaRequestDto
{
    [Required]
    [Range(1, int.MaxValue, ErrorMessage = "EmpresaId es requerido")]
    public int EmpresaId { get; set; }

    [Required]
    [Range(1900, 2100, ErrorMessage = "Año debe estar entre 1900 y 2100")]
    public short Ano { get; set; }

    [Required]
    [Range(1, int.MaxValue, ErrorMessage = "Número de comprobante debe ser mayor a 0")]
    public int NumCompAper { get; set; }

    [Required]
    [Range(1, int.MaxValue, ErrorMessage = "Debe seleccionar cuenta de resultado")]
    public int IdCuentaResul { get; set; }

    [Required]
    [Range(1, int.MaxValue, ErrorMessage = "Debe seleccionar cuenta de crédito IVA")]
    public int IdCuentaCredIVA { get; set; }

    [Range(0, double.MaxValue, ErrorMessage = "Remanente IVA debe ser mayor o igual a 0")]
    public double RemIVAUTM { get; set; }
}

/// <summary>
/// DTO for the apertura form with client-side validation support
/// Contains all form fields with display properties for Tag Helpers
/// </summary>
public class AperturaFormDto
{
    [Required(ErrorMessage = "El número de comprobante es requerido")]
    [Range(1, int.MaxValue, ErrorMessage = "El número de comprobante debe ser mayor a 0")]
    [Display(Name = "Nº de comprobante de apertura")]
    public int NumCompAper { get; set; } = 1;

    [Required(ErrorMessage = "Debe seleccionar una cuenta de resultado")]
    [Range(1, int.MaxValue, ErrorMessage = "Debe seleccionar una cuenta de patrimonio")]
    [Display(Name = "Cuenta de resultado")]
    public int IdCuentaResul { get; set; }

    // Display field for result account (read-only, populated via modal)
    [Display(Name = "Cuenta de resultado")]
    public string? DescCuentaResul { get; set; }

    [Required(ErrorMessage = "Debe seleccionar una cuenta de crédito IVA")]
    [Range(1, int.MaxValue, ErrorMessage = "Debe seleccionar una cuenta de crédito IVA")]
    [Display(Name = "Cuenta de Crédito IVA")]
    public int IdCuentaCredIVA { get; set; }

    // Display field for IVA account (read-only, populated via modal)
    [Display(Name = "Cuenta de Crédito IVA")]
    public string? DescCuentaCredIVA { get; set; }

    [Range(0, double.MaxValue, ErrorMessage = "El remanente IVA debe ser mayor o igual a 0")]
    [Display(Name = "Remanente IVA año anterior (UTM)")]
    public double RemIVAUTM { get; set; }

    // Additional properties for UI state
    public bool RemIVAReadOnly { get; set; }
    public string? RemIVASourceInfo { get; set; }
}

/// <summary>
/// DTO for apertura execution result
/// </summary>
public class AperturaResultDto
{
    public string Message { get; set; } = string.Empty;
    public int NumCompAper { get; set; }
    public int? IdCompAper { get; set; }
    public int IdCuentaResul { get; set; }
    public int? IdCompAperTrib { get; set; }
    public double RemIVAUTM { get; set; }
}

/// <summary>
/// DTO for account selection (used in account picker)
/// </summary>
public class AccountDto
{
    public int IdCuenta { get; set; }
    public string Codigo { get; set; } = string.Empty;
    public string Descripcion { get; set; } = string.Empty;
    public string Nombre { get; set; } = string.Empty;
    public string FullDescription => $"{Codigo} - {Descripcion}";
}


/// <summary>
/// DTO for IVA remainder configuration
/// </summary>
public class AperturaIvaRemainderDto
{
    public double RemIVAUTM { get; set; }
    public bool IsReadOnly { get; set; }
    public string Source { get; set; } = string.Empty; // "PreviousYearClose" or "ManualInput"
    public string SourceDescription { get; set; } = string.Empty;
}
