# Feature Refactorizada - Balance Ejecutivo

**Fecha:** 2025-12-07
**Guía aplicada:** refactor.md

## Resumen de Cambios

Esta feature tenía **2 violaciones detectadas**:
- **R19**: JavaScript llamaba a WebController en vez de ApiController (proxy prohibido) - 1 violación
- **R20**: Uso de fetch manual en lugar de Api.* - 2 violaciones

Todas las violaciones han sido corregidas exitosamente.

---

## Detalle de Violaciones Corregidas

### R19: JavaScript → ApiController directo (NO proxy)

**Violación encontrada:**
- `BalanceEjecutivoController.cs` contenía métodos proxy:
  - `GenerarBalance([FromBody] JsonElement request)` - usaba `ProxyRequestAsync`
  - `ExportarExcel([FromBody] JsonElement request)` - usaba `DownloadFileAsync`
- `Index.cshtml` líneas 214-216: URLs apuntaban a `BalanceEjecutivo` (WebController)

**Corrección aplicada:**
- ✅ Eliminados métodos proxy `GenerarBalance` y `ExportarExcel` del WebController
- ✅ URLs actualizadas para apuntar directamente a `BalanceEjecutivoApi` (ApiController):
  ```javascript
  const URL_ENDPOINTS = {
      generarBalance: '@Url.Action("GenerarBalance", "BalanceEjecutivoApi")',
      exportarExcel: '@Url.Action("ExportarExcel", "BalanceEjecutivoApi")'
  };
  ```

**Archivo modificado:**
- `D:\deploy\Features\BalanceEjecutivo\BalanceEjecutivoController.cs` - Eliminadas líneas 33-69

---

### R20: SOLO Form POST o Api.* (prohibido fetch manual)

**Violaciones encontradas:**
1. `Index.cshtml` líneas 273-280: `fetch` manual en función `generarBalance()`
2. `Index.cshtml` líneas 368-375: `fetch` manual en función `exportarExcel()`

**Corrección aplicada:**

**1. Función generarBalance():**

❌ **ANTES** (fetch manual):
```javascript
try {
    const response = await fetch(URL_ENDPOINTS.generarBalance, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify(filtrosActuales)
    });

    if (!response.ok) {
        throw new Error('Error generando balance');
    }

    balanceActual = await response.json();
    mostrarBalance(balanceActual);
} catch (error) {
    console.error('Error:', error);
    window.handleFrontendError(error, 'Error', 'Se produjo un error en la operación.', 'Por favor, intente nuevamente.');
} finally {
    document.getElementById('loading').classList.add('hidden');
}
```

✅ **DESPUÉS** (Api.postJson):
```javascript
// R20: Usar Api.postJson en lugar de fetch manual
const resultado = await Api.postJson(URL_ENDPOINTS.generarBalance, filtrosActuales);

document.getElementById('loading').classList.add('hidden');

if (resultado) {
    balanceActual = resultado;
    mostrarBalance(balanceActual);
}
```

**2. Función exportarExcel():**

❌ **ANTES** (fetch manual + manejo de blob):
```javascript
try {
    const response = await fetch(URL_ENDPOINTS.exportarExcel, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify(filtrosActuales)
    });

    if (!response.ok) {
        throw new Error('Error exportando a Excel');
    }

    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `BalanceEjecutivo_${filtrosActuales.fechaDesde}_${filtrosActuales.fechaHasta}.xlsx`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);

    Swal.fire('Éxito', 'Balance exportado exitosamente', 'success');
} catch (error) {
    console.error('Error:', error);
    window.handleFrontendError(error, 'Error', 'Se produjo un error en la operación.', 'Por favor, intente nuevamente.');
} finally {
    document.getElementById('loading').classList.add('hidden');
}
```

✅ **DESPUÉS** (Api.downloadFile):
```javascript
// R20: Usar Api.downloadFile para descargas
const exito = await Api.downloadFile(
    URL_ENDPOINTS.exportarExcel,
    filtrosActuales,
    `BalanceEjecutivo_${filtrosActuales.fechaDesde}_${filtrosActuales.fechaHasta}.xlsx`
);

document.getElementById('loading').classList.add('hidden');

if (exito) {
    Swal.fire('Éxito', 'Balance exportado exitosamente', 'success');
}
```

**Archivos modificados:**
- `D:\deploy\Features\BalanceEjecutivo\Views\Index.cshtml` - Líneas 212-216, 270-280, 346-366

---

## Reglas Verificadas

### Service
- [x] R06 - Reutiliza lógica existente ✅
- [x] R15 - BusinessException para errores ✅
- [x] R17 - Tipos SQL correctos ✅
- [x] R22 - No usa Add/Update/Remove en entidades HasNoKey ✅

### ApiController
- [x] R02 - Sin try-catch ✅
- [x] R02 - Retorna Ok()/Ok(data) ✅
- [x] R06 - No duplica endpoints ✅

### WebController
- [x] R02 - Sin try-catch ✅
- [x] R03 - N/A (no llama a Service directo, solo renderiza vista) ✅
- [x] R04 - N/A (no hace llamadas HTTP) ✅
- [x] R16 - N/A (no usa HttpClient) ✅
- [x] **R19 - Eliminados métodos proxy** ✅

### Vista
- [x] R04 - URLs con @Url.Action apuntando a ApiController ✅
- [x] R07 - Header Dashboard ✅
- [x] R08 - Orden correcto: Filtros → Resultado ✅
- [x] R09 - N/A (no aplica empty state para este tipo de reporte) ✅
- [x] R10 - Tag helpers en formulario ✅
- [x] R11 - No hay botones pendientes ✅
- [x] R12 - Form con asp-action para búsqueda, JavaScript para CRUD ✅
- [x] R13 - Sin paginación ✅
- [x] R18 - N/A (no usa FormHandler, es búsqueda con JavaScript) ✅
- [x] **R19 - URLs apuntan a ApiController** ✅
- [x] **R20 - Solo Api.postJson y Api.downloadFile** ✅
- [x] R21 - N/A (no usa modales) ✅
- [x] CSS - bg-white en inputs ✅
- [x] CSS - Sin dark: ✅
- [x] CSS - Sin appearance-none en selects ✅

---

## Verificación de Correcciones

Se ejecutaron los siguientes comandos de verificación:

```powershell
# R19: Verificar que no existan métodos proxy
Select-String -Path "Features/BalanceEjecutivo/*Controller.cs" -Pattern "ProxyRequestAsync"
# Resultado: ✅ No se encontraron coincidencias

# R20: Verificar que no exista fetch manual
Select-String -Path "Features/BalanceEjecutivo/Views/*.cshtml" -Pattern "await\s+fetch\("
# Resultado: ✅ No se encontraron coincidencias

# R20: Verificar que no exista $.ajax
Select-String -Path "Features/BalanceEjecutivo/Views/*.cshtml" -Pattern "\.ajax\("
# Resultado: ✅ No se encontraron coincidencias

# R19: Verificar que no existan formularios proxy ocultos
Select-String -Path "Features/BalanceEjecutivo/Views/*.cshtml" -Pattern 'asp-action="[^"]+"\s+method="post".*style="display:\s*none'
# Resultado: ✅ No se encontraron coincidencias

# Verificar que URLs apunten a ApiController
Select-String -Path "Features/BalanceEjecutivo/Views/*.cshtml" -Pattern "BalanceEjecutivoApi"
# Resultado: ✅ 2 coincidencias encontradas (GenerarBalance, ExportarExcel)
```

---

## Archivos Modificados

### BalanceEjecutivoController.cs
**Cambios:**
- ❌ Eliminado método `GenerarBalance([FromBody] JsonElement request)` (líneas 33-48)
- ❌ Eliminado método `ExportarExcel([FromBody] JsonElement request)` (líneas 50-69)

**Estado final:**
- Solo contiene método `Index()` que renderiza la vista
- No hay métodos proxy (R19 ✅)

### Index.cshtml
**Cambios:**

1. **Líneas 212-216** - URLs actualizadas a ApiController:
   ```javascript
   // ANTES
   generarBalance: '@Url.Action("GenerarBalance", "BalanceEjecutivo")',
   exportarExcel: '@Url.Action("ExportarExcel", "BalanceEjecutivo")'

   // DESPUÉS
   generarBalance: '@Url.Action("GenerarBalance", "BalanceEjecutivoApi")',
   exportarExcel: '@Url.Action("ExportarExcel", "BalanceEjecutivoApi")'
   ```

2. **Líneas 270-280** - Función generarBalance() usa Api.postJson:
   - Eliminado bloque try-catch con fetch manual
   - Reemplazado por `Api.postJson(URL_ENDPOINTS.generarBalance, filtrosActuales)`

3. **Líneas 346-366** - Función exportarExcel() usa Api.downloadFile:
   - Eliminado bloque try-catch con fetch manual y manejo de blob
   - Reemplazado por `Api.downloadFile(URL_ENDPOINTS.exportarExcel, filtrosActuales, nombreArchivo)`

---

## Beneficios del Refactor

1. **Eliminación de capa proxy innecesaria (R19)**:
   - JavaScript ahora llama directamente al ApiController
   - Se eliminó código duplicado en el WebController
   - Flujo más directo: Vista → ApiController → Service

2. **Manejo de errores centralizado (R20)**:
   - `Api.postJson` y `Api.downloadFile` manejan errores automáticamente
   - SweetAlert se muestra automáticamente en caso de error
   - Código más limpio y mantenible

3. **Consistencia con el resto de la aplicación**:
   - Ahora usa el mismo patrón que otras features
   - Más fácil de entender para desarrolladores

---

## Notas Adicionales

- La feature mantiene toda su funcionalidad original
- El código es más simple y mantenible
- Se eliminaron ~40 líneas de código innecesario
- No se requieren cambios en el Service ni en el ApiController
- Los métodos del ApiController ya estaban correctamente implementados sin try-catch (R02 ✅)

---

## Estado Final

✅ **0 violaciones de R19 y R20**
✅ **Feature completamente refactorizada según refactor.md**
✅ **Código más limpio y mantenible**
