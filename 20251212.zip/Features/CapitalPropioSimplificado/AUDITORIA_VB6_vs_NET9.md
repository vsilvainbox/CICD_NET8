# AUDITORIA DE GAPS: Capital Propio Simplificado
## VB6 vs .NET 9

**Fecha de análisis:** 6 de diciembre de 2025
**Feature:** Capital Propio Tributario Simplificado - Artículo 14 D Ley de Renta
**Archivo VB6:** `D:\deploy\vb6\Contabilidad70\HyperContabilidad\FrmCapPropioSimpl.frm`
**Archivos .NET:** `D:\deploy\Features\CapitalPropioSimplificado\*`

---

## RESUMEN EJECUTIVO

### Porcentaje de Paridad General

| Categoría | Total Aspectos | Completos | Parciales | Faltantes | % Paridad |
|-----------|:-------------:|:---------:|:---------:|:---------:|:---------:|
| **Auditoría Estructural** | 71 | 42 | 18 | 11 | **73.2%** |
| **Auditoría Funcional** | 15 | 8 | 4 | 3 | **66.7%** |
| **TOTAL GENERAL** | **86** | **50** | **22** | **14** | **71.5%** |

### Estado del Proyecto

| Métrica | Valor |
|---------|-------|
| **Estado General** | 🟠 REQUIERE REVISIÓN (80-89%) |
| **Paridad de Funcionalidad** | 71.5% |
| **Gaps Críticos** | 6 |
| **Gaps Altos** | 8 |
| **Gaps Medios** | 8 |
| **Gaps Bajos** | 0 |
| **Recomendación** | Completar funcionalidades críticas antes de producción |

---

## INVENTARIO DE FUNCIONALIDADES VB6

### Botones y Acciones Principales

| Botón VB6 | Acción | Código Línea | Implementado .NET | Gap |
|-----------|--------|:------------:|:-----------------:|:---:|
| **Bt_Preview** | Vista previa de impresión | 905 | ⚠️ Parcial (window.print) | Media |
| **Bt_Print** | Imprimir reporte | 928 | ⚠️ Parcial (window.print) | Media |
| **Bt_CopyExcel** | Copiar a Excel | 945 | ⚠️ CSV básico | Media |
| **Bt_Sum** | Sumar movimientos seleccionados | 950 | ❌ Falta | Alta |
| **Bt_ConvMoneda** | Convertir moneda | 960 | ❌ Falta | Baja |
| **Bt_Calc** | Calculadora | 971 | ❌ Falta | Baja |
| **Bt_Calendar** | Calendario | 975 | ❌ Falta | Baja |
| **Bt_Manual** | Abrir manual PDF | 363 | ❌ Falta | Baja |
| **Bt_Cerrar** | Cerrar formulario | 335 | ✅ Implementado | - |

### Grilla Interactiva (Grid VB6)

| Funcionalidad | VB6 Línea | .NET | Gap |
|---------------|:---------:|:----:|:---:|
| **Grid editable** (FlexEdGrid3) | 19-39 | ⚠️ Inputs HTML | Media |
| **Doble clic en celda** para detalle | 1050 | ❌ Falta | Crítica |
| **Edición inline** con validación | 1027-1033 | ⚠️ Básica | Alta |
| **24 tipos de detalle modal** | 1064-1282 | ❌ Falta | Crítica |
| **Formateo numérico automático** | 1029 | ✅ Implementado | - |
| **Cálculo automático total** | 1286-1324 | ⚠️ Parcial | Alta |

### Formularios Modales Relacionados

| Formulario Modal VB6 | Línea | Propósito | .NET Equivalente | Gap |
|---------------------|:-----:|-----------|:----------------:|:---:|
| **FrmCapitalAportado** | 1068 | Detalle capital aportado | ❌ Falta | Crítica |
| **FrmDetCapPropioSimpl** | 1078+ | Detalle componentes CPS (múltiples tipos) | ❌ Falta | Crítica |
| **FrmBaseImponible14D** | 1090 | Base imponible 14D | ❌ Falta | Crítica |
| **FrmDetCapPropioSimplMini** | 1268 | Otros ajustes | ❌ Falta | Alta |
| **FrmPrintPreview** | 913 | Vista previa impresión | ⚠️ window.print() | Media |
| **FrmSumSimple** | 953 | Sumar valores seleccionados | ❌ Falta | Alta |
| **FrmConverMoneda** | 964 | Conversor de moneda | ❌ Falta | Baja |
| **FrmCalendar** | 979 | Selector de fecha | ❌ Falta | Baja |

### Queries y Persistencia

| Query VB6 | Línea | Tabla(s) | .NET Equivalente | Gap |
|-----------|:-----:|----------|:----------------:|:---:|
| **SELECT datos CPS** | 463-470 | EmpresasAno | ✅ ObtenerCPSAsync (L10) | - |
| **SELECT año anterior** | 485-497 | EmpresasAno | ✅ Service (L72-85) | - |
| **UPDATE al cerrar** | 336-358 | EmpresasAno | ✅ GuardarCPSAsync (L94) | - |
| **GetCPSAnual()** (función externa) | 525, 566+ | CapPropioSimplAnual | ❌ Falta | Alta |
| **DELETE detalle CPS** | 577, 604, 632+ | DetCapPropioSimpl | ❌ Falta | Alta |

### Tablas de Base de Datos Utilizadas

| Tabla | VB6 Uso | .NET Uso | Gap |
|-------|:-------:|:--------:|:---:|
| **EmpresasAno** | ✅ Lectura/Escritura | ✅ Lectura/Escritura | - |
| **DetCapPropioSimpl** | ✅ Detalle de componentes | ❌ No se usa | Crítica |
| **CapPropioSimplAnual** | ✅ Acumulados anuales | ❌ No se usa | Alta |
| **Empresas** | ✅ ProPymeGeneral, ProPymeTransp | ⚠️ TODO hardcoded | Alta |

---

## ANÁLISIS DETALLADO POR LOS 86 ASPECTOS

### 1. INPUTS / DEPENDENCIAS DE ENTRADA (6 aspectos)

| # | Aspecto | VB6 | .NET | Estado | Gap |
|---|---------|-----|------|:------:|:---:|
| 1 | **Variables globales** | `gEmpresa.id`, `gEmpresa.Ano`, `gEmpresa.ProPymeGeneral`, `gEmpresa.ProPymeTransp`, `gEmpresa.TieneAnoAnt` (L345, 401, 548, 1044) | SessionHelper.EmpresaId, SessionHelper.Ano (View L4-5); ProPyme hardcoded a false (Service L32-33) | ⚠️ Parcial | Alta |
| 2 | **Parámetros de entrada** | `FView(TipoInforme)` (L327-332) | `Index(TipoInformeCPS tipoInforme)` (Controller L12) | ✅ Completo | - |
| 3 | **Configuraciones** | `gIniFile` para mensaje 14DN8Ingresos (L403-408) | No implementado | ⚠️ Falta | Media |
| 4 | **Estado previo requerido** | Valida empresa activa (implícito en gEmpresa) | Asume empresaId/ano de sesión | ✅ Equivalente | - |
| 5 | **Datos maestros necesarios** | Año anterior (EmpresasAno) | ✅ Implementado (L72-85) | ✅ Completo | - |
| 6 | **Conexión/Sesión** | `DbMain` global | LpContabContext inyectado | ✅ Completo | - |

### 2. DATOS Y PERSISTENCIA (10 aspectos)

| # | Aspecto | VB6 | .NET | Estado | Gap |
|---|---------|-----|------|:------:|:---:|
| 7 | **Queries SELECT** | SELECT de 24 campos CPS (L463-470), año anterior (L485-497) | EF Core LINQ (Service L16-67) | ✅ Completo | - |
| 8 | **Queries INSERT** | No hay INSERT directo en este form | No hay INSERT | ✅ N/A | - |
| 9 | **Queries UPDATE** | `UpdateSQL` al cerrar con 24 campos (L336-358) | `SaveChangesAsync()` (Service L136) | ✅ Completo | - |
| 10 | **Queries DELETE** | `DeleteSQL` para limpiar DetCapPropioSimpl cuando ProPyme cambia (L577, 604, 632, 660, 761, 787, 813, 839) | ❌ No implementado | ❌ Falta | Crítica |
| 11 | **Stored Procedures** | No utiliza | No utiliza | ✅ N/A | - |
| 12 | **Tablas accedidas** | EmpresasAno, DetCapPropioSimpl (implícito en modales), CapPropioSimplAnual (función GetCPSAnual) | Solo EmpresasAno | ⚠️ Parcial | Crítica |
| 13 | **Campos leídos** | 24 campos CPS_* de EmpresasAno | 24 campos CPS_* | ✅ Completo | - |
| 14 | **Campos escritos** | CPS_CapPropioSimplificado, CPS_CapPropioSimplVarAnual, CPS_BaseImpPrimCat_14DN3/14DN8, CPS_CapPropioTribAnoAnt, CPS_RepPerdidaArrastre | Mismos campos (Service L110-134) | ✅ Completo | - |
| 15 | **Transacciones** | No explícitas (auto-commit) | No explícitas | ✅ Equivalente | - |
| 16 | **Concurrencia** | No maneja | No maneja | ✅ Equivalente | - |

### 3. ACCIONES Y OPERACIONES (6 aspectos)

| # | Aspecto | VB6 | .NET | Estado | Gap |
|---|---------|-----|------|:------:|:---:|
| 17 | **Botones/Acciones** | 9 botones: Preview, Print, CopyExcel, Sum, ConvMoneda, Calc, Calendar, Manual, Cerrar | 4 botones: Imprimir, Exportar, Guardar, Cerrar | ⚠️ Parcial | Alta |
| 18 | **Operaciones CRUD** | Solo Read + Update (al cerrar) | Read (GET Obtener) + Update (POST Guardar) | ✅ Completo | - |
| 19 | **Operaciones especiales** | GetCPSAnual() para cálculo acumulado (L525, 566, 593, 621, 649, 675, 689, 703, 718, 735, 751, 777, 803, 829, 855, 869) | ❌ No implementado | ❌ Falta | Alta |
| 20 | **Búsquedas** | No aplica (no es listado) | No aplica | ✅ N/A | - |
| 21 | **Ordenamiento** | No aplica | No aplica | ✅ N/A | - |
| 22 | **Paginación** | No aplica | No aplica | ✅ N/A | - |

### 4. VALIDACIONES (6 aspectos)

| # | Aspecto | VB6 | .NET | Estado | Gap |
|---|---------|-----|------|:------:|:---:|
| 23 | **Campos requeridos** | No hay validación explícita (solo cálculo) | No hay validación | ✅ Equivalente | - |
| 24 | **Validación de rangos** | No permite total negativo (L1314-1318) | No permite total negativo (Service L190) | ✅ Completo | - |
| 25 | **Validación de formato** | `vFmt()`, `Format()` para números (L346, 350, 353, 489, etc.) | formatNumber() JS (View L440-446) | ✅ Completo | - |
| 26 | **Validación de longitud** | No aplica | No aplica | ✅ N/A | - |
| 27 | **Validaciones custom** | Validación de tipo empresa ProPyme (L345-351, 548-575, 612-637) | ⚠️ Hardcoded a false (Service L32-33) | ❌ Falta | Alta |
| 28 | **Manejo de nulos** | `vFld()` para evitar nulls (L489, 512, etc.) | `?? 0` en Service (L43-66) | ✅ Completo | - |

### 5. CÁLCULOS Y LÓGICA (5 aspectos)

| # | Aspecto | VB6 | .NET | Estado | Gap |
|---|---------|-----|------|:------:|:---:|
| 29 | **Funciones de cálculo** | `CalcTot()` con 16 componentes (L1286-1324) | `CalcularTotalCPSAsync()` con 16 componentes (Service L144-193) | ✅ Completo | - |
| 30 | **Redondeos** | `Format(valor, NUMFMT)` (L1029) | `Math.Round()` en formatNumber JS (L445) | ✅ Completo | - |
| 31 | **Campos calculados** | Total CPS calculado en tiempo real (L1286) | Total calculado al cargar y guardar | ⚠️ Parcial | Media |
| 32 | **Dependencias campos** | `Grid_AcceptValue` recalcula total (L1027-1033) | `actualizarMonto()` NO recalcula total (View L330-334, TODO L337) | ❌ Falta | Crítica |
| 33 | **Valores por defecto** | Valores desde BD, 0 si null | Valores desde BD, 0 si null | ✅ Completo | - |

### 6. INTERFAZ Y UX (5 aspectos)

| # | Aspecto | VB6 | .NET | Estado | Gap |
|---|---------|-----|------|:------:|:---:|
| 34 | **Combos/Listas** | No hay combos | Radio buttons TipoInforme (View L38-47) | ✅ Completo | - |
| 35 | **Mensajes usuario** | `MsgBox1` al cargar (L399), mensajes de advertencia (L89-107) | SweetAlert en operaciones (View L353-368), advertencias estáticas (L120-133) | ✅ Completo | - |
| 36 | **Confirmaciones** | No hay confirmaciones | No hay confirmaciones | ✅ Equivalente | - |
| 37 | **Habilitaciones UI** | Habilita edición según modo (L1036-1047) | Todos los campos editables siempre (View L308-315) | ⚠️ Diferente | Media |
| 38 | **Formatos display** | `Format(valor, NUMFMT)` (múltiples líneas) | `formatNumber()` JS (View L440) | ✅ Completo | - |

### 7. SEGURIDAD (2 aspectos)

| # | Aspecto | VB6 | .NET | Estado | Gap |
|---|---------|-----|------|:------:|:---:|
| 39 | **Permisos requeridos** | No valida permisos explícitos | No valida permisos | ✅ Equivalente | - |
| 40 | **Validación acceso** | Implícito en menú principal | [Authorize] implícito en Controller | ✅ Equivalente | - |

### 8. MANEJO DE ERRORES (2 aspectos)

| # | Aspecto | VB6 | .NET | Estado | Gap |
|---|---------|-----|------|:------:|:---:|
| 41 | **Captura errores** | Implícito (On Error Goto en módulos base) | try/catch en JS (View L213-225), service sin try/catch | ⚠️ Parcial | Media |
| 42 | **Mensajes de error** | `MsgBox1` con descripción | SweetAlert con mensaje genérico (View L216-220) | ✅ Completo | - |

### 9. OUTPUTS / SALIDAS (6 aspectos)

| # | Aspecto | VB6 | .NET | Estado | Gap |
|---|---------|-----|------|:------:|:---:|
| 43 | **Datos de retorno** | Guarda en BD al cerrar (L335-361) | POST Guardar explícito | ✅ Completo | - |
| 44 | **Exportar Excel** | `LP_FGr2Clip()` copia grid a Excel (L946) | CSV básico (View L371-429) | ⚠️ Parcial | Media |
| 45 | **Exportar PDF** | No tiene PDF directo, usa impresión | No implementado | ✅ Equivalente | - |
| 46 | **Exportar CSV/Texto** | No tiene CSV | ✅ CSV implementado (View L384-403) | ✅ Completo | - |
| 47 | **Impresión** | `PrtFlexGrid()` con preview (L905-925, 928-942) | window.print() + CSS (View L58, 453-515) | ⚠️ Parcial | Media |
| 48 | **Llamadas a otros módulos** | Abre 7 formularios modales (L1068-1280) | ❌ No abre modales de detalle | ❌ Falta | Crítica |

### 10. PARIDAD DE CONTROLES UI (6 aspectos)

| # | Aspecto | VB6 | .NET | Estado | Gap |
|---|---------|-----|------|:------:|:---:|
| 49 | **TextBoxes** | Tx_CapPropio (solo lectura, L40-59), Tx_TotCapPropio (solo lectura, L60-80) | `<span id="totalCPS">` (View L113) | ✅ Equivalente | - |
| 50 | **Labels/Etiquetas** | Label1(0), Label1(1) con instrucciones (L88-107) | Advertencias estáticas (View L120-133) | ✅ Completo | - |
| 51 | **ComboBoxes/Selects** | No hay combos | Radio buttons TipoInforme | ✅ Equivalente | - |
| 52 | **Grids/Tablas** | FlexEdGrid3.FEd3Grid con edición inline (L19-39) | `<table>` HTML con inputs (View L88-107) | ⚠️ Parcial | Media |
| 53 | **CheckBoxes** | No hay checkboxes | No hay checkboxes | ✅ N/A | - |
| 54 | **Campos ocultos/IDs** | lRowCapAportado, lRowBaseImp, etc. (variables row index, L303-323) | Campos identificados por índice en JS | ✅ Equivalente | - |

### 11. GRIDS Y COLUMNAS (2 aspectos)

| # | Aspecto | VB6 | .NET | Estado | Gap |
|---|---------|-----|------|:------:|:---:|
| 55 | **Columnas del grid** | C_TITULO (5600px), C_MONTO (1500px), C_SIGNO (400px), C_FMT (oculto), C_OBLIGATORIA (oculto) (L423-427) | Componente (flex), Monto (200px), Signo (80px) (View L91-99) | ✅ Completo | - |
| 56 | **Datos del grid** | LoadAll() carga 24 componentes según tipo empresa y año (L435-903) | renderizarComponentes() carga dinámicamente (View L228-296) | ✅ Completo | - |

### 12. EVENTOS E INTERACCIÓN (5 aspectos)

| # | Aspecto | VB6 | .NET | Estado | Gap |
|---|---------|-----|------|:------:|:---:|
| 57 | **Doble clic** | `Grid_DblClick()` abre formularios modales de detalle (L1050-1285) | ❌ No implementado | ❌ Falta | Crítica |
| 58 | **Teclas especiales** | `Grid_EditKeyPress` para validar entrada numérica (L1326-1333) | No implementado | ⚠️ Falta | Media |
| 59 | **Eventos Change** | `Grid_AcceptValue` recalcula total (L1027-1033) | `onchange="actualizarMonto()"` formatea pero NO recalcula (View L312, L330-334) | ❌ Falta | Crítica |
| 60 | **Menú contextual** | No tiene menú contextual | No tiene menú contextual | ✅ N/A | - |
| 61 | **Modales Lookup** | 7 formularios modales con retorno de valores (L1068-1280) | ❌ No implementado | ❌ Falta | Crítica |

### 13. ESTADOS Y MODOS DEL FORMULARIO (3 aspectos)

| # | Aspecto | VB6 | .NET | Estado | Gap |
|---|---------|-----|------|:------:|:---:|
| 62 | **Modos del form** | `lTipoInforme` (CPS_TIPOINFO_GENERAL=0, CPS_TIPOINFO_VARANUAL=1) (L301, 327) | `TipoInformeCPS` enum (Dto L3-7) | ✅ Completo | - |
| 63 | **Controles por modo** | Habilita edición solo en Variación Anual para ciertos campos (L1036-1047) | Todos editables siempre | ⚠️ Diferente | Media |
| 64 | **Orden de tabulación** | No crítico en este form | No crítico | ✅ N/A | - |

### 14. INICIALIZACIÓN Y CARGA (3 aspectos)

| # | Aspecto | VB6 | .NET | Estado | Gap |
|---|---------|-----|------|:------:|:---:|
| 65 | **Carga inicial** | `Form_Load()` ejecuta SetUpGrid + LoadAll + MsgBox (L386-411) | Carga manual al presionar botón (View L190-226) | ⚠️ Diferente | Media |
| 66 | **Valores por defecto** | Carga desde BD, 0 si null | Carga desde BD, 0 si null | ✅ Completo | - |
| 67 | **Llenado de combos** | No hay combos | No hay combos | ✅ N/A | - |

### 15. FILTROS Y BÚSQUEDA (2 aspectos)

| # | Aspecto | VB6 | .NET | Estado | Gap |
|---|---------|-----|------|:------:|:---:|
| 68 | **Campos de filtro** | No aplica (no es listado) | No aplica | ✅ N/A | - |
| 69 | **Criterios de búsqueda** | No aplica | No aplica | ✅ N/A | - |

### 16. REPORTES E IMPRESIÓN (2 aspectos)

| # | Aspecto | VB6 | .NET | Estado | Gap |
|---|---------|-----|------|:------:|:---:|
| 70 | **Reportes disponibles** | Vista previa + Impresión con `gPrtReportes.PrtFlexGrid()` (L905-925, 928-942) | window.print() + CSS @media print (View L453-515) | ⚠️ Parcial | Media |
| 71 | **Parámetros de reporte** | Titulos[], Encabezados[], ColWi[], año (L987-1025) | CSS personalizado con año en variables JS (View L164) | ⚠️ Parcial | Media |

---

## AUDITORÍA FUNCIONAL (15 aspectos)

### 17. REGLAS DE NEGOCIO (4 aspectos)

| # | Aspecto | VB6 | .NET | Estado | Gap |
|---|---------|-----|------|:------:|:---:|
| 72 | **Umbrales y límites** | Total CPS no puede ser negativo (L1314-1318) | Total CPS no puede ser negativo (Service L190) | ✅ Completo | - |
| 73 | **Fórmulas de cálculo** | Fórmula con +/- según componente (L1289-1311) | Misma fórmula (Service L148-187) | ✅ Completo | - |
| 74 | **Condiciones de negocio** | ProPymeGeneral vs ProPymeTransp afecta componentes visibles (L345-351, 548-844) | ⚠️ Hardcoded a false (Service L32-33) | ❌ Falta | Crítica |
| 75 | **Restricciones** | CTDImputableIPE solo hasta año 2021 para ProPymeTransp (L726-740) | Validación implementada (Service L169-172, View L271-274) | ✅ Completo | - |

### 18. FLUJOS DE TRABAJO (3 aspectos)

| # | Aspecto | VB6 | .NET | Estado | Gap |
|---|---------|-----|------|:------:|:---:|
| 76 | **Secuencia de estados** | No aplica (no es workflow) | No aplica | ✅ N/A | - |
| 77 | **Acciones por estado** | Edición habilitada según modo y campo (L1036-1047) | Todos editables siempre | ⚠️ Diferente | Media |
| 78 | **Transiciones válidas** | No aplica | No aplica | ✅ N/A | - |

### 19. INTEGRACIONES ENTRE MÓDULOS (3 aspectos)

| # | Aspecto | VB6 | .NET | Estado | Gap |
|---|---------|-----|------|:------:|:---:|
| 79 | **Llamadas a otros módulos** | 7 formularios modales: FrmCapitalAportado, FrmDetCapPropioSimpl (múltiples tipos), FrmBaseImponible14D, FrmDetCapPropioSimplMini (L1068-1280) | ❌ No implementado | ❌ Falta | Crítica |
| 80 | **Parámetros de integración** | TipoDetCPS, código artículo, lTipoInforme, retorno por referencia (valor As Double) (L1069, 1079, 1091) | No aplica | ❌ Falta | Crítica |
| 81 | **Datos compartidos/retorno** | Modales retornan valor actualizado, actualizan grid (L1072-1084) | No aplica | ❌ Falta | Crítica |

### 20. MENSAJES AL USUARIO (2 aspectos)

| # | Aspecto | VB6 | .NET | Estado | Gap |
|---|---------|-----|------|:------:|:---:|
| 82 | **Mensajes de error** | "No se encontró el archivo Manual_CPT_Simplificado.pdf" (L374), "Error X al abrir" (L379) | Mensajes genéricos en SweetAlert (View L216-220) | ⚠️ Parcial | Media |
| 83 | **Mensajes de confirmación** | No hay confirmaciones | No hay confirmaciones | ✅ N/A | - |

### 21. CASOS BORDE Y VALORES ESPECIALES (3 aspectos)

| # | Aspecto | VB6 | .NET | Estado | Gap |
|---|---------|-----|------|:------:|:---:|
| 84 | **Valores cero** | Permite valores 0, se muestra como "0" (L512, 549, etc.) | Permite valores 0 | ✅ Completo | - |
| 85 | **Valores negativos** | Permite montos negativos en base imponible (signo +/-), pero total CPS no negativo (L1314-1318) | Mismo comportamiento (Service L190) | ✅ Completo | - |
| 86 | **Valores nulos/vacíos** | `vFld()` convierte null a 0 (múltiples líneas) | `?? 0` convierte null a 0 (Service L43-66) | ✅ Completo | - |

---

## RESUMEN DE GAPS IDENTIFICADOS

### GAPS CRÍTICOS (Bloquean funcionalidad core)

| # | Gap | VB6 | .NET | Impacto | Prioridad |
|---|-----|-----|------|---------|:---------:|
| **G-01** | **Doble clic para abrir detalle** | Grid_DblClick() abre 7 formularios modales de detalle según fila (L1050-1285) | ❌ No implementado | Usuario no puede ingresar/editar detalle de componentes | **CRÍTICA** |
| **G-02** | **24 tipos de detalle modal** | FrmDetCapPropioSimpl con 24 tipos diferentes (CPS_AUMENTOSCAP, CPS_PARTICIPACIONES, CPS_DISMINUCIONES, etc.) | ❌ No implementado | No se pueden gestionar detalles de: Aumentos Capital, Participaciones, Disminuciones, Gastos Rechazados, Retiros/Dividendos, INR Propios, etc. | **CRÍTICA** |
| **G-03** | **Tabla DetCapPropioSimpl no usada** | DELETE/INSERT en DetCapPropioSimpl (L577, 604, 632, 660, 761, 787, 813, 839) | ❌ Tabla no se usa | Pérdida de trazabilidad de movimientos de detalle | **CRÍTICA** |
| **G-04** | **GetCPSAnual() no implementado** | Función que obtiene datos anuales de CapPropioSimplAnual (L525, 566, 593, etc.) | ❌ No implementado | En modo Variación Anual no se obtienen datos correctos | **CRÍTICA** |
| **G-05** | **Recálculo automático al editar** | Grid_AcceptValue() recalcula total (L1027-1033) | actualizarMonto() solo formatea, TODO en L337 | Usuario edita pero total no se actualiza hasta guardar | **CRÍTICA** |
| **G-06** | **Validación ProPyme hardcoded** | gEmpresa.ProPymeGeneral, gEmpresa.ProPymeTransp controlan componentes visibles (L345-844) | Hardcoded a false (Service L32-33) | Componentes incorrectos según tipo de empresa | **CRÍTICA** |

### GAPS ALTOS (Funcionalidad secundaria faltante)

| # | Gap | VB6 | .NET | Impacto | Prioridad |
|---|-----|-----|------|---------|:---------:|
| **G-07** | **Botón Sumar selección** | Bt_Sum abre FrmSumSimple (L950-959) | ❌ No implementado | Usuario no puede sumar valores seleccionados | **ALTA** |
| **G-08** | **Modal FrmBaseImponible14D** | Abre form específico para base imponible 14D (L1090-1097) | ❌ No implementado | No se puede editar base imponible con asistente | **ALTA** |
| **G-09** | **Modal FrmCapitalAportado** | Detalle de capital aportado (L1068-1074) | ❌ No implementado | No se puede detallar capital aportado | **ALTA** |
| **G-10** | **Modal FrmDetCapPropioSimplMini** | Otros ajustes (L1268-1280) | ❌ No implementado | No se pueden detallar otros ajustes | **ALTA** |
| **G-11** | **Tabla CapPropioSimplAnual no usada** | GetCPSAnual() consulta acumulados (L525, 566, etc.) | ❌ No implementado | Sin histórico de movimientos anuales | **ALTA** |
| **G-12** | **Configuración ProPyme desde BD** | Lee ProPymeGeneral/ProPymeTransp de Empresas (L345, 548, 612) | ⚠️ TODO: Verificar campos (Service L31-33) | Lógica de negocio incorrecta | **ALTA** |
| **G-13** | **Edición inline con validación numérica** | Grid_EditKeyPress valida KeyNumPos/KeyNum (L1326-1333) | Solo formateo básico | Usuario puede ingresar texto en campos numéricos | **ALTA** |
| **G-14** | **Modo solo lectura en TipoInforme General** | BeforeEdit bloquea edición según row y modo (L1035-1048) | Todos editables siempre | Usuario puede editar campos que no debería | **ALTA** |

### GAPS MEDIOS (UX diferente o funcionalidad legacy)

| # | Gap | VB6 | .NET | Impacto | Prioridad |
|---|-----|-----|------|---------|:---------:|
| **G-15** | **Vista previa de impresión** | FrmPrintPreview con formato profesional (L905-925) | window.print() básico | Impresión menos profesional | **MEDIA** |
| **G-16** | **Copiar a Excel** | LP_FGr2Clip() con formato FlexGrid (L946) | CSV básico | Exportación menos amigable | **MEDIA** |
| **G-17** | **SetUpPrtGrid personalizado** | Configura títulos, encabezados, anchos columna (L987-1025) | CSS genérico | Impresión sin customización | **MEDIA** |
| **G-18** | **Configuración INI para mensajes** | GetIniString/SetIniString para mostrar mensaje solo 1 vez (L403-408) | Mensaje siempre visible o nunca visible | UX diferente en advertencias | **MEDIA** |
| **G-19** | **Carga automática al abrir** | Form_Load() carga datos automáticamente (L386-411) | Usuario debe presionar "Cargar" | Paso extra para usuario | **MEDIA** |
| **G-20** | **Textos de solo lectura con formato** | Tx_CapPropio, Tx_TotCapPropio con colores y estilos (L40-80) | Solo span con total | Menos visual | **MEDIA** |
| **G-21** | **Grid con estilos VB6** | FlxGrid.BackColorFixed, BackColor, GridColor (L429-431) | Estilos TailwindCSS modernos | Diferente pero equivalente | **MEDIA** |
| **G-22** | **Manejo de errores en Service** | Implícito en módulos base VB6 | No hay try/catch en Service | Errores no controlados en backend | **MEDIA** |

### GAPS BAJOS (Funcionalidad auxiliar no crítica)

| # | Gap | VB6 | .NET | Impacto | Prioridad |
|---|-----|-----|------|---------|:---------:|
| **G-23** | **Botón Manual PDF** | Bt_Manual abre Manual_CPT_Simplificado.pdf (L363-384) | ❌ No implementado | Usuario no accede a ayuda contextual | **BAJA** |
| **G-24** | **Botón Convertir Moneda** | Bt_ConvMoneda abre FrmConverMoneda (L960-969) | ❌ No implementado | Usuario no puede convertir monedas | **BAJA** |
| **G-25** | **Botón Calculadora** | Bt_Calc llama función Calculadora() (L971-973) | ❌ No implementado | Usuario no puede usar calculadora integrada | **BAJA** |
| **G-26** | **Botón Calendario** | Bt_Calendar abre FrmCalendar (L975-985) | ❌ No implementado | Usuario no puede abrir calendario | **BAJA** |

---

## MEJORAS EN .NET SOBRE VB6

| # | Mejora | Descripción | Beneficio |
|---|--------|-------------|-----------|
| **M-01** | **Arquitectura MVC + API** | Separación Controller → ApiController → Service vs monolítico VB6 | Mantenibilidad, escalabilidad, testabilidad |
| **M-02** | **Inyección de dependencias** | ICapitalPropioSimplificadoService inyectado vs variables globales VB6 | Código más limpio, testeable |
| **M-03** | **async/await** | Operaciones asíncronas en Service | Mejor performance, no bloquea UI |
| **M-04** | **Entity Framework Core** | LINQ vs queries SQL concatenados | Seguridad (SQL injection), tipado fuerte |
| **M-05** | **DTOs tipados** | CapitalPropioSimplificadoDto vs variables dinámicas VB6 | Type safety, validación automática |
| **M-06** | **TailwindCSS moderno** | UI moderna responsive vs controles VB6 | Mejor UX, accesible desde cualquier dispositivo |
| **M-07** | **SweetAlert profesional** | Modales elegantes vs MsgBox básico | Mejor experiencia de usuario |
| **M-08** | **Exportación CSV nativa** | Función JS vs dependencias ActiveX | No requiere componentes externos |
| **M-09** | **CSS @media print** | Impresión personalizada sin componentes extra | Funciona en cualquier navegador |
| **M-10** | **Estado inicial guiado** | Pantalla de bienvenida explicativa vs formulario vacío | Mejor onboarding de usuario |
| **M-11** | **Loading spinner** | Indicador de carga vs pantalla congelada | Usuario sabe que está procesando |
| **M-12** | **Iconografía Font Awesome** | Iconos modernos vs imágenes embebidas .frx | Escalable, profesional |
| **M-13** | **Logging estructurado** | ILogger con contexto vs Debug.Print | Trazabilidad en producción |
| **M-14** | **Enum TipoInformeCPS** | Enum fuertemente tipado vs constantes numéricas | Menos errores, IntelliSense |

---

## RECOMENDACIONES

### CRÍTICAS (Implementar ANTES de producción)

1. **[G-01, G-02, G-79, G-80, G-81] Implementar Modales de Detalle**
   - Crear componentes modales para:
     - Capital Aportado
     - Aumentos de Capital (con grid de movimientos)
     - Base Imponible 14D (con asistente)
     - Participaciones, Disminuciones, Gastos Rechazados, Retiros/Dividendos (con grid de documentos)
     - INR Propios, Utilidades Pérdida, Ingreso Diferido, CTD Imputable, Incentivo Ahorro, IDPC Voluntario (con detalle manual)
     - Crédito Activos Fijos, Crédito Participaciones (con detalle)
     - Otros Ajustes (con mini-grid)
   - Implementar doble clic en fila para abrir modal correspondiente
   - Retornar valor actualizado y actualizar campo en tabla principal

2. **[G-03, G-04, G-11] Utilizar Tablas de Detalle**
   - Implementar CRUD en `DetCapPropioSimpl` para guardar movimientos de detalle
   - Implementar `GetCPSAnual()` que consulte `CapPropioSimplAnual` para modo Variación Anual
   - Agregar endpoints API para estas operaciones

3. **[G-05] Recálculo Automático en Tiempo Real**
   - Implementar `recalcularTotal()` en View (L337 TODO)
   - Llamar a `CalcularTotal` API endpoint al cambiar valores
   - Actualizar total CPS dinámicamente

4. **[G-06, G-12] Leer ProPyme desde BD**
   - Agregar campos `ProPymeGeneral`, `ProPymeTransp` a entity Empresas
   - Leer desde BD en Service (L32-33)
   - Aplicar lógica de componentes visibles según tipo empresa

### ALTAS (Implementar para paridad completa)

5. **[G-07] Botón Sumar Selección**
   - Implementar checkbox en cada fila de tabla
   - Agregar botón "Sumar Seleccionados"
   - Mostrar modal con suma total de filas seleccionadas

6. **[G-13, G-14] Validación y Modo de Edición**
   - Validar entrada numérica en inputs (solo dígitos, punto decimal)
   - Deshabilitar campos no editables según `TipoInforme` y reglas de negocio
   - Implementar lógica `BeforeEdit` equivalente

### MEDIAS (Mejoras UX)

7. **[G-15, G-16, G-17] Mejorar Impresión/Exportación**
   - Crear endpoint `/CapitalPropioSimplificado/ImprimirPDF` con generador PDF profesional
   - Implementar exportación real a Excel con formato (EPPlus/ClosedXML)
   - Agregar logo, encabezados personalizados, pie de página

8. **[G-18] Configuración de Mensajes**
   - Implementar sistema de "mostrar solo una vez" usando localStorage JS
   - O tabla de configuración por usuario en BD

9. **[G-19] Carga Automática Opcional**
   - Agregar checkbox "Cargar automáticamente al abrir" en configuración usuario
   - Si está activo, ejecutar `cargarDatos()` en DOMContentLoaded

### BAJAS (Opcionales, mejoran experiencia)

10. **[G-23, G-24, G-25, G-26] Botones Auxiliares**
    - Agregar enlace a manual PDF en sección de ayuda
    - Integrar conversor de moneda con API externa
    - Agregar botón calculadora que abra modal con calculadora JS
    - Integrar date picker en campos de fecha

### MEJORAS ADICIONALES (No bloqueantes)

11. **Validaciones FluentValidation**
    - Agregar validaciones en `CapitalPropioSimplificadoDto`
    - Validar rangos, campos requeridos según tipo empresa

12. **Unit Tests**
    - Tests para `CalcularTotalCPSAsync()` con diferentes escenarios
    - Tests para lógica ProPyme General vs Transparente
    - Tests para modo General vs Variación Anual

13. **Logging mejorado**
    - Agregar logging en Service al guardar (qué campos cambiaron)
    - Log de cálculo de total con breakdown de componentes

14. **Manejo de Errores Robusto**
    - Agregar try/catch en Service con mensajes específicos
    - Retornar errores detallados a frontend
    - Mostrar errores de validación en SweetAlert con detalle

---

## PLAN DE ACCIÓN SUGERIDO

### Fase 1: Funcionalidad Core (2-3 semanas)

- [ ] **Semana 1:** Implementar modales de detalle (G-01, G-02)
  - Modal genérico reutilizable con grid editable
  - Integración con API para CRUD en `DetCapPropioSimpl`

- [ ] **Semana 2:** Tablas de detalle y cálculo anual (G-03, G-04, G-11)
  - Endpoint `/api/CapitalPropioSimplificado/GetCPSAnual`
  - CRUD completo para `DetCapPropioSimpl` y `CapPropioSimplAnual`

- [ ] **Semana 3:** Recálculo automático y ProPyme (G-05, G-06, G-12)
  - Endpoint `/api/CapitalPropioSimplificado/CalcularTotal`
  - Lectura de campos ProPyme desde BD
  - Lógica de componentes visibles

### Fase 2: Paridad Completa (1-2 semanas)

- [ ] **Semana 4:** Validaciones y UX (G-07, G-13, G-14)
  - Botón Sumar selección
  - Validación numérica
  - Modo de edición según tipo informe

### Fase 3: Mejoras (1 semana)

- [ ] **Semana 5:** Impresión/Exportación profesional (G-15, G-16, G-17)
  - PDF con diseño profesional
  - Excel con formato

### Fase 4: Opcionales (según prioridad)

- [ ] Botones auxiliares (G-23 a G-26)
- [ ] Tests unitarios
- [ ] Mejoras de logging

---

## CONCLUSIÓN

### Veredicto

| Aspecto | Evaluación |
|---------|-----------|
| **Paridad Funcional** | 71.5% - Requiere mejoras significativas |
| **Funcionalidad Core** | ❌ INCOMPLETA - Falta sistema de detalle modal |
| **Listo para Producción** | ❌ NO - Implementar gaps críticos primero |
| **Calidad de Código .NET** | ✅ BUENA - Arquitectura sólida, mejorable |
| **Experiencia de Usuario** | ⚠️ ACEPTABLE - Falta interactividad de VB6 |

### Riesgo de Migración

🔴 **RIESGO ALTO** - La ausencia de modales de detalle y tablas `DetCapPropioSimpl`/`CapPropioSimplAnual` representa una pérdida crítica de funcionalidad respecto a VB6. Usuarios no podrán gestionar el detalle de componentes CPS.

### Recomendación Final

**NO DEPLOY A PRODUCCIÓN** sin implementar:
1. Sistema de modales de detalle (G-01, G-02)
2. Uso de tablas de detalle (G-03, G-04, G-11)
3. Recálculo automático (G-05)
4. Lectura de ProPyme desde BD (G-06, G-12)

**Esfuerzo estimado para paridad mínima:** 3-4 semanas de desarrollo + 1 semana de testing.

**Paridad aceptable (90%+) alcanzable en 5-6 semanas** implementando Fases 1 y 2 del plan de acción.

---

**Auditado por:** Claude Opus 4.5
**Fecha:** 6 de diciembre de 2025
**Versión del reporte:** 1.0
