using Microsoft.AspNetCore.Mvc;

namespace App.Features.CapitalPropioSimplificado;

[ApiController]
[Route("[controller]/[action]")]
public class CapitalPropioSimplificadoApiController(
    ICapitalPropioSimplificadoService service,
    ILogger<CapitalPropioSimplificadoApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<CapitalPropioSimplificadoDto>> Obtener(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        [FromQuery] TipoInformeCPS tipoInforme)
    {
        logger.LogInformation("API: Obtener CPS llamado");

        {
            var datos = await service.ObtenerCPSAsync(empresaId, ano, tipoInforme);
            return Ok(datos);
        }
    }

    [HttpPost]
    public async Task<IActionResult> Guardar([FromBody] CapitalPropioSimplificadoDto datos)
    {
        logger.LogInformation("API: Guardar CPS llamado");

        await service.GuardarCPSAsync(datos);
        return Ok();
    }

    [HttpPost]
    public async Task<ActionResult<decimal>> CalcularTotal([FromBody] CapitalPropioSimplificadoDto datos)
    {
        {
            var total = await service.CalcularTotalCPSAsync(datos);
            return Ok(total);
        }
    }
}
