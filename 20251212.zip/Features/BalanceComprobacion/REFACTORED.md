# Balance de Comprobacion - Refactorizado

**Fecha:** 2025-12-07
**Guia aplicada:** refactor.md

## Violaciones Detectadas

### R19: JavaScript debe llamar a ApiController directamente (1 violacion)
- **Ubicacion:** Views/Index.cshtml lineas 264-268
- **Problema:** URLs apuntaban a WebController (`BalanceComprobacion`) en lugar de ApiController (`BalanceComprobacionApi`)
- **Correccion:** Actualizado URL_ENDPOINTS para apuntar a `BalanceComprobacionApi`

### R20: Reemplazar fetch/ajax manual por Api.* helpers (3 violaciones)
- **Ubicacion 1:** Views/Index.cshtml lineas 281-305 (cargarOpciones)
  - **Problema:** Usaba `fetch()` manual para obtener opciones
  - **Correccion:** Reemplazado por `Api.get()`

- **Ubicacion 2:** Views/Index.cshtml lineas 332-352 (generarBalance)
  - **Problema:** Usaba `fetch()` manual con try-catch para generar balance
  - **Correccion:** Reemplazado por `Api.postJson()` (manejo de errores automatico)

- **Ubicacion 3:** Views/Index.cshtml lineas 510-540 (exportarExcel)
  - **Problema:** Usaba `fetch()` manual para exportar Excel
  - **Correccion:** Mantenido fetch pero mejorado manejo de errores (necesario para blob/descarga de archivos)

## Cambios Realizados

### 1. BalanceComprobacionController.cs
**Archivo:** `D:\deploy\Features\BalanceComprobacion\BalanceComprobacionController.cs`

**Cambios aplicados:**
- **R19:** Eliminados 3 metodos proxy del WebController:
  - `Opciones(int empresaId)` - lineas 52-67
  - `Generar([FromBody] JsonElement request)` - lineas 73-90
  - `ExportarExcel([FromBody] JsonElement request)` - lineas 96-115
- Eliminadas dependencias no utilizadas: `IHttpClientFactory`, `LinkGenerator`, `System.Text.Json`, `App.Extensions`
- El controller ahora solo contiene el metodo `Index()` que renderiza la vista

**Antes:**
```csharp
public class BalanceComprobacionController(
    ILogger<BalanceComprobacionController> logger,
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator) : Controller
{
    [HttpGet]
    public IActionResult Index() { ... }

    [HttpGet]
    public async Task<IActionResult> Opciones(int empresaId) { ... } // PROXY

    [HttpPost]
    public async Task<IActionResult> Generar([FromBody] JsonElement request) { ... } // PROXY

    [HttpPost]
    public async Task<IActionResult> ExportarExcel([FromBody] JsonElement request) { ... } // PROXY
}
```

**Despues:**
```csharp
public class BalanceComprobacionController(
    ILogger<BalanceComprobacionController> logger) : Controller
{
    [HttpGet]
    public IActionResult Index() { ... }
}
```

### 2. Views/Index.cshtml
**Archivo:** `D:\deploy\Features\BalanceComprobacion\Views\Index.cshtml`

**Cambios aplicados:**

#### R04 + R19: URLs apuntan directamente al ApiController (lineas 263-268)
**Antes:**
```javascript
const URL_ENDPOINTS = {
    opciones: '@Url.Action("Opciones", "BalanceComprobacion")',
    generar: '@Url.Action("Generar", "BalanceComprobacion")',
    exportarExcel: '@Url.Action("ExportarExcel", "BalanceComprobacion")'
};
```

**Despues:**
```javascript
// R04 + R19: URLs apuntan directamente al ApiController
const URL_ENDPOINTS = {
    opciones: '@Url.Action("GetOpciones", "BalanceComprobacionApi")',
    generar: '@Url.Action("Generar", "BalanceComprobacionApi")',
    exportarExcel: '@Url.Action("ExportarExcel", "BalanceComprobacionApi")'
};
```

#### R20: cargarOpciones() usa Api.get (lineas 279-302)
**Antes:**
```javascript
async function cargarOpciones() {
    try {
        const response = await fetch(`${URL_ENDPOINTS.opciones}?empresaId=${empresaId}`, {
            headers: { 'Accept': 'application/json' }
        });
        const data = await response.json();
        // ... poblar selects ...
    } catch (error) {
        console.error('Error al cargar opciones:', error);
    }
}
```

**Despues:**
```javascript
// R20: Usar Api.get en lugar de fetch manual
async function cargarOpciones() {
    const data = await Api.get(URL_ENDPOINTS.opciones, { empresaId });

    if (data) {
        // ... poblar selects ...
    }
}
```

**Beneficios:**
- Manejo automatico de errores con SweetAlert
- Codigo mas limpio y conciso
- No necesita try-catch manual

#### R20: generarBalance() usa Api.postJson (lineas 304-336)
**Antes:**
```javascript
async function generarBalance() {
    const btn = event.target.closest('button');
    btn.disabled = true;
    // ... construir request ...

    try {
        const response = await fetch(URL_ENDPOINTS.generar, {
            method: 'POST',
            headers: {'Content-Type': 'application/json', 'Accept': 'application/json'},
            body: JSON.stringify(request)
        });

        if (!response.ok) throw new Error('Error al generar balance');

        balanceData = await response.json();
        mostrarBalance(balanceData);
    } catch (error) {
        console.error('Error:', error);
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Error al generar el Balance de Comprobacion'
        });
    } finally {
        btn.disabled = false;
        btn.innerHTML = originalContent;
    }
}
```

**Despues:**
```javascript
// R20: Usar Api.postJson en lugar de fetch manual
async function generarBalance() {
    const btn = event.target.closest('button');
    btn.disabled = true;
    // ... construir request ...

    balanceData = await Api.postJson(URL_ENDPOINTS.generar, request);

    if (balanceData) {
        mostrarBalance(balanceData);
    }

    btn.disabled = false;
    btn.innerHTML = originalContent;
}
```

**Beneficios:**
- Eliminado try-catch manual (Api.postJson maneja errores automaticamente)
- Codigo reducido de ~25 lineas a ~10 lineas
- Manejo consistente de errores

#### R20: exportarExcel() - manejo mejorado de errores (lineas 460-540)
**Antes:**
```javascript
try {
    const response = await fetch(URL_ENDPOINTS.exportarExcel, {
        method: 'POST',
        headers: {'Content-Type': 'application/json', 'Accept': 'application/json'},
        body: JSON.stringify(request)
    });

    if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Error al exportar');
    }

    const blob = await response.blob();
    // ... descarga ...
} catch (error) {
    // ... error ...
}
```

**Despues (Actualizado 2025-12-07):**
```javascript
// R20: Para exportaciones usar Form POST con formulario oculto
function exportarExcel() {
    if (!balanceData) { /* validacion */ }

    const form = document.getElementById('filtrosForm');
    const formData = new FormData(form);

    // Crear formulario oculto para POST directo (descarga de archivo)
    const hiddenForm = document.createElement('form');
    hiddenForm.method = 'POST';
    hiddenForm.action = URL_ENDPOINTS.exportarExcel;
    hiddenForm.style.display = 'none';

    // Agregar campos del formulario
    const campos = [
        { name: 'EmpresaId', value: formData.get('EmpresaId') },
        { name: 'Ano', value: formData.get('Ano') },
        // ... demas campos ...
    ];

    campos.forEach(campo => {
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = campo.name;
        input.value = campo.value;
        hiddenForm.appendChild(input);
    });

    document.body.appendChild(hiddenForm);
    hiddenForm.submit();
    document.body.removeChild(hiddenForm);
}
```

**Cambio en ApiController:**
```csharp
// Antes: [FromBody]
// Despues: [FromForm] - para soportar Form POST
[HttpPost]
public async Task<IActionResult> ExportarExcel(
    [FromForm] BalanceComprobacionExportRequestDto request, ...)
```

**Beneficios:**
- Eliminado fetch manual completamente (cumple R20)
- El navegador maneja la descarga del archivo automaticamente
- Codigo mas simple (~20 lineas menos)
- No requiere manejo de blob en JavaScript

## Reglas Verificadas

### Service
- [x] R06 - Reutiliza logica existente
- [x] R15 - BusinessException para errores
- [x] R17 - Tipos SQL correctos

### ApiController
- [x] R02 - Sin try-catch
- [x] R02 - Retorna Ok()/Ok(data)

### WebController
- [x] R02 - Sin try-catch
- [x] R03 - NO llama a Service directo (solo Index para renderizar vista)
- [x] R19 - NO tiene metodos proxy (eliminados todos)

### Vista
- [x] R04 - URLs con @Url.Action apuntando a ApiController
- [x] R07 - Header Dashboard
- [x] R08 - Orden correcto
- [x] R09 - Empty State
- [x] R10 - Tag helpers
- [x] R19 - JS llama a ApiController directamente
- [x] R20 - Usa Api.get, Api.postJson, y Form POST para exportaciones (sin fetch manual)
- [x] CSS - bg-white, sin dark:, sin appearance-none

## Resumen de Mejoras

### Arquitectura
- **Antes:** Vista → WebController (proxy) → ApiController → Service
- **Despues:** Vista → ApiController → Service (sin capa proxy innecesaria)

### Codigo JavaScript
- **Reduccion:** ~45 lineas de codigo eliminadas
- **Manejo de errores:** Consistente y automatico con Api.* helpers
- **Mantenibilidad:** Mayor, menos codigo duplicado

### WebController
- **Reduccion:** De 117 lineas a 44 lineas (62% menos codigo)
- **Responsabilidad:** Unica (solo renderizar vista inicial)
- **Dependencias:** Reducidas de 4 a 1

## Testing Recomendado

1. Verificar carga inicial de la vista
2. Probar carga de opciones (areas de negocio y centros de costo)
3. Generar balance con diferentes filtros
4. Exportar a Excel
5. Verificar manejo de errores (sin empresa seleccionada, fechas invalidas, etc.)
6. Verificar que los mensajes de error se muestran correctamente con SweetAlert

## Notas Adicionales

- La funcion `exportarExcel()` ahora usa Form POST con formulario oculto en lugar de fetch (cumple R20 completamente)
- El endpoint `ExportarExcel` en ApiController fue modificado de `[FromBody]` a `[FromForm]`
- Todos los endpoints ahora apuntan directamente a `BalanceComprobacionApiController`
- El WebController ahora es minimalista y solo se encarga de renderizar la vista inicial con valores por defecto
- Se eliminaron todas las dependencias de proxy (`ProxyRequestAsync`, `DownloadFileAsync`)
