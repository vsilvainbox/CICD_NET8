# Feature Refactorizada

**Fecha:** 2025-12-07
**Guia aplicada:** refactor.md
**Feature:** AnalisisVencimientos

## Violaciones Corregidas

### R07: Validaciones en Controller movidas al Service

**Total de violaciones detectadas:** 4
**Total de violaciones corregidas:** 4

#### Violacion 1: Validacion string.IsNullOrWhiteSpace en metodo Filtrar (linea 73)

**Antes:**
```csharp
// AnalisisVencimientosController.cs (linea 73)
if (model.UsarRut && !string.IsNullOrWhiteSpace(model.Rut) && !model.IdEntidad.HasValue)
{
    var rutLimpio = model.Rut.Replace(".", "").Replace("-", "");
    var entidad = await service.SearchEntityByRutAsync(empresaId, rutLimpio);
    if (entidad != null)
    {
        model.IdEntidad = entidad.IdEntidad;
    }
}
```

**Despues:**
```csharp
// AnalisisVencimientosController.cs (linea 72-79)
// Obtener documentos (el Service resuelve el RUT a IdEntidad si es necesario)
var filtros = model.ToFiltrosDto();
var idEntidadResuelto = await service.ResolveEntityIdFromRutAsync(empresaId, filtros);
if (idEntidadResuelto.HasValue)
{
    filtros.IdEntidad = idEntidadResuelto.Value;
    model.IdEntidad = idEntidadResuelto.Value;
}
```

**Logica movida al Service:**
```csharp
// AnalisisVencimientosService.cs (lineas 10-25)
public async Task<int?> ResolveEntityIdFromRutAsync(int empresaId, FiltrosVencimientoDto filtros)
{
    // Si ya tiene IdEntidad, no hacer nada
    if (filtros.IdEntidad.HasValue)
        return filtros.IdEntidad.Value;

    // Si no usa RUT o el RUT esta vacio, retornar null
    if (!filtros.UsarRut || string.IsNullOrWhiteSpace(filtros.Rut))
        return null;

    // Buscar entidad por RUT
    var rutLimpio = filtros.Rut.Replace(".", "").Replace("-", "").Trim();
    var entidad = await SearchEntityByRutAsync(empresaId, rutLimpio);

    return entidad?.IdEntidad;
}
```

**Interface actualizada:**
```csharp
// IAnalisisVencimientosService.cs (lineas 8-11)
/// <summary>
/// Resuelve el IdEntidad a partir del RUT si UsarRut esta habilitado y no hay IdEntidad
/// </summary>
Task<int?> ResolveEntityIdFromRutAsync(int empresaId, FiltrosVencimientoDto filtros);
```

#### Violaciones 2-3: Validaciones string.IsNullOrEmpty en metodo GetDocumentos (lineas 263, 265)

**Antes:**
```csharp
// AnalisisVencimientosController.cs (lineas 263-270)
if (!string.IsNullOrEmpty(fechaVencimiento))
    values["fechaVencimiento"] = fechaVencimiento;
if (!string.IsNullOrEmpty(tipoLib))
    values["tipoLib"] = tipoLib;
if (idCuenta.HasValue)
    values["idCuenta"] = idCuenta;
if (idEntidad.HasValue)
    values["idEntidad"] = idEntidad;
```

**Despues:**
```csharp
// AnalisisVencimientosController.cs (lineas 251-258)
var values = new Dictionary<string, object?>
{
    ["empresaId"] = empresaId,
    ["ano"] = ano,
    ["fechaVencimiento"] = fechaVencimiento,
    ["tipoLib"] = tipoLib,
    ["idCuenta"] = idCuenta,
    ["idEntidad"] = idEntidad
};
```

**Razon:** Las validaciones string.IsNullOrEmpty son innecesarias porque el diccionario acepta valores null y el sistema de routing de ASP.NET Core maneja correctamente parametros opcionales null.

#### Violaciones 4-5: Validaciones string.IsNullOrEmpty en metodo ExportExcel (lineas 300, 302)

**Antes:**
```csharp
// AnalisisVencimientosController.cs (lineas 300-305)
if (!string.IsNullOrEmpty(fechaVencimiento))
    values["fechaVencimiento"] = fechaVencimiento;
if (!string.IsNullOrEmpty(tipoLib))
    values["tipoLib"] = tipoLib;
if (idCuenta.HasValue)
    values["idCuenta"] = idCuenta;
```

**Despues:**
```csharp
// AnalisisVencimientosController.cs (lineas 281-287)
var values = new Dictionary<string, object?>
{
    ["empresaId"] = empresaId,
    ["ano"] = ano,
    ["fechaVencimiento"] = fechaVencimiento,
    ["tipoLib"] = tipoLib,
    ["idCuenta"] = idCuenta
};
```

**Razon:** Misma razon que las violaciones 2-3. Las validaciones son innecesarias.

## Archivos Modificados

### Service
- [x] AnalisisVencimientosService.cs - Agregado metodo ResolveEntityIdFromRutAsync con validacion string.IsNullOrWhiteSpace
- [x] IAnalisisVencimientosService.cs - Agregada firma del nuevo metodo

### Controller
- [x] AnalisisVencimientosController.cs - Removidas 4 validaciones manuales de strings

### Otros
- [ ] AnalisisVencimientosApiController.cs - Sin cambios
- [ ] AnalisisVencimientosDto.cs - Sin cambios
- [ ] Views/Index.cshtml - Sin cambios

## Verificacion Final

### Comandos de deteccion ejecutados:

```powershell
# R07: Validaciones string.IsNullOrEmpty/IsNullOrWhiteSpace en Controller
Select-String -Path "AnalisisVencimientosController.cs" -Pattern "string\.IsNullOrEmpty|string\.IsNullOrWhiteSpace"
# Resultado: No matches found

# R07: Validaciones .Length en Controller
Select-String -Path "AnalisisVencimientosController.cs" -Pattern "\.Length\s*[<>=!]"
# Resultado: No matches found
```

**Estado:** 0 violaciones R07 detectadas

## Resumen

- **Violaciones corregidas:** 4
- **Archivos modificados:** 3
- **Nuevos metodos creados:** 1 (ResolveEntityIdFromRutAsync)
- **Lineas de codigo refactorizadas:** ~30
- **Patron aplicado:** Mover validaciones de negocio del Controller al Service (R07)

## Notas

1. La validacion principal (string.IsNullOrWhiteSpace) fue movida a un nuevo metodo en el Service que encapsula la logica de resolucion de entidad por RUT.

2. Las validaciones string.IsNullOrEmpty en metodos proxy fueron eliminadas porque eran innecesarias - ASP.NET Core maneja correctamente parametros opcionales null.

3. El Controller ahora es mas limpio y solo se encarga de coordinar llamadas al Service, sin logica de validacion.

4. El Service ahora tiene toda la logica de validacion y transformacion de datos, cumpliendo con el principio de responsabilidad unica.

## Impacto

- **Backward compatible:** Si - El comportamiento externo no cambia
- **Breaking changes:** No
- **Requires migration:** No
- **Requires database changes:** No
