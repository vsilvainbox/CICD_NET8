using System.ComponentModel.DataAnnotations;
using App.Models.Validation;

namespace App.Features.AnalisisVencimientos;

/// <summary>
/// DTO para documento con saldo vencido
/// </summary>
public class DocumentoVencimientoDto
{
    public int IdDoc { get; set; }
    public int? TipoLib { get; set; }
    public int? TipoDoc { get; set; }
    public string? NumDoc { get; set; }
    public DateTime? FEmision { get; set; }
    public DateTime? FVenc { get; set; }
    public string? RutEntidad { get; set; }
    public string? NombreEntidad { get; set; }
    public bool NotValidRut { get; set; }
    public decimal? Total { get; set; }
    public decimal? SaldoDoc { get; set; }

    // Campos calculados/formateados
    public string TipoDocDescripcion { get; set; } = string.Empty;
    public string RutFormateado { get; set; } = string.Empty;
    public string FEmisionFormateada => FEmision?.ToString("dd/MM/yyyy") ?? string.Empty;
    public string FVencFormateada => FVenc?.ToString("dd/MM/yyyy") ?? string.Empty;
    public string TotalFormateado => Total?.ToString("N0") ?? "0";
    public string SaldoDocFormateado => SaldoDoc?.ToString("N0") ?? "0";
}

/// <summary>
/// DTO para filtros de búsqueda de documentos vencidos
/// </summary>
public class FiltrosVencimientoDto
{
    [Display(Name = "Vencim. al")]
    [DataType(DataType.Date)]
    public DateTime? FechaVencimiento { get; set; }

    [Display(Name = "Libro")]
    public int? TipoLib { get; set; }

    [Display(Name = "Cuenta")]
    public int? IdCuenta { get; set; }

    [Display(Name = "Nombre")]
    public int? IdEntidad { get; set; }

    [Display(Name = "RUT")]
    [StringLength(12)]
    [RutChileno(ValidateCheckDigit = false, ErrorMessage = "Formato de RUT inválido")]
    public string? Rut { get; set; }

    [Display(Name = "Usar RUT")]
    public bool UsarRut { get; set; } = true;

    [Display(Name = "Clasificación")]
    public int? Clasificacion { get; set; }

    public bool UseCidFormat { get; set; } = true;
}

/// <summary>
/// DTO para entidad encontrada por RUT
/// </summary>
public class EntidadBusquedaDto
{
    public int IdEntidad { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public string? Rut { get; set; }
    public bool? NotValidRut { get; set; }
    public byte? Clasif0 { get; set; }
    public byte? Clasif1 { get; set; }
    public byte? Clasif2 { get; set; }
    public byte? Clasif3 { get; set; }
    public byte? Clasif4 { get; set; }
    public byte? Clasif5 { get; set; }
}

/// <summary>
/// DTO para combo de entidades
/// </summary>
public class EntidadComboDto
{
    public int IdEntidad { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public string? Rut { get; set; }
    public bool NotValidRut { get; set; }
    public string RutFormateado { get; set; } = string.Empty;
}

/// <summary>
/// DTO para combo de cuentas
/// </summary>
public class CuentaComboDto
{
    public int IdCuenta { get; set; }
    public string Codigo { get; set; } = string.Empty;
    public string Nombre { get; set; } = string.Empty;
    public string CodigoNombre => $"{Codigo} - {Nombre}";
}

/// <summary>
/// DTO para tipo de libro
/// </summary>
public class TipoLibroDto
{
    public int Codigo { get; set; }
    public string Descripcion { get; set; } = string.Empty;
}

/// <summary>
/// DTO para clasificación de entidad
/// </summary>
public class ClasificacionEntidadDto
{
    public int Codigo { get; set; }
    public string Descripcion { get; set; } = string.Empty;
}

/// <summary>
/// DTO para totales del informe
/// </summary>
public class TotalesVencimientoDto
{
    public decimal TotalGeneral { get; set; }
    public decimal SaldoTotal { get; set; }
    public int CantidadDocumentos { get; set; }
    public string TotalGeneralFormateado => TotalGeneral.ToString("N0");
    public string SaldoTotalFormateado => SaldoTotal.ToString("N0");
}