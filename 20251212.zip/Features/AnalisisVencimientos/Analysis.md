# Legacy Analysis: AnalisisVencimientos

## 📄 Información del Formulario VB6

**Archivo VB6:** `vb6\Contabilidad70\HyperContabilidad\FrmInfoVencim.frm`
**Fecha Análisis:** 2025-10-07
**Analista:** IA
**Complejidad:** Alta

### Propósito del Formulario
Este formulario genera un informe de documentos (compras, ventas, retenciones, otros) que tienen saldo pendiente y están vencidos hasta una fecha determinada. Permite filtrar por libro, cuenta contable, entidad (RUT/nombre), y muestra detalle de cada documento con su saldo. Incluye funcionalidades de exportación a Excel, vista previa, impresión, suma de seleccionados, y herramientas auxiliares (calculadora, calendario, conversión de moneda).

---

## 🎨 CONTROLES UI IDENTIFICADOS

### Textboxes (Campos de Entrada)
| Control VB6 | Propiedad Bound | Tipo | Validación | Propósito |
|-------------|----------------|------|------------|-----------|
| Tx_Fecha | N/A | Date | Required, formato fecha | Fecha límite de vencimiento para el informe |
| Tx_Rut | Entidades.Rut | String | Formato RUT chileno, existe en BD | RUT de la entidad para filtrar documentos |

### ComboBoxes (Listas Desplegables)
| Control VB6 | Fuente Datos | Valor | Display | Evento Change |
|-------------|--------------|-------|---------|---------------|
| Cb_TipoLib | Hardcoded (LIB_COMPRAS, LIB_VENTAS, LIB_RETEN, LIB_OTROS) | ItemData | Texto sin prefijo "Libro de " | Habilita botón Listar |
| Cb_Cuentas | Tabla Cuentas | IdCuenta | Código + Nombre | Habilita botón Listar |
| Cb_Entidad | Hardcoded (ENT_CLIENTE, ENT_PROVEEDOR, etc.) | Clasif | Nombre clasificación | Filtra combo Cb_Nombre, habilita botón Listar |
| Cb_Nombre | Tabla Entidades (filtrado por Clasif) | IdEntidad | Nombre | Actualiza Tx_Rut con RUT de entidad seleccionada |

### Grillas (MSFlexGrid)
| Control VB6 | Fuente Datos | Columnas | Eventos | Acciones |
|-------------|--------------|----------|---------|----------|
| Grid | Query LoadGrid | 8 cols: IdDoc (hidden), FVenc, FEmision, NumDoc, RUT, Nombre, Total, Saldo | DblClick | DblClick abre detalle del documento en FrmDoc |
| GridTot | Calculado | Fila única con totales | N/A | Muestra total general y total saldo |

#### Columnas de Grid
1. **C_IDDOC (0)**: IdDoc (oculta, Width=0)
2. **C_FVENC (1)**: Fecha Vencimiento (formato fecha)
3. **C_FEMISION (2)**: Fecha Emisión (formato fecha)
4. **C_NUMDOC (3)**: Número Documento con diminutivo de tipo
5. **C_RUT (4)**: RUT entidad (formato CID)
6. **C_NOMBRE (5)**: Nombre entidad
7. **C_VALOR (6)**: Total documento (formato numérico)
8. **C_SALDO (7)**: Saldo pendiente (formato numérico con negativos)

### Labels y Campos Calculados
| Control VB6 | Cálculo/Origen | Actualización |
|-------------|----------------|---------------|
| GridTot.TextMatrix(0, C_FVENC) | "TOTAL" | Al cargar/refrescar grid |
| GridTot.TextMatrix(0, C_VALOR) | SUM(Grid.C_VALOR) | Al cargar/refrescar grid |
| GridTot.TextMatrix(0, C_SALDO) | SUM(Grid.C_SALDO) | Al cargar/refrescar grid |

### Botones de Acción
| Botón VB6 | Caption | Habilitado Si | Acción | Mapeo .NET |
|-----------|---------|---------------|--------|------------|
| Bt_Fecha | (icono) | Siempre | Abre calendario (FrmCalendar) para seleccionar fecha | OpenCalendarAsync() |
| Bt_List | "&Listar" | Filtros modificados | Ejecuta query y carga grid con documentos vencidos | LoadGridAsync() |
| Bt_VerDoc | (icono) | Grid con selección válida | Abre detalle del documento en FrmDoc | ViewDocumentDetailAsync() |
| Bt_Preview | (icono) | Grid cargado | Vista previa de impresión (FrmPrintPreview) | PrintPreviewAsync() |
| Bt_Print | (icono) | Grid cargado | Imprimir directamente | PrintAsync() |
| Bt_CopyExcel | (icono) | Grid cargado | Copiar grid al portapapeles para Excel | CopyToExcelAsync() |
| Bt_Sum | (icono) | Grid con datos | Abre FrmSumSimple para sumar filas seleccionadas | SumSelectedAsync() |
| Bt_ConvMoneda | (icono) | Siempre | Abre FrmConverMoneda para convertir monedas | [INTEGRATION] [LOW] [FUTURE] ConvertCurrencyAsync() |
| Bt_Calc | (icono) | Siempre | Abre calculadora externa | [LEGACY] [LOW] OpenCalculatorAsync() |
| Bt_Calendar | (icono) | Siempre | Abre calendario standalone (FrmCalendar) | [LEGACY] [LOW] OpenCalendarStandaloneAsync() |
| Bt_Cerrar | "Cerrar" | Siempre | Cierra formulario | N/A (navegación) |

#### 🚨 REGLA CRÍTICA: TODOS LOS BOTONES MIGRADOS

**✅ Botones Completamente Funcionales:**
- Bt_Fecha: Selector de fecha (usar input type="date" HTML5)
- Bt_List: Cargar grid con filtros aplicados
- Bt_VerDoc: Abrir modal/página de detalle del documento
- Bt_CopyExcel: Exportar datos a Excel (EPPlus)
- Bt_Sum: Modal con suma de columnas seleccionadas
- Bt_Preview: Generar PDF con vista previa
- Bt_Print: Descargar/imprimir PDF directamente
- Bt_Cerrar: Navegación estándar

**⚠️ Botones con Excepciones Documentadas:**

```javascript
// Bt_ConvMoneda - Conversor de moneda
// TODO: [INTEGRATION] [LOW] [FUTURE] Implementar conversor de moneda cuando API de tasas esté disponible
// Requiere: API de tipos de cambio, configuración de monedas base
function convertirMoneda() {
    Swal.fire('En desarrollo', 'El conversor de moneda estará disponible en una versión futura', 'info');
}
```

```javascript
// Bt_Calc - Calculadora
// TODO: [LEGACY] [LOW] VB6 abría calculadora de Windows
// Alternativa web: implementar calculadora JavaScript simple o usar API de evaluación segura
function abrirCalculadora() {
    Swal.fire('No disponible', 'Use la calculadora de su sistema operativo o dispositivo', 'info');
}
```

```javascript
// Bt_Calendar - Calendario standalone
// TODO: [LEGACY] [LOW] VB6 abría calendario independiente
// En web moderno: ya existe selector de fecha integrado (Bt_Fecha), este botón es redundante
function abrirCalendarioStandalone() {
    Swal.fire('No necesario', 'Use el selector de fecha al lado del campo "Vencim. al"', 'info');
}
```

### CheckBox
| Control VB6 | Caption | Estado Inicial | Acción | Mapeo .NET |
|-------------|---------|----------------|--------|------------|
| Ch_Rut | "RUT:" | Checked (1) | Alterna entre búsqueda por RUT o por nombre | ToggleSearchModeAsync() |

### Otros Controles
| Tipo Control | Nombre | Propósito | Eventos |
|--------------|--------|-----------|---------|
| Frame | Frame1 | Agrupador visual de botones de toolbar | N/A |
| Frame | Frame2 | Agrupador visual de filtros de búsqueda | N/A |

---

## 🔘 EVENTOS IDENTIFICADOS

### Eventos de Formulario
| Evento VB6 | Cuándo Ocurre | Acciones | Mapeo .NET |
|------------|---------------|----------|------------|
| Form_Load | Al abrir form | Inicializar fecha actual + lDias (parámetro), llenar combos (Cuentas, TipoLib, Entidad), setear Ch_Rut=1, configurar grid, ejecutar RecalcSaldos, cargar grid inicial | InitializeAsync(), LoadComboDataAsync() |
| Form_Resize | Al cambiar tamaño | Ajustar altura de Grid y GridTot, recalcular filas visibles | N/A (CSS responsive) |

### Eventos de Botones
[Ya documentados en tabla de Botones arriba]

### Eventos de Controles
| Control.Evento | Trigger | Acción VB6 | Mapeo .NET |
|----------------|---------|------------|------------|
| Tx_Rut.Change | Usuario modifica RUT | Habilitar botón Listar | EnableListButton() |
| Tx_Rut.KeyPress | Tecla presionada | Validar formato CID si Ch_Rut activo, Enter ejecuta LostFocus | ValidateRutInput() |
| Tx_Rut.LostFocus | Sale del campo | Buscar entidad por RUT, seleccionar clasificación y nombre en combos | SearchEntityByRutAsync() |
| Tx_Rut.Validate | Al validar | Verificar RUT válido con MsgValidCID | ValidateRutFormatAsync() |
| Cb_TipoLib.Click | Selección cambia | Habilitar botón Listar | EnableListButton() |
| Cb_Cuentas.Click | Selección cambia | Habilitar botón Listar | EnableListButton() |
| Cb_Entidad.Click | Selección cambia | Llenar Cb_Nombre con entidades de esa clasificación, limpiar Tx_Rut si no hay selección | FilterEntitiesByClassificationAsync() |
| Cb_Nombre.Click | Selección cambia | Actualizar Tx_Rut con RUT de entidad seleccionada, ajustar Ch_Rut según NotValidRut | UpdateRutFromEntityAsync() |
| Ch_Rut.Click | Toggle checkbox | Habilitar botón Listar | EnableListButton() |
| Grid.DblClick | Doble click en fila | Abrir detalle del documento (Bt_VerDoc_Click) | ViewDocumentDetailAsync() |
| Bt_Fecha.Click | Click en botón calendario | Abrir FrmCalendar para seleccionar fecha, habilitar botón Listar | OpenCalendarPickerAsync() |

---

## 🔧 FUNCIONES Y PROCEDIMIENTOS VB6

### Funciones Públicas

```vb
' Función: FView
' Propósito: Punto de entrada para mostrar el formulario desde otros formularios
' Parámetros: Dias (Optional, default=30) - Días a agregar a fecha actual para fecha inicial
' Retorno: Void
' Llamado por: Otros formularios del sistema
' Mapeo .NET: Constructor del ViewModel o método Index del Controller con parámetro dias
Public Sub FView(Optional ByVal Dias As Integer = 30)
   lDias = Dias
   Me.Show vbModal
End Sub
```

### Funciones Privadas

```vb
' Función: SetUpGrid
' Propósito: Configurar columnas, anchos, alineaciones y encabezados del grid principal
' Parámetros: Ninguno
' Retorno: Void
' Llamado por: Form_Load
' Mapeo .NET: ConfigureGridAsync() - JavaScript en vista, configurar columnas de DataTable
Private Sub SetUpGrid()
    ' Configura anchos, alineaciones y encabezados de Grid
    ' Llama a FGrTotales para inicializar GridTot
End Sub
```

```vb
' Función: FillCb
' Propósito: Llenar todos los ComboBoxes con sus datos iniciales
' Parámetros: Ninguno
' Retorno: Void
' Llamado por: Form_Load
' Mapeo .NET: LoadComboDataAsync() - múltiples endpoints API
Private Sub FillCb()
    ' Llena Cb_Cuentas desde base de datos
    ' Llena Cb_TipoLib con constantes (LIB_COMPRAS, LIB_VENTAS, LIB_RETEN, LIB_OTROS)
    ' Llena Cb_Entidad con clasificaciones (ENT_CLIENTE, ENT_PROVEEDOR, etc.)
End Sub
```

```vb
' Función: LoadGrid
' Propósito: Cargar grid con documentos vencidos según filtros aplicados
' Parámetros: IdDoc (Optional) - Si se pasa, selecciona esa fila al cargar
' Retorno: Void
' Llamado por: Form_Load, Bt_List_Click
' Validaciones:
'   - Si Tx_Rut lleno y entidad no existe, mostrar error
'   - Validar que filtros sean coherentes
' Mapeo .NET: LoadGridAsync(filtros) - Endpoint API que retorna DocumentoVencimientoDto[]
Private Sub LoadGrid(Optional ByVal IdDoc As Long = 0)
    ' Construye query con filtros WHERE dinámicos
    ' Filtra por: IdEntidad, TipoLib, IdCuenta, FVenc <= Tx_Fecha, SaldoDoc <> 0
    ' JOIN con Entidades y MovDocumento
    ' Calcula totales (Total, TotSaldo)
    ' Actualiza GridTot
End Sub
```

```vb
' Función: SelCbEntidad
' Propósito: Llenar Cb_Nombre con entidades de una clasificación específica
' Parámetros: Clasif (Integer) - Código de clasificación de entidad
' Retorno: Void
' Llamado por: Cb_Entidad_Click
' Mapeo .NET: GetEntitiesByClassificationAsync(clasif)
Private Sub SelCbEntidad(Clasif As Integer)
    ' Query: SELECT Nombre, IdEntidad, Rut, NotValidRut FROM Entidades
    ' WHERE Clasif{N} = CON_CLASIF (valor -1)
    ' ORDER BY Nombre
End Sub
```

```vb
' Función: SetUpPrtGrid
' Propósito: Configurar objeto gPrtReportes para impresión/vista previa
' Parámetros: Ninguno
' Retorno: Void
' Llamado por: Bt_Preview_Click, Bt_Print_Click
' Mapeo .NET: GenerateReportDataAsync() - Preparar datos para PDF
Private Sub SetUpPrtGrid()
    ' Configura títulos, encabezados, anchos de columna, totales
    ' Usa objeto global gPrtReportes
End Sub
```

### Lista Completa de Funciones
| Función VB6 | Tipo | Propósito | Mapeo .NET Method |
|-------------|------|-----------|-------------------|
| FView(Dias) | Public Sub | Mostrar formulario con parámetro días | Index(dias) en Controller |
| Form_Load() | Event | Inicializar formulario y datos | InitializeAsync() |
| SetUpGrid() | Private Sub | Configurar grid principal | ConfigureGridAsync() (JS) |
| FillCb() | Private Sub | Llenar combos | LoadComboDataAsync() |
| LoadGrid(IdDoc) | Private Sub | Cargar documentos vencidos | LoadGridAsync(filtros) |
| SelCbEntidad(Clasif) | Private Sub | Filtrar entidades por clasificación | GetEntitiesByClassificationAsync(clasif) |
| SetUpPrtGrid() | Private Sub | Preparar datos para impresión | GenerateReportDataAsync() |
| Tx_Rut_LostFocus() | Event | Buscar entidad por RUT | SearchEntityByRutAsync(rut) |
| Bt_List_Click() | Event | Validar y ejecutar LoadGrid | LoadGridAsync() |
| Bt_VerDoc_Click() | Event | Abrir detalle de documento | ViewDocumentDetailAsync(idDoc) |
| Bt_CopyExcel_Click() | Event | Copiar grid a Excel | CopyToExcelAsync() |
| Bt_Preview_Click() | Event | Vista previa de impresión | PrintPreviewAsync() |
| Bt_Print_Click() | Event | Imprimir reporte | PrintAsync() |
| Bt_Sum_Click() | Event | Sumar filas seleccionadas | SumSelectedAsync() |
| Bt_ConvMoneda_Click() | Event | Convertir moneda | [FUTURE] ConvertCurrencyAsync() |
| Bt_Calc_Click() | Event | Abrir calculadora | [LEGACY] OpenCalculatorAsync() |
| Bt_Calendar_Click() | Event | Abrir calendario | [LEGACY] OpenCalendarStandaloneAsync() |
| Bt_Cerrar_Click() | Event | Cerrar formulario | N/A (navegación) |
| Form_Resize() | Event | Ajustar tamaño de controles | N/A (CSS responsive) |

---

## 💾 ACCESO A DATOS VB6

### Query Principal: Cargar Documentos Vencidos

#### Query 1: LoadGrid - Documentos con Saldo Vencido
```vb
' Ubicación: LoadGrid()
' Tablas: Documento, Entidades, MovDocumento, Cuentas
' Filtros: IdEmpresa, Ano, IdEntidad (opcional), TipoLib (opcional), IdCuenta (opcional), FVenc <= Tx_Fecha, SaldoDoc <> 0, EsTotalDoc <> 0
Q1 = "SELECT Documento.IdDoc, TipoLib, TipoDoc, NumDoc, NumDocHasta, Documento.IdEntidad, Entidades.Rut, "
Q1 = Q1 & " Entidades.Nombre, Entidades.NotValidRut, FEmision, FVenc, Total, Descrip, Documento.Estado, SaldoDoc, "
Q1 = Q1 & " MovDocumento.Debe, MovDocumento.Haber"
Q1 = Q1 & " FROM ((Documento LEFT JOIN Entidades ON Documento.IdEntidad = Entidades.IdEntidad "
Q1 = Q1 & "  AND Documento.IdEmpresa = Entidades.IdEmpresa )"
Q1 = Q1 & " LEFT JOIN MovDocumento ON Documento.IdDoc = MovDocumento.IdDoc "
Q1 = Q1 & JoinEmpAno(gDbType, "Documento", "MovDocumento") & " )"
Q1 = Q1 & " LEFT JOIN Cuentas ON MovDocumento.IdCuenta = Cuentas.IdCuenta "
Q1 = Q1 & JoinEmpAno(gDbType, "Cuentas", "MovDocumento")
Q1 = Q1 & Where  ' Filtros dinámicos
Q1 = Q1 & " AND Documento.IdEmpresa = " & gEmpresa.id & " AND Documento.Ano = " & gEmpresa.Ano
Q1 = Q1 & " ORDER BY FVenc, Entidades.Nombre, NumDoc"
```

**Filtros dinámicos (WHERE clause):**
```vb
' Si Tx_Rut tiene valor y entidad existe:
Where = Where & " AND Documento.IdEntidad = " & IdEnt

' Si Cb_TipoLib seleccionado:
Where = Where & " AND Documento.TipoLib = " & ItemData(Cb_TipoLib)

' Si Cb_Cuentas seleccionado:
Where = Where & " AND MovDocumento.IdCuenta = " & ItemData(Cb_Cuentas)

' Si Tx_Fecha tiene valor:
Where = Where & " AND (FVenc > 0 AND Documento.FVenc <= " & GetTxDate(Tx_Fecha) & ")"

' Siempre:
Where = Where & " AND Documento.SaldoDoc <> 0 AND (EsTotalDoc <> 0 OR EsTotalDoc IS NULL)"
```

**Mapeo Entity Framework:**
```csharp
// ⚠️ IMPORTANTE: Cuentas.idCuenta es camelCase (no IdCuenta)
var query = _context.Documento
    .Include(d => d.IdEntidadNavigation) // Entidades
    .Where(d => d.IdEmpresa == empresaId && d.Ano == ano)
    .Where(d => d.SaldoDoc != null && d.SaldoDoc != 0);

// Filtros opcionales
if (filtros.IdEntidad.HasValue)
    query = query.Where(d => d.IdEntidad == filtros.IdEntidad.Value);

if (filtros.TipoLib.HasValue)
    query = query.Where(d => d.TipoLib == filtros.TipoLib.Value);

if (filtros.FechaVencimiento.HasValue)
    query = query.Where(d => d.FVenc.HasValue && d.FVenc.Value <= filtros.FechaVencimiento.Value);

// Si filtro por cuenta, necesitamos JOIN con MovDocumento
if (filtros.IdCuenta.HasValue)
{
    query = query.Where(d => _context.MovDocumento
        .Any(m => m.IdDoc == d.IdDoc
            && m.IdCuenta == filtros.IdCuenta.Value
            && m.EsTotalDoc != 0
            && m.IdEmpresa == empresaId
            && m.Ano == ano));
}

var documentos = await query
    .OrderBy(d => d.FVenc)
    .ThenBy(d => d.IdEntidadNavigation.Nombre)
    .ThenBy(d => d.NumDoc)
    .Select(d => new DocumentoVencimientoDto
    {
        IdDoc = d.IdDoc,
        TipoLib = d.TipoLib,
        TipoDoc = d.TipoDoc,
        NumDoc = d.NumDoc,
        FEmision = d.FEmision,
        FVenc = d.FVenc,
        RutEntidad = d.IdEntidadNavigation.Rut,
        NombreEntidad = d.IdEntidadNavigation.Nombre,
        NotValidRut = d.IdEntidadNavigation.NotValidRut,
        Total = d.Total,
        SaldoDoc = d.SaldoDoc
    })
    .ToListAsync();
```

#### Query 2: Buscar Entidad por RUT
```vb
' Ubicación: Tx_Rut_LostFocus()
Q1 = "SELECT IdEntidad, Clasif0, Clasif1, Clasif2, Clasif3, Clasif4, Clasif5 FROM Entidades WHERE Rut = '" & vFmtCID(Tx_Rut, Ch_Rut <> 0) & "'"
Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.id
```

**Mapeo Entity Framework:**
```csharp
var entidad = await _context.Entidades
    .Where(e => e.Rut == rutFormateado && e.IdEmpresa == empresaId)
    .Select(e => new EntidadBusquedaDto
    {
        IdEntidad = e.IdEntidad,
        Clasif0 = e.Clasif0,
        Clasif1 = e.Clasif1,
        Clasif2 = e.Clasif2,
        Clasif3 = e.Clasif3,
        Clasif4 = e.Clasif4,
        Clasif5 = e.Clasif5
    })
    .FirstOrDefaultAsync();
```

#### Query 3: Entidades por Clasificación
```vb
' Ubicación: SelCbEntidad(Clasif)
Q1 = "SELECT Nombre, idEntidad, Rut, NotValidRut FROM Entidades"
Q1 = Q1 & " WHERE Clasif" & Clasif & "=" & CON_CLASIF  ' CON_CLASIF = -1
Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.id
Q1 = Q1 & " ORDER BY Nombre "
```

**Mapeo Entity Framework:**
```csharp
// Filtro dinámico por clasificación (Clasif0 a Clasif5)
IQueryable<Entidades> query = _context.Entidades.Where(e => e.IdEmpresa == empresaId);

switch (clasif)
{
    case 0: query = query.Where(e => e.Clasif0 == -1); break;
    case 1: query = query.Where(e => e.Clasif1 == -1); break;
    case 2: query = query.Where(e => e.Clasif2 == -1); break;
    case 3: query = query.Where(e => e.Clasif3 == -1); break;
    case 4: query = query.Where(e => e.Clasif4 == -1); break;
    case 5: query = query.Where(e => e.Clasif5 == -1); break;
}

var entidades = await query
    .OrderBy(e => e.Nombre)
    .Select(e => new EntidadComboDto
    {
        IdEntidad = e.IdEntidad,
        Nombre = e.Nombre,
        Rut = e.Rut,
        NotValidRut = e.NotValidRut
    })
    .ToListAsync();
```

---

## ✅ VALIDACIONES Y REGLAS DE NEGOCIO

### Validaciones de Campos
| Campo | Regla | Mensaje Error VB6 | Implementar en .NET |
|-------|-------|-------------------|---------------------|
| Tx_Fecha | Obligatorio para listar | "Presione el botón Listar antes de..." (implícito) | [Required] attribute + ValidateAsync() |
| Tx_Rut | Formato RUT chileno válido | MsgValidCID | ValidateRutFormatAsync() |
| Tx_Rut | Debe existir en tabla Entidades | "Este RUT no ha sido ingresado al sistema." | CheckEntityExistsAsync(rut) |
| Bt_List antes de acciones | Grid debe estar cargado (Bt_List.Enabled = False) | "Presione el botón Listar antes de..." | ValidateGridLoadedAsync() |

### Reglas de Negocio

1. **Filtro por RUT requiere entidad válida**: Si usuario ingresa RUT en Tx_Rut, debe existir en base de datos con ese RUT exacto
   ```vb
   If Trim(Tx_Rut) <> "" And Val(lcbNombre.Matrix(M_IDENTIDAD)) = 0 Then
      MsgBox1 "El RUT ingresado no es válido o no ha sido ingresado al sistema."
   End If
   ```
   **→ Implementar:** `ValidateEntityByRutAsync(rut)` valida existencia antes de filtrar

2. **Solo documentos con saldo pendiente**: Query siempre filtra `SaldoDoc <> 0`
   **→ Implementar:** Condición LINQ `.Where(d => d.SaldoDoc != null && d.SaldoDoc != 0)`

3. **Solo documentos con línea total**: Filtra `EsTotalDoc <> 0 OR EsTotalDoc IS NULL`
   **→ Implementar:** Subconsulta en MovDocumento validando EsTotalDoc

4. **Fecha de vencimiento obligatoria en query**: Si Tx_Fecha tiene valor, filtra `FVenc <= GetTxDate(Tx_Fecha)`
   **→ Implementar:** `.Where(d => d.FVenc.HasValue && d.FVenc.Value <= fechaVencimiento)`

5. **Recálculo de saldos al inicio**: Form_Load ejecuta `RecalcSaldos` y `RecalcSaldosFulle` para asegurar datos actualizados
   **→ Implementar:** Endpoint de recálculo o trigger en stored procedure

6. **Formato de RUT dinámico**: Ch_Rut=1 usa formato CID (XX.XXX.XXX-X), Ch_Rut=0 usa texto libre
   **→ Implementar:** `FormatRutAsync(rut, useCidFormat)` en frontend

---

## 🧮 CÁLCULOS Y FÓRMULAS

### Cálculo 1: Total General de Documentos
```vb
' Dónde: LoadGrid(), GridTot.TextMatrix(0, C_VALOR)
' Fórmula: SUM de columna Total en Grid
Total = Total + vFld(Rs("Total"))
GridTot.TextMatrix(0, C_VALOR) = Format(Total, NUMFMT)
```
**→ Implementar:** `CalculateTotalAsync()` retorna suma de Total de documentos en grid

### Cálculo 2: Total Saldo Pendiente
```vb
' Dónde: LoadGrid(), GridTot.TextMatrix(0, C_SALDO)
' Fórmula: SUM de columna SaldoDoc en Grid
TotSaldo = TotSaldo + vFld(Rs("SaldoDoc"))
GridTot.TextMatrix(0, C_SALDO) = Format(TotSaldo, NEGNUMFMT)
```
**→ Implementar:** `CalculateSaldoTotalAsync()` retorna suma de SaldoDoc

### Cálculo 3: Suma de Seleccionados (Bt_Sum)
```vb
' Dónde: Bt_Sum_Click
' Fórmula: Abre FrmSumSimple que suma columnas de filas seleccionadas en Grid
Call Frm.FViewSum(Grid)
```
**→ Implementar:** `SumSelectedColumnsAsync()` calcula suma de columnas de filas seleccionadas (checkbox o selección múltiple)

---

## 🚀 NAVEGACIÓN Y FLUJO

### Formularios Llamados
| Desde VB6 | Formulario Destino | Parámetros | Retorno | Mapeo .NET |
|-----------|-------------------|------------|---------|------------|
| Bt_VerDoc_Click | FrmDoc.frm | IdDoc | Ninguno | Redirect a /Documento/Detalle/{idDoc} |
| Bt_Fecha_Click | FrmCalendar.frm | Tx_Fecha (ByRef) | Fecha seleccionada | Input type="date" HTML5 |
| Bt_Preview_Click | FrmPrintPreview.frm | Grid configurado | Ninguno | Generar PDF, abrir en nueva ventana |
| Bt_Sum_Click | FrmSumSimple.frm | Grid | Ninguno | Modal JavaScript con suma de columnas |
| Bt_ConvMoneda_Click | FrmConverMoneda.frm | Ninguno | Valor convertido | [FUTURE] Modal de conversión |
| Bt_Calendar_Click | FrmCalendar.frm (standalone) | Ninguno | Ninguno | [LEGACY] No implementar, redundante |

### Flujo de Estados del Form
```
[Inicio] → Form_Load() → [Estado: Filtros Iniciales]
  ↓
[Modificar filtros] → (Cb_TipoLib/Cb_Cuentas/Tx_Rut/Ch_Rut) → Bt_List.Enabled = True
  ↓
[Bt_List_Click] → ValidarFiltros() → LoadGrid() → [Estado: Grid Cargado, Bt_List.Enabled = False]
  ↓
[Grid_DblClick] → Bt_VerDoc_Click → Abrir FrmDoc → [Estado: Visualizando Detalle]
  ↓
[Bt_CopyExcel] → FGr2Clip() → [Datos en portapapeles]
  ↓
[Bt_Preview] → SetUpPrtGrid() → FrmPrintPreview → [Vista previa PDF]
  ↓
[Bt_Print] → SetUpPrtGrid() → Printer.Print → [Impresión directa]
  ↓
[Bt_Cerrar] → Unload Me → [Formulario cerrado]
```

---

## 📊 EXPORTACIONES E IMPORTACIONES

### Exportación a Excel
```vb
' Botón: Bt_CopyExcel_Click
' Formato: Portapapeles, formato compatible con Excel
' Columnas: FVenc, FEmision, NumDoc, RUT, Nombre, Total, Saldo
' Incluye: Título con fecha y filtros aplicados
Call FGr2Clip(Grid, Me.Caption & " al " & Tx_Fecha & " " & Tit)
```
**→ Implementar:** `ExportToExcelAsync()` usando EPPlus o Open XML, descargar archivo .xlsx

### Impresión/Vista Previa
```vb
' Botones: Bt_Preview_Click, Bt_Print_Click
' Formato: Reporte impreso con títulos, encabezados, datos, totales
' Configuración: SetUpPrtGrid() prepara objeto gPrtReportes
' Orientación: lOrientacion (ORIENT_VER = Vertical)
```
**→ Implementar:**
- `GeneratePdfAsync()` usando iTextSharp o similar
- Vista previa: abrir PDF en nueva ventana/modal
- Impresión: descargar PDF directamente

---

## 🎯 MAPEO FINAL: MÉTODOS .NET DETERMINADOS

### Interface del Service

```csharp
public interface IAnalisisVencimientosService
{
    // CRUD Principal (solo lectura, es un informe)
    Task<IEnumerable<DocumentoVencimientoDto>> GetDocumentosVencidosAsync(int empresaId, int ano, FiltrosVencimientoDto filtros);

    // Búsquedas y Filtros
    Task<EntidadBusquedaDto?> SearchEntityByRutAsync(int empresaId, string rut);
    Task<IEnumerable<EntidadComboDto>> GetEntitiesByClassificationAsync(int empresaId, int clasificacion);

    // Combos y Lookups
    Task<IEnumerable<CuentaComboDto>> GetCuentasActivasAsync(int empresaId, int ano);
    Task<IEnumerable<TipoLibroDto>> GetTiposLibroAsync();
    Task<IEnumerable<ClasificacionEntidadDto>> GetClasificacionesEntidadAsync();

    // Validaciones
    Task<bool> ValidateRutFormatAsync(string rut, bool useCidFormat);
    Task<bool> CheckEntityExistsAsync(int empresaId, string rut);

    // Cálculos
    Task<TotalesVencimientoDto> CalculateTotalsAsync(IEnumerable<DocumentoVencimientoDto> documentos);
    Task<Dictionary<string, decimal>> SumSelectedColumnsAsync(IEnumerable<DocumentoVencimientoDto> documentos, string[] columnas);

    // Exportación
    Task<byte[]> ExportToExcelAsync(int empresaId, int ano, FiltrosVencimientoDto filtros);
    Task<byte[]> GeneratePdfAsync(int empresaId, int ano, FiltrosVencimientoDto filtros, bool preview = true);

    // Mantenimiento
    Task RecalcularSaldosAsync(int empresaId, int ano);
}
```

### DTOs Requeridos

```csharp
public class DocumentoVencimientoDto
{
    public int IdDoc { get; set; }
    public int? TipoLib { get; set; }
    public int? TipoDoc { get; set; }
    public string? NumDoc { get; set; }
    public DateTime? FEmision { get; set; }  // DTO moderno: DateTime
    public DateTime? FVenc { get; set; }     // DTO moderno: DateTime
    public string? RutEntidad { get; set; }
    public string? NombreEntidad { get; set; }
    public bool NotValidRut { get; set; }    // DTO moderno: bool
    public decimal? Total { get; set; }
    public decimal? SaldoDoc { get; set; }

    // Campos calculados
    public string TipoDocDescripcion { get; set; }  // Diminutivo del tipo de documento
    public string RutFormateado { get; set; }       // RUT con formato CID
}

public class FiltrosVencimientoDto
{
    public DateTime? FechaVencimiento { get; set; }  // DTO moderno: DateTime
    public int? TipoLib { get; set; }
    public int? IdCuenta { get; set; }
    public int? IdEntidad { get; set; }
    public string? Rut { get; set; }
    public bool UseCidFormat { get; set; }           // DTO moderno: bool
}

public class EntidadBusquedaDto
{
    public int IdEntidad { get; set; }
    public int? Clasif0 { get; set; }
    public int? Clasif1 { get; set; }
    public int? Clasif2 { get; set; }
    public int? Clasif3 { get; set; }
    public int? Clasif4 { get; set; }
    public int? Clasif5 { get; set; }
}

public class EntidadComboDto
{
    public int IdEntidad { get; set; }
    public string? Nombre { get; set; }
    public string? Rut { get; set; }
    public bool NotValidRut { get; set; }  // DTO moderno: bool
}

public class CuentaComboDto
{
    public int IdCuenta { get; set; }
    public string? Codigo { get; set; }
    public string? Nombre { get; set; }
    public string CodigoNombre => $"{Codigo} - {Nombre}";
}

public class TipoLibroDto
{
    public int Codigo { get; set; }
    public string Descripcion { get; set; }
}

public class ClasificacionEntidadDto
{
    public int Codigo { get; set; }
    public string Descripcion { get; set; }
}

public class TotalesVencimientoDto
{
    public decimal TotalGeneral { get; set; }
    public decimal SaldoTotal { get; set; }
    public int CantidadDocumentos { get; set; }
}
```

### Resumen de Mapeo
| Funcionalidad VB6 | Método .NET | Complejidad | Prioridad |
|-------------------|-------------|-------------|-----------|
| Form_Load cargar datos | GetDocumentosVencidosAsync(), GetCuentasActivasAsync(), GetTiposLibroAsync() | Media | Alta |
| LoadGrid con filtros | GetDocumentosVencidosAsync(filtros) | Alta | Alta |
| Tx_Rut_LostFocus búsqueda | SearchEntityByRutAsync(rut) | Baja | Alta |
| Cb_Entidad_Click filtro | GetEntitiesByClassificationAsync(clasif) | Baja | Alta |
| Bt_List_Click validar | ValidateRutFormatAsync(), CheckEntityExistsAsync() | Baja | Alta |
| Totales GridTot | CalculateTotalsAsync() | Baja | Alta |
| Bt_VerDoc detalle | N/A (navegación a /Documento/Detalle/{id}) | Baja | Media |
| Bt_CopyExcel | ExportToExcelAsync() | Media | Media |
| Bt_Preview | GeneratePdfAsync(preview=true) | Alta | Media |
| Bt_Print | GeneratePdfAsync(preview=false) | Alta | Media |
| Bt_Sum | SumSelectedColumnsAsync() | Media | Baja |
| Bt_ConvMoneda | [FUTURE] ConvertCurrencyAsync() | Alta | Baja |
| Bt_Calc | [LEGACY] No implementar | N/A | N/A |
| Bt_Calendar standalone | [LEGACY] No implementar | N/A | N/A |
| RecalcSaldos | RecalcularSaldosAsync() | Alta | Media |

---

## ⚠️ NOTAS IMPORTANTES Y OBSERVACIONES

### Peculiaridades del Form VB6
- Usa variables globales `gEmpresa.id` y `gEmpresa.Ano` para filtrar datos
- Parámetro `Dias` en FView permite personalizar fecha inicial (default 30 días adelante)
- Ch_Rut controla modo de validación: Checked=formato RUT, Unchecked=texto libre
- Campo Tx_Rut puede recibir RUT o nombre según estado de Ch_Rut
- Grid tiene encabezados de 2 filas (FixedRows=2)
- Usa objeto global `gPrtReportes` para impresión
- Llamadas a `RecalcSaldos` y `RecalcSaldosFulle` al cargar (funciones de módulo global)

### Decisiones de Diseño
- **Solo lectura**: Es un informe de consulta, no permite crear/editar/eliminar documentos
- **Filtros dinámicos**: Query se construye dinámicamente según filtros activos
- **Totales en tiempo real**: Se calculan al cargar grid, no requieren recalculo adicional
- **Formato de fechas**: VB6 usa Int32 (formato serial date), .NET usa DateTime
- **Formato de RUT**: Implementar funciones de formateo FmtCID y vFmtCID en .NET
- **Paginación**: VB6 carga todos los documentos, considerar paginación si >500 registros

### Decisiones de Implementación
- **Recálculo de saldos**: Implementar como endpoint separado o trigger automático
- **Impresión**: Usar generación de PDF con iTextSharp o similar
- **Excel**: Usar EPPlus para generar archivo .xlsx descargable
- **Calendario**: Input type="date" HTML5 suficiente, no requiere FrmCalendar
- **Suma de seleccionados**: Modal JavaScript con checkboxes en grid
- **Conversión de moneda**: Marcar como [FUTURE], requiere API de tipos de cambio

### Pendientes/Incompletos en VB6
- **Bt_ConvMoneda**: Funcional pero requiere integración externa → **MIGRAR con TODO [INTEGRATION]**
- **Bt_Calc**: Abre calculadora de Windows → **MIGRAR con TODO [LEGACY]** (sugerir usar calculadora del SO)
- **Bt_Calendar** standalone: Redundante con Bt_Fecha → **MIGRAR con TODO [LEGACY]** (indicar que ya existe selector de fecha)
- **RecalcSaldos**: Funciones de módulo global, no está en este form → **Investigar implementación** en módulos VB6

---

## ✅ CHECKLIST DE COMPLETITUD DEL ANÁLISIS

- [x] Todos los controles UI documentados
- [x] Todos los botones y eventos mapeados
- [x] **TODOS los botones tienen "Mapeo .NET" definido** (con excepciones documentadas para integraciones futuras)
- [x] **Botones con excepciones documentan razón válida** (INTEGRATION, LEGACY)
- [x] Todas las funciones VB6 identificadas
- [x] Todos los queries SQL traducidos a EF Core
- [x] Todas las validaciones documentadas
- [x] Todas las reglas de negocio identificadas
- [x] Todos los cálculos documentados
- [x] Navegación y flujos mapeados
- [x] Métodos .NET determinados
- [x] Interface del Service definida
- [x] DTOs requeridos especificados
- [x] **Decisiones de excepción justificadas y estructuradas**

---

**✅ ANÁLISIS COMPLETO - LISTO PARA IMPLEMENTACIÓN**
