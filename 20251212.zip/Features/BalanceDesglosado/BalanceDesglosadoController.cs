using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Extensions;
using App.Helpers;

namespace App.Features.BalanceDesglosado;

/// <summary>
/// MVC Controller para Balance Desglosado
/// </summary>
public class BalanceDesglosadoController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<BalanceDesglosadoController> logger) : Controller
{
    /// <summary>
    /// Vista principal del balance desglosado
    /// </summary>
    public IActionResult Index(string tipoDesglose = "AREANEG")
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder al Balance Desglosado";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        var empresaId = SessionHelper.EmpresaId;
        var ano = (short)SessionHelper.Ano;

        logger.LogInformation("Loading Balance Desglosado for empresaId: {EmpresaId}, año: {Ano}, tipo: {TipoDesglose}",
            empresaId, ano, tipoDesglose);

        var request = new BalanceDesglosadoRequest
        {
            EmpresaId = empresaId,
            Ano = ano,
            TipoDesglose = tipoDesglose,
            TipoDesgloseDescripcion = tipoDesglose == "AREANEG" ? "Área de Negocio" : "Centro de Costo"
        };

        return View(request);
    }

}