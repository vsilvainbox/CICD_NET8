namespace App.Features.AuditoriaCuentasDefinidas;

/// <summary>
/// Interfaz para el servicio de auditoría de cuentas definidas.
/// Proporciona funcionalidad para consultar y exportar el historial de cambios
/// en la configuración de cuentas definidas.
/// </summary>
public interface IAuditoriaCuentasDefinidasService
{
    /// <summary>
    /// Obtiene el reporte de auditoría con filtros opcionales
    /// </summary>
    /// <param name="idEmpresa">ID de empresa (opcional)</param>
    /// <param name="annio">Año (opcional)</param>
    /// <param name="usuario">Nombre de usuario (opcional)</param>
    /// <param name="fechaDesde">Fecha desde (opcional)</param>
    /// <param name="fechaHasta">Fecha hasta (opcional)</param>
    /// <returns>Lista de registros de auditoría</returns>
    Task<IEnumerable<AuditoriaCuentasDefinidasDto>> GetFilteredAsync(
        int? idEmpresa = null,
        int? annio = null,
        string? usuario = null,
        DateTime? fechaDesde = null,
        DateTime? fechaHasta = null);

    /// <summary>
    /// Obtiene la lista de empresas disponibles para el filtro
    /// </summary>
    /// <returns>Lista de empresas</returns>
    Task<IEnumerable<ComboItemDto>> GetEmpresasAsync();

    /// <summary>
    /// Obtiene la lista de años disponibles en la tabla Auditoria_Empresas
    /// </summary>
    /// <returns>Lista de años distintos</returns>
    Task<IEnumerable<ComboItemDto>> GetDistinctYearsAsync();

    /// <summary>
    /// Obtiene la lista de usuarios distintos en la tabla de auditoría
    /// </summary>
    /// <returns>Lista de usuarios</returns>
    Task<IEnumerable<ComboItemDto>> GetUsuariosAsync();

    /// <summary>
    /// Valida el rango de fechas
    /// </summary>
    /// <param name="fechaDesde">Fecha desde</param>
    /// <param name="fechaHasta">Fecha hasta</param>
    /// <returns>Resultado de validación</returns>
    Task<ValidationResult> ValidateFiltersAsync(DateTime? fechaDesde, DateTime? fechaHasta);

    /// <summary>
    /// Formatea un RUT al formato XX.XXX.XXX-X
    /// </summary>
    /// <param name="rut">RUT sin formato</param>
    /// <returns>RUT formateado</returns>
    string FormatRut(string rut);

    /// <summary>
    /// Exporta el reporte a Excel
    /// </summary>
    /// <param name="datos">Datos a exportar</param>
    /// <returns>Tupla con el archivo Excel en bytes y el nombre sugerido del archivo</returns>
    Task<(byte[] FileBytes, string FileName)> ExportToExcelAsync(IEnumerable<AuditoriaCuentasDefinidasDto> datos);

    /// <summary>
    /// Exporta el reporte a PDF
    /// </summary>
    /// <param name="datos">Datos a exportar</param>
    /// <returns>Tupla con el archivo PDF en bytes y el nombre sugerido del archivo</returns>
    Task<(byte[] FileBytes, string FileName)> ExportToPdfAsync(IEnumerable<AuditoriaCuentasDefinidasDto> datos);
}