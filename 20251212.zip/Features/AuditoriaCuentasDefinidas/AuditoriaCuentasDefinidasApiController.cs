using Microsoft.AspNetCore.Mvc;

namespace App.Features.AuditoriaCuentasDefinidas;

/// <summary>
/// API Controller para auditoría de cuentas definidas.
/// Proporciona endpoints REST para consultar y exportar el historial de cambios.
/// </summary>
[Route("[controller]/[action]")]
[ApiController]
public class AuditoriaCuentasDefinidasApiController(
    IAuditoriaCuentasDefinidasService service,
    ILogger<AuditoriaCuentasDefinidasApiController> logger) : ControllerBase
{
    /// <summary>
    /// Obtiene el reporte de auditoría con filtros opcionales
    /// </summary>
    /// <param name="idEmpresa">ID de empresa (opcional)</param>
    /// <param name="annio">año (opcional)</param>
    /// <param name="usuario">Usuario (opcional)</param>
    /// <param name="fechaDesde">Fecha desde en formato yyyy-MM-dd (opcional)</param>
    /// <param name="fechaHasta">Fecha hasta en formato yyyy-MM-dd (opcional)</param>
    /// <returns>Lista de registros de auditoría</returns>
    [HttpGet]
    public async Task<ActionResult<IEnumerable<AuditoriaCuentasDefinidasDto>>> GetFiltered(
        [FromQuery] int? idEmpresa = null,
        [FromQuery] int? annio = null,
        [FromQuery] string? usuario = null,
        [FromQuery] DateTime? fechaDesde = null,
        [FromQuery] DateTime? fechaHasta = null)
    {
        {
            logger.LogInformation(
                "GET api/AuditoriaCuentasDefinidas: idEmpresa={IdEmpresa}, annio={Annio}, usuario={Usuario}, fechaDesde={FechaDesde}, fechaHasta={FechaHasta}",
                idEmpresa, annio, usuario, fechaDesde, fechaHasta);

            // Validar filtros
            await service.ValidateFiltersAsync(fechaDesde, fechaHasta);

            var result = await service.GetFilteredAsync(idEmpresa, annio, usuario, fechaDesde, fechaHasta);

            logger.LogInformation("GET api/AuditoriaCuentasDefinidas: Retornando {Count} registros", result.Count());
            return Ok(result);
        }
    }

    /// <summary>
    /// Obtiene la lista de empresas disponibles
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<IEnumerable<ComboItemDto>>> GetEmpresas()
    {
        {
            logger.LogInformation("GET api/AuditoriaCuentasDefinidas/empresas");
            var result = await service.GetEmpresasAsync();
            return Ok(result);
        }
    }

    /// <summary>
    /// Obtiene la lista de años disponibles
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<IEnumerable<ComboItemDto>>> GetYears()
    {
        {
            logger.LogInformation("GET api/AuditoriaCuentasDefinidas/years");
            var result = await service.GetDistinctYearsAsync();
            return Ok(result);
        }
    }

    /// <summary>
    /// Obtiene la lista de usuarios disponibles
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<IEnumerable<ComboItemDto>>> GetUsuarios()
    {
        {
            logger.LogInformation("GET api/AuditoriaCuentasDefinidas/usuarios");
            var result = await service.GetUsuariosAsync();
            return Ok(result);
        }
    }

    /// <summary>
    /// Exporta el reporte filtrado a Excel
    /// </summary>
    /// <param name="idEmpresa">ID de empresa (opcional)</param>
    /// <param name="annio">año (opcional)</param>
    /// <param name="usuario">Usuario (opcional)</param>
    /// <param name="fechaDesde">Fecha desde en formato yyyy-MM-dd (opcional)</param>
    /// <param name="fechaHasta">Fecha hasta en formato yyyy-MM-dd (opcional)</param>
    /// <returns>Archivo Excel</returns>
    [HttpGet]
    public async Task<IActionResult> ExportExcel(
        [FromQuery] int? idEmpresa = null,
        [FromQuery] int? annio = null,
        [FromQuery] string? usuario = null,
        [FromQuery] DateTime? fechaDesde = null,
        [FromQuery] DateTime? fechaHasta = null)
    {
        {
            logger.LogInformation("GET api/AuditoriaCuentasDefinidas/export-excel");

            var datos = await service.GetFilteredAsync(idEmpresa, annio, usuario, fechaDesde, fechaHasta);
            var (excelBytes, fileName) = await service.ExportToExcelAsync(datos);

            logger.LogInformation("Exportando a Excel: {FileName}, {Count} registros", fileName, datos.Count());

            return File(
                excelBytes,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                fileName);
        }
    }

    /// <summary>
    /// Exporta el reporte filtrado a PDF
    /// </summary>
    /// <param name="idEmpresa">ID de empresa (opcional)</param>
    /// <param name="annio">año (opcional)</param>
    /// <param name="usuario">Usuario (opcional)</param>
    /// <param name="fechaDesde">Fecha desde en formato yyyy-MM-dd (opcional)</param>
    /// <param name="fechaHasta">Fecha hasta en formato yyyy-MM-dd (opcional)</param>
    /// <returns>Archivo PDF</returns>
    [HttpGet]
    public async Task<IActionResult> ExportPdf(
        [FromQuery] int? idEmpresa = null,
        [FromQuery] int? annio = null,
        [FromQuery] string? usuario = null,
        [FromQuery] DateTime? fechaDesde = null,
        [FromQuery] DateTime? fechaHasta = null)
    {
        {
            logger.LogInformation("GET api/AuditoriaCuentasDefinidas/export-pdf");

            var datos = await service.GetFilteredAsync(idEmpresa, annio, usuario, fechaDesde, fechaHasta);
            var (pdfBytes, fileName) = await service.ExportToPdfAsync(datos);

            logger.LogInformation("Exportando a PDF: {FileName}, {Count} registros", fileName, datos.Count());

            return File(pdfBytes, "application/pdf", fileName);
        }
    }
}