using Microsoft.AspNetCore.Mvc;

namespace App.Features.AcercaDelSistema;

[ApiController]
[Route("[controller]/[action]")]
public class AcercaDelSistemaApiController(
    IAcercaDelSistemaService service,
    ILogger<AcercaDelSistemaApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<AcercaDelSistemaDto>> Get()
    {
        logger.LogInformation("API: Get called for system information");
            
        {
            var data = await service.GetAsync();
            logger.LogInformation("API: Returning system information");
            return Ok(data);
        }
    }
}