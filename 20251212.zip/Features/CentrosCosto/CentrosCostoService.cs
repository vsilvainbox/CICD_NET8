using Microsoft.EntityFrameworkCore;
using App.Data;
using App.Exceptions;

namespace App.Features.CentrosCosto;

/// <summary>
/// Servicio para gestión de Centros de Costo (Centros de Gestión)
/// Migración de FrmCentrosCosto.frm (VB6) a .NET 9
/// </summary>
public class CentrosCostoService(LpContabContext context, ILogger<CentrosCostoService> logger) : ICentrosCostoService
{
    /// <summary>
    /// Obtiene todos los centros de costo de una empresa
    /// VB6: LoadAll() - SELECT Codigo, idCCosto, Descripcion FROM CentroCosto WHERE IdEmpresa = X ORDER BY Codigo
    /// NOTA: VB6 NO filtra por Vigente, carga todos los registros
    /// </summary>
    public async Task<IEnumerable<CentrosCostoDto>> GetAllAsync(int empresaId)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");

        logger.LogInformation("Getting centros costo for empresaId: {EmpresaId}", empresaId);

        var centrosCosto = await context.CentroCosto
            .Where(c => c.IdEmpresa == empresaId)
            .OrderBy(c => c.Codigo)
            .Select(c => new CentrosCostoDto
            {
                IdCCosto = c.IdCCosto,
                IdEmpresa = c.IdEmpresa,
                Codigo = c.Codigo,
                Descripcion = c.Descripcion,
                Vigente = c.Vigente
            })
            .ToListAsync();

        logger.LogInformation("Found {Count} centros costo for empresaId: {EmpresaId}",
            centrosCosto.Count, empresaId);

        return centrosCosto;
    }

    /// <summary>
    /// Obtiene un centro de costo específico
    /// VB6: Usado en Bt_Edit_Click → lCCosto.id = Grid.TextMatrix(Row, C_ID) → FrmCCosto.FEdit(lCCosto)
    /// </summary>
    public async Task<CentrosCostoDto?> GetByIdAsync(int id, int empresaId)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");

        logger.LogInformation("Getting centro costo with id: {Id} for empresaId: {EmpresaId}", id, empresaId);

        var centroCosto = await context.CentroCosto
            .Where(c => c.IdCCosto == id && c.IdEmpresa == empresaId)
            .Select(c => new CentrosCostoDto
            {
                IdCCosto = c.IdCCosto,
                IdEmpresa = c.IdEmpresa,
                Codigo = c.Codigo,
                Descripcion = c.Descripcion,
                Vigente = c.Vigente
            })
            .FirstOrDefaultAsync();

        if (centroCosto == null)
        {
            logger.LogWarning("Centro costo with id: {Id} not found for empresaId: {EmpresaId}", id, empresaId);
            throw new BusinessException($"Centro de costo con ID {id} no encontrado");
        }

        logger.LogInformation("Centro costo {Codigo} found for empresaId: {EmpresaId}", centroCosto.Codigo, empresaId);

        return centroCosto;
    }

    /// <summary>
    /// Crea un nuevo centro de costo
    /// VB6: Bt_New_Click → FrmCCosto.FNew() → INSERT INTO CentroCosto
    /// Lógica VB6: Código se convierte a mayúsculas, vigente default=-1
    /// </summary>
    public async Task<CentrosCostoDto> CreateAsync(int empresaId, CentrosCostoCreateDto dto)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");

        logger.LogInformation("Creating centro costo {Codigo} for empresaId: {EmpresaId}", dto.Codigo, empresaId);

        // Convertir código a mayúsculas (lógica VB6 KeyUpper)
        var codigo = dto.Codigo?.ToUpper() ?? string.Empty;

        // Validar código único
        var existingCode = await CheckUniqueCodeAsync(codigo, empresaId);
        if (existingCode)
        {
            logger.LogWarning("Cannot create centro costo. Code {Codigo} already exists for empresaId: {EmpresaId}", codigo, empresaId);
            throw new BusinessException($"El código {codigo} ya existe.");
        }

        // Crear nuevo centro de costo usando ruta completa para evitar conflictos
        var centroCosto = new App.Data.CentroCosto
        {
            IdEmpresa = empresaId,
            Codigo = codigo,
            Descripcion = dto.Descripcion,
            Vigente = dto.Vigente
        };

        context.CentroCosto.Add(centroCosto);
        await context.SaveChangesAsync();

        logger.LogInformation("Successfully created centro costo {Codigo} with ID {Id} for empresaId: {EmpresaId}",
            codigo, centroCosto.IdCCosto, empresaId);

        return new CentrosCostoDto
        {
            IdCCosto = centroCosto.IdCCosto,
            IdEmpresa = centroCosto.IdEmpresa,
            Codigo = centroCosto.Codigo,
            Descripcion = centroCosto.Descripcion,
            Vigente = centroCosto.Vigente
        };
    }

    /// <summary>
    /// Actualiza un centro de costo existente
    /// VB6: Bt_Edit_Click → FrmCCosto.FEdit() → UPDATE CentroCosto
    /// </summary>
    public async Task<CentrosCostoDto> UpdateAsync(int id, int empresaId, CentrosCostoUpdateDto dto)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");

        logger.LogInformation("Updating centro costo {Id} with codigo {Codigo} for empresaId: {EmpresaId}",
            id, dto.Codigo, empresaId);

        var centroCosto = await context.CentroCosto
            .FirstOrDefaultAsync(c => c.IdCCosto == id && c.IdEmpresa == empresaId);

        if (centroCosto == null)
        {
            logger.LogWarning("Cannot update. Centro costo with id: {Id} not found for empresaId: {EmpresaId}", id, empresaId);
            throw new BusinessException($"Centro de costo con ID {id} no encontrado.");
        }

        // Convertir código a mayúsculas
        var codigo = dto.Codigo?.ToUpper() ?? string.Empty;

        // Validar código único (excluyendo el registro actual)
        var existingCode = await CheckUniqueCodeAsync(codigo, empresaId, id);
        if (existingCode)
        {
            logger.LogWarning("Cannot update centro costo {Id}. Code {Codigo} already exists for empresaId: {EmpresaId}",
                id, codigo, empresaId);
            throw new BusinessException($"El código {codigo} ya existe.");
        }

        // Actualizar propiedades
        centroCosto.Codigo = codigo;
        centroCosto.Descripcion = dto.Descripcion;
        centroCosto.Vigente = dto.Vigente;

        await context.SaveChangesAsync();

        logger.LogInformation("Successfully updated centro costo {Id} with codigo {Codigo} for empresaId: {EmpresaId}",
            id, codigo, empresaId);

        return new CentrosCostoDto
        {
            IdCCosto = centroCosto.IdCCosto,
            IdEmpresa = centroCosto.IdEmpresa,
            Codigo = centroCosto.Codigo,
            Descripcion = centroCosto.Descripcion,
            Vigente = centroCosto.Vigente
        };
    }

    /// <summary>
    /// Elimina un centro de costo (HARD DELETE)
    /// VB6: Bt_Del_Click → DeleteSQL(DbMain, "CentroCosto", WHERE)
    /// CRÍTICO: VB6 usa HARD DELETE (elimina físicamente), NO soft delete
    /// </summary>
    public async Task<bool> DeleteAsync(int id, int empresaId)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");

        logger.LogInformation("Deleting centro costo {Id} for empresaId: {EmpresaId}", id, empresaId);

        // Verificar si existe el centro de costo
        var centroCosto = await context.CentroCosto
            .FirstOrDefaultAsync(c => c.IdCCosto == id && c.IdEmpresa == empresaId);

        if (centroCosto == null)
        {
            logger.LogWarning("Cannot delete. Centro costo with id: {Id} not found for empresaId: {EmpresaId}", id, empresaId);
            throw new BusinessException($"Centro de costo con ID {id} no encontrado");
        }

        // Verificar si tiene movimientos asociados en MovComprobante
        var hasMovements = await context.MovComprobante
            .AnyAsync(m => m.idCCosto == id);

        if (hasMovements)
        {
            logger.LogWarning("Cannot delete centro costo {Id}. Has associated movements in MovComprobante", id);
            throw new BusinessException("No puede borrar el centro de gestión, existe un movimiento asociado.");
        }

        // HARD DELETE como en VB6 (elimina físicamente)
        context.CentroCosto.Remove(centroCosto);
        await context.SaveChangesAsync();

        logger.LogInformation("Successfully deleted centro costo {Id} ({Codigo}) for empresaId: {EmpresaId}",
            id, centroCosto.Codigo, empresaId);

        return true;
    }

    /// <summary>
    /// Verifica si un código ya existe para una empresa
    /// VB6: Validación implícita en FrmCCosto al guardar
    /// </summary>
    public async Task<bool> CheckUniqueCodeAsync(string codigo, int empresaId, int? excludeId = null)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");
        if (string.IsNullOrWhiteSpace(codigo))
            throw new BusinessException("Debe ingresar un código");

        var codigoUpper = codigo?.ToUpper() ?? string.Empty;

        var query = context.CentroCosto
            .Where(c => c.IdEmpresa == empresaId && c.Codigo == codigoUpper);

        if (excludeId.HasValue)
        {
            query = query.Where(c => c.IdCCosto != excludeId.Value);
        }

        var exists = await query.AnyAsync();

        logger.LogDebug("CheckUniqueCode for {Codigo} in empresaId {EmpresaId} (exclude {ExcludeId}): {Exists}",
            codigoUpper, empresaId, excludeId, exists);

        return exists;
    }

    /// <summary>
    /// Verifica si un centro de costo puede ser eliminado (no tiene movimientos asociados)
    /// VB6: Bt_Del_Click → SELECT Count(*) as n FROM MovComprobante WHERE idCCosto=X
    /// CRÍTICO: Si tiene movimientos asociados, muestra mensaje y NO permite eliminar
    /// </summary>
    public async Task<bool> CanDeleteAsync(int id, int empresaId)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");

        logger.LogInformation("Checking if centro costo {Id} can be deleted for empresaId: {EmpresaId}", id, empresaId);

        // Verificar si existe el centro de costo
        var exists = await context.CentroCosto
            .AnyAsync(c => c.IdCCosto == id && c.IdEmpresa == empresaId);

        if (!exists)
        {
            logger.LogWarning("Centro costo {Id} not found for empresaId: {EmpresaId}", id, empresaId);
            return false;
        }

        // Verificar si tiene movimientos asociados en MovComprobante
        var hasMovements = await context.MovComprobante
            .AnyAsync(m => m.idCCosto == id);

        if (hasMovements)
        {
            logger.LogWarning("Cannot delete centro costo {Id}. Has associated movements in MovComprobante", id);
            return false;
        }

        logger.LogInformation("Centro costo {Id} can be deleted (no associated movements)", id);
        return true;
    }
}

