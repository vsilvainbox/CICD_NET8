namespace App.Features.CentrosCosto;

/// <summary>
/// Interface del servicio de Centros de Costo (Centros de Gestión)
/// Basado en FrmCentrosCosto.frm del sistema VB6
/// </summary>
public interface ICentrosCostoService
{
    /// <summary>
    /// Obtiene todos los centros de costo de una empresa
    /// Mapeo VB6: LoadAll() - SELECT Codigo, idCCosto, Descripcion FROM CentroCosto WHERE IdEmpresa = X ORDER BY Codigo
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <returns>Lista de centros de costo</returns>
    Task<IEnumerable<CentrosCostoDto>> GetAllAsync(int empresaId);

    /// <summary>
    /// Obtiene un centro de costo específico por su ID
    /// Mapeo VB6: Usado en Bt_Edit_Click para cargar datos antes de editar
    /// </summary>
    /// <param name="id">ID del centro de costo</param>
    /// <param name="empresaId">ID de la empresa</param>
    /// <returns>Centro de costo o null si no existe</returns>
    Task<CentrosCostoDto?> GetByIdAsync(int id, int empresaId);

    /// <summary>
    /// Crea un nuevo centro de costo
    /// Mapeo VB6: Bt_New_Click → FrmCCosto.FNew() → INSERT en CentroCosto
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="dto">Datos del centro de costo a crear</param>
    /// <returns>Centro de costo creado</returns>
    Task<CentrosCostoDto> CreateAsync(int empresaId, CentrosCostoCreateDto dto);

    /// <summary>
    /// Actualiza un centro de costo existente
    /// Mapeo VB6: Bt_Edit_Click → FrmCCosto.FEdit() → UPDATE CentroCosto
    /// </summary>
    /// <param name="id">ID del centro de costo a actualizar</param>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="dto">Nuevos datos del centro de costo</param>
    /// <returns>Centro de costo actualizado</returns>
    Task<CentrosCostoDto> UpdateAsync(int id, int empresaId, CentrosCostoUpdateDto dto);

    /// <summary>
    /// Elimina un centro de costo (HARD DELETE)
    /// Mapeo VB6: Bt_Del_Click → DeleteSQL(DbMain, "CentroCosto", WHERE)
    /// IMPORTANTE: VB6 usa hard delete (elimina físicamente), NO soft delete
    /// </summary>
    /// <param name="id">ID del centro de costo a eliminar</param>
    /// <param name="empresaId">ID de la empresa</param>
    /// <returns>True si se eliminó correctamente, false si no existe</returns>
    Task<bool> DeleteAsync(int id, int empresaId);

    /// <summary>
    /// Verifica si un código ya existe para una empresa (validación de unicidad)
    /// Mapeo VB6: Validación implícita en FrmCCosto al guardar
    /// </summary>
    /// <param name="codigo">Código a verificar</param>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="excludeId">ID a excluir de la búsqueda (para edición)</param>
    /// <returns>True si el código ya existe, false si está disponible</returns>
    Task<bool> CheckUniqueCodeAsync(string codigo, int empresaId, int? excludeId = null);

    /// <summary>
    /// Verifica si un centro de costo puede ser eliminado (no tiene movimientos asociados)
    /// Mapeo VB6: Bt_Del_Click → SELECT Count(*) FROM MovComprobante WHERE idCCosto = X
    /// CRÍTICO: Si tiene movimientos asociados, NO puede eliminarse
    /// </summary>
    /// <param name="id">ID del centro de costo</param>
    /// <param name="empresaId">ID de la empresa</param>
    /// <returns>True si puede eliminarse, false si tiene movimientos asociados</returns>
    Task<bool> CanDeleteAsync(int id, int empresaId);
}

