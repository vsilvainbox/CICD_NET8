using Microsoft.AspNetCore.Mvc;
using App.Extensions;
using App.Helpers;

namespace App.Features.CentrosCosto;

/// <summary>
/// Controller MVC para Centros de Costo
/// Migración de FrmCentrosCosto.frm (VB6)
/// </summary>

public class CentrosCostoController(
    ICentrosCostoService service,
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<CentrosCostoController> logger) : Controller
{
    /// <summary>
    /// Vista principal de Centros de Costo
    /// Mapeo VB6: FrmCentrosCosto.FEdit() - modo edición completa
    /// GET /CentrosCosto
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Centros de Costo";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        var empresaId = SessionHelper.EmpresaId;
        logger.LogInformation("Loading CentrosCosto index for empresaId: {EmpresaId}", empresaId);

        {
            // Cargar datos iniciales desde API interna
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<CentrosCostoApiController>(
                HttpContext,
                nameof(CentrosCostoApiController.GetAll),
                new { empresaId }
            );
            var centrosCosto = await client.GetFromApiAsync<List<CentrosCostoDto>>(url!);

            logger.LogInformation("Successfully loaded {Count} centros costo for empresaId: {EmpresaId}",
                centrosCosto?.Count ?? 0, empresaId);

            return View(centrosCosto ?? new List<CentrosCostoDto>());
        }
    }

    /// <summary>
    /// Guarda (Crea o Edita) un centro de costo
    /// POST /CentrosCosto/Save
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Save([FromForm] CentrosCostoFormDto form)
    {
        if (!ModelState.IsValid)
        {
            return Json(new { success = false, message = "Datos inválidos", errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage) });
        }

        var empresaId = SessionHelper.EmpresaId;
        
        try 
        {
            if (form.IdCCosto == 0)
            {
                // Crear
                var createDto = new CentrosCostoCreateDto
                {
                    Codigo = form.Codigo,
                    Descripcion = form.Descripcion,
                    Vigente = form.Vigente
                };
                await service.CreateAsync(empresaId, createDto);
                return Json(new { success = true, message = "Centro de gestión creado correctamente" });
            }
            else
            {
                // Actualizar
                var updateDto = new CentrosCostoUpdateDto
                {
                    Codigo = form.Codigo,
                    Descripcion = form.Descripcion,
                    Vigente = form.Vigente
                };
                await service.UpdateAsync(form.IdCCosto, empresaId, updateDto);
                return Json(new { success = true, message = "Centro de gestión actualizado correctamente" });
            }
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error saving CentroCosto");
            return Json(new { success = false, message = ex.Message });
        }
    }
}
