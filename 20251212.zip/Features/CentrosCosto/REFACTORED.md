# CentrosCosto - Refactorización Completada

## Cambios Aplicados (2025-12-07)

### R04 - URLs hardcodeadas → @Url.Action (6 URLs)

- ✅ `URL_ENDPOINTS` actualizado para usar `@Url.Action()` en lugar de strings hardcodeadas
- ✅ getAll → `@Url.Action("GetAll", "CentrosCostoApi")`
- ✅ getById → `@Url.Action("GetById", "CentrosCostoApi")`
- ✅ create → `@Url.Action("Create", "CentrosCostoApi")`
- ✅ update → `@Url.Action("Update", "CentrosCostoApi")`
- ✅ canDelete → `@Url.Action("CanDelete", "CentrosCostoApi")`
- ✅ delete → `@Url.Action("Delete", "CentrosCostoApi")`

### R16 - ProxyRequestAsync eliminado (1 instancia)

- ✅ Eliminado método `SaveForm` que usaba `ProxyRequestAsync`
- ✅ Eliminados imports no usados (`System.Text.Json`, `System.Linq`)

### R19 - Métodos proxy eliminados → Vista llama ApiController directo (4 métodos)

- ✅ Eliminados métodos proxy del WebController:
  - `GetAll(int empresaId)`
  - `GetById(int id, int empresaId)`
  - `CanDelete(int id, int empresaId)`
  - `Create([FromBody] JsonElement request)`
  - `Update(int id, [FromBody] JsonElement request)`
  - `Delete(int id, int empresaId)`
  - `SaveForm([FromForm] CentrosCostoFormDto formDto)`
- ✅ Vista ahora llama directamente al ApiController via `Api.*`
- ✅ Nueva función `guardarCentroCosto()` que usa `Api.postJson` y `Api.put`

### R21 - Modal local → función global (1 función)

- ✅ `cerrarCentroCostoModal()` usa `cerrarModal('modalCentroCosto')` global de _Layout
- ✅ Formulario cambiado de `data-form-submit` a `onclick="guardarCentroCosto()"`

## Archivos Modificados

- `CentrosCostoController.cs` - R16, R19 (eliminados métodos proxy)
- `Views/Index.cshtml` - R04, R19, R21

## Fecha

2025-12-07
