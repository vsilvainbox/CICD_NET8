using Microsoft.AspNetCore.Mvc;
using App.Helpers;

namespace App.Features.CapitalSimpleAcumulado;

public class CapitalSimpleAcumuladoController(
    ILogger<CapitalSimpleAcumuladoController> logger) : Controller
{
    public IActionResult Index(int tipoDetCPS = 1)
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Capital Simple Acumulado";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        logger.LogInformation("Cargando vista Capital Simple Acumulado");

        var viewModel = new CapitalSimpleAcumuladoIndexViewModel
        {
            EmpresaId = SessionHelper.EmpresaId,
            Ano = (short)SessionHelper.Ano,
            TipoDetCPS = tipoDetCPS
        };

        return View(viewModel);
    }
}
