# Refactorización - CapitalSimpleAcumulado

**Fecha:** 2025-12-07
**Guía aplicada:** refactor.md
**Violaciones detectadas:** R19 (proxy), R20 (fetch-manual)

---

## Resumen de Cambios

### 1. R19: JavaScript debe llamar a ApiController directamente (no proxy via WebController)

**Problema detectado:**
- El WebController tenía métodos proxy `Obtener` y `Guardar` que reenviaban las peticiones al ApiController
- JavaScript llamaba al WebController en lugar del ApiController directamente

**Archivos modificados:**

#### `CapitalSimpleAcumuladoController.cs`
**ANTES:**
```csharp
public class CapitalSimpleAcumuladoController(
    ILogger<CapitalSimpleAcumuladoController> logger,
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator) : Controller
{
    // ... método Index ...

    [HttpGet]
    public async Task<IActionResult> Obtener(int empresaId, int anoActual, int tipoDetCPS)
    {
        // Método proxy eliminado
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<CapitalSimpleAcumuladoApiController>(...);
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    [HttpPost]
    public async Task<IActionResult> Guardar([FromBody] JsonElement request)
    {
        // Método proxy eliminado
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<CapitalSimpleAcumuladoApiController>(...);
        var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }
}
```

**DESPUÉS:**
```csharp
public class CapitalSimpleAcumuladoController(
    ILogger<CapitalSimpleAcumuladoController> logger) : Controller
{
    public IActionResult Index(int tipoDetCPS = 1)
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Capital Simple Acumulado";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        logger.LogInformation("Cargando vista Capital Simple Acumulado");

        var viewModel = new CapitalSimpleAcumuladoIndexViewModel
        {
            EmpresaId = SessionHelper.EmpresaId,
            Ano = (short)SessionHelper.Ano,
            TipoDetCPS = tipoDetCPS
        };

        return View(viewModel);
    }
}
```

**Cambios realizados:**
- Eliminados métodos proxy `Obtener` y `Guardar`
- Removidas dependencias innecesarias: `IHttpClientFactory`, `LinkGenerator`, `System.Text.Json`, `App.Extensions`
- WebController ahora solo maneja la vista Index

---

### 2. R20: Reemplazar fetch/ajax manual por Api.get/Api.post/Api.postForm helpers

**Problema detectado:**
- JavaScript usaba `fetch()` manual para obtener y guardar datos
- No seguía el patrón estandarizado de helpers `Api.*`

**Archivos modificados:**

#### `Views/Index.cshtml`

**ANTES:**
```javascript
const URL_ENDPOINTS = {
    obtener: '@Url.Action("Obtener", "CapitalSimpleAcumulado")',  // ← Apuntaba a WebController
    guardar: '@Url.Action("Guardar", "CapitalSimpleAcumulado")'   // ← Apuntaba a WebController
};

async function cargarDatos() {
    const loading = document.getElementById('loadingIndicator');
    const contenedor = document.getElementById('contenedor');

    loading.classList.remove('hidden');
    contenedor.classList.add('hidden');

    try {
        const response = await fetch(  // ← fetch manual
            `${URL_ENDPOINTS.obtener}?empresaId=${empresaId}&anoActual=${ano}&tipoDetCPS=${tipoDetCPS}`,
            {
                headers: { 'Accept': 'application/json' }
            }
        );

        if (!response.ok) throw new Error('Error cargando datos');

        datosActuales = await response.json();

        document.getElementById('titulo').textContent = 'Acumulado Anual ' + datosActuales.titulo;
        renderizarValores();

    } catch (error) {
        window.handleFrontendError(error, 'Error', 'Se produjo un error en la operación.', 'Por favor, intente nuevamente.');
    } finally {
        loading.classList.add('hidden');
        contenedor.classList.remove('hidden');
    }
}

async function guardarDatos() {
    try {
        const request = {
            empresaId: empresaId,
            tipoDetCPS: tipoDetCPS,
            valores: datosActuales.valores
        };

        const response = await fetch(URL_ENDPOINTS.guardar, {  // ← fetch manual
            method: 'POST',
            headers: {'Content-Type': 'application/json', 'Accept': 'application/json'},
            body: JSON.stringify(request)
        });

        if (!response.ok) throw new Error('Error guardando');

        await Swal.fire('Éxito', 'Datos guardados correctamente', 'success');
        window.history.back();
    } catch (error) {
        window.handleFrontendError(error, 'Error', 'Se produjo un error en la operación.', 'Por favor, intente nuevamente.');
    }
}
```

**DESPUÉS:**
```javascript
const URL_ENDPOINTS = {
    obtener: '@Url.Action("Obtener", "CapitalSimpleAcumuladoApi")',  // ← Ahora apunta al ApiController
    guardar: '@Url.Action("Guardar", "CapitalSimpleAcumuladoApi")'   // ← Ahora apunta al ApiController
};

async function cargarDatos() {
    const loading = document.getElementById('loadingIndicator');
    const contenedor = document.getElementById('contenedor');

    loading.classList.remove('hidden');
    contenedor.classList.add('hidden');

    const datos = await Api.get(URL_ENDPOINTS.obtener, {  // ← Usa Api.get
        empresaId: empresaId,
        anoActual: ano,
        tipoDetCPS: tipoDetCPS
    });

    if (datos) {
        datosActuales = datos;
        document.getElementById('titulo').textContent = 'Acumulado Anual ' + datosActuales.titulo;
        renderizarValores();
    }

    loading.classList.add('hidden');
    contenedor.classList.remove('hidden');
}

async function guardarDatos() {
    const request = {
        empresaId: empresaId,
        tipoDetCPS: tipoDetCPS,
        valores: datosActuales.valores
    };

    const result = await Api.postJson(URL_ENDPOINTS.guardar, request);  // ← Usa Api.postJson

    if (result) {
        await Swal.fire('Éxito', 'Datos guardados correctamente', 'success');
        window.history.back();
    }
}
```

**Cambios realizados:**
- URLs ahora apuntan a `CapitalSimpleAcumuladoApi` (ApiController) en lugar de `CapitalSimpleAcumulado` (WebController)
- Reemplazado `fetch()` manual por `Api.get()` en `cargarDatos()`
- Reemplazado `fetch()` manual por `Api.postJson()` en `guardarDatos()`
- Eliminado manejo manual de errores (los helpers `Api.*` ya manejan errores con SweetAlert)
- Eliminado bloque try-catch innecesario
- Código más limpio y consistente con el estándar del proyecto

---

### 3. R02: Controllers sin try-catch (corrección adicional)

**Problema detectado:**
- ApiController retornaba mensaje envuelto en objeto JSON innecesario

**Archivos modificados:**

#### `CapitalSimpleAcumuladoApiController.cs`

**ANTES:**
```csharp
[HttpPost]
public async Task<IActionResult> Guardar([FromBody] CapitalSimpleAcumuladoRequestDto request)
{
    logger.LogInformation("API: Guardar valores anuales");
    await service.GuardarValoresAnualesAsync(request.EmpresaId, request.TipoDetCPS, request.Valores);
    return Ok(new { message = "Datos guardados exitosamente" });  // ← Envoltorio innecesario
}
```

**DESPUÉS:**
```csharp
[HttpPost]
public async Task<IActionResult> Guardar([FromBody] CapitalSimpleAcumuladoRequestDto request)
{
    logger.LogInformation("API: Guardar valores anuales");
    await service.GuardarValoresAnualesAsync(request.EmpresaId, request.TipoDetCPS, request.Valores);
    return Ok();  // ← Solo Ok() para operaciones void
}
```

**Cambios realizados:**
- Eliminado envoltorio `new { message = "..." }` innecesario
- ApiController retorna `Ok()` directamente según la guía R02

---

## Verificación de Reglas

### Service
- [x] R06 - Reutiliza lógica existente (no hay duplicación)
- [x] R15 - Lanza excepciones apropiadamente
- [x] R17 - Tipos SQL correctos

### ApiController
- [x] R02 - Sin try-catch
- [x] R02 - Retorna Ok()/Ok(data) sin envoltorio

### WebController
- [x] R02 - Sin try-catch
- [x] R03 - Ya no llama a Service (eliminados métodos proxy)
- [x] R19 - Eliminados métodos proxy que reenviaban al ApiController

### Vista
- [x] R04 - URLs con @Url.Action apuntando al ApiController
- [x] R19 - JS llama directamente a ApiController
- [x] R20 - Usa Api.get y Api.postJson (no fetch manual)

---

## Archivos Modificados

1. `CapitalSimpleAcumuladoController.cs` - Eliminados métodos proxy (R19)
2. `Views/Index.cshtml` - Reemplazado fetch por Api.* y actualizado endpoints (R19 + R20)
3. `CapitalSimpleAcumuladoApiController.cs` - Eliminado envoltorio de mensaje (R02)

---

## Estado Final

✅ **R19 RESUELTO:** JavaScript ahora llama directamente al ApiController sin pasar por el WebController
✅ **R20 RESUELTO:** Eliminado fetch manual, ahora usa Api.get() y Api.postJson()
✅ **R02 MEJORADO:** ApiController retorna Ok() sin envoltorio innecesario

**Violaciones restantes:** 0

La feature ahora cumple con todas las reglas de refactorización aplicables.
