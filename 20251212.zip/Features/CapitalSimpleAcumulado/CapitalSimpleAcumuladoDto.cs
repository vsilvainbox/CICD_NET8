namespace App.Features.CapitalSimpleAcumulado;

public class ValorAnualDto
{
    public int IdCapPropioSimplAnual { get; set; }
    public short AnoValor { get; set; }
    public decimal Valor { get; set; }
    public bool? IngresoManual { get; set; }
    public bool EsEditable => IngresoManual == true;
}

public class CapitalSimpleAcumuladoRequestDto
{
    public int EmpresaId { get; set; }
    public byte TipoDetCPS { get; set; }
    public List<ValorAnualDto> Valores { get; set; } = new List<ValorAnualDto>();
}

public class CapitalSimpleAcumuladoResponseDto
{
    public string Titulo { get; set; } = string.Empty;
    public List<ValorAnualDto> Valores { get; set; } = new List<ValorAnualDto>();
    public decimal Total { get; set; }
}

#region ViewModels

public class CapitalSimpleAcumuladoIndexViewModel
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public int TipoDetCPS { get; set; }
}

#endregion