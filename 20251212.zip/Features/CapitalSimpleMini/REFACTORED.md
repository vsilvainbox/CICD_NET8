# Refactorización Completada - CapitalSimpleMini

**Fecha:** 2025-12-07
**Guía aplicada:** D:\deploy\refactor.md

## Resumen de Violaciones Detectadas

Se identificaron 4 violaciones en la feature CapitalSimpleMini:
- **R16**: 1 violación - Uso de `GetFromApiAsync` en WebController
- **R19**: 1 violación - Uso de métodos proxy en WebController (`GetData`, `SaveData`)
- **R20**: 2 violaciones - Uso de `fetch` manual en lugar de helpers `Api.*`

## Cambios Aplicados

### 1. CapitalSimpleMiniController.cs

#### R16 + R19: Eliminación de métodos proxy
**Antes:**
```csharp
public class CapitalSimpleMiniController(
    ILogger<CapitalSimpleMiniController> logger,
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator) : Controller
{
    // Método proxy para GetData (GET)
    [HttpGet]
    public async Task<IActionResult> GetData(int empresaId, short ano, int tipoDetCps, int tipoInforme)
    {
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<CapitalSimpleMiniApiController>(
            HttpContext,
            nameof(CapitalSimpleMiniApiController.GetData),
            new { empresaId, ano, tipoDetCps, tipoInforme });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    // Método proxy para SaveData (POST)
    [HttpPost]
    public async Task<IActionResult> SaveData([FromBody] JsonElement request)
    {
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<CapitalSimpleMiniApiController>(
            HttpContext,
            nameof(CapitalSimpleMiniApiController.SaveData));
        var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }
}
```

**Después:**
```csharp
public class CapitalSimpleMiniController(
    ILogger<CapitalSimpleMiniController> logger) : Controller
{
    public IActionResult Index(
        int? tipoDetCps = null,
        int? tipoInforme = null)
    {
        // Solo contiene la lógica de la vista Index
        // Sin métodos proxy
    }
}
```

**Justificación:**
- **R19**: JavaScript debe llamar directamente al ApiController, no usar proxy via WebController
- **R16**: Se eliminó el uso innecesario de `HttpClientFactory` y `LinkGenerator` del WebController
- Se simplificó el controller eliminando dependencias no necesarias

---

### 2. Views/Index.cshtml

#### R04 + R19: URLs apuntando directamente al ApiController

**Antes:**
```javascript
// URL Endpoints - Arquitectura correcta: Vista → MVC Controller → API
const URL_ENDPOINTS = {
    getData: '@Url.Action("GetData", "CapitalSimpleMini")',
    saveData: '@Url.Action("SaveData", "CapitalSimpleMini")'
};
```

**Después:**
```javascript
// R04 + R19: URLs apuntan directamente al ApiController (no proxy via WebController)
const URL_ENDPOINTS = {
    getData: '@Url.Action("GetData", "CapitalSimpleMiniApi")',
    saveData: '@Url.Action("SaveData", "CapitalSimpleMiniApi")'
};
```

**Justificación:**
- **R04**: URLs generadas con `@Url.Action()` (type-safe, no hardcodeadas)
- **R19**: JavaScript llama directamente a `CapitalSimpleMiniApi` (ApiController), eliminando el patrón proxy prohibido

---

#### R20: Reemplazo de fetch manual por Api.get

**Antes:**
```javascript
async function loadData() {
    try {
        Swal.fire({
            title: 'Cargando...',
            text: 'Obteniendo datos',
            allowOutsideClick: false,
            didOpen: () => { Swal.showLoading(); }
        });

        const response = await fetch(
            `${URL_ENDPOINTS.getData}?empresaId=${empresaId}&ano=${ano}&tipoDetCps=${tipoDetCps}&tipoInforme=${tipoInforme}`,
            {
                headers: {
                    'Accept': 'application/json'
                }
            }
        );

        if (!response.ok) {
            throw new Error('Error al cargar datos');
        }

        dataOriginal = await response.json();
        // ...
    } catch (error) {
        console.error('Error loading data:', error);
        Swal.fire('Error', 'No se pudieron cargar los datos: ' + error.message, 'error');
    }
}
```

**Después:**
```javascript
async function loadData() {
    try {
        Swal.fire({
            title: 'Cargando...',
            text: 'Obteniendo datos',
            allowOutsideClick: false,
            didOpen: () => { Swal.showLoading(); }
        });

        // R20: Usar Api.get en lugar de fetch manual
        const data = await Api.get(URL_ENDPOINTS.getData, {
            empresaId: empresaId,
            ano: ano,
            tipoDetCps: tipoDetCps,
            tipoInforme: tipoInforme
        });

        if (!data) {
            // Api.get ya mostró el error con SweetAlert
            return;
        }

        dataOriginal = data;
        // ...
    } catch (error) {
        console.error('Error loading data:', error);
        // R15: No ocultar errores, mostrar SweetAlert
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'No se pudieron cargar los datos: ' + error.message
        });
    }
}
```

**Justificación:**
- **R20**: Uso de `Api.get()` en lugar de `fetch` manual
- **R15**: Manejo consistente de errores con SweetAlert (no errores silenciosos)
- Código más limpio y mantenible
- Los helpers `Api.*` manejan automáticamente errores y muestran SweetAlert

---

#### R20: Reemplazo de fetch manual por Api.postJson

**Antes:**
```javascript
async function guardarCambios() {
    // ... validaciones ...
    try {
        Swal.fire({
            title: 'Guardando...',
            text: 'Guardando cambios',
            allowOutsideClick: false,
            didOpen: () => { Swal.showLoading(); }
        });

        const data = {
            empresaId: empresaId,
            ano: ano,
            tipoDetCps: tipoDetCps,
            detalles: detallesModificados
        };

        const response = await fetch(URL_ENDPOINTS.saveData, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify(data)
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message || 'Error al guardar');
        }

        await Swal.fire({
            icon: 'success',
            title: 'Éxito',
            text: 'Cambios guardados correctamente',
            confirmButtonColor: '#d64000',
            timer: 2000
        });

        await loadData();

    } catch (error) {
        console.error('Error saving:', error);
        Swal.fire('Error', 'Error al guardar los cambios: ' + error.message, 'error');
    }
}
```

**Después:**
```javascript
async function guardarCambios() {
    // ... validaciones ...
    try {
        Swal.fire({
            title: 'Guardando...',
            text: 'Guardando cambios',
            allowOutsideClick: false,
            didOpen: () => { Swal.showLoading(); }
        });

        const requestData = {
            empresaId: empresaId,
            ano: ano,
            tipoDetCps: tipoDetCps,
            detalles: detallesModificados
        };

        // R20: Usar Api.postJson en lugar de fetch manual
        const result = await Api.postJson(URL_ENDPOINTS.saveData, requestData);

        if (!result) {
            // Api.postJson ya mostró el error con SweetAlert
            return;
        }

        await Swal.fire({
            icon: 'success',
            title: 'Éxito',
            text: 'Cambios guardados correctamente',
            confirmButtonColor: '#d64000',
            timer: 2000
        });

        await loadData();

    } catch (error) {
        console.error('Error saving:', error);
        // R15: No ocultar errores, mostrar SweetAlert
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Error al guardar los cambios: ' + error.message
        });
    }
}
```

**Justificación:**
- **R20**: Uso de `Api.postJson()` en lugar de `fetch` manual
- **R15**: Manejo consistente de errores con SweetAlert
- Eliminación de código boilerplate (headers, stringify, response.ok, etc.)
- Mayor consistencia con el resto de la aplicación

---

## Reglas Verificadas

### CapitalSimpleMiniService.cs
- [x] R06 - Reutiliza lógica existente (no duplica código)
- [x] R14 - Propiedades en PascalCase
- [x] R15 - Usa BusinessException para errores de validación
- [x] R17 - Tipos SQL correctos (short para smallint, byte para tinyint)
- [x] R22 - No aplica (no usa entidades HasNoKey con Add/Update/Remove)

### CapitalSimpleMiniApiController.cs
- [x] R02 - Sin try-catch (middleware maneja errores)
- [x] R02 - Retorna Ok()/Ok(data) correctamente
- [x] R06 - No duplica endpoints
- [x] R14 - Parámetros correctos
- [x] R15 - No captura excepciones

### CapitalSimpleMiniController.cs
- [x] R02 - Sin try-catch
- [x] R03 - Ya no aplica (eliminados métodos que llamaban a API)
- [x] R04 - Ya no aplica (eliminados métodos con URLs)
- [x] R16 - **CORREGIDO** - Eliminados métodos con GetFromApiAsync/ProxyRequestAsync
- [x] R19 - **CORREGIDO** - Eliminados métodos proxy

### Views/Index.cshtml
- [x] R04 - **CORREGIDO** - URLs con @Url.Action() apuntando a ApiController
- [x] R07 - Header con icono y título (estilo personalizado de esta feature)
- [x] R08 - Orden correcto (header, info, tabla, botones)
- [x] R09 - No aplica (no tiene empty state, siempre muestra tabla editable)
- [x] R10 - Usa inputs estándar HTML (no tag helpers por ser tabla dinámica)
- [x] R11 - Botones funcionales (sin disabled/próximamente)
- [x] R12 - Operaciones CRUD con Api.* (no Form POST)
- [x] R13 - Sin paginación (tabla simple)
- [x] R15 - Errores con SweetAlert
- [x] R18 - No aplica (no usa FormHandler, es tabla editable con JavaScript)
- [x] R19 - **CORREGIDO** - JavaScript llama directamente a ApiController
- [x] R20 - **CORREGIDO** - Usa Api.get y Api.postJson (no fetch manual)
- [x] R21 - No aplica (no tiene modales)
- [x] CSS - Inputs con clases correctas (bg-white, borders, focus:ring-primary-500)
- [x] CSS - Sin appearance-none
- [x] CSS - Sin dark:*
- [x] CSS - Colores primary-* para botones principales

---

## Verificación de Violaciones

### Antes de la refactorización:
```
R16: 1 violación - GetFromApiAsync en CapitalSimpleMiniController.cs línea 59
R19: 1 violación - Métodos proxy GetData y SaveData en CapitalSimpleMiniController.cs
R20: 2 violaciones - fetch manual en Index.cshtml líneas 132 y 438
```

### Después de la refactorización:
```
R16: 0 violaciones
R19: 0 violaciones
R20: 0 violaciones
```

---

## Notas Adicionales

1. **Patrón proxy eliminado completamente**: El WebController ahora solo contiene el método `Index()` que renderiza la vista. No hay métodos intermediarios entre JavaScript y el ApiController.

2. **Flujo de datos simplificado**:
   - **Antes**: Vista → WebController (proxy) → ApiController → Service
   - **Después**: Vista → ApiController → Service

3. **Beneficios obtenidos**:
   - Código más limpio y mantenible
   - Eliminación de capa innecesaria (métodos proxy)
   - Manejo consistente de errores con helpers `Api.*`
   - Reducción de líneas de código
   - Mayor adherencia a las reglas de arquitectura del proyecto

4. **Compatibilidad**: Los cambios son compatibles con la arquitectura existente. El ApiController no requiere modificaciones.

5. **Testing recomendado**:
   - Verificar carga de datos al abrir la vista
   - Probar agregar nuevas filas
   - Probar editar filas existentes
   - Probar eliminar filas de ingreso manual
   - Verificar guardado de cambios
   - Verificar manejo de errores (validaciones, errores de servidor)

---

## Estado Final

**FEATURE TOTALMENTE REFACTORIZADA**

- Todas las violaciones detectadas han sido corregidas
- El código cumple con las reglas R16, R19 y R20 del documento refactor.md
- La feature está lista para testing y deployment
