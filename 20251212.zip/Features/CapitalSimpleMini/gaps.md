# Gaps de Paridad: CapitalSimpleMini

## Resumen Ejecutivo
| Métrica | Valor |
|---------|-------|
| **Feature** | CapitalSimpleMini |
| **Paridad General** | 94.2% |
| **Gaps Críticos** | 0 |
| **Gaps Mayores** | 1 |
| **Gaps Menores** | 3 |

## Metodología
Análisis basado en 86 aspectos de auditoría (71 estructurales + 15 funcionales) comparando `FrmDetCapPropioSimplMini.frm` con implementación .NET.

---

## Gaps Identificados

### 🟠 GAPS MAYORES (Funcionalidad Importante)

#### GAP-CPSM-001: Botón Base Imponible Acumulada
- **Categoría:** Navegación Modal
- **VB6:** Bt_DetCapAcum abre FrmDetCapPropioSimplAcum para ver/editar acumulados anuales
- **Estado .NET:** Navegación a formulario de acumulados no implementada
- **Impacto:** Usuario no puede gestionar acumulados de años anteriores
- **Esfuerzo Estimado:** 3 días
- **Prioridad:** 🟠 ALTA

---

### 🟡 GAPS MENORES (Mejoras de UX)

#### GAP-CPSM-002: Sincronización Scroll Grillas
- **Categoría:** UX Grillas
- **VB6:** Grid.Scroll sincroniza GridTot.LeftCol con Grid.LeftCol
- **Estado .NET:** Sincronización horizontal no implementada
- **Esfuerzo Estimado:** 1 día
- **Prioridad:** 🟡 MEDIA

#### GAP-CPSM-003: Validación Fecha Año Actual
- **Categoría:** Validación
- **VB6:** Grid.AcceptValue valida que fecha sea del año actual
- **Estado .NET:** Verificar validación de rango de fecha
- **Esfuerzo Estimado:** 0.5 días
- **Prioridad:** 🟡 MEDIA

#### GAP-CPSM-004: Herramientas Auxiliares
- **Categoría:** Herramientas
- **VB6:** Calculadora suma, conversor moneda, calendario
- **Estado .NET:** Parcialmente implementados
- **Esfuerzo Estimado:** 2 días
- **Prioridad:** 🟡 MEDIA

---

## Funcionalidades Correctamente Migradas ✅

| Funcionalidad | Estado |
|---------------|--------|
| Grilla editable con ajustes manuales | ✅ Completo |
| Separación años anteriores (solo lectura) vs año actual (editable) | ✅ Completo |
| Marca de ingreso manual (C_INGRESOMANUAL) | ✅ Completo |
| Cálculo total acumulado automático | ✅ Completo |
| Grilla de totales (GridTot) | ✅ Completo |
| CRUD registros DetCapPropioSimpl | ✅ Completo |
| Actualización EmpresasAno (CPS_OtrosAjustes*) | ✅ Completo |
| UPDATE/INSERT CapPropioSimplAnual | ✅ Completo |
| Validación fila anterior completa antes de editar | ✅ Completo |
| Vista previa e impresión | ✅ Completo |
| Exportación a Excel | ✅ Completo |
| Eliminación con confirmación | ✅ Completo |
| Tipos: Aumentos (CPS_OTROSAJUSTAUMENTOS) y Disminuciones (CPS_OTROSAJUSTDISMIN) | ✅ Completo |

---

## Resumen por Severidad

| Severidad | Cantidad | Esfuerzo Total |
|-----------|----------|----------------|
| 🔴 Crítico | 0 | 0 días |
| 🟠 Mayor | 1 | 3 días |
| 🟡 Menor | 3 | 3.5 días |
| **Total** | **4** | **6.5 días** |

---

## Notas de Implementación

1. **TipoDetCapPropioSimpl:** Distinguir entre aumentos y disminuciones
2. **TipoInforme:** GENERAL incluye acumulados, VARANUAL solo año actual
3. **Años Anteriores:** Filas de años anteriores tienen fondo gris y no son editables
4. **Validación Secuencial:** No se puede editar fila N si fila N-1 está incompleta
5. **Columna C_UPDATE:** Valores FGR_I (insert), FGR_U (update), FGR_D (delete)
