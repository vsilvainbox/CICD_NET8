using Microsoft.AspNetCore.Mvc;
using App.Helpers;

namespace App.Features.CapitalSimpleMini;

public class CapitalSimpleMiniController(
    ILogger<CapitalSimpleMiniController> logger) : Controller
{
    public IActionResult Index(
        int? tipoDetCps = null,
        int? tipoInforme = null)
    {
        // Obtener empresaId y ano desde sesión (BaseController)
        var empresaId = SessionHelper.EmpresaId;
        var ano = SessionHelper.Ano;

        if (empresaId == 0)
        {
            logger.LogWarning("No empresa selected in session, redirecting to SeleccionarEmpresa");
            TempData["SwalError"] = "Debe seleccionar una empresa";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        // Usar valores por defecto si no se proporcionan
        var tipoDetCpsValue = tipoDetCps ?? 1; // Default: CPS_OTROSAJUSTAUMENTOS
        var tipoInformeValue = tipoInforme ?? 0; // Default: CPS_TIPOINFO_GENERAL

        logger.LogInformation("Loading CapitalSimpleMini for empresa: {EmpresaId}, ano: {Ano}, tipo: {TipoDetCps}, informe: {TipoInforme}",
            empresaId, ano, tipoDetCpsValue, tipoInformeValue);

        var viewModel = new CapitalSimpleMiniIndexViewModel
        {
            TipoDetCps = tipoDetCpsValue,
            TipoInforme = tipoInformeValue
        };

        return View(viewModel);
    }
}
