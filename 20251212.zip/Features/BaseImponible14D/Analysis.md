# Legacy Analysis: Base Imponible 14D

## 📄 Información del Formulario VB6

**Archivo VB6:** `old/Contabilidad70/HyperContabilidad/FrmBaseImponible14D.frm`
**Fecha Análisis:** 2024-01-15
**Analista:** IA
**Complejidad:** Media

### Propósito del Formulario
Este formulario permite visualizar y editar la Base Imponible de Primera Categoría según Régimen 14D (Pro Pyme) para el año tributario actual. Soporta dos regímenes: Pro Pyme General (14D N°3) y Pro Pyme Transparente (14D N°8).

---

## 🎨 CONTROLES UI IDENTIFICADOS

### Grillas (FlexEdGrid)
| Control VB6 | Fuente Datos | Columnas | Eventos | Acciones |
|-------------|--------------|----------|---------|----------|
| Grid | EmpresasAno.CPS_BaseImpPrimCat_14DN3, CPS_BaseImpPrimCat_14DN8 | 3 cols: Régimen, Monto, Update | DblClick | DblClick abre FrmBaseImponible14DFull para edición detallada |

**Estructura de la Grilla:**
```vb
' 2 filas fijas de datos (sin headers dinámicos)
R_14DN3 = 1  ' Fila para Pro Pyme General
R_14DN8 = 2  ' Fila para Pro Pyme Transparente

C_REGIMEN = 0  ' Nombre del régimen
C_MONTO = 1    ' Valor de la base imponible
C_UPDATE = 2   ' Flag de actualización (oculto)
```

### Botones de Acción
| Botón VB6 | Caption | Habilitado Si | Acción | Mapeo .NET |
|-----------|---------|---------------|--------|------------|
| Bt_OK | "Cerrar" | Siempre | Valida, guarda y cierra | N/A (navegación) |
| Bt_Preview | [Icono] | Siempre | Vista previa de impresión | PreviewAsync() |
| Bt_Print | [Icono] | Siempre | Imprime grilla | PrintAsync() |
| Bt_CopyExcel | [Icono] | Siempre | Copia a clipboard formato Excel | ExportToExcelAsync() |
| Bt_Sum | [Icono] | Siempre | Abre calculadora de suma | N/A (cliente JS) |
| Bt_Calc | [Icono] | Siempre | Abre calculadora | N/A (legacy tool) |
| Bt_Calendar | [Icono] | Siempre | Abre calendario | N/A (legacy tool) |
| Bt_ConvMoneda | [Icono] | Siempre | Abre conversor moneda | N/A (legacy tool) |
| Bt_BaseImpAcum | "Base Imponible Acumulada..." | Solo si TipoInforme != VARANUAL | Abre FrmDetCapPropioSimplAcum | TODO: [FUTURE] [LOW] Implementar cuando DetCapPropioSimpl sea migrado |

#### 🚨 REGLA CRÍTICA: TODOS LOS BOTONES MIGRADOS

**✅ IMPLEMENTACIÓN OBLIGATORIA:**

1. **Bt_OK (Cerrar)**: ✅ Funcionalidad completa - Valida y guarda antes de cerrar
2. **Bt_Preview (Vista Previa)**: ✅ Funcionalidad completa - PDF preview
3. **Bt_Print (Imprimir)**: ✅ Funcionalidad completa - Genera PDF para impresión
4. **Bt_CopyExcel (Copiar Excel)**: ✅ Funcionalidad completa - Exporta a Excel
5. **Bt_Sum (Suma)**: ✅ Funcionalidad completa - Calculadora simple JavaScript
6. **Bt_Calc (Calculadora)**: ✅ TODO [LEGACY] [LOW] VB6 abría calculadora Windows, web usa calculadora JavaScript
7. **Bt_Calendar (Calendario)**: ✅ TODO [LEGACY] [LOW] VB6 abría calendario custom, web usa input date HTML5
8. **Bt_ConvMoneda (Convertir Moneda)**: ✅ Funcionalidad completa - Link a feature ConversionMonedas
9. **Bt_BaseImpAcum (Base Imponible Acumulada)**: ✅ TODO [FUTURE] [MEDIUM] [BLOCKED_BY: DetCapPropioSimpl] Requiere migración de FrmDetCapPropioSimplAcum

### Labels y Campos Calculados
| Control VB6 | Cálculo/Origen | Actualización |
|-------------|----------------|---------------|
| Label1 | Texto estático: "Nota: Recuerde hacer doble clic en el monto para verificar la BI 14D" | N/A |

---

## 🔘 EVENTOS IDENTIFICADOS

### Eventos de Formulario
| Evento VB6 | Cuándo Ocurre | Acciones | Mapeo .NET |
|------------|---------------|----------|------------|
| Form_Load | Al abrir form | Oculta Bt_BaseImpAcum si TipoInforme = VARANUAL, llama SetUpGrid(), llama LoadAll() | GetAsync() (carga datos) |

### Eventos de Botones
[Ya documentados en tabla de Botones arriba]

### Eventos de Grilla
| Control.Evento | Trigger | Acción VB6 | Mapeo .NET |
|----------------|---------|------------|------------|
| Grid.DblClick | Doble click en fila | Abre FrmBaseImponible14DFull para edición detallada del régimen seleccionado | Redirect a /BaseImponible14DCompleta (future) |
| Grid.BeforeEdit | Antes de editar celda | COMENTADO - Edición deshabilitada | N/A |
| Grid.AcceptValue | Al aceptar valor editado | COMENTADO - Sin funcionalidad | N/A |
| Grid.EditKeyPress | Al presionar tecla en edición | COMENTADO - Validación numérica deshabilitada | N/A |

---

## 🔧 FUNCIONES Y PROCEDIMIENTOS VB6

### Funciones Públicas
```vb
' Función: FEdit
' Propósito: Inicializar y mostrar el formulario modalmente
' Parámetros: TipoInforme (Integer), BaseImponible (Double ByRef)
' Retorno: Integer (vbOK o vbCancel)
' Llamado por: Formularios padres que necesitan capturar base imponible
' Mapeo .NET: Index() en MVC Controller
Public Function FEdit(ByVal TipoInforme As Integer, BaseImponible As Double) As Integer
    lTipoInforme = TipoInforme
    Me.Show vbModal
    
    BaseImponible = 0
    
    If lRc = vbOK Then
       BaseImponible = lBaseImponible
    End If
    
    FEdit = lRc
End Function
```

### Funciones Privadas
```vb
' Función: SetUpGrid
' Propósito: Configurar columnas y headers de la grilla
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: N/A (estructura de vista)
Private Sub SetUpGrid()
    Grid.Cols = NCOLS + 1
    Call FGrSetup(Grid, True)
    Grid.ColWidth(C_REGIMEN) = 5160
    Grid.ColWidth(C_MONTO) = 1500
    Grid.ColWidth(C_UPDATE) = 0
    Grid.ColAlignment(C_MONTO) = flexAlignRightCenter
    Grid.TextMatrix(0, C_REGIMEN) = "Régimen"
    Grid.TextMatrix(0, C_MONTO) = "Monto"
End Sub
```

```vb
' Función: LoadAll
' Propósito: Cargar datos desde EmpresasAno según tipo de empresa
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: GetAsync() en Service
Private Sub LoadAll()
    Grid.TextMatrix(R_14DN3, C_REGIMEN) = "14 D N°3 Régimen Pro Pyme General"
    Grid.TextMatrix(R_14DN8, C_REGIMEN) = "14 D N°8 Régimen Pro Pyme Transparente"
    
    Q1 = "SELECT CPS_BaseImpPrimCat_14DN3, CPS_BaseImpPrimCat_14DN8 "
    Q1 = Q1 & " FROM EmpresasAno "
    Q1 = Q1 & " WHERE IdEmpresa = " & gEmpresa.id & " AND Ano = " & gEmpresa.Ano
    
    Set Rs = OpenRs(DbMain, Q1)
    
    If Not Rs.EOF Then
        If gEmpresa.ProPymeGeneral <> 0 Then
            Grid.TextMatrix(R_14DN3, C_MONTO) = Format(vFld(Rs("CPS_BaseImpPrimCat_14DN3")), NUMFMT)
        ElseIf gEmpresa.ProPymeTransp <> 0 Then
            Grid.TextMatrix(R_14DN8, C_MONTO) = Format(vFld(Rs("CPS_BaseImpPrimCat_14DN8")), NUMFMT)
        End If
    End If
End Sub
```

```vb
' Función: SaveAll
' Propósito: Guardar valores en EmpresasAno y CapPropioSimplAnual
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: SaveAsync() en Service
Private Sub SaveAll()
    lBaseImponible = 0
    
    Q1 = "UPDATE EmpresasAno SET "
    
    If gEmpresa.ProPymeGeneral <> 0 Then
        lBaseImponible = vFmt(Grid.TextMatrix(R_14DN3, C_MONTO))
        Q1 = Q1 & "  CPS_BaseImpPrimCat_14DN3 = " & lBaseImponible
        Q1 = Q1 & ", CPS_BaseImpPrimCat_14DN8 = 0 "
    ElseIf gEmpresa.ProPymeTransp <> 0 Then
        lBaseImponible = vFmt(Grid.TextMatrix(R_14DN8, C_MONTO))
        Q1 = Q1 & "  CPS_BaseImpPrimCat_14DN3 = 0 "
        Q1 = Q1 & ", CPS_BaseImpPrimCat_14DN8 = " & lBaseImponible
    End If
    
    Q1 = Q1 & " WHERE IdEmpresa = " & gEmpresa.id & " AND Ano = " & gEmpresa.Ano
    Call ExecSQL(DbMain, Q1)
    
    ' También actualiza tabla CapPropioSimplAnual
    ' Si existe el registro lo actualiza, sino lo crea
End Sub
```

```vb
' Función: valida
' Propósito: Validar datos antes de guardar
' Parámetros: Ninguno
' Retorno: Boolean (siempre True)
' Mapeo .NET: ValidateAsync() en Service (opcional)
Private Function valida() As Boolean
    valida = True
End Function
```

```vb
' Función: SetUpPrtGrid
' Propósito: Configurar grilla para impresión
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: GeneratePdfAsync() en Service
Private Sub SetUpPrtGrid()
    Printer.Orientation = ORIENT_VER
    Set gPrtReportes.Grid = Grid
    Titulos(0) = Me.Caption
    Titulos(1) = "Año " & gEmpresa.Ano
    gPrtReportes.Titulos = Titulos
    ' ... configuración de impresión
End Sub
```

### Lista Completa de Funciones
| Función VB6 | Tipo | Propósito | Mapeo .NET Method |
|-------------|------|-----------|-------------------|
| FEdit() | Public Function→Integer | Mostrar formulario y obtener resultado | Index() (MVC) |
| SetUpGrid() | Private Sub | Configurar grilla | N/A (estructura vista) |
| LoadAll() | Private Sub | Cargar datos desde BD | GetAsync() |
| SaveAll() | Private Sub | Guardar en EmpresasAno y CapPropioSimplAnual | SaveAsync() |
| valida() | Private Function→Boolean | Validar formulario | ValidateAsync() |
| SetUpPrtGrid() | Private Sub | Preparar grilla para impresión | GeneratePdfAsync() |

---

## 💾 ACCESO A DATOS VB6

### Queries Identificadas

#### Query 1: Cargar Base Imponible Actual
```vb
' Ubicación: LoadAll()
' Tablas: EmpresasAno
' Filtros: IdEmpresa, Ano
Q1 = "SELECT CPS_BaseImpPrimCat_14DN3, CPS_BaseImpPrimCat_14DN8 "
Q1 = Q1 & " FROM EmpresasAno "
Q1 = Q1 & " WHERE IdEmpresa = " & gEmpresa.id & " AND Ano = " & gEmpresa.Ano
```

**Mapeo Entity Framework:**
```csharp
await _context.EmpresasAno
    .Where(ea => ea.idEmpresa == empresaId && ea.Ano == ano)
    .Select(ea => new {
        CPS_BaseImpPrimCat_14DN3 = ea.CPS_BaseImpPrimCat_14DN3,
        CPS_BaseImpPrimCat_14DN8 = ea.CPS_BaseImpPrimCat_14DN8
    })
    .FirstOrDefaultAsync();
```

#### Query 2: Actualizar Base Imponible en EmpresasAno
```vb
' Ubicación: SaveAll()
' Tablas: EmpresasAno
Q1 = "UPDATE EmpresasAno SET "

If gEmpresa.ProPymeGeneral <> 0 Then
    lBaseImponible = vFmt(Grid.TextMatrix(R_14DN3, C_MONTO))
    Q1 = Q1 & "  CPS_BaseImpPrimCat_14DN3 = " & lBaseImponible
    Q1 = Q1 & ", CPS_BaseImpPrimCat_14DN8 = 0 "
ElseIf gEmpresa.ProPymeTransp <> 0 Then
    lBaseImponible = vFmt(Grid.TextMatrix(R_14DN8, C_MONTO))
    Q1 = Q1 & "  CPS_BaseImpPrimCat_14DN3 = 0 "
    Q1 = Q1 & ", CPS_BaseImpPrimCat_14DN8 = " & lBaseImponible
End If

Q1 = Q1 & " WHERE IdEmpresa = " & gEmpresa.id & " AND Ano = " & gEmpresa.Ano
Call ExecSQL(DbMain, Q1)
```

**Mapeo Entity Framework:**
```csharp
var empresaAno = await _context.EmpresasAno
    .FirstOrDefaultAsync(ea => ea.idEmpresa == empresaId && ea.Ano == ano);

if (empresaAno != null)
{
    if (esProPymeGeneral)
    {
        empresaAno.CPS_BaseImpPrimCat_14DN3 = baseImponible;
        empresaAno.CPS_BaseImpPrimCat_14DN8 = 0;
    }
    else if (esProPymeTransp)
    {
        empresaAno.CPS_BaseImpPrimCat_14DN3 = 0;
        empresaAno.CPS_BaseImpPrimCat_14DN8 = baseImponible;
    }
    
    await _context.SaveChangesAsync();
}
```

#### Query 3: Verificar Existencia en CapPropioSimplAnual
```vb
' Ubicación: SaveAll()
' Tablas: CapPropioSimplAnual
Q1 = "SELECT IdCapPropioSimplAnual FROM CapPropioSimplAnual "
Q1 = Q1 & " WHERE TipoDetCPS = " & CPS_BASEIMPONIBLE & " AND AnoValor = " & gEmpresa.Ano
Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.id

Set Rs = OpenRs(DbMain, Q1)

If Not Rs.EOF Then
    ' UPDATE
    Q1 = "UPDATE CapPropioSimplAnual SET Valor = " & lBaseImponible & ", IngresoManual = 0 "
    Q1 = Q1 & " WHERE TipoDetCPS = " & CPS_BASEIMPONIBLE & " AND AnoValor = " & gEmpresa.Ano
    Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.id
Else
    ' INSERT
    Q1 = "INSERT INTO CapPropioSimplAnual (TipoDetCPS, IngresoManual, AnoValor, Valor, IdEmpresa )"
    Q1 = Q1 & " VALUES( " & CPS_BASEIMPONIBLE
    Q1 = Q1 & ", 0"
    Q1 = Q1 & ", " & gEmpresa.Ano
    Q1 = Q1 & ", " & lBaseImponible
    Q1 = Q1 & ", " & gEmpresa.id & ") "
End If

Call ExecSQL(DbMain, Q1)
```

**Mapeo Entity Framework:**
```csharp
var capPropio = await _context.CapPropioSimplAnual
    .FirstOrDefaultAsync(c => 
        c.TipoDetCPS == CPS_BASEIMPONIBLE && 
        c.AnoValor == ano && 
        c.IdEmpresa == empresaId);

if (capPropio != null)
{
    capPropio.Valor = baseImponible;
    capPropio.IngresoManual = 0;
}
else
{
    var newCapPropio = new App.Data.CapPropioSimplAnual
    {
        TipoDetCPS = CPS_BASEIMPONIBLE,
        IngresoManual = 0,
        AnoValor = ano,
        Valor = baseImponible,
        IdEmpresa = empresaId
    };
    _context.CapPropioSimplAnual.Add(newCapPropio);
}

await _context.SaveChangesAsync();
```

---

## ✅ VALIDACIONES Y REGLAS DE NEGOCIO

### Validaciones de Campos
| Campo | Regla | Mensaje Error VB6 | Implementar en .NET |
|-------|-------|-------------------|---------------------|
| Monto | Numérico (implícito) | N/A | Validación JS y backend |

### Reglas de Negocio

1. **Solo un régimen activo por empresa**: Dependiendo del tipo de empresa (ProPymeGeneral o ProPymeTransp), solo se edita una fila
   - Si `gEmpresa.ProPymeGeneral <> 0`: Solo se edita R_14DN3
   - Si `gEmpresa.ProPymeTransp <> 0`: Solo se edita R_14DN8
   **→ Implementar:** `GetTipoRegimenAsync(empresaId)` retorna tipo de régimen activo

2. **Actualización dual de tablas**: Al guardar se actualizan dos tablas simultáneamente
   - `EmpresasAno`: Campos CPS_BaseImpPrimCat_14DN3 o CPS_BaseImpPrimCat_14DN8
   - `CapPropioSimplAnual`: Registro con TipoDetCPS = CPS_BASEIMPONIBLE
   **→ Implementar:** `SaveAsync()` en transacción actualiza ambas tablas

3. **Reinicio de régimen no activo**: Al guardar, el régimen NO activo se setea a 0
   **→ Implementar:** Lógica de zeroing en `SaveAsync()`

---

## 🧮 CÁLCULOS Y FÓRMULAS

### Cálculo 1: Base Imponible según Régimen
```vb
' Dónde: SaveAll()
' Fórmula: Obtiene valor de la grilla según régimen activo
If gEmpresa.ProPymeGeneral <> 0 Then
    lBaseImponible = vFmt(Grid.TextMatrix(R_14DN3, C_MONTO))
ElseIf gEmpresa.ProPymeTransp <> 0 Then
    lBaseImponible = vFmt(Grid.TextMatrix(R_14DN8, C_MONTO))
End If
```
**→ Implementar:** Lógica condicional en `SaveAsync()`

---

## 🚀 NAVEGACIÓN Y FLUJO

### Formularios Llamados
| Desde VB6 | Formulario Destino | Parámetros | Retorno | Mapeo .NET |
|-----------|-------------------|------------|---------|------------|
| Bt_BaseImpAcum_Click | FrmDetCapPropioSimplAcum | CPS_BASEIMPONIBLE, valor | valor actualizado | TODO: [FUTURE] Redirect a /DetCapPropioSimplAcum?tipo=baseimponible |
| Grid_DblClick | FrmBaseImponible14DFull | ValorBaseImp | Valor editado | TODO: [FUTURE] Redirect a /BaseImponible14DCompleta |

### Flujo de Estados del Form
```
[Inicio] → Form_Load() → LoadAll() → [Estado: Visualizando]
  ↓
[Grid_DblClick] → FrmBaseImponible14DFull → Actualiza valor en grilla → [Estado: Editado]
  ↓
[Bt_BaseImpAcum_Click] → FrmDetCapPropioSimplAcum → Actualiza valor en grilla → [Estado: Editado]
  ↓
[Bt_OK] → valida() → SaveAll() → [Cierra]
```

---

## 📊 EXPORTACIONES E IMPORTACIONES

### Exportación a Excel
```vb
' Botón: Bt_CopyExcel_Click
' Formato: Clipboard con headers
' Columnas: Régimen, Monto
Call LP_FGr2Clip(Grid, Me.Caption & vbTab & "Año " & gEmpresa.Ano)
```
**→ Implementar:** `ExportToExcelAsync()` usando EPPlus

### Impresión
```vb
' Botón: Bt_Print_Click, Bt_Preview_Click
' Orientación: Vertical
' Títulos: Caption, "Año " & gEmpresa.Ano
```
**→ Implementar:** `GeneratePdfAsync()` para impresión y preview

---

## 🎯 MAPEO FINAL: MÉTODOS .NET DETERMINADOS

### Interface del Service
```csharp
public interface IBaseImponible14DService
{
    // Lectura
    Task<BaseImponible14DDto?> GetAsync(int empresaId, int ano);
    
    // Escritura
    Task<ValidationResult> SaveAsync(int empresaId, int ano, BaseImponible14DDto dto);
    
    // Utilidades
    Task<string> GetTipoRegimenAsync(int empresaId, int ano);
    
    // Exportación
    Task<byte[]> ExportToExcelAsync(int empresaId, int ano);
    Task<byte[]> GeneratePdfAsync(int empresaId, int ano);
}
```

### Resumen de Mapeo
| Funcionalidad VB6 | Método .NET | Complejidad | Prioridad |
|-------------------|-------------|-------------|-----------|
| Form_Load → LoadAll | GetAsync() | Baja | Alta |
| Bt_OK → SaveAll | SaveAsync() | Media | Alta |
| Bt_Print | GeneratePdfAsync() | Media | Media |
| Bt_CopyExcel | ExportToExcelAsync() | Baja | Media |
| Grid_DblClick → FrmBaseImponible14DFull | N/A (redirect) | N/A | Futura |
| Bt_BaseImpAcum | N/A (redirect) | N/A | Futura |

---

## ⚠️ NOTAS IMPORTANTES Y OBSERVACIONES

### Peculiaridades del Form VB6
- Usa constantes globales: `CPS_BASEIMPONIBLE`, `CPS_TIPOINFO_VARANUAL`
- Tipo de régimen (ProPymeGeneral vs ProPymeTransp) determina qué fila se edita
- Grilla de solo 2 filas fijas, sin datos dinámicos
- Edición directa en grilla DESHABILITADA (código comentado)
- Solo se edita mediante doble click que abre formulario detallado

### Decisiones de Diseño
- **Entidad principal**: `EmpresasAno` (no usa tabla `BaseImponible14D`)
- **Tabla adicional**: `CapPropioSimplAnual` también se actualiza
- **Validación**: VB6 no valida, implementar validaciones básicas en .NET
- **Tipo de régimen**: Obtener desde `Empresas` (campos ProPymeGeneral, ProPymeTransp)

### Pendientes/Incompletos en VB6
- Botón "Base Imponible Acumulada" (Bt_BaseImpAcum) existe → **MIGRAR**: Incluir con TODO [FUTURE] bloqueado por DetCapPropioSimpl
- Doble click en grilla abre FrmBaseImponible14DFull → **MIGRAR**: Incluir con TODO [FUTURE] bloqueado por BaseImponible14DCompleta

---

## ✅ CHECKLIST DE COMPLETITUD DEL ANÁLISIS

- [x] Todos los controles UI documentados
- [x] Todos los botones y eventos mapeados
- [x] **TODOS los botones tienen "Mapeo .NET" definido** (con excepciones documentadas)
- [x] **Botones con excepciones documentan razón válida** (FUTURE, LEGACY)
- [x] Todas las funciones VB6 identificadas
- [x] Todos los queries SQL traducidos a EF Core
- [x] Todas las validaciones documentadas
- [x] Todas las reglas de negocio identificadas
- [x] Todos los cálculos documentados
- [x] Navegación y flujos mapeados
- [x] Métodos .NET determinados
- [x] Interface del Service definida
- [x] **Decisiones de excepción justificadas y estructuradas**

---

**✅ ANÁLISIS COMPLETO - LISTO PARA IMPLEMENTACIÓN**

