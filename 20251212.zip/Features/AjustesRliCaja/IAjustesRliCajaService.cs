﻿namespace App.Features.AjustesRliCaja;

public interface IAjustesRliCajaService
{
    Task<AjustesRliCajaDto> GetAjustesAsync(int empresaId, short ano);
    Task<ExportarHrRabRadResultDto> ExportarHrRabRadAsync(int empresaId, short ano);
}
