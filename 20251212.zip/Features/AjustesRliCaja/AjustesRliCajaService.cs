using Microsoft.EntityFrameworkCore;
using App.Data;
using App.Exceptions;
using System.Text;

namespace App.Features.AjustesRliCaja;

public class AjustesRliCajaService(LpContabContext context, ILogger<AjustesRliCajaService> logger) : IAjustesRliCajaService
{
    public async Task<AjustesRliCajaDto> GetAjustesAsync(int empresaId, short ano)
    {
        logger.LogInformation("Getting ajustes RLI for empresa {EmpresaId}, año {Ano}", empresaId, ano);

        {
            var dto = new AjustesRliCajaDto
            {
                EmpresaId = empresaId,
                Ano = ano,
                Tipos = new List<TipoAjusteRliDto>()
            };

            // Cargar tipos de ajuste con grupos
            var tiposAjuste = new List<TipoAjusteRliDto>
            {
                new TipoAjusteRliDto
                {
                    IdTipo = 1,
                    Nombre = "Agregados",
                    Grupos = await GetGruposAgregadosAsync(empresaId, ano)
                },
                new TipoAjusteRliDto
                {
                    IdTipo = 2,
                    Nombre = "Deducciones",
                    Grupos = await GetGruposDeduccionesAsync(empresaId, ano)
                }
            };

            dto.Tipos = tiposAjuste;

            logger.LogInformation("Ajustes RLI retrieved successfully");
            return dto;
        }
    }

    private async Task<List<GrupoAjusteRliDto>> GetGruposAgregadosAsync(int empresaId, short ano)
    {
        var grupos = new List<GrupoAjusteRliDto>();

        // A) Agregados art 33
        grupos.Add(new GrupoAjusteRliDto
        {
            IdGrupo = 1,
            Nombre = "A) Agregados art 33",
            Items = await GetItemsAgregadosArt33Async(empresaId, ano)
        });

        // B) Otros agregados  
        grupos.Add(new GrupoAjusteRliDto
        {
            IdGrupo = 2,
            Nombre = "B) Otros agregados",
            Items = await GetItemsOtrosAgregadosAsync(empresaId, ano)
        });

        return grupos;
    }

    private async Task<List<GrupoAjusteRliDto>> GetGruposDeduccionesAsync(int empresaId, short ano)
    {
        var grupos = new List<GrupoAjusteRliDto>();

        // C) Deducciones
        grupos.Add(new GrupoAjusteRliDto
        {
            IdGrupo = 3,
            Nombre = "C) Deducciones",
            Items = await GetItemsDeduccionesAsync(empresaId, ano)
        });

        return grupos;
    }

    private Task<List<ItemAjusteRliDto>> GetItemsAgregadosArt33Async(int empresaId, short ano)
    {
        var items = new List<ItemAjusteRliDto>();

        // TODO: [LEGACY] [MEDIUM] Implementar cálculos complejos de ajustes art 33
        // Requiere análisis detallado de fórmulas tributarias específicas
        
        return Task.FromResult(items);
    }

    private Task<List<ItemAjusteRliDto>> GetItemsOtrosAgregadosAsync(int empresaId, short ano)
    {
        var items = new List<ItemAjusteRliDto>();

        // TODO: [LEGACY] [MEDIUM] Implementar cálculos de otros agregados
        // Requiere análisis detallado de fórmulas tributarias específicas
        
        return Task.FromResult(items);
    }

    private async Task<List<ItemAjusteRliDto>> GetItemsDeduccionesAsync(int empresaId, short ano)
    {
        var items = new List<ItemAjusteRliDto>();

        // Calcular desde MovComprobante
        // NOTA: MovComprobante NO tiene navegación a Comprobante ni TipoAjuste
        // Necesitamos hacer JOIN manual
        
        var movimientos = await context.MovComprobante
            .Where(m => m.IdEmpresa == empresaId && m.Ano == ano)
            .ToListAsync();

        // TODO: [LEGACY] [MEDIUM] Implementar cálculos de deducciones
        // Requiere análisis detallado de fórmulas tributarias específicas

        return items;
    }

    public async Task<ExportarHrRabRadResultDto> ExportarHrRabRadAsync(int empresaId, short ano)
    {
        if (ano < 1900 || ano > 2100)
            throw new BusinessException("El año debe estar entre 1900 y 2100");

        logger.LogInformation("Exporting HR RAB/RAD for empresa {EmpresaId}, año {Ano}", empresaId, ano);

        {
            var ajustes = await GetAjustesAsync(empresaId, ano);

            // Generar CSV
            var sb = new StringBuilder();

            // Header
            sb.AppendLine("Tipo,Grupo,Item,Concepto,Valor");

            // Datos
            foreach (var tipo in ajustes.Tipos)
            {
                foreach (var grupo in tipo.Grupos)
                {
                    foreach (var item in grupo.Items)
                    {
                        sb.AppendLine($"{tipo.Nombre},{grupo.Nombre},{item.IdItem},{item.Concepto},{item.Valor}");
                    }
                }
            }

            var csvData = Encoding.UTF8.GetBytes(sb.ToString());

            // Validación de negocio: no hay datos
            if (csvData == null || csvData.Length == 0)
            {
                throw new BusinessException("No existen datos para generar archivo");
            }

            // Lógica de negocio: determinar nombre de archivo según el año
            var fileName = ano >= 2020
                ? $"RLI_HR_RAD_{ano.ToString().Substring(2)}.csv"
                : $"RLI_HR_RAB_{ano.ToString().Substring(2)}.csv";

            logger.LogInformation("HR RAB/RAD exported successfully, size: {Size} bytes, fileName: {FileName}", csvData.Length, fileName);

            return new ExportarHrRabRadResultDto
            {
                CsvData = csvData,
                FileName = fileName
            };
        }
    }
}
