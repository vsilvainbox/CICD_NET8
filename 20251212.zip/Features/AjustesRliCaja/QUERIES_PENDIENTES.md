# QUERIES PENDIENTES - AjustesRliCaja

## Documento Técnico para Implementación

**Feature:** AjustesRliCaja
**Fecha:** 2025-12-06
**Objetivo:** Detallar las queries VB6 que deben implementarse en .NET

---

## QUERY #1: Cálculo de Valores por Item

### VB6 Original (líneas 411-417)

```vb
Function LoadValCuentas(ByVal Row As Integer, ByVal TipoItem As String,
                        ByVal NombreItem As String, ByVal LstCuentas As String) As Double

    Dim Rs As Recordset
    Dim Q1 As String
    Dim Tot As Double

    If LstCuentas = "" Then
       LoadValCuentas = 0
       Exit Function
    End If

    ' Limpiar formato de lista "(123,456,789)" -> "123,456,789"
    LstCuentas = Mid(LstCuentas, 2)
    LstCuentas = Left(LstCuentas, Len(LstCuentas) - 1)

    Q1 = "SELECT Sum(Debe - Haber) as Valor "
    Q1 = Q1 & " FROM MovComprobante INNER JOIN Comprobante ON (MovComprobante.IdComp = Comprobante.IdComp "
    Q1 = Q1 & JoinEmpAno(gDbType, "Comprobante", "MovComprobante") & " )"
    Q1 = Q1 & " WHERE IdCuenta IN (" & LstCuentas & ")"
    Q1 = Q1 & " AND TipoAjuste IN (" & TAJUSTE_FINANCIERO & "," & TAJUSTE_AMBOS & ")"
    Q1 = Q1 & " AND Comprobante.Tipo <> " & TC_APERTURA
    Q1 = Q1 & " AND Comprobante.IdEmpresa = " & gEmpresa.id & " AND Comprobante.Ano = " & gEmpresa.Ano

    Set Rs = OpenRs(DbMain, Q1)

    If Not Rs.EOF Then
       Tot = Format(vFld(Rs("Valor")), NEGNUMFMT)
    End If

    Call CloseRs(Rs)

    LoadValCuentas = Tot
End Function
```

### Traducción a SQL Estándar

```sql
SELECT SUM(m.Debe - m.Haber) AS Valor
FROM MovComprobante m
INNER JOIN Comprobante c ON m.IdComp = c.IdComp
                         AND m.IdEmpresa = c.IdEmpresa
                         AND m.Ano = c.Ano
WHERE m.IdCuenta IN (123, 456, 789)  -- Lista de cuentas del item
  AND c.TipoAjuste IN (1, 3)         -- TAJUSTE_FINANCIERO=1, TAJUSTE_AMBOS=3
  AND c.Tipo <> 1                     -- TC_APERTURA=1 (excluir aperturas)
  AND c.IdEmpresa = @empresaId
  AND c.Ano = @ano
```

### Implementación en .NET (propuesta)

```csharp
private async Task<decimal> CalcularValorPorCuentasAsync(
    int empresaId,
    short ano,
    List<int> lstCuentas)
{
    if (lstCuentas == null || !lstCuentas.Any())
        return 0;

    // Constantes (deben estar definidas en algún lugar)
    const int TAJUSTE_FINANCIERO = 1;
    const int TAJUSTE_AMBOS = 3;
    const int TC_APERTURA = 1;

    var valor = await context.MovComprobante
        .Where(m => m.IdEmpresa == empresaId && m.Ano == ano)
        .Where(m => lstCuentas.Contains(m.IdCuenta))
        .Join(
            context.Comprobante,
            m => new { m.IdComp, m.IdEmpresa, m.Ano },
            c => new { c.IdComp, c.IdEmpresa, c.Ano },
            (m, c) => new { m, c }
        )
        .Where(x => x.c.TipoAjuste == TAJUSTE_FINANCIERO || x.c.TipoAjuste == TAJUSTE_AMBOS)
        .Where(x => x.c.Tipo != TC_APERTURA)
        .SumAsync(x => (decimal?)(x.m.Debe - x.m.Haber));

    return Math.Abs(valor ?? 0);
}
```

**Ubicación:** `AjustesRliCajaService.cs`, llamar desde `GetItemsAgregadosArt33Async()`, etc.

---

## QUERY #2: Exportación - Detalle de Movimientos

### VB6 Original (líneas 635-652)

```vb
Q1 = "SELECT Comprobante.Tipo, Comprobante.Correlativo, Comprobante.Fecha, "
Q1 = Q1 & "MovComprobante.Debe - MovComprobante.Haber as Valor "
Q1 = Q1 & " FROM MovComprobante INNER JOIN Comprobante ON (MovComprobante.IdComp = Comprobante.IdComp "
Q1 = Q1 & JoinEmpAno(gDbType, "Comprobante", "MovComprobante") & " )"
Q1 = Q1 & " WHERE IdCuenta IN (" & LstCuentas & ")"
Q1 = Q1 & " AND TipoAjuste IN (" & TAJUSTE_FINANCIERO & "," & TAJUSTE_AMBOS & ")"
Q1 = Q1 & " AND Comprobante.Tipo <> " & TC_APERTURA
Q1 = Q1 & " AND Comprobante.IdEmpresa = " & gEmpresa.id & " AND Comprobante.Ano = " & gEmpresa.Ano

Set Rs = OpenRs(DbMain, Q1)

Do While Not Rs.EOF
   Descrip = gTipoComp(vFld(Rs("Tipo"))) & " " & vFld(Rs("Correlativo")) & " " & Trim(Grid.TextMatrix(r, C_CONCEPTO))
   Buf = TipoItem & Sep & Format(vFld(Rs("Fecha")), "dd/mm/yyyy") & Sep & Descrip & Sep & Abs(vFld(Rs("Valor")))
   Print #Fd, Buf
   n = n + 1

   Call Rs.MoveNext
Loop
```

### Traducción a SQL Estándar

```sql
SELECT c.Tipo,
       c.Correlativo,
       c.Fecha,
       m.Debe - m.Haber AS Valor
FROM MovComprobante m
INNER JOIN Comprobante c ON m.IdComp = c.IdComp
                         AND m.IdEmpresa = c.IdEmpresa
                         AND m.Ano = c.Ano
WHERE m.IdCuenta IN (123, 456, 789)
  AND c.TipoAjuste IN (1, 3)
  AND c.Tipo <> 1
  AND c.IdEmpresa = @empresaId
  AND c.Ano = @ano
ORDER BY c.Fecha, c.Correlativo
```

### Implementación en .NET (propuesta)

```csharp
public class MovimientoExportRliDto
{
    public int Tipo { get; set; }
    public string? TipoNombre { get; set; }  // "EGRESO", "INGRESO", etc.
    public int Correlativo { get; set; }
    public DateTime Fecha { get; set; }
    public decimal Valor { get; set; }
    public string? TipoItem { get; set; }      // "AG01", "DD02", etc.
    public string? ConceptoItem { get; set; }  // Nombre del item
}

private async Task<List<MovimientoExportRliDto>> GetMovimientosParaExportacionAsync(
    int empresaId,
    short ano,
    List<int> lstCuentas,
    string tipoItem,
    string conceptoItem)
{
    const int TAJUSTE_FINANCIERO = 1;
    const int TAJUSTE_AMBOS = 3;
    const int TC_APERTURA = 1;

    var movimientos = await context.MovComprobante
        .Where(m => m.IdEmpresa == empresaId && m.Ano == ano)
        .Where(m => lstCuentas.Contains(m.IdCuenta))
        .Join(
            context.Comprobante,
            m => new { m.IdComp, m.IdEmpresa, m.Ano },
            c => new { c.IdComp, c.IdEmpresa, c.Ano },
            (m, c) => new { m, c }
        )
        .Where(x => x.c.TipoAjuste == TAJUSTE_FINANCIERO || x.c.TipoAjuste == TAJUSTE_AMBOS)
        .Where(x => x.c.Tipo != TC_APERTURA)
        .Select(x => new MovimientoExportRliDto
        {
            Tipo = x.c.Tipo,
            Correlativo = x.c.Correlativo,
            Fecha = x.c.Fecha,
            Valor = x.m.Debe - x.m.Haber,
            TipoItem = tipoItem,
            ConceptoItem = conceptoItem
        })
        .OrderBy(x => x.Fecha)
        .ThenBy(x => x.Correlativo)
        .ToListAsync();

    return movimientos;
}
```

### Formato CSV Esperado

```csv
Tipo Item;Fecha;Descripción;Monto
AG01;31/12/2023;EGRESO 123 Ajuste por depreciación;150000
AG01;31/12/2023;EGRESO 124 Ajuste por depreciación;75000
DD02;31/12/2023;INGRESO 45 Deducción por incentivo;50000
```

### Lógica de Generación CSV

```csharp
public async Task<ExportarHrRabRadResultDto> ExportarHrRabRadAsync(int empresaId, short ano)
{
    var sb = new StringBuilder();

    // Header
    sb.AppendLine("Tipo Item;Fecha;Descripción;Monto");

    // Obtener configuración de ajustes
    var configuracion = await GetConfiguracionAjustesAsync(empresaId, ano);

    // Iterar por cada item configurado
    foreach (var item in configuracion)
    {
        // Obtener movimientos para este item
        var movimientos = await GetMovimientosParaExportacionAsync(
            empresaId, ano, item.LstCuentas, item.TipoItem, item.Concepto);

        // Generar líneas CSV
        foreach (var mov in movimientos)
        {
            // Descripción: "[TipoComp] [Correlativo] [Concepto]"
            var tipoCompNombre = GetTipoComprobanteNombre(mov.Tipo);
            var descripcion = $"{tipoCompNombre} {mov.Correlativo} {mov.ConceptoItem}";

            // Línea CSV
            var linea = string.Join(";",
                mov.TipoItem,
                mov.Fecha.ToString("dd/MM/yyyy"),
                descripcion,
                Math.Abs(mov.Valor).ToString("0")
            );

            sb.AppendLine(linea);
        }
    }

    var csvData = Encoding.UTF8.GetBytes(sb.ToString());
    var fileName = ano >= 2020
        ? $"RLI_HR_RAD_{ano.ToString().Substring(2)}.csv"
        : $"RLI_HR_RAB_{ano.ToString().Substring(2)}.csv";

    return new ExportarHrRabRadResultDto
    {
        CsvData = csvData,
        FileName = fileName
    };
}
```

---

## CONSTANTES NECESARIAS

### Tipos de Ajuste

```csharp
public static class TipoAjuste
{
    public const int Tributario = 0;
    public const int Financiero = 1;
    public const int Ambos = 3;
}
```

### Tipos de Comprobante

```csharp
public static class TipoComprobante
{
    public const int Apertura = 1;
    public const int Egreso = 2;
    public const int Ingreso = 3;
    public const int Traspaso = 4;
    // ... etc.
}

public static class TipoComprobanteNombres
{
    public static string GetNombre(int tipo)
    {
        return tipo switch
        {
            1 => "APERTURA",
            2 => "EGRESO",
            3 => "INGRESO",
            4 => "TRASPASO",
            // ... etc.
            _ => "COMP"
        };
    }
}
```

---

## CONFIGURACIÓN DE AJUSTES

### Estructura de Tabla Requerida

```sql
CREATE TABLE AjustesExtraContRLI (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    TipoAjuste INT NOT NULL,          -- 1=Agregados, 2=Deducciones
    IdGrupo INT NOT NULL,             -- 1, 2, 3...
    IdItem INT NOT NULL,              -- 1, 2, 3...
    Nombre NVARCHAR(200) NOT NULL,    -- "Ajuste por depreciación"
    TipoItem NVARCHAR(10) NULL,       -- "AG01", "DD02", etc.
    LstCuentas NVARCHAR(500) NULL,    -- "123,456,789"
    Orden INT NOT NULL DEFAULT 0,
    Activo BIT NOT NULL DEFAULT 1
);

-- Índice
CREATE INDEX IX_AjustesExtraContRLI_Tipo_Grupo_Item
ON AjustesExtraContRLI(TipoAjuste, IdGrupo, IdItem);
```

### Datos de Ejemplo (extraer de VB6)

```sql
-- Tipo 1: AGREGADOS
-- Grupo 1: A) Agregados art 33
INSERT INTO AjustesExtraContRLI (TipoAjuste, IdGrupo, IdItem, Nombre, TipoItem, LstCuentas, Orden)
VALUES
(1, 1, 1, 'Ajuste por depreciación acelerada', 'AG01', '123,124,125', 1),
(1, 1, 2, 'Ajuste por provisiones', 'AG02', '126,127', 2),
(1, 1, 3, 'Otros ajustes art 33', 'AG03', '128,129,130', 3);

-- Grupo 2: B) Otros agregados
INSERT INTO AjustesExtraContRLI (TipoAjuste, IdGrupo, IdItem, Nombre, TipoItem, LstCuentas, Orden)
VALUES
(1, 2, 1, 'Gastos rechazados', 'AG04', '201,202', 1),
(1, 2, 2, 'Multas e intereses', 'AG05', '203', 2);

-- Tipo 2: DEDUCCIONES
-- Grupo 3: C) Deducciones
INSERT INTO AjustesExtraContRLI (TipoAjuste, IdGrupo, IdItem, Nombre, TipoItem, LstCuentas, Orden)
VALUES
(2, 3, 1, 'Depreciación normal', 'DD01', '301,302', 1),
(2, 3, 2, 'Incentivo ahorro', 'DD02', '303', 2);
```

### Modelo EF Core

```csharp
public class AjustesExtraContRLI
{
    public int Id { get; set; }
    public int TipoAjuste { get; set; }
    public int IdGrupo { get; set; }
    public int IdItem { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public string? TipoItem { get; set; }
    public string? LstCuentas { get; set; }  // "123,456,789"
    public int Orden { get; set; }
    public bool Activo { get; set; } = true;

    // Helper property
    public List<int> GetListaCuentas()
    {
        if (string.IsNullOrEmpty(LstCuentas))
            return new List<int>();

        return LstCuentas
            .Split(',')
            .Select(c => int.Parse(c.Trim()))
            .ToList();
    }
}
```

---

## PLAN DE IMPLEMENTACIÓN

### Paso 1: Migrar Configuración

1. Extraer datos de VB6 (desde código o BD)
2. Crear tabla en BD .NET
3. Insertar datos
4. Crear modelo EF Core
5. Agregar DbSet a LpContabContext

**SQL para extracción desde VB6:**

Si `gAjustesExtraContRLI` está en base de datos VB6:
```sql
SELECT * FROM AjustesExtraContRLI
WHERE Activo = 1
ORDER BY TipoAjuste, IdGrupo, Orden
```

Si está hardcoded en código VB6, revisar archivos `.bas` y crear script de INSERT.

### Paso 2: Modificar Service para Leer Config

```csharp
private async Task<List<GrupoAjusteRliDto>> GetGruposAgregadosAsync(int empresaId, short ano)
{
    var grupos = await context.AjustesExtraContRLI
        .Where(a => a.TipoAjuste == 1 && a.Activo)
        .GroupBy(a => a.IdGrupo)
        .Select(g => new GrupoAjusteRliDto
        {
            IdGrupo = g.Key,
            Nombre = g.First().Nombre,  // Ajustar según estructura real
            Items = g.Select(a => new ItemAjusteRliDto
            {
                TipoAjuste = a.TipoAjuste,
                IdGrupo = a.IdGrupo,
                IdItem = a.IdItem,
                TipoItem = a.TipoItem ?? "",
                Concepto = a.Nombre,
                Orden = a.Orden,
                Valor = 0  // Se calculará en siguiente paso
            }).ToList()
        })
        .ToListAsync();

    return grupos;
}
```

### Paso 3: Implementar Cálculo de Valores

```csharp
private async Task<List<ItemAjusteRliDto>> GetItemsAgregadosArt33Async(int empresaId, short ano)
{
    var items = await context.AjustesExtraContRLI
        .Where(a => a.TipoAjuste == 1 && a.IdGrupo == 1 && a.Activo)
        .OrderBy(a => a.Orden)
        .ToListAsync();

    var resultado = new List<ItemAjusteRliDto>();

    foreach (var item in items)
    {
        var lstCuentas = item.GetListaCuentas();
        var valor = await CalcularValorPorCuentasAsync(empresaId, ano, lstCuentas);

        resultado.Add(new ItemAjusteRliDto
        {
            TipoAjuste = item.TipoAjuste,
            IdGrupo = item.IdGrupo,
            IdItem = item.IdItem,
            TipoItem = item.TipoItem ?? "",
            Concepto = item.Nombre,
            Orden = item.Orden,
            Valor = valor
        });
    }

    return resultado;
}
```

### Paso 4: Implementar Exportación Correcta

Ver código completo en sección "QUERY #2" arriba.

---

## TESTING

### Test 1: Comparar Valores Calculados

```csharp
[Fact]
public async Task CalcularValor_DebeCoincidirConVB6()
{
    // Arrange
    var empresaId = 1;
    var ano = 2023;
    var lstCuentas = new List<int> { 123, 456, 789 };

    // Act
    var valorNet = await service.CalcularValorPorCuentasAsync(empresaId, ano, lstCuentas);

    // Assert
    var valorVB6 = 150000m;  // Valor obtenido de VB6 para mismos parámetros
    Assert.Equal(valorVB6, valorNet);
}
```

### Test 2: Validar Formato CSV

```csharp
[Fact]
public async Task ExportarCSV_DebeGenerarFormatoHR()
{
    // Arrange
    var empresaId = 1;
    var ano = 2023;

    // Act
    var result = await service.ExportarHrRabRadAsync(empresaId, ano);
    var csv = Encoding.UTF8.GetString(result.CsvData);

    // Assert
    Assert.Contains("Tipo Item;Fecha;Descripción;Monto", csv);
    Assert.DoesNotContain("Tipo,Grupo,Item", csv);

    var lineas = csv.Split('\n');
    Assert.True(lineas.Length > 1);

    var primeraLinea = lineas[1];
    var columnas = primeraLinea.Split(';');
    Assert.Equal(4, columnas.Length);
}
```

### Test 3: Comparar Output con VB6

1. Ejecutar en VB6 con empresa de prueba
2. Guardar archivo CSV generado
3. Ejecutar en .NET con misma empresa
4. Comparar archivos línea por línea
5. Verificar que valores coinciden

---

## CHECKLIST DE IMPLEMENTACIÓN

- [ ] Crear tabla `AjustesExtraContRLI`
- [ ] Migrar datos desde VB6
- [ ] Agregar modelo EF Core
- [ ] Agregar DbSet a Context
- [ ] Implementar `CalcularValorPorCuentasAsync()`
- [ ] Modificar `GetItemsAgregadosArt33Async()` para usar cálculo real
- [ ] Modificar `GetItemsOtrosAgregadosAsync()` para usar cálculo real
- [ ] Modificar `GetItemsDeduccionesAsync()` para usar cálculo real
- [ ] Implementar `GetMovimientosParaExportacionAsync()`
- [ ] Reescribir `ExportarHrRabRadAsync()` con formato correcto
- [ ] Agregar constantes de TipoAjuste y TipoComprobante
- [ ] Testing con datos reales
- [ ] Validar archivo en HR
- [ ] Documentar configuración

---

**Fecha:** 2025-12-06
**Responsable:** Equipo .NET
**Revisión:** Pendiente post-implementación
