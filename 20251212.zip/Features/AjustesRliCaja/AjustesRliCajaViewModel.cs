namespace App.Features.AjustesRliCaja;

public class AjustesRliCajaViewModel
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public List<TipoAjusteRliViewModel> Tipos { get; set; } = new();
    public bool MostrarSoloConValor { get; set; }

    // Propiedades calculadas
    public string TituloFormateado => Ano >= 2020
        ? "Ajustes Extra-Contables RLI HR RAD"
        : "Ajustes Extra-Contables RLI HR RAB";

    public string SufijoExportacion => Ano >= 2020 ? "RAD" : "RAB";
}

public class TipoAjusteRliViewModel
{
    public int IdTipo { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public List<GrupoAjusteRliViewModel> Grupos { get; set; } = new();
    public bool EsPrimerTipo { get; set; }
}

public class GrupoAjusteRliViewModel
{
    public int IdGrupo { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public List<ItemAjusteRliViewModel> Items { get; set; } = new();
}

public class ItemAjusteRliViewModel
{
    public int TipoAjuste { get; set; }
    public int IdGrupo { get; set; }
    public int IdItem { get; set; }
    public string TipoItem { get; set; } = string.Empty;
    public string Concepto { get; set; } = string.Empty;
    public decimal Valor { get; set; }
    public int Orden { get; set; }

    // Propiedades calculadas/formateadas
    public string ValorFormateado => new System.Globalization.CultureInfo("es-CL")
        .NumberFormat.Clone() switch
        {
            var nfi => string.Format(
                new System.Globalization.CultureInfo("es-CL")
                {
                    NumberFormat = { NumberDecimalDigits = 0 }
                },
                "{0:N0}",
                Math.Abs(Valor))
        };

    public bool TieneValor => Valor > 0;
}
