namespace App.Features.CentroCostoIndividual;

/// <summary>
/// Servicio para gestión individual de centros de costo
/// Basado en FrmCCosto.frm del sistema VB6
/// </summary>
public interface ICentroCostoIndividualService
{
    /// <summary>
    /// Obtiene un centro de costo por su ID
    /// Mapea: FrmCCosto.LoadAll()
    /// </summary>
    Task<CentroCostoDto> GetByIdAsync(int id, int empresaId);
    
    /// <summary>
    /// Crea un nuevo centro de costo
    /// Mapea: FrmCCosto.FNew() → bt_OK_Click()
    /// </summary>
    Task<CentroCostoDto> CreateAsync(CrearCentroCostoDto dto, int empresaId);
    
    /// <summary>
    /// Actualiza un centro de costo existente
    /// Mapea: FrmCCosto.FEdit() → bt_OK_Click()
    /// </summary>
    Task<CentroCostoDto> UpdateAsync(int id, ActualizarCentroCostoDto dto, int empresaId);
    
    /// <summary>
    /// Valida si un código ya existe en la empresa (excepto el ID especificado)
    /// Mapea: FrmCCosto.Valida()
    /// </summary>
    Task<bool> ExisteCodigoAsync(string codigo, int empresaId, int? excludeId = null);
}
