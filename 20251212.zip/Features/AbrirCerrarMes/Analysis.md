# Legacy Analysis: Abrir/Cerrar Mes (Control de Períodos Contables)

## 📄 VB6 Form Information
**File:** `vb6/Contabilidad70/HyperContabilidad/FrmEstadoMeses.frm`
**Lines of Code:** 271
**Purpose:** Permite abrir y cerrar meses contables para controlar los períodos en los que se pueden registrar movimientos. Solo permite editar comprobantes en meses abiertos.

## 🎯 Business Logic Overview

Este formulario gestiona el **estado de los períodos contables** (meses) para una empresa y año específico. Los estados posibles son:
- **ABIERTO**: Se pueden registrar/modificar comprobantes en este mes
- **CERRADO**: No se permiten cambios en este mes (protección de datos históricos)

**Regla crítica:** Solo puede haber **un mes abierto a la vez** (excepto si `gAbrirMesesParalelo = True`, caso especial no común).

## 🎮 Controls Identified

### Form Properties
| Property | Value | Purpose |
|----------|-------|---------|
| Caption | "Estado de los Meses" | Window title |
| StartUpPosition | 2 'CenterScreen | Center on screen |
| BorderStyle | 3 'Fixed Dialog | Non-resizable window |
| MaxButton | False | No maximize button |
| MinButton | False | No minimize button |
| KeyPreview | True | Form receives keyboard events first |

### MSFlexGrid (Grid)
**Control Name:** `Grid`
**Type:** MSFlexGrid
**Rows:** 13 (1 header + 12 months)
**Columns:** 5

**Column Structure:**
| Col Index | Constant Name | Purpose | Width | Visible |
|-----------|---------------|---------|-------|---------|
| 0 | C_NUMMES | Month number (1-12) | 0 | Hidden |
| 1 | C_ULTIMOMES | Red arrow indicator "→" | 500 | Yes |
| 2 | C_NOMBMES | Month name (Enero, Febrero...) | 2000 | Yes |
| 3 | C_ESTADO | State text (ABIERTO/CERRADO) | 1500 | Yes |
| 4 | C_IDESTADO | State ID (EM_ABIERTO/EM_CERRADO) | 0 | Hidden |

**Grid Configuration:**
```vb
Grid.Cols = 5
Grid.rows = 13
Grid.FixedCols = 0
Grid.FixedRows = 1
Grid.SelectionMode = flexSelectionByRow
Grid.HighLight = flexHighlightAlways
```

### Buttons
| Control Name | Caption | Shortcut | Action | Permission | Mapeo .NET |
|--------------|---------|----------|--------|------------|------------|
| Bt_AbrirMes | "&Abrir Mes" | Alt+A | Opens selected month (validates only one open) | PRV_ADM_EMPRESA | OpenMonthAsync() |
| Bt_CerrarMes | "&Cerrar Mes" | Alt+C | Closes selected month | PRV_ADM_EMPRESA | CloseMonthAsync() |
| Bt_Salir | "&Salir" | Alt+S | Closes form | None | N/A (browser navigation) |

### Other Controls
| Control Name | Type | Purpose |
|--------------|------|---------|
| Lb_EmpresaRazonSocial | Label | Displays company name |
| Lb_Ano | Label | Displays current year |

## 🔧 Functions and Procedures

### Form_Load()
**Purpose:** Initializes form on load
**Logic:**
1. Sets form caption: "Estado de los Meses"
2. Calls `SetUpGrid()` to configure grid
3. Calls `LoadMeses()` to populate month data
4. Calls `SetupPriv()` to configure permissions
5. Displays company info: `gEmpresa.RazonSocial` and `gEmpresa.Ano`

**Mapeo .NET:**
- MVC Controller: Pass company info via ViewData
- JavaScript: Call API on DOMContentLoaded to load month states

---

### SetUpGrid()
**Purpose:** Configures grid columns and headers
**Logic:**
```vb
Grid.Cols = 5
Grid.rows = 13
Grid.FixedCols = 0
Grid.FixedRows = 1

' Headers
Grid.TextMatrix(0, C_NUMMES) = ""
Grid.TextMatrix(0, C_ULTIMOMES) = ""
Grid.TextMatrix(0, C_NOMBMES) = "Mes"
Grid.TextMatrix(0, C_ESTADO) = "Estado"
Grid.TextMatrix(0, C_IDESTADO) = ""

' Column widths
Grid.ColWidth(C_NUMMES) = 0          ' Hidden
Grid.ColWidth(C_ULTIMOMES) = 500     ' Arrow indicator
Grid.ColWidth(C_NOMBMES) = 2000      ' Month name
Grid.ColWidth(C_ESTADO) = 1500       ' State text
Grid.ColWidth(C_IDESTADO) = 0        ' Hidden

Grid.SelectionMode = flexSelectionByRow
Grid.HighLight = flexHighlightAlways
```

**Mapeo .NET:**
- HTML table with 4 visible columns (omit hidden columns)
- Tailwind CSS for styling

---

### LoadMeses()
**Purpose:** Loads month states from database and populates grid
**Logic:**
1. **Initialize all 12 months as CERRADO** (default state):
   ```vb
   For i = 1 To 12
      Grid.TextMatrix(i, C_NUMMES) = i
      Grid.TextMatrix(i, C_ULTIMOMES) = ""
      Grid.TextMatrix(i, C_NOMBMES) = gNomMes(i)       ' Global array: Enero, Febrero, ...
      Grid.TextMatrix(i, C_ESTADO) = gEstadoMes(EM_CERRADO)  ' "CERRADO"
      Grid.TextMatrix(i, C_IDESTADO) = EM_CERRADO
   Next i
   ```

2. **Query database for actual states**:
   ```vb
   Q1 = "SELECT Mes, Estado FROM EstadoMes "
   Q1 = Q1 & " WHERE IdEmpresa = " & gEmpresa.id & " AND Ano = " & gEmpresa.Ano
   Q1 = Q1 & " ORDER BY Mes"
   Set Rs = OpenRs(Q1)

   Do While Not Rs.EOF
      Mes = Rs("Mes")
      Estado = Rs("Estado")
      Grid.TextMatrix(Mes, C_ESTADO) = gEstadoMes(Estado)  ' "ABIERTO" or "CERRADO"
      Grid.TextMatrix(Mes, C_IDESTADO) = Estado
      Rs.MoveNext
   Loop
   ```

3. **Mark last month with movements** (red arrow indicator):
   ```vb
   Mes = GetUltimoMesConMovs()
   If Mes > 0 Then
      Grid.TextMatrix(Mes, C_ULTIMOMES) = "→"
      Grid.Row = Mes
      Grid.Col = C_NOMBMES
   End If
   ```

**Database Table:** `EstadoMes`
- Columns: `IdEmpresa`, `Ano`, `Mes`, `Estado`
- Primary Key: (IdEmpresa, Ano, Mes)
- Estado values: `EM_ABIERTO` (1), `EM_CERRADO` (0)

**Mapeo .NET:**
- Service method: `GetMonthStatesAsync(int empresaId, int ano)`
- Returns: `List<EstadoMesDto>` with 12 months
- EF Core LINQ query on `EstadoMes` table

---

### GetUltimoMesConMovs()
**Purpose:** Determines the last month that has comprobantes (movements)
**Returns:** Month number (1-12) or 0 if no movements
**Logic:**
```vb
Q1 = "SELECT MAX(Mes) as UltMes FROM Comprobante "
Q1 = Q1 & " WHERE IdEmpresa = " & gEmpresa.id & " AND Ano = " & gEmpresa.Ano
Set Rs = OpenRs(Q1)

If Not Rs.EOF Then
   If Not IsNull(Rs("UltMes")) Then
      GetUltimoMesConMovs = Rs("UltMes")
   Else
      GetUltimoMesConMovs = 0
   End If
End If
```

**Mapeo .NET:**
```csharp
var lastMonth = await _context.Comprobante
    .Where(c => c.IdEmpresa == empresaId && c.Ano == ano)
    .Select(c => c.Mes)
    .MaxAsync();
```

---

### Bt_AbrirMes_Click()
**Purpose:** Opens the selected month for editing
**Business Rule:** Only ONE month can be open at a time (unless `gAbrirMesesParalelo = True`)
**Logic:**

1. **Get selected month**:
   ```vb
   Mes = Val(Grid.TextMatrix(Grid.Row, C_NUMMES))
   ```

2. **Check if already open**:
   ```vb
   If Val(Grid.TextMatrix(Grid.Row, C_IDESTADO)) = EM_ABIERTO Then
      MsgBox1 "El mes de " & gNomMes(Mes) & " ya está abierto.", vbInformation
      Exit Sub
   End If
   ```

3. **Validate only one month open** (critical business rule):
   ```vb
   If Not gAbrirMesesParalelo Then
      For i = 1 To Grid.rows - 1
         If Val(Grid.TextMatrix(i, C_IDESTADO)) = EM_ABIERTO Then
            MsgBox1 "Para abrir este mes, debe antes cerrar el mes de " & gNomMes(i) & ".", vbExclamation
            Exit Sub
         End If
      Next i
   End If
   ```

4. **Call AbrirMes() function** (external module function):
   ```vb
   If AbrirMes(Mes) = True Then
      Grid.TextMatrix(Grid.Row, C_IDESTADO) = EM_ABIERTO
      Grid.TextMatrix(Grid.Row, C_ESTADO) = gEstadoMes(EM_ABIERTO)  ' "ABIERTO"
      MsgBox1 "El mes de " & gNomMes(Mes) & " ha sido abierto correctamente.", vbInformation
   End If
   ```

**AbrirMes() Function Logic** (assumed from typical implementation):
```vb
Function AbrirMes(Mes As Integer) As Boolean
   On Error GoTo ErrorHandler

   ' Update or Insert EstadoMes record
   Q1 = "UPDATE EstadoMes SET Estado = " & EM_ABIERTO
   Q1 = Q1 & " WHERE IdEmpresa = " & gEmpresa.id
   Q1 = Q1 & " AND Ano = " & gEmpresa.Ano
   Q1 = Q1 & " AND Mes = " & Mes

   Execute Q1

   ' If no rows affected, insert new record
   If GetRowsAffected() = 0 Then
      Q1 = "INSERT INTO EstadoMes (IdEmpresa, Ano, Mes, Estado) VALUES ("
      Q1 = Q1 & gEmpresa.id & ", " & gEmpresa.Ano & ", " & Mes & ", " & EM_ABIERTO & ")"
      Execute Q1
   End If

   AbrirMes = True
   Exit Function

ErrorHandler:
   AbrirMes = False
End Function
```

**Mapeo .NET:**
```csharp
public async Task<ValidationResult> OpenMonthAsync(int empresaId, int ano, int mes)
{
    // 1. Check if already open
    var estadoMes = await _context.EstadoMes
        .FirstOrDefaultAsync(e => e.IdEmpresa == empresaId && e.Ano == ano && e.Mes == mes);

    if (estadoMes?.Estado == EstadoMesEnum.Abierto)
    {
        return ValidationResult.Fail("El mes ya está abierto");
    }

    // 2. Validate only one month open (unless parallel mode)
    var openMonths = await _context.EstadoMes
        .Where(e => e.IdEmpresa == empresaId && e.Ano == ano && e.Estado == EstadoMesEnum.Abierto)
        .ToListAsync();

    if (openMonths.Any())
    {
        // Assuming gAbrirMesesParalelo is a configuration setting
        var config = await GetEmpresaConfigAsync(empresaId);
        if (!config.AbrirMesesParalelo)
        {
            var openMonth = openMonths.First();
            return ValidationResult.Fail($"Para abrir este mes, debe antes cerrar el mes de {GetMonthName(openMonth.Mes)}");
        }
    }

    // 3. Update or Insert EstadoMes
    if (estadoMes == null)
    {
        estadoMes = new App.Data.EstadoMes
        {
            IdEmpresa = empresaId,
            Ano = ano,
            Mes = mes,
            Estado = EstadoMesEnum.Abierto
        };
        _context.EstadoMes.Add(estadoMes);
    }
    else
    {
        estadoMes.Estado = EstadoMesEnum.Abierto;
        _context.EstadoMes.Update(estadoMes);
    }

    await _context.SaveChangesAsync();
    return ValidationResult.Success($"El mes de {GetMonthName(mes)} ha sido abierto correctamente");
}
```

---

### Bt_CerrarMes_Click()
**Purpose:** Closes the selected month
**Logic:**

1. **Get selected month**:
   ```vb
   Mes = Val(Grid.TextMatrix(Grid.Row, C_NUMMES))
   ```

2. **Check if already closed**:
   ```vb
   If Val(Grid.TextMatrix(Grid.Row, C_IDESTADO)) = EM_CERRADO Then
      MsgBox1 "El mes de " & gNomMes(Mes) & " ya está cerrado.", vbInformation
      Exit Sub
   End If
   ```

3. **Call CerrarMes() function**:
   ```vb
   If CerrarMes(Mes) = True Then
      Grid.TextMatrix(Grid.Row, C_IDESTADO) = EM_CERRADO
      Grid.TextMatrix(Grid.Row, C_ESTADO) = gEstadoMes(EM_CERRADO)  ' "CERRADO"
      MsgBox1 "El mes de " & gNomMes(Mes) & " ha sido cerrado correctamente.", vbInformation
   End If
   ```

**CerrarMes() Function Logic** (assumed):
```vb
Function CerrarMes(Mes As Integer) As Boolean
   On Error GoTo ErrorHandler

   Q1 = "UPDATE EstadoMes SET Estado = " & EM_CERRADO
   Q1 = Q1 & " WHERE IdEmpresa = " & gEmpresa.id
   Q1 = Q1 & " AND Ano = " & gEmpresa.Ano
   Q1 = Q1 & " AND Mes = " & Mes

   Execute Q1

   If GetRowsAffected() = 0 Then
      Q1 = "INSERT INTO EstadoMes (IdEmpresa, Ano, Mes, Estado) VALUES ("
      Q1 = Q1 & gEmpresa.id & ", " & gEmpresa.Ano & ", " & Mes & ", " & EM_CERRADO & ")"
      Execute Q1
   End If

   CerrarMes = True
   Exit Function

ErrorHandler:
   CerrarMes = False
End Function
```

**Mapeo .NET:**
```csharp
public async Task<ValidationResult> CloseMonthAsync(int empresaId, int ano, int mes)
{
    var estadoMes = await _context.EstadoMes
        .FirstOrDefaultAsync(e => e.IdEmpresa == empresaId && e.Ano == ano && e.Mes == mes);

    if (estadoMes?.Estado == EstadoMesEnum.Cerrado)
    {
        return ValidationResult.Fail("El mes ya está cerrado");
    }

    if (estadoMes == null)
    {
        estadoMes = new App.Data.EstadoMes
        {
            IdEmpresa = empresaId,
            Ano = ano,
            Mes = mes,
            Estado = EstadoMesEnum.Cerrado
        };
        _context.EstadoMes.Add(estadoMes);
    }
    else
    {
        estadoMes.Estado = EstadoMesEnum.Cerrado;
        _context.EstadoMes.Update(estadoMes);
    }

    await _context.SaveChangesAsync();
    return ValidationResult.Success($"El mes de {GetMonthName(mes)} ha sido cerrado correctamente");
}
```

---

### SetupPriv()
**Purpose:** Configures button permissions based on user privileges
**Logic:**
```vb
If Not CheckPrivilegios(PRV_ADM_EMPRESA) Then
   Bt_AbrirMes.Enabled = False
   Bt_CerrarMes.Enabled = False
End If
```

**Permission Required:** `PRV_ADM_EMPRESA` (Empresa Administration privilege)

**Mapeo .NET:**
- Check permissions in API controller using `[Authorize]` attribute
- Alternative: Check `gUsuario.Privilegios` bitwise flag in service layer

---

### Form_KeyPress(KeyAscii As Integer)
**Purpose:** Handles keyboard shortcuts
**Logic:**
```vb
If KeyAscii = 27 Then  ' ESC key
   Unload Me
End If
```

**Mapeo .NET:**
- JavaScript event listener: `document.addEventListener('keydown', (e) => { if (e.key === 'Escape') window.history.back(); })`

---

## 💾 Data Access

### Database Table: EstadoMes

**Schema:**
```sql
CREATE TABLE EstadoMes (
    IdEmpresa INTEGER NOT NULL,
    Ano INTEGER NOT NULL,
    Mes INTEGER NOT NULL,
    Estado INTEGER NOT NULL,
    PRIMARY KEY (IdEmpresa, Ano, Mes),
    FOREIGN KEY (IdEmpresa) REFERENCES Empresas(Id)
);
```

**Estado Values:**
- `EM_CERRADO = 0` (Closed - no edits allowed)
- `EM_ABIERTO = 1` (Open - edits allowed)

**Important:** If a record doesn't exist in `EstadoMes` for a specific month, the default state is **CERRADO**.

---

### VB6 Queries → EF Core LINQ

**VB6 Query 1: Load all month states**
```vb
Q1 = "SELECT Mes, Estado FROM EstadoMes "
Q1 = Q1 & " WHERE IdEmpresa = " & gEmpresa.id & " AND Ano = " & gEmpresa.Ano
Q1 = Q1 & " ORDER BY Mes"
```

**EF Core LINQ:**
```csharp
var monthStates = await _context.EstadoMes
    .Where(e => e.IdEmpresa == empresaId && e.Ano == ano)
    .OrderBy(e => e.Mes)
    .Select(e => new EstadoMesDto
    {
        Mes = e.Mes,
        Estado = e.Estado,
        EstadoTexto = e.Estado == 1 ? "ABIERTO" : "CERRADO"
    })
    .ToListAsync();

// Fill missing months (1-12)
var allMonths = new List<EstadoMesDto>();
for (int i = 1; i <= 12; i++)
{
    var existing = monthStates.FirstOrDefault(m => m.Mes == i);
    allMonths.Add(existing ?? new EstadoMesDto
    {
        Mes = i,
        Estado = 0,  // Default: CERRADO
        EstadoTexto = "CERRADO",
        NombreMes = GetMonthName(i)
    });
}
```

---

**VB6 Query 2: Get last month with movements**
```vb
Q1 = "SELECT MAX(Mes) as UltMes FROM Comprobante "
Q1 = Q1 & " WHERE IdEmpresa = " & gEmpresa.id & " AND Ano = " & gEmpresa.Ano
```

**EF Core LINQ:**
```csharp
var lastMonth = await _context.Comprobante
    .Where(c => c.IdEmpresa == empresaId && c.Ano == ano)
    .MaxAsync(c => (int?)c.Mes) ?? 0;
```

---

**VB6 Query 3: Update month state**
```vb
Q1 = "UPDATE EstadoMes SET Estado = " & nuevoEstado
Q1 = Q1 & " WHERE IdEmpresa = " & gEmpresa.id
Q1 = Q1 & " AND Ano = " & gEmpresa.Ano
Q1 = Q1 & " AND Mes = " & mes
```

**EF Core:**
```csharp
var estadoMes = await _context.EstadoMes
    .FirstOrDefaultAsync(e => e.IdEmpresa == empresaId && e.Ano == ano && e.Mes == mes);

if (estadoMes != null)
{
    estadoMes.Estado = nuevoEstado;
    _context.EstadoMes.Update(estadoMes);
}
else
{
    _context.EstadoMes.Add(new App.Data.EstadoMes
    {
        IdEmpresa = empresaId,
        Ano = ano,
        Mes = mes,
        Estado = nuevoEstado
    });
}

await _context.SaveChangesAsync();
```

---

## ✅ Validations

### Business Rules

1. **Only One Month Open Rule**
   - **When:** Opening a month
   - **Rule:** If another month is already open, must close it first
   - **Exception:** `gAbrirMesesParalelo = True` (configuration setting)
   - **Message:** "Para abrir este mes, debe antes cerrar el mes de {nombre_mes}."

2. **Already Open/Closed Check**
   - **When:** Opening/closing a month
   - **Rule:** Cannot open an already open month, cannot close an already closed month
   - **Message:** "El mes de {nombre_mes} ya está {abierto/cerrado}."

3. **Permission Check**
   - **When:** Form load
   - **Rule:** User must have `PRV_ADM_EMPRESA` privilege
   - **Action:** Disable "Abrir Mes" and "Cerrar Mes" buttons if no permission

### Data Validations

1. **Month Range**
   - **Rule:** Month must be between 1 and 12
   - **Validation:** `mes >= 1 && mes <= 12`

2. **Estado Values**
   - **Rule:** Estado must be 0 (CERRADO) or 1 (ABIERTO)
   - **Validation:** `estado == 0 || estado == 1`

3. **Empresa and Año**
   - **Rule:** Must be valid empresa and año from session
   - **Validation:** Check `gEmpresa.id` and `gEmpresa.Ano` not null/zero

---

## 🎨 UI/UX Behavior

### Visual Indicators

1. **Red Arrow (→)**
   - Appears in column C_ULTIMOMES
   - Marks the last month with comprobantes
   - Helps user identify data boundaries

2. **Row Selection**
   - Full row selection mode (`flexSelectionByRow`)
   - Highlights selected row
   - Always highlighted (`flexHighlightAlways`)

3. **Estado Colors** (suggested for .NET)
   - **ABIERTO**: Green badge (`bg-green-100 text-green-800`)
   - **CERRADO**: Red badge (`bg-red-100 text-red-800`)

### User Interactions

1. **Double-click on row** → Not implemented in VB6, but could be added in .NET for quick open/close

2. **ESC key** → Closes form (in .NET: navigate back)

3. **Button clicks** → Show confirmation dialog before state change (SweetAlert2 in .NET)

---

## 🔄 Migration Strategy

### Architecture Pattern

```
User Browser (Razor View)
    ↓
JavaScript (fetch API)
    ↓
MVC Controller (HttpClient)
    ↓
API Controller (REST endpoints)
    ↓
Service Layer (Business logic)
    ↓
EF Core (ORM)
    ↓
SQLite Database (EstadoMes table)
```

### Technology Stack

- **Backend:** .NET 9, ASP.NET Core MVC, Entity Framework Core 9
- **Database:** SQLite (EstadoMes table)
- **Frontend:** Razor Pages, Tailwind CSS, JavaScript (ES6+), SweetAlert2
- **Icons:** Font Awesome 6.4.0

---

## 🎯 Service Methods Determined

Based on VB6 analysis, the following service methods are required:

### IAbrirCerrarMesService

```csharp
public interface IAbrirCerrarMesService
{
    /// <summary>
    /// Gets all month states (1-12) for a company and year
    /// Maps to: LoadMeses() in VB6
    /// </summary>
    Task<IEnumerable<EstadoMesDto>> GetMonthStatesAsync(int empresaId, int ano);

    /// <summary>
    /// Gets the last month with comprobantes
    /// Maps to: GetUltimoMesConMovs() in VB6
    /// </summary>
    Task<int> GetLastMonthWithMovementsAsync(int empresaId, int ano);

    /// <summary>
    /// Opens a month (validates only one month open)
    /// Maps to: Bt_AbrirMes_Click() + AbrirMes() in VB6
    /// </summary>
    Task<ValidationResult> OpenMonthAsync(int empresaId, int ano, int mes);

    /// <summary>
    /// Closes a month
    /// Maps to: Bt_CerrarMes_Click() + CerrarMes() in VB6
    /// </summary>
    Task<ValidationResult> CloseMonthAsync(int empresaId, int ano, int mes);

    /// <summary>
    /// Gets empresa configuration for parallel month opening
    /// Maps to: gAbrirMesesParalelo global variable
    /// </summary>
    Task<bool> GetAbrirMesesParaleloAsync(int empresaId);
}
```

---

## 📋 DTOs Required

### EstadoMesDto
```csharp
public class EstadoMesDto
{
    public int Mes { get; set; }                    // 1-12
    public int Estado { get; set; }                  // 0=CERRADO, 1=ABIERTO
    public string EstadoTexto { get; set; }          // "ABIERTO" or "CERRADO"
    public string NombreMes { get; set; }            // "Enero", "Febrero", ...
    public bool EsUltimoMesConMovs { get; set; }     // Red arrow indicator
}
```

### AbrirCerrarMesRequestDto
```csharp
public class AbrirCerrarMesRequestDto
{
    public int EmpresaId { get; set; }
    public int Ano { get; set; }
    public int Mes { get; set; }
}
```

### ValidationResult
```csharp
public class ValidationResult
{
    public bool Success { get; set; }
    public string Message { get; set; }

    public static ValidationResult Ok(string message) => new() { Success = true, Message = message };
    public static ValidationResult Fail(string message) => new() { Success = false, Message = message };
}
```

---

## 🚀 API Endpoints Required

```
GET    /api/AbrirCerrarMes/estados?empresaId={id}&ano={year}
       → Returns EstadoMesDto[] (all 12 months)

GET    /api/AbrirCerrarMes/ultimo-mes-movimientos?empresaId={id}&ano={year}
       → Returns int (last month with data)

POST   /api/AbrirCerrarMes/abrir
       Body: { empresaId, ano, mes }
       → Returns ValidationResult

POST   /api/AbrirCerrarMes/cerrar
       Body: { empresaId, ano, mes }
       → Returns ValidationResult
```

---

## 🎨 UI Components (Razor View)

### Layout Structure

```html
<div class="max-w-5xl mx-auto">
    <!-- Header -->
    <div class="mb-6">
        <h1>Control de Períodos Contables</h1>
        <p>Empresa: {RazonSocial} - Año: {Ano}</p>
    </div>

    <!-- Months Table -->
    <table class="min-w-full divide-y divide-gray-200">
        <thead>
            <tr>
                <th>Indicador</th>
                <th>Mes</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <!-- 12 rows, one per month -->
            <tr>
                <td>→</td>  <!-- Red arrow if last month with data -->
                <td>Enero</td>
                <td>
                    <span class="badge bg-green-100">ABIERTO</span>
                </td>
                <td>
                    <button onclick="abrirMes(1)">Abrir</button>
                    <button onclick="cerrarMes(1)">Cerrar</button>
                </td>
            </tr>
            <!-- ... repeat for all 12 months -->
        </tbody>
    </table>
</div>
```

### JavaScript Functions

```javascript
async function loadMonthStates() {
    const response = await fetch(`/api/AbrirCerrarMes/estados?empresaId=${empresaId}&ano=${ano}`);
    const months = await response.json();
    renderTable(months);
}

async function abrirMes(mes) {
    // Show confirmation with SweetAlert2
    const result = await Swal.fire({
        title: '¿Abrir mes?',
        text: `Se abrirá el mes de ${getMonthName(mes)}`,
        icon: 'warning',
        showCancelButton: true
    });

    if (result.isConfirmed) {
        const response = await fetch('/api/AbrirCerrarMes/abrir', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ empresaId, ano, mes })
        });

        const result = await response.json();

        if (result.success) {
            Swal.fire('Éxito', result.message, 'success');
            loadMonthStates();  // Refresh table
        } else {
            Swal.fire('Error', result.message, 'error');
        }
    }
}

async function cerrarMes(mes) {
    // Similar to abrirMes()
}
```

---

## ⚠️ Critical Migration Notes

### 1. Global Variables to Configuration

**VB6 Uses Global Variables:**
- `gEmpresa.id` → Get from session or route parameter
- `gEmpresa.Ano` → Get from session or route parameter
- `gEmpresa.RazonSocial` → Query from Empresas table
- `gNomMes(1..12)` → Use C# array or resource file
- `gEstadoMes(0..1)` → Map to enum: `EstadoMesEnum { Cerrado = 0, Abierto = 1 }`
- `gAbrirMesesParalelo` → Store in `Config` table or `appsettings.json`

**.NET Approach:**
```csharp
public static class MonthNames
{
    public static readonly string[] Spanish = {
        "", "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
        "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
    };
}

public enum EstadoMesEnum
{
    Cerrado = 0,
    Abierto = 1
}
```

---

### 2. Permission Handling

**VB6 Uses:**
```vb
If Not CheckPrivilegios(PRV_ADM_EMPRESA) Then
   Bt_AbrirMes.Enabled = False
End If
```

**.NET Approach:**
- Option 1: Use `[Authorize(Policy = "AdministrarEmpresa")]` attribute
- Option 2: Check permission in service layer
- Option 3: Return button enabled/disabled state in DTO

**Recommended:** Option 3 for gradual migration
```csharp
public class EstadoMesesConfigDto
{
    public bool CanOpenClose { get; set; }  // Based on PRV_ADM_EMPRESA
    public bool AbrirMesesParalelo { get; set; }
}
```

---

### 3. EstadoMes Table Population

**Important:** If a month has no record in `EstadoMes`, default state is **CERRADO**.

**Service Logic:**
```csharp
// Always return 12 months
var dbMonths = await _context.EstadoMes
    .Where(e => e.IdEmpresa == empresaId && e.Ano == ano)
    .ToListAsync();

var allMonths = new List<EstadoMesDto>();
for (int i = 1; i <= 12; i++)
{
    var dbMonth = dbMonths.FirstOrDefault(m => m.Mes == i);
    allMonths.Add(new EstadoMesDto
    {
        Mes = i,
        Estado = dbMonth?.Estado ?? 0,  // Default: CERRADO
        EstadoTexto = dbMonth?.Estado == 1 ? "ABIERTO" : "CERRADO",
        NombreMes = MonthNames.Spanish[i]
    });
}
```

---

### 4. Red Arrow Indicator Logic

**VB6:**
```vb
Mes = GetUltimoMesConMovs()  ' Returns 1-12 or 0
If Mes > 0 Then
   Grid.TextMatrix(Mes, C_ULTIMOMES) = "→"
End If
```

**.NET:**
```csharp
var lastMonth = await GetLastMonthWithMovementsAsync(empresaId, ano);

foreach (var month in allMonths)
{
    month.EsUltimoMesConMovs = (month.Mes == lastMonth);
}
```

**Razor View:**
```html
<td>
    @if (month.EsUltimoMesConMovs)
    {
        <i class="fas fa-arrow-right text-red-500"></i>
    }
</td>
```

---

## ✅ Testing Checklist

- [ ] Load 12 months with correct names (Enero, Febrero, ...)
- [ ] Display correct estado (ABIERTO/CERRADO) for each month
- [ ] Red arrow appears on last month with comprobantes
- [ ] Open month validation: prevents opening if another month is open
- [ ] Open month: changes estado to ABIERTO in database
- [ ] Close month: changes estado to CERRADO in database
- [ ] Cannot open already open month (shows error)
- [ ] Cannot close already closed month (shows error)
- [ ] Permission check: buttons disabled without PRV_ADM_EMPRESA
- [ ] Configuration: `AbrirMesesParalelo = true` allows multiple open months

---

## 📊 Impact Analysis

### Tables Modified
- **EstadoMes** (INSERT, UPDATE)

### Tables Read
- **EstadoMes** (SELECT)
- **Comprobante** (SELECT MAX(Mes))
- **Empresas** (SELECT for company info)
- **Config** (SELECT for gAbrirMesesParalelo setting)

### Forms Affected
- **All comprobante editing forms** (must check if month is open before allowing edits)
- Future feature: Validate mes estado before INSERT/UPDATE on Comprobante

---

## 🔗 Related Features

- **Cierre Anual** (`FrmCierreAnual.frm`) - Closes all months for year-end
- **Apertura** (`FrmApertura.frm`) - Opens first month of new year
- **Saldo de Apertura** (`FrmSaldoApertura.frm`) - Sets opening balances
- **Nuevo Comprobante** (`FrmComprobante.frm`) - Must validate mes estado before saving

---

## 📝 Final Notes

This form is **CRITICAL** for accounting integrity. It prevents users from editing historical data in closed months. The "only one month open" rule is a key business constraint that must be strictly enforced in the .NET implementation.

**Migration Complexity:** Medium
**Business Logic Complexity:** Medium
**UI Complexity:** Low
**Database Impact:** Low (single table INSERT/UPDATE)

---

**Analysis Completed:** 2025-10-02
**VB6 Form Lines Analyzed:** 271
**Estimated .NET Implementation Time:** 6-8 hours
**Status:** Ready for implementation ✅
