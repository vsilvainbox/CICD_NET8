using Microsoft.AspNetCore.Mvc;
using App.Helpers;
using App.Extensions;

namespace App.Features.CambioEstado;

public class CambioEstadoController(
    IHttpClientFactory httpClientFactory,
    ILogger<CambioEstadoController> logger,
    LinkGenerator linkGenerator) : Controller
{
    [HttpGet]
    public IActionResult Index([FromQuery] string? ids = null)
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Cambio de Estado";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        // Verificar permiso PRV_ADM_COMP para cambiar estado de comprobantes
        var hasAdmCompPermission = SessionHelper.HasPrivilege(SessionHelper.Privileges.PRV_ADM_COMP);

        // Crear ViewModel tipado con todos los datos necesarios para la vista
        var model = new CambioEstadoViewModel
        {
            EmpresaId = SessionHelper.EmpresaId,
            Ano = SessionHelper.Ano,
            HasAdmCompPermission = hasAdmCompPermission,
            IdComprobantes = ids ?? string.Empty,
            NuevoEstado = 2 // Pendiente por defecto
        };

        return View(model);
    }

    /// <summary>
    /// Método que recibe el formulario con Tag Helpers
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Index(CambioEstadoViewModel viewModel)
    {
        // Verificar permiso antes de permitir cambio
        if (!SessionHelper.HasPrivilege(SessionHelper.Privileges.PRV_ADM_COMP))
        {
            logger.LogWarning("User attempted to change voucher status without permission");
            return Json(new { success = false, errors = new[] { "No tiene permisos para cambiar el estado de comprobantes. Requiere permiso: Administrar Comprobantes" } });
        }

        if (!ModelState.IsValid)
        {
            var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).ToList();
            return Json(new { success = false, errors });
        }

        // Parsear IDs del textarea
        var ids = ParsearIds(viewModel.IdComprobantes);
        if (ids.Count == 0)
        {
            return Json(new { success = false, errors = new[] { "Debe ingresar al menos un ID de comprobante válido" } });
        }

        // Crear request para la API
        var request = new CambioEstadoRequestDto
        {
            EmpresaId = SessionHelper.EmpresaId,
            Ano = SessionHelper.Ano,
            IdComprobantes = ids,
            NuevoEstado = viewModel.NuevoEstado
        };

        logger.LogInformation("MVC: CambiarEstado called with {Count} vouchers", ids.Count);

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<CambioEstadoApiController>(
            HttpContext,
            nameof(CambioEstadoApiController.CambiarEstado));

        var response = await client.PostToApiAsync<CambioEstadoRequestDto, CambioEstadoResponseDto>(url!, request);

        return Json(new { success = true, message = $"Se cambió el estado de {response.ComprobantesActualizados} comprobante(s) exitosamente" });
    }

    /// <summary>
    /// Parsea IDs del textarea (separados por coma o línea nueva)
    /// </summary>
    private static List<int> ParsearIds(string texto)
    {
        if (string.IsNullOrWhiteSpace(texto)) return new List<int>();

        return texto.Split(new[] { '\n', ',' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(s => s.Trim())
            .Where(s => int.TryParse(s, out _))
            .Select(int.Parse)
            .ToList();
    }
}
