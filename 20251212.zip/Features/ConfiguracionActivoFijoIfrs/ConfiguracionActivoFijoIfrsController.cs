using Microsoft.AspNetCore.Mvc;
using App.Helpers;

namespace App.Features.ConfiguracionActivoFijoIfrs;

public class ConfiguracionActivoFijoIfrsController(
    ILogger<ConfiguracionActivoFijoIfrsController> logger) : Controller
{
    public IActionResult Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Configuración Activo Fijo IFRS";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        logger.LogInformation("ConfiguracionActivoFijoIfrs index accessed");
        var viewModel = new ConfiguracionActivoFijoIfrsIndexViewModel
        {
            EmpresaId = SessionHelper.EmpresaId
        };
        return View(viewModel);
    }

}