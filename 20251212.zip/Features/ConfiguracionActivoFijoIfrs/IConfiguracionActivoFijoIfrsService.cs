namespace App.Features.ConfiguracionActivoFijoIfrs;

public interface IConfiguracionActivoFijoIfrsService
{
    Task<ConfiguracionActivoFijoIfrsDto> GetConfiguracionAsync(int empresaId);
    Task<int> CreateGrupoAsync(CreateGrupoDto dto);
    Task UpdateGrupoAsync(UpdateGrupoDto dto);
    Task DeleteGrupoAsync(int idGrupo, int empresaId);
    Task<int> CreateComponenteAsync(CreateComponenteDto dto);
    Task UpdateComponenteAsync(UpdateComponenteDto dto);
    Task DeleteComponenteAsync(int idComp, int empresaId);
}
