namespace App.Features.ConfiguracionActivoFijoIfrs;

public class ConfiguracionActivoFijoIfrsDto
{
    public int EmpresaId { get; set; }
    public List<GrupoIfrsDto> Grupos { get; set; } = new();
}

public class GrupoIfrsDto
{
    public int IdGrupo { get; set; }
    public int IdEmpresa { get; set; }
    public string? NombGrupo { get; set; }
    public int CantidadActivos { get; set; }
    public List<ComponenteIfrsDto> Componentes { get; set; } = new();
}

public class ComponenteIfrsDto
{
    public int IdComp { get; set; }
    public int IdEmpresa { get; set; }
    public int IdGrupo { get; set; }
    public string? NombComp { get; set; }
    public int CantidadActivos { get; set; }
}

public class CreateGrupoDto
{
    public int EmpresaId { get; set; }
    public string NombGrupo { get; set; } = string.Empty;
}

public class UpdateGrupoDto
{
    public int IdGrupo { get; set; }
    public int EmpresaId { get; set; }
    public string NombGrupo { get; set; } = string.Empty;
}

public class CreateComponenteDto
{
    public int EmpresaId { get; set; }
    public int IdGrupo { get; set; }
    public string NombComp { get; set; } = string.Empty;
}

public class UpdateComponenteDto
{
    public int IdComp { get; set; }
    public int EmpresaId { get; set; }
    public string NombComp { get; set; } = string.Empty;
}
