using Microsoft.AspNetCore.Mvc;

namespace App.Features.ConfiguracionActivoFijoIfrs;

[ApiController]
[Route("[controller]/[action]")]
public class ConfiguracionActivoFijoIfrsApiController(
    IConfiguracionActivoFijoIfrsService service,
    ILogger<ConfiguracionActivoFijoIfrsApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<ConfiguracionActivoFijoIfrsDto>> Get([FromQuery] int empresaId)
    {
        logger.LogInformation("API: Get configuraciÃ³n called");

        {
            var data = await service.GetConfiguracionAsync(empresaId);
            return Ok(data);
        }
    }

    [HttpPost]
    public async Task<ActionResult<int>> CreateGrupo([FromBody] CreateGrupoDto dto)
    {
        logger.LogInformation("API: CreateGrupo called");

        {
            var idGrupo = await service.CreateGrupoAsync(dto);
            return Ok(idGrupo);
        }
    }

    [HttpPut]
    public async Task<ActionResult> UpdateGrupo([FromBody] UpdateGrupoDto dto)
    {
        logger.LogInformation("API: UpdateGrupo called");

        await service.UpdateGrupoAsync(dto);
        return Ok();
    }

    [HttpDelete]
    public async Task<ActionResult> DeleteGrupo(int idGrupo, [FromQuery] int empresaId)
    {
        logger.LogInformation("API: DeleteGrupo called");

        await service.DeleteGrupoAsync(idGrupo, empresaId);
        return Ok();
    }

    [HttpPost]
    public async Task<ActionResult<int>> CreateComponente([FromBody] CreateComponenteDto dto)
    {
        logger.LogInformation("API: CreateComponente called");

        var idComp = await service.CreateComponenteAsync(dto);
        return Ok(idComp);
    }

    [HttpPut]
    public async Task<ActionResult> UpdateComponente([FromBody] UpdateComponenteDto dto)
    {
        logger.LogInformation("API: UpdateComponente called");

        await service.UpdateComponenteAsync(dto);
        return Ok();
    }

    [HttpDelete]
    public async Task<ActionResult> DeleteComponente(int idComp, [FromQuery] int empresaId)
    {
        logger.LogInformation("API: DeleteComponente called");

        await service.DeleteComponenteAsync(idComp, empresaId);
        return Ok();
    }
}
