using App.Data;
using Microsoft.EntityFrameworkCore;

namespace App.Features.CapitalPropio;

public class CapitalPropioService(LpContabContext context, ILogger<CapitalPropioService> logger) : ICapitalPropioService
{
    private const int CLASCTA_ACTIVO = 1;
    private const int CLASCTA_PASIVO = 2;
    private const int CAPPROPIO_ACTIVO_COMPACTIVO = 1;
    private const int CAPPROPIO_ACTIVO_VALINTO = 2;
    private const int CAPPROPIO_PASIVO_EXIGIBLE = 3;
    private const int TAJUSTE_TRIBUTARIO = 1;
    private const int TAJUSTE_AMBOS = 3;
    private const int EC_APROBADO = 2;

    public async Task<CapitalPropioResultDto> CalculateCapitalPropioAsync(int empresaId, short ano)
    {
        logger.LogInformation("Calculating Capital Propio for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        var result = new CapitalPropioResultDto { Ano = ano };
        var fechaInicio = new DateTime(ano, 1, 1).ToOADate();
        var fechaFin = new DateTime(ano, 12, 31).ToOADate();

        {
            // 1. Calcular Total Activos (Debe - Haber, excluyendo Capital Propio - Complementario de Activo)
            var totalActivosDebe = await (from m in context.MovComprobante
                join c in context.Cuentas on new { idCuenta = m.IdCuenta, IdEmpresa = m.IdEmpresa, Ano = m.Ano }
                    equals new { idCuenta = (int?)c.idCuenta, IdEmpresa = (int?)c.IdEmpresa, Ano = (short?)c.Ano }
                join comp in context.Comprobante on new { IdComp = m.IdComp, IdEmpresa = m.IdEmpresa, Ano = m.Ano }
                    equals new { IdComp = (int?)comp.IdComp, IdEmpresa = comp.IdEmpresa, Ano = comp.Ano }
                where m.IdEmpresa == empresaId && m.Ano == ano
                where c.Clasificacion == CLASCTA_ACTIVO
                where (c.Atrib2 == null || c.Atrib2 == 0) ||
                      (c.Atrib2 != 0 && c.TipoCapPropio != CAPPROPIO_ACTIVO_COMPACTIVO)
                where comp.TipoAjuste == TAJUSTE_TRIBUTARIO || comp.TipoAjuste == TAJUSTE_AMBOS
                                          where comp.Estado == EC_APROBADO
                                          where comp.Fecha >= fechaInicio && comp.Fecha <= fechaFin
                select m.Debe ?? 0).SumAsync();

            var totalActivosHaber = await (from m in context.MovComprobante
                join c in context.Cuentas on new { idCuenta = m.IdCuenta, IdEmpresa = m.IdEmpresa, Ano = m.Ano }
                    equals new { idCuenta = (int?)c.idCuenta, IdEmpresa = (int?)c.IdEmpresa, Ano = (short?)c.Ano }
                join comp in context.Comprobante on new { IdComp = m.IdComp, IdEmpresa = m.IdEmpresa, Ano = m.Ano }
                    equals new { IdComp = (int?)comp.IdComp, IdEmpresa = comp.IdEmpresa, Ano = comp.Ano }
                where m.IdEmpresa == empresaId && m.Ano == ano
                where c.Clasificacion == CLASCTA_ACTIVO
                where (c.Atrib2 == null || c.Atrib2 == 0) ||
                      (c.Atrib2 != 0 && c.TipoCapPropio != CAPPROPIO_ACTIVO_COMPACTIVO)
                where comp.TipoAjuste == TAJUSTE_TRIBUTARIO || comp.TipoAjuste == TAJUSTE_AMBOS
                                           where comp.Estado == EC_APROBADO
                                           where comp.Fecha >= fechaInicio && comp.Fecha <= fechaFin
                select m.Haber ?? 0).SumAsync();

            result.TotalActivos = (decimal)(totalActivosDebe - totalActivosHaber);

            // 2. Calcular Deducciones del Activo (Complementario de Activo)
            var deduccionesData = await (from m in context.MovComprobante
                join c in context.Cuentas on new { idCuenta = m.IdCuenta, IdEmpresa = m.IdEmpresa, Ano = m.Ano }
                    equals new { idCuenta = (int?)c.idCuenta, IdEmpresa = (int?)c.IdEmpresa, Ano = (short?)c.Ano }
                join comp in context.Comprobante on new { IdComp = m.IdComp, IdEmpresa = m.IdEmpresa, Ano = m.Ano }
                    equals new { IdComp = (int?)comp.IdComp, IdEmpresa = comp.IdEmpresa, Ano = comp.Ano }
                where m.IdEmpresa == empresaId && m.Ano == ano
                where c.Clasificacion == CLASCTA_ACTIVO
                where c.Atrib2 != 0 && c.TipoCapPropio == CAPPROPIO_ACTIVO_COMPACTIVO
                where comp.TipoAjuste == TAJUSTE_TRIBUTARIO || comp.TipoAjuste == TAJUSTE_AMBOS
                                         where comp.Estado == EC_APROBADO
                                         where comp.Fecha >= fechaInicio && comp.Fecha <= fechaFin
                group m by c.Descripcion into g
                select new DetalleLineaDto
                {
                    Descripcion = g.Key,
                    Valor = (decimal)g.Sum(m => (m.Debe ?? 0) - (m.Haber ?? 0))
                }).ToListAsync();

            result.DeduccionesActivo = deduccionesData;
            result.TotalDeducciones = deduccionesData.Sum(d => d.Valor);

            // Activo Depurado = Total Activos + Total Deducciones (ya viene negativo)
            result.ActivoDepurado = result.TotalActivos + result.TotalDeducciones;

            // 3. Calcular Valores INTO
            var valoresIntoData = await (from m in context.MovComprobante
                join c in context.Cuentas on new { idCuenta = m.IdCuenta, IdEmpresa = m.IdEmpresa, Ano = m.Ano }
                    equals new { idCuenta = (int?)c.idCuenta, IdEmpresa = (int?)c.IdEmpresa, Ano = (short?)c.Ano }
                join comp in context.Comprobante on new { IdComp = m.IdComp, IdEmpresa = m.IdEmpresa, Ano = m.Ano }
                    equals new { IdComp = (int?)comp.IdComp, IdEmpresa = comp.IdEmpresa, Ano = comp.Ano }
                where m.IdEmpresa == empresaId && m.Ano == ano
                where c.Clasificacion == CLASCTA_ACTIVO
                where c.Atrib2 != 0 && c.TipoCapPropio == CAPPROPIO_ACTIVO_VALINTO
                where comp.TipoAjuste == TAJUSTE_TRIBUTARIO || comp.TipoAjuste == TAJUSTE_AMBOS
                                         where comp.Estado == EC_APROBADO
                                         where comp.Fecha >= fechaInicio && comp.Fecha <= fechaFin
                group m by c.Descripcion into g
                select new DetalleLineaDto
                {
                    Descripcion = g.Key,
                    Valor = (decimal)g.Sum(m => (m.Debe ?? 0) - (m.Haber ?? 0))
                }).ToListAsync();

            result.ValoresINTO = valoresIntoData;
            result.TotalValoresINTO = valoresIntoData.Sum(v => v.Valor);

            // Capital Efectivo = Activo Depurado - Valores INTO
            result.CapitalEfectivo = result.ActivoDepurado - result.TotalValoresINTO;

            // 4. Calcular Pasivo Exigible
            var pasivoExigibleData = await (from m in context.MovComprobante
                join c in context.Cuentas on new { idCuenta = m.IdCuenta, IdEmpresa = m.IdEmpresa, Ano = m.Ano }
                equals new { idCuenta = (int?)c.idCuenta, IdEmpresa = (int?)c.IdEmpresa, Ano = (short?)c.Ano }
                join comp in context.Comprobante on new { IdComp = m.IdComp, IdEmpresa = m.IdEmpresa, Ano = m.Ano }
                equals new { IdComp = (int?)comp.IdComp, IdEmpresa = comp.IdEmpresa, Ano = comp.Ano }
                where m.IdEmpresa == empresaId && m.Ano == ano
                where c.Clasificacion == CLASCTA_PASIVO
                where c.Atrib2 != 0 && c.TipoCapPropio == CAPPROPIO_PASIVO_EXIGIBLE
                where comp.TipoAjuste == TAJUSTE_TRIBUTARIO || comp.TipoAjuste == TAJUSTE_AMBOS
                                            where comp.Estado == EC_APROBADO
                                            where comp.Fecha >= fechaInicio && comp.Fecha <= fechaFin
                group m by c.Descripcion into g
                select new DetalleLineaDto
                {
                    Descripcion = g.Key,
                    Valor = (decimal)g.Sum(m => (m.Debe ?? 0) - (m.Haber ?? 0))
                }).ToListAsync();

            result.PasivoExigible = pasivoExigibleData;
            result.TotalPasivoExigible = pasivoExigibleData.Sum(p => p.Valor);

            // Capital Propio Tributario = Capital Efectivo - Pasivo Exigible
            result.CapitalPropioTributario = result.CapitalEfectivo + result.TotalPasivoExigible; // Ya viene negativo

            // Determinar código Form 22
            result.CodigoForm22 = result.CapitalPropioTributario >= 0 ? 645 : 646;

            // Advertencias sobre saldos incorrectos
            foreach (var valInto in result.ValoresINTO.Where(v => v.Valor < 0))
            {
                result.Advertencias.Add($"ADVERTENCIA: La cuenta de valores INTO '{valInto.Descripcion}' tiene saldo Acreedor.");
            }

            foreach (var pasExig in result.PasivoExigible.Where(p => p.Valor > 0))
            {
                result.Advertencias.Add($"ADVERTENCIA: La cuenta de Pasivo Exigible '{pasExig.Descripcion}' tiene saldo Deudor.");
            }

            logger.LogInformation("Capital Propio calculated: {Total}", result.CapitalPropioTributario);

            return result;
        }
    }

    public async Task<decimal> GetCapitalEfectivoAsync(int empresaId, short ano)
    {
        var result = await CalculateCapitalPropioAsync(empresaId, ano);
        return result.CapitalEfectivo;
    }

    public async Task SaveCapitalPropioAsync(int empresaId, short ano, decimal total)
    {
        logger.LogInformation("Saving Capital Propio: {Total}", total);

        var valorString = total.ToString("F2");

        // R22: ParamEmpresa es HasNoKey, usar SQL raw
        var param = await context.ParamEmpresa
            .FirstOrDefaultAsync(p => p.Tipo == "CAPPROPIO" && p.IdEmpresa == empresaId && p.Ano == ano);

        if (param != null)
        {
            // UPDATE con SQL raw
            await context.Database.ExecuteSqlRawAsync(
                @"UPDATE ParamEmpresa
                  SET Valor = @p0
                  WHERE Tipo = @p1 AND IdEmpresa = @p2 AND Ano = @p3",
                valorString, "CAPPROPIO", empresaId, ano);
        }
        else
        {
            // INSERT con SQL raw
            await context.Database.ExecuteSqlRawAsync(
                @"INSERT INTO ParamEmpresa (Tipo, Codigo, Valor, IdEmpresa, Ano)
                  VALUES (@p0, @p1, @p2, @p3, @p4)",
                "CAPPROPIO", 0, valorString, empresaId, ano);
        }

        // Actualizar EmpresasAno (esta entidad SÍ tiene PK, puede usar EF normal)
        var empresaAno = await context.EmpresasAno
            .FirstOrDefaultAsync(e => e.idEmpresa == empresaId && e.Ano == ano);

        if (empresaAno != null)
        {
            empresaAno.CPS_CapPropioTrib = (double)total;
            await context.SaveChangesAsync();
        }
    }

    public async Task<decimal?> GetSavedCapitalPropioAsync(int empresaId, short ano)
    {
        var param = await context.ParamEmpresa
            .FirstOrDefaultAsync(p => p.Tipo == "CAPPROPIO" && p.IdEmpresa == empresaId && p.Ano == ano);

        if (param != null && decimal.TryParse(param.Valor, out var valor))
        {
            return valor;
        }

        return null;
    }
}