using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using App.Helpers;

namespace App.Features.CapitalPropio;

[Authorize]
public class CapitalPropioController(ILogger<CapitalPropioController> logger) : Controller
{
    public IActionResult Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Capital Propio";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        // Obtener empresaId y ano desde la sesión
        var empresaId = SessionHelper.EmpresaId;
        var ano = SessionHelper.Ano;

        logger.LogInformation("Loading Capital Propio for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        var viewModel = new CapitalPropioIndexViewModel
        {
            EmpresaId = empresaId,
            Ano = (short)ano
        };

        return View(viewModel);
    }

    // R19: Métodos proxy eliminados - JavaScript debe llamar directamente a CapitalPropioApiController
}
