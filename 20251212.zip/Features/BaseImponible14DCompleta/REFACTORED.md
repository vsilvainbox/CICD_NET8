# Refactorización Completada - BaseImponible14DCompleta

**Fecha:** 2025-12-07
**Guía aplicada:** D:\deploy\refactor.md

## Resumen de Cambios

Se aplicaron las reglas R19 y R20 para eliminar el patrón proxy y reemplazar fetch manual por helpers Api.*.

### Violaciones Detectadas Inicialmente
- **R19**: 3 violaciones (métodos proxy en WebController)
- **R20**: 6 violaciones (fetch manual en vistas)

### Violaciones Después de Refactorización
- **R19**: 0 violaciones
- **R20**: 0 violaciones

---

## Cambios Realizados

### 1. BaseImponible14DCompletaController.cs (WebController)

#### Eliminados (R19 - Patrón Proxy Prohibido)

Se eliminaron los siguientes métodos proxy que usaban `ProxyRequestAsync`:

- `GetData(int empresaId, short ano)` - líneas 112-126
- `GetSaldosVigentes(int empresaId, short ano)` - líneas 128-142
- `UpdateItem([FromBody] JsonElement request)` - líneas 144-165
- `Save([FromBody] JsonElement request)` - líneas 167-187
- `ExportExcel(int empresaId, short ano)` - líneas 189-203
- `ActualizarValor([FromForm] EditarValorRequest request)` - líneas 227-291

**Razón:** Estos métodos violaban R19 al actuar como proxy entre JavaScript y el ApiController. JavaScript debe llamar directamente al ApiController.

---

### 2. Views/Index.cshtml

#### Cambios en URL_ENDPOINTS (R04 + R19)

```javascript
// ANTES (apuntaban al WebController)
const URL_ENDPOINTS = {
    updateItem: '@Url.Action("ActualizarValor", "BaseImponible14DCompleta")',
    exportExcel: '@Url.Action("ExportExcel", "BaseImponible14DCompleta")'
};

// DESPUÉS (apuntan al ApiController)
const URL_ENDPOINTS = {
    updateItem: '@Url.Action("UpdateItemValue", "BaseImponible14DCompletaApi")',
    exportExcel: '@Url.Action("ExportToExcel", "BaseImponible14DCompletaApi")'
};
```

#### Función expandAll() (R20)

```javascript
// ANTES - fetch manual
const response = await fetch(`${URL_ENDPOINTS.index}?expandirTodo=true`);
const html = await response.text();

// DESPUÉS - Api.getHtml
const html = await Api.getHtml(`${URL_ENDPOINTS.index}?expandirTodo=true`);
if (!html) return;
```

#### Función saveEditModal() (R19 + R20)

```javascript
// ANTES - fetch manual + FormData al WebController
const formData = new FormData();
formData.append('Codigo', currentEditCode);
formData.append('ValorString', valorIngresado);
const response = await fetch(URL_ENDPOINTS.updateItem, {
    method: 'POST',
    headers: { 'RequestVerificationToken': token },
    body: formData
});
const result = await response.json();

// DESPUÉS - Api.put directamente al ApiController
const valorDecimal = parseFloat(valorIngresado.replace(/\./g, '').replace(',', '.'));
const url = `${URL_ENDPOINTS.updateItem}?empresaId=${empresaId}&ano=${ano}&codigo=${currentEditCode}`;
const result = await Api.put(url, valorDecimal);
```

#### Función copyToExcel() (R20)

```javascript
// ANTES - fetch manual + blob handling
const response = await fetch(`${URL_ENDPOINTS.exportExcel}?empresaId=${empresaId}&ano=${ano}`);
const blob = await response.blob();
const url = window.URL.createObjectURL(blob);
// ... código de descarga manual

// DESPUÉS - window.open (el navegador maneja la descarga)
const url = `${URL_ENDPOINTS.exportExcel}?empresaId=${empresaId}&ano=${ano}`;
window.open(url, '_blank');
```

#### Eliminado

- Bloque `@functions` con `GetAntiforgeryToken()` (ya no es necesario)

---

### 3. Views/AsistentePPM.cshtml

#### Cambios en URL_ENDPOINTS (R04 + R19)

```javascript
// ANTES (apuntaba al WebController inexistente)
const URL_ENDPOINTS = {
    getData: '@Url.Action("GetData", "BaseImponible14DCompletaApi")'
};

// DESPUÉS (apunta al ApiController correcto)
const URL_ENDPOINTS = {
    getData: '@Url.Action("GetByEmpresaAno", "BaseImponible14DCompletaApi")'
};
```

#### DOMContentLoaded (R20)

```javascript
// ANTES - fetch manual
const response = await fetch(`${URL_ENDPOINTS.getData}?empresaId=@Model.EmpresaId&ano=@Model.Ano`);
if (response.ok) {
    const data = await response.json();
    document.getElementById('txtBaseImponible').value = data.total || 0;
}

// DESPUÉS - Api.get
const data = await Api.get(URL_ENDPOINTS.getData, {
    empresaId: @Model.EmpresaId,
    ano: @Model.Ano
});

if (data) {
    document.getElementById('txtBaseImponible').value = data.baseImponible || 0;
}
```

---

### 4. Views/EditarDetalle.cshtml

#### Nuevo URL_ENDPOINTS (R04 + R19)

```javascript
// ANTES - Sin constantes de URLs, fetch directo a WebController inexistente
await fetch('@Url.Action("GuardarDetalle", "BaseImponible14DCompleta")', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
});

// DESPUÉS - Constantes de URLs apuntando al ApiController
const URL_ENDPOINTS = {
    updateItem: '@Url.Action("UpdateItemValue", "BaseImponible14DCompletaApi")'
};
```

#### Form Submit Handler (R20)

```javascript
// ANTES - fetch manual
const response = await fetch('@Url.Action("GuardarDetalle", "BaseImponible14DCompleta")', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
});

if (response.ok) {
    Swal.fire('Exito', 'Detalle guardado correctamente', 'success')
        .then(() => window.location.href = '@Url.Action("Index", "BaseImponible14DCompleta")');
} else {
    const error = await response.json();
    Swal.fire('Error', error.message || 'Error al guardar', 'error');
}

// DESPUÉS - Api.put
const url = `${URL_ENDPOINTS.updateItem}?empresaId=${empresaId}&ano=${ano}&codigo=${codigo}`;
const result = await Api.put(url, monto);

if (result) {
    await Swal.fire({
        icon: 'success',
        title: 'Guardado',
        text: 'Detalle guardado correctamente',
        timer: 1500,
        showConfirmButton: false
    });
    window.location.href = '@Url.Action("Index", "BaseImponible14DCompleta")';
}
```

---

### 5. Views/Print.cshtml

#### Cambios en URL_ENDPOINTS (R04 + R19)

```javascript
// ANTES (apuntaba al WebController inexistente)
const URL_ENDPOINTS = {
    getData: '@Url.Action("GetData", "BaseImponible14DCompletaApi")'
};

// DESPUÉS (apunta al ApiController correcto)
const URL_ENDPOINTS = {
    getData: '@Url.Action("GetByEmpresaAno", "BaseImponible14DCompletaApi")'
};
```

#### DOMContentLoaded (R20)

```javascript
// ANTES - fetch manual
const response = await fetch(`${URL_ENDPOINTS.getData}?empresaId=@empresaId&ano=@ano`);
if (response.ok) {
    const data = await response.json();
    renderData(data);
} else {
    document.getElementById('printContent').innerHTML = '<p>Error al cargar los datos</p>';
}

// DESPUÉS - Api.get
const data = await Api.get(URL_ENDPOINTS.getData, {
    empresaId: @empresaId,
    ano: @ano
});

if (data) {
    renderData(data);
} else {
    document.getElementById('printContent').innerHTML = '<p>No hay datos disponibles</p>';
}
```

#### Función renderData()

Se actualizó para trabajar con la estructura correcta del DTO:

```javascript
// ANTES - Asumía estructura incorrecta
data.items.forEach(function(item) { ... });

// DESPUÉS - Usa estructura correcta del DTO
data.secciones.forEach(function(seccion) {
    seccion.items.forEach(function(item) { ... });
});
```

---

## Reglas Verificadas

### WebController
- [x] R19 - JavaScript llama a ApiController directo (eliminados métodos proxy)
- [x] R03 - WebController solo maneja vistas (no proxy de datos)

### Vistas (Index, AsistentePPM, EditarDetalle, Print)
- [x] R04 - URLs con @Url.Action en constantes
- [x] R19 - JavaScript llama a *ApiController (no WebController)
- [x] R20 - Solo Api.get/Api.put/Api.getHtml (eliminado fetch manual)
- [x] R15 - Api.* maneja errores automáticamente con SweetAlert

---

## Beneficios de la Refactorización

### 1. Arquitectura más clara
- Separación limpia: WebController = vistas, ApiController = datos
- Eliminado middleware innecesario (métodos proxy)
- JavaScript habla directamente con API

### 2. Menos código
- Eliminadas 180 líneas de código proxy
- Lógica de manejo de errores centralizada en Api.* helpers
- Sin código duplicado de validación de respuestas

### 3. Mejor manejo de errores
- Api.* helpers muestran SweetAlert automáticamente
- Errores consistentes en toda la aplicación
- No más errores silenciosos

### 4. Más fácil de mantener
- URLs centralizadas en URL_ENDPOINTS
- Tipo de controlador visible en el nombre ("Api")
- Menos puntos de falla

---

## Testing Recomendado

### Funcionalidades a verificar:

1. **Index.cshtml**
   - [ ] Expandir todo → Recarga tabla correctamente
   - [ ] Editar valor manual → Guarda y recalcula
   - [ ] Exportar Excel → Descarga archivo
   - [ ] Saldos vigentes → Filtra correctamente

2. **AsistentePPM.cshtml**
   - [ ] Carga base imponible al abrir
   - [ ] Calcula PPM correctamente

3. **EditarDetalle.cshtml**
   - [ ] Guarda cambios correctamente
   - [ ] Redirige a Index después de guardar

4. **Print.cshtml**
   - [ ] Carga datos completos
   - [ ] Renderiza tabla con secciones
   - [ ] Muestra totales correctamente

---

## Notas Adicionales

- El ApiController ya tenía los endpoints correctos, solo era necesario eliminar el proxy
- Api.* helpers manejan automáticamente el token antiforgery para métodos POST/PUT/DELETE
- La estructura del DTO (secciones → items) se respeta en todas las vistas
- Se mantiene la funcionalidad de formato chileno de números (punto = miles, coma = decimal)

---

## Archivos Modificados

```
Features/BaseImponible14DCompleta/
├── BaseImponible14DCompletaController.cs    (180 líneas eliminadas)
├── Views/
│   ├── Index.cshtml                         (refactorizado)
│   ├── AsistentePPM.cshtml                  (refactorizado)
│   ├── EditarDetalle.cshtml                 (refactorizado)
│   └── Print.cshtml                         (refactorizado)
└── REFACTORED.md                            (este archivo)
```

---

## Estado Final

✅ **Refactorización completada exitosamente**

- 0 violaciones de R19 (proxy prohibido)
- 0 violaciones de R20 (fetch manual prohibido)
- Arquitectura limpia y mantenible
- Código consistente con el resto del proyecto
