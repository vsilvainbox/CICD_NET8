using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.BaseImponible14DCompleta;

/// <summary>
/// Controlador MVC para Base Imponible 14D Completa
/// REFACTORIZADO: Usa ViewModels, Model Binding, server-side rendering
/// </summary>
public class BaseImponible14DCompletaController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<BaseImponible14DCompletaController> logger) : Controller
{
    /// <summary>
    /// Vista principal de la base imponible 14D completa
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Index(bool expandirTodo = false, bool modoSaldosVigentes = false)
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Base Imponible 14D Completa";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        logger.LogInformation("Accediendo a Base Imponible 14D Completa para empresa {EmpresaId} año {Ano}",
            SessionHelper.EmpresaId, SessionHelper.Ano);

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<BaseImponible14DCompletaApiController>(
            HttpContext,
            nameof(BaseImponible14DCompletaApiController.GetByEmpresaAno),
            new { empresaId = SessionHelper.EmpresaId, ano = SessionHelper.Ano });

        var dto = await client.GetFromApiAsync<BaseImponible14DCompletaDto>(url!);

        // Mapear DTO a ViewModel
        var viewModel = MapearDtoAViewModel(dto, expandirTodo, modoSaldosVigentes);

        return View(viewModel);
    }

    /// <summary>
    /// Vista de detalle para edición de valores manuales
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> EditarDetalle(int codigo, string descripcion)
    {
        logger.LogInformation("Editando detalle c�digo {Codigo} para empresa {EmpresaId} año {Ano}",
            codigo, SessionHelper.EmpresaId, SessionHelper.Ano);

        var viewModel = new BaseImponible14DEditarDetalleViewModel
        {
            EmpresaId = SessionHelper.EmpresaId,
            Ano = SessionHelper.Ano,
            Codigo = codigo,
            Descripcion = descripcion ?? string.Empty
        };

        await Task.CompletedTask;
        return View(viewModel);
    }

    /// <summary>
    /// Vista de impresión
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Print()
    {
        logger.LogInformation("Vista de impresión para empresa {EmpresaId} año {Ano}",
            SessionHelper.EmpresaId, SessionHelper.Ano);

        var viewModel = new BaseImponible14DPrintViewModel
        {
            EmpresaId = SessionHelper.EmpresaId,
            Ano = SessionHelper.Ano
        };

        await Task.CompletedTask;
        return View(viewModel);
    }

    /// <summary>
    /// Vista de asistente PPM (para año >= 2022)
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> AsistentePPM()
    {
        if (SessionHelper.Ano < 2022)
        {
            TempData["Warning"] = "El asistente PPM est� disponible solo para años 2022 en adelante";
            return RedirectToAction("Index");
        }

        logger.LogInformation("Abriendo asistente PPM para empresa {EmpresaId} año {Ano}",
            SessionHelper.EmpresaId, SessionHelper.Ano);

        var viewModel = new BaseImponible14DAsistentePPMViewModel
        {
            EmpresaId = SessionHelper.EmpresaId,
            Ano = SessionHelper.Ano
        };

        await Task.CompletedTask;
        return View(viewModel);
    }


    /// <summary>
    /// Vista de saldos vigentes (solo items con valores)
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> SaldosVigentes(int empresaId, short ano)
    {
        logger.LogInformation("Cargando saldos vigentes para empresa {EmpresaId} año {Ano}", empresaId, ano);

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<BaseImponible14DCompletaApiController>(
            HttpContext,
            nameof(BaseImponible14DCompletaApiController.GetWithNonZeroValues),
            new { empresaId, ano });

        var dto = await client.GetFromApiAsync<BaseImponible14DCompletaDto>(url!);

        // Mapear DTO a ViewModel con modo saldos vigentes
        var viewModel = MapearDtoAViewModel(dto, expandirTodo: true, modoSaldosVigentes: true);

        return View("Index", viewModel);
    }


    /// <summary>
    /// Mapear DTO de API a ViewModel para la vista
    /// </summary>
    private BaseImponible14DCompletaViewModel MapearDtoAViewModel(
        BaseImponible14DCompletaDto dto,
        bool expandirTodo,
        bool modoSaldosVigentes)
    {
        var viewModel = new BaseImponible14DCompletaViewModel
        {
            EmpresaId = dto.IdEmpresa,
            Ano = dto.Ano,
            NombreEmpresa = dto.NombreEmpresa,
            Regimen = dto.Regimen,
            ProPymeGeneral = dto.ProPymeGeneral,
            ProPymeTransp = dto.ProPymeTransp,
            PeriodoCerrado = dto.PeriodoCerrado,
            TotalIngresos = dto.TotalIngresos,
            TotalEgresos = dto.TotalEgresos,
            BaseImponible = dto.BaseImponible,
            ModoSaldosVigentes = modoSaldosVigentes,
            Secciones = dto.Secciones.Select(s => new BaseImponible14DSeccionViewModel
            {
                Nivel = s.Nivel,
                Titulo = s.Titulo,
                Subtotal = s.Subtotal,
                Expandida = s.Expandida || expandirTodo,
                Items = s.Items.Select(i => MapearItemDtoAViewModel(i, expandirTodo)).ToList()
            }).ToList()
        };

        // Construir set de nodos expandidos
        if (expandirTodo)
        {
            foreach (var seccion in viewModel.Secciones)
            {
                AgregarNodosExpandidos(seccion.Items, viewModel.NodosExpandidos);
            }
        }

        return viewModel;
    }

    /// <summary>
    /// Mapear item DTO a ViewModel recursivamente
    /// </summary>
    private BaseImponible14DItemViewModel MapearItemDtoAViewModel(BaseImponible14DItemDto dto, bool expandirTodo)
    {
        return new BaseImponible14DItemViewModel
        {
            IdBaseImponible14D = dto.IdBaseImponible14D,
            IdEmpresa = dto.IdEmpresa,
            Ano = dto.Ano,
            Tipo = dto.Tipo,
            Nivel = dto.Nivel,
            Codigo = dto.Codigo,
            Descripcion = dto.Descripcion,
            Valor = dto.Valor,
            FormaIngreso = dto.FormaIngreso,
            EsEditable = dto.EsEditable,
            EsSubtotal = dto.EsSubtotal,
            EsNegrita = dto.EsNegrita,
            EsVisible = dto.EsVisible,
            ColorTexto = dto.ColorTexto,
            TieneHijos = dto.TieneHijos,
            Expandido = dto.Expandido || expandirTodo,
            CodigoEspejo = dto.CodigoEspejo,
            Hijos = dto.Hijos.Select(h => MapearItemDtoAViewModel(h, expandirTodo)).ToList()
        };
    }

    /// <summary>
    /// Agregar códigos de nodos expandidos al set
    /// </summary>
    private void AgregarNodosExpandidos(List<BaseImponible14DItemViewModel> items, HashSet<int> nodosExpandidos)
    {
        foreach (var item in items)
        {
            if (item.TieneHijos && item.Nivel <= 4)
            {
                nodosExpandidos.Add(item.Codigo);
            }

            if (item.Hijos.Any())
            {
                AgregarNodosExpandidos(item.Hijos, nodosExpandidos);
            }
        }
    }
}