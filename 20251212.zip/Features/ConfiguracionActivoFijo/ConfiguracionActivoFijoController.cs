using Microsoft.AspNetCore.Mvc;
using App.Extensions;
using App.Helpers;

namespace App.Features.ConfiguracionActivoFijo;

public class ConfiguracionActivoFijoController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<ConfiguracionActivoFijoController> logger) : Controller
{
    /// <summary>
    /// Vista principal de configuracion de Activo Fijo
    /// </summary>
    public async Task<IActionResult> Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a la Configuración de Activo Fijo";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        var empresaId = SessionHelper.EmpresaId;
        var ano = (short)SessionHelper.Ano;

        // Cargar configuracion actual
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionActivoFijoApiController>(
            HttpContext,
            nameof(ConfiguracionActivoFijoApiController.GetConfig),
            new { empresaId, ano });

        var config = await client.GetFromApiAsync<ConfiguracionActivoFijoDto>(url!);

        var viewModel = new ConfiguracionActivoFijoViewModel
        {
            IdEmpresa = empresaId,
            Ano = ano,
            AFMesCompleto = config?.AFMesCompleto ?? false
        };

        return View(viewModel);
    }

    /// <summary>
    /// Guardar configuracion usando formulario POST con Tag Helpers
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Index(ConfiguracionActivoFijoViewModel model)
    {
        if (!ModelState.IsValid)
        {
            var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).ToList();
            return Json(new { success = false, errors });
        }

        var client = httpClientFactory.CreateClient();

        var saveDto = new SaveConfiguracionActivoFijoDto
        {
            IdEmpresa = model.IdEmpresa,
            Ano = model.Ano,
            AFMesCompleto = model.AFMesCompleto
        };

        var url = linkGenerator.GetApiUrl<ConfiguracionActivoFijoApiController>(
            HttpContext,
            nameof(ConfiguracionActivoFijoApiController.SaveConfig));

        await client.PostToApiAsync<SaveConfiguracionActivoFijoDto, object>(url!, saveDto);

        return Json(new { success = true, message = "Configuración guardada exitosamente" });
    }
}
