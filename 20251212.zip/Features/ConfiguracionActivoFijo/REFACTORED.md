# Feature Refactorizada: ConfiguracionActivoFijo

**Fecha:** 2025-12-07
**Guia aplicada:** refactor.md

## Violaciones Detectadas y Corregidas

### R19: JavaScript debe llamar a ApiController directamente (2 violaciones)

**Ubicacion:** ConfiguracionActivoFijoController.cs

**Violacion 1 - Linea 73:** Uso de `ProxyRequestAsync` en metodo Index POST
```csharp
// ANTES
var (statusCode, content) = await client.ProxyRequestAsync(
    url!,
    JsonSerializer.SerializeToElement(saveDto),
    HttpMethod.Post);

if (statusCode == 200)
{
    TempData["SwalSuccess"] = "Configuracion guardada exitosamente";
    return RedirectToAction(nameof(Index));
}
else
{
    TempData["SwalError"] = "Error al guardar la configuracion";
    return View(model);
}

// DESPUES
await client.PostToApiAsync<SaveConfiguracionActivoFijoDto, object>(url!, saveDto);

TempData["SwalSuccess"] = "Configuracion guardada exitosamente";
return RedirectToAction(nameof(Index));
```

**Violacion 2 - Lineas 94-122:** Metodos proxy en WebController (GetConfig y SaveConfig)
```csharp
// ANTES - Estos metodos fueron eliminados completamente
[HttpGet]
public async Task<IActionResult> GetConfig(int empresaId, short ano)
{
    var client = httpClientFactory.CreateClient();
    var url = linkGenerator.GetApiUrl<ConfiguracionActivoFijoApiController>(...);
    var datos = await client.GetFromApiAsync<object>(url!);
    return Ok(datos);
}

[HttpPost]
public async Task<IActionResult> SaveConfig([FromBody] JsonElement request)
{
    var client = httpClientFactory.CreateClient();
    var url = linkGenerator.GetApiUrl<ConfiguracionActivoFijoApiController>(...);
    var (statusCode, content) = await client.ProxyRequestAsync(url!, request!, HttpMethod.Post);
    return StatusCode(statusCode, content);
}

// DESPUES - Eliminados (JavaScript debe llamar directamente a ApiController)
```

**Impacto:**
- El WebController ya no hace de proxy entre JavaScript y ApiController
- Se elimino la dependencia de `System.Text.Json` en el WebController
- El flujo ahora es mas directo: Form POST -> WebController -> ApiController (usando HttpClientExtensions)

---

### R22: Entidades HasNoKey deben usar SQL raw (1 violacion)

**Ubicacion:** ConfiguracionActivoFijoService.cs, lineas 54 y 67

**Violacion:** Uso de `Update()` y `AddAsync()` en entidad `ParamEmpresa` que tiene `HasNoKey`

```csharp
// ANTES
if (param != null)
{
    // Actualizar registro existente
    param.Codigo = 0;
    param.Valor = valorString;
    context.ParamEmpresa.Update(param);  // ERROR: ParamEmpresa es HasNoKey
}
else
{
    // Insertar nuevo registro
    var newParam = new App.Data.ParamEmpresa
    {
        IdEmpresa = dto.IdEmpresa,
        Ano = dto.Ano,
        Tipo = "AFMESCOMPT",
        Codigo = 0,
        Valor = valorString
    };
    await context.ParamEmpresa.AddAsync(newParam);  // ERROR: ParamEmpresa es HasNoKey
}

await context.SaveChangesAsync();

// DESPUES
if (param != null)
{
    // Actualizar registro existente usando SQL raw (ParamEmpresa es HasNoKey)
    await context.Database.ExecuteSqlRawAsync(
        @"UPDATE ParamEmpresa
          SET Codigo = @p0, Valor = @p1
          WHERE IdEmpresa = @p2 AND Ano = @p3 AND Tipo = @p4",
        0, valorString, dto.IdEmpresa, dto.Ano, "AFMESCOMPT");
}
else
{
    // Insertar nuevo registro usando SQL raw (ParamEmpresa es HasNoKey)
    await context.Database.ExecuteSqlRawAsync(
        @"INSERT INTO ParamEmpresa (IdEmpresa, Ano, Tipo, Codigo, Valor)
          VALUES (@p0, @p1, @p2, @p3, @p4)",
        dto.IdEmpresa, dto.Ano, "AFMESCOMPT", 0, valorString);
}
```

**Razon:** La entidad `ParamEmpresa` esta configurada con `HasNoKey()` en el DbContext, por lo que no puede usar los metodos `Add()`, `Update()`, `Remove()` o `Attach()` de Entity Framework. Estos metodos causan el error en runtime: "Unable to track an instance of type 'ParamEmpresa' because it does not have a primary key".

**Impacto:**
- Evita errores en runtime al intentar guardar configuracion
- Usa SQL raw con parametros (@p0, @p1, etc.) para seguridad contra SQL injection
- Elimina la necesidad de `SaveChangesAsync()` ya que ExecuteSqlRawAsync ejecuta inmediatamente

---

## Reglas Verificadas

### Service (ConfiguracionActivoFijoService.cs)
- [x] R06 - Reutiliza logica existente (no duplica queries)
- [x] R14 - Propiedades en PascalCase en DTOs
- [x] R15 - Errores de validacion lanzan BusinessException
- [x] R17 - Tipos SQL coinciden con C# (short para ano, int para empresaId)
- [x] **R22 - Entidades HasNoKey usan SQL raw (CORREGIDO)**

### ApiController (ConfiguracionActivoFijoApiController.cs)
- [x] R02 - Sin try-catch (middleware maneja errores)
- [x] R02 - Retorna Ok() para void, Ok(data) para datos
- [x] R06 - No duplica endpoints de otros features
- [x] R14 - Parametros coinciden con tipos del cliente
- [x] R15 - No captura excepciones (fluyen al middleware)

### WebController (ConfiguracionActivoFijoController.cs)
- [x] R02 - Sin try-catch
- [x] R03 - Llama a API Controller (no a Service directo)
- [x] R04 - URLs con GetApiUrl<T>() (no hardcodeadas)
- [x] R14 - Tipos genericos coinciden con ViewModel
- [x] R15 - Usa PostToApiAsync/GetFromApiAsync (lanzan excepciones)
- [x] R16 - NO usa PostAsJsonAsync, GetAsync, SendAsync manual
- [x] **R19 - Sin metodos proxy (CORREGIDO)**

### Vista (Views/Index.cshtml)
- [x] R04 - URLs con @Url.Action (no hardcodeadas) - N/A: No hay JavaScript
- [x] R07 - Header estilo Dashboard (simple, sin icono grande)
- [x] R08 - Orden correcto (Header -> Card de config -> Form)
- [x] R09 - Empty State - N/A: Es formulario de configuracion
- [x] R10 - Forms con tag helpers (asp-action, asp-for)
- [x] R11 - Botones pendientes disabled - N/A: No hay botones pendientes
- [x] R12 - Form POST para guardar (patron correcto)
- [x] R13 - Sin paginacion - N/A: No es tabla de datos
- [x] R18 - FormHandler con data-confirm-title
- [x] R19 - JavaScript llama a ApiController - N/A: No hay JavaScript personalizado
- [x] R20 - Solo Form POST - N/A: No hay fetch/ajax manual
- [x] R21 - Modales usan funciones globales - N/A: No hay modales
- [x] CSS - Inputs con bg-white text-gray-900 (editables)
- [x] CSS - Sin appearance-none en selects
- [x] CSS - Sin clases dark:*
- [x] CSS - Colores primary-* (no blue-*, green-*)

### DTO (ConfiguracionActivoFijoDto.cs)
- [x] R14 - Propiedades en PascalCase
- [x] R14 - Nombres descriptivos
- [x] R17 - Tipos coinciden con BD

---

## Archivos Modificados

1. **ConfiguracionActivoFijoService.cs**
   - Reemplazado `Update()` por `ExecuteSqlRawAsync` para UPDATE
   - Reemplazado `AddAsync()` por `ExecuteSqlRawAsync` para INSERT
   - Eliminado `SaveChangesAsync()` (ya no es necesario)

2. **ConfiguracionActivoFijoController.cs**
   - Reemplazado `ProxyRequestAsync` por `PostToApiAsync<TRequest, TResponse>`
   - Eliminado manejo manual de statusCode
   - Eliminados metodos proxy `GetConfig` y `SaveConfig`
   - Eliminado using `System.Text.Json`

---

## Verificacion de Cumplimiento

### Comandos de deteccion ejecutados (resultado esperado: 0 violaciones)

```powershell
# R19: Proxy prohibido
Select-String -Path "Features/ConfiguracionActivoFijo/*Controller.cs" -Pattern "ProxyRequestAsync"
# RESULTADO: 0 coincidencias

# R22: HasNoKey con Add/Update/Remove
Select-String -Path "Features/ConfiguracionActivoFijo/*Service.cs" -Pattern "\.(Add|Update|Remove|Attach)\s*\(" | Select-String -Pattern "ParamEmpresa"
# RESULTADO: 0 coincidencias
```

---

## Notas Tecnicas

1. **ParamEmpresa es una entidad HasNoKey**: Esta tabla no tiene clave primaria definida en el modelo de EF Core. Por lo tanto, SIEMPRE debe usarse SQL raw para INSERT, UPDATE y DELETE.

2. **Parametros SQL seguros**: Se usan parametros @p0, @p1, etc. en lugar de concatenacion de strings para prevenir SQL injection.

3. **TempData para feedback**: Se usa `TempData["SwalSuccess"]` y `TempData["SwalError"]` que son procesados automaticamente por `_Layout.cshtml` para mostrar SweetAlert.

4. **Flujo de datos consistente**:
   - Carga: WebController -> ApiController -> Service -> BD
   - Guardado: Form POST -> WebController -> ApiController -> Service -> BD (SQL raw)

5. **No hay JavaScript personalizado**: Esta feature usa solo Form POST tradicional con FormHandler, por lo que no aplican las reglas de JavaScript (R19, R20, R21).

---

## Estado Final

TODAS LAS VIOLACIONES CORREGIDAS
- R19: 2 violaciones -> 0 violaciones
- R22: 1 violacion -> 0 violaciones

Feature lista para produccion.
