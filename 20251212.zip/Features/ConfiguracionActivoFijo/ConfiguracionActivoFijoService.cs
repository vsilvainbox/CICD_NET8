using App.Data;
using App.Exceptions;
using Microsoft.EntityFrameworkCore;

namespace App.Features.ConfiguracionActivoFijo;

/// <summary>
/// Servicio para gestión de configuración de Activo Fijo
/// </summary>
public class ConfiguracionActivoFijoService(
    LpContabContext context,
    ILogger<ConfiguracionActivoFijoService> logger) : IConfiguracionActivoFijoService
{
    public async Task<ConfiguracionActivoFijoDto> GetConfiguracionAsync(int empresaId, short ano)
    {
        logger.LogInformation("Getting AF configuration for empresa {EmpresaId}, ano {Ano}", empresaId, ano);

        var param = await context.ParamEmpresa
            .FirstOrDefaultAsync(p => 
                p.IdEmpresa == empresaId && 
                p.Ano == ano && 
                p.Tipo == "AFMESCOMPT");

        var afMesCompleto = false;
        if (param != null && !string.IsNullOrEmpty(param.Valor))
        {
            // El valor se almacena como string "0" o "1"
            afMesCompleto = param.Valor == "1" || param.Valor.ToLower() == "true";
        }

        return new ConfiguracionActivoFijoDto
        {
            AFMesCompleto = afMesCompleto
        };
    }

    public async Task SaveConfiguracionAsync(SaveConfiguracionActivoFijoDto dto)
    {
        logger.LogInformation("Saving AF configuration for empresa {EmpresaId}, ano {Ano}", dto.IdEmpresa, dto.Ano);

        var param = await context.ParamEmpresa
            .FirstOrDefaultAsync(p => 
                p.IdEmpresa == dto.IdEmpresa && 
                p.Ano == dto.Ano && 
                p.Tipo == "AFMESCOMPT");

        var valorString = dto.AFMesCompleto ? "1" : "0";

        if (param != null)
        {
            // Actualizar registro existente usando SQL raw (ParamEmpresa es HasNoKey)
            await context.Database.ExecuteSqlRawAsync(
                @"UPDATE ParamEmpresa
                  SET Codigo = @p0, Valor = @p1
                  WHERE IdEmpresa = @p2 AND Ano = @p3 AND Tipo = @p4",
                0, valorString, dto.IdEmpresa, dto.Ano, "AFMESCOMPT");
        }
        else
        {
            // Insertar nuevo registro usando SQL raw (ParamEmpresa es HasNoKey)
            await context.Database.ExecuteSqlRawAsync(
                @"INSERT INTO ParamEmpresa (IdEmpresa, Ano, Tipo, Codigo, Valor)
                  VALUES (@p0, @p1, @p2, @p3, @p4)",
                dto.IdEmpresa, dto.Ano, "AFMESCOMPT", 0, valorString);
        }
        logger.LogInformation("AF configuration saved successfully");
    }
}

