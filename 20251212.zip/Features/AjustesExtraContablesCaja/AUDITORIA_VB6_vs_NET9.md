# 📊 AUDITORÍA DE GAPS: AjustesExtraContablesCaja
## Comparación VB6 → .NET 9

**Fecha de análisis:** 2025-12-06
**Feature:** Ajuste Extra Libro de Caja (Art. 14 ter)
**Archivos analizados:**
- **VB6:** `D:\deploy\vb6\Contabilidad70\HyperContabilidad\FrmAjustesExtraLibCaja.frm`
- **.NET:** `D:\deploy\Features\AjustesExtraContablesCaja\*`

---

## 📋 RESUMEN EJECUTIVO

### Métricas de Paridad

| Métrica | Resultado |
|---------|-----------|
| **Paridad Global** | **62.8%** |
| Aspectos Completos (✅) | 54 / 86 |
| Gaps Críticos (🔴) | 8 |
| Gaps Altos (🟠) | 12 |
| Gaps Medios (🟡) | 10 |
| Gaps Bajos (⚪) | 2 |
| Mejoras sobre VB6 (⭐) | 5 |

### Veredicto

🟠 **NO LISTO PARA PRODUCCIÓN** - Requiere completar funcionalidades críticas antes del despliegue.

La implementación .NET tiene la **estructura base** pero carece de la **lógica de negocio completa** que existe en VB6. Se identificaron gaps críticos en:
- Cálculo de ajustes automáticos (33 Bis, empresas relacionadas, ingresos no percibidos)
- Guardado de datos en base de datos
- Detalle de documentos relacionados
- Herramientas auxiliares (calculadora, calendario, conversión de moneda)
- Vista previa e impresión

---

## 📊 INVENTARIO DE FUNCIONALIDADES VB6

### Botones y Acciones Identificadas

| Botón VB6 | Funcionalidad | Implementado en .NET |
|-----------|---------------|:--------------------:|
| `Bt_OK` | Guardar ajustes y cerrar | ✅ Parcial (sin cerrar) |
| `Bt_Cancelar` | Cancelar sin guardar | ❌ |
| `Bt_Print` | Imprimir con configuración | ❌ |
| `Bt_Preview` | Vista previa de impresión | ❌ |
| `Bt_CopyExcel` | Copiar a Excel | ✅ |
| `Bt_DetDoc` | Ver detalle del documento | ❌ |
| `Bt_Calendar` | Abrir calendario | ❌ |
| `Bt_Calc` | Calculadora | ❌ |
| `Bt_ConvMoneda` | Convertir moneda | ❌ |
| `Bt_Sum` | Sumar celdas seleccionadas | ❌ |

### Constantes de Columnas (Grid VB6)

```vb
C_ID = 0              ' ID del ajuste (oculto)
C_TIPOAJUSTE = 1      ' 1=Agregados, 2=Deducciones (oculto)
C_IDITEM = 2          ' ID del item de ajuste (oculto)
C_CONCEPTO = 3        ' Descripción del concepto (9000 width)
C_VALOR = 4           ' Valor editable/calculado (1600 width)
C_SUBTOTAL = 5        ' Subtotales (1600 width)
C_TIPOING = 6         ' Tipo de ingreso (oculto)
C_FMT = 7             ' Formato de línea (oculto)
C_COLOBLIGATORIA = 8  ' Columna obligatoria (oculto)
C_UPD = 9             ' Marca de actualización (oculto)
```

### Variables Globales Críticas

```vb
lRow_SaldoFinal        ' Fila del saldo final
lRow_Agregados         ' Fila de inicio de agregados
lRow_Deducciones       ' Fila de inicio de deducciones
lRow_BaseImponible     ' Fila de la base imponible
lRow_GastosPresuntos   ' Fila de gastos presuntos (cálculo especial)
lRow_IngFEmision       ' Fila ingresos no percibidos > 12 meses emisión
lRow_IngFExigibilidad  ' Fila ingresos no percibidos > 12 meses exigibilidad
lValUTM                ' Valor de la UTM (para cálculo gastos presuntos)
```

### Queries SQL Identificadas

#### 1. Cálculo de Saldos Ingresos/Egresos (`CalcSaldosIngEgr`)

**Ingresos:**
```sql
SELECT Sum(Pagado) as TotIngreso
FROM LibroCaja
INNER JOIN TipoDocs ON LibroCaja.TipoLib = TipoDocs.TipoLib AND LibroCaja.TipoDoc = TipoDocs.TipoDoc
WHERE FechaIngresoLibro BETWEEN [01-01-Ano] AND [31-12-Ano]
  AND LibroCaja.TipoOper = TOPERCAJA_INGRESO (1)
  AND LibroCaja.IdEmpresa = [gEmpresa.id]
  AND LibroCaja.Ano = [gEmpresa.Ano]
```

**Egresos:**
```sql
SELECT Sum(Pagado) as TotEgreso
FROM LibroCaja
INNER JOIN TipoDocs ON LibroCaja.TipoLib = TipoDocs.TipoLib AND LibroCaja.TipoDoc = TipoDocs.TipoDoc
WHERE FechaIngresoLibro BETWEEN [01-01-Ano] AND [31-12-Ano]
  AND LibroCaja.TipoOper = TOPERCAJA_EGRESO (2)
  AND LibroCaja.IdEmpresa = [gEmpresa.id]
  AND LibroCaja.Ano = [gEmpresa.Ano]
```

**Estado en .NET:** ❌ No implementado (Service devuelve datos de prueba)

---

#### 2. Obtener Valor Guardado (`GetStoredVal`)

```sql
SELECT IdAjustesExtLibCaja, Valor
FROM AjustesExtLibCaja
WHERE TipoAjuste = [TipoAjuste]
  AND IdItemAjuste = [IdItemAjuste]
  AND IdEmpresa = [gEmpresa.id]
  AND Ano = [gEmpresa.Ano]
```

**Estado en .NET:** ❌ No implementado (TODO en línea 21)

---

#### 3. Ingresos No Percibidos - Empresas Relacionadas (`GetIngNoPercibRel`)

```sql
SELECT Sum(SaldoDoc) as Saldo
FROM Documento
INNER JOIN Entidades ON Documento.IdEntidad = Entidades.IdEntidad
  AND Documento.IdEmpresa = Entidades.IdEmpresa
WHERE TipoLib = LIB_VENTAS (2)
  AND FEmision BETWEEN [01-01-Ano] AND [31-12-Ano]
  AND NOT Entidades.EntRelacionada IS NULL
  AND Entidades.EntRelacionada <> 0
  AND Documento.IdEmpresa = [gEmpresa.id]
  AND Documento.Ano = [gEmpresa.Ano]
```

**Estado en .NET:** ❌ No implementado (TODO en Service línea 107)

---

#### 4. Ingresos No Percibidos > 12 Meses desde Emisión (`GetIngNoPercib12MesesEmiNoRel`)

```sql
SELECT Sum(SaldoDoc) as Saldo
FROM Documento
LEFT JOIN Entidades ON Documento.IdEntidad = Entidades.IdEntidad
  AND Documento.IdEmpresa = Entidades.IdEmpresa
WHERE TipoLib = LIB_VENTAS (2)
  AND (NumCuotas IS NULL OR NumCuotas = 0) -- Al contado
  AND (Entidades.EntRelacionada IS NULL OR Entidades.EntRelacionada = 0) -- No relacionada
  AND DateDiff(month, FEmisionOri, [31-12-Ano]) > 12
  AND Documento.IdEmpresa = [gEmpresa.id]
  AND Documento.Ano = [gEmpresa.Ano]
```

**Estado en .NET:** ❌ No implementado (TODO en Service línea 107)

---

#### 5. Ingresos No Percibidos > 12 Meses desde Exigibilidad (`GetIngNoPercib12MesesExigNoRel`)

```sql
SELECT Sum(MontoCuota) as Saldo
FROM Documento
INNER JOIN DocCuotas ON Documento.IdDoc = DocCuotas.IdDoc
LEFT JOIN Entidades ON Documento.IdEntidad = Entidades.IdEntidad
WHERE TipoLib = LIB_VENTAS (2)
  AND (Entidades.EntRelacionada IS NULL OR Entidades.EntRelacionada = 0) -- No relacionada
  AND (FechaIngPercibido IS NULL or FechaIngPercibido = 0) -- No pagado
  AND DateDiff(month, FEmisionOri, [31-12-Ano]) > 12
  AND Documento.IdEmpresa = [gEmpresa.id]
  AND Documento.Ano = [gEmpresa.Ano]
```

**Estado en .NET:** ❌ No implementado (TODO en Service línea 107)

---

#### 6. Ingresos/Egresos Devengados antes del Art. 14 ter (`GetIngEgrDevengados`)

```sql
SELECT Sum(Pagado) as Saldo
FROM LibroCaja
WHERE TipoOper = [TipoOper] -- 1=Ingreso, 2=Egreso
  AND NOT OperDevengada IS NULL
  AND OperDevengada <> 0
  AND FechaIngresoLibro BETWEEN [01-01-Ano] AND [31-12-Ano]
  AND IdEmpresa = [gEmpresa.id]
  AND Ano = [gEmpresa.Ano]
```

**Estado en .NET:** ❌ No implementado (TODO en Service línea 107)

---

#### 7. Crédito Art. 33 Bis (`GetVal33Bis`)

```vb
' Función no visible en el código proporcionado
' Probablemente está en un módulo compartido
```

**Estado en .NET:** ❌ No implementado

---

#### 8. Valor de la UF/UTM (`GetValUTM`)

```vb
' Función no visible en el código proporcionado
' Probablemente obtiene última UTM vigente <= 31-12-Ano
```

**Utilizado para:** Cálculo de Gastos Presuntos (mín: 1 UTM, máx: 15 UTM)

**Estado en .NET:** ❌ No implementado

---

#### 9. Carga de Cuentas Asociadas (`LoadValCuentasAjustes`)

```vb
' Función no visible en el código proporcionado
' Probablemente consulta MovComprobante o saldos de cuentas específicas
```

**Estado en .NET:** ❌ No implementado

---

#### 10. Guardado de Ajustes (`SaveAll`)

**UPDATE si existe:**
```sql
UPDATE AjustesExtLibCaja
SET Valor = [Valor]
WHERE IdAjustesExtLibCaja = [Id]
  AND IdEmpresa = [gEmpresa.id]
  AND Ano = [gEmpresa.Ano]
```

**INSERT si no existe:**
```sql
SELECT Max(IdAjustesExtLibCaja) FROM AjustesExtLibCaja
WHERE IdEmpresa = [gEmpresa.id] AND Ano = [gEmpresa.Ano]

INSERT INTO AjustesExtLibCaja (
  IdAjustesExtLibCaja, TipoAjuste, IdItemAjuste, Valor, IdEmpresa, Ano
) VALUES (
  [MaxId+1], [TipoAjuste], [IdItemAjuste], [Valor], [gEmpresa.id], [gEmpresa.Ano]
)
```

**Estado en .NET:** ❌ No implementado (TODO en línea 21)

---

### Cálculos Automáticos VB6

#### Gastos Presuntos (Item 'R')

**Fórmula:**
```vb
Base = SaldoCajaIngresos + IngNoPercib12MesesEmi + IngNoPercib12MesesExig
Calculado = Base * 0.005  ' 0.5%

' Topar en UTM
If lValUTM > 0 Then
  MaxR = 15 * lValUTM
  MinR = 1 * lValUTM

  If Calculado > MaxR Then
    Calculado = MaxR
  ElseIf Calculado < MinR Then
    Calculado = MinR
  End If
End If
```

**Estado en .NET:** ❌ No implementado

---

#### Saldo Final Libro Caja

**Fórmula:**
```vb
SaldoFinal = SaldoCajaIngresos - SaldoCajaEgresos
```

**Estado en .NET:** ✅ Implementado (cálculo simple)

---

#### Total Agregados

**Fórmula:**
```vb
TotalAgregados = Sum(Valores de items tipo TAEC_AGREGADOS)
```

**Estado en .NET:** ✅ Implementado

---

#### Total Deducciones

**Fórmula:**
```vb
TotalDeducciones = Sum(Valores de items tipo TAEC_DEDUCCIONES)
```

**Estado en .NET:** ✅ Implementado

---

#### Base Imponible

**Fórmula:**
```vb
BaseImponible = SaldoFinal + TotalAgregados - TotalDeducciones
```

**Estado en .NET:** ✅ Implementado

---

## 1️⃣ INPUTS / DEPENDENCIAS DE ENTRADA (6 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 1 | **Variables globales** | `gEmpresa.id`, `gEmpresa.Ano`, `gDbMain`, `gAjustesExtraCont()` | `SessionHelper.EmpresaId`, `SessionHelper.Ano`, `DbContext` | ✅ |
| 2 | **Parámetros de entrada** | `FEdit()` - Modal sin parámetros | `Index()` - GET, usa sesión | ✅ |
| 3 | **Configuraciones** | Array global `gAjustesExtraCont(TipoAjuste, IdItem)` con nombres y tipos de ingreso | ❌ No se carga configuración de items | 🔴 |
| 4 | **Estado previo requerido** | Valida `gEmpresa.Id > 0` implícitamente | Valida `SessionHelper.EmpresaId > 0` explícitamente (línea 16) | ✅ |
| 5 | **Datos maestros necesarios** | Tabla `AjustesExtLibCaja`, `LibroCaja`, `Documento`, `DocCuotas`, `Entidades`, `IPC` | Mismas tablas disponibles en `LpContabContext` | ✅ |
| 6 | **Conexión/Sesión** | `DbMain` (ADO Connection global) | `LpContabContext` (DI de EF Core) | ✅ |

**Resumen:** ✅ 5/6 | 🔴 1 gap crítico (configuración de items de ajuste no se carga)

---

## 2️⃣ DATOS Y PERSISTENCIA (10 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 7 | **Queries SELECT** | 6 queries complejas para cálculos de ajustes | ❌ Solo consulta básica de LibroCaja (línea 50) | 🔴 |
| 8 | **Queries INSERT** | `INSERT INTO AjustesExtLibCaja` (línea 783) | ❌ No implementado (TODO línea 21) | 🔴 |
| 9 | **Queries UPDATE** | `UPDATE AjustesExtLibCaja SET Valor` (línea 769) | ❌ No implementado (TODO línea 21) | 🔴 |
| 10 | **Queries DELETE** | No hay eliminaciones | N/A | ✅ |
| 11 | **Stored Procedures** | No se usan | N/A | ✅ |
| 12 | **Tablas accedidas** | `LibroCaja`, `TipoDocs`, `Documento`, `Entidades`, `DocCuotas`, `AjustesExtLibCaja` | Solo `LibroCaja`, `EmpresasAno`, `DocCuotas`, `IPC` | 🟠 |
| 13 | **Campos leídos** | `Pagado`, `SaldoDoc`, `NumCuotas`, `EntRelacionada`, `FEmisionOri`, `FechaIngPercibido`, `OperDevengada` | Campos básicos de `LibroCaja` | 🟠 |
| 14 | **Campos escritos** | `AjustesExtLibCaja.Valor` | ❌ No se escribe | 🔴 |
| 15 | **Transacciones** | No usa transacciones explícitas | No usa transacciones | ✅ |
| 16 | **Concurrencia** | Sin manejo | Sin manejo | ✅ |

**Resumen:** ✅ 4/10 | 🔴 4 gaps críticos | 🟠 2 gaps altos

---

## 3️⃣ ACCIONES Y OPERACIONES (6 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 17 | **Botones/Acciones** | 10 botones: OK, Cancelar, Imprimir, Preview, Excel, DetDoc, Calendar, Calc, ConvMoneda, Sum | 3 botones: Aceptar (guardar), Imprimir (window.print), Excel | 🟠 |
| 18 | **Operaciones CRUD** | Read (LoadAll), Update/Insert (SaveAll) | Read (`CalcularAjustesAsync`), Update (stub) | 🟠 |
| 19 | **Operaciones especiales** | Detalle doc (abre `FrmLibCaja` o `FrmRepActivoFijo`), Calculadora, Calendario, Conversión moneda, Suma | ❌ Ninguna | 🔴 |
| 20 | **Búsquedas** | No hay filtros de búsqueda | No hay filtros | ✅ |
| 21 | **Ordenamiento** | Grid ordenado por posición fija (Agregados, Deducciones) | Mismo orden lógico | ✅ |
| 22 | **Paginación** | No aplica (grid único) | No aplica | ✅ |

**Resumen:** ✅ 3/6 | 🔴 1 gap crítico | 🟠 2 gaps altos

---

## 4️⃣ VALIDACIONES (6 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 23 | **Campos requeridos** | `valida()` retorna siempre `True` (línea 796) - Sin validaciones | ❌ No hay validaciones | ⚪ |
| 24 | **Validación de rangos** | No hay validaciones de rango explícitas | No hay | ⚪ |
| 25 | **Validación de formato** | No hay | No hay | ✅ |
| 26 | **Validación de longitud** | No hay | No hay | ✅ |
| 27 | **Validaciones custom** | No hay (función `valida()` vacía) | No hay | ✅ |
| 28 | **Manejo de nulos** | `vFld()` para campos de DB, `vFmt()` para valores numéricos | `?? 0`, `HasValue` en nullable | ✅ |

**Resumen:** ✅ 4/6 | ⚪ 2 gaps bajos (no hay validaciones en ninguno)

---

## 5️⃣ CÁLCULOS Y LÓGICA (5 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 29 | **Funciones de cálculo** | `CalcSaldosIngEgr()`, `CalcTot()`, 6 funciones Get* para ajustes específicos | ❌ Stub de `CalcularAjustesDocumentoAsync` con TODOs | 🔴 |
| 30 | **Redondeos** | `Format(valor, NUMFMT)` para gastos presuntos (línea 722) | ❌ No implementado | 🟠 |
| 31 | **Campos calculados** | Gastos Presuntos (0.5% con tope UTM), Subtotales, Base Imponible | Subtotales básicos, sin gastos presuntos | 🟠 |
| 32 | **Dependencias campos** | `Grid_AcceptValue` recalcula todo con `CalcTot()` (línea 969) | `actualizarValor()` recalcula totales (línea 195) | ✅ |
| 33 | **Valores por defecto** | Valores leídos de DB o calculados automáticamente | ❌ Retorna valores vacíos/cero | 🟠 |

**Resumen:** ✅ 1/5 | 🔴 1 gap crítico | 🟠 3 gaps altos

---

## 6️⃣ INTERFAZ Y UX (5 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 34 | **Combos/Listas** | No hay combos | No hay combos | ✅ |
| 35 | **Mensajes usuario** | `MsgBox` para errores (no hay en este form) | `Swal.fire()` para éxito/error | ✅ |
| 36 | **Confirmaciones** | No hay confirmaciones explícitas | No hay | ✅ |
| 37 | **Habilitaciones UI** | Solo celdas con `TipoIngreso = TIA_INGDIRECTO` editables, resto bloqueado por `BeforeEdit` | Atributo `editable` controla inputs (línea 163) | ✅ |
| 38 | **Formatos display** | `Format(valor, NEGNUMFMT)` - negativos entre paréntesis | `formatNumber()` - negativos entre paréntesis (línea 276) | ✅ |

**Resumen:** ✅ 5/5 | Excelente paridad en UX básica

---

## 7️⃣ SEGURIDAD (2 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 39 | **Permisos requeridos** | No hay validación de permisos en el form | ❌ No hay `[Authorize]` o validación de permisos | 🟡 |
| 40 | **Validación acceso** | Solo valida que empresa esté seleccionada | Valida empresa seleccionada (línea 16) | ✅ |

**Resumen:** ✅ 1/2 | 🟡 1 gap medio (permisos no validados)

---

## 8️⃣ MANEJO DE ERRORES (2 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 41 | **Captura errores** | Sin `On Error GoTo` en este form | `try/catch` en frontend JS (líneas 81, 256) | ✅ |
| 42 | **Mensajes de error** | Sin manejo explícito | `Swal.fire()` con mensajes descriptivos | ✅ |

**Resumen:** ✅ 2/2 | .NET tiene mejor manejo de errores

---

## 9️⃣ OUTPUTS / SALIDAS (6 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 43 | **Datos de retorno** | `Unload Me` después de guardar - no retorna datos | `RedirectToAction` después de guardar (implícito) | ✅ |
| 44 | **Exportar Excel** | `Bt_CopyExcel_Click` - copia grid al portapapeles (línea 955) | `exportarExcel()` - descarga archivo XLS (línea 265) | ⭐ |
| 45 | **Exportar PDF** | No hay exportación a PDF directa | No hay | ✅ |
| 46 | **Exportar CSV/Texto** | No hay | No hay | ✅ |
| 47 | **Impresión** | `Bt_Print_Click` con `FrmPrtSetup`, orientación, papel foliado, `SetUpPrtGrid` (línea 812) | `window.print()` básico (línea 30) | 🟠 |
| 48 | **Llamadas a otros módulos** | `FrmLibCaja.FView()`, `FrmRepActivoFijo.FView()` al hacer clic en detalle doc (línea 260, 269) | ❌ No implementado | 🔴 |

**Resumen:** ✅ 4/6 | 🔴 1 gap crítico | 🟠 1 gap alto | ⭐ 1 mejora

---

## 🔟 PARIDAD DE CONTROLES UI (6 aspectos)

| # | Aspecto | VB6 (.frm) | .NET (.cshtml) | Estado |
|---|---------|------------|----------------|:------:|
| 49 | **TextBoxes** | No hay inputs de texto estáticos | No hay | ✅ |
| 50 | **Labels/Etiquetas** | Etiquetas de concepto en grid (col C_CONCEPTO) | Etiquetas en `<td>` (línea 131) | ✅ |
| 51 | **ComboBoxes/Selects** | No hay combos | No hay | ✅ |
| 52 | **Grids/Tablas** | `FlexEdGrid2.FEd2Grid` con 10 columnas (3 visibles) | `<table>` con 3 columnas | ✅ |
| 53 | **CheckBoxes** | No hay checkboxes | No hay | ✅ |
| 54 | **Campos ocultos/IDs** | Columnas ocultas: C_ID, C_TIPOAJUSTE, C_IDITEM, C_TIPOING, C_FMT, C_UPD | `data-tipo`, `data-index` en inputs (línea 166) | ✅ |

**Resumen:** ✅ 6/6 | Paridad perfecta en controles

---

## 1️⃣1️⃣ GRIDS Y COLUMNAS (2 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 55 | **Columnas del grid** | 3 columnas visibles: Concepto (9000), Valor (1600), Subtotal (1600) | 3 columnas: Concepto (60%), Valor (20%), Subtotal (20%) | ✅ |
| 56 | **Datos del grid** | `LoadAll()` carga saldos + items de `gAjustesExtraCont()` | `cargarDatos()` / `renderGrid()` carga desde API | ✅ |

**Resumen:** ✅ 2/2 | Estructura de grid equivalente

---

## 1️⃣2️⃣ EVENTOS E INTERACCIÓN (5 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 57 | **Doble clic** | `Grid_BeforeEdit` redirige a `Bt_DetDoc_Click` si celda no editable (línea 978) | ❌ No hay evento doble clic | 🟠 |
| 58 | **Teclas especiales** | No usa `KeyPreview` ni atajos F1-F12 | No hay | ✅ |
| 59 | **Eventos Change** | `Grid_AcceptValue` al editar celda, recalcula con `CalcTot()` (línea 964) | `actualizarValor()` en `onblur`, recalcula (línea 195) | ✅ |
| 60 | **Menú contextual** | No hay menú contextual | No hay | ✅ |
| 61 | **Modales Lookup** | Abre `FrmLibCaja` o `FrmRepActivoFijo` al hacer clic (líneas 260, 269) | ❌ No implementado | 🔴 |

**Resumen:** ✅ 3/5 | 🔴 1 gap crítico | 🟠 1 gap alto

---

## 1️⃣3️⃣ ESTADOS Y MODOS DEL FORMULARIO (3 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 62 | **Modos del form** | Un solo modo: `FEdit()` - edición modal | Un solo modo: Index - edición SPA | ✅ |
| 63 | **Controles por modo** | Celdas editables si `TipoIngreso = TIA_INGDIRECTO` | Inputs si `editable = true` | ✅ |
| 64 | **Orden de tabulación** | No tiene `TabIndex` definido | Orden natural del DOM | ✅ |

**Resumen:** ✅ 3/3 | Paridad completa

---

## 1️⃣4️⃣ INICIALIZACIÓN Y CARGA (3 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 65 | **Carga inicial** | `Form_Load()` llama `SetUpGrid()` y `LoadAll()` (línea 291) | `cargarDatos()` al cargar página (línea 294) | ✅ |
| 66 | **Valores por defecto** | Valores leídos de DB o calculados (líneas 336-499) | ❌ Valores de prueba (Service no calcula) | 🔴 |
| 67 | **Llenado de combos** | No hay combos | No hay combos | ✅ |

**Resumen:** ✅ 2/3 | 🔴 1 gap crítico (valores no se calculan)

---

## 1️⃣5️⃣ FILTROS Y BÚSQUEDA (2 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 68 | **Campos de filtro** | No hay filtros | No hay filtros | ✅ |
| 69 | **Criterios de búsqueda** | No aplica | No aplica | ✅ |

**Resumen:** ✅ 2/2 | No se requieren filtros en esta pantalla

---

## 1️⃣6️⃣ REPORTES E IMPRESIÓN (2 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 70 | **Reportes disponibles** | Vista previa (`Bt_Preview_Click`) e impresión (`Bt_Print_Click`) con `FrmPrtSetup`, `gPrtLibros`, encabezado empresa, pie de balance | `window.print()` básico con CSS `@media print` | 🟠 |
| 71 | **Parámetros de reporte** | Orientación (`lOrientacion`), papel foliado (`lPapelFoliado`), info preliminar (`lInfoPreliminar`) | ❌ Sin parámetros | 🟠 |

**Resumen:** 🟠 2 gaps altos (impresión muy básica vs VB6)

---

## 🔬 AUDITORÍA FUNCIONAL

### 1️⃣7️⃣ REGLAS DE NEGOCIO (4 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 72 | **Umbrales y límites** | Gastos Presuntos: Min 1 UTM, Max 15 UTM (líneas 722-729) | ❌ No implementado | 🔴 |
| 73 | **Fórmulas de cálculo** | Gastos Presuntos = (SaldoIng + IngNoPer12M) * 0.5%, Base Imponible = SaldoFinal + Agregados - Deducciones | Fórmula Base Imponible ✅, Gastos Presuntos ❌ | 🟠 |
| 74 | **Condiciones de negocio** | Ajustes automáticos según: EntRelacionada, NumCuotas, DateDiff > 12 meses, OperDevengada | ❌ No implementado (TODO línea 107) | 🔴 |
| 75 | **Restricciones** | No hay restricciones de edición | No hay | ✅ |

**Resumen:** ✅ 1/4 | 🔴 2 gaps críticos | 🟠 1 gap alto

---

### 1️⃣8️⃣ FLUJOS DE TRABAJO (3 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 76 | **Secuencia de estados** | No aplica (no tiene estados) | No aplica | ✅ |
| 77 | **Acciones por estado** | No aplica | No aplica | ✅ |
| 78 | **Transiciones válidas** | No aplica | No aplica | ✅ |

**Resumen:** ✅ 3/3 | No aplica a este módulo

---

### 1️⃣9️⃣ INTEGRACIONES ENTRE MÓDULOS (3 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 79 | **Llamadas a otros módulos** | `FrmLibCaja.FView(-1)` (línea 261), `FrmRepActivoFijo.FView()` (línea 270) | ❌ No implementado | 🔴 |
| 80 | **Parámetros de integración** | `FView(-1)` para ver todo el libro de caja, sin parámetros para Activo Fijo | N/A | 🔴 |
| 81 | **Datos compartidos/retorno** | No retorna datos, solo muestra modales | N/A | ✅ |

**Resumen:** ✅ 1/3 | 🔴 2 gaps críticos

---

### 2️⃣0️⃣ MENSAJES AL USUARIO (2 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 82 | **Mensajes de error** | No hay mensajes de error explícitos en este form | `Swal.fire()` para errores de carga/guardado | ⭐ |
| 83 | **Mensajes de confirmación** | No hay confirmaciones | No hay confirmaciones | ✅ |

**Resumen:** ✅ 2/2 | ⭐ .NET tiene mejor UX con mensajes

---

### 2️⃣1️⃣ CASOS BORDE Y VALORES ESPECIALES (3 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 84 | **Valores cero** | Permite valores cero, usa `vFmt()` para manejarlos | Permite valores cero | ✅ |
| 85 | **Valores negativos** | Permite negativos, formatea entre paréntesis `NEGNUMFMT` | Permite negativos, formato `(valor)` (línea 283) | ✅ |
| 86 | **Valores nulos/vacíos** | `vFld()` convierte nulls a 0 | `?? 0` convierte nulls a 0 | ✅ |

**Resumen:** ✅ 3/3 | Manejo correcto de casos borde

---

## 📊 RESUMEN DE GAPS POR PRIORIDAD

### 🔴 GAPS CRÍTICOS (8)

| # | Gap | Impacto | Archivo .NET |
|---|-----|---------|--------------|
| 1 | **Configuración de items de ajuste no se carga** | No hay conceptos/nombres de items a mostrar | `AjustesExtraContablesCajaService.cs` |
| 2 | **Query de cálculo de saldos Ingresos/Egresos no implementada** | Saldos incorrectos/vacíos | `AjustesExtraContablesCajaService.cs:50` |
| 3 | **INSERT/UPDATE en AjustesExtLibCaja no implementado** | No se guardan los datos | `AjustesExtraContablesCajaService.cs:21` |
| 4 | **Queries de ajustes automáticos no implementadas** | Items calculados (K, L, M, Ñ, W) con valor 0 | `AjustesExtraContablesCajaService.cs:107` |
| 5 | **Cálculo de Gastos Presuntos (R) no implementado** | Deducción crítica para 14 ter ausente | `AjustesExtraContablesCajaService.cs` |
| 6 | **Valores por defecto no se calculan** | Grid vacío en lugar de datos reales | `AjustesExtraContablesCajaService.cs` |
| 7 | **Navegación a detalle de documentos no implementada** | No se puede ver origen de los ajustes | `Index.cshtml` |
| 8 | **Integraciones con FrmLibCaja y FrmRepActivoFijo ausentes** | Pérdida de trazabilidad | N/A |

---

### 🟠 GAPS ALTOS (12)

| # | Gap | Impacto | Archivo .NET |
|---|-----|---------|--------------|
| 9 | **Herramientas auxiliares no implementadas** | Calculadora, Calendario, Conversión Moneda, Suma | N/A |
| 10 | **Impresión avanzada no implementada** | Sin configuración, papel foliado, encabezado empresa | `Index.cshtml:30` |
| 11 | **Vista previa de impresión ausente** | No se puede verificar antes de imprimir | N/A |
| 12 | **Botón Cancelar sin implementar** | No se puede cerrar sin guardar | `Index.cshtml` |
| 13 | **Tablas secundarias no consultadas** | `Documento`, `Entidades` no se usan | `AjustesExtraContablesCajaService.cs` |
| 14 | **Campos críticos no leídos** | `SaldoDoc`, `EntRelacionada`, `OperDevengada` | `AjustesExtraContablesCajaService.cs` |
| 15 | **Redondeo de Gastos Presuntos ausente** | Valor sin formatear a 0 decimales | N/A |
| 16 | **Valores calculados incompletos** | Solo subtotales básicos | `Index.cshtml:205` |
| 17 | **Doble clic en grid no navega** | En VB6 abre detalle, en .NET no hace nada | `Index.cshtml` |
| 18 | **Fórmula de Gastos Presuntos incompleta** | Falta 0.5%, tope UTM | N/A |
| 19 | **Parámetros de impresión ausentes** | Orientación, info preliminar | N/A |
| 20 | **Condiciones de negocio no validadas** | Lógica de empresas relacionadas, cuotas, etc. | `AjustesExtraContablesCajaService.cs` |

---

### 🟡 GAPS MEDIOS (10)

| # | Gap | Impacto | Archivo .NET |
|---|-----|---------|--------------|
| 21 | **Sin validación de permisos** | Cualquier usuario puede acceder | `AjustesExtraContablesCajaController.cs` |
| 22 | **Carga de cuentas asociadas ausente** | Items tipo `TIA_CTASASOCIADAS` sin valor | N/A |
| 23 | **Crédito Art. 33 Bis no calculado** | Item 'H' sin valor | N/A |
| 24 | **Valor de UTM no se obtiene** | Gastos Presuntos sin tope | N/A |
| 25 | **No valida año cerrado/bloqueado** | Permite editar períodos cerrados | N/A |
| 26 | **Sin log de auditoría** | No registra quién modificó | N/A |
| 27 | **Formato NEGNUMFMT no exacto** | VB6 usa formato específico de sistema | `Index.cshtml:276` |
| 28 | **Sin validación de EmpresasAno** | Si no existe, retorna DTO vacío sin avisar | `AjustesExtraContablesCajaService.cs:62` |
| 29 | **IPC conversion no completa** | Solo estructura, falta lógica de ajuste | `AjustesExtraContablesCajaService.cs:128` |
| 30 | **Sin manejo de entidades relacionadas** | Flag `ConEntRel` se lee pero no se usa | `AjustesExtraContablesCajaService.cs:154` |

---

### ⚪ GAPS BAJOS (2)

| # | Gap | Impacto | Archivo .NET |
|---|-----|---------|--------------|
| 31 | **Sin validaciones de campos** | VB6 tampoco las tiene (`valida()` vacía) | N/A |
| 32 | **Sin validaciones de rangos** | Ambos sistemas permiten cualquier valor | N/A |

---

## ⭐ MEJORAS EN .NET SOBRE VB6 (5)

| # | Mejora | Descripción | Archivo .NET |
|---|--------|-------------|--------------|
| 1 | **Arquitectura limpia** | Separación Controller → Service → Repository | Todos |
| 2 | **Async/Await** | Operaciones asíncronas para mejor escalabilidad | `AjustesExtraContablesCajaService.cs` |
| 3 | **Mensajes SweetAlert** | UX moderna vs MsgBox | `Index.cshtml:82` |
| 4 | **Exportación Excel mejorada** | Descarga archivo vs copiar portapapeles | `Index.cshtml:265` |
| 5 | **Responsive design** | Tailwind CSS vs formulario fijo VB6 | `Index.cshtml` |

---

## 🎯 RECOMENDACIONES

### Prioridad 1 - CRÍTICA (Bloquea producción)

#### 1.1 Implementar carga de configuración de items
**Archivo:** `AjustesExtraContablesCajaService.cs`

Crear método para cargar items desde una tabla de configuración (equivalente a `gAjustesExtraCont()` en VB6):

```csharp
// Opción A: Tabla AjustesExtraContConfig
SELECT TipoAjuste, IdItem, Nombre, TipoIngreso, IdItemCtasAsociadas
FROM AjustesExtraContConfig
WHERE Activo = 1
ORDER BY TipoAjuste, Orden

// Opción B: Hardcodear en código (menos flexible)
private static readonly Dictionary<(int TipoAjuste, int IdItem), AjusteConfig> ConfiguracionItems = new() { ... }
```

---

#### 1.2 Implementar queries de cálculo de saldos
**Archivo:** `AjustesExtraContablesCajaService.cs`

```csharp
private async Task<(decimal Ingresos, decimal Egresos)> CalcSaldosIngEgrAsync(int empresaId, short ano)
{
    var fechaInicio = new DateTime(ano, 1, 1);
    var fechaFin = new DateTime(ano, 12, 31);

    var ingresos = await context.LibroCaja
        .Where(lc => lc.IdEmpresa == empresaId
                  && lc.Ano == ano
                  && lc.FechaIngresoLibro >= fechaInicio.ToOADate()
                  && lc.FechaIngresoLibro <= fechaFin.ToOADate()
                  && lc.TipoOper == 1) // TOPERCAJA_INGRESO
        .SumAsync(lc => lc.Pagado ?? 0);

    var egresos = await context.LibroCaja
        .Where(lc => lc.IdEmpresa == empresaId
                  && lc.Ano == ano
                  && lc.FechaIngresoLibro >= fechaInicio.ToOADate()
                  && lc.FechaIngresoLibro <= fechaFin.ToOADate()
                  && lc.TipoOper == 2) // TOPERCAJA_EGRESO
        .SumAsync(lc => lc.Pagado ?? 0);

    return (ingresos, egresos);
}
```

---

#### 1.3 Implementar guardado en AjustesExtLibCaja
**Archivo:** `AjustesExtraContablesCajaService.cs` (línea 21)

```csharp
public async Task<GuardarAjustesResponseDto> GuardarAjustesAsync(SaveAjustesDto dto)
{
    using var transaction = await context.Database.BeginTransactionAsync();

    try
    {
        foreach (var item in dto.Items)
        {
            var existente = await context.AjustesExtLibCaja
                .FirstOrDefaultAsync(a => a.IdEmpresa == dto.EmpresaId
                                       && a.Ano == dto.Ano
                                       && a.TipoAjuste == item.TipoAjuste
                                       && a.IdItemAjuste == item.IdItemAjuste);

            if (existente != null)
            {
                existente.Valor = item.Valor;
            }
            else
            {
                var maxId = await context.AjustesExtLibCaja
                    .Where(a => a.IdEmpresa == dto.EmpresaId && a.Ano == dto.Ano)
                    .MaxAsync(a => (int?)a.IdAjustesExtLibCaja) ?? 0;

                context.AjustesExtLibCaja.Add(new AjustesExtLibCaja
                {
                    IdAjustesExtLibCaja = maxId + 1,
                    TipoAjuste = item.TipoAjuste,
                    IdItemAjuste = item.IdItemAjuste,
                    Valor = item.Valor,
                    IdEmpresa = dto.EmpresaId,
                    Ano = dto.Ano
                });
            }
        }

        await context.SaveChangesAsync();
        await transaction.CommitAsync();

        return new GuardarAjustesResponseDto { Message = "Ajustes guardados correctamente" };
    }
    catch (Exception ex)
    {
        await transaction.RollbackAsync();
        logger.LogError(ex, "Error guardando ajustes");
        throw;
    }
}
```

---

#### 1.4 Implementar queries de ajustes automáticos
**Archivo:** `AjustesExtraContablesCajaService.cs` (reemplazar TODO línea 107)

**K - Ingresos No Percibidos Empresas Relacionadas:**
```csharp
private async Task<decimal> GetIngNoPercibRelAsync(int empresaId, short ano)
{
    var fechaInicio = new DateTime(ano, 1, 1);
    var fechaFin = new DateTime(ano, 12, 31);

    var saldo = await (from doc in context.Documento
                       join ent in context.Entidades
                           on new { doc.IdEntidad, doc.IdEmpresa } equals new { ent.IdEntidad, ent.IdEmpresa }
                       where doc.IdEmpresa == empresaId
                             && doc.Ano == ano
                             && doc.TipoLib == 2 // LIB_VENTAS
                             && doc.FEmision >= fechaInicio.ToOADate()
                             && doc.FEmision <= fechaFin.ToOADate()
                             && ent.EntRelacionada == true
                       select doc.SaldoDoc ?? 0)
                      .SumAsync();

    return saldo;
}
```

**L - Ingresos No Percibidos > 12 Meses desde Emisión (No Relacionadas):**
```csharp
private async Task<decimal> GetIngNoPercib12MesesEmiNoRelAsync(int empresaId, short ano)
{
    var fechaCierre = new DateTime(ano, 12, 31);
    var fecha12MesesAtras = fechaCierre.AddMonths(-12);

    var saldo = await (from doc in context.Documento
                       from ent in context.Entidades.Where(e => e.IdEntidad == doc.IdEntidad && e.IdEmpresa == doc.IdEmpresa).DefaultIfEmpty()
                       where doc.IdEmpresa == empresaId
                             && doc.Ano == ano
                             && doc.TipoLib == 2 // LIB_VENTAS
                             && (doc.NumCuotas == null || doc.NumCuotas == 0) // Al contado
                             && (ent == null || ent.EntRelacionada != true) // No relacionada
                             && doc.FEmisionOri < fecha12MesesAtras.ToOADate()
                       select doc.SaldoDoc ?? 0)
                      .SumAsync();

    return saldo;
}
```

**M - Ingresos No Percibidos > 12 Meses desde Exigibilidad (No Relacionadas):**
```csharp
private async Task<decimal> GetIngNoPercib12MesesExigNoRelAsync(int empresaId, short ano)
{
    var fechaCierre = new DateTime(ano, 12, 31);
    var fecha12MesesAtras = fechaCierre.AddMonths(-12);

    var saldo = await (from doc in context.Documento
                       join cuota in context.DocCuotas
                           on new { doc.IdDoc, doc.IdEmpresa, doc.Ano } equals new { cuota.IdDoc, cuota.IdEmpresa, cuota.Ano }
                       from ent in context.Entidades.Where(e => e.IdEntidad == doc.IdEntidad && e.IdEmpresa == doc.IdEmpresa).DefaultIfEmpty()
                       where doc.IdEmpresa == empresaId
                             && doc.Ano == ano
                             && doc.TipoLib == 2 // LIB_VENTAS
                             && (ent == null || ent.EntRelacionada != true)
                             && (cuota.FechaIngPercibido == null || cuota.FechaIngPercibido == 0)
                             && doc.FEmisionOri < fecha12MesesAtras.ToOADate()
                       select cuota.MontoCuota ?? 0)
                      .SumAsync();

    return saldo;
}
```

**Ñ y W - Operaciones Devengadas:**
```csharp
private async Task<decimal> GetIngEgrDevengadosAsync(int empresaId, short ano, int tipoOper)
{
    var fechaInicio = new DateTime(ano, 1, 1);
    var fechaFin = new DateTime(ano, 12, 31);

    var saldo = await context.LibroCaja
        .Where(lc => lc.IdEmpresa == empresaId
                  && lc.Ano == ano
                  && lc.TipoOper == tipoOper
                  && lc.OperDevengada == true
                  && lc.FechaIngresoLibro >= fechaInicio.ToOADate()
                  && lc.FechaIngresoLibro <= fechaFin.ToOADate())
        .SumAsync(lc => lc.Pagado ?? 0);

    return saldo;
}
```

---

#### 1.5 Implementar cálculo de Gastos Presuntos
**Archivo:** `AjustesExtraContablesCajaService.cs`

```csharp
private async Task<decimal> CalcularGastosPresuntosAsync(
    decimal saldoCajaIngresos,
    decimal ingNoPercib12MesesEmi,
    decimal ingNoPercib12MesesExig,
    short ano)
{
    // Base = Ingresos + Ing.NoPerc.12Meses
    var baseCalculo = saldoCajaIngresos + ingNoPercib12MesesEmi + ingNoPercib12MesesExig;

    // Calcular 0.5%
    var gastosPresuntos = baseCalculo * 0.005m;

    // Obtener valor UTM vigente al 31/12/Ano
    var fechaCierre = new DateTime(ano, 12, 31);
    var anoMesCierre = ano * 100 + 12;

    var utm = await context.UTM
        .Where(u => u.AnoMes <= anoMesCierre)
        .OrderByDescending(u => u.AnoMes)
        .Select(u => u.vUTM)
        .FirstOrDefaultAsync();

    if (utm.HasValue && utm.Value > 0)
    {
        var maxGastos = 15 * utm.Value;
        var minGastos = utm.Value;

        // Redondear a 0 decimales
        gastosPresuntos = Math.Round(gastosPresuntos, 0);

        // Topar
        if (gastosPresuntos > maxGastos)
            gastosPresuntos = maxGastos;
        else if (gastosPresuntos < minGastos)
            gastosPresuntos = minGastos;
    }

    return gastosPresuntos;
}
```

---

### Prioridad 2 - ALTA (Planificar en siguiente sprint)

#### 2.1 Implementar navegación a detalle de documentos
**Archivo:** `Index.cshtml`

Agregar evento doble clic en filas no editables:
```javascript
function agregarFilaEditable(item, index, tipo) {
    // ... código existente ...

    if (!item.editable) {
        tr.style.cursor = 'pointer';
        tr.ondblclick = () => abrirDetalle(item);
    }
}

function abrirDetalle(item) {
    if (item.concepto.toLowerCase().includes('33 bis')) {
        window.open('/ActivoFijo/Reporte', '_blank');
    } else {
        window.open('/LibroCaja/Index', '_blank');
    }
}
```

---

#### 2.2 Implementar impresión avanzada
**Archivo:** Crear `AjustesExtraContablesCaja/Views/Print.cshtml`

Vista de impresión con encabezado de empresa, configuración de papel foliado, orientación.

**Controller:**
```csharp
[HttpGet]
public async Task<IActionResult> Print(int empresaId, short ano, bool prelim = false)
{
    var datos = await httpClientFactory.CreateClient()
        .GetFromApiAsync<AjustesExtraContablesCajaDto>(...);

    var empresa = await GetEmpresaDataAsync(empresaId);

    ViewBag.InfoPreliminar = prelim ? "INFORMACIÓN PRELIMINAR" : null;
    ViewBag.Empresa = empresa;

    return View(datos);
}
```

---

#### 2.3 Agregar herramientas auxiliares
**Opciones:**
1. Botón Calculadora: Abrir calculadora de Windows con `Process.Start("calc")`
2. Calendario: Widget de calendario JS (ej: Flatpickr)
3. Conversión Moneda: Modal con tipo de cambio del día
4. Suma: Seleccionar celdas y mostrar total en tooltip

**Prioridad:** Media-Baja (nice to have)

---

#### 2.4 Implementar botón Cancelar
**Archivo:** `Index.cshtml`

```html
<a href="@Url.Action("Index", "Home")"
   class="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50">
    Cancelar
</a>
```

O si se abre modal:
```javascript
function cancelar() {
    if (confirm('¿Desea salir sin guardar?')) {
        window.close(); // Si es popup
        // O: window.location = '/Home/Index';
    }
}
```

---

### Prioridad 3 - MEDIA (Backlog)

#### 3.1 Agregar validación de permisos
**Archivo:** `AjustesExtraContablesCajaController.cs`

```csharp
[Authorize(Policy = "AjustesExtraContablesCaja.Ver")]
public IActionResult Index() { ... }

[Authorize(Policy = "AjustesExtraContablesCaja.Editar")]
public async Task<IActionResult> Guardar(...) { ... }
```

---

#### 3.2 Implementar cálculo de Art. 33 Bis
Requiere análisis del módulo de Activo Fijo.

---

#### 3.3 Validar año cerrado
```csharp
var empresaAno = await context.EmpresasAno
    .FirstOrDefaultAsync(ea => ea.idEmpresa == empresaId && ea.Ano == ano);

if (empresaAno?.FCierre != null && empresaAno.FCierre > 0)
{
    throw new BusinessException("El período está cerrado y no puede modificarse");
}
```

---

### Prioridad 4 - BAJA (Opcional)

#### 4.1 Agregar log de auditoría
Tabla `AuditLog` con usuario, fecha, acción, valores antes/después.

---

#### 4.2 Validaciones de campos
Como VB6 no tiene validaciones, evaluar si son necesarias en .NET (ej: valores razonables, rangos).

---

## ✅ CONCLUSIÓN

### Estado Actual
La implementación .NET de **AjustesExtraContablesCaja** tiene una **paridad estructural del 62.8%** con VB6, pero **paridad funcional cercana al 30%** debido a que las funcionalidades de cálculo críticas no están implementadas.

### Veredicto Final
🔴 **NO LISTO PARA PRODUCCIÓN**

### Riesgos de Deployment
- **Datos incorrectos:** Saldos y ajustes automáticos retornan valores vacíos/cero
- **Pérdida de datos:** El guardado no funciona (TODO en línea 21)
- **Incumplimiento tributario:** Cálculos del Art. 14 ter incorrectos pueden generar problemas con el SII
- **Pérdida de trazabilidad:** No se puede navegar a documentos de origen

### Esfuerzo Estimado para Completar
- **Prioridad 1 (Crítica):** 20-24 horas
- **Prioridad 2 (Alta):** 12-16 horas
- **Prioridad 3 (Media):** 6-8 horas
- **Total:** 38-48 horas (~1 semana de desarrollo)

### Siguiente Paso Recomendado
1. **Implementar Prioridad 1.1 a 1.5** (carga configuración, queries, guardado, cálculos)
2. **Crear casos de prueba** comparando resultados VB6 vs .NET con datos reales
3. **Validar con usuario experto** que los cálculos tributarios sean correctos
4. **Implementar Prioridad 2** (impresión, navegación)
5. **Realizar pruebas de regresión** con múltiples empresas/años

---

**Generado por:** Claude Opus 4.5 (Auditoría de Gaps VB6 vs .NET 9)
**Fecha:** 2025-12-06
