using Microsoft.AspNetCore.Mvc;
using App.Helpers;

namespace App.Features.AjustesExtraContablesCaja;


public class AjustesExtraContablesCajaController(
    ILogger<AjustesExtraContablesCajaController> logger) : Controller
{
    public IActionResult Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Ajustes Extra Contables Caja";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        logger.LogInformation("AjustesExtraContablesCaja accessed for EmpresaId: {EmpresaId}, Ano: {Ano}",
            SessionHelper.EmpresaId, SessionHelper.Ano);

        return View();
    }
}
