namespace App.Features.AsistentePpm;

/// <summary>
/// ViewModel para la vista Index del Asistente de Reajuste PPM
/// </summary>
public class AsistentePpmIndexViewModel
{
    /// <summary>
    /// ID de la empresa seleccionada en sesión
    /// </summary>
    public int EmpresaId { get; set; }

    /// <summary>
    /// Año seleccionado en sesión
    /// </summary>
    public short Ano { get; set; }
}
