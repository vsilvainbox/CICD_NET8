﻿namespace App.Features.AsistentePpm;

/// <summary>
/// Servicio para gestionar el Asistente de Reajuste de PPM (Pagos Provisionales Mensuales)
/// Calcula montos actualizados con factores IPC y diferencia entre PPM Obligatorio y Voluntario
/// </summary>
public interface IAsistentePpmService
{
    /// <summary>
    /// Obtiene los datos de PPM Obligatorio con actualización por factores IPC
    /// Incluye la lista de registros, totales y reajuste calculado
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año fiscal</param>
    /// <returns>DTO con registros PPM obligatorios, totales y reajuste</returns>
    Task<AsistentePpmObligatorioDto> GetPpmObligatorioAsync(int empresaId, short ano);

    /// <summary>
    /// Obtiene los datos de PPM Voluntario con actualización por factores IPC
    /// Incluye la lista de registros, totales y reajuste calculado
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año fiscal</param>
    /// <returns>DTO con registros PPM voluntarios, totales y reajuste</returns>
    Task<AsistentePpmVoluntarioDto> GetPpmVoluntarioAsync(int empresaId, short ano);

    /// <summary>
    /// Calcula el total de reajuste a traspasar sumando el reajuste de PPM obligatorio y voluntario
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año fiscal</param>
    /// <returns>DTO con reajustes individuales y total a traspasar</returns>
    Task<AsistentePpmTotalTraspasoDto> GetTotalTraspasoAsync(int empresaId, short ano);

    /// <summary>
    /// Obtiene la configuración actual de AsistentePpm
    /// Incluye flag de exclusión 20/Enero, cuentas configuradas y si existen registros excluidos
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año fiscal</param>
    /// <returns>DTO con configuración actual</returns>
    Task<AsistentePpmConfiguracionDto> GetConfiguracionAsync(int empresaId, short ano);

    /// <summary>
    /// Actualiza la configuración de inclusión/exclusión de PPM pagados hasta 20/Enero
    /// Modifica el registro ParamEmpresa con Tipo='PPM'
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año fiscal</param>
    /// <param name="excluirHasta20Enero">True para excluir PPM hasta 20/Enero, False para incluir todos</param>
    /// <exception cref="BusinessException">Si no se puede actualizar la configuración</exception>
    Task ActualizarConfiguracionAsync(int empresaId, short ano, bool excluirHasta20Enero);

    /// <summary>
    /// Exporta a Excel el reporte completo de reajuste PPM (obligatorio + voluntario + total traspaso)
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año fiscal</param>
    /// <returns>Bytes del archivo Excel generado</returns>
    Task<byte[]> ExportarExcelAsync(int empresaId, short ano);
}
