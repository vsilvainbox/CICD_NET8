using System.ComponentModel.DataAnnotations;

namespace App.Features.AsistentePpm;

/// <summary>
/// DTO para un registro individual de pago PPM con su monto actualizado
/// </summary>
public class AsistentePpmRegistroDto
{
    /// <summary>
    /// Fecha del pago PPM
    /// </summary>
    public DateTime FechaPago { get; set; }

    /// <summary>
    /// Monto original pagado
    /// </summary>
    public decimal Monto { get; set; }

    /// <summary>
    /// Monto actualizado con factor de actualizaci�n IPC
    /// </summary>
    public decimal MontoActualizado { get; set; }
}

/// <summary>
/// DTO para datos de PPM Obligatorio con totales y reajuste
/// </summary>
public class AsistentePpmObligatorioDto
{
    /// <summary>
    /// Lista de pagos PPM obligatorios
    /// </summary>
    public List<AsistentePpmRegistroDto> Registros { get; set; } = new();

    /// <summary>
    /// Suma de montos originales
    /// </summary>
    public decimal TotalMonto { get; set; }

    /// <summary>
    /// Suma de montos actualizados
    /// </summary>
    public decimal TotalMontoActualizado { get; set; }

    /// <summary>
    /// Reajuste calculado (TotalMontoActualizado - TotalMonto)
    /// </summary>
    public decimal Reajuste { get; set; }

    /// <summary>
    /// Indica si debe mostrarse el bot�n de configuraci�n (cuando hay registros excluidos antes 20/Enero)
    /// </summary>
    public bool MostrarBotonConfiguracion { get; set; }
}

/// <summary>
/// DTO para datos de PPM Voluntario con totales y reajuste
/// </summary>
public class AsistentePpmVoluntarioDto
{
    /// <summary>
    /// Lista de pagos PPM voluntarios
    /// </summary>
    public List<AsistentePpmRegistroDto> Registros { get; set; } = new();

    /// <summary>
    /// Suma de montos originales
    /// </summary>
    public decimal TotalMonto { get; set; }

    /// <summary>
    /// Suma de montos actualizados
    /// </summary>
    public decimal TotalMontoActualizado { get; set; }

    /// <summary>
    /// Reajuste calculado (TotalMontoActualizado - TotalMonto)
    /// </summary>
    public decimal Reajuste { get; set; }
}

/// <summary>
/// DTO para el total de reajuste a traspasar (suma de ambos tipos de PPM)
/// </summary>
public class AsistentePpmTotalTraspasoDto
{
    /// <summary>
    /// Reajuste de PPM Obligatorio
    /// </summary>
    public decimal ReajusteObligatorio { get; set; }

    /// <summary>
    /// Reajuste de PPM Voluntario
    /// </summary>
    public decimal ReajusteVoluntario { get; set; }

    /// <summary>
    /// Total de reajuste a traspasar (ReajusteObligatorio + ReajusteVoluntario)
    /// </summary>
    public decimal TotalTraspaso { get; set; }
}

/// <summary>
/// DTO para configuraci�n de AsistentePpm
/// </summary>
public class AsistentePpmConfiguracionDto
{
    /// <summary>
    /// Si debe excluir PPM pagados hasta 20/Enero en los c�lculos
    /// </summary>
    public bool ExcluirHasta20Enero { get; set; }

    /// <summary>
    /// ID de la cuenta contable configurada para PPM Obligatorio
    /// </summary>
    public int? IdCuentaObligatoria { get; set; }

    /// <summary>
    /// ID de la cuenta contable configurada para PPM Voluntario
    /// </summary>
    public int? IdCuentaVoluntaria { get; set; }

    /// <summary>
    /// Indica si existen registros excluidos por la configuraci�n de fecha 20/Enero
    /// </summary>
    public bool ExistenRegistrosExcluidos { get; set; }
}

/// <summary>
/// DTO para actualizar la configuraci�n de inclusi�n/exclusi�n de PPM hasta 20/Enero
/// </summary>
public class ActualizarConfiguracionPpmDto
{
    [Required(ErrorMessage = "El ID de empresa es requerido")]
    public int EmpresaId { get; set; }

    [Required(ErrorMessage = "El a�o es requerido")]
    [Range(2000, 2100, ErrorMessage = "El a�o debe estar entre 2000 y 2100")]
    public short Ano { get; set; }

    [Required(ErrorMessage = "Debe indicar si excluir hasta 20/Enero")]
    public bool ExcluirHasta20Enero { get; set; }
}
