using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using App.Helpers;

namespace App.Features.AsistentePpm;

/// <summary>
/// Controller MVC para vista de Asistente de Reajuste PPM
/// </summary>
[Authorize]
public class AsistentePpmController(ILogger<AsistentePpmController> logger) : Controller
{
    /// <summary>
    /// Muestra la vista principal del Asistente de Reajuste PPM
    /// </summary>
    /// <returns>Vista Index con empresaId y año desde sesión</returns>
    public IActionResult Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder al Asistente PPM";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        var viewModel = new AsistentePpmIndexViewModel
        {
            EmpresaId = SessionHelper.EmpresaId,
            Ano = SessionHelper.Ano
        };

        return View(viewModel);
    }
}
