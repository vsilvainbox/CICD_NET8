# Gaps Identificados: AsistentePpm

## Resumen Ejecutivo
| Métrica | Valor |
|---------|-------|
| **Feature** | AsistentePpm |
| **Paridad Estimada** | 89.5% |
| **Gaps Críticos** | 1 |
| **Gaps Altos** | 2 |
| **Gaps Medios** | 3 |
| **Gaps Bajos** | 2 |

## Análisis de Paridad

### Aspectos Cubiertos ✅
1. **Dos grillas PPM** - Obligatorio y Voluntario
2. **Cálculo de totales** - Suma de montos originales y actualizados
3. **Cálculo de reajustes** - Diferencia entre actualizado y original
4. **Total traspaso** - Suma de reajustes obligatorio + voluntario
5. **Exportación Excel** - Copiar al portapapeles
6. **Vista previa/Impresión** - Funcionalidad de reporte
7. **Herramientas auxiliares** - Calculadora, calendario, conversor

### Aspectos No Cubiertos ❌

Falta verificar:
- Query con factor de actualización anual (FactorActAnual)
- Configuración PPM 20/Enero
- Join complejo Comprobante + MovComprobante + ParamEmpresa

---

## Gaps Detallados

### 🔴 CRÍTICA PRIORIDAD

#### GAP-001: Factor de Actualización Anual IPC
- **Aspecto:** Actualización de montos por IPC
- **VB6:** 
```sql
SELECT Factor FROM FactorActAnual
WHERE Ano = Year(Fecha)
AND MesCol = 12
AND MesRow = Month(Fecha)
```
- **Estado .NET:** Verificar si existe lógica de actualización por factor IPC
- **Impacto:** Alto - Cálculo tributario oficial SII
- **Recomendación:** Implementar tabla FactorActAnual y lógica de actualización

### 🟠 ALTA PRIORIDAD

#### GAP-002: Query PPM Obligatorio complejo
- **Aspecto:** Join de 3 tablas para PPM Obligatorio
- **VB6:**
```sql
SELECT Comprobante.FECHA, MovComprobante.DEBE 
FROM (MovComprobante INNER JOIN Comprobante ON MovComprobante.IdComp = Comprobante.IdComp)
  INNER JOIN ParamEmpresa ON MovComprobante.IdEmpresa = ParamEmpresa.IdEmpresa 
WHERE MovComprobante.IdEmpresa = {gEmpresa.id}
  AND ParamEmpresa.tipo = 'CTAPPMOBLI'
  AND MovComprobante.idCuenta = Convert(int, ParamEmpresa.valor)
  AND COMPROBANTE.TIPO = {TC_EGRESO}
  AND COMPROBANTE.ESTADO = {EC_APROBADO}
```
- **Estado .NET:** Verificar implementación del query complejo
- **Impacto:** Alto - Datos base del reporte

#### GAP-003: Query PPM Voluntario similar
- **Aspecto:** Query para PPM Voluntario con CTAPPMVOLU
- **VB6:** Similar al obligatorio pero con `ParamEmpresa.tipo = 'CTAPPMVOLU'`
- **Estado .NET:** Verificar implementación
- **Impacto:** Alto - Completitud del reporte

### 🟡 MEDIA PRIORIDAD

#### GAP-004: Configuración PPM 20/Enero
- **Aspecto:** Excluir PPM pagados antes del 20 de enero
- **VB6:**
```sql
SELECT Codigo, Valor FROM ParamEmpresa 
WHERE Tipo='PPM' AND IdEmpresa = gEmpresa.id AND Ano = gEmpresa.Ano
```
- **Estado .NET:** Verificar configuración de exclusión
- **Impacto:** Medio - Regla tributaria específica

#### GAP-005: Grillas totales separadas
- **Aspecto:** GridTotOblig, GridTotVolunt, GridTotTraspaso
- **VB6:** 3 grillas independientes para totales
- **Estado .NET:** Posiblemente simplificado en una tabla
- **Impacto:** Bajo - Presentación visual

#### GAP-006: Selección múltiple para sumar
- **Aspecto:** Bt_Sum[0] y Bt_Sum[1] para sumar selección
- **VB6:** Permite seleccionar filas y sumar manualmente
- **Estado .NET:** Verificar si existe esta funcionalidad
- **Impacto:** Bajo - Utilidad adicional

### 🟢 BAJA PRIORIDAD

#### GAP-007: Indicador bt_Help para PPM excluidos
- **Aspecto:** Botón visible cuando hay PPM excluidos por fecha
- **VB6:** `bt_Help.Visible = True` si hay PPM < 20/Enero
- **Estado .NET:** Puede mostrarse como nota informativa
- **Impacto:** Muy bajo - Solo indicador visual

#### GAP-008: Orientación de impresión
- **Aspecto:** `lOrientacion = ORIENT_VER`
- **VB6:** Configuración de impresión vertical
- **Estado .NET:** Manejado por CSS @media print
- **Impacto:** Muy bajo

---

## Queries Clave a Verificar

1. **FactorActAnual** - Tabla de factores IPC mensuales
2. **ParamEmpresa.CTAPPMOBLI** - Cuenta PPM Obligatorio
3. **ParamEmpresa.CTAPPMVOLU** - Cuenta PPM Voluntario
4. **ParamEmpresa.PPM** - Configuración de exclusión 20/Enero

## Recomendaciones

1. **Prioridad Crítica:** Verificar tabla FactorActAnual y lógica de actualización IPC
2. **Prioridad Alta:** Validar queries de PPM Obligatorio y Voluntario
3. **Prioridad Media:** Implementar configuración de exclusión 20/Enero

## Conclusión

Feature de complejidad media-alta con lógica tributaria específica SII. El gap más crítico es la actualización por factor IPC que es fundamental para el cálculo correcto del reajuste de PPM.
