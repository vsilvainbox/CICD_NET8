using Microsoft.EntityFrameworkCore;
using App.Data;
using App.Exceptions;
using ComprobanteEntity = App.Data.Comprobante;

namespace App.Features.AuditoriaGeneral;

public class AuditoriaGeneralService(LpContabContext context, ILogger<AuditoriaGeneralService> logger) : IAuditoriaGeneralService
{
    private const int O_NEW = 1;
    private const int O_EDIT = 2;
    private const int O_DELETE = 3;
    private const int O_IMPORT = 4;
    private const int EC_PENDIENTE = 1;
    private const int EC_APROBADO = 2;
    private const int EC_ANULADO = 3;
    private const int EC_ELIMINADO = 4;
    private const int TAJUSTE_FINANCIERO = 1;
    private const int TAJUSTE_TRIBUTARIO = 2;
    private const int TAJUSTE_AMBOS = 3;

    private static readonly Dictionary<int, string> TiposComprobante = new()
    {
        { 1, "Ingreso" }, { 2, "Egreso" }, { 3, "Traspaso" },
        { 4, "Apertura" }, { 5, "Ajuste" }, { 6, "Saldo Inicial" }
    };

    private static readonly Dictionary<int, string> EstadosComprobante = new()
    {
        { 1, "Pendiente" }, { 2, "Aprobado" }, { 3, "Anulado" }, { 4, "Eliminado" }
    };

    private static readonly Dictionary<int, string> Operaciones = new()
    {
        { 1, "Crear" }, { 2, "Modificar" }, { 3, "Eliminar" }, { 4, "Importar" }
    };

    private static readonly Dictionary<int, string> TiposAjuste = new()
    {
        { 1, "Financiero" }, { 2, "Tributario" }, { 3, "Ambos" }
    };

    public async Task<List<AuditoriaDto>> GetAllAsync(int empresaId, short ano, AuditoriaFiltrosDto filtros)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");
        if (ano <= 0)
            throw new BusinessException("Debe seleccionar un año");

        ValidateFilters(filtros, ano);

        logger.LogInformation("Getting auditoria for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        var query = from log in context.LogComprobantes
                join usuario in context.Usuarios on log.IdUsuario equals usuario.IdUsuario into uj
                from usuario in uj.DefaultIfEmpty()
                join comp in context.Comprobante on log.IdComp equals comp.IdComp into cj
                from comp in cj.DefaultIfEmpty()
                where log.IdEmpresa == empresaId && log.Ano == ano
                select new { log, usuario, comp };

            if (filtros.NumeroComp.HasValue && filtros.NumeroComp.Value > 0)
                query = query.Where(x => x.comp != null && x.comp.Correlativo == filtros.NumeroComp.Value);
            if (filtros.TipoComp.HasValue && filtros.TipoComp.Value > 0)
                query = query.Where(x => x.log.TipoComp == filtros.TipoComp.Value);
            if (filtros.TipoAjuste.HasValue)
            {
                if (filtros.TipoAjuste.Value == TAJUSTE_FINANCIERO)
                    query = query.Where(x => x.log.TipoAjusteComp == null || x.log.TipoAjusteComp == TAJUSTE_FINANCIERO || x.log.TipoAjusteComp == TAJUSTE_AMBOS);
                else
                    query = query.Where(x => x.log.TipoAjusteComp == null || x.log.TipoAjusteComp == filtros.TipoAjuste.Value);
            }
            if (filtros.FechaOperDesde.HasValue && filtros.FechaOperHasta.HasValue)
                query = query.Where(x => x.log.Fecha >= filtros.FechaOperDesde.Value && x.log.Fecha <= filtros.FechaOperHasta.Value);
            if (filtros.FechaCompDesde.HasValue && filtros.FechaCompHasta.HasValue)
                query = query.Where(x => x.comp != null && x.comp.Fecha >= filtros.FechaCompDesde.Value && x.comp.Fecha <= filtros.FechaCompHasta.Value);
            if (filtros.IdOper.HasValue && filtros.IdOper.Value > 0)
                query = query.Where(x => x.log.IdOper == filtros.IdOper.Value);
            if (filtros.IdUsuario.HasValue && filtros.IdUsuario.Value > 0)
                query = query.Where(x => x.log.IdUsuario == filtros.IdUsuario.Value);

        var results = await query.OrderByDescending(x => x.log.Fecha).ToListAsync();
        return results.Select(r => MapToDto(r.log, r.usuario, r.comp)).ToList();
    }

    private AuditoriaDto MapToDto(LogComprobantes log, Usuarios usuario, ComprobanteEntity comp)
    {
        var dto = new AuditoriaDto
        {
            IdLog = log.IdLog,
            IdComp = log.IdComp ?? 0,
            IdUsuario = log.IdUsuario ?? 0,
            Usuario = usuario?.Usuario ?? string.Empty,
            IdOper = log.IdOper ?? 0,
            Oper = Operaciones.GetValueOrDefault(log.IdOper ?? 0, string.Empty),
            FechaOperOA = log.Fecha ?? 0.0
        };

        if (log.Fecha.HasValue && log.Fecha.Value > 0)
        {
            var fecha = DateTime.FromOADate(log.Fecha.Value);
            dto.FechaOper = fecha.ToString("dd/MM/yyyy HH:mm");
        }

        if (comp == null || comp.Correlativo == 0)
        {
            dto.CorrComp = log.CorrComp ?? 0;
            dto.CorrCompCurrent = 0;
            dto.IdTipoComp = log.TipoComp ?? 0;
            dto.TipoComp = TiposComprobante.GetValueOrDefault(log.TipoComp ?? 0, string.Empty);
            dto.IdEstadoComp = EC_ELIMINADO;
            dto.EstadoComp = "Eliminado";
            dto.IdTipoAjuste = log.TipoAjusteComp ?? TAJUSTE_FINANCIERO;
            dto.TAjuste = GetTipoAjusteAbrev(log.TipoAjusteComp ?? TAJUSTE_FINANCIERO);
            dto.FechaCompInt = log.FechaComp ?? 0;
            dto.FechaComp = FormatFechaInt(log.FechaComp ?? 0);
            dto.EsEliminado = true;
        }
        else
        {
            dto.CorrComp = comp.Correlativo ?? 0;
            dto.CorrCompCurrent = comp.Correlativo ?? 0;
            dto.IdTipoComp = comp.Tipo ?? 0;
            dto.TipoComp = TiposComprobante.GetValueOrDefault(comp.Tipo ?? 0, string.Empty);
            dto.IdEstadoComp = comp.Estado ?? EC_PENDIENTE;
            dto.EstadoComp = EstadosComprobante.GetValueOrDefault(comp.Estado ?? EC_PENDIENTE, "Pendiente");
            dto.IdTipoAjuste = comp.TipoAjuste ?? TAJUSTE_FINANCIERO;
            dto.TAjuste = GetTipoAjusteAbrev(comp.TipoAjuste ?? TAJUSTE_FINANCIERO);
            dto.FechaCompInt = comp.Fecha ?? 0;
            dto.FechaComp = FormatFechaInt(comp.Fecha ?? 0);
            dto.EsEliminado = false;
        }

        if (log.Estado == EC_ELIMINADO)
        {
            dto.IdEstadoOper = EC_ELIMINADO;
            dto.EstadoOper = "Eliminado";
        }
        else
        {
            dto.IdEstadoOper = log.Estado ?? EC_PENDIENTE;
            dto.EstadoOper = EstadosComprobante.GetValueOrDefault(log.Estado ?? EC_PENDIENTE, "Pendiente");
        }

        return dto;
    }

    private string GetTipoAjusteAbrev(int tipoAjuste)
    {
        var texto = TiposAjuste.GetValueOrDefault(tipoAjuste, "Financiero");
        return texto.Substring(0, 1);
    }

    private string FormatFechaInt(int fecha)
    {
        if (fecha == 0) return string.Empty;

        var fechaStr = fecha.ToString();
        if (fechaStr.Length == 8)
        {
            var year = int.Parse(fechaStr.Substring(0, 4));
            var month = int.Parse(fechaStr.Substring(4, 2));
            var day = int.Parse(fechaStr.Substring(6, 2));
            return new DateTime(year, month, day).ToString("dd/MM/yyyy");
        }

        return string.Empty;
    }

    public void ValidateFilters(AuditoriaFiltrosDto filtros, int anoEmpresa)
    {
        if ((filtros.FechaOperDesde.HasValue && !filtros.FechaOperHasta.HasValue) || (!filtros.FechaOperDesde.HasValue && filtros.FechaOperHasta.HasValue))
            throw new BusinessException("Rango de fechas de operacion invalido.");
        if (filtros.FechaOperDesde.HasValue && filtros.FechaOperHasta.HasValue && filtros.FechaOperDesde.Value > filtros.FechaOperHasta.Value)
            throw new BusinessException("Rango de fechas de operacion invalido.");
        if (filtros.FechaOperDesde.HasValue)
        {
            var anoDesde = int.Parse(filtros.FechaOperDesde.Value.ToString().Substring(0, 4));
            if (anoDesde != anoEmpresa)
                throw new BusinessException("Solo es posible visualizar ano actual.");
        }
        if (filtros.FechaOperHasta.HasValue)
        {
            var anoHasta = int.Parse(filtros.FechaOperHasta.Value.ToString().Substring(0, 4));
            if (anoHasta != anoEmpresa)
                throw new BusinessException("Solo es posible visualizar ano actual.");
        }
        if ((filtros.FechaCompDesde.HasValue && !filtros.FechaCompHasta.HasValue) || (!filtros.FechaCompDesde.HasValue && filtros.FechaCompHasta.HasValue))
            throw new BusinessException("Rango de fechas de comprobante invalido.");
        if (filtros.FechaCompDesde.HasValue && filtros.FechaCompHasta.HasValue && filtros.FechaCompDesde.Value > filtros.FechaCompHasta.Value)
            throw new BusinessException("Rango de fechas de comprobante invalido.");
        if (filtros.FechaCompDesde.HasValue)
        {
            var anoDesde = int.Parse(filtros.FechaCompDesde.Value.ToString().Substring(0, 4));
            if (anoDesde != anoEmpresa)
                throw new BusinessException("Solo es posible visualizar ano actual.");
        }
        if (filtros.FechaCompHasta.HasValue)
        {
            var anoHasta = int.Parse(filtros.FechaCompHasta.Value.ToString().Substring(0, 4));
            if (anoHasta != anoEmpresa)
                throw new BusinessException("Solo es posible visualizar ano actual.");
        }
    }

    public async Task<List<ComboItemDto>> GetTiposComprobanteAsync()
    {
        var items = new List<ComboItemDto> { new ComboItemDto { Value = -1, Text = "(todos)" } };
        foreach (var tipo in TiposComprobante)
            items.Add(new ComboItemDto { Value = tipo.Key, Text = tipo.Value });
        return await Task.FromResult(items);
    }

    public async Task<List<ComboItemDto>> GetTiposAjusteAsync()
    {
        var items = new List<ComboItemDto>
        {
            new ComboItemDto { Value = TAJUSTE_FINANCIERO, Text = "Financiero" },
            new ComboItemDto { Value = TAJUSTE_TRIBUTARIO, Text = "Tributario" }
        };
        return await Task.FromResult(items);
    }

    public async Task<List<ComboItemDto>> GetOperacionesAsync()
    {
        var items = new List<ComboItemDto>
        {
            new ComboItemDto { Value = -1, Text = "(todas)" },
            new ComboItemDto { Value = O_NEW, Text = "Crear" },
            new ComboItemDto { Value = O_EDIT, Text = "Modificar" },
            new ComboItemDto { Value = O_DELETE, Text = "Eliminar" },
            new ComboItemDto { Value = O_IMPORT, Text = "Importar" }
        };
        return await Task.FromResult(items);
    }

    public async Task<List<ComboItemDto>> GetUsuariosAsync()
    {
        var items = new List<ComboItemDto> { new ComboItemDto { Value = -1, Text = "(todos)" } };
        var usuarios = await context.Usuarios.Where(u => u.Activo == true).OrderBy(u => u.Usuario)
            .Select(u => new ComboItemDto { Value = u.IdUsuario, Text = u.Usuario ?? string.Empty }).ToListAsync();
        items.AddRange(usuarios);
        return items;
    }

    public async Task CanDeleteImportedAsync(int idComp, int empresaId, short ano, bool confirmarAntiguo = false)
    {
        if (idComp <= 0)
            throw new BusinessException("Debe proporcionar un identificador de comprobante válido");
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");
        if (ano <= 0)
            throw new BusinessException("Debe seleccionar un año");

        var comp = await context.Comprobante.FirstOrDefaultAsync(c => c.IdComp == idComp && c.IdEmpresa == empresaId && c.Ano == ano);
        if (comp == null)
            throw new BusinessException("Comprobante no encontrado.");
        if (comp.Estado == EC_ELIMINADO)
            throw new BusinessException("Este comprobante ya ha sido eliminado.");
        var esImportado = await context.LogComprobantes.AnyAsync(l => l.IdComp == idComp && l.IdEmpresa == empresaId && l.Ano == ano && l.IdOper == O_IMPORT);
        if (!esImportado)
            throw new BusinessException("Esta operacion es solo para comprobantes importados.");

        if (!confirmarAntiguo)
        {
            var logImport = await context.LogComprobantes.Where(l => l.IdComp == idComp && l.IdEmpresa == empresaId && l.Ano == ano && l.IdOper == O_IMPORT)
                .OrderByDescending(l => l.Fecha).FirstOrDefaultAsync();
            if (logImport?.Fecha != null)
            {
                var fechaImport = DateTime.FromOADate(logImport.Fecha.Value);
                if (fechaImport < DateTime.Now.AddMonths(-1))
                    throw new ConfirmationRequiredException(
                        "COMPROBANTE_ANTIGUO",
                        "Este comprobante fue importado hace mas de un mes atras. Esta seguro que desea eliminarlo?");
            }
        }
    }

    public async Task DeleteImportedAsync(int idComp, int empresaId, short ano, int idUsuario, bool confirmarAntiguo = false)
    {
        if (idComp <= 0)
            throw new BusinessException("Debe proporcionar un identificador de comprobante válido");
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");
        if (ano <= 0)
            throw new BusinessException("Debe seleccionar un año");
        if (idUsuario <= 0)
            throw new BusinessException("Debe proporcionar un usuario válido");

        // Valida y lanza ConfirmationRequiredException si es necesario
        await CanDeleteImportedAsync(idComp, empresaId, ano, confirmarAntiguo);

        var comp = await context.Comprobante.FirstOrDefaultAsync(c => c.IdComp == idComp && c.IdEmpresa == empresaId && c.Ano == ano);
        if (comp == null)
            throw new BusinessException("Comprobante no encontrado.");

        var corrComp = comp.Correlativo ?? 0;
        var fechaComp = comp.Fecha ?? 0;
        int tipoComp = comp.Tipo ?? 0;
        int tipoAjuste = comp.TipoAjuste ?? TAJUSTE_FINANCIERO;
        comp.Estado = (byte?)EC_ELIMINADO;

        var logEntry = new LogComprobantes
        {
            IdEmpresa = empresaId,
            Ano = ano,
            IdComp = idComp,
            IdUsuario = idUsuario,
            Fecha = DateTime.Now.ToOADate(),
            IdOper = (short?)O_DELETE,
            Estado = (short?)EC_ELIMINADO,
            CorrComp = corrComp,
            FechaComp = fechaComp,
            TipoComp = (short?)tipoComp,
            EstadoComp = (short?)EC_ELIMINADO,
            TipoAjusteComp = (short?)tipoAjuste
        };
        context.LogComprobantes.Add(logEntry);
        await context.SaveChangesAsync();
    }

    public async Task<byte[]> ExportToExcelAsync(int empresaId, short ano, AuditoriaFiltrosDto? filtros)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");
        if (ano <= 0)
            throw new BusinessException("Debe seleccionar un año");

        return await Task.FromResult(Array.Empty<byte>());
    }
}