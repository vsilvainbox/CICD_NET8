# Auditoría de Migración: CompraVenta (Libro de Compras y Ventas)

## Información General

| Campo | Valor |
|-------|-------|
| **Feature** | CompraVenta |
| **Archivo VB6** | `FrmCompraVenta.frm` (10,066 líneas) |
| **Carpeta .NET** | `Features/CompraVenta/` |
| **Fecha de Auditoría** | 2025-01-09 |
| **Importancia** | 🟡 MEDIA |
| **Estado General** | ⚠️ Migración Parcial |

---

## Resumen Ejecutivo

La migración del módulo CompraVenta presenta una **implementación parcial** con funcionalidades críticas pendientes. El sistema VB6 original contiene lógica de negocio altamente especializada para la gestión de libros de compras y ventas según normativa tributaria chilena (IVA, SII), que no ha sido completamente trasladada a .NET.

### Estadísticas de Migración

| Categoría | VB6 | .NET | Cobertura |
|-----------|-----|------|-----------|
| Líneas de código | 10,066 | ~1,500 | ~15% |
| Columnas de grilla | 46+ | ~12 | ~26% |
| Operaciones principales | 15+ | 6 | ~40% |
| Tipos de documento | 20+ | Dinámico | ✅ |
| Filtros disponibles | 10+ | 5 | ~50% |

---

## 1. ESTRUCTURA DE ARCHIVOS

### 1.1 Inventario de Archivos

| Archivo | Propósito | Líneas | Estado |
|---------|-----------|--------|--------|
| `CompraVentaController.cs` | Controlador MVC | 151 | ✅ Existe |
| `CompraVentaApiController.cs` | API REST | 104 | ✅ Existe |
| `CompraVentaService.cs` | Lógica de negocio | 472 | ⚠️ Parcial |
| `CompraVentaDto.cs` | DTOs | 118 | ✅ Existe |
| `CompraVentaViewModels.cs` | ViewModels | 37 | ✅ Existe |
| `Views/Index.cshtml` | Vista principal | 636 | ⚠️ Parcial |

### 1.2 Archivos Faltantes

| Archivo Sugerido | Propósito | Prioridad |
|------------------|-----------|-----------|
| `CompraVentaCentralizarService.cs` | Lógica de centralización contable | 🔴 ALTA |
| `CompraVentaImportService.cs` | Importación desde archivos | 🟡 MEDIA |
| `CompraVentaPrintService.cs` | Generación de informes/impresión | 🟡 MEDIA |
| `CompraVentaValidationService.cs` | Validaciones de negocio | 🔴 ALTA |
| `Views/ResumenIVA.cshtml` | Vista de resumen IVA | 🟡 MEDIA |
| `Views/Detalle.cshtml` | Vista de detalle documento | 🟡 MEDIA |

---

## 2. CONTROLES Y COMPONENTES UI

### 2.1 Mapeo de Controles VB6 → .NET

| Control VB6 | Propósito | Equivalente .NET | Estado |
|-------------|-----------|------------------|--------|
| `Grid` (MSFlexGrid) | Grilla principal documentos | `<table>` con JS | ⚠️ Parcial |
| `GridTot` | Fila de totales | Cálculo JS `calcularTotales()` | ✅ Migrado |
| `Cb_Mes` | Combo mes | `<select id="mesSelect">` | ✅ Migrado |
| `Cb_Ano` | Combo año | `<select id="anoSelect">` | ✅ Migrado |
| `Cb_TipoDoc` | Filtro tipo documento | No visible | ❌ Falta |
| `Cb_Estado` | Filtro estado documento | No visible | ❌ Falta |
| `Cb_Entidad` | Filtro clasificación entidad | No visible | ❌ Falta |
| `Cb_Sucursal` | Filtro sucursal | No visible | ❌ Falta |
| `Cb_DTE` | Filtro DTE | No visible | ❌ Falta |
| `Tx_NumDoc` | Búsqueda por número | Posible en búsqueda general | ⚠️ Parcial |
| `Tx_Rut` | Búsqueda por RUT | No visible | ❌ Falta |
| `Tx_Descrip` | Búsqueda por descripción | No visible | ❌ Falta |
| `Bt_Centralizar` | Botón centralizar | `btnCentralizar` | ⚠️ No funcional |
| `Bt_AnulaDoc` | Anular documento | No visible | ❌ Falta |
| `Bt_DupDoc` | Duplicar documento | No visible | ❌ Falta |
| `Bt_DelAll` | Eliminar todos | No visible | ❌ Falta |
| `Bt_ActivoFijo` | Gestión activo fijo | No visible | ❌ Falta |
| `Bt_DocCuotas` | Cuotas documento | No visible | ❌ Falta |
| `Bt_ResumenIVA` | Resumen IVA | No visible | ❌ Falta |
| `Ch_ViewDetOtrosImp` | Ver otros impuestos | No visible | ❌ Falta |
| `Ch_ViewDocHasta` | Ver doc hasta | No visible | ❌ Falta |
| `Ch_ViewPropIVA` | Ver proporcionalidad IVA | No visible | ❌ Falta |
| `Ch_RepetirGlosa` | Repetir glosa | No visible | ❌ Falta |
| `Bt_Print` | Imprimir libro | `btnImprimir` → `window.print()` | ⚠️ Básico |
| `Bt_Preview` | Vista previa | No existe | ❌ Falta |
| `Bt_Importar` | Importar archivo | `btnImportar` (no funcional) | ⚠️ No implementado |
| `Bt_Exportar` | Exportar Excel | `btnExportar` | ✅ Migrado |

### 2.2 Columnas de Grilla

#### VB6 - Columnas Definidas (46+)

```
C_IDDOC=0, C_NUMLIN=1, C_CORRINTERNO=2, C_CHECK=3, C_TIPODOC=4, C_DTE=5,
C_GIRO=6, C_NUMFISCIMPR=7, C_NUMINFORMEZ=8, C_NUMDOC=9, C_NUMDOCHASTA=10,
C_CANTBOLETAS=11, C_PROPIVA=12, C_FECHA=13, C_RUT=14, C_NOMBRE=15,
C_SUCURSAL=16, C_EXENTO=17, C_AFECTO=18, C_IVA=19, C_OTROIMP=20,
C_TOTAL=21, C_FECHAEMIORI=22, C_FECHAVENC=23, C_EX_CODCUENTA=24,
C_EX_CUENTA=25, C_AF_CODCUENTA=26, C_AF_CUENTA=27, C_TOT_CODCUENTA=28,
C_TOT_CUENTA=29, C_DETACTFIJO=30, C_DETALLE=31, C_DOCASOC=32,
C_DESCRIP=33, C_ESTADO=34, C_USUARIO=35, C_VENTASACUM=36...
+ Columnas de otros impuestos (C_INIDETOTROIMP a C_ENDDETOTROIMP)
+ Columnas ocultas de IDs
```

#### .NET - Columnas Visibles (~12)

```html
Día, Tipo Doc, DTE, Número, RUT, Nombre, Exento, Neto, IVA, Total,
Estado, Descripción
```

#### GAP: Columnas Faltantes

| Columna VB6 | Propósito | Impacto |
|-------------|-----------|---------|
| `C_CORRINTERNO` | Correlativo interno | Ordenamiento |
| `C_GIRO` | Giro actividad | Tributario |
| `C_NUMFISCIMPR` | Número fiscal impresora | Máquinas registradoras |
| `C_NUMINFORMEZ` | Número informe Z | Máquinas registradoras |
| `C_NUMDOCHASTA` | Rango documentos | Boletas |
| `C_CANTBOLETAS` | Cantidad boletas | Boletas |
| `C_PROPIVA` | Proporcionalidad IVA | Tributario crítico |
| `C_SUCURSAL` | Sucursal | Multi-sucursal |
| `C_FECHAEMIORI` | Fecha emisión original | Tributario |
| `C_FECHAVENC` | Fecha vencimiento | Cobranza |
| `C_EX/AF/TOT_CODCUENTA` | Cuentas contables | Centralización |
| `C_DETACTFIJO` | Indicador activo fijo | Activos |
| `C_DOCASOC` | Documento asociado | Notas crédito/débito |
| `C_VENTASACUM` | Ventas acumuladas | Informes Z |
| `C_IDPROPIVA` | ID proporcionalidad | Cálculos IVA |

---

## 3. OPERACIONES CRUD

### 3.1 Estado de Operaciones

| Operación | VB6 | .NET | Estado | Notas |
|-----------|-----|------|--------|-------|
| **Listar** | `LoadGrid()` | `GetAllAsync()` | ⚠️ Parcial | Faltan filtros avanzados |
| **Crear** | Inline en grilla | Redirect a GestionDocumentos | ✅ Delegado | |
| **Editar** | `SaveGrid()` | `UpdateAsync()` | ⚠️ Parcial | Falta edición inline |
| **Eliminar** | `Bt_Del_Click()` | `DeleteAsync()` | ✅ Migrado | |
| **Centralizar** | `Bt_Centralizar_Click()` | Retorna 501 | ❌ NO IMPLEMENTADO | **CRÍTICO** |
| **Anular** | `Bt_AnulaDoc_Click()` | No existe | ❌ Falta | |
| **Duplicar** | `Bt_DupDoc_Click()` | No existe | ❌ Falta | |
| **Importar** | `Bt_Importar_Click()` | "En desarrollo" | ❌ NO IMPLEMENTADO | |
| **Exportar Excel** | `Bt_ExcelTot_Click()` | `ExportToExcelAsync()` | ✅ Migrado | |

### 3.2 Detalle de GAPs Críticos

#### 3.2.1 Centralización Contable (❌ CRÍTICO)

**VB6 - Funcionalidad completa:**
```vb
Private Sub Bt_Centralizar_Click()
   ' Genera comprobante contable desde documentos del libro
   ' Maneja múltiples documentos seleccionados
   ' Actualiza estado documento a ED_CENTRALIZADO
   ' Genera MovDocumento con asientos contables
   ' Gestiona cuentas de IVA Crédito/Débito Fiscal
   ' Controla privilegios PRV_ADM_DOCS
```

**VB6 - `GenMovDocumento()` (líneas 7151-7469):**
- Genera asientos contables automáticos
- Distingue entre Libro Compras vs Ventas
- Maneja cuentas: Exento, Afecto, IVA, Otros Impuestos, Total
- Aplica Centro de Costo y Área de Negocio
- Considera tipo documento (NC = rebaja → débito/haber invertido)
- Gestiona IVA Activo Fijo, IVA Irrecuperable

**.NET - Estado actual:**
```csharp
// CompraVentaApiController.cs línea 70
[HttpPost("{id}/centralizar")]
public IActionResult Centralizar(int id)
{
    // TODO: Implementar lógica de centralización
    return StatusCode(501, new { message = "Centralización no implementada" });
}
```

**Impacto:** Los usuarios no pueden generar comprobantes contables desde el libro de compras/ventas, lo cual es la función principal del módulo.

#### 3.2.2 Importación desde Archivo (❌ PENDIENTE)

**VB6 - Múltiples formatos:**
- Importa desde archivos SII
- Importa desde Excel
- Valida duplicados automáticamente
- Mapea tipos de documento

**.NET - Estado actual:**
```javascript
// Index.cshtml - JavaScript
function importarDocumentos() {
    mostrarAlerta('info', 'Información', 'Esta función está en desarrollo');
}
```

---

## 4. VALIDACIONES DE NEGOCIO

### 4.1 Validaciones VB6 Identificadas

| Validación | Ubicación VB6 | .NET | Estado |
|------------|---------------|------|--------|
| RUT válido chileno | `ValidCID()` | No encontrado | ❌ Falta |
| Fecha emisión ≤ último día mes | `IsValidLine()` | No validado | ❌ Falta |
| Número documento único | `ValidaNumDoc()` | Parcial en DB | ⚠️ Parcial |
| Documento año anterior no duplicado | `ValidaNumDocAnoAnt()` | No existe | ❌ Falta |
| IVA CF fuera de plazo (2 meses) | `IsValidLine()` líneas 7580-7600 | No existe | ❌ Falta |
| Nota crédito plazo 3/6 meses | `Grid_BeforeEdit()` | No existe | ❌ Falta |
| Factura venta requiere Afecto | `IsValidLine()` | No existe | ❌ Falta |
| 14TER/14D requiere descripción | `IsValidLine()` | No existe | ❌ Falta |
| Máquina registradora: campos obligatorios | `IsValidLine()` | No existe | ❌ Falta |
| Cuenta contable último nivel | `Grid_AcceptValue()` | No existe | ❌ Falta |
| Estado documento permite edición | `ValidaEstadoEdit()` | Parcial | ⚠️ Parcial |

### 4.2 Validaciones Tributarias Críticas

**Ley 21.398 (IVA Notas de Crédito):**
```vb
' VB6 - FrmCompraVenta.frm líneas 3892-3898
If FechaForm > DateSerial(2022, 4, 1) Then
    MsgBox1 "...plazo para rebajar el débito fiscal es de 6 meses..."
Else
    MsgBox1 "...plazo para rebajar el débito fiscal es de 3 meses..."
End If
```
**Estado .NET:** ❌ No implementado

**IVA Crédito Fiscal - Plazo 2 períodos:**
```vb
' VB6 - FrmCompraVenta.frm líneas 7580-7600
If Abs(DateDiff("m", FRecep, Val(Grid.TextMatrix(Row, C_LNGFECHAEMIORI)))) > 2 Then
    ' Ofrece reclasificar IVA como Irrecuperable
    Grid.TextMatrix(Row, C_IVA_IDCUENTA) = lIdCuentaIVAIrrec
```
**Estado .NET:** ❌ No implementado

---

## 5. REGLAS DE NEGOCIO

### 5.1 Cálculo de Totales

**VB6 - `CalcTotRow()`:**
```vb
IVA = Round(vFmt(Grid.TextMatrix(Row, C_AFECTO)) * gIVA)
' Valida diferencia > 2 unidades
Tot = Exento + Afecto + IVA + OtroImp
```

**VB6 - `CalcIngresoTotal()` (para boletas):**
```vb
' Calcula afecto e IVA desde total (inverso)
Afecto = Total / (1 + gIVA)
IVA = Total - Afecto
```

**.NET - `calcularTotales()`:**
```javascript
// Solo suma columnas visibles, no aplica reglas de negocio
let totales = { exento: 0, neto: 0, iva: 0, total: 0 };
```

**GAP:** Falta cálculo automático de IVA, validación de diferencias, y lógica de ingreso desde total.

### 5.2 Estados de Documento

**VB6 - Estados definidos:**
```vb
ED_PENDIENTE = 1
ED_CENTRALIZADO = 2
ED_PAGADO = 3
ED_ANULADO = 4
ED_APROBADO = 5  ' Para DTE
```

**.NET - Manejo parcial:**
- Solo muestra texto del estado
- No valida transiciones de estado
- No controla edición según estado

### 5.3 Proporcionalidad de IVA

**VB6 - Sistema completo:**
```vb
PIVA_SINPROP = 0
PIVA_TOTAL = 1
PIVA_PARCIAL = 2
PIVA_NO = 3
' Se muestra en columna C_PROPIVA
' Afecta cálculo de IVA recuperable
```

**.NET:** ❌ No implementado - Campo crítico para empresas con ventas mixtas (afectas/exentas)

---

## 6. FLUJOS DE TRABAJO

### 6.1 Flujo de Ingreso de Documento

**VB6 - Flujo completo:**
```
1. Usuario ingresa día → Se autocompleta fecha emisión
2. Se hereda tipo doc de línea anterior
3. Se hereda número doc + 1 para ventas
4. Ingresa RUT → Valida formato → Busca/Crea entidad
5. Ingresa montos → Calcula IVA automático
6. Se asignan cuentas contables default
7. Validación línea completa
8. Guardado con tracking
```

**.NET - Flujo actual:**
```
1. Usuario hace clic en "Nuevo"
2. Redirect a GestionDocumentos
3. (Flujo diferente, no inline)
```

**GAP:** Pérdida de productividad por no tener ingreso inline en grilla.

### 6.2 Flujo de Centralización

**VB6:**
```
1. Usuario selecciona documentos (checkbox)
2. Clic en "Centralizar"
3. Sistema valida documentos completos
4. Genera comprobante contable
5. Genera MovDocumento con asientos
6. Actualiza estado a ED_CENTRALIZADO
7. Opcional: Recálculo proporcionalidad IVA
```

**.NET:** ❌ No existe

---

## 7. INTEGRACIONES

### 7.1 Integraciones Identificadas

| Sistema | VB6 | .NET | Estado |
|---------|-----|------|--------|
| **Entidades** | `FrmEntidad` | Parcial | ⚠️ |
| **Plan de Cuentas** | `FrmPlanCuentas` | No integrado | ❌ |
| **Comprobantes** | `FrmComprobante` | No integrado | ❌ |
| **Activo Fijo** | `FrmActivoFijoFicha` | No integrado | ❌ |
| **Cuotas Documento** | `FrmDocCuotas` | No integrado | ❌ |
| **Libro Caja** | `LibroCaja` tabla | No integrado | ❌ |
| **Sucursales** | `Sucursales` tabla | No integrado | ❌ |
| **Proporcionalidad IVA** | `PropIVA_*` | No integrado | ❌ |
| **Tracking/Auditoría** | `SeguimientoDocumento()` | No encontrado | ❌ |
| **SII** | Exportación formato | No integrado | ❌ |

### 7.2 Integración con Base de Datos

**VB6 - Tablas utilizadas:**
- `Documento` - Cabecera documentos
- `MovDocumento` - Detalle movimientos contables
- `Entidades` - Clientes/Proveedores
- `Cuentas` / `CuentasBasicas` - Plan de cuentas
- `TipoDocs` - Tipos de documento
- `Sucursales` - Sucursales
- `LibroCaja` - Libro de caja
- `Tracking_Documento` / `Tracking_MovDocumento` - Auditoría

**.NET - Uso actual:**
```csharp
// CompraVentaService.cs
var documentos = await context.Documento
    .Where(d => d.TipoLib == tipoLib)
    // Consulta básica sin joins complejos
```

---

## 8. MENSAJES Y TEXTOS

### 8.1 Mensajes VB6 No Migrados

| Mensaje VB6 | Contexto | .NET |
|-------------|----------|------|
| "Ingrese el día antes de continuar" | Validación fecha | ❌ |
| "Línea anterior incompleta o inválida" | Validación secuencia | ❌ |
| "RUT inválido" | Validación RUT | ❌ |
| "Esta entidad no ha sido ingresada..." | Nueva entidad | ❌ |
| "Tipo de documento inválido" | Validación tipo doc | ❌ |
| "Recuerde que si está ingresando una nota de crédito..." | Ley IVA | ❌ |
| "El documento X ya ha sido ingresado" | Duplicado | Parcial |
| "No es posible ingresar documentos sin configurar cuentas IVA" | Config inicial | ❌ |
| "El Libro se está editando en equipo X" | Bloqueo concurrente | ❌ |

### 8.2 Alertas de Usuario .NET

```javascript
// Implementadas con SweetAlert2
mostrarAlerta('success', 'Éxito', 'Operación completada');
mostrarAlerta('error', 'Error', 'No se pudo completar');
```

**GAP:** Mensajes genéricos sin contexto de negocio específico.

---

## 9. CASOS BORDE Y ESPECIALES

### 9.1 Casos Identificados en VB6

| Caso | Manejo VB6 | .NET |
|------|------------|------|
| Documento año anterior | Valida duplicado, permite "exportar" | ❌ |
| Notas de crédito (rebaja) | Invierte signos débito/haber | ❌ |
| Boletas (ingreso desde total) | Calcula afecto/IVA inverso | ❌ |
| Máquina registradora | Campos especiales obligatorios | ❌ |
| Vale pago electrónico (VPE) | Validación especial | ❌ |
| Documento importación (IMP) | RUT default, validación especial | ❌ |
| Venta sin documento (VSD) | NumDoc autogenerado | ❌ |
| Empresa 14TER/14D | Fecha venc = contado, descripción obligatoria | ❌ |
| Proporcionalidad IVA | Cálculo especial, recálculo mensual | ❌ |
| IVA Activo Fijo | Cuenta especial, clasificación | ❌ |
| IVA Irrecuperable | Reclasificación fuera de plazo | ❌ |
| Entidad relacionada | Pago contado automático | ❌ |
| Documento DTE | Flag especial, validaciones | Parcial |
| Documento con Giro | Afecta tratamiento tributario | ❌ |
| Edición concurrente | LockAction por mes/libro | ❌ |

### 9.2 Tratamiento de Tipos de Documento Especiales

```vb
' VB6 - Constantes de tipos de documento
TDOC_VENTASINDOC = "VSD"    ' Venta sin documento
TDOC_BOLVENTA = "BOV"       ' Boleta venta
TDOC_BOLVENTAEX = "DVB"     ' Devolución boleta
TDOC_BOLEXENTA = "BOE"      ' Boleta exenta
TDOC_MAQREGISTRADORA = "MRG" ' Máquina registradora
TDOC_VALEPAGOELECTR = "VPE" ' Vale pago electrónico
```

**.NET:** Solo maneja tipos genéricamente sin lógica especial.

---

## 10. CONFIGURACIÓN Y PARÁMETROS

### 10.1 Parámetros de Empresa VB6

| Parámetro | Uso | .NET |
|-----------|-----|------|
| `gEmpresa.Franq14Ter` | Régimen tributario 14TER | ❌ |
| `gEmpresa.ProPymeGeneral` | Régimen ProPyme | ❌ |
| `gEmpresa.ProPymeTransp` | Régimen ProPyme Transparente | ❌ |
| `gIVA` | Tasa IVA actual | ❌ |
| `gCtasBas.IdCtaIVACred` | Cuenta IVA Crédito | ❌ |
| `gCtasBas.IdCtaIVADeb` | Cuenta IVA Débito | ❌ |
| `gFmtCodigoCta` | Formato código cuenta | ❌ |

### 10.2 Privilegios de Usuario

```vb
' VB6 - Control de privilegios
PRV_ING_DOCS    ' Ingreso documentos
PRV_ADM_DOCS    ' Administración (centralizar, anular)
```

**.NET:** No se encontró control de privilegios específico para esta funcionalidad.

---

## 11. RENDIMIENTO Y PAGINACIÓN

### 11.1 VB6 - Sistema de Paginación

```vb
' Clase lClsPaging para manejo de registros
lClsPaging.NumReg      ' Número de registros
lClsPaging.CurReg      ' Registro actual
gPageNumReg            ' Registros por página
```

### 11.2 .NET - Paginación Actual

```javascript
// Index.cshtml - Sin paginación visible
// Carga todos los documentos del período
```

**GAP:** Para meses con muchos documentos, puede haber problemas de rendimiento.

---

## 12. RESUMEN DE PRIORIDADES

### 🔴 Prioridad ALTA (Bloqueantes)

1. **Centralización contable** - Función principal del módulo
2. **Validaciones tributarias** - Cumplimiento normativo SII
3. **Proporcionalidad IVA** - Empresas con ventas mixtas
4. **Generación MovDocumento** - Asientos contables

### 🟡 Prioridad MEDIA (Importantes)

5. **Importación desde archivo** - Productividad usuarios
6. **Filtros avanzados** - Usabilidad
7. **Columnas adicionales grilla** - Información completa
8. **Anular/Duplicar documentos** - Operaciones comunes
9. **Gestión cuotas documento** - Cobranza
10. **Resumen IVA** - Informes tributarios

### 🟢 Prioridad BAJA (Mejoras)

11. **Edición inline en grilla** - UX similar a VB6
12. **Checkboxes de visualización** - Personalización
13. **Vista previa impresión** - Usabilidad
14. **Bloqueo concurrente** - Multi-usuario

---

## 13. RECOMENDACIONES

### 13.1 Acciones Inmediatas

1. **Implementar `CentralizarAsync()` en `CompraVentaService.cs`**
   - Portar lógica de `GenMovDocumento()`
   - Manejar transacciones atómicas
   - Actualizar estados de documento

2. **Crear `CompraVentaValidationService.cs`**
   - Validación RUT chileno
   - Validación fechas tributarias
   - Validación plazos IVA

3. **Agregar columnas faltantes a la grilla**
   - Fecha emisión original
   - Fecha vencimiento
   - Proporcionalidad IVA (para compras)
   - Cuentas contables

### 13.2 Acciones Corto Plazo

4. **Implementar importación desde archivo**
   - Formato SII (CSV)
   - Formato Excel

5. **Agregar filtros avanzados**
   - Por tipo documento
   - Por estado
   - Por sucursal
   - Por DTE

6. **Integrar con Plan de Cuentas**
   - Selector de cuentas
   - Validación cuenta último nivel

### 13.3 Acciones Mediano Plazo

7. **Implementar Proporcionalidad IVA**
   - Cálculo mensual
   - Recálculo automático

8. **Integración Activo Fijo**
   - Detección automática cuentas AF
   - Creación fichas desde documento

9. **Sistema de tracking/auditoría**
   - Equivalente a `SeguimientoDocumento()`

---

## 14. MÉTRICAS DE MIGRACIÓN

| Métrica | Valor |
|---------|-------|
| **Completitud funcional** | ~25% |
| **Completitud UI** | ~40% |
| **Validaciones migradas** | ~15% |
| **Reglas de negocio** | ~20% |
| **Integraciones** | ~10% |
| **Score general** | **~22%** |

---

## 15. ANEXOS

### 15.1 Columnas VB6 Completas

```vb
' FrmCompraVenta.frm - Constantes de columnas
Const C_IDDOC = 0
Const C_NUMLIN = 1
Const C_CORRINTERNO = 2
Const C_CHECK = 3
Const C_TIPODOC = 4
Const C_DTE = 5
Const C_GIRO = 6
Const C_NUMFISCIMPR = 7
Const C_NUMINFORMEZ = 8
Const C_NUMDOC = 9
Const C_NUMDOCHASTA = 10
Const C_CANTBOLETAS = 11
Const C_PROPIVA = 12
Const C_FECHA = 13
Const C_RUT = 14
Const C_NOMBRE = 15
Const C_SUCURSAL = 16
Const C_EXENTO = 17
Const C_AFECTO = 18
Const C_IVA = 19
Const C_OTROIMP = 20
Const C_TOTAL = 21
Const C_FECHAEMIORI = 22
Const C_FECHAVENC = 23
Const C_EX_CODCUENTA = 24
Const C_EX_CUENTA = 25
Const C_AF_CODCUENTA = 26
Const C_AF_CUENTA = 27
Const C_TOT_CODCUENTA = 28
Const C_TOT_CUENTA = 29
Const C_DETACTFIJO = 30
Const C_DETALLE = 31
Const C_DOCASOC = 32
Const C_DESCRIP = 33
Const C_ESTADO = 34
Const C_USUARIO = 35
Const C_VENTASACUM = 36
' + columnas ocultas de IDs y otros impuestos
```

### 15.2 Estados de Documento

```vb
Const ED_PENDIENTE = 1
Const ED_CENTRALIZADO = 2
Const ED_PAGADO = 3
Const ED_ANULADO = 4
Const ED_APROBADO = 5
```

### 15.3 Tipos de Libro

```vb
Const LIB_COMPRAS = 1
Const LIB_VENTAS = 2
```

---

*Documento generado automáticamente - Auditoría de migración VB6 → .NET 9*
