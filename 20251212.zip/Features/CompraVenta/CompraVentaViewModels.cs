namespace App.Features.CompraVenta;

/// <summary>
/// ViewModel para la vista Index de CompraVenta
/// Reemplaza el uso de ViewBag con propiedades tipadas
/// </summary>
public class CompraVentaIndexViewModel
{
    /// <summary>
    /// Tipo de libro: 1 = Compras, 2 = Ventas
    /// </summary>
    public int? TipoLib { get; set; }

    /// <summary>
    /// Año para filtrar documentos
    /// </summary>
    public int Ano { get; set; }

    /// <summary>
    /// Mes para filtrar documentos (1-12, 0 = Todos)
    /// </summary>
    public int Mes { get; set; }

    /// <summary>
    /// ID de la empresa seleccionada en sesión
    /// </summary>
    public int EmpresaId { get; set; }

    /// <summary>
    /// Constructor por defecto que inicializa con valores actuales
    /// </summary>
    public CompraVentaIndexViewModel()
    {
        Ano = DateTime.Now.Year;
        Mes = DateTime.Now.Month;
    }
}
