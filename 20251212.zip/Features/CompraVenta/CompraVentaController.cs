using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Extensions;
using App.Helpers;

namespace App.Features.CompraVenta;

/// <summary>
/// MVC Controller para gestión de compra/venta - NUNCA inyecta services directamente
/// Basado en FrmCompraVenta.frm del sistema VB6
/// </summary>

public class CompraVentaController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<CompraVentaController> logger) : Controller
{
    [HttpGet]
    public IActionResult Index(int? tipoLib, int? ano, int? mes)
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Compra/Venta";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        logger.LogInformation("Loading CompraVenta index for tipoLib: {TipoLib}, año: {Ano}, mes: {Mes}",
            tipoLib, ano, mes);

        // Crear ViewModel tipado en lugar de usar ViewBag
        var viewModel = new CompraVentaIndexViewModel
        {
            TipoLib = tipoLib,
            Ano = ano ?? DateTime.Now.Year,
            Mes = mes ?? DateTime.Now.Month,
            EmpresaId = SessionHelper.EmpresaId
        };

        return View(viewModel);
    }

    /// <summary>
    /// Crear nuevo documento de compra/venta - Redirige a GestionDocumentos
    /// GET /CompraVenta/Create?tipoLib={tipoLib}
    /// </summary>
    [HttpGet]
    public IActionResult Create(int? tipoLib)
    {
        logger.LogInformation("Redirigiendo a creación de documento con tipoLib: {TipoLib}", tipoLib);

        // Redirigir a GestionDocumentos/Create con el tipo de libro
        return RedirectToAction("Create", "GestionDocumentos", new { tipoLib = tipoLib });
    }

    /// <summary>
    /// Editar documento de compra/venta - Redirige a GestionDocumentos
    /// GET /CompraVenta/Edit/{id}
    /// </summary>
    [HttpGet]
    public IActionResult Edit(int id)
    {
        logger.LogInformation("Redirigiendo a edición de documento {IdDoc}", id);

        // Redirigir a GestionDocumentos/Edit con el ID del documento
        return RedirectToAction("Edit", "GestionDocumentos", new { idDoc = id });
    }

    /// <summary>
    /// Método proxy para obtener documentos de compra/venta
    /// GET /CompraVenta/GetDocumentos?tipoLib={tipoLib}&amp;ano={ano}&amp;mes={mes}
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetDocumentos(int tipoLib, short ano, int mes)
    {
        logger.LogInformation("Proxy: GetDocumentos - tipoLib: {TipoLib}, ano: {Ano}, mes: {Mes}", tipoLib, ano, mes);

        var empresaId = SessionHelper.EmpresaId;
        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<CompraVentaApiController>(
            HttpContext,
            nameof(CompraVentaApiController.GetAll),
            new { empresaId, ano, tipoLib, mes }
        );
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    // ELIMINADO: Métodos EliminarDocumento y Centralizar proxy (R19) - JavaScript llama directamente a /api/CompraVentaApi

    /// <summary>
    /// Método proxy para exportar a Excel
    /// GET /CompraVenta/ExportarExcel?tipoLib={tipoLib}&amp;ano={ano}&amp;mes={mes}
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ExportarExcel(int tipoLib, short ano, int mes)
    {
        logger.LogInformation("Proxy: ExportarExcel - tipoLib: {TipoLib}, ano: {Ano}, mes: {Mes}", tipoLib, ano, mes);

        var empresaId = SessionHelper.EmpresaId;
        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<CompraVentaApiController>(
            HttpContext,
            nameof(CompraVentaApiController.Exportar),
            new { empresaId, ano, tipoLib, mes }
        );
        var (fileBytes, contentType) = await client.DownloadFileAsync(url, HttpMethod.Get);
        var fileName = $"LibroCompraVenta_{tipoLib}_{ano}_{mes:D2}.xlsx";
        return File(fileBytes, contentType, fileName);
    }
}
