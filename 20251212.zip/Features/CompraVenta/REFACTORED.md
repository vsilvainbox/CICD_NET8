# CompraVenta - Refactorización Completada

## Cambios Aplicados

### CSS - appearance-none (3 instancias)

- ✅ Removido de `#cbTipoLib` select
- ✅ Removido de `#cbAno` select
- ✅ Removido de `#cbMes` select

### R19 - WebController proxy → ApiController directo (4 URLs)

- ✅ `URL_ENDPOINTS` actualizado para usar `/CompraVentaApi/` directamente
- ✅ getDocumentos → `/CompraVentaApi/GetAll`
- ✅ eliminarDocumento → `/CompraVentaApi/Delete`
- ✅ centralizar → `/CompraVentaApi/Centralizar`
- ✅ exportarExcel → `/CompraVentaApi/Exportar`

### R20 - fetch → Api.* (3 instancias)

- ✅ `cargarDocumentos()`: fetch → `Api.get()`
- ✅ `eliminarDocumento()`: fetch DELETE → `Api.delete()`
- ✅ `centralizarDocumentos()`: fetch POST → `Api.postJson()`

## Archivos Modificados

- `Views/Index.cshtml` - CSS, R19, R20

## Fecha

2025-01-21
