using Microsoft.AspNetCore.Mvc;
using App.Helpers;

namespace App.Features.CierreAnual;

/// <summary>
/// MVC Controller para cierre anual (cierre de ejercicio)
/// Migrado desde VB6 FrmCierreAnual.frm
/// </summary>
public class CierreAnualController(ILogger<CierreAnualController> logger) : Controller
{
    /// <summary>
    /// Vista principal del cierre anual
    /// Muestra el año a cerrar y permite ejecutar el proceso
    /// </summary>
    public IActionResult Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder al Cierre Anual";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        var empresaId = SessionHelper.EmpresaId;
        int ano = SessionHelper.Ano;
        logger.LogInformation("Loading CierreAnual Index view for empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        var viewModel = new CierreAnualIndexViewModel
        {
            EmpresaId = empresaId,
            Ano = ano
        };

        return View(viewModel);
    }
}