using Microsoft.AspNetCore.Mvc;

namespace App.Features.BalanceTributarioIfrs;

/// <summary>
/// API Controller para Balance Tributario IFRS (8 columnas).
/// </summary>
[ApiController]
[Route("[controller]/[action]")]
public class BalanceTributarioIfrsApiController(
    IBalanceTributarioIfrsService service,
    ILogger<BalanceTributarioIfrsApiController> logger) : ControllerBase
{
    /// <summary>
    /// Genera el Balance Tributario IFRS.
    /// </summary>
    /// <param name="request">Parámetros de filtrado.</param>
    /// <returns>Balance con estructura de 8 columnas.</returns>
    [HttpPost]
    public async Task<ActionResult<BalanceTributarioIfrsResponseDto>> Generar(
        [FromBody] BalanceTributarioIfrsRequestDto request)
    {
        var resultado = await service.GenerarAsync(request);
        return Ok(resultado);
    }

    /// <summary>
    /// Valida el plan de cuentas actual.
    /// </summary>
    /// <returns>Información sobre la validez del plan.</returns>
    [HttpGet]
    public async Task<ActionResult> ValidarPlan()
    {
        var (esValido, planActual, mensaje) = await service.ValidarPlanCuentasAsync();

        return Ok(new
        {
            esValido,
            planActual,
            mensaje
        });
    }

    /// <summary>
    /// Verifica si existen cuentas sin clasificación IFRS.
    /// </summary>
    /// <param name="fechaHasta">Fecha hasta para verificar saldos.</param>
    /// <returns>True si hay cuentas sin clasificar con saldo.</returns>
    [HttpGet]
    public async Task<ActionResult> ValidarClasificacion([FromQuery] DateTime fechaHasta)
    {
        var (existen, mensaje) = await service.ValidarClasificacionIfrsAsync(fechaHasta);

        return Ok(new
        {
            existen,
            mensaje
        });
    }

    /// <summary>
    /// Obtiene las áreas de negocio disponibles.
    /// </summary>
    /// <returns>Lista de áreas de negocio.</returns>
    [HttpGet]
    public async Task<ActionResult> ObtenerAreasNegocio()
    {
        var items = await service.ObtenerAreasNegocioAsync();
        return Ok(items);
    }

    /// <summary>
    /// Obtiene los centros de costo disponibles.
    /// </summary>
    /// <returns>Lista de centros de costo.</returns>
    [HttpGet]
    public async Task<ActionResult> ObtenerCentrosCosto()
    {
        var items = await service.ObtenerCentrosCostoAsync();
        return Ok(items);
    }

    /// <summary>
    /// Exporta el Balance Tributario IFRS a PDF.
    /// </summary>
    /// <param name="request">Parámetros del balance a exportar.</param>
    /// <param name="incluirMembrete">Si debe incluir membrete de la empresa.</param>
    /// <returns>Archivo PDF del balance.</returns>
    [HttpPost]
    public async Task<ActionResult> ExportarPdf(
        [FromBody] BalanceTributarioIfrsRequestDto request,
        [FromQuery] bool incluirMembrete = true)
    {
        var (pdfBytes, fileName) = await service.ExportarPdfAsync(request, incluirMembrete);
        return File(pdfBytes, "application/pdf", fileName);
    }
}
