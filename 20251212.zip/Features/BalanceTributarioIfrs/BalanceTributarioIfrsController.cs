using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Authorization;
using App.Extensions;

namespace App.Features.BalanceTributarioIfrs;

/// <summary>
/// Controller MVC para Balance Tributario IFRS.
/// </summary>
[Authorize]

public class BalanceTributarioIfrsController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<BalanceTributarioIfrsController> logger) : Controller
{
    /// <summary>
    /// Página principal del Balance Tributario IFRS.
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Index()
    {
        var viewModel = await CargarDatosIniciales();
        return View(viewModel);
    }

    private async Task<BalanceTributarioIfrsIndexViewModel> CargarDatosIniciales()
    {
        var client = httpClientFactory.CreateClient();
        var viewModel = new BalanceTributarioIfrsIndexViewModel();

        // Niveles (1-5)
        viewModel.Niveles = Enumerable.Range(1, 5)
            .Select(n => new SelectListItem { Value = n.ToString(), Text = $"Nivel {n}" })
            .ToList();

        // Áreas de negocio desde API
        var urlAreas = linkGenerator.GetApiUrl<BalanceTributarioIfrsApiController>(
            HttpContext,
            nameof(BalanceTributarioIfrsApiController.ObtenerAreasNegocio));

        var areas = await client.GetFromApiAsync<List<Shared.ComboItemDto>>(urlAreas!);
        viewModel.AreasNegocio = (areas ?? new()).Select(a => new SelectListItem
        {
            Value = a.Value.ToString(),
            Text = a.Text
        }).ToList();

        // Centros de costo desde API
        var urlCentros = linkGenerator.GetApiUrl<BalanceTributarioIfrsApiController>(
            HttpContext,
            nameof(BalanceTributarioIfrsApiController.ObtenerCentrosCosto));

        var centros = await client.GetFromApiAsync<List<Shared.ComboItemDto>>(urlCentros!);
        viewModel.CentrosCosto = (centros ?? new()).Select(c => new SelectListItem
        {
            Value = c.Value.ToString(),
            Text = c.Text
        }).ToList();

        // Validaciones desde API
        var urlValidar = linkGenerator.GetApiUrl<BalanceTributarioIfrsApiController>(
            HttpContext,
            nameof(BalanceTributarioIfrsApiController.ValidarPlan));

        var validacion = await client.GetFromApiAsync<JsonElement>(urlValidar!);

        viewModel.PlanValido = validacion.TryGetProperty("esValido", out var esValidoProp)
            ? esValidoProp.GetBoolean()
            : false;

        viewModel.PlanActual = validacion.TryGetProperty("planActual", out var planActualProp)
            ? planActualProp.GetString() ?? "Desconocido"
            : "Desconocido";

        // Fecha por defecto
        var hoy = DateTime.Now;
        viewModel.FechaDesde = new DateTime(hoy.Year, 1, 1);
        viewModel.FechaHasta = hoy;

        return viewModel;
    }
}
