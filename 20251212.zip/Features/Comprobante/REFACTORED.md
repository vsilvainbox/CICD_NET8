# Comprobante - Refactorización Completada

## Fecha: 2025-01-15

## Reglas Aplicadas

### CSS: appearance-none (3 removidos)
- `Views/Index.cshtml` línea 44: select#tipoComprobante
- `Views/Index.cshtml` línea 53: select#estadoComprobante  
- `Views/Index.cshtml` línea 62: select#tipoAjuste

### R19: Eliminar proxy WebController→ApiController
- `Views/Index.cshtml`: API_URLS actualizado para apuntar directamente a `ListarComprobantesApi`
  - getTiposComprobante → ListarComprobantesApi/GetTiposComprobante
  - getEstadosComprobante → ListarComprobantesApi/GetEstadosComprobante
  - getTiposAjuste → ListarComprobantesApi/GetTiposAjuste
  - getTiposDocumento → ListarComprobantesApi/GetTiposDocumento
  - getCuentas → ListarComprobantesApi/GetCuentas
  - getEntidades → ListarComprobantesApi/GetEntidades
  - getSucursales → ListarComprobantesApi/GetSucursales
  - buscar → ListarComprobantesApi/Buscar
  - getDetalle → ListarComprobantesApi/GetDetalle
  - delete → ListarComprobantesApi/Delete
  - cambiarEstado → ListarComprobantesApi/CambiarEstado
  - calcularTotal → ListarComprobantesApi/CalcularTotal
  - exportar → ListarComprobantesApi/Exportar
- `ComprobanteController.cs`: Sección de proxies de listado marcada como obsoleta

### R20: Convertir fetch → Api.* (13 convertidos)
- `Views/Index.cshtml`:
  - `loadTiposComprobante()` → Api.get()
  - `loadEstadosComprobante()` → Api.get()
  - `loadTiposAjuste()` → Api.get()
  - `loadTiposDocumento()` → Api.get()
  - `loadCuentas()` → Api.get() con params empresaId, ano
  - `loadEntidades()` → Api.get() con param empresaId
  - `loadSucursales()` → Api.get() con param empresaId
  - `performSearch()` → Api.postJson() con params empresaId, ano
  - `viewDetailById()` → Api.get() con params empresaId, ano
  - `deleteById()` → Api.delete() con params empresaId, ano
  - `changeStateById()` → Api.postJson() con params empresaId, ano
  - `calculateSum()` → Api.postJson() con params empresaId, ano
  - `exportResults()` → Api.download() con params empresaId, ano

### R07: Validación Session
- Verificado: No hay uso de Session[] en JavaScript
- TempData se usa correctamente para mensajes MVC

### R16: http-directo
- Verificado: No hay construcciones manuales de URL con HttpContext.Request.Host

## Archivos Modificados
1. `Views/Index.cshtml` - CSS, URLs, fetch→Api.*
2. `ComprobanteController.cs` - Comentario sección proxy obsoleta

## Notas
- Los métodos proxy en ComprobanteController.cs se mantienen por compatibilidad pero están marcados como obsoletos
- Index.cshtml ahora usa EMPRESA_ID y ANO del Razor para pasar a las llamadas API
- ListarComprobantesApiController requiere empresaId y ano como query params
