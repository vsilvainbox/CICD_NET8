﻿namespace App.Features.Comprobante;

public interface IComprobanteService
{
    // ========== CRUD Principal ==========
    
    /// <summary>
    /// Crea un nuevo comprobante con sus movimientos
    /// </summary>
    Task<ComprobanteDto> CreateAsync(int empresaId, int usuarioId, ComprobanteCreateDto dto);
    
    /// <summary>
    /// Actualiza un comprobante existente
    /// </summary>
    Task<ComprobanteDto> UpdateAsync(int id, int usuarioId, ComprobanteUpdateDto dto);
    
    /// <summary>
    /// Obtiene un comprobante por ID con todos sus movimientos
    /// </summary>
    Task<ComprobanteDto?> GetByIdAsync(int id);
    
    /// <summary>
    /// Elimina un comprobante (soft delete cambiando estado a Anulado)
    /// </summary>
    Task DeleteAsync(int id);
    
    
    // ========== Operaciones de Comprobante ==========
    
    /// <summary>
    /// Obtiene el próximo correlativo disponible
    /// </summary>
    Task<int> GetNextCorrelativeAsync(int empresaId, short ano, byte? tipo = null);
    
    /// <summary>
    /// Valida los datos del comprobante antes de guardar
    /// Lanza BusinessException si hay errores de validación
    /// </summary>
    Task ValidateAsync(ComprobanteCreateDto dto, int? idUsuario = null, int? idEmpresa = null);
    
    /// <summary>
    /// Valida que el comprobante esté balanceado (Debe = Haber)
    /// </summary>
    Task<bool> ValidateBalanceAsync(List<MovimientoDto> movimientos);
    
    /// <summary>
    /// Valida que el período no esté cerrado
    /// </summary>
    Task<bool> ValidateOpenPeriodAsync(DateTime fecha, int empresaId);
    
    /// <summary>
    /// Cuadra automáticamente el comprobante agregando el valor faltante
    /// </summary>
    Task<ComprobanteDto> BalanceVoucherAsync(int id, int movimientoIndex, int idCuenta);
    
    
    // ========== Operaciones de Movimientos ==========
    
    /// <summary>
    /// Agrega un nuevo movimiento a un comprobante
    /// </summary>
    Task<MovimientoDto> AddMovementAsync(int idComp, MovimientoCreateDto dto);
    
    /// <summary>
    /// Actualiza un movimiento existente
    /// </summary>
    Task<MovimientoDto> UpdateMovementAsync(int id, MovimientoUpdateDto dto);
    
    /// <summary>
    /// Elimina un movimiento
    /// </summary>
    Task DeleteMovementAsync(int id);
    
    /// <summary>
    /// Duplica un movimiento existente
    /// </summary>
    Task<MovimientoDto> DuplicateMovementAsync(int id);
    
    /// <summary>
    /// Reordena un movimiento (mueve arriba o abajo)
    /// </summary>
    Task ReorderMovementAsync(int id, bool moveUp);
    
    
    // ========== Cálculos ==========
    
    /// <summary>
    /// Calcula los totales debe/haber del comprobante
    /// </summary>
    Task<TotalesDto> CalculateTotalsAsync(int idComp);
    
    /// <summary>
    /// Suma montos de movimientos seleccionados
    /// </summary>
    Task<double> SumMovementsAsync(List<int> movimientosIds, bool sumDebe);
    
    
    // ========== Documentos ==========
    
    /// <summary>
    /// Asigna un documento a un movimiento
    /// </summary>
    Task AssignDocumentAsync(int idMovimiento, int idDocumento);

    /// <summary>
    /// Remueve la asociación de documento de un movimiento
    /// </summary>
    Task RemoveDocumentAsync(int idMovimiento);
    
    /// <summary>
    /// Busca documentos según criterios
    /// </summary>
    Task<List<DocumentoDto>> SearchDocumentsAsync(int empresaId, DocumentoSearchDto searchDto);
    
    /// <summary>
    /// Genera comprobante de pago automático desde documentos seleccionados
    /// </summary>
    Task<ComprobanteDto> GeneratePaymentAsync(int empresaId, int usuarioId, List<int> documentosIds);
    
    
    // ========== Cuentas y Plan de Cuentas ==========

    /// <summary>
    /// Valida que una cuenta exista y sea de último nivel
    /// </summary>
    Task<CuentaDto?> ValidateAccountAsync(int empresaId, short ano, string? codigo);

    /// <summary>
    /// Busca cuentas por código o nombre
    /// </summary>
    Task<List<CuentaDto>> SearchAccountsAsync(int empresaId, short ano, string? searchTerm);
    
    /// <summary>
    /// Obtiene una cuenta por ID
    /// </summary>
    Task<CuentaDto?> GetAccountByIdAsync(int idCuenta, int empresaId, short ano);
    
    
    // ========== Utilitarios ==========

    /// <summary>
    /// Obtiene la fecha sugerida para un nuevo comprobante
    /// VB6: GetMesActual() + GetUltimoMesConComps() en HyperCont.bas
    /// </summary>
    Task<DateTime> GetFechaSugeridaAsync(int empresaId, short ano);

    /// <summary>
    /// Convierte monto entre monedas
    /// </summary>
    Task<ConversionMonedaDto> ConvertCurrencyAsync(double amount, string fromCurrency, string toCurrency, DateTime fecha);

    /// <summary>
    /// Obtiene glosas predefinidas
    /// </summary>
    Task<List<GlosaDto>> GetGlossariesAsync(int empresaId);
    
    /// <summary>
    /// Exporta comprobante a Excel
    /// </summary>
    Task<byte[]> ExportToExcelAsync(int idComp);
    
    /// <summary>
    /// Genera reporte PDF del comprobante
    /// </summary>
    Task<byte[]> GenerateReportAsync(int idComp, bool resumido = false);
    
    /// <summary>
    /// Genera cheque en PDF para imprimir
    /// </summary>
    Task<byte[]> GenerateChequePdfAsync(int idComp, ChequeConfigDto config);
    
    
    // ========== Comprobantes Tipo (Plantillas) ==========

    /// <summary>
    /// Obtiene todos los comprobantes tipo
    /// </summary>
    Task<List<ComprobanteTipoDto>> GetVoucherTypesAsync(int empresaId);

    /// <summary>
    /// Obtiene una plantilla por ID con todos sus movimientos
    /// VB6: Usado en FrmComprobante.FEdit(IdComp, True)
    /// </summary>
    Task<ComprobanteTipoDetailDto?> GetVoucherTypeByIdAsync(int idComp, int empresaId);

    /// <summary>
    /// Carga datos desde un comprobante tipo
    /// </summary>
    Task<ComprobanteDto> LoadFromVoucherTypeAsync(int idCompTipo);

    /// <summary>
    /// Crea un nuevo comprobante tipo desde un comprobante existente
    /// </summary>
    Task<ComprobanteTipoDto> CreateVoucherTypeAsync(int empresaId, ComprobanteTipoCreateDto dto);

    /// <summary>
    /// Crea una plantilla desde el comprobante actual (VB6: Bt_NewCompTipo)
    /// </summary>
    Task<ComprobanteTipoDto> CreateVoucherTypeFromCurrentAsync(CreateVoucherTypeFromCurrentDto dto);

    /// <summary>
    /// Crea una plantilla directamente con movimientos (sin requerir comprobante origen)
    /// Usado desde formulario Comprobante en modo isTemplate=true
    /// </summary>
    Task<ComprobanteTipoDto> CreateVoucherTypeDirectAsync(ComprobanteTipoDirectCreateDto dto);

    /// <summary>
    /// Actualiza una plantilla existente
    /// VB6: Usado en FrmComprobante al guardar en modo plantilla
    /// </summary>
    Task<ComprobanteTipoDetailDto> UpdateVoucherTypeAsync(int idComp, int empresaId, ComprobanteTipoDirectCreateDto dto);


    // ========== Catálogos ==========

    /// <summary>
    /// Obtiene catálogos para dropdowns (áreas de negocio, centros de costo)
    /// </summary>
    Task<CatalogsDto> GetCatalogsAsync(int empresaId, short ano);
    
    
    // ========== Activo Fijo ==========
    
    /// <summary>
    /// Verifica si una cuenta es de Activo Fijo
    /// VB6: EsCuentaActFijo() - Valida Cuentas.Atrib bit ATRIB_ACTIVOFIJO
    /// </summary>
    Task<bool> IsCuentaActivoFijoAsync(int idCuenta);
    
    /// <summary>
    /// Obtiene las fichas de activo fijo asociadas a un comprobante
    /// VB6: FrmLstActFijo.FViewFromComp()
    /// </summary>
    Task<List<ActivoFijoMovimientoDto>> GetActivosFijosAsync(int idComp, int empresaId, short ano);
    
    /// <summary>
    /// Asocia una ficha de activo fijo a un comprobante
    /// VB6: ActivoFijo() - Crea registro en ActFijoCompsFicha
    /// </summary>
    Task<ActivoFijoMovimientoDto> AsignarActivoFijoAsync(AsignarActivoFijoDto dto);
    
    /// <summary>
    /// Elimina la asociación de activo fijo con comprobante
    /// </summary>
    Task RemoverActivoFijoAsync(int idCompFicha);
    
    /// <summary>
    /// Cuenta cuántas fichas de activo fijo tiene un comprobante
    /// VB6: CountActFijo() - Para validación
    /// </summary>
    Task<int> CountActivoFijoAsync(int idComp);
    
    
    // ========== Crear Documento desde Movimiento ==========
    
    /// <summary>
    /// Crea un nuevo documento y lo asocia al movimiento actual
    /// VB6: Bt_NewDoc_Click() - Detecta tipo desde glosa, crea FrmDoc.FNew()
    /// </summary>
    Task<GestionDocumentos.DocumentoDto> CreateDocumentFromMovimientoAsync(int idMov, CreateDocumentoFromMovimientoDto dto);
    
    
    // ========== Validaciones Adicionales ==========
    
    /// <summary>
    /// Verifica si una cuenta es de tipo banco (para impresión de cheques)
    /// VB6: ValidIdCtaBanco() - Valida Cuentas.Atrib bit ATRIB_CONCILIACION
    /// </summary>
    Task<bool> IsCuentaBancoAsync(int idCuenta);
    
    /// <summary>
    /// Valida si un movimiento proviene de centralización o pago automático
    /// VB6: Validación en Bt_BuscarDoc_Click y Bt_DelDoc_Click
    /// </summary>
    Task<bool> ValidarMovimientoEditable(int idMov);
    
    
    // ========== Notas de Movimientos ==========
    // VB6: M_AddNote_Click, M_EditNote_Click, M_ViewNote_Click, M_DelNote_Click (lines 4945-5020)
    
    /// <summary>
    /// Obtiene la nota de un movimiento
    /// </summary>
    Task<string?> GetMovimientoNotaAsync(int idMov);
    
    /// <summary>
    /// Agrega o actualiza la nota de un movimiento
    /// </summary>
    Task SaveMovimientoNotaAsync(int idMov, string? nota);

    /// <summary>
    /// Elimina la nota de un movimiento
    /// </summary>
    Task DeleteMovimientoNotaAsync(int idMov);
    
    
    // ========== Ver Detalle de Documento ==========
    // VB6: Bt_DetMov_Click (lines 1382-1412)
    
    /// <summary>
    /// Obtiene el detalle completo del documento asociado a un movimiento
    /// Redirecciona a GestionDocumentos
    /// </summary>
    Task<DocumentoDto?> GetDocumentoDetalleFromMovimientoAsync(int idMov);
    
    
    // ========== Validaciones Avanzadas ==========
    
    /// <summary>
    /// Valida que el comprobante cuadre (Debe = Haber) con tolerancia
    /// VB6: Valida() - ValidaCuadrado
    /// </summary>
    Task<(bool esValido, double diferencia)> ValidarComprobanteCuadradoAsync(int idComp);
    
    /// <summary>
    /// Valida que todos los movimientos tengan cuenta asignada
    /// VB6: Valida() - ValidaCtaMov
    /// </summary>
    Task<(bool esValido, List<int> movimientosSinCuenta)> ValidarMovimientosTienenCuentaAsync(int idComp);
    
    /// <summary>
    /// Valida que el comprobante tenga al menos un movimiento
    /// VB6: Valida() - ValidaCantMovimientos
    /// </summary>
    Task<bool> ValidarTieneMovimientosAsync(int idComp);
    
    /// <summary>
    /// Valida que la fecha del comprobante esté en período abierto
    /// VB6: Valida() - ValidaPeriodoAbierto
    /// </summary>
    Task<bool> ValidarPeriodoAbiertoAsync(DateTime fecha, int empresaId, short ano);
    
    /// <summary>
    /// Valida que si hay impresión de cheque, la cuenta sea de tipo banco
    /// VB6: Valida() - ValidaCuentaBanco para cheques
    /// </summary>
    Task<bool> ValidarCuentaBancoParaChequeAsync(int idCuenta);

    /// <summary>
    /// Navega entre comprobantes (first, prev, next, last)
    /// VB6: Bt_First_Click, Bt_Prev_Click, Bt_Next_Click, Bt_Last_Click
    /// </summary>
    Task<object> NavigateVoucherAsync(string? direction, int? currentId, int empresaId, short ano);

    /// <summary>
    /// Busca comprobantes con filtros
    /// VB6: Bt_Find_Click
    /// </summary>
    Task<List<VoucherSearchResultDto>> SearchVouchersAsync(VoucherSearchFilters filters);


    // ========== INTEGRACIÓN CON FEATURES EXISTENTES ==========

    /// <summary>
    /// Verifica si un movimiento tiene un activo fijo asociado
    /// VB6: CountActFijo() - línea 6223
    /// Integración con: \app\Features\GestionActivoFijo
    /// </summary>
    Task<bool> MovimientoTieneActivoFijoAsync(int idMov);

    /// <summary>
    /// Obtiene el ID del activo fijo asociado a un movimiento
    /// VB6: GridActivoFijo() - línea 6098
    /// Integración con: \app\Features\GestionActivoFijo
    /// </summary>
    Task<int?> GetIdActivoFijoByMovimientoAsync(int idMov);

    /// <summary>
    /// Prepara los datos para abrir la gestión de activo fijo desde un movimiento
    /// VB6: Bt_ActivoFijo_Click() - línea 1802
    /// Integración con: \app\Features\GestionActivoFijo
    /// </summary>
    Task<ActivoFijoIntegrationDto> PrepararActivoFijoAsync(int idMov);

    /// <summary>
    /// Prepara los datos para imprimir cheque desde comprobante
    /// VB6: Bt_PrtCheque_Click() - línea 1908
    /// Integración con: \app\Features\ImpresionCheques
    /// </summary>
    Task<ChequeIntegrationDto> PrepararImpresionChequeAsync(PrepararChequeDto dto);

    /// <summary>
    /// Valida que los movimientos seleccionados puedan imprimir cheque
    /// VB6: Validaciones en Bt_PrtCheque_Click()
    /// Integración con: \app\Features\ImpresionCheques
    /// Lanza BusinessException si hay errores de validación
    /// </summary>
    Task ValidarMovimientosParaChequeAsync(List<int> idMovimientos);

    /// <summary>
    /// Prepara datos para crear un nuevo documento desde un movimiento
    /// VB6: Bt_NewDoc_Click() - líneas 1615-1706
    /// Integración con: \app\Features\GestionDocumentos
    /// </summary>
    Task<CrearDocumentoIntegrationDto> PrepararCrearDocumentoAsync(int idMov);

    /// <summary>
    /// Prepara datos para ver el detalle de un documento asociado a un movimiento
    /// VB6: Bt_DetMov_Click() - líneas 1382-1410
    /// Integración con: \app\Features\GestionDocumentos
    /// </summary>
    Task<VerDocumentoIntegrationDto> PrepararVerDocumentoAsync(int idMov);

    // ========== CENTRALIZACIONES ==========

    /// <summary>
    /// Verifica si un comprobante es de centralización completa
    /// VB6: ValidaCompFull() - líneas 6600-6619
    /// </summary>
    Task<bool> EsCentralizacionFullAsync(int idComp, int empresaId, short ano);

    /// <summary>
    /// Marca un comprobante como centralización completa
    /// VB6: InsertComprCentraFull() - líneas 6582-6598
    /// </summary>
    Task MarcarComoCentralizacionFullAsync(int idComp, int empresaId, short ano);

    /// <summary>
    /// Calcula los totales completos de un comprobante (incluyendo todos los movimientos guardados)
    /// VB6: CalcTotFull() - líneas 6526-6580
    /// </summary>
    Task<TotalesCentralizacionDto> CalcularTotalesFullAsync(int idComp, int empresaId, short ano);

    /// <summary>
    /// Deja en cero todos los movimientos de un comprobante (usado al anular)
    /// VB6: DejarEnCeroMovs() - líneas 6337-6358
    /// </summary>
    Task DejarEnCeroMovimientosAsync(int idComp, int empresaId);


    // ========== NUEVO DOCUMENTO (Modal Inline) ==========

    /// <summary>
    /// Obtiene tipos de documento filtrados por tipo de libro
    /// VB6: FrmDoc - carga de combo TipoDoc basado en TipoLib
    /// </summary>
    Task<List<TipoDocumentoDto>> GetTiposDocumentoAsync(int tipoLib, int empresaId);

    /// <summary>
    /// Busca una entidad por RUT
    /// VB6: FrmDoc - búsqueda en entidades para autocompletar nombre
    /// </summary>
    Task<EntidadBusquedaDto?> BuscarEntidadPorRutAsync(string? rut, int empresaId);

    /// <summary>
    /// Crea un nuevo documento desde el modal inline
    /// VB6: FrmDoc.FNew() - Crea documento y retorna para asociar a movimiento
    /// </summary>
    Task<DocumentoCreatedDto> CrearDocumentoAsync(int empresaId, short ano, int usuarioId, CrearDocumentoDto dto);
}
