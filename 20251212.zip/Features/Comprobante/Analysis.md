# Legacy Analysis: Nuevo Comprobante

## 📄 Información del Formulario VB6

**Archivo VB6:** `old/Contabilidad70/HyperContabilidad/FrmComprobante.frm`
**Fecha Análisis:** 2025-09-29
**Analista:** IA Assistant
**Complejidad:** Alta

### Propósito del Formulario
Este formulario permite crear y editar comprobantes contables (asientos contables). Es uno de los formularios más complejos del sistema, ya que maneja la entrada de datos de los movimientos contables, asociación con documentos, cuentas, áreas de negocio, centros de costo, y múltiples validaciones y cálculos. El formulario también maneja comprobantes tipo (plantillas) y tiene funcionalidades avanzadas como pago automático de documentos y generación de cheques.

---

## 🎨 CONTROLES UI IDENTIFICADOS

### Textboxes (Campos de Entrada)
| Control VB6 | Propiedad Bound | Tipo | Validación | Propósito |
|-------------|----------------|------|------------|-----------|
| Tx_IdComp | Comprobante.IdComp | Integer | ReadOnly | ID único del comprobante |
| Tx_Correlativo | Comprobante.Correlativo | Integer | ReadOnly | Número correlativo |
| Tx_Fecha | Comprobante.Fecha | Date | Required, DateValid | Fecha del comprobante |
| Tx_Glosa | Comprobante.Glosa | String | MaxLen=100 | Descripción general del comprobante |
| Tx_Usuario | Usuario.Nombre | String | ReadOnly | Usuario que creó el comprobante |
| Tx_NombCompTipo | ComprobanteTipo.Nombre | String | MaxLen=15 | Nombre del comprobante tipo |
| Tx_Descrip | ComprobanteTipo.Descripcion | String | MaxLen=40 | Descripción del comprobante tipo |
| Tx_Nombre | ComprobanteTipo.NombreCorto | String | MaxLen=15 | Nombre corto comprobante tipo |
| Tx_GlosaCompTipo | ComprobanteTipo.Glosa | String | MaxLen=100 | Glosa del comprobante tipo |

### ComboBoxes (Listas Desplegables)
| Control VB6 | Fuente Datos | Valor | Display | Evento Change |
|-------------|--------------|-------|---------|---------------|
| Cb_Tipo | Hardcoded | 1-4 | Egreso/Ingreso/Traspaso/Apertura | Cambia validaciones |
| Cb_Estado | Hardcoded | 1-4 | Anulado/Aprobado/Pendiente/Erróneo | Controla edición |
| Cb_TipoCompTipo | Hardcoded | 1-4 | Tipos comprobante | Para plantillas |

### Grillas (FlexGrid)
| Control VB6 | Fuente Datos | Columnas | Eventos | Acciones |
|-------------|--------------|----------|---------|----------|
| Grid | MovComprobante + Joins | 24 cols: IdMov, Orden, Cuenta, Debe, Haber, Glosa, etc. | BeforeEdit, AcceptValue | Edición inline de movimientos |
| GridTot | Calculado | Totales Debe/Haber | None | Solo muestra totales |
| GridTotFull | Calculado | Totales completos | None | Muestra totales paginados |

### CheckBoxes y OptionButtons
| Control VB6 | Propiedad Bound | Evento Change | Propósito |
|-------------|----------------|---------------|-----------|
| Ch_ImpRes | Comprobante.ImpResumido | Click | Impresión resumida |
| Ch_OtrosIngEg14TER | Comprobante.OtrosIngEg14TER | Click | Otros ingresos/egresos 14TER |
| Op_TAjuste(1-3) | Comprobante.TipoAjuste | Click | Tipo ajuste: Financiero/Tributario/Ambos |

### Botones de Acción
| Botón VB6 | Caption | Habilitado Si | Acción | Mapeo .NET |
|-----------|---------|---------------|--------|------------|
| Bt_OK | "Aceptar" | Form válido | Valida y guarda comprobante | SaveAsync() |
| Bt_Cancel | "Cancelar" | Siempre | Cancela y cierra | N/A (navegación) |
| Bt_Salir | "Cerrar" | Siempre | Cierra formulario | N/A (navegación) |
| Bt_Duplicate | Icon | Movimiento seleccionado | Duplica movimiento | DuplicateMovementAsync() |
| Bt_Del | Icon | Movimiento seleccionado | Elimina movimiento | DeleteMovementAsync() |
| Bt_MoveUp | Icon | No primer movimiento | Mueve movimiento arriba | ReorderMovementAsync() |
| Bt_MoveDown | Icon | No último movimiento | Mueve movimiento abajo | ReorderMovementAsync() |
| Bt_Copy | Icon | Movimiento seleccionado | Copia valor a clipboard | CopyValueAsync() |
| Bt_Paste | Icon | Clipboard con datos | Pega valor de clipboard | PasteValueAsync() |
| Bt_Sum | Icon | Movimientos seleccionados | Suma movimientos | SumMovementsAsync() |
| Bt_Cuadrar | Icon | Comprobante descuadrado | Cuadra automáticamente | BalanceVoucherAsync() |
| Bt_NewDoc | Icon | Movimiento seleccionado | Crea nuevo documento | CreateDocumentAsync() |
| Bt_GenPago | Icon | Siempre | Genera pago automático | GeneratePaymentAsync() |
| Bt_BuscarDoc | Icon | Movimiento seleccionado | Busca documento existente | SearchDocumentAsync() |
| Bt_DelDoc | Icon | Movimiento con documento | Elimina asociación documento | RemoveDocumentAsync() |
| Bt_DetMov | Icon | Movimiento con documento | Ver detalle documento | ViewDocumentDetailAsync() |
| Bt_ActivoFijo | Icon | Cuenta activo fijo | Gestiona activo fijo | ManageFixedAssetAsync() |
| Bt_Cuentas | Icon | Siempre | Abre plan de cuentas | OpenChartOfAccountsAsync() |
| Bt_ConvMoneda | Icon | Valor numérico | Convierte moneda | ConvertCurrencyAsync() |
| Bt_Calc | Icon | Siempre | Abre calculadora | OpenCalculatorAsync() |
| Bt_Calendar | Icon | Campo fecha | Abre calendario | OpenCalendarAsync() |
| Bt_Preview | Icon | Comprobante válido | Vista previa impresión | PreviewAsync() |
| Bt_Print | Icon | Comprobante válido | Imprime comprobante | PrintAsync() |
| Bt_CopyExcel | Icon | Siempre | Copia a Excel | ExportToExcelAsync() |
| Bt_PrtCheque | "Imprimir Cheque..." | Comprobante de pago | Imprime cheque | PrintCheckAsync() |
| Bt_Glosas(0) | Icon | Siempre | Selecciona glosa principal | SelectGlossAsync() |
| Bt_Glosas(1) | Icon | Comprobante tipo | Selecciona glosa tipo | SelectGlossAsync() |
| Bt_SelFecha | Icon | Siempre | Selecciona fecha | SelectDateAsync() |
| Bt_CompTipo | Icon | Siempre | Selecciona comprobante tipo | SelectVoucherTypeAsync() |
| Bt_SelCompTipo | Icon | Siempre | Busca comprobante tipo | SearchVoucherTypeAsync() |
| Bt_NewCompTipo | Icon | Comprobante válido | Crea comprobante tipo | CreateVoucherTypeAsync() |

### Otros Controles
| Tipo Control | Nombre | Propósito | Eventos |
|--------------|--------|-----------|---------|
| Frame | Fr_Header(0) | Agrupa controles encabezado normal | N/A |
| Frame | Fr_Header(1) | Agrupa controles encabezado tipo | N/A |
| Frame | Fr_SelCompTipo | Agrupa controles comprobante tipo | N/A |
| Frame | Fr_Doc | Agrupa botones de documentos | N/A |
| Frame | Fr_TAjuste | Agrupa opciones tipo ajuste | N/A |
| Frame | fr_Paginacion | Controles paginación SQL Server | N/A |

---

## 🔘 EVENTOS IDENTIFICADOS

### Eventos de Formulario
| Evento VB6 | Cuándo Ocurre | Acciones | Mapeo .NET |
|------------|---------------|----------|------------|
| Form_Load | Al abrir form | Cargar combos, inicializar grilla, cargar datos | InitializeAsync(), LoadDataAsync() |
| Form_Activate | Al recibir foco | Habilitar controles, enfocar campo | N/A (onFocus JS) |
| Form_Resize | Al cambiar tamaño | Redimensionar controles | N/A (CSS responsive) |
| Form_Unload | Al cerrar | Validar si guardar, liberar locks | BeforeUnloadAsync() |

### Eventos de Botones
[Ya documentados en tabla de Botones arriba]

### Eventos de Grilla
| Control.Evento | Trigger | Acción VB6 | Mapeo .NET |
|----------------|---------|------------|------------|
| Grid.BeforeEdit | Antes editar celda | Validar si puede editar, configurar editor | ValidateEditAsync() |
| Grid.AcceptValue | Después editar celda | Validar valor, actualizar datos relacionados | AcceptValueAsync() |
| Grid.Click | Click en celda | Seleccionar movimiento, actualizar botones | SelectMovementAsync() |
| Grid.DblClick | Doble click | Editar celda o abrir detalle | EditCellAsync() |

### Eventos de Controles
| Control.Evento | Trigger | Acción VB6 | Mapeo .NET |
|----------------|---------|------------|------------|
| Tx_Fecha.LostFocus | Pierde foco | Validar fecha, actualizar estado | ValidateDateAsync() |
| Cb_Tipo.Click | Selecciona tipo | Cambiar validaciones | UpdateValidationsAsync() |
| Cb_Estado.Click | Selecciona estado | Habilitar/deshabilitar edición | UpdateFormStateAsync() |
| Ch_ImpRes.Click | Toggle checkbox | Marcar para impresión resumida | ToggleResumedPrintAsync() |
| Ch_OtrosIngEg14TER.Click | Toggle checkbox | Marcar otros ingresos/egresos | ToggleOtherIncomeAsync() |

---

## 🔧 FUNCIONES Y PROCEDIMIENTOS VB6

### Funciones Públicas
```vb
' Función: FNew
' Propósito: Crear un nuevo comprobante
' Parámetros: IdEmpresa, Fecha, Tipo opcional
' Retorno: Integer (vbOK/vbCancel)
' Mapeo .NET: CreateAsync() en Service
Friend Function FNew(Optional ByVal IdEmpresa As Long = 0, Optional ByVal Fecha As Long = 0, Optional ByVal Tipo As Integer = 0) As Integer
```

```vb
' Función: FEdit
' Propósito: Editar un comprobante existente
' Parámetros: IdComp
' Retorno: Integer (vbOK/vbCancel)
' Mapeo .NET: EditAsync() en Service
Friend Function FEdit(ByVal IdComp As Long) As Integer
```

```vb
' Función: FView
' Propósito: Ver un comprobante (solo lectura)
' Parámetros: IdComp
' Retorno: Integer (vbOK/vbCancel)
' Mapeo .NET: ViewAsync() en Service
Friend Function FView(ByVal IdComp As Long) As Integer
```

### Funciones Privadas
```vb
' Función: SaveAll
' Propósito: Guardar comprobante y movimientos
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: SaveAsync() en Service
Private Sub SaveAll()
```

```vb
' Función: LoadAll
' Propósito: Cargar datos del comprobante
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: LoadDataAsync() en Service
Private Sub LoadAll()
```

```vb
' Función: CalcTot
' Propósito: Calcular totales debe/haber
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: CalculateTotalsAsync() en Service
Private Sub CalcTot()
```

```vb
' Función: ValidarDatos
' Propósito: Validar datos antes de guardar
' Parámetros: Ninguno
' Retorno: Boolean (True si válido)
' Mapeo .NET: ValidateAsync() en Service
Private Function ValidarDatos() As Boolean
```

### Lista Completa de Funciones
| Función VB6 | Tipo | Propósito | Mapeo .NET Method |
|-------------|------|-----------|-------------------|
| SaveAll() | Private Sub | Guardar comprobante completo | SaveAsync() |
| LoadAll() | Private Sub | Cargar datos comprobante | LoadDataAsync() |
| CalcTot() | Private Sub | Calcular totales | CalculateTotalsAsync() |
| CalcTotFull() | Private Sub | Calcular totales paginados | CalculateFullTotalsAsync() |
| ValidarDatos() | Private Function→Boolean | Validar antes guardar | ValidateAsync() |
| AsignarDoc() | Private Sub | Asignar documento a movimiento | AssignDocumentAsync() |
| AsignarLstDoc() | Private Sub | Asignar lista documentos | AssignDocumentListAsync() |
| DelMov() | Private Sub | Eliminar movimiento | DeleteMovementAsync() |
| GridActivoFijo() | Private Sub | Manejar cuenta activo fijo | HandleFixedAssetAsync() |
| GridAtribCuenta() | Private Sub | Manejar atributos cuenta | HandleAccountAttributesAsync() |
| FillCompTipo() | Private Sub | Llenar desde comprobante tipo | FillFromVoucherTypeAsync() |
| SetUpGrid() | Private Sub | Configurar grilla | SetupGridAsync() |
| FillCombosFrm() | Private Sub | Llenar combos formulario | LoadCombosAsync() |

---

## 💾 ACCESO A DATOS VB6

### Query 1: Cargar Comprobante
```vb
' Ubicación: LoadAll()
' Tablas: Comprobante
Q1 = "SELECT * FROM Comprobante WHERE IdComp = " & lidComp & " AND IdEmpresa = " & gEmpresa.id
```

**Mapeo Entity Framework:**
```csharp
var comprobante = await _context.Comprobante
    .Where(c => c.IdComp == id && c.IdEmpresa == empresaId)
    .FirstOrDefaultAsync();
```

### Query 2: Cargar Movimientos
```vb
' Ubicación: LoadAll()
' Tablas: MovComprobante + Cuentas + AreaNegocio + CentroCosto + Documento + Entidades
Q1 = "SELECT MovComprobante.*, Cuentas.Codigo as CodCta, Cuentas.Descripcion as DescCta, " &
     "AreaNegocio.Descripcion as DescAreaNeg, CentroCosto.Descripcion as DescCCosto, " &
     "Documento.NumDoc, Documento.TipoLib, Documento.TipoDoc, Entidades.Nombre as NombEnt " &
     "FROM MovComprobante " &
     "LEFT JOIN Cuentas ON MovComprobante.IdCuenta = Cuentas.idCuenta " &
     "LEFT JOIN AreaNegocio ON MovComprobante.idAreaNeg = AreaNegocio.IdAreaNeg " &
     "LEFT JOIN CentroCosto ON MovComprobante.idCCosto = CentroCosto.IdCCosto " &
     "LEFT JOIN Documento ON MovComprobante.IdDoc = Documento.IdDoc " &
     "LEFT JOIN Entidades ON Documento.IdEntidad = Entidades.IdEntidad " &
     "WHERE MovComprobante.IdComp = " & lidComp & " AND MovComprobante.IdEmpresa = " & gEmpresa.id &
     "ORDER BY MovComprobante.Orden"
```

**Mapeo Entity Framework:**
```csharp
var movimientos = await _context.MovComprobante
    .Where(m => m.IdComp == idComp && m.IdEmpresa == empresaId)
    .Include(m => m.Cuenta)
    .Include(m => m.AreaNegocio)
    .Include(m => m.CentroCosto)
    .Include(m => m.Documento)
        .ThenInclude(d => d.Entidad)
    .OrderBy(m => m.Orden)
    .Select(m => new MovimientoDto
    {
        IdMov = m.IdMov,
        Orden = m.Orden,
        CodigoCuenta = m.Cuenta.Codigo,
        NombreCuenta = m.Cuenta.Descripcion,
        Debe = m.Debe,
        Haber = m.Haber,
        Glosa = m.Glosa,
        AreaNegocio = m.AreaNegocio.Descripcion,
        CentroCosto = m.CentroCosto.Descripcion,
        NumeroDocumento = m.Documento.NumDoc,
        NombreEntidad = m.Documento.Entidad.Nombre
    })
    .ToListAsync();
```

### Query 3: Guardar Comprobante Nuevo
```vb
' Ubicación: SaveAll() - modo nuevo
Q1 = "INSERT INTO Comprobante (IdEmpresa, Ano, Correlativo, Fecha, Tipo, Estado, Glosa, IdUsuario) " &
     "VALUES (" & gEmpresa.id & ", " & gEmpresa.Ano & ", " & lCorrelativo & ", " & 
     GetTxDate(Tx_Fecha) & ", " & CbItemData(Cb_Tipo) & ", " & CbItemData(Cb_Estado) & 
     ", '" & ParaSQL(Tx_Glosa) & "', " & gUsuario.id & ")"
```

**Mapeo Entity Framework:**
```csharp
var comprobante = new App.Data.Comprobante
{
    IdEmpresa = empresaId,
    Ano = año,
    Correlativo = correlativo,
    Fecha = DateHelper.ToDbDate(dto.Fecha),
    Tipo = dto.Tipo,
    Estado = dto.Estado,
    Glosa = dto.Glosa,
    IdUsuario = usuarioId,
    FechaCreacion = DateHelper.ToDbDate(DateTime.Now),
    TotalDebe = dto.TotalDebe,
    TotalHaber = dto.TotalHaber
};
_context.Comprobante.Add(comprobante);
await _context.SaveChangesAsync();
```

### Query 4: Guardar Movimientos
```vb
' Ubicación: SaveAll()
For i = Grid.FixedRows To Grid.rows - 1
    If Grid.TextMatrix(i, C_ORDEN) <> "" And Grid.RowHeight(i) > 0 Then
        If Grid.TextMatrix(i, C_UPDATE) = FGR_I Then ' Nuevo
            Q1 = "INSERT INTO MovComprobante (IdEmpresa, Ano, IdComp, Orden, IdCuenta, Debe, Haber, Glosa) " &
                 "VALUES (" & gEmpresa.id & ", " & gEmpresa.Ano & ", " & lidComp & ", " & Grid.TextMatrix(i, C_ORDEN) &
                 ", " & Grid.TextMatrix(i, C_IDCUENTA) & ", " & vFmt(Grid.TextMatrix(i, C_DEBE)) & 
                 ", " & vFmt(Grid.TextMatrix(i, C_HABER)) & ", '" & ParaSQL(Grid.TextMatrix(i, C_GLOSA)) & "')"
        End If
    End If
Next i
```

**Mapeo Entity Framework:**
```csharp
foreach (var movDto in dto.Movimientos)
{
    if (movDto.IsNew)
    {
        var movimiento = new App.Data.MovComprobante
        {
            IdEmpresa = empresaId,
            Ano = año,
            IdComp = comprobante.IdComp,
            Orden = movDto.Orden,
            IdCuenta = movDto.IdCuenta,
            Debe = movDto.Debe,
            Haber = movDto.Haber,
            Glosa = movDto.Glosa,
            idAreaNeg = movDto.IdAreaNegocio,
            idCCosto = movDto.IdCentroCosto,
            IdDoc = movDto.IdDocumento
        };
        _context.MovComprobante.Add(movimiento);
    }
}
await _context.SaveChangesAsync();
```

---

## ✅ VALIDACIONES Y REGLAS DE NEGOCIO

### Validaciones de Campos
| Campo | Regla | Mensaje Error VB6 | Implementar en .NET |
|-------|-------|-------------------|---------------------|
| Tx_Fecha | Obligatorio | "Debe ingresar una fecha válida" | [Required] + ValidateDateAsync() |
| Tx_Fecha | Fecha válida | "Fecha inválida" | DateTime parsing |
| Tx_Fecha | Mes no cerrado | "No se puede ingresar comp. en mes cerrado" | ValidateOpenPeriodAsync() |
| Tx_Glosa | Obligatorio | "Debe ingresar una glosa" | [Required] |
| Tx_Glosa | Máximo 100 chars | N/A | [MaxLength(100)] |
| Cb_Tipo | Seleccionado | "Debe seleccionar un tipo" | [Required] |
| Cb_Estado | Seleccionado | "Debe seleccionar un estado" | [Required] |
| Grid Debe/Haber | No negativo | "El valor no puede ser negativo" | [Range(0, double.MaxValue)] |
| Grid Cuenta | Existe y último nivel | "Cuenta no existe o no es de último nivel" | ValidateAccountAsync() |

### Reglas de Negocio
1. **Comprobante debe estar cuadrado**: Total Debe = Total Haber
   ```vb
   If Abs(SumDebe - SumHaber) > 0.01 Then
       MsgBox1 "El comprobante no está cuadrado. Diferencia: " & Format(SumDebe - SumHaber, BL_NUMFMT)
       Exit Function
   End If
   ```
   **→ Implementar:** `ValidateBalanceAsync()` - verificar que debe = haber

2. **Al menos un movimiento obligatorio**: Debe tener mínimo una línea con cuenta
   **→ Implementar:** `ValidateMinimumMovementsAsync()`

3. **No debe y haber simultáneos**: En una línea no puede haber valor en debe Y haber
   ```vb
   If vFmt(Grid.TextMatrix(Row, C_DEBE)) <> 0 And vFmt(Grid.TextMatrix(Row, C_HABER)) <> 0 Then
       Grid.TextMatrix(Row, C_HABER) = ""  ' Limpia el haber si se ingresa debe
   End If
   ```
   **→ Implementar:** Validación en cliente JavaScript y servidor

4. **Validación mes abierto**: No permitir comprobantes en meses cerrados
   **→ Implementar:** `ValidateOpenPeriodAsync(fecha, empresaId)`

5. **Número correlativo único**: Asignar automáticamente el próximo correlativo disponible
   **→ Implementar:** `GetNextCorrelativeAsync(empresaId, año, tipo)`

---

## 🧮 CÁLCULOS Y FÓRMULAS

### Cálculo 1: Totales Debe/Haber
```vb
' Dónde: CalcTot(), Grid.AcceptValue
' Fórmula: SUM de columnas Debe y Haber en grilla
SumDebe = 0: SumHaber = 0
For i = 1 To Grid.rows - 1
    If Grid.RowHeight(i) > 0 Then
        SumDebe = SumDebe + vFmt(Grid.TextMatrix(i, C_DEBE))
        SumHaber = SumHaber + vFmt(Grid.TextMatrix(i, C_HABER))
    End If
Next i
GridTot.TextMatrix(0, C_DEBE) = Format(SumDebe, BL_NUMFMT)
GridTot.TextMatrix(0, C_HABER) = Format(SumHaber, BL_NUMFMT)
```
**→ Implementar:** `CalculateTotalsAsync()` sumar debe/haber de todos los movimientos

### Cálculo 2: Cuadre Automático
```vb
' Dónde: Bt_Cuadrar_Click
' Fórmula: Calcular diferencia y sugerir valor para cuadrar
Diff = SumDebe - SumHaber
If Diff < 0 Then
    Grid.TextMatrix(Row, C_DEBE) = Format(Abs(Diff), BL_NUMFMT)  ' Falta debe
Else
    Grid.TextMatrix(Row, C_HABER) = Format(Diff, BL_NUMFMT)      ' Falta haber
End If
```
**→ Implementar:** `BalanceVoucherAsync()` calcular valor faltante para cuadrar

### Cálculo 3: Próximo Correlativo
```vb
' Dónde: Nuevo comprobante
' Fórmula: Obtener máximo correlativo + 1
Q1 = "SELECT MAX(Correlativo) FROM Comprobante WHERE IdEmpresa = " & gEmpresa.id & " AND Ano = " & gEmpresa.Ano & " AND Tipo = " & Tipo
lCorrelativo = vFld(Rs(0)) + 1
```
**→ Implementar:** `GetNextCorrelativeAsync(empresaId, año, tipo)`

---

## 🚀 NAVEGACIÓN Y FLUJO

### Formularios Llamados
| Desde VB6 | Formulario Destino | Parámetros | Retorno | Mapeo .NET |
|-----------|-------------------|------------|---------|------------|
| Bt_Cuentas_Click | FrmPlanCuentas.frm | Ninguno | Cuenta seleccionada | Modal /PlanCuentas |
| Bt_BuscarDoc_Click | FrmLstDoc.frm | TipoLib, Estado | Lista documentos | Modal /DocumentosBuscar |
| Bt_NewDoc_Click | FrmDoc.frm | Nuevo | IdDoc creado | Modal /DocumentosNuevo |
| Bt_DetMov_Click | FrmDoc.frm | IdDoc | Ninguno | Modal /DocumentosDetalle/{id} |
| Bt_GenPago_Click | FrmLstDoc.frm | Selección múltiple | Lista documentos | Modal /DocumentosPago |
| Bt_ActivoFijo_Click | FrmLstActFijo.frm | IdComp, IdMov | Ninguno | Modal /ActivoFijo |
| Bt_ConvMoneda_Click | FrmConverMoneda.frm | Valor inicial | Valor convertido | Modal /ConversionMoneda |
| Bt_Calc_Click | Calculator | Ninguno | Ninguno | window.open calculator |
| Bt_Calendar_Click | FrmCalendar.frm | Fecha actual | Fecha seleccionada | DatePicker JS |
| Bt_Glosas_Click | FrmGlosas.frm | Ninguno | Glosa seleccionada | Modal /Glosas |
| Bt_CompTipo_Click | FrmSelCompTipo.frm | Ninguno | IdCompTipo | Modal /ComprobantesTipo |

### Flujo de Estados del Form
```
[Nuevo] → Form_Load() → [Estado: Editando]
  ↓
[Ingresar movimientos] → Grid.AcceptValue() → [Validar y calcular]
  ↓
[Bt_OK] → ValidarDatos() → SaveAll() → [Estado: Guardado] → Cerrar

[Editar existente] → Form_Load() → LoadAll() → [Estado: Editando]
  ↓
[Modificar datos] → Grid.AcceptValue() → [Actualizar cálculos]
  ↓
[Bt_OK] → ValidarDatos() → SaveAll() → [Estado: Guardado] → Cerrar

[Ver solo lectura] → Form_Load() → LoadAll() → [Estado: Solo lectura]
  ↓
[Bt_Salir] → Cerrar (sin cambios)
```

---

## 📊 EXPORTACIONES E IMPORTACIONES

### Exportación a Excel
```vb
' Botón: Bt_CopyExcel_Click
' Formato: Datos de grilla con encabezado
Call FGr2Clip(Grid, "Número comprobante: " & Tx_Correlativo & " Tipo: " & Cb_Tipo & " Estado: " & Cb_Estado & " Fecha: " & Tx_Fecha)
```
**→ Implementar:** `ExportToExcelAsync()` usando EPPlus con datos del comprobante

### Impresión
```vb
' Botón: Bt_Print_Click y Bt_Preview_Click
' Formato: Reporte formal del comprobante con totales
```
**→ Implementar:** `GenerateReportAsync()` para PDF/impresión

### Impresión de Cheques
```vb
' Botón: Bt_PrtCheque_Click
' Condición: Solo para comprobantes de pago con cuentas banco
```
**→ Implementar:** `PrintCheckAsync()` (funcionalidad legacy, documentar como [LEGACY])

---

## 🎯 MAPEO FINAL: MÉTODOS .NET DETERMINADOS

### Interface del Service
```csharp
public interface INuevoComprobanteService
{
    // CRUD Principal
    Task<ComprobanteDto> CreateAsync(int empresaId, ComprobanteCreateDto dto);
    Task<ComprobanteDto> UpdateAsync(int id, ComprobanteUpdateDto dto);
    Task<ComprobanteDto> GetByIdAsync(int id);
    Task<bool> DeleteAsync(int id);

    // Operaciones de Comprobante
    Task<int> GetNextCorrelativeAsync(int empresaId, int año, int tipo);
    Task<ValidationResult> ValidateAsync(ComprobanteCreateDto dto);
    Task<bool> ValidateBalanceAsync(List<MovimientoDto> movimientos);
    Task<bool> ValidateOpenPeriodAsync(DateTime fecha, int empresaId);
    Task<ComprobanteDto> BalanceVoucherAsync(int id, int movimientoIndex);
    
    // Operaciones de Movimientos
    Task<MovimientoDto> AddMovementAsync(int idComp, MovimientoCreateDto dto);
    Task<MovimientoDto> UpdateMovementAsync(int id, MovimientoUpdateDto dto);
    Task<bool> DeleteMovementAsync(int id);
    Task<MovimientoDto> DuplicateMovementAsync(int id);
    Task<bool> ReorderMovementAsync(int id, bool moveUp);
    
    // Cálculos
    Task<TotalesDto> CalculateTotalsAsync(int idComp);
    Task<decimal> SumMovementsAsync(List<int> movimientosIds);
    
    // Documentos
    Task<bool> AssignDocumentAsync(int idMovimiento, int idDocumento);
    Task<bool> RemoveDocumentAsync(int idMovimiento);
    Task<List<DocumentoDto>> SearchDocumentsAsync(int tipoLib, int estado);
    Task<ComprobanteDto> GeneratePaymentAsync(int idComp, List<int> documentosIds);
    
    // Cuentas y Plan de Cuentas
    Task<CuentaDto> ValidateAccountAsync(string codigo, string nombre);
    Task<List<CuentaDto>> SearchAccountsAsync(string searchTerm);
    
    // Utilitarios
    Task<decimal> ConvertCurrencyAsync(decimal amount, string fromCurrency, string toCurrency);
    Task<List<GlosaDto>> GetGlossariesAsync();
    Task<byte[]> ExportToExcelAsync(int idComp);
    Task<byte[]> GenerateReportAsync(int idComp, bool resumido = false);
    
    // Comprobantes Tipo
    Task<List<ComprobanteTipoDto>> GetVoucherTypesAsync();
    Task<ComprobanteDto> LoadFromVoucherTypeAsync(int idCompTipo);
    Task<ComprobanteTipoDto> CreateVoucherTypeAsync(int idComp, ComprobanteTipoCreateDto dto);
}
```

### Resumen de Mapeo
| Funcionalidad VB6 | Método .NET | Complejidad | Prioridad |
|-------------------|-------------|-------------|-----------|
| Form_Load + LoadAll | GetByIdAsync(), GetNextCorrelativeAsync() | Alta | Alta |
| SaveAll() | CreateAsync() / UpdateAsync() | Alta | Alta |
| CalcTot() | CalculateTotalsAsync() | Media | Alta |
| ValidarDatos() | ValidateAsync(), ValidateBalanceAsync() | Alta | Alta |
| Grid.AcceptValue | UpdateMovementAsync() | Media | Alta |
| Bt_Cuadrar_Click | BalanceVoucherAsync() | Media | Media |
| Bt_Duplicate_Click | DuplicateMovementAsync() | Baja | Media |
| Bt_Del_Click | DeleteMovementAsync() | Baja | Media |
| Bt_BuscarDoc_Click | SearchDocumentsAsync(), AssignDocumentAsync() | Media | Media |
| Bt_GenPago_Click | GeneratePaymentAsync() | Alta | Baja |
| Bt_ConvMoneda_Click | ConvertCurrencyAsync() | Media | Baja |
| Bt_CopyExcel_Click | ExportToExcelAsync() | Media | Baja |
| Bt_Print_Click | GenerateReportAsync() | Alta | Media |

---

## ⚠️ NOTAS IMPORTANTES Y OBSERVACIONES

### Peculiaridades del Form VB6
- Usa variables globales `gEmpresa`, `gUsuario` para contexto
- Maneja paginación para SQL Server (control `fr_Paginacion`)
- Estados: 1=Anulado, 2=Aprobado, 3=Pendiente, 4=Erróneo
- Tipos: 1=Egreso, 2=Ingreso, 3=Traspaso, 4=Apertura
- Fechas almacenadas como enteros (yyyymmdd)
- Montos con formato `BL_NUMFMT` (separadores de miles)
- Grilla con 24 columnas, algunas ocultas
- Validación de cuentas de activo fijo especial
- Integración con módulos de documentos, libros auxiliares

### Decisiones de Diseño
- **Async Pattern**: Todas las operaciones de BD async
- **Validación Doble**: Cliente (JS) y servidor (.NET)
- **Estados Enum**: Crear enums para Estados y Tipos
- **Responsive UI**: Grilla adaptable con scroll horizontal
- **Modal Dialogs**: Para selección de cuentas, documentos, etc.
- **Real-time Validation**: Validar balance mientras se ingresa
- **Auto-save**: Opcional guardar automáticamente cada cierto tiempo

### Pendientes/Incompletos en VB6
- Botón "Imprimir Cheque" existe pero funcionalidad limitada → **MIGRAR**: Incluir con TODO [LEGACY] [LOW] [BLOCKED_BY: PRINTER_INTEGRATION]
- Paginación SQL Server solo visible si necesario → **MIGRAR**: Implementar paginación moderna
- Comprobantes Tipo funcionales pero poco usados → **MIGRAR**: Mantener funcionalidad completa
- Módulo Activo Fijo integrado → **MIGRAR**: Incluir con TODO [BLOCKED] [MEDIUM] [BLOCKED_BY: ACTIVO_FIJO_MODULE]

---

## ✅ CHECKLIST DE COMPLETITUD DEL ANÁLISIS

- [x] Todos los controles UI documentados
- [x] Todos los botones y eventos mapeados
- [x] **TODOS los botones tienen "Mapeo .NET" definido** 
- [x] **Botones con excepciones documentan razón válida** (LEGACY, BLOCKED)
- [x] Todas las funciones VB6 identificadas
- [x] Todos los queries SQL traducidos a EF Core
- [x] Todas las validaciones documentadas
- [x] Todas las reglas de negocio identificadas
- [x] Todos los cálculos documentados
- [x] Navegación y flujos mapeados
- [x] Métodos .NET determinados
- [x] Interface del Service definida
- [x] **Decisiones de excepción justificadas y estructuradas**

---

**✅ ANÁLISIS COMPLETO - LISTO PARA IMPLEMENTACIÓN**