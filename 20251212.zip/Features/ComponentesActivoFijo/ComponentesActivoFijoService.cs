using App.Data;
using App.Exceptions;
using Microsoft.EntityFrameworkCore;

namespace App.Features.ComponentesActivoFijo;

public class ComponentesActivoFijoService(LpContabContext context, ILogger<ComponentesActivoFijoService> logger) : IComponentesActivoFijoService
{
    public async Task<ComponentesActivoFijoDto?> GetDatosActivoFijoAsync(int idActFijo, int empresaId, short ano)
    {
        logger.LogInformation("Getting datos activo fijo for IdActFijo: {IdActFijo}, EmpresaId: {EmpresaId}, Ano: {Ano}",
            idActFijo, empresaId, ano);

        var movActivo = await context.MovActivoFijo
            .FirstOrDefaultAsync(m => m.IdActFijo == idActFijo && m.IdEmpresa == empresaId && m.Ano == ano);

        if (movActivo == null)
        {
            logger.LogWarning("Activo fijo not found: {IdActFijo}", idActFijo);
            throw new BusinessException("Activo fijo no encontrado");
        }

        var ficha = await context.ActFijoFicha
            .FirstOrDefaultAsync(f => f.IdActFijo == idActFijo && f.IdEmpresa == empresaId && f.Ano == ano);

        var grupo = ficha != null && ficha.IdGrupo != null
            ? await context.AFGrupos.FirstOrDefaultAsync(g => g.IdGrupo == ficha.IdGrupo && g.IdEmpresa == empresaId)
            : null;

        var componentes = await context.ActFijoCompsFicha
            .Where(c => c.IdActFijo == idActFijo && c.IdEmpresa == empresaId && c.Ano == ano)
            .OrderBy(c => c.IdCompFicha)
            .ToListAsync();

        var componentesDto = new List<ComponenteDto>();
        foreach (var comp in componentes)
        {
            var afComp = comp.IdComp != null && comp.IdComp > 0
                ? await context.AFComponentes.FirstOrDefaultAsync(a => a.IdComp == comp.IdComp && a.IdEmpresa == empresaId)
                : null;

            componentesDto.Add(new ComponenteDto
            {
                IdCompFicha = comp.IdCompFicha,
                IdComp = comp.IdComp,
                NombComp = afComp?.NombComp ?? "Sin detalle",
                PjeDivComp = comp.PjeDivComp,
                ValorCompra = comp.ValorCompra,
                ValorResidual = comp.ValorResidual,
                PjeAmortizacion = comp.PjeAmortizacion,
                VidaUtil = comp.VidaUtil,
                CostosAdicionales = comp.CostosAdicionales,
                TasaDesc = comp.TasaDesc,
                CostoDesmant = comp.CostoDesmant,
                ValActCostoDesmant = comp.ValActCostoDesmant,
                ValorBien = comp.ValorBien,
                ValorRazonable_31_12 = comp.ValorRazonable_31_12,
                NoExisteValRazonable = comp.NoExisteValRazonable,
                OtrasDiferencias = comp.OtrasDiferencias
            });
        }

        var dto = new ComponentesActivoFijoDto
        {
            IdActFijo = idActFijo,
            EmpresaId = empresaId,
            Ano = ano,
            IdGrupo = ficha?.IdGrupo,
            NombGrupo = grupo?.NombGrupo,
            Descripcion = movActivo.Descrip,
            Cantidad = movActivo.Cantidad,
            SinDetComps = ficha?.SinDetComps,
            NoDepreciable = movActivo.NoDepreciable,
            PrecioFactura = ficha?.PrecioFactura,
            DerechosIntern = ficha?.DerechosIntern,
            Transporte = ficha?.Transporte,
            ObrasAdapt = ficha?.ObrasAdapt,
            FImported = movActivo.FImported,
            Componentes = componentesDto
        };

        logger.LogInformation("Found {Count} componentes for activo fijo {IdActFijo}", componentesDto.Count, idActFijo);
        return dto;
    }

    public async Task<List<ComponenteDisponibleDto>> GetComponentesDisponiblesAsync(int idGrupo, int idActFijo, int empresaId, short ano)
    {
        logger.LogInformation("Getting componentes disponibles for IdGrupo: {IdGrupo}", idGrupo);

        var todosComponentes = await context.AFComponentes
            .Where(c => c.IdGrupo == idGrupo && c.IdEmpresa == empresaId)
            .OrderBy(c => c.NombComp)
            .ToListAsync();

        var componentesAsignados = await context.ActFijoCompsFicha
            .Where(c => c.IdActFijo == idActFijo && c.IdEmpresa == empresaId && c.Ano == ano && c.IdComp != null && c.IdComp > 0)
            .Select(c => c.IdComp!.Value)
            .ToListAsync();

        var disponibles = todosComponentes
            .Where(c => !componentesAsignados.Contains(c.IdComp))
            .Select(c => new ComponenteDisponibleDto
            {
                IdComp = c.IdComp,
                NombComp = c.NombComp
            })
            .ToList();

        logger.LogInformation("Found {Count} componentes disponibles", disponibles.Count);
        return disponibles;
    }

    public async Task<int> GuardarComponenteAsync(GuardarComponenteDto dto)
    {
        logger.LogInformation("Saving componente {IdComp} for activo fijo {IdActFijo}",
            dto.Componente.IdComp, dto.IdActFijo);

        // Validar porcentaje de división (lanza BusinessException si hay error)
        await ValidarPorcentajeDivisionAsync(dto);

        // Obtener datos del activo fijo para cálculos
        var ficha = await context.ActFijoFicha
            .FirstOrDefaultAsync(f => f.IdActFijo == dto.IdActFijo && f.IdEmpresa == dto.EmpresaId && f.Ano == dto.Ano);

        var movActivo = await context.MovActivoFijo
            .FirstOrDefaultAsync(m => m.IdActFijo == dto.IdActFijo && m.IdEmpresa == dto.EmpresaId && m.Ano == dto.Ano);

        if (ficha == null || movActivo == null)
        {
            throw new BusinessException("No se encontró el activo fijo");
        }

        // Calcular campos automáticos
        var componenteCalculado = CalcularCamposComponente(
            dto.Componente,
            ficha.PrecioFactura,
            ficha.DerechosIntern,
            ficha.Transporte,
            ficha.ObrasAdapt,
            movActivo.Cantidad
        );

        App.Data.ActFijoCompsFicha? comp;

        if (dto.Componente.IdCompFicha > 0)
        {
            // Actualizar existente
            comp = await context.ActFijoCompsFicha
                .FirstOrDefaultAsync(c => c.IdCompFicha == dto.Componente.IdCompFicha
                    && c.IdEmpresa == dto.EmpresaId && c.Ano == dto.Ano);

            if (comp == null)
            {
                throw new BusinessException("Componente no encontrado");
            }

            logger.LogInformation("Updating existing componente {IdCompFicha}", dto.Componente.IdCompFicha);
        }
        else
        {
            // Crear nuevo
            comp = new App.Data.ActFijoCompsFicha
            {
                IdActFijo = dto.IdActFijo,
                IdEmpresa = dto.EmpresaId,
                Ano = dto.Ano,
                IdGrupo = dto.IdGrupo,
                IdComp = dto.SinDetComps ? -1 : dto.Componente.IdComp
            };
            context.ActFijoCompsFicha.Add(comp);
            logger.LogInformation("Creating new componente for IdComp: {IdComp}", comp.IdComp);
        }

        // Asignar valores calculados
        comp.PjeDivComp = componenteCalculado.PjeDivComp;
        comp.ValorCompra = componenteCalculado.ValorCompra;
        comp.ValorResidual = componenteCalculado.ValorResidual;
        comp.PjeAmortizacion = componenteCalculado.PjeAmortizacion;
        comp.VidaUtil = componenteCalculado.VidaUtil;
        comp.CostosAdicionales = componenteCalculado.CostosAdicionales;
        comp.TasaDesc = componenteCalculado.TasaDesc;
        comp.CostoDesmant = componenteCalculado.CostoDesmant;
        comp.ValActCostoDesmant = componenteCalculado.ValActCostoDesmant;
        comp.ValorBien = componenteCalculado.ValorBien;
        comp.ValorRazonable_31_12 = componenteCalculado.NoExisteValRazonable == true ? null : componenteCalculado.ValorRazonable_31_12;
        comp.NoExisteValRazonable = componenteCalculado.NoExisteValRazonable;
        comp.OtrasDiferencias = componenteCalculado.OtrasDiferencias;

        await context.SaveChangesAsync();

        logger.LogInformation("Successfully saved componente {IdCompFicha}", comp.IdCompFicha);
        return comp.IdCompFicha;
    }

    public async Task EliminarComponenteAsync(int idCompFicha, int empresaId, short ano)
    {
        logger.LogInformation("Deleting componente {IdCompFicha}", idCompFicha);

        var comp = await context.ActFijoCompsFicha
            .FirstOrDefaultAsync(c => c.IdCompFicha == idCompFicha && c.IdEmpresa == empresaId && c.Ano == ano);

        if (comp == null)
            throw new BusinessException("Componente no encontrado");

        context.ActFijoCompsFicha.Remove(comp);
        await context.SaveChangesAsync();

        logger.LogInformation("Successfully deleted componente {IdCompFicha}", idCompFicha);
    }

    public async Task ActualizarSinDetCompsAsync(int idActFijo, int empresaId, short ano, bool sinDetComps)
    {
        logger.LogInformation("Updating SinDetComps to {SinDetComps} for activo {IdActFijo}", sinDetComps, idActFijo);

        var ficha = await context.ActFijoFicha
            .FirstOrDefaultAsync(f => f.IdActFijo == idActFijo && f.IdEmpresa == empresaId && f.Ano == ano);

        if (ficha == null)
            throw new BusinessException("Ficha no encontrada");

        if (sinDetComps)
        {
            // Si marca sin detalle, eliminar componentes existentes
            var comps = await context.ActFijoCompsFicha
                .Where(c => c.IdActFijo == idActFijo && c.IdEmpresa == empresaId && c.Ano == ano)
                .ToListAsync();

            if (comps.Any())
            {
                context.ActFijoCompsFicha.RemoveRange(comps);
                logger.LogInformation("Deleted {Count} componentes for sin detalle", comps.Count);
            }
        }

        ficha.SinDetComps = sinDetComps;
        await context.SaveChangesAsync();

        logger.LogInformation("Successfully updated SinDetComps");
    }

    public ComponenteDto CalcularCamposComponente(ComponenteDto componente, double? precioFactura,
        double? derechosIntern, double? transporte, double? obrasAdapt, int? cantidad)
    {
        // Cálculos automáticos según VB6 CalcFicha()
        var pjeDivComp = componente.PjeDivComp ?? 0;
        var precioFacturaVal = precioFactura ?? 0;
        var derechosInternVal = derechosIntern ?? 0;
        var transporteVal = transporte ?? 0;
        var obrasAdaptVal = obrasAdapt ?? 0;
        var cantidadVal = cantidad ?? 1;

        componente.ValorCompra = precioFacturaVal * pjeDivComp;
        componente.CostosAdicionales = (derechosInternVal + transporteVal + obrasAdaptVal) * pjeDivComp;

        // Valor actual costos desmantelamiento
        var tasaDesc = componente.TasaDesc ?? 0;
        var vidaUtil = componente.VidaUtil ?? 0;
        var costoDesmant = componente.CostoDesmant ?? 0;

        if (tasaDesc > 0 && vidaUtil > 0)
        {
            componente.ValActCostoDesmant = costoDesmant * Math.Pow(1 / (1 + tasaDesc), vidaUtil / 12.0);
        }
        else
        {
            componente.ValActCostoDesmant = 0;
        }

        // Valor del bien (según Thomson Reuters Joshua 4 jul 2018)
        componente.ValorBien = ((componente.ValorCompra ?? 0) + (componente.CostosAdicionales ?? 0) + (componente.ValActCostoDesmant ?? 0)) * cantidadVal;

        return componente;
    }

    private async Task ValidarPorcentajeDivisionAsync(GuardarComponenteDto dto)
    {
        if (dto.SinDetComps)
        {
            var pjeDivComp = dto.Componente.PjeDivComp ?? 0;
            if (Math.Abs(pjeDivComp - 1.0) > 0.0001)
                throw new BusinessException("El porcentaje de División Componentes debe ser 100% dado que no hay detalle de componentes.");
        }
        else
        {
            // Obtener suma de porcentajes de otras componentes
            var sumaPorcentajes = await context.ActFijoCompsFicha
                .Where(c => c.IdActFijo == dto.IdActFijo
                    && c.IdEmpresa == dto.EmpresaId
                    && c.Ano == dto.Ano
                    && c.IdCompFicha != dto.Componente.IdCompFicha)
                .SumAsync(c => c.PjeDivComp ?? 0);

            var pjeDivComp = dto.Componente.PjeDivComp ?? 0;
            var totalPorcentaje = Math.Round(sumaPorcentajes + pjeDivComp, 4);

            if (totalPorcentaje > 1.0001)
            {
                var sugerido = Math.Round(1.0 - sumaPorcentajes, 4);
                throw new BusinessException($"El porcentaje de División Componentes supera el 100% si se consideran todas las componentes.\n\nEl valor sugerido para este porcentaje es {sugerido:P2}");
            }
        }

        // Validar valor residual
        var valorCompra = dto.Componente.ValorCompra ?? 0;
        var valorResidual = dto.Componente.ValorResidual ?? 0;
        if (valorCompra > 0 && valorResidual > valorCompra)
            throw new BusinessException("El valor residual debe ser inferior al valor de compra del bien.");

        // Validar valor razonable
        var noExisteValRazonable = dto.Componente.NoExisteValRazonable ?? false;
        var valorRazonable = dto.Componente.ValorRazonable_31_12 ?? 0;
        if (!noExisteValRazonable && valorRazonable < 0)
            throw new BusinessException("El valor razonable debe ser mayor o igual que cero.");
    }
}
