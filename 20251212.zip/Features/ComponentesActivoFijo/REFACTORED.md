# ComponentesActivoFijo - Refactorización Completada

## Fecha: 2025-01-29

## Cambios Aplicados

### R19: Eliminación de Proxies en WebController
- **Archivo**: `ComponentesActivoFijoController.cs`
- **Cambios**: Eliminados 4 métodos proxy (`GetDatos`, `GetDisponibles`, `Guardar`, `Eliminar`, `SinDetComps`)
- **Resultado**: Controller reducido solo al método `Index()` para servir la vista
- **Dependencias eliminadas**: `IHttpClientFactory`, `LinkGenerator`, `System.Text.Json`, `App.Extensions`

### R20: Reemplazo de fetch() por Api.*
- **Archivo**: `Views/Index.cshtml`
- **Cambios**:
  - `fetch()` GET → `Api.get()` en `cargarDatos()` y `mostrarComponentesDisponibles()`
  - `fetch()` POST → `Api.postJson()` en `onSinDetCompsChange()` y `guardarComponente()`
  - `fetch()` DELETE → `Api.delete()` en `eliminarComponente()`
- **URLs actualizadas**: De `@Url.Action("X", "ComponentesActivoFijo")` a `/ComponentesActivoFijoApi/X`

### R21: Uso de Funciones Globales de Modal
- **Archivo**: `Views/Index.cshtml`
- **Cambios**:
  - Eliminada función local `cerrarModal()`
  - `classList.remove('hidden')` → `abrirModal('modalComponentes')`
  - `cerrarModal()` → `cerrarModal('modalComponentes')`

## Arquitectura Resultante
```
Vista (Index.cshtml)
    ↓ Api.get/postJson/delete
ComponentesActivoFijoApiController
    ↓
IComponentesActivoFijoService
    ↓
LpContabContext (EF Core)
```
