using Microsoft.AspNetCore.Mvc;
using App.Helpers;

namespace App.Features.ComponentesActivoFijo;

public class ComponentesActivoFijoController(ILogger<ComponentesActivoFijoController> logger) : Controller
{
    public IActionResult Index(int idActFijo)
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Componentes de Activo Fijo";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        // Obtener empresaId y ano desde la sesión
        var empresaId = SessionHelper.EmpresaId;
        int ano = SessionHelper.Ano;

        logger.LogInformation("Loading ComponentesActivoFijo for IdActFijo: {IdActFijo}, EmpresaId: {EmpresaId}, Ano: {Ano}",
            idActFijo, empresaId, ano);

        var viewModel = new ComponentesActivoFijoIndexViewModel
        {
            IdActFijo = idActFijo,
            EmpresaId = empresaId,
            Ano = (short)ano
        };

        return View(viewModel);
    }
}
