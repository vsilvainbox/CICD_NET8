namespace App.Features.Ayuda;

/// <summary>
/// DTO para contenido de ayuda específico
/// </summary>
public class AyudaContentDto
{
    public string Titulo { get; set; } = string.Empty;
    public string Descripcion { get; set; } = string.Empty;
    public List<AyudaItemDto> Items { get; set; } = new();
}

/// <summary>
/// DTO para un elemento individual de ayuda
/// </summary>
public class AyudaItemDto
{
    public string Codigo { get; set; } = string.Empty;
    public string Descripcion { get; set; } = string.Empty;
    public string Detalle { get; set; } = string.Empty;
    public string Categoria { get; set; } = string.Empty; // "SOLO 14D3", "AMBOS", "SOLO 14D8"
    public string TipoOperacion { get; set; } = string.Empty; // "+", "-"
}

/// <summary>
/// DTO para tipos de ayuda disponibles
/// </summary>
public class AyudaTipoDto
{
    public int Id { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public string Descripcion { get; set; } = string.Empty;
    public string Icono { get; set; } = string.Empty;
}

/// <summary>
/// ViewModel para la vista Modal de ayuda
/// Combina AyudaContentDto con propiedades adicionales para eliminar ViewBag
/// </summary>
public class AyudaModalViewModel
{
    public string Titulo { get; set; } = string.Empty;
    public string Descripcion { get; set; } = string.Empty;
    public List<AyudaItemDto> Items { get; set; } = new();
    public string TipoAyuda { get; set; } = string.Empty;
    public string Contexto { get; set; } = string.Empty;
    public string? Error { get; set; }

    /// <summary>
    /// Constructor por defecto
    /// </summary>
    public AyudaModalViewModel() { }

    /// <summary>
    /// Constructor que crea el ViewModel desde un AyudaContentDto
    /// </summary>
    public AyudaModalViewModel(AyudaContentDto? content, string tipoAyuda, string contexto, string? error = null)
    {
        Titulo = content?.Titulo ?? string.Empty;
        Descripcion = content?.Descripcion ?? string.Empty;
        Items = content?.Items ?? new();
        TipoAyuda = tipoAyuda;
        Contexto = contexto;
        Error = error;
    }
}

/// <summary>
/// Enumeración para tipos de ayuda
/// </summary>
public enum TipoAyuda
{
    AjustesAumentos = 1,
    AjustesDisminuciones = 2
}