using App.Data;
using App.Exceptions;
using Microsoft.EntityFrameworkCore;

namespace App.Features.ActualizacionGlosas;

/// <summary>
/// Servicio para gestión de glosas
/// Replica la funcionalidad de FrmGlosasUpdate.frm
/// </summary>
public class ActualizacionGlosasService(
    LpContabContext context,
    ILogger<ActualizacionGlosasService> logger) : IActualizacionGlosasService
{
    public async Task<GuardarGlosaResponse> CrearGlosaAsync(string glosa, int empresaId)
    {
        logger.LogInformation("Creating new glosa for empresaId: {EmpresaId}", empresaId);

        // Validar que la glosa no esté vacía
        if (string.IsNullOrWhiteSpace(glosa))
        {
            logger.LogWarning("Attempted to create empty glosa");
            throw new BusinessException("Debe ingresar una glosa");
        }

        // Validar longitud máxima (250 caracteres)
        if (glosa.Length > 250)
        {
            logger.LogWarning("Glosa exceeds max length: {Length}", glosa.Length);
            throw new BusinessException("La glosa no puede exceder 250 caracteres");
        }

        // Crear nueva glosa
        var nuevaGlosa = new global::App.Data.Glosas
        {
            IdEmpresa = empresaId,
            Glosa = glosa.Trim()
        };

        context.Glosas.Add(nuevaGlosa);
        await context.SaveChangesAsync();

        logger.LogInformation("Glosa created successfully with ID: {IdGlosa}", nuevaGlosa.idGlosa);

        return new GuardarGlosaResponse
        {
            IdGlosa = nuevaGlosa.idGlosa,
            Glosa = nuevaGlosa.Glosa ?? string.Empty
        };
    }

    public async Task<GuardarGlosaResponse> ActualizarGlosaAsync(int idGlosa, string glosa, int empresaId, int? idGlosaRequest)
    {
        logger.LogInformation("Updating glosa {IdGlosa} for empresaId: {EmpresaId}", idGlosa, empresaId);

        // Validar que los IDs coincidan
        if (idGlosaRequest.HasValue && idGlosaRequest.Value != idGlosa)
        {
            logger.LogWarning("ID mismatch: route id {IdGlosa} != request id {RequestId}", idGlosa, idGlosaRequest.Value);
            throw new BusinessException("El ID de la glosa no coincide");
        }

        // Validar que la glosa no esté vacía
        if (string.IsNullOrWhiteSpace(glosa))
        {
            logger.LogWarning("Attempted to update with empty glosa");
            throw new BusinessException("Debe ingresar una glosa");
        }

        // Validar longitud máxima (250 caracteres)
        if (glosa.Length > 250)
        {
            logger.LogWarning("Glosa exceeds max length: {Length}", glosa.Length);
            throw new BusinessException("La glosa no puede exceder 250 caracteres");
        }

        // Buscar la glosa existente
        var glosaExistente = await context.Glosas
            .FirstOrDefaultAsync(g => g.idGlosa == idGlosa && g.IdEmpresa == empresaId);

        if (glosaExistente == null)
        {
            logger.LogWarning("Glosa {IdGlosa} not found for empresaId: {EmpresaId}", idGlosa, empresaId);
            throw new BusinessException("Glosa no encontrada");
        }

        // Actualizar la glosa
        glosaExistente.Glosa = glosa.Trim();
        context.Glosas.Update(glosaExistente);
        await context.SaveChangesAsync();

        logger.LogInformation("Glosa {IdGlosa} updated successfully", idGlosa);

        return new GuardarGlosaResponse
        {
            IdGlosa = glosaExistente.idGlosa,
            Glosa = glosaExistente.Glosa ?? string.Empty
        };
    }

    public async Task<GlosaDto> ObtenerGlosaAsync(int idGlosa, int empresaId)
    {
        logger.LogInformation("Getting glosa {IdGlosa} for empresaId: {EmpresaId}", idGlosa, empresaId);

        var glosa = await context.Glosas
            .Where(g => g.idGlosa == idGlosa && g.IdEmpresa == empresaId)
            .Select(g => new GlosaDto
            {
                IdGlosa = g.idGlosa,
                IdEmpresa = g.IdEmpresa ?? 0,
                Glosa = g.Glosa ?? string.Empty
            })
            .FirstOrDefaultAsync();

        if (glosa == null)
        {
            logger.LogWarning("Glosa {IdGlosa} not found for empresaId: {EmpresaId}", idGlosa, empresaId);
            throw new BusinessException("Glosa no encontrada");
        }

        return glosa;
    }

    public async Task ExisteGlosaAsync(int idGlosa, int empresaId)
    {
        logger.LogInformation("Checking if glosa {IdGlosa} exists for empresaId: {EmpresaId}", idGlosa, empresaId);

        var existe = await context.Glosas
            .AnyAsync(g => g.idGlosa == idGlosa && g.IdEmpresa == empresaId);

        if (!existe)
        {
            logger.LogWarning("Glosa {IdGlosa} does not exist for empresaId: {EmpresaId}", idGlosa, empresaId);
            throw new BusinessException("Glosa no encontrada");
        }
    }

    public async Task<List<GlosaDto>> GetAllAsync(int empresaId)
    {
        logger.LogInformation("Getting all glosas for empresaId: {EmpresaId}", empresaId);

        var glosas = await context.Glosas
            .Where(g => g.IdEmpresa == empresaId)
            .OrderBy(g => g.Glosa)
            .Select(g => new GlosaDto
            {
                IdGlosa = g.idGlosa,
                IdEmpresa = g.IdEmpresa ?? 0,
                Glosa = g.Glosa ?? string.Empty
            })
            .ToListAsync();

        logger.LogInformation("Found {Count} glosas for empresaId: {EmpresaId}", glosas.Count, empresaId);

        return glosas;
    }
}
