namespace App.Features.ActualizacionGlosas;

/// <summary>
/// Servicio para gestión de glosas (crear/actualizar)
/// </summary>
public interface IActualizacionGlosasService
{
    /// <summary>
    /// Crea una nueva glosa
    /// </summary>
    /// <param name="glosa">Texto de la glosa</param>
    /// <param name="empresaId">ID de la empresa</param>
    /// <returns>Resultado con ID generado</returns>
    Task<GuardarGlosaResponse> CrearGlosaAsync(string glosa, int empresaId);
    
    /// <summary>
    /// Actualiza una glosa existente
    /// </summary>
    /// <param name="idGlosa">ID de la glosa a actualizar</param>
    /// <param name="glosa">Nuevo texto</param>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="idGlosaRequest">ID de la glosa del request (para validación)</param>
    /// <returns>Resultado de la actualización</returns>
    Task<GuardarGlosaResponse> ActualizarGlosaAsync(int idGlosa, string glosa, int empresaId, int? idGlosaRequest);
    
    /// <summary>
    /// Obtiene una glosa por su ID
    /// </summary>
    /// <param name="idGlosa">ID de la glosa</param>
    /// <param name="empresaId">ID de la empresa</param>
    /// <returns>DTO con los datos de la glosa</returns>
    Task<GlosaDto> ObtenerGlosaAsync(int idGlosa, int empresaId);
    
    /// <summary>
    /// Verifica si existe una glosa
    /// </summary>
    /// <param name="idGlosa">ID de la glosa</param>
    /// <param name="empresaId">ID de la empresa</param>
    /// <exception cref="BusinessException">Si la glosa no existe</exception>
    Task ExisteGlosaAsync(int idGlosa, int empresaId);
    
    /// <summary>
    /// Obtiene todas las glosas de una empresa
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <returns>Lista de glosas</returns>
    Task<List<GlosaDto>> GetAllAsync(int empresaId);
}
