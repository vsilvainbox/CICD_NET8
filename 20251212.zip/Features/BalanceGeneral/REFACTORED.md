# Refactorización: Balance General

**Fecha:** 2025-12-07
**Guía aplicada:** refactor.md
**Reglas aplicadas:** R19, R20

---

## Resumen de Cambios

Esta refactorización eliminó el patrón proxy prohibido (R19) y reemplazó las llamadas AJAX manuales por helpers estandarizados (R20).

### Violaciones Detectadas y Corregidas

#### R19: JavaScript debe llamar a ApiController directamente (no proxy via WebController)
- **Violación detectada:** 1 instancia
  - WebController tenía métodos proxy: `GetEmpresas`, `GetAreasNegocio`, `GetCentrosCosto`, `Generate`, `Export`
  - Estos métodos usaban `ProxyRequestAsync` para redirigir a ApiControllers
  - JavaScript llamaba al WebController en lugar de llamar directamente a los ApiControllers

#### R20: Usar Api.* helpers en lugar de fetch/ajax manual
- **Violaciones detectadas:** 2 instancias
  - Uso de `$.get()` para cargar listas (empresas, áreas de negocio, centros de costo)
  - Uso de `$.ajax()` para generar balance (POST con JSON)
  - Uso de `$.ajax()` para exportar balance (descarga de archivo)

---

## Archivos Modificados

### 1. BalanceGeneralController.cs

**Cambios realizados:**
- ✅ Eliminados 5 métodos proxy del WebController:
  - `GetEmpresas()` - redirigía a `ListadoEmpresasApiController.GetAll`
  - `GetAreasNegocio()` - redirigía a `AreasNegocioApiController.GetAll`
  - `GetCentrosCosto()` - redirigía a `CentrosCostoApiController.GetAll`
  - `Generate()` - redirigía a `BalanceGeneralApiController.Generate` usando `ProxyRequestAsync`
  - `Export()` - redirigía a `BalanceGeneralApiController.Export` usando `DownloadFileAsync`

- ✅ Limpiados imports innecesarios:
  - Removido `System.Text.Json`
  - Removido `App.Extensions`
  - Removido `App.Features.ListadoEmpresas`
  - Removido `App.Features.AreasNegocio`
  - Removido `App.Features.CentrosCosto`

- ✅ Simplificado constructor:
  - Removido `IHttpClientFactory`
  - Removido `LinkGenerator`
  - Solo mantiene `ILogger<BalanceGeneralController>`

**Líneas de código eliminadas:** ~125 líneas

---

### 2. Views/Index.cshtml

**Cambios realizados:**

#### A. URLs actualizadas (R19)

**ANTES:**
```javascript
const URL_ENDPOINTS = {
    getEmpresas: '@Url.Action("GetEmpresas", "BalanceGeneral")',        // ❌ WebController
    getAreasNegocio: '@Url.Action("GetAreasNegocio", "BalanceGeneral")', // ❌ WebController
    getCentrosCosto: '@Url.Action("GetCentrosCosto", "BalanceGeneral")', // ❌ WebController
    generate: '@Url.Action("Generate", "BalanceGeneral")',               // ❌ WebController
    export: '@Url.Action("Export", "BalanceGeneral")'                    // ❌ WebController
};
```

**DESPUÉS:**
```javascript
const URL_ENDPOINTS = {
    getEmpresas: '@Url.Action("GetAll", "ListadoEmpresasApi")',      // ✅ ApiController directo
    getAreasNegocio: '@Url.Action("GetAll", "AreasNegocioApi")',     // ✅ ApiController directo
    getCentrosCosto: '@Url.Action("GetAll", "CentrosCostoApi")',     // ✅ ApiController directo
    generate: '@Url.Action("Generate", "BalanceGeneralApi")',        // ✅ ApiController directo
    export: '@Url.Action("Export", "BalanceGeneralApi")'             // ✅ ApiController directo
};
```

#### B. Funciones convertidas a async/await con Api.* (R20)

**1. loadEmpresas()**

**ANTES:**
```javascript
function loadEmpresas() {
    $.get(URL_ENDPOINTS.getEmpresas, function(data) {  // ❌ jQuery $.get
        const select = $('#EmpresaId');
        select.empty().append('<option value="">Seleccione...</option>');
        data.forEach(emp => {
            select.append(`<option value="${emp.idEmpresa}">${emp.razonSocial}</option>`);
        });
    }).fail(function() {
        console.error('Error loading empresas');
    });
}
```

**DESPUÉS:**
```javascript
async function loadEmpresas() {                      // ✅ async/await
    const data = await Api.get(URL_ENDPOINTS.getEmpresas);  // ✅ Api.get
    if (data) {
        const select = $('#EmpresaId');
        select.empty().append('<option value="">Seleccione...</option>');
        data.forEach(emp => {
            select.append(`<option value="${emp.idEmpresa}">${emp.razonSocial}</option>`);
        });
    }
    // Api.get ya maneja errores con SweetAlert automáticamente
}
```

**2. loadAreaNegocios() y loadCentrosCosto()**

Similar a `loadEmpresas()`, convertidas de `$.get()` a `Api.get()` con query parameters:

```javascript
async function loadAreaNegocios() {
    const sessionEmpresaId = @Html.Raw(Json.Serialize(App.Helpers.SessionHelper.EmpresaId));
    const data = await Api.get(URL_ENDPOINTS.getAreasNegocio, { empresaId: sessionEmpresaId });
    // ...
}
```

**3. generateBalance()**

**ANTES:**
```javascript
function generateBalance() {
    // ...
    $.ajax({                                         // ❌ jQuery $.ajax
        url: URL_ENDPOINTS.generate,
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(parametros),
        success: function(data) {
            balanceData = data;
            renderBalance(data);
            // ...
        },
        error: function(xhr) {
            Swal.fire({                              // ❌ Manejo manual de errores
                icon: 'error',
                title: 'Error al Generar',
                text: xhr.responseJSON?.message || xhr.statusText
            });
        },
        complete: function() {
            btnSubmit.prop('disabled', false).html('...');
        }
    });
}
```

**DESPUÉS:**
```javascript
async function generateBalance() {                   // ✅ async/await
    // ...
    const data = await Api.postJson(URL_ENDPOINTS.generate, parametros);  // ✅ Api.postJson

    if (data) {
        balanceData = data;
        renderBalance(data);
        $('#loadingState').addClass('hidden');
        $('#balanceContainer').removeClass('hidden');
        $('#btnExport, #btnPrint').prop('disabled', false);
    } else {
        // Api.postJson ya mostró el error con SweetAlert  // ✅ Sin manejo manual
        $('#loadingState').addClass('hidden');
        $('#estadoInicial').removeClass('hidden');
    }

    btnSubmit.prop('disabled', false).html('...');
}
```

**4. exportBalance()**

**ANTES:**
```javascript
function exportBalance() {
    $.ajax({                                         // ❌ jQuery $.ajax
        url: URL_ENDPOINTS.export,
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(exportDto),
        xhrFields: {
            responseType: 'blob'
        },
        success: function(blob) {
            // descarga archivo
        },
        error: function(xhr) {
            Swal.fire({ /* ... */ });                // ❌ Manejo manual de errores
        }
    });
}
```

**DESPUÉS:**
```javascript
async function exportBalance() {                     // ✅ async/await
    // ...
    try {
        const response = await fetch(URL_ENDPOINTS.export, {  // ✅ fetch nativo
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(exportDto)
        });

        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: errorData.message || 'Error al exportar el balance'
            });
            return;
        }

        const blob = await response.blob();
        // descarga archivo
    } catch (error) {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Error al exportar: ' + error.message
        });
    }
}
```

**Nota:** Para exportación de archivos se usa `fetch` nativo en lugar de `Api.*` porque los helpers actuales no tienen soporte para descargas de blob. Sin embargo, se mantiene la consistencia usando async/await y manejo de errores estandarizado.

---

## Reglas Verificadas

### Service
- [N/A] R06 - Reutiliza lógica existente (no aplica, sin cambios)
- [N/A] R15 - BusinessException para errores (no aplica, sin cambios)
- [N/A] R17 - Tipos SQL correctos (no aplica, sin cambios)

### ApiController
- [N/A] R02 - Sin try-catch (no aplica, sin cambios)
- [N/A] R02 - Retorna Ok()/Ok(data) (no aplica, sin cambios)

### WebController
- [✅] R02 - Sin try-catch (verificado, solo tiene Index())
- [✅] R03 - NO llama a Service directo (verificado, no tiene llamadas)
- [✅] R04 - NO usa URLs hardcodeadas (verificado)
- [✅] R16 - NO usa PostAsJsonAsync/GetAsync (verificado, eliminados)
- [✅] R19 - NO tiene métodos proxy (corregido, todos eliminados)

### Vista
- [✅] R04 - URLs con @Url.Action apuntando a ApiControllers (corregido)
- [N/A] R07 - Header Dashboard (no aplica, ya correcto)
- [N/A] R08 - Orden correcto (no aplica, ya correcto)
- [N/A] R09 - Empty State (no aplica, ya correcto)
- [N/A] R10 - Tag helpers (no aplica, ya correcto)
- [N/A] R11 - Botones disabled (no aplica, ya correcto)
- [N/A] R12 - Form POST / Api.* (no aplica, ya correcto)
- [N/A] R13 - Sin paginación (no aplica, ya correcto)
- [N/A] R18 - FormHandler (no aplica, ya correcto)
- [✅] R19 - JS → ApiController directo (corregido)
- [✅] R20 - Solo Api.* / fetch nativo (corregido)
- [N/A] CSS - Estilos (no aplica, ya correcto)

---

## Beneficios de la Refactorización

1. **Menor complejidad:** WebController simplificado de ~155 líneas a ~42 líneas (-73%)
2. **Menos puntos de fallo:** Eliminadas 5 capas proxy innecesarias
3. **Mejor performance:** JavaScript llama directamente a APIs sin proxy intermedio
4. **Manejo de errores centralizado:** Api.* helpers manejan errores automáticamente con SweetAlert
5. **Código más mantenible:** Patrón consistente en todas las llamadas AJAX
6. **Type-safety mejorado:** URLs generadas con @Url.Action en lugar de strings hardcodeados

---

## Validación Post-Refactorización

### Comandos de detección ejecutados:

```powershell
# R19: JavaScript llama a WebController en vez de ApiController (proxy prohibido)
Select-String -Path "D:\deploy\Features\BalanceGeneral\*Controller.cs" -Pattern "ProxyRequestAsync"
# Resultado: 0 violaciones ✅

# R20: fetch manual, $.ajax, axios
Select-String -Path "D:\deploy\Features\BalanceGeneral\Views\*.cshtml" -Pattern "await\s+fetch\(|\.ajax\(|axios\."
# Resultado: 1 ocurrencia (exportBalance con fetch nativo para descarga de archivos) ⚠️
```

### Notas sobre fetch en exportBalance:

La función `exportBalance()` ha sido **refactorizada** para usar Form POST nativo en lugar de fetch manual:

---

## Refactorización Adicional (2025-12-07)

### R20: Eliminar fetch manual restante

**Problema:** La función `exportBalance()` usaba `fetch` manual para POST con descarga de blob.

**Solución:** Cambiada a Form POST tradicional que el navegador procesa nativamente.

#### Archivos modificados:

**1. Views/Index.cshtml - Función exportBalance()**

**ANTES:**
```javascript
async function exportBalance() {
    const response = await fetch(URL_ENDPOINTS.export, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(exportDto)
    });
    // manejo manual de blob y descarga
}
```

**DESPUÉS:**
```javascript
function exportBalance() {
    // R20: Form POST tradicional - el navegador maneja la descarga
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = URL_ENDPOINTS.export;
    // campos hidden con datos serializados como JSON
    form.submit();
}
```

**2. BalanceGeneralApiController.cs**
- Agregado `using System.Text.Json`
- Método `Export` cambiado de `[FromBody]` a `[FromForm]`
- Deserializa el JSON recibido como string

**3. BalanceGeneralDto.cs**
- Agregado nuevo DTO `BalanceGeneralExportFormDto` para recibir Form data

---

## Checklist de Verificación Manual

- [✅] WebController solo tiene método Index()
- [✅] JavaScript llama directamente a ApiControllers
- [✅] URLs generadas con @Url.Action apuntando a "*Api" controllers
- [✅] Funciones convertidas a async/await
- [✅] Uso de Api.get() para lecturas
- [✅] Uso de Api.postJson() para escrituras
- [✅] **Exportación usa Form POST nativo (sin fetch manual)**
- [✅] Errores manejados automáticamente por Api.* (sin manejo manual redundante)
- [✅] Código más limpio y mantenible

---

**Refactorización completada exitosamente** ✅
