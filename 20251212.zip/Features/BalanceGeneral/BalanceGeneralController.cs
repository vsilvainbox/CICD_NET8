using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using App.Helpers;

namespace App.Features.BalanceGeneral;

/// <summary>
/// Controlador MVC para Balance General de 8 Columnas
/// Solo maneja la vista, no necesita llamadas a API (JavaScript las hace directamente)
/// </summary>
[Authorize]
public class BalanceGeneralController(
    ILogger<BalanceGeneralController> logger) : Controller
{
    /// <summary>
    /// Vista principal del Balance General
    /// GET /BalanceGeneral
    /// </summary>
    public IActionResult Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder al Balance General";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        logger.LogInformation("Loading Balance General Index view");
        
        var model = new BalanceGeneralParametrosDto
        {
            EmpresaId = SessionHelper.EmpresaId,
            Ano = SessionHelper.Ano,
            FechaDesde = new DateTime(SessionHelper.Ano, 1, 1),
            FechaHasta = new DateTime(SessionHelper.Ano, 12, 31),
            Nivel = 9
        };
        
        return View(model);
    }
}