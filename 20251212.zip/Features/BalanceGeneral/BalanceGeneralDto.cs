using System.ComponentModel.DataAnnotations;

namespace App.Features.BalanceGeneral;

/// <summary>
/// DTO para una l�nea del balance general de 8 columnas
/// </summary>
public class BalanceGeneralDto
{
    public int idCuenta { get; set; }
        
    [Display(Name = "C�digo")]
    public string? Codigo { get; set; }
        
    [Display(Name = "Cuenta")]
    public string? Descripcion { get; set; }
        
    public int? Nivel { get; set; }
        
    public int? Clasificacion { get; set; }
        
    [Display(Name = "D�bitos")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double Debitos { get; set; }
        
    [Display(Name = "Cr�ditos")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double Creditos { get; set; }
        
    [Display(Name = "Saldo Deudor")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double SaldoDeudor { get; set; }
        
    [Display(Name = "Saldo Acreedor")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double SaldoAcreedor { get; set; }
        
    [Display(Name = "Inventario Activo")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double InventarioActivo { get; set; }
        
    [Display(Name = "Inventario Pasivo")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double InventarioPasivo { get; set; }
        
    [Display(Name = "P�rdida")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double Perdida { get; set; }
        
    [Display(Name = "Ganancia")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double Ganancia { get; set; }
        
    /// <summary>
    /// Indica si es una l�nea de total
    /// </summary>
    public bool IsTotal { get; set; }
        
    /// <summary>
    /// Indica si es total general
    /// </summary>
    public bool IsTotalGeneral { get; set; }
}

/// <summary>
/// DTO para parámetros de generación del balance
/// </summary>
public class BalanceGeneralParametrosDto
{
    [Required(ErrorMessage = "La empresa es obligatoria")]
    [Display(Name = "Empresa")]
    public int EmpresaId { get; set; }
        
    [Required(ErrorMessage = "El año es obligatorio")]
    [Display(Name = "Año")]
    public short Ano { get; set; }
        
    [Required(ErrorMessage = "La fecha desde es obligatoria")]
    [Display(Name = "Fecha Desde")]
    [DataType(DataType.Date)]
    public DateTime FechaDesde { get; set; }
        
    [Required(ErrorMessage = "La fecha hasta es obligatoria")]
    [Display(Name = "Fecha Hasta")]
    [DataType(DataType.Date)]
    public DateTime FechaHasta { get; set; }
        
    [Range(1, 10, ErrorMessage = "El nivel debe ser entre 1 y 10")]
    [Display(Name = "Nivel Máximo")]
    public int Nivel { get; set; } = 9;
        
    /// <summary>
    /// 1=Financiero, 2=Tributario, 0=Todos
    /// </summary>
    [Display(Name = "Tipo Ajuste")]
    public int? TipoAjuste { get; set; }
        
    [Display(Name = "Área de Negocio")]
    public int? AreaNegocio { get; set; }
        
    [Display(Name = "Centro de Costo")]
    public int? CentroCosto { get; set; }
        
    /// <summary>
    /// Solo comprobantes aprobados
    /// </summary>
    [Display(Name = "Solo Libro Oficial")]
    public bool LibroOficial { get; set; } = true;
    
    /// <summary>
    /// Mostrar cuentas en cero
    /// </summary>
    [Display(Name = "Mostrar Cuentas en Cero")]
    public bool MostrarCero { get; set; }
        
    /// <summary>
    /// Mostrar código de cuenta en reporte
    /// </summary>
    public bool MostrarCodigo { get; set; } = true;
}

/// <summary>
/// DTO para totales del balance
/// </summary>
public class BalanceGeneralTotalesDto
{
    [Display(Name = "Total D�bitos")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double TotalDebitos { get; set; }
        
    [Display(Name = "Total Cr�ditos")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double TotalCreditos { get; set; }
        
    [Display(Name = "Total Saldo Deudor")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double TotalSaldoDeudor { get; set; }
        
    [Display(Name = "Total Saldo Acreedor")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double TotalSaldoAcreedor { get; set; }
        
    [Display(Name = "Total Inventario Activo")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double TotalInventarioActivo { get; set; }
        
    [Display(Name = "Total Inventario Pasivo")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double TotalInventarioPasivo { get; set; }
        
    [Display(Name = "Total P�rdida")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double TotalPerdida { get; set; }
        
    [Display(Name = "Total Ganancia")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double TotalGanancia { get; set; }
        
    [Display(Name = "Patrimonio")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double Patrimonio { get; set; }
        
    /// <summary>
    /// Verifica ecuación contable
    /// Activos + P�rdidas = Pasivos + Patrimonio + Ganancias
    /// </summary>
    public bool EcuacionBalanceada => 
        Math.Abs((TotalInventarioActivo + TotalPerdida) - 
                 (TotalInventarioPasivo + Patrimonio + TotalGanancia)) < 0.01;
}

/// <summary>
/// DTO para resultado completo del balance
/// </summary>
public class BalanceGeneralResultadoDto
{
    public List<BalanceGeneralDto> Lineas { get; set; } = new();
        
    public BalanceGeneralTotalesDto Totales { get; set; } = new();
        
    public BalanceGeneralParametrosDto Parametros { get; set; } = new();
}

/// <summary>
/// DTO para exportación
/// </summary>
public class BalanceGeneralExportDto
{
    public BalanceGeneralResultadoDto Resultado { get; set; } = new();
        
    public bool IncluirMembrete { get; set; }
        
    public string Formato { get; set; } = "Excel"; // Excel, PDF, CSV
}

/// <summary>
/// DTO para exportación vía Form POST (R20: evitar fetch manual)
/// </summary>
public class BalanceGeneralExportFormDto
{
    /// <summary>
    /// JSON serializado del resultado del balance
    /// </summary>
    public string? Resultado { get; set; }
    
    public bool IncluirMembrete { get; set; }
    
    public string? Formato { get; set; }
}