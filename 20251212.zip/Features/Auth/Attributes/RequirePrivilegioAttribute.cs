using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using App.Features.Auth.Models;
using App.Models.Auth;
using System.Text.Json;

namespace App.Features.Auth.Attributes;

/// <summary>
/// Atributo que requiere que el usuario tenga privilegios específicos
/// Similar a las validaciones PRV_* de VB6
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
public class RequirePrivilegioAttribute : Attribute, IAuthorizationFilter
{
    private readonly Privilegios[] _privilegiosRequeridos;
    private readonly bool _requiereTodos;

    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="requiereTodos">Si es true, el usuario debe tener TODOS los privilegios. Si es false, basta con UNO</param>
    /// <param name="privilegios">Privilegios requeridos</param>
    public RequirePrivilegioAttribute(bool requiereTodos = false, params Privilegios[] privilegios)
    {
        _privilegiosRequeridos = privilegios;
        _requiereTodos = requiereTodos;
    }

    /// <summary>
    /// Constructor simplificado para un solo privilegio
    /// </summary>
    public RequirePrivilegioAttribute(Privilegios privilegio)
    {
        _privilegiosRequeridos = new[] { privilegio };
        _requiereTodos = false;
    }

    public void OnAuthorization(AuthorizationFilterContext context)
    {
        // Obtener logger
        var loggerFactory = context.HttpContext.RequestServices.GetService<Microsoft.Extensions.Logging.ILoggerFactory>();
        var logger = loggerFactory?.CreateLogger<RequirePrivilegioAttribute>();

        logger?.LogInformation("[RequirePrivilegio] Checking privileges: {Privilegios}", string.Join(", ", _privilegiosRequeridos));

        // Verificar que el usuario esté autenticado
        if (!context.HttpContext.User.Identity?.IsAuthenticated ?? true)
        {
            logger?.LogWarning("[RequirePrivilegio] User not authenticated, redirecting to Login");
            context.Result = new RedirectToActionResult("Login", "Auth", null);
            return;
        }

        // Obtener usuario de sesión - con acceso seguro
        string? usuarioJson = null;

        try
        {
            usuarioJson = context.HttpContext.Session.GetString("UsuarioActual");
        }
        catch (Exception ex)
        {
            logger?.LogWarning(ex, "[RequirePrivilegio] Session not available, redirecting to Login");
            context.Result = new RedirectToActionResult("Login", "Auth", null);
            return;
        }

        logger?.LogInformation("[RequirePrivilegio] UsuarioActual in session: {HasValue}", !string.IsNullOrEmpty(usuarioJson));

        if (string.IsNullOrEmpty(usuarioJson))
        {
            logger?.LogWarning("[RequirePrivilegio] UsuarioActual not found in session, redirecting to Login");
            context.Result = new RedirectToActionResult("Login", "Auth", null);
            return;
        }

        var usuarioSession = JsonSerializer.Deserialize<UsuarioSession>(usuarioJson);
        if (usuarioSession == null)
        {
            logger?.LogWarning("[RequirePrivilegio] Failed to deserialize UsuarioActual, redirecting to Login");
            context.Result = new RedirectToActionResult("Login", "Auth", null);
            return;
        }

        logger?.LogInformation("[RequirePrivilegio] Usuario: {Usuario}, PrivilegiosActuales: {Privilegios}",
            usuarioSession.Usuario, usuarioSession.PrivilegiosActuales);

        // Verificar privilegios
        var tieneAcceso = _requiereTodos
            ? PrivilegiosHelper.TieneTodosLosPrivilegios(usuarioSession.PrivilegiosActuales, _privilegiosRequeridos)
            : PrivilegiosHelper.TieneAlgunPrivilegio(usuarioSession.PrivilegiosActuales, _privilegiosRequeridos);

        logger?.LogInformation("[RequirePrivilegio] Tiene acceso: {TieneAcceso}", tieneAcceso);

        if (!tieneAcceso)
        {
            logger?.LogWarning("[RequirePrivilegio] Access denied, redirecting to AccessDenied");
            context.Result = new RedirectToActionResult("AccessDenied", "Auth", null);
        }
    }
}
