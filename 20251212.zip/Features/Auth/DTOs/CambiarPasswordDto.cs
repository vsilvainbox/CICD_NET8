using System.ComponentModel.DataAnnotations;

namespace App.Features.Auth.DTOs;

public class CambiarPasswordDto
{
    [Required(ErrorMessage = "La contraseña actual es obligatoria")]
    [Display(Name = "Contraseña Actual")]
    [DataType(DataType.Password)]
    public string PasswordActual { get; set; } = string.Empty;

    [Required(ErrorMessage = "La nueva contraseña es obligatoria")]
    [StringLength(50, MinimumLength = 4, ErrorMessage = "La contraseña debe tener entre 4 y 50 caracteres")]
    [Display(Name = "Nueva Contraseña")]
    [DataType(DataType.Password)]
    public string PasswordNueva { get; set; } = string.Empty;

    [Required(ErrorMessage = "Debe confirmar la nueva contraseña")]
    [Compare("PasswordNueva", ErrorMessage = "Las contraseñas no coinciden")]
    [Display(Name = "Confirmar Contraseña")]
    [DataType(DataType.Password)]
    public string PasswordConfirmacion { get; set; } = string.Empty;
}
