﻿namespace App.Features.CapitalAportado;

public interface ICapitalAportadoService
{
    Task<CapitalAportadoDto> GetCapitalAportadoAsync(int empresaId, short ano);
    Task SaveCapitalAportadoAsync(SaveCapitalAportadoRequestDto request);
}
