namespace App.Features.CapitalAportado;

/// <summary>
/// ViewModel para la vista Index de Capital Aportado
/// Contiene los datos de sesión necesarios para la vista
/// </summary>
public class CapitalAportadoIndexViewModel
{
    /// <summary>
    /// ID de la empresa actual en sesión
    /// </summary>
    public int EmpresaId { get; set; }

    /// <summary>
    /// Año actual en sesión
    /// </summary>
    public short Ano { get; set; }
}
