using Microsoft.AspNetCore.Mvc;

namespace App.Features.CapitalAportado;

[ApiController]
[Route("[controller]/[action]")]
public class CapitalAportadoApiController(
    ICapitalAportadoService service,
    ILogger<CapitalAportadoApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<CapitalAportadoDto>> Get(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        logger.LogInformation("API: Get capital aportado called");

        var data = await service.GetCapitalAportadoAsync(empresaId, ano);
        return Ok(data);
    }

    [HttpPost]
    public async Task<ActionResult> Save([FromBody] SaveCapitalAportadoRequestDto request)
    {
        logger.LogInformation("API: Save capital aportado called");

        await service.SaveCapitalAportadoAsync(request);
        return Ok();
    }
}
