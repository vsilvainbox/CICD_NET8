namespace App.Features.AreasNegocio;

public interface IAreasNegocioService
{
    // CRUD Principal
    Task<IEnumerable<AreasNegocioDto>> GetAllAsync(int empresaId);
    Task<AreasNegocioDto> GetByIdAsync(int id, int empresaId);
    Task<AreasNegocioDto> CreateAsync(int empresaId, AreasNegocioCreateDto dto);
    Task<AreasNegocioDto> UpdateAsync(int id, int empresaId, AreasNegocioUpdateDto dto);
    Task DeleteAsync(int id, int empresaId);

    // Validaciones
    Task<bool> CheckUniqueCodeAsync(string codigo, int empresaId, int? excludeId = null);

    // Validación de referencias
    Task<bool> HasReferencesAsync(int id, int empresaId);
}