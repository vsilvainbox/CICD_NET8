
# Audit System Script
# Detects inconsistencies between Frontend (JS/Razor) and Backend (C# Controllers)

$ErrorActionPreference = "Stop"

# --- 1. Build Backend Map ---
Write-Host "Scanning Backend Controllers..." -ForegroundColor Cyan

$backendMap = @{} # Key: "ControllerName.ActionName", Value: FilePath

$controllerFiles = Get-ChildItem -Path "D:\deploy\Features" -Recurse -Include "*Controller.cs"

foreach ($file in $controllerFiles) {
    $content = Get-Content $file.FullName -Raw

    # Extract Controller Name
    # Updated to handle C# 12 Primary Constructors: public class Name(...) : Base
    # Look specifically for classes ending in Controller
    if ($content -match 'class\s+(\w+Controller)\s*[\(:]') {
        $className = $matches[1]
        $controllerName = $className -replace "Controller$", ""

        # Extract Methods - Multiple patterns for comprehensive coverage
        # Pattern 1: Standard action methods with IActionResult, ActionResult, Task<...>, etc.
        # Pattern 2: Methods returning custom types wrapped in Task<ActionResult<T>>

        $methodPatterns = @(
            # Pattern for methods with simple return types
            'public\s+(?:override\s+)?(?:virtual\s+)?(?:async\s+)?(?:Task|IActionResult|ActionResult|JsonResult|ViewResult|FileResult|ContentResult|RedirectResult|PartialViewResult|FileContentResult|FileStreamResult|string|int|bool|void)\s+(\w+)\s*\(',
            # Pattern for methods with generic Task<T> - handles nested generics like Task<ActionResult<List<T>>>
            # Note: async keyword is optional (methods can return Task<T> without async)
            'public\s+(?:override\s+)?(?:virtual\s+)?(?:async\s+)?Task<[^(]+>\s+(\w+)\s*\(',
            # Pattern for methods with ActionResult<T>
            'public\s+(?:override\s+)?(?:virtual\s+)?(?:async\s+)?(?:Task<)?ActionResult<[^(]+>\s+(\w+)\s*\(',
            # Pattern for methods returning IEnumerable, List, etc.
            'public\s+(?:override\s+)?(?:virtual\s+)?(?:async\s+)?(?:Task<)?(?:IEnumerable|List|IList|ICollection)<[^(]+>\s+(\w+)\s*\(',
            # Pattern for [Http*] decorated methods - captures method name after any return type
            '\[Http(?:Get|Post|Put|Delete|Patch)(?:\([^\)]*\))?\]\s*(?:\[[^\]]*\]\s*)*public\s+[^(]+\s+(\w+)\s*\('
        )

        foreach ($pattern in $methodPatterns) {
            $methodMatches = [regex]::Matches($content, $pattern)
            foreach ($match in $methodMatches) {
                $methodName = $match.Groups[1].Value
                if ($methodName -and $methodName -notin @('class', 'interface', 'struct', 'enum')) {
                    $key = "$controllerName.$methodName"
                    if (-not $backendMap.ContainsKey($key)) {
                        $backendMap[$key] = $file.FullName
                    }
                }
            }
        }
    }
}

Write-Host "Found $($backendMap.Count) backend endpoints." -ForegroundColor Green

# --- 2. Scan Razor Views for Url.Action ---
Write-Host "`nScanning Razor Views for Url.Action..." -ForegroundColor Cyan

$razorMap = @{} # Key: "UrlKey", Value: { Controller, Action, File }
$razorFiles = Get-ChildItem -Path "D:\deploy\Features" -Recurse -Include "*.cshtml"

foreach ($file in $razorFiles) {
    $content = Get-Content $file.FullName -Raw
    
    # Regex to find: key: '@Url.Action("Action", "Controller")'
    # Also handles spaces and newlines slightly
    $matches = [regex]::Matches($content, '(\w+)\s*:\s*[''"]@Url\.Action\(\s*[''"](\w+)[''"]\s*,\s*[''"](\w+)[''"]\s*\)[''"]')
    
    foreach ($match in $matches) {
        $urlKey = $match.Groups[1].Value
        $action = $match.Groups[2].Value
        $controller = $match.Groups[3].Value
        
        # Store definition
        if (-not $razorMap.ContainsKey($urlKey)) {
            $razorMap[$urlKey] = @{
                Controller = $controller
                Action = $action
                DefinedIn = $file.Name
            }
        }
        
        # Verify against Backend
        $backendKey = "$controller.$action"
        if (-not $backendMap.ContainsKey($backendKey)) {
            Write-Host "  [BROKEN LINK] '$urlKey' in $($file.Name) points to $backendKey which was NOT found." -ForegroundColor Red
        }
    }
}

# --- 2.1 Scan Razor Views for Tag Helpers (asp-action, asp-controller) ---
Write-Host "`nScanning Razor Views for Tag Helpers (asp-action, asp-controller)..." -ForegroundColor Cyan

foreach ($file in $razorFiles) {
    $content = Get-Content $file.FullName -Raw
    
    # Regex to find: asp-controller="Controller" asp-action="Action" (or vice versa)
    # This is a bit complex because attributes can be in any order.
    # We'll look for tags that contain both.
    
    # Find all tags with asp-controller and asp-action
    $tagMatches = [regex]::Matches($content, '<[^>]+asp-controller=["''](\w+)["''][^>]*asp-action=["''](\w+)["''][^>]*>|<[^>]+asp-action=["''](\w+)["''][^>]*asp-controller=["''](\w+)["''][^>]*>')
    
    foreach ($match in $tagMatches) {
        if ($match.Groups[1].Success) {
            $controller = $match.Groups[1].Value
            $action = $match.Groups[2].Value
        } else {
            $action = $match.Groups[3].Value
            $controller = $match.Groups[4].Value
        }
        
        $backendKey = "$controller.$action"
        if (-not $backendMap.ContainsKey($backendKey)) {
            Write-Host "  [BROKEN TAG HELPER] <... asp-controller=''$controller'' asp-action=''$action'' ...> in $($file.Name) points to $backendKey which was NOT found." -ForegroundColor Red
        }
    }
}

# --- 3. Scan JS for Usage ---
Write-Host "`nScanning JS for usage of urls.KEY..." -ForegroundColor Cyan

# Exclude obsolete folder from JS scanning
$jsFiles = Get-ChildItem -Path "D:\deploy\wwwroot\js" -Recurse -Include "*.js" | Where-Object { $_.FullName -notlike "*\obsolete\*" }

foreach ($file in $jsFiles) {
    $content = Get-Content $file.FullName -Raw
    
    # Regex: urls.key or urls['key']
    $matches = [regex]::Matches($content, "urls\.(\w+)|urls\['(\w+)'\]")
    
    foreach ($match in $matches) {
        $key = if ($match.Groups[1].Success) { $match.Groups[1].Value } else { $match.Groups[2].Value }
        
        # Check if this key was defined in ANY Razor file (Approximation)
        # In a real app, JS is coupled to specific Views, but checking global existence is a good first step.
        if (-not $razorMap.ContainsKey($key)) {
            # Ignore common false positives if any
            Write-Host "  [POSSIBLE MISSING URL] '$key' used in $($file.Name) but not found in scanned Razor templates." -ForegroundColor Yellow
        }
    }
}

# --- 4. Scan for Hardcoded API Calls ---
Write-Host "`nScanning for Hardcoded API calls (excluding obsolete)..." -ForegroundColor Cyan

foreach ($file in $jsFiles) {
    # Skip obsolete files (already filtered above, but double-check)
    if ($file.FullName -like "*\obsolete\*") { continue }
    $content = Get-Content $file.FullName -Raw
    
    # Look for /api/ or /Controller/
    $matches = [regex]::Matches($content, '[''"]/(api/\w+|[A-Z]\w+)/(\w+)[''"]')
    
    foreach ($match in $matches) {
        $fullPath = $match.Value
        $controller = $match.Groups[1].Value -replace "^api/", ""
        $action = $match.Groups[2].Value
        
        # Try to match against backend
        # This is fuzzy because hardcoded paths might not match Controller/Action naming 1:1
        # But often they do.
        
        $backendKey = "$controller.$action"
        if (-not $backendMap.ContainsKey($backendKey)) {
             Write-Host "  [UNVERIFIED HARDCODED PATH] $fullPath in $($file.Name). Could not verify against $backendKey." -ForegroundColor Magenta
        }
    }
}

# --- 5. Scan for Empty Catch Blocks ---
Write-Host "`nScanning for Empty Catch Blocks (Swallowed Exceptions)..." -ForegroundColor Cyan

$csFiles = Get-ChildItem -Path "D:\deploy\Features" -Recurse -Include "*.cs"

foreach ($file in $csFiles) {
    $content = Get-Content $file.FullName -Raw
    # Regex for catch (...) { } with only whitespace inside
    if ($content -match 'catch\s*\([^)]*\)\s*\{\s*\}') {
         Write-Host "  [EMPTY CATCH BLOCK] Found in $($file.Name). This swallows errors silently." -ForegroundColor Yellow
    }
}

# --- 6. Scan for Async Void ---
Write-Host "`nScanning for 'async void' methods (Dangerous in ASP.NET Core)..." -ForegroundColor Cyan
foreach ($file in $csFiles) {
    $content = Get-Content $file.FullName -Raw
    if ($content -match 'async\s+void\s+') {
         Write-Host "  [ASYNC VOID] Found in $($file.Name). Avoid 'async void', use 'async Task'. This can crash the process." -ForegroundColor Red
    }
}

# --- 7. Scan for Console.WriteLine ---
Write-Host "`nScanning for Console.WriteLine (Should use ILogger)..." -ForegroundColor Cyan
foreach ($file in $csFiles) {
    $content = Get-Content $file.FullName -Raw
    # Skip Program.cs as it might use Console for startup
    if ($file.Name -ne "Program.cs" -and $content -match 'Console\.WriteLine') {
         Write-Host "  [CONSOLE LOGGING] Found in $($file.Name). Use ILogger instead for proper log management." -ForegroundColor Yellow
    }
}

# --- 8. Scan for Potential Hardcoded Secrets ---
Write-Host "`nScanning for Potential Hardcoded Secrets..." -ForegroundColor Cyan
$allFiles = Get-ChildItem -Path "D:\deploy" -Recurse -Include "*.cs", "*.json", "*.config"
foreach ($file in $allFiles) {
    $content = Get-Content $file.FullName -Raw
    # Simple patterns for common secrets (Case insensitive)
    if ($content -match '(?i)(password|apikey|secret)\s*=\s*["''][^"''\s]+["'']') {
         # Don't print the secret, just the file
         Write-Host "  [POTENTIAL SECRET] Found pattern in $($file.Name). Verify it's not a real credential." -ForegroundColor Red
    }
}

# --- 9. Scan for Controllers missing [Authorize] ---
Write-Host "`nScanning for Controllers missing [Authorize]..." -ForegroundColor Cyan
foreach ($file in $controllerFiles) {
    $content = Get-Content $file.FullName -Raw
    # Check if it inherits from Controller or ControllerBase
    if ($content -match ':\s*Controller(Base)?') {
        # Check if [Authorize] is present in the file (Simple check)
        if ($content -notmatch '\[Authorize') {
             # Exclude AuthController or Login related
             if ($file.Name -notmatch "Auth|Login|Home") {
                Write-Host "  [SECURITY RISK] $($file.Name) does not seem to have [Authorize] attribute. Verify if it should be public." -ForegroundColor Magenta
             }
        }
    }
}

Write-Host "`nAudit Complete." -ForegroundColor Cyan
