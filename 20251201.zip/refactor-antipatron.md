# Documento de Refactorizacion: Anti-Patrones en Vistas ASP.NET Core MVC

## Resumen Ejecutivo

Este documento identifica los principales anti-patrones encontrados en las vistas del proyecto y proporciona soluciones usando las capacidades nativas de ASP.NET Core MVC.

### Estadisticas Generales

| Anti-Patron | Ocurrencias | Archivos Afectados |
|-------------|-------------|-------------------|
| innerHTML con construccion HTML | 175+ | 45+ archivos |
| JSON.stringify manual | 107+ | 35+ archivos |
| Variables de estado globales | 66+ | 40+ archivos |
| Calculos en JavaScript | 92+ | 30+ archivos |
| Formateo de moneda/fecha en JS | 80+ | 35+ archivos |
| Validaciones duplicadas | 55+ | 25+ archivos |

---

## Anti-Patron 1: innerHTML con Construccion de HTML

### Descripcion del Problema

Se construyen strings HTML en JavaScript y se inyectan mediante `innerHTML`, `insertAdjacentHTML` o template literals.

### Por que es un Anti-Patron

1. **Seguridad**: Riesgo de XSS si se incluyen datos del usuario sin escapar
2. **Mantenimiento**: HTML disperso entre C# y JavaScript
3. **Rendimiento**: El navegador debe parsear el HTML string cada vez
4. **Depuracion**: Errores de HTML no se detectan en tiempo de compilacion

### Ejemplos Encontrados

#### Ejemplo 1: AbrirCerrarMes/Views/Index.cshtml (lineas 236-258)

```javascript
// ANTI-PATRON: Construir filas de tabla con innerHTML
const tdMonth = document.createElement('td');
tdMonth.className = 'px-4 py-4 whitespace-nowrap';
tdMonth.innerHTML = `<span class="text-sm font-medium text-gray-900">${month.nombreMes}</span>`;

const tdEstado = document.createElement('td');
tdEstado.innerHTML = `
    <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${estadoBadgeClass}">
        ${estadoIcon}${month.estadoTexto}
    </span>
`;
```

#### Ejemplo 2: Apertura/Views/Index.cshtml (lineas 382-403)

```javascript
// ANTI-PATRON: Renderizar lista de cuentas con innerHTML
accounts.forEach(account => {
    const row = document.createElement('tr');
    row.innerHTML = `
        <td class="px-3 py-2 text-sm text-gray-900">${account.codigo}</td>
        <td class="px-3 py-2 text-sm text-gray-700">${account.descripcion}</td>
        <td class="px-3 py-2 text-right">
            <button onclick="selectAccount(${account.idCuenta}, '${account.fullDescription}')">
                Seleccionar
            </button>
        </td>
    `;
    tbody.appendChild(row);
});
```

#### Ejemplo 3: AjustesRliCaja/Views/Index.cshtml (lineas 105, 190-201)

```javascript
// ANTI-PATRON: Limpiar y reconstruir tabla completa
function renderGrid() {
    const tbody = document.getElementById('tbody-ajustes');
    tbody.innerHTML = '';  // Destruir todo el DOM
    // ... reconstruir fila por fila ...
}
```

### Solucion ASP.NET Core MVC

#### Usar Partial Views + AJAX que retorna HTML renderizado

**1. Crear EditorTemplate para la fila:**

```html
<!-- Views/Shared/EditorTemplates/MesEstadoItem.cshtml -->
@model MesEstadoViewModel

<tr class="hover:bg-gray-50">
    <td class="px-4 py-4 whitespace-nowrap text-center">
        @if (Model.EsUltimoMesConMovimientos)
        {
            <i class="fas fa-arrow-right text-red-500 text-lg"></i>
        }
    </td>
    <td class="px-4 py-4 whitespace-nowrap">
        <span class="text-sm font-medium text-gray-900">@Model.NombreMes</span>
    </td>
    <td class="px-4 py-4">
        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium @Model.BadgeClass">
            <i class="@Model.EstadoIcon mr-1"></i>@Model.EstadoTexto
        </span>
    </td>
</tr>
```

**2. Endpoint que retorna HTML:**

```csharp
[HttpGet]
public IActionResult GetMesesEstado()
{
    var meses = _service.ObtenerMesesConEstado();
    return PartialView("_MesesLista", meses);
}
```

**3. JavaScript simplificado:**

```javascript
async function cargarMeses() {
    const response = await fetch('/AbrirCerrarMes/GetMesesEstado');
    const html = await response.text();
    document.getElementById('mesesContainer').innerHTML = html;
}
```

---

## Anti-Patron 2: JSON.stringify con Construccion Manual de Objetos

### Descripcion del Problema

Se construyen objetos JavaScript manualmente y se serializan con `JSON.stringify()` para enviar al servidor.

### Por que es un Anti-Patron

1. **Sin validacion de tipos**: Errores de tipado solo se detectan en runtime
2. **Codigo verboso**: Mapeo manual de campos es propenso a errores
3. **Duplicacion**: La estructura del objeto se define en JS y en el DTO del servidor
4. **Fragilidad**: Cambios en el backend requieren cambios en el JS

### Ejemplos Encontrados

#### Ejemplo 1: AbrirCerrarMes/Views/Index.cshtml (lineas 342-346)

```javascript
// ANTI-PATRON: Construccion manual del payload
const response = await fetch(URL_ENDPOINTS.abrir, {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    },
    body: JSON.stringify({
        empresaId: empresaId,
        ano: ano,
        mes: mes
    })
});
```

#### Ejemplo 2: BaseImponible14DCompleta/Views/Index.cshtml (lineas 197, 460)

```javascript
// ANTI-PATRON: Clonacion profunda con parse/stringify
baseImponibleDataOriginal = JSON.parse(JSON.stringify(baseImponibleData));

// ANTI-PATRON: Construccion manual de cambios
body: JSON.stringify({
    empresaId: empresaId,
    ano: ano,
    cambios: cambiosPendientes
})
```

#### Ejemplo 3: CuentasAjustesRli/Views/Index.cshtml (lineas 251, 277)

```javascript
// ANTI-PATRON: Almacenar objetos como JSON en data attributes
option.dataset.tipo = JSON.stringify(tipo);
// Luego recuperar y parsear
const tipo = JSON.parse(selectedOption.dataset.tipo);
```

### Solucion ASP.NET Core MVC

#### Usar formularios HTML nativos con Model Binding

**1. Formulario con inputs hidden para datos complejos:**

```html
<form id="frmAbrirMes" asp-action="AbrirMes" method="post">
    <input type="hidden" asp-for="EmpresaId" />
    <input type="hidden" asp-for="Ano" />
    <input type="hidden" asp-for="Mes" id="mesSeleccionado" />

    <!-- El formulario se envia normalmente, sin JSON.stringify -->
    <button type="submit">Abrir Mes</button>
</form>
```

**2. Para datos de colecciones, usar EditorFor:**

```html
@for (int i = 0; i < Model.Cambios.Count; i++)
{
    <input type="hidden" name="Cambios[@i].Id" value="@Model.Cambios[i].Id" />
    <input type="hidden" name="Cambios[@i].Valor" value="@Model.Cambios[i].Valor" />
}
```

**3. Controller con Model Binding automatico:**

```csharp
[HttpPost]
[ValidateAntiForgeryToken]
public async Task<IActionResult> AbrirMes(AbrirMesRequest request)
{
    // request ya viene poblado por Model Binding
    // No necesita deserializacion manual
}
```

---

## Anti-Patron 3: Variables de Estado Globales

### Descripcion del Problema

Se usan variables a nivel de modulo (`let items = []`, `let selectedRow = null`) para mantener estado de la aplicacion.

### Por que es un Anti-Patron

1. **Dificil de testear**: Estado global no se puede aislar en pruebas
2. **Race conditions**: Multiples funciones modifican el mismo estado
3. **Memoria**: Arrays grandes nunca se liberan
4. **Debugging**: Dificil rastrear quien modifica que

### Ejemplos Encontrados

#### Ejemplo 1: AsistenteImportacionPrimeraCategoria/Views/Index.cshtml (lineas 178-180)

```javascript
// ANTI-PATRON: Estado global mutable
let empresaId = @App.Helpers.SessionHelper.EmpresaId;
let ano = @App.Helpers.SessionHelper.Ano;
let currentData = [];      // Array que crece indefinidamente
let selectedRow = null;    // Referencia al DOM
let selectedCol = null;
```

#### Ejemplo 2: AnalisisVencimientos/Views/Index.cshtml (lineas 204-206)

```javascript
// ANTI-PATRON: Array global de documentos
let documentos = [];  // Modificado por listarDocumentos(), renderDocumentos(), etc.
```

#### Ejemplo 3: ConfiguracionComprobanteActivoFijo/Views/Index.cshtml (lineas 218-230)

```javascript
// ANTI-PATRON: Multiples objetos globales relacionados
let valoresActivoFijo = {
    valorRazonable: 0,
    valorInicial: 0,
    valorDelBien: 0,
    // ... mas campos
};

let lineasComprobante = [];  // Otro array global
```

### Solucion ASP.NET Core MVC

#### Mover el estado al servidor, usar ViewModels

**1. ViewModel con todo el estado necesario:**

```csharp
public class AnalisisVencimientosViewModel
{
    // Estado que antes estaba en JS
    public List<DocumentoVencimiento> Documentos { get; set; } = new();
    public int? DocumentoSeleccionadoId { get; set; }

    // Propiedades calculadas (no en JS)
    public decimal TotalGeneral => Documentos.Sum(d => d.Total);
    public decimal TotalSaldo => Documentos.Sum(d => d.SaldoDoc);

    // Filtros actuales
    public FiltrosVencimiento Filtros { get; set; } = new();
}
```

**2. Partial View que recibe el estado:**

```html
<!-- _DocumentosLista.cshtml -->
@model AnalisisVencimientosViewModel

<tbody id="documentosBody">
@foreach (var doc in Model.Documentos)
{
    <tr class="@(doc.Id == Model.DocumentoSeleccionadoId ? "bg-blue-50" : "")">
        <td>@doc.Numero</td>
        <td>@doc.Total.ToString("N0")</td>
        <!-- No necesita JS para renderizar -->
    </tr>
}
</tbody>

<tfoot>
    <tr>
        <td>Total:</td>
        <td>@Model.TotalGeneral.ToString("N0")</td>
    </tr>
</tfoot>
```

**3. AJAX que actualiza solo la parte necesaria:**

```javascript
// JavaScript minimo - solo coordina, no almacena estado
async function filtrar() {
    const form = document.getElementById('frmFiltros');
    const response = await fetch('/AnalisisVencimientos/Filtrar?' + new URLSearchParams(new FormData(form)));
    document.getElementById('resultados').innerHTML = await response.text();
}
```

---

## Anti-Patron 4: Calculos en JavaScript

### Descripcion del Problema

Se realizan calculos financieros (sumas, totales, porcentajes, depreciacion) en el cliente.

### Por que es un Anti-Patron

1. **Inconsistencia**: Calculos JS pueden diferir de los del servidor
2. **Auditoria**: Calculos financieros deben ser trazables en el servidor
3. **Precision**: JavaScript tiene problemas con decimales (0.1 + 0.2 !== 0.3)
4. **Manipulacion**: Usuario puede modificar calculos via DevTools

### Ejemplos Encontrados

#### Ejemplo 1: AnalisisVencimientos/Views/Index.cshtml (lineas 399-405)

```javascript
// ANTI-PATRON: Calcular totales en el cliente
function calcularTotales() {
    const totalGeneral = documentos.reduce((sum, doc) => sum + (doc.total || 0), 0);
    const totalSaldo = documentos.reduce((sum, doc) => sum + (doc.saldoDoc || 0), 0);

    document.getElementById('totalGeneral').textContent = totalGeneral.toLocaleString('es-CL');
    document.getElementById('totalSaldo').textContent = totalSaldo.toLocaleString('es-CL');
}
```

#### Ejemplo 2: ConfiguracionComprobanteActivoFijo/Views/Index.cshtml (lineas 322-352)

```javascript
// ANTI-PATRON: Calculo contable complejo en JS
function calcularMonto() {
    let monto = 0;

    if (document.getElementById('ckValorRazonable').checked) {
        monto += valoresActivoFijo.valorRazonable;
    }
    if (document.getElementById('ckValorInicial').checked) {
        monto += valoresActivoFijo.valorInicial;
    }
    // ... mas condiciones ...

    return monto;  // Este valor se usa en el formulario
}
```

#### Ejemplo 3: AnalisisVencimientos/Views/Index.cshtml (lineas 457-476)

```javascript
// ANTI-PATRON: Suma de seleccionados en cliente
function sumarSeleccionados() {
    let sumaTotal = 0;
    let sumaSaldo = 0;

    checkboxes.forEach(cb => {
        const index = parseInt(cb.dataset.index);
        const doc = documentos[index];
        sumaTotal += doc.total || 0;
        sumaSaldo += doc.saldoDoc || 0;
    });

    // Estos totales podrian ser manipulados
    document.getElementById('sumaTotal').textContent = '$' + sumaTotal.toLocaleString('es-CL');
}
```

### Solucion ASP.NET Core MVC

#### Propiedades calculadas en el ViewModel

**1. ViewModel con calculos server-side:**

```csharp
public class DocumentosViewModel
{
    public List<DocumentoItem> Documentos { get; set; } = new();

    // Calculos como propiedades (precision decimal)
    public decimal TotalGeneral => Documentos.Sum(d => d.Total);
    public decimal TotalSaldo => Documentos.Sum(d => d.SaldoDoc);

    // Para documentos seleccionados
    public List<int> IdsSeleccionados { get; set; } = new();

    public decimal SumaSeleccionados =>
        Documentos.Where(d => IdsSeleccionados.Contains(d.Id)).Sum(d => d.Total);
}
```

**2. Vista que muestra valores pre-calculados:**

```html
<tfoot>
    <tr class="font-bold">
        <td>Total General:</td>
        <td class="text-right">@Model.TotalGeneral.ToString("C0")</td>
        <td class="text-right">@Model.TotalSaldo.ToString("C0")</td>
    </tr>
</tfoot>

<div id="sumaSeleccionados" class="mt-4">
    <span>Suma seleccionados: @Model.SumaSeleccionados.ToString("C0")</span>
</div>
```

**3. Endpoint para recalcular seleccion:**

```csharp
[HttpPost]
public IActionResult CalcularSeleccion([FromBody] List<int> idsSeleccionados)
{
    var suma = _documentoService.CalcularSumaDocumentos(idsSeleccionados);
    return Json(new { suma = suma.ToString("C0") });
}
```

---

## Anti-Patron 5: Formateo de Moneda/Fecha en JavaScript

### Descripcion del Problema

Se formatea moneda y fechas en el cliente usando `toLocaleString()`, `toFixed()`, o funciones personalizadas.

### Por que es un Anti-Patron

1. **Inconsistencia de locale**: Depende de la configuracion del navegador
2. **Duplicacion**: La misma logica de formateo en multiples archivos
3. **Precision**: `toFixed()` no es adecuado para moneda
4. **Multi-moneda**: Hardcodear '$' no funciona para otras monedas

### Ejemplos Encontrados

#### Ejemplo 1: AnalisisVencimientos/Views/Index.cshtml (lineas 403-404)

```javascript
// ANTI-PATRON: Formateo dependiente del browser
document.getElementById('totalGeneral').textContent = totalGeneral.toLocaleString('es-CL');
document.getElementById('totalSaldo').textContent = totalSaldo.toLocaleString('es-CL');
```

#### Ejemplo 2: BalanceClasificado/Views/Index.cshtml (lineas 627-629)

```javascript
// ANTI-PATRON: Formateo inline con opciones
const saldoFormateado = fila.saldo != null && fila.saldo !== 0
    ? '$' + fila.saldo.toLocaleString('es-CL', {minimumFractionDigits: 0, maximumFractionDigits: 0})
    : '';
```

#### Ejemplo 3: ConversionMonedas/Views/Index.cshtml (lineas 316-319)

```javascript
// ANTI-PATRON: toFixed para decimales de moneda
document.getElementById('txtResultado').value = result.valorConvertido.toFixed(2);
document.getElementById('txtEquivOrigen').value = result.equivalenciaOrigen.toFixed(4);
```

#### Ejemplo 4: GestionActivoFijo/Views/Create.cshtml (lineas 419-421)

```javascript
// ANTI-PATRON: Funcion de formateo duplicada en cada archivo
function formatCurrency(amount) {
    return new Intl.NumberFormat('es-CL', {
        style: 'currency',
        currency: 'CLP',
        minimumFractionDigits: 0
    }).format(amount);
}
```

### Solucion ASP.NET Core MVC

#### Formateo server-side con cultura configurada

**1. Configurar cultura en Startup:**

```csharp
public void Configure(IApplicationBuilder app)
{
    var cultureInfo = new CultureInfo("es-CL");
    cultureInfo.NumberFormat.CurrencySymbol = "$";
    cultureInfo.NumberFormat.CurrencyDecimalDigits = 0;

    app.UseRequestLocalization(new RequestLocalizationOptions
    {
        DefaultRequestCulture = new RequestCulture(cultureInfo),
        SupportedCultures = new[] { cultureInfo }
    });
}
```

**2. ViewModel con propiedades formateadas:**

```csharp
public class DocumentoItem
{
    public decimal Total { get; set; }
    public decimal Saldo { get; set; }
    public DateTime FechaVencimiento { get; set; }

    // Propiedades formateadas para la vista
    public string TotalFormateado => Total.ToString("C0");
    public string SaldoFormateado => Saldo.ToString("C0");
    public string FechaFormateada => FechaVencimiento.ToString("dd/MM/yyyy");
}
```

**3. Vista usa valores pre-formateados:**

```html
<td class="text-right">@item.TotalFormateado</td>
<td class="text-right">@item.SaldoFormateado</td>
<td>@item.FechaFormateada</td>
```

**4. Display Templates para consistencia:**

```html
<!-- Views/Shared/DisplayTemplates/Currency.cshtml -->
@model decimal
@Model.ToString("C0")
```

```html
<!-- Uso en vista -->
<td>@Html.DisplayFor(m => item.Total, "Currency")</td>
```

---

## Anti-Patron 6: Validaciones Duplicadas

### Descripcion del Problema

Se implementan las mismas validaciones tanto en JavaScript (para UX) como en el servidor (para seguridad), creando duplicacion y posible divergencia.

### Por que es un Anti-Patron

1. **Mantenimiento**: Cambiar una regla requiere cambios en 2 lugares
2. **Divergencia**: Las reglas pueden volverse inconsistentes
3. **Codigo duplicado**: Misma logica escrita dos veces
4. **Mensajes diferentes**: Usuario ve mensajes distintos en cliente vs servidor

### Ejemplos Encontrados

#### Ejemplo 1: ConversionMonedas/Views/Index.cshtml (lineas 241-270)

```javascript
// ANTI-PATRON: Validaciones que se repiten en el servidor
async function ejecutarConversion() {
    const idMonedaOrigen = parseInt(document.getElementById('cbMonedaOrigen').value);
    const idMonedaDestino = parseInt(document.getElementById('cbMonedaDestino').value);
    const valor = parseFloat(document.getElementById('txtValor').value);

    // Validacion 1 - tambien existe en ConversionController.cs
    if (!idMonedaOrigen) {
        Swal.fire('Error', 'Debe seleccionar moneda de origen', 'warning');
        return;
    }

    // Validacion 2 - tambien existe en ConversionController.cs
    if (!idMonedaDestino) {
        Swal.fire('Error', 'Debe seleccionar moneda de destino', 'warning');
        return;
    }

    // Validacion 3 - tambien existe en ConversionController.cs
    if (!valor || valor <= 0) {
        Swal.fire('Error', 'Debe ingresar un valor mayor a cero', 'warning');
        return;
    }

    // ... enviar al servidor que valida todo de nuevo
}
```

#### Ejemplo 2: Auth/Views/CambiarPassword.cshtml (lineas 159-169)

```javascript
// ANTI-PATRON: Validacion de coincidencia de passwords
function checkPasswordMatch() {
    if (newPassword.value === confirmPassword.value) {
        message.innerHTML = '<i class="fas fa-check mr-1"></i>Las contraseñas coinciden';
    } else {
        message.innerHTML = '<i class="fas fa-times mr-1"></i>Las contraseñas no coinciden';
    }
    // El servidor tambien valida esto en ChangePasswordRequest
}
```

#### Ejemplo 3: GestionActivoFijo/Views/Create.cshtml (lineas 387-390)

```javascript
// ANTI-PATRON: Validar campos requeridos en JS
if (!fechaUtilizacion || !valorCompra || !vidaUtilMeses) {
    Swal.fire('Error', 'Debe completar fecha de utilizacion, valor de compra y vida util', 'warning');
    return;
}
// El ViewModel tiene [Required] en estos mismos campos
```

### Solucion ASP.NET Core MVC

#### Usar DataAnnotations + Validacion Remota + jQuery Validation

**1. ViewModel con DataAnnotations:**

```csharp
public class ConversionRequest : IValidatableObject
{
    [Required(ErrorMessage = "Debe seleccionar moneda de origen")]
    [Display(Name = "Moneda Origen")]
    public int? IdMonedaOrigen { get; set; }

    [Required(ErrorMessage = "Debe seleccionar moneda de destino")]
    [Display(Name = "Moneda Destino")]
    public int? IdMonedaDestino { get; set; }

    [Required(ErrorMessage = "Debe ingresar un valor")]
    [Range(0.01, double.MaxValue, ErrorMessage = "El valor debe ser mayor a cero")]
    [Display(Name = "Valor")]
    public decimal? Valor { get; set; }

    // Validacion de negocio
    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (IdMonedaOrigen == IdMonedaDestino)
        {
            yield return new ValidationResult(
                "La moneda de origen y destino deben ser diferentes",
                new[] { nameof(IdMonedaDestino) });
        }
    }
}
```

**2. Vista con validacion automatica:**

```html
<form asp-action="Convertir" method="post">
    <div class="form-group">
        <label asp-for="IdMonedaOrigen"></label>
        <select asp-for="IdMonedaOrigen" asp-items="Model.Monedas" class="form-control">
            <option value="">-- Seleccione --</option>
        </select>
        <span asp-validation-for="IdMonedaOrigen" class="text-danger"></span>
    </div>

    <div class="form-group">
        <label asp-for="Valor"></label>
        <input asp-for="Valor" class="form-control" />
        <span asp-validation-for="Valor" class="text-danger"></span>
    </div>

    <button type="submit">Convertir</button>
</form>

@section Scripts {
    <partial name="_ValidationScriptsPartial" />
}
```

**3. Para validaciones asincronas, usar [Remote]:**

```csharp
public class CambiarPasswordRequest
{
    [Required]
    public string PasswordActual { get; set; }

    [Required]
    [StringLength(100, MinimumLength = 8)]
    [Remote(action: "ValidarPassword", controller: "Auth",
            ErrorMessage = "La contrasena no cumple los requisitos")]
    public string NuevaPassword { get; set; }

    [Required]
    [Compare(nameof(NuevaPassword), ErrorMessage = "Las contrasenas no coinciden")]
    public string ConfirmarPassword { get; set; }
}
```

**4. Validacion automatica en cliente y servidor:**

```javascript
// NO se necesita JavaScript para validar
// jQuery Unobtrusive Validation lo hace automaticamente
// basado en los data-val-* attributes generados por ASP.NET Core
```

---

## Resumen de Archivos por Prioridad de Refactorizacion

### Prioridad Alta (Multiples Anti-Patrones)

| Archivo | Anti-Patrones | Lineas JS |
|---------|---------------|-----------|
| AnalisisVencimientos/Views/Index.cshtml | 1,3,4,5,6 | ~500 |
| ConfiguracionComprobanteActivoFijo/Views/Index.cshtml | 1,2,3,4 | ~450 |
| GestionActivoFijo/Views/Create.cshtml | 1,2,4,5,6 | ~400 |
| BaseImponible14DCompleta/Views/Index.cshtml | 2,3,4 | ~600 |
| BalanceClasificado/Views/Index.cshtml | 1,3,4,5 | ~700 |
| AbrirCerrarMes/Views/Index.cshtml | 1,2,3 | ~400 |

### Prioridad Media

| Archivo | Anti-Patrones | Lineas JS |
|---------|---------------|-----------|
| Apertura/Views/Index.cshtml | 1,2,3 | ~300 |
| ConversionMonedas/Views/Index.cshtml | 2,5,6 | ~350 |
| CuentasAjustesRli/Views/Index.cshtml | 2,3 | ~300 |
| AjustesRliCaja/Views/Index.cshtml | 1,3 | ~250 |

### Prioridad Baja

| Archivo | Anti-Patrones | Lineas JS |
|---------|---------------|-----------|
| Auth/Views/CambiarPassword.cshtml | 1,6 | ~100 |
| AsistenteImportacionPrimeraCategoria/Views/Index.cshtml | 3 | ~200 |

---

## Checklist de Refactorizacion

Para cada archivo, seguir estos pasos:

### Fase 1: Eliminar innerHTML
- [ ] Identificar todas las construcciones de HTML en JS
- [ ] Crear EditorTemplates para filas de tabla
- [ ] Crear Partial Views para secciones dinamicas
- [ ] Cambiar endpoints para retornar HTML renderizado

### Fase 2: Eliminar JSON.stringify
- [ ] Identificar todos los fetch() con body JSON
- [ ] Convertir a formularios HTML con Model Binding
- [ ] Para colecciones, usar nomenclatura de indices

### Fase 3: Eliminar Estado Global
- [ ] Identificar variables let/var a nivel modulo
- [ ] Mover estado al ViewModel
- [ ] Recargar Partial Views en vez de modificar estado

### Fase 4: Mover Calculos al Servidor
- [ ] Identificar calculos de totales/sumas
- [ ] Agregar propiedades calculadas al ViewModel
- [ ] Eliminar funciones de calculo en JS

### Fase 5: Centralizar Formateo
- [ ] Identificar usos de toLocaleString/toFixed
- [ ] Crear propiedades *Formateado en ViewModels
- [ ] Crear DisplayTemplates para Currency/Date

### Fase 6: Unificar Validaciones
- [ ] Eliminar validaciones JS manuales
- [ ] Agregar DataAnnotations completos
- [ ] Implementar IValidatableObject para reglas complejas
- [ ] Usar [Remote] para validaciones async
- [ ] Incluir _ValidationScriptsPartial

---

## Ejemplo Completo de Refactorizacion

### Antes: AnalisisVencimientos/Views/Index.cshtml

```javascript
// 500+ lineas de JavaScript con todos los anti-patrones

let documentos = [];  // Estado global

function renderDocumentos() {
    const tbody = document.getElementById('tbody');
    tbody.innerHTML = '';  // innerHTML

    documentos.forEach(doc => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${doc.numero}</td>
            <td>${doc.total.toLocaleString('es-CL')}</td>  // Formateo JS
        `;
        tbody.appendChild(tr);
    });

    calcularTotales();  // Calculo en JS
}

function calcularTotales() {
    const total = documentos.reduce((sum, d) => sum + d.total, 0);
    document.getElementById('total').textContent = '$' + total.toLocaleString('es-CL');
}

async function filtrar() {
    if (!document.getElementById('fecha').value) {  // Validacion duplicada
        Swal.fire('Error', 'Seleccione fecha', 'warning');
        return;
    }

    const response = await fetch('/api/documentos', {
        method: 'POST',
        body: JSON.stringify({ fecha: fecha, tipo: tipo })  // JSON manual
    });

    documentos = await response.json();
    renderDocumentos();
}
```

### Despues: AnalisisVencimientos (Refactorizado)

**ViewModel:**
```csharp
public class AnalisisVencimientosViewModel : IValidatableObject
{
    [Required(ErrorMessage = "Seleccione fecha")]
    public DateTime? Fecha { get; set; }

    public int? TipoDocumento { get; set; }

    public List<DocumentoVencimientoItem> Documentos { get; set; } = new();

    // Calculado server-side
    public decimal TotalGeneral => Documentos.Sum(d => d.Total);
    public string TotalGeneralFormateado => TotalGeneral.ToString("C0");

    public IEnumerable<ValidationResult> Validate(ValidationContext ctx)
    {
        // Validaciones de negocio centralizadas
        yield break;
    }
}

public class DocumentoVencimientoItem
{
    public string Numero { get; set; }
    public decimal Total { get; set; }
    public string TotalFormateado => Total.ToString("C0");
}
```

**Vista Principal:**
```html
@model AnalisisVencimientosViewModel

<form id="frmFiltros" asp-action="Filtrar" method="get">
    <input asp-for="Fecha" type="date" />
    <span asp-validation-for="Fecha" class="text-danger"></span>

    <button type="submit">Filtrar</button>
</form>

<div id="resultados">
    <partial name="_DocumentosLista" model="Model" />
</div>

@section Scripts {
    <partial name="_ValidationScriptsPartial" />
    <script>
        // Solo 20 lineas de JS para AJAX
        document.getElementById('frmFiltros').addEventListener('submit', async (e) => {
            e.preventDefault();
            if (!$(e.target).valid()) return;

            const response = await fetch('/AnalisisVencimientos/Filtrar?' + new URLSearchParams(new FormData(e.target)));
            document.getElementById('resultados').innerHTML = await response.text();
        });
    </script>
}
```

**Partial View _DocumentosLista.cshtml:**
```html
@model AnalisisVencimientosViewModel

<table>
    <tbody>
    @foreach (var doc in Model.Documentos)
    {
        <tr>
            <td>@doc.Numero</td>
            <td class="text-right">@doc.TotalFormateado</td>
        </tr>
    }
    </tbody>
    <tfoot>
        <tr class="font-bold">
            <td>Total:</td>
            <td class="text-right">@Model.TotalGeneralFormateado</td>
        </tr>
    </tfoot>
</table>
```

**Resultado:**
- De ~500 lineas JS a ~20 lineas
- Validaciones centralizadas en DataAnnotations
- Calculos server-side con precision decimal
- Formateo consistente via ToString()
- Sin estado global
- Sin innerHTML

---

## Conclusiones

Los anti-patrones identificados son comunes en migraciones de aplicaciones de escritorio a web. La solucion no requiere frameworks JavaScript modernos (React, Vue, Angular), sino aprovechar las capacidades nativas de ASP.NET Core MVC:

1. **EditorTemplates** y **Partial Views** reemplazan innerHTML
2. **Model Binding** reemplaza JSON.stringify
3. **ViewModels** reemplazan estado global
4. **Propiedades calculadas** reemplazan calculos JS
5. **ToString() con cultura** reemplaza toLocaleString
6. **DataAnnotations + [Remote]** reemplazan validaciones duplicadas

El patron recomendado es **Server-Side Rendering con AJAX parcial**: el servidor renderiza HTML completo, y JavaScript solo se usa para coordinar actualizaciones via fetch() que retornan HTML pre-renderizado.
