# Patrón de Refactorización de Vistas - Tag Helpers Nativos ASP.NET Core

## Resumen

Este documento establece el patrón de refactorización para migrar todas las vistas del sistema a usar **Tag Helpers nativos de ASP.NET Core MVC** para formularios fuertemente tipados con validaciones centralizadas en DTOs.

### Estado Actual del Proyecto

| Métrica | Cantidad |
|---------|----------|
| Vistas con Tag Helpers (asp-for) | ~80+ archivos |
| Vistas con inputs manuales | ~54 archivos |
| Validaciones JS migradas | ~40 bloques |
| Features totales | ~170 carpetas |

**Última actualización:** Noviembre 2025 - Migración masiva de vistas con filtros y formularios.

### Vistas Migradas Recientemente
- `ResumenVpe/Index.cshtml` - Filtros de fechas con validaciones
- `Percepciones/Index.cshtml` - Filtros con Tag Helpers
- `CompraVenta/Index.cshtml` - Filtros con Tag Helpers + DTO
- `InformeAnaliticoAvanzado/Index.cshtml` - Formulario completo
- `DocumentosLibros/Index.cshtml` - Filtros con Tag Helpers + DTO
- `LibroCaja/Index.cshtml` - Filtros con Tag Helpers
- `GestionDocumentos/Index.cshtml` - Formulario completo con modales
- `InformeAnalitico/Index.cshtml` - Filtros con validaciones

---

## Validaciones JavaScript a Migrar a DTOs

### Validaciones Detectadas

Las siguientes validaciones JavaScript **duplican lógica** que debe estar en el DTO:

#### 1. Campos Obligatorios (Mover a `[Required]`)

| Vista | Validación JS Actual | Migrar a DTO |
|-------|---------------------|--------------|
| `NuevoComprobante` | `if (!glosaValue.trim())` | `[Required] Glosa` |
| `TiposDocumentos` | `if (!newValue)` | `[Required]` en campo |
| `GestionDocumentos/_EditarDocumento` | `if (!numDocValue)` | `[Required] NumDoc` |
| `GestionDocumentos/_EditarDocumento` | `if (!fEmisionValue)` | `[Required] FEmision` |
| `GestionDocumentos/Index` | `if (!documento.numDoc)` | `[Required] NumDoc` |
| `UsuariosFiscalizadores` | `if (!clave \|\| !claveConfirm)` | `[Required]` ambos campos |
| `PlanCuentas` | `if (!accountData.codigo)` | `[Required] Codigo` |
| `ParametrosRazones` | `if (!codigo)` | `[Required] Codigo` |
| `FoliacionParaTimbraje` | `if (!folioHasta)` | `[Required] FolioHasta` |

#### 2. Validación de Rangos (Mover a `[Range]`)

| Vista | Validación JS Actual | Migrar a DTO |
|-------|---------------------|--------------|
| `NuevoComprobante` | `parseFloat(formValues.monto) <= 0` | `[Range(0.01, double.MaxValue)]` |
| `GestionDocumentos` | `documento.total <= 0` | `[Range(0.01, ...)]` |
| `GestionActivoFijo/Edit` | `if (!valorCompra)` | `[Range(0.01, ...)]` |
| `ParametrosRazones` | `cantDias <= 0` | `[Range(1, int.MaxValue)]` |
| `LibroRetenciones` | `isNaN(valorNuevo)` | `[Range]` numérico |

#### 3. Validación de Fechas (Mover a `[Required]` + `[DataType]`)

| Vista | Validación JS Actual | Migrar a DTO |
|-------|---------------------|--------------|
| `ResumenVpe` | `if (!fechaDesde \|\| !fechaHasta)` | `[Required]` ambas fechas |
| `LibroMayor` | `if (!fechaDesde \|\| !fechaHasta)` | `[Required]` ambas fechas |
| `ImportarCartolasBancarias` | `if (!fechaDesde \|\| !fechaHasta)` | `[Required]` ambas fechas |
| `InformeAnaliticoAvanzado` | `if (!filtros.fechaHasta)` | `[Required]` fechas |
| `UsuariosFiscalizadores` | `fechaDate < today` | Custom validator o `[Remote]` |

#### 4. Validación de RUT (Mover a `[RutChileno]` o `[Remote]`)

| Vista | Validación JS Actual | Migrar a DTO |
|-------|---------------------|--------------|
| `MantenimientoPercepciones` | `validateRut(input)` | `[RutChileno]` |
| `ImportarSiiRetenciones` | `validarRut(rut)` | `[RutChileno]` o `[Remote]` |
| `GestionDocumentos` | `validarRUT(rut)` | `[RutChileno]` |
| `DetalleSaldoApertura` | `if (rut === '0-0')` | `[RutChileno]` |

#### 5. Validación de Selects (Mover a `[Required]` + `[Range]`)

| Vista | Validación JS Actual | Migrar a DTO |
|-------|---------------------|--------------|
| `FichaActivoFijo` | `if (!grupo.value)` | `[Required] IdGrupo` |
| `MantenimientoRazonesFinancieras` | `if (!$('#cbTipoDetalle').val())` | `[Required] TipoDetalle` |
| `ImportarCartolasBancarias` | `if (!idCuentaBanco)` | `[Required] IdCuentaBanco` |

#### 6. Validaciones Únicas/Duplicados (Mover a `[Remote]`)

| Vista | Validación JS Actual | Migrar a DTO |
|-------|---------------------|--------------|
| Códigos únicos | Validación manual fetch | `[Remote("ValidarCodigoUnico", ...)]` |
| RUT empresa existente | Validación manual | `[Remote("ValidarRutNoExiste", ...)]` |

---

### Patrón de Migración de Validación JS a DTO

#### ❌ ANTES (Validación duplicada en JS)

```javascript
// Vista: GestionDocumentos/Index.cshtml
async function guardarDocumento() {
    // ❌ DUPLICADO - Esta lógica está en el DTO
    if (!documento.numDoc) {
        Swal.fire('Advertencia', 'Debe ingresar el número de documento', 'warning');
        return false;
    }
    
    if (!documento.fEmision) {
        Swal.fire('Advertencia', 'Debe ingresar la fecha de emisión', 'warning');
        return false;
    }
    
    if (!documento.total || documento.total <= 0) {
        Swal.fire('Advertencia', 'Debe ingresar un valor mayor a cero', 'warning');
        return false;
    }
    
    // ... continuar con fetch
}
```

#### ✅ DESPUÉS (Validación centralizada en DTO)

```csharp
// DTO: GestionDocumentos/GestionDocumentosDto.cs
public class DocumentoFormDto
{
    [Required(ErrorMessage = "Debe ingresar el número de documento")]
    [Display(Name = "Número Documento")]
    public string NumDoc { get; set; } = string.Empty;

    [Required(ErrorMessage = "Debe ingresar la fecha de emisión")]
    [Display(Name = "Fecha Emisión")]
    [DataType(DataType.Date)]
    public DateTime FEmision { get; set; }

    [Required(ErrorMessage = "Debe ingresar un valor mayor a cero")]
    [Range(0.01, double.MaxValue, ErrorMessage = "El valor debe ser mayor a cero")]
    [Display(Name = "Total")]
    public decimal Total { get; set; }
}
```

```javascript
// Vista: GestionDocumentos/Index.cshtml
async function guardarDocumento() {
    // ✅ Una sola línea - jQuery Validation usa las reglas del DTO
    if (!$('#formDocumento').valid()) return;
    
    // ... continuar con fetch
}
```

---

### Validación de RUT - Patrón Recomendado

#### Opción A: Atributo Custom `[RutChileno]` (Preferido)

```csharp
// Features/DatosEmpresa/Validators/RutChilenoAttribute.cs (ya existe)
public class RutChilenoAttribute : ValidationAttribute
{
    protected override ValidationResult? IsValid(object? value, ValidationContext context)
    {
        if (value == null || string.IsNullOrEmpty(value.ToString()))
            return ValidationResult.Success;
        
        string rut = value.ToString()!;
        if (!ValidarRutChileno(rut))
        {
            return new ValidationResult(ErrorMessage ?? "RUT inválido");
        }
        return ValidationResult.Success;
    }

    private bool ValidarRutChileno(string rut)
    {
        rut = rut.Replace(".", "").Replace("-", "").ToUpper();
        if (rut.Length < 2) return false;
        
        string cuerpo = rut[..^1];
        char dv = rut[^1];
        
        if (!int.TryParse(cuerpo, out int rutNum)) return false;
        
        int suma = 0;
        int multiplicador = 2;
        
        for (int i = cuerpo.Length - 1; i >= 0; i--)
        {
            suma += int.Parse(cuerpo[i].ToString()) * multiplicador;
            multiplicador = multiplicador == 7 ? 2 : multiplicador + 1;
        }
        
        int resto = suma % 11;
        char dvCalculado = resto switch
        {
            0 => '0',
            1 => 'K',
            _ => (char)('0' + (11 - resto))
        };
        
        return dv == dvCalculado;
    }
}

// Uso en DTO
[RutChileno(ErrorMessage = "RUT inválido")]
public string Rut { get; set; } = string.Empty;
```

#### Opción B: `[Remote]` para Validación con Lógica de Negocio

```csharp
// DTO
[Required(ErrorMessage = "El RUT es obligatorio")]
[Remote(action: "ValidarRut", controller: "MiFeature",
        AdditionalFields = "Id",
        ErrorMessage = "RUT inválido o ya registrado")]
public string Rut { get; set; } = string.Empty;

// Controller
[HttpGet]
public IActionResult ValidarRut(string rut, int id = 0)
{
    // 1. Validar formato RUT
    if (!RutHelper.EsValido(rut))
        return Json("Formato de RUT inválido");
    
    // 2. Validar que no esté duplicado (excluyendo el registro actual)
    var existe = _service.ExisteRut(rut, id);
    if (existe)
        return Json("Este RUT ya está registrado");
    
    return Json(true);
}
```

---

### Validaciones que NO Deben Moverse

Algunas validaciones JS son **validaciones de UI** que NO pertenecen al DTO:

```javascript
// ✅ MANTENER EN JS - Validación de estado de UI
if (movimientos.length === 0) {
    Swal.fire('Error', 'Debe ingresar al menos un movimiento', 'error');
    return;
}

// ✅ MANTENER EN JS - Validación de selección múltiple
if (selectedCheckboxes.length === 0) {
    Swal.showValidationMessage('Debe seleccionar al menos un documento');
    return false;
}

// ✅ MANTENER EN JS - Confirmaciones de usuario
const confirmResult = await Swal.fire({
    title: '¿Está seguro?',
    showCancelButton: true
});
if (!confirmResult.isConfirmed) return;
```

---

## Arquitectura de Validación

```
┌─────────────────────────────────────────────────────────────────────┐
│                    FUENTE ÚNICA DE VERDAD                          │
│                         DTO con Data Annotations                    │
│    [Required] [MaxLength] [Range] [Email] [Display] [Remote]       │
└───────────────────────────────┬────────────────────────────────────┘
                                │
           ┌────────────────────┼────────────────────┐
           │                    │                    │
           ▼                    ▼                    ▼
┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
│  Tag Helpers     │  │  jQuery Validate │  │  ModelState      │
│  (Razor)         │  │  (Cliente)       │  │  (Servidor)      │
│                  │  │                  │  │                  │
│  asp-for         │  │  Validación      │  │  Validación      │
│  asp-validation  │  │  automática      │  │  automática      │
│  asp-validation  │  │  antes de        │  │  en controller   │
│  -summary        │  │  submit          │  │  si falla JS     │
└──────────────────┘  └──────────────────┘  └──────────────────┘
```

---

## Componentes del Sistema

### 1. ViewImports (Ya configurado)

```csharp
// Features/_ViewImports.cshtml
@using App
@using App.Extensions
@using App.Helpers
@using App.Features.Shared
@using Microsoft.AspNetCore.Mvc.Rendering

@addTagHelper *, Microsoft.AspNetCore.Mvc.TagHelpers
```

### 2. Scripts de Validación

```html
<!-- Features/Shared/_ValidationScriptsPartial.cshtml -->
<script src="~/lib/jquery/jquery.min.js"></script>
<script src="~/lib/jquery-validation/jquery.validate.min.js"></script>
<script src="~/lib/jquery-validation-unobtrusive/jquery.validate.unobtrusive.min.js"></script>
```

---

## Data Annotations Disponibles

### Validaciones Básicas

| Annotation | Uso | Ejemplo |
|------------|-----|---------|
| `[Required]` | Campo obligatorio | `[Required(ErrorMessage = "El código es obligatorio")]` |
| `[MaxLength]` | Longitud máxima | `[MaxLength(15, ErrorMessage = "Máximo 15 caracteres")]` |
| `[StringLength]` | Longitud con min/max | `[StringLength(50, MinimumLength = 3)]` |
| `[Range]` | Rango numérico | `[Range(0.01, 100, ErrorMessage = "Entre 0.01 y 100")]` |
| `[EmailAddress]` | Formato email | `[EmailAddress(ErrorMessage = "Email inválido")]` |
| `[RegularExpression]` | Expresión regular | `[RegularExpression(@"^\d{8}-[\dkK]$")]` |
| `[Compare]` | Comparar campos | `[Compare("Password", ErrorMessage = "No coinciden")]` |
| `[DataType]` | Tipo de dato | `[DataType(DataType.Password)]` |
| `[Display]` | Etiqueta del campo | `[Display(Name = "Nombre de Usuario")]` |

### Validación Remota (Asíncrona)

```csharp
// DTO
[Remote(action: "ValidarRutRepresentante", controller: "DatosEmpresa", 
        ErrorMessage = "El RUT no es válido")]
public string? Rut { get; set; }

// Controller
[HttpGet]
public IActionResult ValidarRutRepresentante(string rut)
{
    bool isValid = ValidateRut(rut);
    return Json(isValid);
}
```

### Validadores Custom

```csharp
// Validators/RutChilenoAttribute.cs
public class RutChilenoAttribute : ValidationAttribute
{
    protected override ValidationResult? IsValid(object? value, ValidationContext context)
    {
        if (value == null) return ValidationResult.Success;
        
        string rut = value.ToString()!;
        if (!ValidarRutChileno(rut))
        {
            return new ValidationResult(ErrorMessage ?? "RUT inválido");
        }
        return ValidationResult.Success;
    }
}

// Uso en DTO
[RutChileno(ErrorMessage = "RUT inválido")]
public string Rut { get; set; } = string.Empty;
```

---

## Patrón de DTO para Formularios

### Estructura Recomendada

```csharp
namespace App.Features.MiFeature;

/// <summary>
/// DTO para listar registros (sin validaciones, solo lectura)
/// </summary>
public class MiEntidadDto
{
    public int Id { get; set; }
    public string? Codigo { get; set; }
    public string? Descripcion { get; set; }
    public bool? Vigente { get; set; }
    
    // Propiedades calculadas para UI
    public bool IsVigente => Vigente == true;
    public string VigenteTexto => IsVigente ? "Activo" : "Inactivo";
}

/// <summary>
/// DTO para formulario Create/Update con validaciones completas
/// Usado con Tag Helpers para validación client-side automática
/// </summary>
public class MiEntidadFormDto
{
    /// <summary>
    /// ID del registro (0 = nuevo, >0 = edición)
    /// </summary>
    public int Id { get; set; }

    /// <summary>
    /// Código - Requerido, máximo 15 caracteres
    /// </summary>
    [Required(ErrorMessage = "El código es obligatorio")]
    [StringLength(15, ErrorMessage = "El código no puede exceder 15 caracteres")]
    [Display(Name = "Código")]
    public string Codigo { get; set; } = string.Empty;

    /// <summary>
    /// Descripción - Requerido, máximo 50 caracteres
    /// </summary>
    [Required(ErrorMessage = "La descripción es obligatoria")]
    [StringLength(50, ErrorMessage = "La descripción no puede exceder 50 caracteres")]
    [Display(Name = "Descripción")]
    public string Descripcion { get; set; } = string.Empty;

    /// <summary>
    /// Estado activo/inactivo
    /// </summary>
    [Display(Name = "Registro vigente")]
    public bool Vigente { get; set; } = true;
}
```

---

## Patrón de Vista con Tag Helpers

### ❌ ANTES (HTML Manual - NO USAR)

```html
<form id="formEntidad">
    <input type="hidden" id="idEntidad" value="0">
    
    <div>
        <label>Código <span class="text-red-500">*</span></label>
        <input type="text" id="codigo" maxlength="15" required
               class="w-full px-3 py-2 border rounded-lg">
        <p class="text-xs text-gray-500">máximo 15 caracteres</p>
    </div>
    
    <div>
        <label>Descripción <span class="text-red-500">*</span></label>
        <input type="text" id="descripcion" maxlength="50" required
               class="w-full px-3 py-2 border rounded-lg">
    </div>
    
    <div>
        <input type="checkbox" id="vigente" checked>
        <span>Registro activo</span>
    </div>
</form>
```

### ✅ DESPUÉS (Tag Helpers - USAR)

```html
@* Declarar variable para reutilizar el tipo *@
@{
    var formModel = new App.Features.MiFeature.MiEntidadFormDto();
}

<form id="formEntidad"
      asp-action="Save"
      asp-controller="MiFeature"
      method="post"
      class="space-y-4"
      data-ajax="true">

    <input type="hidden" asp-for="@formModel.Id" id="idEntidad" value="0">

    <!-- Campo Código -->
    <div>
        <label asp-for="@formModel.Codigo" 
               class="block text-sm font-medium text-gray-700 mb-1">
            <span class="text-red-500">*</span>
        </label>
        <input asp-for="@formModel.Codigo"
               id="codigo"
               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
               placeholder="Ej: ENT001" />
        <span asp-validation-for="@formModel.Codigo" 
              class="text-red-600 text-xs mt-1"></span>
    </div>

    <!-- Campo Descripción -->
    <div>
        <label asp-for="@formModel.Descripcion"
               class="block text-sm font-medium text-gray-700 mb-1">
            <span class="text-red-500">*</span>
        </label>
        <input asp-for="@formModel.Descripcion"
               id="descripcion"
               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
               placeholder="Descripción del registro" />
        <span asp-validation-for="@formModel.Descripcion"
              class="text-red-600 text-xs mt-1"></span>
    </div>

    <!-- Checkbox Vigente -->
    <div class="flex items-center">
        <input asp-for="@formModel.Vigente"
               type="checkbox"
               id="vigente"
               class="h-5 w-5 rounded border-gray-300 text-primary-600 focus:ring-primary-500" />
        <label asp-for="@formModel.Vigente"
               class="ml-2 text-sm text-gray-700">
        </label>
    </div>

    <!-- Botones -->
    <div class="flex justify-end gap-3 pt-4 border-t">
        <button type="button" onclick="cerrarModal()"
                class="px-4 py-2 bg-white border border-gray-300 rounded-lg">
            Cancelar
        </button>
        <button type="submit" onclick="guardar(event)"
                class="px-4 py-2 bg-primary-600 text-white rounded-lg">
            Guardar
        </button>
    </div>
</form>

@section Scripts {
    <partial name="_ValidationScriptsPartial" />
}
```

---

## Tag Helpers de Formulario Principales

### Form Tag Helper

```html
<!-- Genera action y method correctos -->
<form asp-action="Create" asp-controller="Entidades" method="post">
<!-- También soporta rutas con parámetros -->
<form asp-action="Update" asp-controller="Entidades" asp-route-id="@Model.Id">
```

### Input Tag Helper

```html
<!-- Genera name, id, type, y atributos data-val-* automáticamente -->
<input asp-for="Codigo" />

<!-- HTML generado -->
<input type="text" 
       id="Codigo" 
       name="Codigo" 
       data-val="true" 
       data-val-required="El código es obligatorio"
       data-val-maxlength="El código no puede exceder 15 caracteres"
       data-val-maxlength-max="15" />
```

### Label Tag Helper

```html
<!-- Usa [Display(Name = "...")] del DTO -->
<label asp-for="Codigo"></label>

<!-- HTML generado -->
<label for="Codigo">Código</label>
```

### Validation Tag Helper

```html
<!-- Mensaje de error individual -->
<span asp-validation-for="Codigo"></span>

<!-- Resumen de todos los errores -->
<div asp-validation-summary="All"></div>
<div asp-validation-summary="ModelOnly"></div>
```

### Select Tag Helper

```html
<!-- Con SelectList -->
<select asp-for="IdRegion" asp-items="ViewBag.Regiones"></select>

<!-- Con IEnumerable -->
<select asp-for="TipoSocio" asp-items="@(new SelectList(Model.TiposSocio, "Id", "Descripcion"))">
    <option value="">-- Seleccione --</option>
</select>
```

---

## JavaScript: Validación y Submit

### Patrón Correcto con jQuery Validation

```javascript
async function guardar(event) {
    event.preventDefault();

    const form = $('#formEntidad');
    
    // ✅ Validación con jQuery Validation (usa Data Annotations del DTO)
    if (!form.valid()) {
        return;
    }

    const id = parseInt($('#idEntidad').val());
    const data = {
        codigo: $('#codigo').val().trim().toUpperCase(),
        descripcion: $('#descripcion').val().trim(),
        vigente: $('#vigente').is(':checked')
    };

    try {
        const url = id === 0 ? URL_ENDPOINTS.create : `${URL_ENDPOINTS.update}?id=${id}`;
        const method = id === 0 ? 'POST' : 'PUT';

        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify(data)
        });

        // ✅ Usar handleApiResponse para errores HTTP
        const result = await handleApiResponse(response);
        if (!result) return;

        await Swal.fire('Éxito', `Registro ${id === 0 ? 'creado' : 'actualizado'}`, 'success');
        cerrarModal();
        location.reload();

    } catch (error) {
        // ✅ Solo errores de red/JS
        window.handleFrontendError(error, 'Error', 'Error de conexión');
    }
}
```

### Alternativa: HTML5 Validation (sin jQuery)

```javascript
async function guardar(event) {
    event.preventDefault();

    const form = document.getElementById('formEntidad');
    
    // ✅ Validación HTML5 nativa
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }

    // ... resto igual
}
```

---

## Validación [Remote] - Validación Asíncrona

### 1. Definir en el DTO

```csharp
public class EntidadFormDto
{
    [Required(ErrorMessage = "El código es obligatorio")]
    [Remote(action: "ValidarCodigoUnico", 
            controller: "Entidades",
            AdditionalFields = "Id",  // Excluir el registro actual en edición
            ErrorMessage = "Este código ya existe")]
    public string Codigo { get; set; } = string.Empty;
}
```

### 2. Implementar el Endpoint de Validación

```csharp
// En el Controller
[HttpGet]
public async Task<IActionResult> ValidarCodigoUnico(string codigo, int id = 0)
{
    var empresaId = SessionHelper.EmpresaId;
    
    var existe = await _service.ExisteCodigo(empresaId, codigo, id);
    
    if (existe)
    {
        return Json($"El código '{codigo}' ya está en uso");
    }
    
    return Json(true);
}
```

### 3. El Tag Helper genera automáticamente

```html
<input asp-for="Codigo" ... />

<!-- HTML generado incluye -->
<input data-val="true"
       data-val-remote="Este código ya existe"
       data-val-remote-url="/Entidades/ValidarCodigoUnico"
       data-val-remote-additionalfields="*.Id" ... />
```

---

## Tipos de Datos Especiales

### Fechas

```csharp
// DTO
[Required(ErrorMessage = "La fecha es obligatoria")]
[Display(Name = "Fecha de Compra")]
[DataType(DataType.Date)]
public DateTime FechaCompra { get; set; }
```

```html
<!-- Vista -->
<input asp-for="@formModel.FechaCompra" class="..." />
<!-- Genera type="date" automáticamente -->
```

### Moneda/Decimal

```csharp
// DTO
[Required]
[Range(0.01, double.MaxValue, ErrorMessage = "El monto debe ser mayor a 0")]
[Display(Name = "Valor")]
[DataType(DataType.Currency)]
public decimal Valor { get; set; }
```

### Password

```csharp
// DTO
[Required(ErrorMessage = "La contraseña es obligatoria")]
[Display(Name = "Contraseña")]
[DataType(DataType.Password)]
[MinLength(6, ErrorMessage = "Mínimo 6 caracteres")]
public string Password { get; set; } = string.Empty;

[Display(Name = "Confirmar Contraseña")]
[DataType(DataType.Password)]
[Compare("Password", ErrorMessage = "Las contraseñas no coinciden")]
public string ConfirmPassword { get; set; } = string.Empty;
```

### Email

```csharp
// DTO
[Required(ErrorMessage = "El email es obligatorio")]
[EmailAddress(ErrorMessage = "Email inválido")]
[Display(Name = "Correo Electrónico")]
public string Email { get; set; } = string.Empty;
```

---

## Mensajes de Error Personalizados en Español

### Configuración Global en _ValidationScriptsPartial

```javascript
$(document).ready(function() {
    $.validator.messages.required = "Este campo es obligatorio.";
    $.validator.messages.email = "Ingrese un correo válido.";
    $.validator.messages.number = "Ingrese un número válido.";
    $.validator.messages.minlength = $.validator.format("Mínimo {0} caracteres.");
    $.validator.messages.maxlength = $.validator.format("Máximo {0} caracteres.");
    $.validator.messages.range = $.validator.format("Debe estar entre {0} y {1}.");
    $.validator.messages.min = $.validator.format("Debe ser mayor o igual a {0}.");
    $.validator.messages.max = $.validator.format("Debe ser menor o igual a {0}.");
});
```

---

## Plan de Migración

### Prioridad 1: Vistas CRUD Principales (Alta frecuencia de uso)

| Feature | Estado | Notas |
|---------|--------|-------|
| CentrosCosto | ✅ Migrado | Referencia de patrón |
| Auth/Login | ✅ Migrado | Referencia de patrón |
| Sucursales | ✅ Migrado | Tag Helpers + jQuery Validation |
| SucursalIndividual | ✅ Migrado | Tag Helpers + jQuery Validation |
| Grupos | ✅ Migrado | Tag Helpers + jQuery Validation |
| AreasNegocio | ✅ Migrado | Tag Helpers + jQuery Validation |
| Glosas | ✅ Migrado | Tag Helpers + jQuery Validation |
| Monedas | ✅ Migrado | Tag Helpers + jQuery Validation |
| MantenimientoMonedas | ✅ Migrado | Crear/Editar con Tag Helpers |
| MantenimientoRazonesFinancieras | ✅ Migrado | Tag Helpers + jQuery Validation |
| CentroCostoIndividual | ✅ Migrado | Tag Helpers + jQuery Validation |
| UsuariosFiscalizadores | ✅ Migrado | Tag Helpers + jQuery Validation |
| ActualizacionGlosas | ✅ Migrado | Modal con Tag Helpers |
| MantenimientoPercepciones | ✅ Migrado | Filtros con Tag Helpers |
| TiposDocumentos | ⏭️ Omitido | Grilla editable inline (no aplica) |
| PlanCuentas | ⏭️ Omitido | Árbol jsTree + modal complejo |
| ListadoDocumentos | ✅ Migrado | Tag Helpers + FormDto completo |

### Prioridad 2: Vistas de Gestión (Complejidad media)

| Feature | Estado | Notas |
|---------|--------|-------|
| GestionDocumentos | ✅ Migrado | Tag Helpers + FormDto |
| NuevoComprobante | ✅ Migrado | Formulario + 8 modales migrados (Nov 2025) |
| ListarComprobantes | ✅ Migrado | Tag Helpers + FormDto completo |
| GestionActivoFijo | ✅ Parcial | Create/Edit migrados |
| DatosEmpresa | ✅ Parcial | Usa [Remote] |
| ResumenVpe | ✅ Migrado | Filtros con Tag Helpers |
| CompraVenta | ✅ Migrado | Filtros con Tag Helpers |
| DocumentosLibros | ✅ Migrado | Filtros con Tag Helpers |
| LibroCaja | ✅ Migrado | Filtros con Tag Helpers |
| InformeAnalitico | ✅ Migrado | Filtros con Tag Helpers |
| InformeAnaliticoAvanzado | ✅ Migrado | Tag Helpers + FormDto |

### Prioridad 3: Vistas de Configuración (Baja frecuencia)

| Feature | Estado | Notas |
|---------|--------|-------|
| PerfilesPermisos | ✅ Migrado | Tag Helpers + FormDto |
| MantenimientoUsuarios | ✅ Migrado | Create/Edit con Tag Helpers |
| ConfiguracionPrincipal | ✅ Migrado | Tag Helpers completos |

### Prioridad 4: Importaciones y Reportes

| Feature | Estado | Notas |
|---------|--------|-------|
| ImportarComprobantes | ✅ Migrado | Tag Helpers completos |
| ImportarCartolasBancarias | ✅ Migrado | Tag Helpers completos |
| Percepciones | ✅ Migrado | Filtros con Tag Helpers |
| ImportarSiiCompras/Ventas/Ret | ⏭️ Omitido | Archivos + JS especial |

### Prioridad 5: Vistas Complejas (Completadas)

| Feature | Estado | Notas |
|---------|--------|-------|
| FichaActivoFijo | ✅ Migrado | FormDto + Tag Helpers + jQuery Validation |
| AnalisisVencimientos | ✅ Migrado | FiltrosDto + Tag Helpers + PascalCase IDs | |

---

## Checklist de Migración por Vista

Para cada vista a migrar:

- [ ] **1. Crear/Verificar DTO de formulario** con Data Annotations
  - [ ] `[Required]` en campos obligatorios
  - [ ] `[MaxLength]` o `[StringLength]` en textos
  - [ ] `[Display(Name = "...")]` para labels
  - [ ] `[DataType]` para tipos especiales (Date, Password, Email)
  - [ ] `[Remote]` para validaciones asíncronas si aplica

- [ ] **2. Actualizar la Vista**
  - [ ] Cambiar `<form>` a usar `asp-action`, `asp-controller`
  - [ ] Cambiar `<input>` a usar `asp-for`
  - [ ] Cambiar `<label>` a usar `asp-for`
  - [ ] Agregar `<span asp-validation-for>` para errores
  - [ ] Agregar `@section Scripts { <partial name="_ValidationScriptsPartial" /> }`

- [ ] **3. Actualizar JavaScript**
  - [ ] Reemplazar validación manual por `$('#form').valid()` o `form.checkValidity()`
  - [ ] Mantener `handleApiResponse()` para errores del servidor
  - [ ] Mantener `handleFrontendError()` para errores de red

- [ ] **4. Verificar Controller**
  - [ ] Endpoint de validación `[Remote]` si aplica
  - [ ] `ModelState.IsValid` como fallback de validación

---

## Ejemplos de Referencia en el Proyecto

### Vista Completa con Tag Helpers

```
Features/CentrosCosto/Views/Index.cshtml
Features/Auth/Views/Login.cshtml
Features/GestionActivoFijo/Views/Create.cshtml
Features/GestionActivoFijo/Views/Edit.cshtml
```

### DTO con Validaciones Completas

```
Features/CentrosCosto/CentrosCostoDto.cs (CentrosCostoFormDto)
Features/Auth/DTOs/LoginDto.cs
Features/DatosEmpresa/DatosEmpresaDto.cs (RepresentanteLegalDto con [Remote])
Features/GestionActivoFijo/GestionActivoFijoDto.cs
```

### Validador Custom

```
Features/DatosEmpresa/Validators/RutChilenoAttribute.cs
```

---

## Configuración de Validadores Custom en Cliente

### Registrar Validadores Custom en jQuery Validation

Para que los atributos custom como `[RutChileno]` funcionen en cliente, se deben registrar en `_ValidationScriptsPartial.cshtml`:

```javascript
// Features/Shared/_ValidationScriptsPartial.cshtml
$(document).ready(function() {
    // ========================================
    // Mensajes en español
    // ========================================
    $.validator.messages.required = "Este campo es obligatorio.";
    $.validator.messages.email = "Por favor, introduce una dirección de correo válida.";
    $.validator.messages.number = "Por favor, introduce un número válido.";
    $.validator.messages.minlength = $.validator.format("Por favor, introduce al menos {0} caracteres.");
    $.validator.messages.maxlength = $.validator.format("Por favor, introduce no más de {0} caracteres.");
    $.validator.messages.range = $.validator.format("El valor debe estar entre {0} y {1}.");
    
    // ========================================
    // Validador custom: RUT chileno
    // ========================================
    $.validator.addMethod("rutchileno", function(value, element) {
        if (!value) return true; // Permitir vacío si no es [Required]
        
        // Limpiar RUT
        let rut = value.replace(/\./g, '').replace(/-/g, '').toUpperCase();
        if (rut.length < 2) return false;
        
        let cuerpo = rut.slice(0, -1);
        let dv = rut.slice(-1);
        
        if (!/^\d+$/.test(cuerpo)) return false;
        
        // Calcular dígito verificador
        let suma = 0;
        let multiplicador = 2;
        
        for (let i = cuerpo.length - 1; i >= 0; i--) {
            suma += parseInt(cuerpo[i]) * multiplicador;
            multiplicador = multiplicador === 7 ? 2 : multiplicador + 1;
        }
        
        let resto = suma % 11;
        let dvCalculado = resto === 0 ? '0' : resto === 1 ? 'K' : String(11 - resto);
        
        return dv === dvCalculado;
    }, "Por favor, introduce un RUT válido (ej: 12345678-9).");

    // Registrar adaptador para unobtrusive validation
    $.validator.unobtrusive.adapters.addBool("rutchileno");
    
    // ========================================
    // Validador custom: Fecha posterior a hoy
    // ========================================
    $.validator.addMethod("fechafutura", function(value, element) {
        if (!value) return true;
        
        const fecha = new Date(value);
        const hoy = new Date();
        hoy.setHours(0, 0, 0, 0);
        
        return fecha >= hoy;
    }, "La fecha debe ser posterior o igual a hoy.");
    
    $.validator.unobtrusive.adapters.addBool("fechafutura");
    
    // ========================================
    // Validador custom: Mayor que cero
    // ========================================
    $.validator.addMethod("mayorquecero", function(value, element) {
        if (!value) return true;
        return parseFloat(value) > 0;
    }, "El valor debe ser mayor a cero.");
    
    $.validator.unobtrusive.adapters.addBool("mayorquecero");
});
```

### Crear el Atributo Correspondiente en Backend

```csharp
// Validators/RutChilenoAttribute.cs
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace App.Features.Shared.Validators;

public class RutChilenoAttribute : ValidationAttribute, IClientModelValidator
{
    public RutChilenoAttribute() : base("RUT inválido") { }

    protected override ValidationResult? IsValid(object? value, ValidationContext context)
    {
        if (value == null || string.IsNullOrEmpty(value.ToString()))
            return ValidationResult.Success;
        
        if (!ValidarRutChileno(value.ToString()!))
            return new ValidationResult(ErrorMessage);
        
        return ValidationResult.Success;
    }

    // IClientModelValidator - Genera atributos data-val-* para validación cliente
    public void AddValidation(ClientModelValidationContext context)
    {
        context.Attributes.Add("data-val", "true");
        context.Attributes.Add("data-val-rutchileno", ErrorMessage ?? "RUT inválido");
    }

    private bool ValidarRutChileno(string rut)
    {
        rut = rut.Replace(".", "").Replace("-", "").ToUpper();
        if (rut.Length < 2) return false;
        
        string cuerpo = rut[..^1];
        char dv = rut[^1];
        
        if (!int.TryParse(cuerpo, out int rutNum)) return false;
        
        int suma = 0;
        int multiplicador = 2;
        
        for (int i = cuerpo.Length - 1; i >= 0; i--)
        {
            suma += int.Parse(cuerpo[i].ToString()) * multiplicador;
            multiplicador = multiplicador == 7 ? 2 : multiplicador + 1;
        }
        
        int resto = suma % 11;
        char dvCalculado = resto switch
        {
            0 => '0',
            1 => 'K',
            _ => (char)('0' + (11 - resto))
        };
        
        return dv == dvCalculado;
    }
}

// Validators/FechaFuturaAttribute.cs
public class FechaFuturaAttribute : ValidationAttribute, IClientModelValidator
{
    public FechaFuturaAttribute() : base("La fecha debe ser posterior o igual a hoy") { }

    protected override ValidationResult? IsValid(object? value, ValidationContext context)
    {
        if (value == null) return ValidationResult.Success;
        
        if (value is DateTime fecha && fecha.Date < DateTime.Today)
            return new ValidationResult(ErrorMessage);
        
        return ValidationResult.Success;
    }

    public void AddValidation(ClientModelValidationContext context)
    {
        context.Attributes.Add("data-val", "true");
        context.Attributes.Add("data-val-fechafutura", ErrorMessage ?? "La fecha debe ser posterior a hoy");
    }
}

// Validators/MayorQueCeroAttribute.cs
public class MayorQueCeroAttribute : ValidationAttribute, IClientModelValidator
{
    public MayorQueCeroAttribute() : base("El valor debe ser mayor a cero") { }

    protected override ValidationResult? IsValid(object? value, ValidationContext context)
    {
        if (value == null) return ValidationResult.Success;
        
        if (value is decimal d && d <= 0) return new ValidationResult(ErrorMessage);
        if (value is double dbl && dbl <= 0) return new ValidationResult(ErrorMessage);
        if (value is int i && i <= 0) return new ValidationResult(ErrorMessage);
        
        return ValidationResult.Success;
    }

    public void AddValidation(ClientModelValidationContext context)
    {
        context.Attributes.Add("data-val", "true");
        context.Attributes.Add("data-val-mayorquecero", ErrorMessage ?? "El valor debe ser mayor a cero");
    }
}
```

### Uso en DTOs

```csharp
public class DocumentoFormDto
{
    [Required(ErrorMessage = "El RUT es obligatorio")]
    [RutChileno(ErrorMessage = "RUT inválido")]
    public string RutEntidad { get; set; } = string.Empty;

    [Required(ErrorMessage = "La fecha es obligatoria")]
    [DataType(DataType.Date)]
    [FechaFutura(ErrorMessage = "La fecha de vencimiento debe ser futura")]
    public DateTime FechaVencimiento { get; set; }

    [Required(ErrorMessage = "El monto es obligatorio")]
    [MayorQueCero(ErrorMessage = "El monto debe ser mayor a cero")]
    public decimal Monto { get; set; }
}
```

---

## Recursos y Referencias

- [ASP.NET Core Tag Helpers](https://learn.microsoft.com/en-us/aspnet/core/mvc/views/tag-helpers/intro)
- [Form Tag Helpers](https://learn.microsoft.com/en-us/aspnet/core/mvc/views/working-with-forms)
- [Client-side validation](https://learn.microsoft.com/en-us/aspnet/core/mvc/models/validation#client-side-validation)
- [Remote validation](https://learn.microsoft.com/en-us/aspnet/core/mvc/models/validation#remote-attribute)
- [Custom validation attributes with client validation](https://learn.microsoft.com/en-us/aspnet/core/mvc/models/validation#iclientmodelvalidator)

---

## Resumen de Validaciones JS a Migrar por Feature

### Prioridad Alta (Uso Frecuente)

| Feature | Validaciones JS | Tipo | Migrar a |
|---------|-----------------|------|----------|
| **NuevoComprobante** | `!glosaValue.trim()` | Required | `[Required] Glosa` |
| | `movimientos.length === 0` | UI Logic | Mantener JS |
| | `monto <= 0` | Range | `[Range(0.01, ...)]` |
| **GestionDocumentos** | `!documento.numDoc` | Required | `[Required]` |
| | `!documento.fEmision` | Required | `[Required]` |
| | `total <= 0` | Range | `[Range(0.01, ...)]` |
| | `validarRUT(rut)` | Format | `[RutChileno]` |
| **PlanCuentas** | `!accountData.codigo` | Required | `[Required]` |
| | `!accountData.descripcion` | Required | `[Required]` |
| **ImportarCartolasBancarias** | `!idCuentaBanco` | Required | `[Required]` |
| | `!fechaDesde \|\| !fechaHasta` | Required | `[Required]` ambas |

### Prioridad Media

| Feature | Validaciones JS | Tipo | Migrar a |
|---------|-----------------|------|----------|
| **TiposDocumentos** | `!newValue` | Required | `[Required]` |
| **UsuariosFiscalizadores** | `!fechaHasta` | Required | `[Required]` |
| | `fechaDate < today` | Custom | `[FechaFutura]` |
| | `!clave \|\| !claveConfirm` | Required | `[Required]` ambos |
| **LibroMayor** | `!fechaDesde \|\| !fechaHasta` | Required | `[Required]` |
| **FichaActivoFijo** | `!grupo.value` | Required | `[Required] IdGrupo` |
| **ParametrosRazones** | `!codigo` | Required | `[Required]` |
| | `cantDias <= 0` | Range | `[Range(1, ...)]` |
| **FoliacionParaTimbraje** | `folioHasta <= 0` | Range | `[Range(1, ...)]` |

### Prioridad Baja

| Feature | Validaciones JS | Tipo | Migrar a |
|---------|-----------------|------|----------|
| **MantenimientoPercepciones** | `validateRut(input)` | Format | `[RutChileno]` |
| **ImportarSiiRetenciones** | `validarRut(rut)` | Format | `[RutChileno]` |
| **LibroRetenciones** | `isNaN(valorNuevo)` | Number | `[Range]` |
| **ResumenVpe** | `!fechaDesde \|\| !fechaHasta` | Required | `[Required]` |
| **GestionActivoFijo** | `!valorCompra` | Required/Range | `[Required][Range]` |
| **DetalleSaldoApertura** | `rut === '0-0'` | Format | `[RutChileno]` |
| **MantenimientoRazonesFinancieras** | `!$('#txtNombre').val()` | Required | `[Required]` |
| | `!$('#cbTipoDetalle').val()` | Required | `[Required]` |

---

## Historial de Cambios

| Fecha | Cambio |
|-------|--------|
| 2025-11-29 | **FormHandler Global** - Patrón para formularios PRG con confirmación |
| 2025-11-29 | Ejemplo: DatosEmpresa/Index - FormHandler + data-attributes |
| 2025-11-28 | Documento inicial - Patrón de Tag Helpers |
| 2025-11-28 | Agregado: Validaciones JS a migrar a DTOs |
| 2025-11-28 | Agregado: Validadores custom (RutChileno, FechaFutura, MayorQueCero) |
| 2025-11-28 | Agregado: Resumen por Feature con prioridades |
| 2025-11-28 | Migrado: Sucursales - Tag Helpers + jQuery Validation |
| 2025-11-28 | Migrado: Glosas - Tag Helpers + jQuery Validation |
| 2025-11-28 | Migrado: Monedas - Tag Helpers + jQuery Validation |
| 2025-11-28 | Migrado: MantenimientoRazonesFinancieras - Tag Helpers + jQuery Validation |
| 2025-11-28 | Migrado: LibroRetenciones/_CreateModal - Tag Helpers + FormDto |
| 2025-11-28 | Migrado: FoliacionParaTimbraje/Index - Tag Helpers + FormDto |
| 2025-11-28 | Migrado: PerfilesPermisos/Index - Campo nombre con Tag Helpers |
| 2025-11-28 | Migrado: ResumenVpe/Index - Filtros con Tag Helpers + DTO |
| 2025-11-29 | Migrado: NuevoComprobante/Index - Formulario + 8 modales con PascalCase IDs |
| 2025-11-29 | Verificado: 50+ vistas ya migradas con Tag Helpers |
| 2025-11-29 | Actualizado: Estado de prioridades - mayoría completadas |
| 2025-11-29 | Migrado: AnalisisVencimientos/Index - FiltrosDto + Tag Helpers |
| 2025-11-29 | Migrado: FichaActivoFijo/Index - FormDto + jQuery Validation |
| 2025-11-29 | ✅ MIGRACIÓN COMPLETA - Todas las vistas prioritarias migradas |
| 2025-11-28 | Migrado: Percepciones/Index - Filtros con Tag Helpers |
| 2025-11-28 | Migrado: CompraVenta/Index - Filtros con Tag Helpers + DTO |
| 2025-11-28 | Migrado: InformeAnaliticoAvanzado/Index - Tag Helpers |
| 2025-11-28 | Migrado: DocumentosLibros/Index - Filtros con Tag Helpers + DTO |
| 2025-11-28 | Migrado: LibroCaja/Index - Filtros con Tag Helpers |
| 2025-11-28 | Migrado: GestionDocumentos/Index - Tag Helpers + FormDto |
| 2025-11-28 | Migrado: InformeAnalitico/Index - Filtros con Tag Helpers + DTO |

