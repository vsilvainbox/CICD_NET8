# Patrón FormHandler Global - POST con Validación y Confirmación

## Resumen

Este documento establece el patrón para formularios **PRG (Post-Redirect-Get)** tradicionales con:
- Validación automática vía jQuery Unobtrusive (Data Annotations del DTO)
- Manejo de validaciones remotas `[Remote]`
- Errores mostrados en SweetAlert2
- Confirmación antes de enviar
- **Cero JavaScript en las vistas** (solo atributos `data-`)

---

## Principios Fundamentales

### 1. POST Nativo con DTOs

> **Siempre que sea posible, enviar formularios de forma nativa con POST de DTOs.**
> El Model Binding de ASP.NET Core se encarga de mapear los campos automáticamente.

```
┌─────────────────┐     POST      ┌─────────────────┐     Model      ┌─────────────────┐
│   Vista HTML    │ ────────────► │   Controller    │ ────────────► │   DTO Tipado    │
│   (Tag Helpers) │   form data   │   Action(dto)   │   Binding     │   Validado      │
└─────────────────┘               └─────────────────┘               └─────────────────┘
```

**Ventajas del POST nativo:**
- ✅ Validación automática server-side con `ModelState.IsValid`
- ✅ Validación automática client-side con jQuery Unobtrusive
- ✅ Binding automático de campos → propiedades del DTO
- ✅ Anti-forgery token integrado
- ✅ Menos código JavaScript que mantener
- ✅ Funciona sin JavaScript habilitado (accesibilidad)

### 2. Uso Restringido de JavaScript/jQuery

> **Reservar JS/jQuery SOLO para:**
> - Manipulación de interfaz de usuario (mostrar/ocultar, habilitar/deshabilitar)
> - Carga de datos dinámicos o condicionales (cascadas de selects, autocompletado)
> - Efectos visuales y animaciones
> - Confirmaciones y alertas (SweetAlert2)
> - Validaciones especiales que NO pueden hacerse en el DTO

**❌ NO usar JS para:**
- Serializar formularios manualmente
- Hacer POST con `fetch`/`ajax` cuando un form tradicional funciona
- Validar campos que tienen Data Annotations
- Construir objetos JSON que el Model Binding puede hacer solo

### 3. Flujo Declarativo

> **El flujo estándar de validación + confirmación + submit debe ser declarativo.**
> Usar atributos `data-*` en lugar de código JavaScript inline.

---

## Vista de Referencia: `DatosEmpresa/Index.cshtml`

Esta vista implementa correctamente el patrón completo.

---

## Manejo Centralizado de TempData en `_Layout.cshtml`

Para mostrar mensajes de éxito, error y validación server-side de forma consistente en **todas** las vistas, el `_Layout.cshtml` incluye el siguiente código:

```javascript
// Manejo centralizado de TempData (Success, Error, ModelState)
document.addEventListener('DOMContentLoaded', function() {
    @if (TempData["Success"] != null)
    {
        <text>
        Swal.fire({
            icon: 'success',
            title: 'Exito',
            text: '@TempData["Success"]',
            confirmButtonColor: '#d64000'
        });
        </text>
    }

    @if (TempData["Error"] != null)
    {
        <text>
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: '@TempData["Error"]',
            confirmButtonColor: '#d64000'
        });
        </text>
    }

    @if (!ViewData.ModelState.IsValid)
    {
        <text>
        Swal.fire({
            icon: 'warning',
            title: 'Por favor corrija los errores',
            text: 'Algunos campos no pasaron la validacion del servidor',
            confirmButtonColor: '#d64000'
        });
        </text>
    }
});
```

**Ventajas de centralizar en _Layout:**
- ✅ Cualquier controller que use `TempData["Success"]` o `TempData["Error"]` mostrará el mensaje automáticamente
- ✅ No hay que duplicar código en cada vista
- ✅ Errores de validación server-side (cuando JS está deshabilitado) se muestran con SweetAlert
- ✅ Consistencia visual en toda la aplicación

---

## FormHandler Global (`_Layout.cshtml`)

El `FormHandler` está definido globalmente en `Features/Shared/_Layout.cshtml` y maneja automáticamente cualquier formulario que use los atributos `data-` correctos.

### Código del FormHandler

```javascript
/**
 * FormHandler - Manejo centralizado de envío de formularios con validación
 * Patrón: Validar → Mostrar errores O Confirmar → POST
 * 
 * Uso:
 *   <form id="miForm" data-confirm-title="¿Guardar?" data-confirm-text="Se guardarán los datos">
 *   <button type="button" data-form-submit="miForm">Guardar</button>
 * 
 * Atributos data- opcionales en el form:
 *   data-confirm-title: Título del diálogo de confirmación (default: '¿Está seguro?')
 *   data-confirm-text: Texto del diálogo (default: '¿Desea continuar con esta acción?')
 *   data-no-confirm: Si existe, no muestra confirmación y envía directo
 */
const FormHandler = {
    primaryColor: '#d64000',
    grayColor: '#6b7280',
    timeoutValidacionRemota: 3000, // 3 segundos máximo para validaciones remotas

    async esperarValidacionesRemotas($form, timeout) {
        const tiempoLimite = timeout || this.timeoutValidacionRemota;
        const inicio = Date.now();
        
        return new Promise((resolve) => {
            const verificar = () => {
                const pendientes = $form.find('.input-validation-error[data-val-remote-url]')
                    .filter(function() {
                        return $(this).hasClass('validating') || 
                               $(this).data('remote-validating');
                    });
                
                if (pendientes.length === 0 || (Date.now() - inicio) > tiempoLimite) {
                    resolve();
                } else {
                    setTimeout(verificar, 100);
                }
            };
            verificar();
        });
    },

    obtenerErroresValidacion($form) {
        const errores = [];
        $form.find('.field-validation-error').each(function() {
            const mensaje = $(this).text().trim();
            if (mensaje) {
                errores.push(mensaje);
            }
        });
        return errores;
    },

    mostrarErroresValidacion(errores) {
        const listaHtml = errores.map(e => `<li style="text-align:left; margin-bottom:4px;">• ${e}</li>`).join('');
        
        Swal.fire({
            icon: 'warning',
            title: 'Por favor corrija los siguientes errores',
            html: `<ul style="list-style:none; padding:0; margin:0;">${listaHtml}</ul>`,
            confirmButtonColor: this.primaryColor
        });
    },

    enfocarPrimerError($form) {
        const primerError = $form.find('.input-validation-error:first');
        if (primerError.length) {
            primerError.focus();
            primerError[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    },

    async procesarEnvio(formId) {
        const $form = $('#' + formId);
        if (!$form.length) {
            console.error('FormHandler: No se encontró el formulario con id:', formId);
            return;
        }

        const validator = $form.data('validator');
        if (!validator) {
            console.error('FormHandler: El formulario no tiene validador jQuery asociado');
            return;
        }

        // 1. Ejecutar validación
        const esValido = $form.valid();

        // 2. Esperar validaciones remotas
        await this.esperarValidacionesRemotas($form);

        // 3. Verificar errores
        const errores = this.obtenerErroresValidacion($form);
        if (errores.length > 0) {
            this.mostrarErroresValidacion(errores);
            this.enfocarPrimerError($form);
            return;
        }

        // 4. Si hay errores de validación estándar
        if (!esValido) {
            this.enfocarPrimerError($form);
            return;
        }

        // 5. Confirmación (si no tiene data-no-confirm)
        const noConfirm = $form.data('no-confirm') !== undefined;
        if (!noConfirm) {
            const titulo = $form.data('confirm-title') || '¿Está seguro?';
            const texto = $form.data('confirm-text') || '¿Desea continuar con esta acción?';
            
            const confirmado = await ErrorHandler.confirm(titulo, texto);
            if (!confirmado) {
                return;
            }
        }

        // 6. Enviar formulario
        $form[0].submit();
    }
};

// Hacer disponible globalmente
window.FormHandler = FormHandler;

// Handler global para botones con data-form-submit
$(document).on('click', '[data-form-submit]', async function(e) {
    e.preventDefault();
    const formId = $(this).data('form-submit');
    await FormHandler.procesarEnvio(formId);
});
```

---

## Comparación: POST Nativo vs Fetch/AJAX

### ❌ INCORRECTO: Serializar y enviar con JavaScript

```javascript
// ❌ NO HACER ESTO para formularios simples
$('#btnGuardar').on('click', async function() {
    // Validación manual duplicada
    if (!$('#nombre').val()) {
        alert('El nombre es requerido');
        return;
    }
    
    // Serialización manual
    const data = {
        id: $('#id').val(),
        nombre: $('#nombre').val(),
        descripcion: $('#descripcion').val(),
        activo: $('#activo').is(':checked')
    };
    
    // POST con fetch
    const response = await fetch('/api/entidad', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });
    
    if (response.ok) {
        window.location.href = '/entidades';
    }
});
```

**Problemas:**
- Validación duplicada (ya está en el DTO)
- Serialización manual propensa a errores
- Más código que mantener
- No funciona sin JavaScript

### ✅ CORRECTO: POST nativo con Tag Helpers

```html
<!-- ✅ HACER ESTO -->
<form id="frmEntidad" asp-action="Save" method="post"
      data-confirm-title="¿Guardar?"
      data-confirm-text="Se guardarán los cambios">
    
    <input asp-for="Id" type="hidden" />
    
    <input asp-for="Nombre" class="..." />
    <span asp-validation-for="Nombre"></span>
    
    <input asp-for="Descripcion" class="..." />
    <span asp-validation-for="Descripcion"></span>
    
    <input asp-for="Activo" type="checkbox" />
    
    <button type="button" data-form-submit="frmEntidad">Guardar</button>
</form>
```

```csharp
// Controller recibe el DTO tipado automáticamente
[HttpPost]
public IActionResult Save(EntidadDto dto)
{
    if (!ModelState.IsValid)
        return View(dto);
    
    _service.Guardar(dto);
    TempData["Success"] = "Guardado correctamente";
    return RedirectToAction("Index");
}
```

**Ventajas:**
- Cero JavaScript de serialización
- Validación automática client + server
- Model Binding automático
- Menos código, menos bugs

---

## Cuándo SÍ Usar Fetch/AJAX

El patrón fetch/AJAX es apropiado para:

| Escenario | Ejemplo | Por qué fetch |
|-----------|---------|---------------|
| **Carga dinámica** | Cascada de selects (Región → Ciudad) | No recarga la página |
| **Autocompletado** | Buscar clientes mientras escribe | Respuesta inmediata |
| **Grillas editables** | Editar celda inline | Guardar sin recargar |
| **Operaciones masivas** | Eliminar N registros seleccionados | Feedback parcial |
| **Validación async** | Verificar RUT único | Validación `[Remote]` |
| **Modales CRUD** | Crear/Editar sin salir de la página | UX fluida |

```javascript
// ✅ CORRECTO: Fetch para carga dinámica
$('#ddlRegion').on('change', async function() {
    const regionId = $(this).val();
    const response = await fetch(`/api/ciudades?regionId=${regionId}`);
    const ciudades = await response.json();
    
    const $ddlCiudad = $('#ddlCiudad');
    $ddlCiudad.empty();
    ciudades.forEach(c => $ddlCiudad.append(`<option value="${c.id}">${c.nombre}</option>`));
});
```

---

## Atributos `data-` Disponibles

### En el `<form>`

| Atributo | Descripción | Valor Default |
|----------|-------------|---------------|
| `data-confirm-title` | Título del diálogo de confirmación | `"¿Está seguro?"` |
| `data-confirm-text` | Texto/descripción del diálogo | `"¿Desea continuar con esta acción?"` |
| `data-no-confirm` | Si existe, NO muestra confirmación | - |

### En el `<button>`

| Atributo | Descripción |
|----------|-------------|
| `data-form-submit="formId"` | ID del formulario a procesar |

---

## Flujo de Ejecución

```
┌─────────────────────────────────────────────────────────────────────┐
│  Click en botón [data-form-submit="formId"]                        │
└───────────────────────────────┬─────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────────┐
│  1. Ejecutar $form.valid() - jQuery Unobtrusive Validation         │
│     (usa Data Annotations del DTO automáticamente)                 │
└───────────────────────────────┬─────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────────┐
│  2. Esperar validaciones [Remote] (máx 3 segundos)                 │
│     Si hay campos con data-val-remote-url pendientes               │
└───────────────────────────────┬─────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────────┐
│  3. ¿Hay errores de validación?                                    │
│                                                                     │
│     SÍ → Mostrar SweetAlert con lista de errores                   │
│          + Focus en primer campo con error                         │
│          + DETENER                                                  │
│                                                                     │
│     NO → Continuar                                                  │
└───────────────────────────────┬─────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────────┐
│  4. ¿Tiene data-no-confirm?                                        │
│                                                                     │
│     SÍ → Saltar confirmación                                        │
│                                                                     │
│     NO → Mostrar SweetAlert de confirmación                        │
│          Título: data-confirm-title                                 │
│          Texto: data-confirm-text                                   │
│          Si cancela → DETENER                                       │
└───────────────────────────────┬─────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────────┐
│  5. form.submit() - POST tradicional                               │
│     (PRG: Post-Redirect-Get)                                        │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Ejemplo Completo: DatosEmpresa

### Vista (`Features/DatosEmpresa/Views/Index.cshtml`)

```html
@model App.Features.DatosEmpresa.EmpresaCompletaDto

<!-- Formulario con atributos data- para FormHandler -->
<form id="frmDatosEmpresa" 
      asp-action="Save" 
      asp-controller="DatosEmpresa" 
      method="post" 
      class="space-y-6"
      data-confirm-title="¿Guardar cambios?"
      data-confirm-text="Se actualizarán los datos de la empresa">
    
    @Html.AntiForgeryToken()
    <input asp-for="IdEmpresa" type="hidden" />
    <input asp-for="Ano" type="hidden" />

    <!-- Campos con Tag Helpers -->
    <div>
        <label asp-for="DatosBasicos.RazonSocial" class="...">
            Razón Social <span class="text-red-500">*</span>
        </label>
        <input asp-for="DatosBasicos.RazonSocial" class="..." />
        <span asp-validation-for="DatosBasicos.RazonSocial" class="text-red-600 text-xs"></span>
    </div>

    <div>
        <label asp-for="DatosLegales.Giro" class="...">
            Giro Comercial <span class="text-red-500">*</span>
        </label>
        <input asp-for="DatosLegales.Giro" class="..." />
        <span asp-validation-for="DatosLegales.Giro" class="text-red-600 text-xs"></span>
    </div>

    <!-- Representante con validación [Remote] -->
    <div>
        <label asp-for="DatosLegales.Representantes[0].Rut" class="...">
            RUT Representante 1
        </label>
        <input asp-for="DatosLegales.Representantes[0].Rut" class="..." />
        <span asp-validation-for="DatosLegales.Representantes[0].Rut" class="text-red-600 text-xs"></span>
    </div>

    <!-- Botones -->
    <div class="flex justify-end space-x-3">
        <button type="button" id="btnCancel" class="...">
            Cancelar
        </button>
        
        <!-- ✅ Botón con data-form-submit -->
        <button type="button" 
                data-form-submit="frmDatosEmpresa"
                class="px-6 py-2.5 bg-primary text-white rounded-lg">
            <i class="fas fa-save mr-2"></i>Guardar
        </button>
    </div>
</form>

@section Scripts {
    <partial name="_ValidationScriptsPartial" />
    @*
        ✅ TempData (Success, Error) y errores ModelState se manejan en _Layout.cshtml
        ✅ FormHandler maneja validación y submit
        ✅ Solo agregar JS específico de esta vista si es necesario
    *@
}
```

### DTO (`Features/DatosEmpresa/DatosEmpresaDto.cs`)

```csharp
public class DatosBasicosDto
{
    public string? Rut { get; set; }
    public string? NombreCorto { get; set; }

    [Required(ErrorMessage = "La razon social es requerida")]
    [StringLength(200, ErrorMessage = "La razon social no puede exceder 200 caracteres")]
    public string? RazonSocial { get; set; }

    [StringLength(15, ErrorMessage = "La clave SII no puede exceder 15 caracteres")]
    public string? ClaveSII { get; set; }

    public DireccionDto? Direccion { get; set; }
    public ContactoDto? Contacto { get; set; }
}

public class DatosLegalesDto
{
    [Required(ErrorMessage = "El giro comercial es requerido")]
    [StringLength(80, ErrorMessage = "El giro no puede exceder 80 caracteres")]
    public string? Giro { get; set; }

    public DateTime? FechaConstitucion { get; set; }
    public DateTime? FechaInicioActividades { get; set; }
    public bool RepresentacionConjunta { get; set; }
    public List<RepresentanteLegalDto> Representantes { get; set; } = new();
}

public class RepresentanteLegalDto
{
    [StringLength(13, ErrorMessage = "El RUT no puede exceder 13 caracteres")]
    [Remote(action: "ValidarRutRepresentante", controller: "DatosEmpresa",
            ErrorMessage = "El RUT ingresado no es valido")]
    public string? Rut { get; set; }

    [StringLength(30, ErrorMessage = "El nombre no puede exceder 30 caracteres")]
    public string? Nombre { get; set; }
}
```

### Controller (`Features/DatosEmpresa/DatosEmpresaController.cs`)

```csharp
[HttpPost]
[ValidateAntiForgeryToken]
public async Task<IActionResult> Save(EmpresaCompletaDto model)
{
    if (!ModelState.IsValid)
    {
        // ✅ _Layout.cshtml mostrará automáticamente SweetAlert de advertencia
        //    porque ViewData.ModelState.IsValid será false
        return View("Index", model);
    }

    try
    {
        await _service.GuardarDatosEmpresaAsync(model);
        // ✅ _Layout.cshtml mostrará automáticamente SweetAlert de éxito
        TempData["Success"] = "Los datos de la empresa fueron guardados correctamente";
        return RedirectToAction("Index");
    }
    catch (Exception ex)
    {
        // ✅ _Layout.cshtml mostrará automáticamente SweetAlert de error
        TempData["Error"] = "Error al guardar: " + ex.Message;
        return View("Index", model);
    }
}

// Endpoint para validación [Remote]
[HttpGet]
public IActionResult ValidarRutRepresentante(string rut)
{
    if (string.IsNullOrWhiteSpace(rut))
        return Json(true); // Vacío es válido (no es [Required])

    bool esValido = RutHelper.Validar(rut);
    return Json(esValido ? true : "El RUT ingresado no es valido");
}
```

---

## Checklist para Implementar en Nuevas Vistas

### 1. En el `<form>`

- [ ] Agregar `id="formId"` único
- [ ] Usar Tag Helpers: `asp-action`, `asp-controller`, `method="post"`
- [ ] Agregar `data-confirm-title="..."` con mensaje de confirmación
- [ ] Agregar `data-confirm-text="..."` con descripción
- [ ] (Opcional) Agregar `data-no-confirm` si NO requiere confirmación

### 2. En el botón de submit

- [ ] Cambiar `type="submit"` → `type="button"`
- [ ] Agregar `data-form-submit="formId"` con el ID del form

### 3. En los campos

- [ ] Usar `asp-for="Campo"` en inputs
- [ ] Agregar `<span asp-validation-for="Campo">` para errores

### 4. En el DTO

- [ ] Agregar `[Required]` con `ErrorMessage` en español
- [ ] Agregar `[StringLength]` o `[MaxLength]` donde corresponda
- [ ] Agregar `[Remote]` para validaciones asíncronas (RUT, códigos únicos)
- [ ] **IMPORTANTE:** Usar caracteres ASCII en ErrorMessage (no ñ, ó, á)

### 5. En Scripts

- [ ] Incluir `<partial name="_ValidationScriptsPartial" />`
- [ ] **NO** agregar código de TempData (ya está en `_Layout.cshtml`)
- [ ] **NO** agregar código de validación ni submit (lo maneja FormHandler)
- [ ] Solo agregar JS si hay comportamiento específico de la vista

---

## Convenciones de UI

### Botón Cancelar: Solo en Modales

> **En formularios de página completa (no modales), NO incluir botón "Cancelar".**
> El usuario puede navegar libremente con el navegador (atrás, menú, etc.)

```html
<!-- ❌ MAL: Botón Cancelar en página completa -->
<div class="flex justify-end space-x-3">
    <button type="button" id="btnCancel">Cancelar</button>
    <button type="button" data-form-submit="form">Guardar</button>
</div>

<!-- ✅ BIEN: Solo botón Guardar en página completa -->
<div class="flex justify-end">
    <button type="button" data-form-submit="form">Guardar</button>
</div>

<!-- ✅ BIEN: Cancelar SÍ en modales (cierra el modal) -->
<div class="flex justify-end space-x-3">
    <button type="button" onclick="cerrarModal()">Cancelar</button>
    <button type="button" data-form-submit="formModal">Guardar</button>
</div>
```

**Razones:**
- El navegador ya tiene botón "Atrás"
- El menú lateral permite navegar a cualquier parte
- Menos código JS que mantener
- UX más limpia

---

## Errores Comunes y Soluciones

### Error: El formulario se envía sin validar

**Causa:** El botón tiene `type="submit"` en lugar de `type="button"`

**Solución:**
```html
<!-- ❌ MAL -->
<button type="submit" data-form-submit="form">Guardar</button>

<!-- ✅ BIEN -->
<button type="button" data-form-submit="form">Guardar</button>
```

### Error: Los errores no se muestran en SweetAlert

**Causa:** Falta el `<span asp-validation-for>` o tiene clase incorrecta

**Solución:**
```html
<!-- ✅ Cada campo debe tener su span de validación -->
<input asp-for="Campo" class="..." />
<span asp-validation-for="Campo" class="field-validation-error text-red-600 text-xs"></span>
```

### Error: Caracteres raros en mensajes de error (ó, ñ, á)

**Causa:** El archivo .cs no está en UTF-8 o hay problemas de encoding

**Solución:** Usar caracteres ASCII en ErrorMessage:
```csharp
// ❌ MAL
[Required(ErrorMessage = "La razón social es requerida")]

// ✅ BIEN  
[Required(ErrorMessage = "La razon social es requerida")]
```

### Error: Validación [Remote] bloquea el submit

**Causa:** La validación remota no termina antes del timeout

**Solución:** El FormHandler espera máximo 3 segundos. Si el endpoint es lento, optimizarlo.

### Error: No aparece el diálogo de confirmación

**Causa:** Falta ErrorHandler en _Layout o no está cargado SweetAlert2

**Solución:** Verificar que `_Layout.cshtml` tenga:
```html
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<!-- Y el código de ErrorHandler + FormHandler -->
```

### Error: No se muestra mensaje de error del servidor

**Causa:** El controller usa `TempData["Error"]` pero la vista no lo procesa

**Solución:** El manejo de TempData debe estar en `_Layout.cshtml` (ver sección "Manejo Centralizado de TempData"). Verificar que incluya:
```javascript
@if (TempData["Error"] != null)
{
    <text>
    Swal.fire({
        icon: 'error',
        title: 'Error',
        text: '@TempData["Error"]',
        confirmButtonColor: '#d64000'
    });
    </text>
}
```

### Error: Validación server-side no muestra alerta visual

**Causa:** El usuario tiene JS deshabilitado o hay validaciones solo en servidor

**Solución:** Agregar en `_Layout.cshtml` el manejo de `ModelState.IsValid`:
```javascript
@if (!ViewData.ModelState.IsValid)
{
    <text>
    Swal.fire({
        icon: 'warning',
        title: 'Por favor corrija los errores',
        text: 'Algunos campos no pasaron la validacion del servidor',
        confirmButtonColor: '#d64000'
    });
    </text>
}
```

---

## Vistas a Migrar al Patrón FormHandler

| Vista | Estado | Notas |
|-------|--------|-------|
| **DatosEmpresa/Index** | ✅ Completado | Vista de referencia |
| ConfiguracionPrincipal | ⏳ Pendiente | PRG con múltiples secciones |
| MantenimientoUsuarios/Create | ⏳ Pendiente | PRG con contraseñas |
| MantenimientoUsuarios/Edit | ⏳ Pendiente | PRG con contraseñas |
| ImportarComprobantes | ⏳ Pendiente | PRG con archivos |
| ParametrosRazones | ⏳ Pendiente | PRG simple |

---

## Historial de Cambios

| Fecha | Cambio |
|-------|--------|
| 2025-11-29 | Agregado: Manejo centralizado de TempData en _Layout.cshtml |
| 2025-11-29 | Agregado: Soporte para TempData["Error"] y ModelState.IsValid |
| 2025-11-29 | Actualizado: Ejemplo de vista sin código TempData duplicado |
| 2025-11-29 | Actualizado: Controller con comentarios sobre manejo automático |
| 2025-11-29 | Agregado: Errores comunes de TempData y validación server-side |
| 2025-11-29 | Agregado: Principios de POST nativo con DTOs |
| 2025-11-29 | Agregado: Uso restringido de JS/jQuery |
| 2025-11-29 | Agregado: Comparación POST nativo vs Fetch/AJAX |
| 2025-11-29 | Agregado: Cuándo SÍ usar Fetch/AJAX |
| 2025-11-29 | Documento inicial - FormHandler Global |
| 2025-11-29 | DatosEmpresa/Index como vista de referencia |
| 2025-11-29 | Agregado checklist de implementación |
| 2025-11-29 | Agregado sección de errores comunes |
