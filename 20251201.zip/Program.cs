using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.Cookies;
using App.Data;
using App.Extensions;
using App.Features.Auth.Services;
using App.Helpers;
using App.Services;

var builder = WebApplication.CreateBuilder(args);

// ========== DATABASE ==========
builder.Services.AddDbContext<LpContabContext>(options =>
{
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection"),
        sqlOptions =>
        {
            sqlOptions.UseQuerySplittingBehavior(QuerySplittingBehavior.SplitQuery);
            sqlOptions.UseCompatibilityLevel(120);
            sqlOptions.CommandTimeout(120); // Timeout de 120 segundos para queries pesadas
        }
    );
});

// ========== PATHBASE ==========
var pathBase = Environment.GetEnvironmentVariable("ASPNETCORE_PATHBASE") ?? "";

// ========== AUTHENTICATION ==========
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        // UsePathBase() maneja el prefijo automáticamente para redirects
        options.LoginPath = "/Auth/Login";
        options.LogoutPath = "/Auth/Logout";
        options.AccessDeniedPath = "/Auth/AccessDenied";
        options.ExpireTimeSpan = TimeSpan.FromHours(8);
        options.Cookie.HttpOnly = true;
        options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
        options.Cookie.Name = ".HyperContabilidad.Auth";
        options.Cookie.Path = string.IsNullOrEmpty(pathBase) ? "/" : pathBase;

        // options.Events.OnRedirectToLogin = context =>
        // {
        //     if (context.Request.Headers["X-Requested-With"] == "XMLHttpRequest")
        //     {
        //         context.Response.StatusCode = 401;
        //         return context.Response.WriteAsJsonAsync(new { error = "No autenticado" });
        //     }
        //     context.Response.Redirect(context.RedirectUri);
        //     return Task.CompletedTask;
        // };

        // options.Events.OnRedirectToAccessDenied = context =>
        // {
        //     if (context.Request.Headers["X-Requested-With"] == "XMLHttpRequest")
        //     {
        //         context.Response.StatusCode = 403;
        //         return context.Response.WriteAsJsonAsync(new { error = "Acceso denegado" });
        //     }
        //     context.Response.Redirect(context.RedirectUri);
        //     return Task.CompletedTask;
        // };
    });

// ========== CORE SERVICES ==========
builder.Services.AddHttpContextAccessor();
builder.Services.AddHttpClient(); // Cliente por defecto (usado por SeleccionarEmpresa)
builder.Services.AddScoped<IErrorLogService, ErrorLogService>();
builder.Services.AddScoped<ISiiAuthService, SiiAuthService>();

builder.Services
    .AddControllersWithViews(options =>
    {
        // Filtro global para loguear excepciones en BD
        options.Filters.Add<App.Filters.SmartExceptionFilter>();
    })
    .AddRazorOptions(options =>
    {
        options.ViewLocationFormats.Clear();
        options.ViewLocationFormats.Add("/Features/{1}/Views/{0}.cshtml");
        options.ViewLocationFormats.Add("/Features/Shared/{0}.cshtml");
        options.ViewLocationFormats.Add("/Features/{1}/EditorTemplates/{0}.cshtml");
        options.ViewLocationFormats.Add("/Features/Shared/EditorTemplates/{0}.cshtml");
    })
    .AddRazorRuntimeCompilation();

// ========== AUTH SERVICES ==========
builder.Services.AddScoped<IPasswordService, PasswordService>();
builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<ISessionService, SessionService>();

// ========== FEATURE SERVICES (auto-registro por reflexión) ==========
builder.Services.AddFeatureServices();

// ========== SESSION ==========
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
    options.Cookie.Name = ".HyperContabilidad.Session";
    options.Cookie.Path = string.IsNullOrEmpty(pathBase) ? "/" : pathBase;
});

var app = builder.Build();

// ========== INICIALIZAR HELPERS ==========
// SessionHelper necesita HttpContextAccessor para acceder a sesión/claims desde cualquier lugar
SessionHelper.Initialize(app.Services.GetRequiredService<IHttpContextAccessor>());

if (!string.IsNullOrEmpty(pathBase))
{
    app.UsePathBase(pathBase);
}

// ========== MIDDLEWARE PIPELINE ==========
app.UseDeveloperExceptionPage();
app.UseHsts();
app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseSession();
app.UseAuthentication();
app.UseAuthorization();

// ========== ENDPOINTS ==========
app.MapControllerRoute("default", "{controller=Home}/{action=Index}/{id?}");

app.Run();