# 🔍 Auditoría de Gaps: Proceso de Validación de Migración VB6 → .NET 9

**Proyecto:** HyperContabilidad  
**Fecha de creación:** 28 de noviembre de 2025  
**Versión:** 1.0

---

## 📋 Descripción del Proceso

Este documento describe el proceso sistemático para validar que cada feature migrada de VB6 a .NET 9 conserva todas las funcionalidades del sistema original y opera sin errores.

### Objetivo
Comparar automáticamente el código fuente VB6 con el código .NET 9 migrado para detectar gaps (funcionalidades faltantes, queries no migradas, validaciones omitidas, etc.).

### Inputs Disponibles
1. **Código fuente VB6:** `d:\vb6\Contabilidad70\`
2. **Código fuente .NET 9:** `d:\deploy\`
3. **Base de datos SQL Server:** Compartida entre ambos sistemas
4. **Mapeo de features:** `d:\features.md`

---

## 📊 86 Aspectos de Comparación (71 Estructurales + 15 Funcionales)

### 1️⃣ INPUTS / DEPENDENCIAS DE ENTRADA (6 aspectos)

| # | Aspecto | Qué buscar en VB6 | Qué buscar en .NET |
|---|---------|-------------------|-------------------|
| 1 | **Variables globales** | `gEmpresa`, `gUsuario`, `gAño`, `gMes`, `gDbMain` | Session, Claims, Context, DbContext |
| 2 | **Parámetros de entrada** | Params al abrir form, propiedad `Tag`, funciones `FNew()`, `FEdit()`, `FView()` | Route params, query params, DTOs |
| 3 | **Configuraciones** | Archivos `*.cfg`, variables de config | `appsettings.json`, Options pattern |
| 4 | **Estado previo requerido** | Validaciones al inicio (`If gEmpresa.Id = 0 Then`) | Precondiciones, redirects |
| 5 | **Datos maestros necesarios** | Tablas consultadas para combos, lookups | Mismos datos disponibles |
| 6 | **Conexión/Sesión** | `DbMain`, `gDbPath`, `gDbType` | DbContext, ConnectionString |

### 2️⃣ DATOS Y PERSISTENCIA (10 aspectos)

| # | Aspecto | Qué buscar en VB6 | Qué buscar en .NET |
|---|---------|-------------------|-------------------|
| 7 | **Queries SELECT** | `OpenRs()`, `Execute`, strings con `SELECT` | LINQ, Dapper, `FromSqlRaw` |
| 8 | **Queries INSERT** | `ExecSQL()` con `INSERT`, `AddNew` | `Add()`, `INSERT` statements |
| 9 | **Queries UPDATE** | `ExecSQL()` con `UPDATE`, `.Update` | `Update()`, `SaveChanges()` |
| 10 | **Queries DELETE** | `ExecSQL()` con `DELETE`, `DeleteSQL()` | `Remove()`, `DELETE` statements |
| 11 | **Stored Procedures** | `EXEC sp_*`, `.StoredProcedure` | `FromSqlRaw("EXEC...")` |
| 12 | **Tablas accedidas** | Nombres de tablas en queries | DbSets, tablas en queries |
| 13 | **Campos leídos** | `SELECT campo`, `rs!campo`, `rs("campo")` | Propiedades en SELECT/DTOs |
| 14 | **Campos escritos** | Campos en INSERT/UPDATE | Propiedades mapeadas |
| 15 | **Transacciones** | `BeginTrans`, `CommitTrans`, `Rollback` | `BeginTransaction`, UnitOfWork |
| 16 | **Concurrencia** | `LockEdits`, bloqueos de registro | Optimistic/Pessimistic locking |

### 3️⃣ ACCIONES Y OPERACIONES (6 aspectos)

| # | Aspecto | Qué buscar en VB6 | Qué buscar en .NET |
|---|---------|-------------------|-------------------|
| 17 | **Botones/Acciones** | `Sub cmd*_Click()`, `Sub Bt_*_Click()` | Controller Actions, Endpoints |
| 18 | **Operaciones CRUD** | Nuevo, Guardar, Eliminar, Editar | Create, Update, Delete, Get |
| 19 | **Operaciones especiales** | Anular, Copiar, Duplicar, Reversar | Métodos específicos equivalentes |
| 20 | **Búsquedas** | Queries con `WHERE`, `LIKE` | Filtros, Search endpoints |
| 21 | **Ordenamiento** | `ORDER BY` en queries | `.OrderBy()`, `ORDER BY` |
| 22 | **Paginación** | `MoveNext`, `MovePrevious`, navegación | `Skip/Take`, paginación |

### 4️⃣ VALIDACIONES (6 aspectos)

| # | Aspecto | Qué buscar en VB6 | Qué buscar en .NET |
|---|---------|-------------------|-------------------|
| 23 | **Campos requeridos** | `If Trim(txt) = "" Then MsgBox` | `[Required]` attribute |
| 24 | **Validación de rangos** | `If Val(x) < 0 Then`, `If x > max Then` | `[Range]`, validaciones custom |
| 25 | **Validación de formato** | Checks de formato (RUT, email, fecha) | `[RegularExpression]`, validators |
| 26 | **Validación de longitud** | `Len()`, `MaxLength` en controles | `[MaxLength]`, `[StringLength]` |
| 27 | **Validaciones custom** | Funciones `Valida()`, `Function Validar*()` | FluentValidation, `if` checks |
| 28 | **Manejo de nulos** | `IsNull()`, `Nz()`, `vFld()` | `null`, `??`, `?.` operators |

### 5️⃣ CÁLCULOS Y LÓGICA (5 aspectos)

| # | Aspecto | Qué buscar en VB6 | Qué buscar en .NET |
|---|---------|-------------------|-------------------|
| 29 | **Funciones de cálculo** | `Function Calcula*()`, fórmulas | Métodos en Services |
| 30 | **Redondeos** | `Round()`, `Int()`, `Fix()` | `Math.Round()`, configuración decimales |
| 31 | **Campos calculados** | Cálculos on-the-fly, propiedades derivadas | Propiedades computed, getters |
| 32 | **Dependencias campos** | `*_Change`, `*_AfterUpdate`, `*_LostFocus` | Eventos JS, watchers, computed |
| 33 | **Valores por defecto** | `= valor` en `Form_Load`, inicializaciones | Defaults en modelos, constructores |

### 6️⃣ INTERFAZ Y UX (5 aspectos)

| # | Aspecto | Qué buscar en VB6 | Qué buscar en .NET |
|---|---------|-------------------|-------------------|
| 34 | **Combos/Listas** | Queries que llenan `cbo*`, `lst*` | Endpoints para selects, ViewData |
| 35 | **Mensajes usuario** | `MsgBox "texto"`, `MsgBox1` | Responses, toasts, SweetAlert |
| 36 | **Confirmaciones** | `MsgBox vbYesNo`, `MsgBox vbQuestion` | Modales de confirmación |
| 37 | **Habilitaciones UI** | `Control.Enabled = False`, `EnableForm()` | Lógica disabled en frontend |
| 38 | **Formatos display** | `Format()`, formateos de fecha/número | Formatters, helpers, pipes |

### 7️⃣ SEGURIDAD (2 aspectos)

| # | Aspecto | Qué buscar en VB6 | Qué buscar en .NET |
|---|---------|-------------------|-------------------|
| 39 | **Permisos requeridos** | `ChkPriv()`, `TienePermiso()`, checks de `gUsuario.Perfil` | `[Authorize]`, policies, claims |
| 40 | **Validación acceso** | `If gUsuario.Nivel < X Then` | Authorization handlers |

### 8️⃣ MANEJO DE ERRORES (2 aspectos)

| # | Aspecto | Qué buscar en VB6 | Qué buscar en .NET |
|---|---------|-------------------|-------------------|
| 41 | **Captura errores** | `On Error GoTo`, `On Error Resume Next` | `try/catch`, middleware |
| 42 | **Mensajes de error** | `MsgBox Err.Description` | Excepciones, error responses |

### 9️⃣ OUTPUTS / SALIDAS (6 aspectos)

| # | Aspecto | Qué buscar en VB6 | Qué buscar en .NET |
|---|---------|-------------------|-------------------|
| 43 | **Datos de retorno** | Variables devueltas al form llamador | Response DTOs, callbacks |
| 44 | **Exportar Excel** | `ExportToExcel`, OLE Automation | EPPlus, ClosedXML |
| 45 | **Exportar PDF** | Crystal Reports, DataReport | PDF generators (iText, etc.) |
| 46 | **Exportar CSV/Texto** | `Print #`, `Write #` | StreamWriter, exports |
| 47 | **Impresión** | `Printer.*`, `PrtFlexGrid`, DataReport | Print views, CSS print, PDF |
| 48 | **Llamadas a otros módulos** | `Load FrmX`, `FrmX.Show vbModal` | Navegación, API calls |

### 🔟 PARIDAD DE CONTROLES UI (6 aspectos)

| # | Aspecto | Qué buscar en VB6 (.frm) | Qué buscar en .NET (.cshtml) |
|---|---------|--------------------------|------------------------------|
| 49 | **TextBoxes** | `Begin VB.TextBox txt*`, controles de entrada de texto | `<input asp-for="*">`, `<input type="text">` |
| 50 | **Labels/Etiquetas** | `Begin VB.Label lbl*`, `Caption = "texto"` | `<label asp-for="*">`, texto estático |
| 51 | **ComboBoxes/Selects** | `Begin VB.ComboBox cbo*`, `Begin VB.ListBox lst*` | `<select asp-for="*">`, `<select asp-items="*">` |
| 52 | **Grids/Tablas** | `Begin MSFlexGridLib.MSFlexGrid`, `Begin VSFlexGridLib` | `<table>`, componentes DataTable, grids JS |
| 53 | **CheckBoxes** | `Begin VB.CheckBox chk*` | `<input type="checkbox" asp-for="*">` |
| 54 | **Campos ocultos/IDs** | `Begin VB.TextBox` con `Visible = 0`, variables de form | `<input type="hidden" asp-for="*">`, `@Model.Id` |

#### Proceso de Comparación de Controles UI

1. **Extraer controles del .frm:**
   - Buscar bloques `Begin VB.TextBox`, `Begin VB.ComboBox`, etc.
   - Identificar el nombre del control (ej: `txtNombre`, `cboTipo`)
   - Verificar propiedades: `Visible`, `Enabled`, `MaxLength`

2. **Extraer controles del .cshtml:**
   - Buscar elementos `<input>`, `<select>`, `<textarea>`
   - Identificar binding: `asp-for="Propiedad"`
   - Verificar atributos: `disabled`, `readonly`, `maxlength`

3. **Mapear 1:1:**
   ```
   VB6: txtNombre     → .NET: asp-for="Nombre"
   VB6: cboTipo       → .NET: asp-for="TipoId"
   VB6: chkActivo     → .NET: asp-for="Activo"
   VB6: grdDetalle    → .NET: <table id="detalle">
   ```

4. **Verificar completitud:**
   - Cada control editable en VB6 debe tener equivalente en .cshtml
   - Los campos ocultos que almacenan IDs deben existir
   - Los grids deben mostrar las mismas columnas

### 1️⃣1️⃣ GRIDS Y COLUMNAS (2 aspectos)

| # | Aspecto | Qué buscar en VB6 | Qué buscar en .NET |
|---|---------|-------------------|-------------------|
| 55 | **Columnas del grid** | `.ColWidth()`, `.TextMatrix()`, headers en código | `<th>`, columnas en DataTable, definición de columnas JS |
| 56 | **Datos del grid** | Query que llena el grid, `AddItem`, `.Rows`, `.Cols` | Endpoint que retorna datos, DTO de lista, `@foreach` |

#### Verificación de Columnas

Comparar que el grid muestre exactamente las mismas columnas:
```
VB6 Grid:                    .NET Grid:
- Código                     - Código ✅
- Nombre                     - Nombre ✅
- RUT                        - RUT ✅
- Teléfono                   - ❌ FALTA
- Estado                     - Estado ✅
```

### 1️⃣2️⃣ EVENTOS E INTERACCIÓN (5 aspectos)

| # | Aspecto | Qué buscar en VB6 | Qué buscar en .NET |
|---|---------|-------------------|-------------------|
| 57 | **Doble clic** | `*_DblClick()`, acciones al hacer doble clic en grid/lista | `@dblclick`, eventos JS `ondblclick`, handlers |
| 58 | **Teclas especiales** | `KeyPreview = True`, `*_KeyDown`, `*_KeyPress`, teclas F1-F12, Ctrl+* | Event listeners JS, `@keydown`, shortcuts |
| 59 | **Eventos Change** | `*_Change()`, `*_LostFocus()`, `*_AfterUpdate()` | `@change`, `@blur`, `onchange`, watchers |
| 60 | **Menú contextual** | `PopupMenu mnu*`, menús de clic derecho | Context menu JS, `@contextmenu`, dropdown acciones |
| 61 | **Modales Lookup** | `FrmBuscar*.Show vbModal`, retorno vía propiedades (`FrmBuscar.Codigo`), asignación a `txt*` post-Show | Modal JS que devuelve valor al seleccionar, callback/evento que asigna al input padre, `data-*` attributes |

#### Modales Lookup - Verificación Detallada

Los formularios de búsqueda modal (lookup) son críticos para la UX. Verificar:

```
FLUJO VB6:                                   FLUJO .NET:
─────────────────────────────────────────────────────────────────────────────
1. Usuario hace clic en botón buscar         1. Clic abre modal JS/Bootstrap
2. FrmBuscarCliente.Show vbModal             2. Modal carga datos vía AJAX
3. Usuario selecciona registro               3. Usuario selecciona registro
4. Doble clic o botón Aceptar                4. Clic en fila o botón Seleccionar
5. Form modal asigna a propiedades:          5. Callback JS ejecuta:
   - FrmBuscarCliente.Codigo = "001"            - document.getElementById('ClienteId').value = '001'
   - FrmBuscarCliente.Nombre = "ACME"           - document.getElementById('ClienteNombre').value = 'ACME'
6. Unload FrmBuscarCliente                   6. Modal se cierra
7. Form padre lee propiedades:               7. Campos ya actualizados por callback
   - txtClienteCod = FrmBuscarCliente.Codigo
   - txtClienteNom = FrmBuscarCliente.Nombre
```

| Verificación | VB6 | .NET | Estado |
|--------------|-----|------|:------:|
| Modal se abre correctamente | `Show vbModal` | Modal Bootstrap/JS | |
| Datos se cargan en el modal | Query en `Form_Load` | Endpoint API + AJAX | |
| Búsqueda/filtro funciona | Filtro en grid | Filtro en DataTable | |
| Selección devuelve valores | Propiedades públicas del form | Callback JS, eventos | |
| Valores se asignan al padre | Asignación post-Show | Callback actualiza inputs | |
| Modal se cierra | `Unload Me` | `.modal('hide')` | |
| Campos correctos actualizados | `txtCodigo`, `txtNombre` | `#ClienteId`, `#ClienteNombre` | |

#### Atajos de Teclado Comunes en VB6

| Tecla | Acción típica | Verificar en .NET |
|-------|---------------|-------------------|
| F2 | Nuevo registro | Botón/acción Nuevo |
| F3 | Buscar | Modal/acción Buscar |
| F4 | Editar | Botón/acción Editar |
| F5 | Refrescar/Actualizar | Refresh de datos |
| F6 | Guardar | Submit del form |
| F8 | Eliminar | Botón/acción Eliminar |
| F9 | Imprimir | Acción de impresión |
| Ctrl+G | Guardar | Submit del form |
| Escape | Cancelar/Cerrar | Cancelar/volver |

### 1️⃣3️⃣ ESTADOS Y MODOS DEL FORMULARIO (3 aspectos)

| # | Aspecto | Qué buscar en VB6 | Qué buscar en .NET |
|---|---------|-------------------|-------------------|
| 62 | **Modos del form** | Variables `mModo`, `mEstado`, funciones `FNew()`, `FEdit()`, `FView()` | Rutas Create/Edit/Details, parámetros de modo |
| 63 | **Controles por modo** | `EnableForm()`, `If mModo = "N" Then ctrl.Enabled`, lógica de habilitación | Lógica de disabled en vista, `@if` condicionales |
| 64 | **Orden de tabulación** | `TabIndex` en cada control, secuencia de navegación | `tabindex` en HTML, orden natural del DOM |

#### Modos Típicos de Formulario

| Modo VB6 | Controles habilitados | Equivalente .NET |
|----------|----------------------|------------------|
| **Nuevo (N)** | Todos editables, ID vacío | Vista Create, form vacío |
| **Editar (E)** | Todos editables, ID cargado | Vista Edit, form con datos |
| **Ver (V)** | Todos deshabilitados | Vista Details, solo lectura |
| **Buscar (B)** | Solo filtros habilitados | Vista Index con filtros |

### 1️⃣4️⃣ INICIALIZACIÓN Y CARGA (3 aspectos)

| # | Aspecto | Qué buscar en VB6 | Qué buscar en .NET |
|---|---------|-------------------|-------------------|
| 65 | **Carga inicial** | `Form_Load`, `Form_Activate`, datos cargados al abrir | Controller GET, `OnGet`, ViewData, datos en Model |
| 66 | **Valores por defecto** | Asignaciones en `Form_Load`, `= valor` iniciales | Defaults en DTO, constructor, valores en vista |
| 67 | **Llenado de combos** | Queries en `Form_Load` que llenan `cbo*` | ViewBag, ViewData, endpoints de lookup, `asp-items` |

#### Checklist de Inicialización

```
Form_Load VB6:                    Controller/Vista .NET:
─────────────────────────────────────────────────────────
1. Llenar cboTipoDoc             1. ViewBag.TiposDoc ✅
2. Llenar cboBodega              2. ViewBag.Bodegas ✅
3. Llenar cboVendedor            3. ❌ FALTA
4. txtFecha = Date               4. Model.Fecha = DateTime.Now ✅
5. txtUsuario = gUsuario.Nombre  5. User.Identity.Name ✅
```

### 1️⃣5️⃣ FILTROS Y BÚSQUEDA (2 aspectos)

| # | Aspecto | Qué buscar en VB6 | Qué buscar en .NET |
|---|---------|-------------------|-------------------|
| 68 | **Campos de filtro** | TextBox/Combo para filtrar, `txt*Filtro`, `cbo*Filtro` | Inputs en Index, query params, formulario de búsqueda |
| 69 | **Criterios de búsqueda** | `WHERE` dinámicos, condiciones en query de búsqueda | `.Where()` en LINQ, filtros en endpoint |

#### Comparación de Filtros Disponibles

```
Filtros VB6:                     Filtros .NET:
─────────────────────────────────────────────────────────
☑ Por código                     ☑ Por código ✅
☑ Por nombre                     ☑ Por nombre ✅
☑ Por fecha desde/hasta          ☑ Por fecha desde/hasta ✅
☑ Por tipo documento             ☐ ❌ FALTA
☑ Por estado                     ☑ Por estado ✅
```

### 1️⃣6️⃣ REPORTES E IMPRESIÓN (2 aspectos)

| # | Aspecto | Qué buscar en VB6 | Qué buscar en .NET |
|---|---------|-------------------|-------------------|
| 70 | **Reportes disponibles** | Crystal Reports `.rpt`, DataReport, llamadas a `CrystalReport1.ReportFileName` | Reportes RDLC, vistas de impresión, generadores PDF |
| 71 | **Parámetros de reporte** | `.ParameterFields`, valores pasados al reporte | Parámetros en endpoint de reporte, query params |

#### Mapeo de Reportes

| Reporte VB6 | Archivo | Reporte .NET | Estado |
|-------------|---------|--------------|:------:|
| Listado Clientes | `RptClientes.rpt` | `/Clientes/Reporte` | ✅ |
| Ficha Cliente | `RptFichaCliente.rpt` | `/Clientes/Ficha/{id}` | ✅ |
| Saldos | `RptSaldos.rpt` | ❌ | ⚠️ FALTA |

---

## 🔄 Proceso de Auditoría

### Paso 1: Identificar Feature a Auditar

Usar el archivo `features.md` para obtener el mapeo:
```
| Funcionalidad | Formularios VB6 | Feature .NET |
|---------------|-----------------|--------------|
| Sucursales    | FrmSucursales.frm, FrmSucursal.frm | \app\Features\Sucursales |
```

### Paso 2: Leer Código Fuente VB6

Archivos a analizar:
- `d:\vb6\Contabilidad70\HyperContabilidad\FrmXXX.frm` - Formulario principal
- `d:\vb6\Contabilidad70\HyperContabilidad\FrmXXX_modal.frm` - Formularios modales relacionados
- `d:\vb6\VB50\*.bas` - Módulos compartidos (`PamDb.bas`, `Pam.bas`)
- `d:\vb6\Contabilidad70\Comun\*.bas` - Módulos comunes (`HyperComun.bas`)

### Paso 3: Leer Código Fuente .NET

Archivos a analizar:
- `d:\deploy\Features\[FeatureName]\*Controller.cs` - Controladores MVC
- `d:\deploy\Features\[FeatureName]\*ApiController.cs` - Controladores API
- `d:\deploy\Features\[FeatureName]\*Service.cs` - Servicios de negocio
- `d:\deploy\Features\[FeatureName]\*Dto.cs` - DTOs y validaciones
- `d:\deploy\Features\[FeatureName]\Views\*.cshtml` - Vistas Razor

### Paso 4: Comparar los 84 Aspectos

Para cada aspecto, verificar:
1. ✅ **Existe en ambos** - Paridad completa
2. ⚠️ **Falta en .NET** - Gap a documentar
3. ✅ **Mejora en .NET** - Funcionalidad adicional
4. ✅ **N/A** - No aplica (ej: funcionalidad obsoleta)

### Paso 5: Generar Reporte de Gaps

Crear archivo `gaps.md` en la carpeta de la feature:
```
d:\deploy\Features\[FeatureName]\gaps.md
```

---

## 📁 Estructura del Reporte de Gaps

```markdown
# 📊 Reporte de Gaps: [NombreFeature]
## Comparación VB6 → .NET 9

**Fecha de análisis:** [fecha]
**Feature:** [nombre]
**Estado general:** [porcentaje] PARIDAD

---

## 📋 Resumen Ejecutivo
[Tabla resumen por categoría]

## 1️⃣ INPUTS / DEPENDENCIAS DE ENTRADA
[Detalle de cada aspecto]

## 2️⃣ DATOS Y PERSISTENCIA
[Detalle de cada aspecto]

... [resto de categorías]

## 📊 RESUMEN DE GAPS
### 🔴 Gaps Críticos
### 🟠 Gaps Medios
### 🟡 Gaps Menores
### ✅ Mejoras sobre VB6

## ✅ CONCLUSIÓN
[Veredicto final]
```

---

## 📈 Métricas de Paridad

### Cálculo del Porcentaje de Paridad

```
Paridad = (Aspectos OK + Aspectos N/A) / Total Aspectos × 100
```

### Clasificación de Gaps

| Tipo | Criterio | Acción |
|------|----------|--------|
| 🔴 **Crítico** | Funcionalidad core faltante, pérdida de datos posible | Bloquea release |
| 🟠 **Medio** | Funcionalidad secundaria faltante, workaround existe | Planificar fix |
| 🟡 **Menor** | UX diferente, funcionalidad legacy no necesaria | Opcional |

### Umbrales de Aceptación

| Paridad | Estado | Acción |
|---------|--------|--------|
| ≥ 95% | ✅ Listo para producción | Deploy |
| 90-94% | ⚠️ Aceptable con gaps documentados | Deploy con plan de mejora |
| 80-89% | 🟠 Requiere revisión | Evaluar gaps críticos |
| < 80% | 🔴 No aceptable | Completar migración |

---

## 🛠️ Herramientas de Análisis

### Patrones de Búsqueda en VB6

```vb
' Queries SELECT
OpenRs(DbMain, "SELECT
Execute "SELECT

' Queries INSERT/UPDATE/DELETE
ExecSQL(DbMain, "INSERT
ExecSQL(DbMain, "UPDATE
ExecSQL(DbMain, "DELETE
DeleteSQL(DbMain,

' Botones/Acciones
Private Sub cmd*_Click()
Private Sub Bt_*_Click()

' Validaciones
If Trim(txt*) = "" Then
If Val(txt*) <= 0 Then
MsgBox*

' Permisos
ChkPriv(
TienePermiso(
gUsuario.Perfil

' Variables globales
gEmpresa.
gUsuario.
gAno
gMes
```

### Patrones de Búsqueda en .NET

```csharp
// Queries
_context.TableName.Where(
.ToListAsync()
.FirstOrDefaultAsync()
.Add(
.Remove(
.SaveChangesAsync()
FromSqlRaw

// Validaciones
[Required]
[MaxLength]
[Range]
FluentValidation

// Permisos
[Authorize]
User.IsInRole
User.HasClaim

// Endpoints
[HttpGet]
[HttpPost]
[HttpPut]
[HttpDelete]
```

### Patrones de Búsqueda para Controles UI

**En archivos .frm (VB6):**
```vb
' TextBoxes
Begin VB.TextBox txt
   Name            =   "txt

' ComboBoxes
Begin VB.ComboBox cbo
   Name            =   "cbo

' CheckBoxes
Begin VB.CheckBox chk
   Name            =   "chk

' Labels
Begin VB.Label lbl
   Caption         =   "

' Grids
Begin MSFlexGridLib.MSFlexGrid
Begin VSFlexGridLib.VSFlexGrid

' Propiedades importantes
Visible         =   0   'False
Enabled         =   0   'False
MaxLength       =
TabIndex        =
```

**En archivos .cshtml (.NET):**
```html
<!-- Inputs -->
<input asp-for="
<input type="text"
<input type="hidden"

<!-- Selects -->
<select asp-for="
<select asp-items="

<!-- Checkboxes -->
<input type="checkbox" asp-for="

<!-- Labels -->
<label asp-for="

<!-- Tablas/Grids -->
<table id="
<table class="

<!-- Atributos de control -->
disabled
readonly
maxlength="
tabindex="
```

### Patrones de Búsqueda para Eventos e Interacción

**En archivos .frm (VB6):**
```vb
' Eventos de interacción
Private Sub *_DblClick()
Private Sub *_KeyDown(
Private Sub *_KeyPress(
Private Sub *_Change()
Private Sub *_LostFocus()
Private Sub *_GotFocus()
Private Sub *_Click()

' Menú contextual
PopupMenu mnu
Begin VB.Menu mnu

' Teclas especiales
KeyPreview      =   -1  'True
Select Case KeyCode
Case vbKeyF2
Case vbKeyF3
Case vbKeyEscape

' Modos de formulario
mModo = "N"
mModo = "E"
mModo = "V"
FNew
FEdit
FView

' Inicialización
Private Sub Form_Load()
Private Sub Form_Activate()
EnableForm
```

**En archivos .cshtml/.js (.NET):**
```javascript
// Eventos JS
@dblclick
ondblclick
@click
onclick
@change
onchange
@blur
onblur
@keydown
onkeydown
addEventListener('keydown'
addEventListener('dblclick'

// Atajos de teclado
e.key === 'F2'
e.key === 'Escape'
e.ctrlKey &&
hotkeys(

// Menú contextual
@contextmenu
oncontextmenu
.dropdown-menu
context-menu
```

### Patrones de Búsqueda para Grids y Columnas

**En archivos .frm/.bas (VB6):**
```vb
' Configuración de grid
.Cols =
.Rows =
.ColWidth(
.TextMatrix(
.FormatString =
.ColAlignment(

' Headers de columnas
.TextMatrix(0, 0) = "
.Row = 0

' Llenado de grid
.AddItem
.RemoveItem
.Clear
Do While Not rs.EOF
```

**En archivos .cshtml/.js (.NET):**
```html
<!-- Headers de tabla -->
<th>
<thead>

<!-- Definición DataTables -->
columns: [
{ data: '
{ title: '

<!-- Iteración de datos -->
@foreach
@for
```

### Patrones de Búsqueda para Reportes

**En archivos .frm/.bas (VB6):**
```vb
' Crystal Reports
CrystalReport1.ReportFileName
.SelectionFormula
.ParameterFields
.PrintReport
.Action = 1

' DataReport
DataReport.Show
DataReport.PrintReport

' Archivos de reporte
*.rpt
```

**En archivos .cs/.cshtml (.NET):**
```csharp
// Reportes
ReportViewer
LocalReport
.rdlc
/Reporte
/Print
/Export
GeneratePdf
```

---

## 🎯 Verificación de Comportamiento (Auditoría Funcional)

La auditoría estructural (70 aspectos) verifica que **existan** los componentes. Esta sección verifica que **funcionen igual**.

### 1️⃣7️⃣ REGLAS DE NEGOCIO (4 aspectos)

| # | Aspecto | Qué verificar en VB6 | Qué verificar en .NET |
|---|---------|---------------------|----------------------|
| 72 | **Umbrales y límites** | `If Monto > 1000000 Then`, valores hardcodeados | Mismos valores en validaciones/constantes |
| 73 | **Fórmulas de cálculo** | Cálculos de IVA, descuentos, retenciones, intereses | Mismas fórmulas con mismos porcentajes |
| 74 | **Condiciones de negocio** | `If TipoDoc = "F" And Estado = "P" Then`, reglas compuestas | Misma lógica condicional |
| 75 | **Restricciones** | Documentos que no se pueden modificar, estados bloqueantes | Mismas restricciones implementadas |

#### Checklist de Reglas de Negocio

```
Regla VB6                                    .NET                     Estado
─────────────────────────────────────────────────────────────────────────────
IVA = Neto * 0.19                           IVA = Neto * 0.19         ✅
Descuento máximo = 20%                      Descuento máximo = 20%    ✅
Monto > 1.000.000 requiere aprobación       ???                       ⚠️ VERIFICAR
No editar documentos contabilizados         No editar contabilizados  ✅
Cliente bloqueado no puede comprar          ???                       ❌ FALTA
```

#### Patrones de Búsqueda - Reglas de Negocio

**VB6:**
```vb
' Umbrales
If Val(txt*) >
If Monto >
If Cantidad >
= 0.19    ' IVA
= 0.10    ' Retención

' Condiciones compuestas
If * And * Then
If * Or * Then
Select Case

' Restricciones
If Estado = "C" Then MsgBox "No se puede"
If Contabilizado Then
```

**.NET:**
```csharp
// Constantes y umbrales
const decimal
public const
> 1000000
>=

// Porcentajes
* 0.19m
* 0.10m
IvaRate
DescuentoMaximo

// Condiciones
if (x && y)
if (x || y)
switch

// Restricciones
throw new InvalidOperationException
return BadRequest("No se puede
```

### 1️⃣8️⃣ FLUJOS DE TRABAJO (3 aspectos)

| # | Aspecto | Qué verificar en VB6 | Qué verificar en .NET |
|---|---------|---------------------|----------------------|
| 76 | **Secuencia de estados** | Borrador → Emitido → Aprobado → Contabilizado | Misma máquina de estados |
| 77 | **Acciones por estado** | Qué botones/acciones disponibles en cada estado | Mismas acciones habilitadas |
| 78 | **Transiciones válidas** | De qué estado a qué estado se puede pasar | Mismas transiciones permitidas |

#### Diagrama de Flujo Comparativo

```
FLUJO VB6:                              FLUJO .NET:
─────────────────────────────────────────────────────────────
[Borrador] ──────────────────────────── [Borrador] ✅
    │                                       │
    ▼ (Emitir)                              ▼ (Emitir)
[Emitido] ───────────────────────────── [Emitido] ✅
    │                                       │
    ▼ (Aprobar)                             ▼ (Aprobar)
[Aprobado] ──────────────────────────── [Aprobado] ✅
    │                                       │
    ▼ (Contabilizar)                        ▼ (???)
[Contabilizado] ─────────────────────── ❌ FALTA
    │
    ▼ (Anular)
[Anulado]  ──────────────────────────── [Anulado] ✅
```

#### Matriz de Acciones por Estado

| Estado | VB6: Editar | .NET: Editar | VB6: Eliminar | .NET: Eliminar | VB6: Aprobar | .NET: Aprobar |
|--------|:-----------:|:------------:|:-------------:|:--------------:|:------------:|:-------------:|
| Borrador | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Emitido | ❌ | ❌ | ❌ | ❌ | ✅ | ✅ |
| Aprobado | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Contabilizado | ❌ | ⚠️ | ❌ | ⚠️ | ❌ | ❌ |

### 1️⃣9️⃣ INTEGRACIONES ENTRE MÓDULOS (3 aspectos)

| # | Aspecto | Qué verificar en VB6 | Qué verificar en .NET |
|---|---------|---------------------|----------------------|
| 79 | **Llamadas a otros módulos** | `Load FrmContabilizar`, `FrmAsiento.Show` después de acciones | Navegación/llamadas equivalentes |
| 80 | **Parámetros de integración** | Valores pasados vía `Tag`, propiedades, variables globales antes del `Show` | Query params, route params, DTOs, estado en sesión |
| 81 | **Datos compartidos/retorno** | Datos devueltos por formulario llamado, variables globales modificadas | Response DTOs, callbacks, estado compartido |

#### Mapa de Integraciones con Parámetros

```
Acción VB6              Llama a                  Parámetros enviados                    .NET equivalente
─────────────────────────────────────────────────────────────────────────────────────────────────────────────
Guardar Factura         FrmContabilizar          FacturaId, TipoDoc, Monto              POST /Contabilidad/Crear
                                                                                         Body: { facturaId, tipoDoc, monto }

Aprobar Documento       FrmAprobacion            DocId, TipoDoc, UsuarioAprueba         POST /Aprobacion/Aprobar/{id}
                                                                                         Body: { tipoDoc }

Seleccionar Cliente     FrmBuscarCliente         Filtro inicial (opcional)              Modal + GET /api/clientes/buscar
                        (modal)                  Retorna: Codigo, Nombre, RUT            ?filtro=xxx
                                                                                         Callback: { id, codigo, nombre, rut }

Ver Saldo Cliente       FrmSaldoCliente          ClienteId, FechaCorte                  GET /Clientes/Saldo/{id}?fecha=xxx
                                                                                         ❌ FALTA

Imprimir                FrmVistaPrevia           ReporteName, Parametros[]              GET /Documento/Print/{id}
                                                                                         ?formato=pdf

Contabilizar            FrmAsiento               DocId, TipoDoc, Fecha, Monto, CuentaId POST /Contabilidad/Asiento
                                                                                         Body: { docId, tipoDoc, fecha, ... }
```

#### Checklist de Parámetros por Integración

Para cada integración, verificar que **todos los parámetros** se envíen correctamente:

| Integración | Parámetro VB6 | Cómo se pasa en VB6 | Parámetro .NET | Cómo se pasa en .NET | Estado |
|-------------|---------------|---------------------|----------------|----------------------|:------:|
| Buscar Cliente | Filtro | `FrmBuscar.Tag = txtFiltro` | filtro | `?filtro=xxx` | |
| Buscar Cliente | **Retorno: Codigo** | `FrmBuscar.Codigo` | clienteId | Callback JS | |
| Buscar Cliente | **Retorno: Nombre** | `FrmBuscar.Nombre` | clienteNombre | Callback JS | |
| Contabilizar | FacturaId | `FrmContab.DocId = mId` | facturaId | Route param `/Contab/{id}` | |
| Contabilizar | TipoDoc | `FrmContab.TipoDoc = mTipo` | tipoDoc | Body DTO | |
| Contabilizar | Monto | Variable global `gMonto` | monto | Body DTO | |

#### Patrones de Búsqueda - Parámetros de Integración

**En VB6 (antes del Show):**
```vb
' Parámetros vía propiedades
FrmDestino.DocId = mId
FrmDestino.TipoDoc = "FAC"
FrmDestino.Monto = Val(txtMonto)

' Parámetros vía Tag
FrmDestino.Tag = mId & "|" & mTipo

' Parámetros vía variables globales
gDocId = mId
gTipoDoc = "FAC"

' Luego el Show
FrmDestino.Show vbModal

' Lectura de retorno
If FrmDestino.Aceptado Then
    txtCodigo = FrmDestino.CodigoSeleccionado
End If
```

**En .NET:**
```csharp
// Route params
[HttpGet("Contabilizar/{docId}")]

// Query params
[HttpGet("Buscar")]
public IActionResult Buscar(string filtro, int? tipoId)

// Body DTO
public class ContabilizarRequest {
    public int DocId { get; set; }
    public string TipoDoc { get; set; }
    public decimal Monto { get; set; }
}

// Response con datos de retorno
public class BuscarClienteResponse {
    public int Id { get; set; }
    public string Codigo { get; set; }
    public string Nombre { get; set; }
}
```

### 2️⃣0️⃣ MENSAJES AL USUARIO (2 aspectos)

| # | Aspecto | Qué verificar en VB6 | Qué verificar en .NET |
|---|---------|---------------------|----------------------|
| 82 | **Mensajes de error** | Texto exacto de `MsgBox` en errores | Mismo mensaje o equivalente claro |
| 83 | **Mensajes de confirmación** | Texto de `MsgBox vbYesNo` | Mismo mensaje en modal de confirmación |

#### Catálogo de Mensajes

| Contexto | Mensaje VB6 | Mensaje .NET | Estado |
|----------|-------------|--------------|:------:|
| Campo vacío | "Debe ingresar el nombre" | "El campo Nombre es requerido" | ✅ Equivalente |
| RUT duplicado | "El RUT ya existe en el sistema" | "Ya existe un registro con este RUT" | ✅ Equivalente |
| Confirmar eliminar | "¿Está seguro de eliminar este registro?" | "¿Confirma que desea eliminar?" | ✅ Equivalente |
| Guardar exitoso | "Registro guardado correctamente" | Toast "Guardado exitosamente" | ✅ Equivalente |
| Sin permiso | "No tiene permisos para esta operación" | ??? | ⚠️ VERIFICAR |

### 2️⃣1️⃣ CASOS BORDE Y VALORES ESPECIALES (3 aspectos)

| # | Aspecto | Qué verificar en VB6 | Qué verificar en .NET |
|---|---------|---------------------|----------------------|
| 84 | **Valores cero** | Comportamiento cuando monto/cantidad = 0 | Mismo comportamiento |
| 85 | **Valores negativos** | ¿Se permiten? ¿Cómo se manejan? | Misma política |
| 86 | **Valores nulos/vacíos** | `IsNull()`, `Nz()`, strings vacíos | Manejo de nulls equivalente |

#### Matriz de Casos Borde

| Escenario | VB6 Comportamiento | .NET Comportamiento | Estado |
|-----------|-------------------|---------------------|:------:|
| Monto = 0 | Permite guardar | Permite guardar | ✅ |
| Monto < 0 | MsgBox "Monto inválido" | Validación "Debe ser mayor a 0" | ✅ |
| Cantidad vacía | Asume 0 | Error validación | ⚠️ DIFERENTE |
| Fecha vacía | Usa fecha actual | Error requerido | ⚠️ DIFERENTE |
| Cliente null | MsgBox "Seleccione cliente" | Validación requerido | ✅ |

### 2️⃣2️⃣ CASOS DE PRUEBA FUNCIONALES (Template)

Para cada feature, documentar casos de prueba que verifiquen paridad funcional:

#### Template de Caso de Prueba

```markdown
### CP-[Feature]-[Número]: [Nombre del caso]

**Precondiciones:**
- [Estado inicial requerido]

**Pasos:**
1. [Acción 1]
2. [Acción 2]
3. [Acción n]

**Resultado esperado VB6:**
- [Qué sucede en VB6]

**Resultado esperado .NET:**
- [Debe ser idéntico o equivalente]

**Estado:** ✅ Pasa | ❌ Falla | ⚠️ Diferencia menor
```

#### Ejemplo: Casos de Prueba para Factura

```markdown
### CP-FAC-001: Crear factura con datos mínimos

**Precondiciones:**
- Usuario logueado con permiso de facturación
- Al menos un cliente y un producto existentes

**Pasos:**
1. Clic en "Nueva Factura"
2. Seleccionar cliente
3. Agregar un producto con cantidad 1
4. Clic en "Guardar"

**Resultado esperado VB6:**
- Factura guardada con número correlativo
- Estado = "Borrador"
- MsgBox "Factura guardada correctamente"

**Resultado esperado .NET:**
- Factura guardada con número correlativo ✅
- Estado = "Borrador" ✅
- Toast "Guardado exitosamente" ✅

**Estado:** ✅ Pasa
```

```markdown
### CP-FAC-002: Intentar guardar factura sin cliente

**Precondiciones:**
- Formulario de nueva factura abierto

**Pasos:**
1. NO seleccionar cliente
2. Agregar un producto
3. Clic en "Guardar"

**Resultado esperado VB6:**
- MsgBox "Debe seleccionar un cliente"
- No guarda la factura
- Foco en campo cliente

**Resultado esperado .NET:**
- Mensaje "El cliente es requerido" ✅
- No guarda la factura ✅
- Foco en campo cliente ⚠️ (no implementado)

**Estado:** ⚠️ Diferencia menor
```

---

## 📊 Resumen de Aspectos de Auditoría

| Categoría | Aspectos | Tipo |
|-----------|:--------:|:----:|
| **AUDITORÍA ESTRUCTURAL** | | |
| 1. Inputs / Dependencias | 6 | Estructura |
| 2. Datos y Persistencia | 10 | Estructura |
| 3. Acciones y Operaciones | 6 | Estructura |
| 4. Validaciones | 6 | Estructura |
| 5. Cálculos y Lógica | 5 | Estructura |
| 6. Interfaz y UX | 5 | Estructura |
| 7. Seguridad | 2 | Estructura |
| 8. Manejo de Errores | 2 | Estructura |
| 9. Outputs / Salidas | 6 | Estructura |
| 10. Paridad de Controles UI | 6 | Estructura |
| 11. Grids y Columnas | 2 | Estructura |
| 12. Eventos e Interacción | **5** | Estructura |
| 13. Estados y Modos | 3 | Estructura |
| 14. Inicialización y Carga | 3 | Estructura |
| 15. Filtros y Búsqueda | 2 | Estructura |
| 16. Reportes e Impresión | 2 | Estructura |
| **Subtotal Estructural** | **71** | |
| **AUDITORÍA FUNCIONAL** | | |
| 17. Reglas de Negocio | 4 | Comportamiento |
| 18. Flujos de Trabajo | 3 | Comportamiento |
| 19. Integraciones | **3** | Comportamiento |
| 20. Mensajes al Usuario | 2 | Comportamiento |
| 21. Casos Borde | 3 | Comportamiento |
| **Subtotal Funcional** | **15** | |
| **TOTAL** | **86** | |

---

## 📝 Features Auditadas

| Feature | Archivo Gaps | Paridad | Estado |
|---------|-------------|:-------:|:------:|
| Sucursales | `Features/Sucursales/gaps.md` | 95.1% | ✅ |
| *[Agregar más features aquí]* | | | |

---

## 🔜 Próximos Pasos

1. **Automatización:** Crear script que parsee VB6 y genere checklist automático
2. **CI/CD:** Integrar validación de gaps en pipeline de deployment
3. **Dashboard:** Crear vista consolidada de paridad por feature
4. **Priorización:** Ordenar features por criticidad para auditoría

---

## 📚 Referencias

- `d:\features.md` - Catálogo completo de funcionalidades y mapeo VB6→.NET
- `d:\vb6\CLAUDE.md` - Documentación de arquitectura VB6
- `d:\deploy\` - Código fuente .NET 9 migrado
