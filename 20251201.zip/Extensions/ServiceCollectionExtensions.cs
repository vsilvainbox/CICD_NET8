﻿using System.Reflection;

namespace App.Extensions;

/// <summary>
/// Extensiones para registro automÃ¡tico de servicios feature-based
/// </summary>
public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Registra automÃ¡ticamente todos los servicios de features por reflexiÃ³n
    /// ðŸ¤– AUTOMÃTICO: Busca IXxxService e XxxService en todas las features
    /// </summary>
    public static IServiceCollection AddFeatureServices(this IServiceCollection services)
    {
        var assembly = Assembly.GetExecutingAssembly();
        
        // ðŸ” BUSCAR: Todas las interfaces de servicios (IXxxService)
        var serviceInterfaces = assembly.GetTypes()
            .Where(t => t.IsInterface && 
                       t.Name.EndsWith("Service") && 
                       t.Namespace?.Contains("Features") == true)
            .ToList();

        foreach (var serviceInterface in serviceInterfaces)
        {
            // ðŸ” BUSCAR: ImplementaciÃ³n correspondiente (XxxService)
            var implementationType = assembly.GetTypes()
                .FirstOrDefault(t => !t.IsInterface && 
                                   !t.IsAbstract &&
                                   serviceInterface.IsAssignableFrom(t) &&
                                   t.Namespace == serviceInterface.Namespace);

            if (implementationType != null)
            {
                // âœ… REGISTRAR: Como Scoped para Entity Framework
                services.AddScoped(serviceInterface, implementationType);
            }
        }

        // ðŸ“‹ REGISTRAR: Servicios concretos de LibroIngresosEgresos
        services.AddScoped<App.Features.LibroIngresosEgresos.LibroIngresosEgresosService>();
        // ðŸ“‹ REGISTRAR: CuentasDefinidas - Interface y Service (estructura corregida)
        services.AddScoped<App.Features.CuentasDefinidas.ICuentasDefinidasService, App.Features.CuentasDefinidas.CuentasDefinidasService>();
        
        // ðŸ“‹ REGISTRAR: Servicios concretos de DatosEmpresa
        services.AddScoped<App.Features.DatosEmpresa.IDatosEmpresaService, App.Features.DatosEmpresa.DatosEmpresaService>();
        
        // ðŸ“‹ REGISTRAR: Servicios concretos de EstadoResultados (BalanceClasificado)
        services.AddScoped<App.Features.BalanceClasificado.IEstadoResultadosService, App.Features.BalanceClasificado.EstadoResultadosService>();
        
        // ðŸ“‹ REGISTRAR: Servicios concretos de InformeAnaliticoAvanzado
        services.AddScoped<App.Features.InformeAnaliticoAvanzado.IInformeAnaliticoAvanzadoService, App.Features.InformeAnaliticoAvanzado.InformeAnaliticoAvanzadoService>();
        
        // ðŸ“‹ REGISTRAR: Servicios concretos de MantenimientoMonedas
        services.AddScoped<App.Features.MantenimientoMonedas.IMantenimientoMonedasService, App.Features.MantenimientoMonedas.MantenimientoMonedasService>();
        
        // ðŸ“‹ REGISTRAR: Servicios concretos de EquivalenciasMonedas
        services.AddScoped<App.Features.EquivalenciasMonedas.IEquivalenciasMonedasService, App.Features.EquivalenciasMonedas.EquivalenciasMonedasService>();
        
        // ðŸ“‹ REGISTRAR: Servicios concretos de FactoresActualizacion
        services.AddScoped<App.Features.FactoresActualizacion.IFactoresActualizacionService, App.Features.FactoresActualizacion.FactoresActualizacionService>();
        
        // ðŸ“‹ REGISTRAR: Servicios concretos de MantenimientoRazonesFinancieras
        services.AddScoped<App.Features.MantenimientoRazonesFinancieras.IMantenimientoRazonesFinancierasService, App.Features.MantenimientoRazonesFinancieras.MantenimientoRazonesFinancierasService>();
        
        // ðŸ“‹ REGISTRAR: Servicios concretos de DatosOficina
        services.AddScoped<App.Features.DatosOficina.IDatosOficinaService, App.Features.DatosOficina.DatosOficinaService>();
        
        // ðŸ“‹ REGISTRAR: Servicios concretos de ReportePorNivel
        services.AddScoped<App.Features.ReportePorNivel.Services.IReportePorNivelService, App.Features.ReportePorNivel.Services.ReportePorNivelService>();
        
        // ðŸ“‹ SumaMovimientos: Migrado a componente JavaScript reutilizable
        // Ver: wwwroot/js/suma-movimientos.js
        // No requiere registro de servicio backend

        // ðŸ“‹ REGISTRAR: Servicios concretos de ListadoActivoFijo
        services.AddScoped<App.Features.ListadoActivoFijo.Services.IListadoActivoFijoService, App.Features.ListadoActivoFijo.Services.ListadoActivoFijoService>();
        
        // ðŸ“‹ REGISTRAR: Servicios concretos de FichaActivoFijo
        services.AddScoped<App.Features.FichaActivoFijo.IFichaActivoFijoService, App.Features.FichaActivoFijo.FichaActivoFijoService>();
        
        // ðŸ“‹ REGISTRAR: Servicios concretos de ComponentesActivoFijo
        services.AddScoped<App.Features.ComponentesActivoFijo.IComponentesActivoFijoService, App.Features.ComponentesActivoFijo.ComponentesActivoFijoService>();
        
        // ðŸ“‹ REGISTRAR: Servicios concretos de LibroElectronicoCompras
        services.AddScoped<App.Features.LibroElectronicoCompras.ILibroElectronicoComprasService, App.Features.LibroElectronicoCompras.LibroElectronicoComprasService>();

        // ðŸ“‹ NOTA: SeleccionParaTraspaso estÃ¡ en deadcode - no se registra

        // ðŸ“‹ REGISTRAR: Servicios concretos de ReporteControlEmpresasAlt
        services.AddScoped<App.Features.ReporteControlEmpresasAlt.IReporteControlEmpresasAltService, App.Features.ReporteControlEmpresasAlt.ReporteControlEmpresasAltService>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de ExportarEmpresa
        services.AddScoped<App.Features.ExportarEmpresa.IExportarEmpresaService, App.Features.ExportarEmpresa.ExportarEmpresaService>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de ImportarDesdeLpRemu
        services.AddScoped<App.Features.ImportarDesdeLpRemu.IImportarDesdeLpRemuService, App.Features.ImportarDesdeLpRemu.ImportarDesdeLpRemuService>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de ConfiguracionCorreccionComprobantes
        services.AddScoped<App.Features.ConfiguracionCorreccionComprobantes.IConfiguracionCorreccionComprobantesService, App.Features.ConfiguracionCorreccionComprobantes.ConfiguracionCorreccionComprobantesService>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de ControlEmpresas
        services.AddScoped<App.Features.ControlEmpresas.IControlEmpresasService, App.Features.ControlEmpresas.ControlEmpresasService>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de AsistenteImportacionPrimeraCategoria
        services.AddScoped<App.Features.AsistenteImportacionPrimeraCategoria.IAsistenteImportacionPrimeraCategoriaService, App.Features.AsistenteImportacionPrimeraCategoria.AsistenteImportacionPrimeraCategoriaService>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de EliminarEmpresaAno
        services.AddScoped<App.Features.EliminarEmpresaAno.IEliminarEmpresaAnoService, App.Features.EliminarEmpresaAno.EliminarEmpresaAnoService>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de Respaldos
        services.AddScoped<App.Features.Respaldos.IRespaldosService, App.Features.Respaldos.RespaldosService>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de AbrirCerrarMes
        services.AddScoped<App.Features.AbrirCerrarMes.IAbrirCerrarMesService, App.Features.AbrirCerrarMes.AbrirCerrarMesService>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de CierreAnual
        services.AddScoped<App.Features.CierreAnual.ICierreAnualService, App.Features.CierreAnual.CierreAnualService>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de Apertura
        services.AddScoped<App.Features.Apertura.IAperturaService, App.Features.Apertura.AperturaService>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de FoliacionParaTimbraje
        services.AddScoped<App.Features.FoliacionParaTimbraje.IFoliacionParaTimbrajeService, App.Features.FoliacionParaTimbraje.FoliacionParaTimbrajeService>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de ConfiguracionPlanCuentas2019
        services.AddScoped<App.Features.ConfiguracionPlanCuentas2019.IConfiguracionPlanCuentas2019Service, App.Features.ConfiguracionPlanCuentas2019.ConfiguracionPlanCuentas2019Service>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de PlanCuentas
        services.AddScoped<App.Features.PlanCuentas.IPlanCuentasService, App.Features.PlanCuentas.PlanCuentasService>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de ActualizacionGlosas
        services.AddScoped<App.Features.ActualizacionGlosas.IActualizacionGlosasService, App.Features.ActualizacionGlosas.ActualizacionGlosasService>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de ConfiguracionImpresion
        services.AddScoped<App.Features.ConfiguracionImpresion.IConfiguracionImpresionService, App.Features.ConfiguracionImpresion.ConfiguracionImpresionService>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de CuentasLibroCompras
        services.AddScoped<App.Features.CuentasLibroCompras.ICuentasLibroComprasService, App.Features.CuentasLibroCompras.CuentasLibroComprasService>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de InformacionAyudaEmpresas
        services.AddScoped<App.Features.InformacionAyudaEmpresas.IInformacionAyudaEmpresasService, App.Features.InformacionAyudaEmpresas.InformacionAyudaEmpresasService>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de CuentasLibroVentas
        services.AddScoped<App.Features.CuentasLibroVentas.ICuentasLibroVentasService, App.Features.CuentasLibroVentas.CuentasLibroVentasService>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de ListadoDocumentos
        services.AddScoped<App.Features.ListadoDocumentos.IListadoDocumentosService, App.Features.ListadoDocumentos.ListadoDocumentosService>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de ImportarEmpresa
        services.AddScoped<App.Features.ImportarEmpresa.IImportarEmpresaService, App.Features.ImportarEmpresa.ImportarEmpresaService>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de ImportarDesdeHr
        services.AddScoped<App.Features.ImportarDesdeHr.IImportarDesdeHrService, App.Features.ImportarDesdeHr.ImportarDesdeHrService>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de ImportarDesdeArchivo
        services.AddScoped<App.Features.ImportarDesdeArchivo.IImportarDesdeArchivoService, App.Features.ImportarDesdeArchivo.ImportarDesdeArchivoService>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de ImportarEmpresas
        services.AddScoped<App.Features.ImportarEmpresas.IImportarEmpresasService, App.Features.ImportarEmpresas.ImportarEmpresasService>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de ReporteControlEmpresas
        services.AddScoped<App.Features.ReporteControlEmpresas.IReporteControlEmpresasService, App.Features.ReporteControlEmpresas.ReporteControlEmpresasService>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de ImportarActivoFijo
        services.AddScoped<App.Features.ImportarActivoFijo.IImportarActivoFijoService, App.Features.ImportarActivoFijo.ImportarActivoFijoService>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de GestionCuotas
        services.AddScoped<App.Features.GestionCuotas.IGestionCuotasService, App.Features.GestionCuotas.GestionCuotasService>();

        // ðŸ“‹ REGISTRAR: Servicios concretos de PrivilegiosPorEmpresa
        services.AddScoped<App.Features.PrivilegiosPorEmpresa.IPrivilegiosPorEmpresaService, App.Features.PrivilegiosPorEmpresa.PrivilegiosPorEmpresaService>();


        // REGISTRAR: Servicios concretos de EstadoSituacionFinancieraIfrs
        // Compartido entre EstadoSituacionFinancieraIfrs y EstadoResultadoIfrs
        services.AddScoped<App.Features.EstadoSituacionFinancieraIfrs.IEstadoSituacionFinancieraIfrsService, App.Features.EstadoSituacionFinancieraIfrs.EstadoSituacionFinancieraIfrsService>();

        // 📋 REGISTRAR: Servicios concretos de ReporteProblema
        services.AddScoped<App.Features.ReporteProblema.IReporteProblemaService, App.Features.ReporteProblema.ReporteProblemaService>();

        // 📋 REGISTRAR: Servicios concretos de RespaldosVb50
        services.AddScoped<App.Features.RespaldosVb50.IRespaldosVb50Service, App.Features.RespaldosVb50.RespaldosVb50Service>();

        // 📋 REGISTRAR: Servicios concretos de GenerarBackup
        services.AddScoped<App.Features.GenerarBackup.IGenerarBackupService, App.Features.GenerarBackup.GenerarBackupService>();

        // 📋 REGISTRAR: Servicios concretos de MantenimientoUsuarios
        services.AddScoped<App.Features.MantenimientoUsuarios.IMantenimientoUsuariosService, App.Features.MantenimientoUsuarios.MantenimientoUsuariosService>();

        // 🔐 REGISTRAR: Servicio de encriptación (compatible con VB6)
        services.AddSingleton<App.Services.IEncryptionService, App.Services.EncryptionService>();

        // 💰 REGISTRAR: Servicio de cuentas básicas
        services.AddScoped<App.Services.ICuentasBasicasService, App.Services.CuentasBasicasService>();

        // 📊 REGISTRAR: Servicio de indicadores económicos (IPC, Factor CM, UTM)
        services.AddScoped<App.Services.IIndicadoresEconomicosService, App.Services.IndicadoresEconomicosService>();

        // 📝 REGISTRAR: Servicio de generación de movimientos contables
        services.AddScoped<App.Services.IMovimientosContablesService, App.Services.MovimientosContablesService>();

        // 📊 REGISTRAR: Servicio genérico de exportaciones (Excel y PDF)
        services.AddScoped<App.Services.IExportService, App.Services.ExportService>();

        return services;
    }
}
