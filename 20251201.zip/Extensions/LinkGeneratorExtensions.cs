using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;

namespace App.Extensions;

/// <summary>
/// Extensions para LinkGenerator que simplifican la generación de URLs a API Controllers
/// </summary>
public static class LinkGeneratorExtensions
{
    /// <summary>
    /// Genera URL absoluta a un API Controller usando convención de nombres.
    /// Convención: XyzController → XyzApiController
    /// </summary>
    /// <typeparam name="TController">Tipo del API Controller</typeparam>
    /// <param name="linkGenerator">LinkGenerator instance</param>
    /// <param name="httpContext">HttpContext para generar URL absoluta</param>
    /// <param name="actionName">Nombre de la acción (usar nameof)</param>
    /// <param name="values">Parámetros de ruta opcionales</param>
    /// <returns>URL absoluta al API endpoint</returns>
    public static string? GetApiUrl<TController>(
        this LinkGenerator linkGenerator,
        HttpContext httpContext,
        string actionName,
        object? values = null) where TController : ControllerBase
    {
        var controllerName = typeof(TController).Name.Replace("Controller", "");

        var url = linkGenerator.GetUriByAction(
            httpContext,
            action: actionName,
            controller: controllerName,
            values: values);

        // Log de URL generada para debugging
        Console.WriteLine($"[API-URL] {controllerName}/{actionName} → {url}");

        return url;
    }
}
