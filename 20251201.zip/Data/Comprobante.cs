﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Comprobante
{
    public int IdComp { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public int? Correlativo { get; set; }

    public int? Fecha { get; set; }

    public byte? Tipo { get; set; }

    public byte? Estado { get; set; }

    public string? Glosa { get; set; }

    public double? TotalDebe { get; set; }

    public double? TotalHaber { get; set; }

    public int? IdUsuario { get; set; }

    public int? FechaCreacion { get; set; }

    public bool? ImpResumido { get; set; }

    public bool? EsCCMM { get; set; }

    public int? FechaImport { get; set; }

    public byte? TipoAjuste { get; set; }

    public bool? OtrosIngEg14TER { get; set; }
}
