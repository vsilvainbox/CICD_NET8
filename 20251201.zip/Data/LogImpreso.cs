﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class LogImpreso
{
    public int IdLog { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public int? Fecha { get; set; }

    public int? CorrInicio { get; set; }

    public int? CorrFin { get; set; }

    public int? idInforme { get; set; }

    public byte? Estado { get; set; }

    public string? Comentario { get; set; }

    public int? IdUsuario { get; set; }

    public short? Mes { get; set; }

    public int? FDesde { get; set; }

    public int? FHasta { get; set; }
}
