﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Monedas
{
    public short idMoneda { get; set; }

    public string? Descrip { get; set; }

    public string? Simbolo { get; set; }

    public float? DecInf { get; set; }

    public float? DecVenta { get; set; }

    public byte? Caracteristica { get; set; }

    public string? CodAduana { get; set; }

    public bool? EsFijo { get; set; }
}
