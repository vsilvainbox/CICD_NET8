﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class CtasAjustesExContRLI
{
    public int IdCtaAjustesRLI { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public byte? TipoAjuste { get; set; }

    public short? IdGrupo { get; set; }

    public short? IdItem { get; set; }

    public int? IdCuenta { get; set; }

    public string? CodCuenta { get; set; }
}
