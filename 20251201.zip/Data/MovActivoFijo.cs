﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class MovActivoFijo
{
    public int IdActFijo { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public int? IdDoc { get; set; }

    public int? IdComp { get; set; }

    public int? IdMovComp { get; set; }

    public short? TipoMovAF { get; set; }

    public int? Fecha { get; set; }

    public int? Cantidad { get; set; }

    public string? Descrip { get; set; }

    public double? Neto { get; set; }

    public double? IVA { get; set; }

    public bool? Cred4Porc { get; set; }

    public short? DepNormal { get; set; }

    public short? DepAcelerada { get; set; }

    public int? IdCuenta { get; set; }

    public short? DepNormalHist { get; set; }

    public short? DepAceleradaHist { get; set; }

    public double? NetoVenta { get; set; }

    public double? IVAVenta { get; set; }

    public int? FechaVentaBaja { get; set; }

    public byte? TipoDep { get; set; }

    public byte? TipoDepHist { get; set; }

    public double? DepAcumHist { get; set; }

    public short? VidaUtil { get; set; }

    public double? DepAcumFinal { get; set; }

    public short? VidaUtilResidual { get; set; }

    public int? FExported { get; set; }

    public int? FechaUtilizacion { get; set; }

    public bool? NoDepreciable { get; set; }

    public double? ValCred33 { get; set; }

    public double? ValReajustadoNeto { get; set; }

    public int? IdActFijoOld { get; set; }

    public int? IdActFijoOldTmp { get; set; }

    public bool? TotalmenteDepreciado { get; set; }

    public double? ValorLibro { get; set; }

    public int? FImported { get; set; }

    public double? ValReajustadoNetoAnt { get; set; }

    public bool? Cred4PorcAnoInit { get; set; }

    public int? FechaImportFile { get; set; }

    public short? DepInstant { get; set; }

    public short? DepDecimaParte { get; set; }

    public short? DepInstantHist { get; set; }

    public short? DepDecimaParteHist { get; set; }

    public short? VidaUtilAnos { get; set; }

    public byte? TipoDepLey21210 { get; set; }

    public short? DepDecimaParte2 { get; set; }

    public short? DepDecimaParte2Hist { get; set; }

    public string? PatenteRol { get; set; }

    public string? NombreProy { get; set; }

    public int? FechaProy { get; set; }

    public byte? TipoDepLey21210Hist { get; set; }

    public byte? DepLey21256 { get; set; }

    public byte? DepLey21256Hist { get; set; }

    public int? idCCosto { get; set; }

    public int? IdAreaNeg { get; set; }
}
