﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class CapPropioSimplAnual
{
    public int IdCapPropioSimplAnual { get; set; }

    public int? IdEmpresa { get; set; }

    public byte? TipoDetCPS { get; set; }

    public bool? IngresoManual { get; set; }

    public short? AnoValor { get; set; }

    public double? Valor { get; set; }
}
