﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class vMovCompIdDoc
{
    public int? IdDoc { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public double? Debe { get; set; }

    public double? Haber { get; set; }
}
