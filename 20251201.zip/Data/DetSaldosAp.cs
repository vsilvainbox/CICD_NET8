﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class DetSaldosAp
{
    public int Id { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public int? IdCuenta { get; set; }

    public int? IdEntidad { get; set; }

    public double? Debe { get; set; }

    public double? Haber { get; set; }

    public double? Saldo { get; set; }
}
