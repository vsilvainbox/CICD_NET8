﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Impuestos
{
    public int idImpuesto { get; set; }

    public string? Impuesto { get; set; }

    public double? Porcentaje { get; set; }

    public int? FechaDesde { get; set; }
}
