﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class TipoDocs
{
    public int Id { get; set; }

    public short? TipoLib { get; set; }

    public short? TipoDoc { get; set; }

    public string? Nombre { get; set; }

    public string? Diminutivo { get; set; }

    public string? Atributo { get; set; }

    public bool? TipoDocFijo { get; set; }

    public short? CodF29Count { get; set; }

    public short? CodF29Neto { get; set; }

    public short? CodF29IVA { get; set; }

    public short? CodF29IVADTE { get; set; }

    public short? CodF29AFCount { get; set; }

    public short? CodF29AFIVA { get; set; }

    public short? CodF29RetHon { get; set; }

    public short? CodF29RetDieta { get; set; }

    public short? CodF29IVARet3ro { get; set; }

    public byte? TieneAfecto { get; set; }

    public byte? TieneExento { get; set; }

    public bool? ExigeRUT { get; set; }

    public bool? EsRebaja { get; set; }

    public bool? DocImpExp { get; set; }

    public bool? DocBoletas { get; set; }

    public short? CodF29ExCount { get; set; }

    public short? CodF29Exento { get; set; }

    public short? CodF29CountNoGiro { get; set; }

    public short? CodF29NetoNoGiro { get; set; }

    public short? CodF29IVANoGiro { get; set; }

    public short? CodF29ExCountNoGiro { get; set; }

    public short? CodF29ExentoNoGiro { get; set; }

    public short? CodF29CountRetParcial { get; set; }

    public short? CodF29NetoRetParcial { get; set; }

    public short? CodF29DifIVARetParcial { get; set; }

    public short? CodF29CountDTE { get; set; }

    public short? CodF29NetoDTE { get; set; }

    public short? CodF29IVAIrrecDTE { get; set; }

    public short? CodF29CountIVAIrrec { get; set; }

    public short? CodF29NetoIVAIrrec { get; set; }

    public string? CodDocSII { get; set; }

    public string? CodDocDTESII { get; set; }

    public bool? AceptaPropIVA { get; set; }

    public short? CodF29CountSuper { get; set; }

    public short? CodF29IVASuper { get; set; }

    public byte? IngresarTotal { get; set; }

    public byte? TieneNumDocHasta { get; set; }

    public byte? TieneCantBoletas { get; set; }
}
