﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class CuentasBasicas
{
    public int Id { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public short? Tipo { get; set; }

    public short? TipoLib { get; set; }

    public short? TipoValor { get; set; }

    public int? IdCuenta { get; set; }

    public int? IdCuentaOld { get; set; }
}
