# Plan de Refactorizacion de Vistas - ASP.NET Core MVC Way

Este documento detalla el plan de refactorizacion para las vistas complejas identificadas en el proyecto, siguiendo el patron aplicado exitosamente en `NuevoComprobante`.

## Patron de Refactorizacion Aplicado

### Antes vs Despues

```
ANTES                                    DESPUES
────────────────────────────────────────────────────────────────────────
Index.cshtml (1000+ lineas)         →    Index.cshtml (~100 lineas)
  ├─ HTML inline                           ├─ @model ViewModel
  ├─ Modales inline                        ├─ @await Html.PartialAsync("Sections/_Header")
  ├─ JS inline (500+ lineas)               ├─ @await Html.PartialAsync("Sections/_Filters")
  ├─ Validaciones en JS                    ├─ @await Html.PartialAsync("Sections/_Table")
  ├─ Calculos en JS                        ├─ @await Html.PartialAsync("Modals/_ModalX")
  └─ Estado global en JS                   └─ <script src="~/js/features/modulo.js">

Sin ViewModel tipado                 →    ViewModel con:
                                           ├─ IValidatableObject
                                           ├─ DataAnnotations
                                           ├─ [Remote] validation
                                           └─ Propiedades computadas
```

### Principios Clave

1. **Validaciones en C#** - No duplicar en JavaScript
2. **Calculos en Backend** - Totales, porcentajes, formateos
3. **Estado en ViewModel** - No variables globales JS
4. **Renderizado Server-Side** - EditorTemplates, no innerHTML
5. **JS Minimalista** - Solo manipulacion de UI

---

## FASE 1: Quick Wins (Impacto Alto, Esfuerzo Medio)

### 1.1 GestionActivoFijo/Movimientos.cshtml

**Estado Actual:**
- Lineas: 545
- JS estimado: ~400 lineas
- Anti-patrones: Arrays globales, innerHTML, calculos en JS

**Problemas Especificos:**
```javascript
// PROBLEMA: Estado global
let movimientos = [];

// PROBLEMA: Renderizado dinamico con innerHTML
row.innerHTML = `<td>...</td><td>...</td>...`;
tbody.appendChild(row);

// PROBLEMA: Formateo en cliente
function formatCurrency(value) { ... }
function formatFecha(fecha) { ... }
```

**Plan de Refactorizacion:**

| Componente | Archivo a Crear | Contenido |
|------------|-----------------|-----------|
| ViewModel | `MovimientosViewModel.cs` | Lista movimientos, totales computados, filtros |
| Parcial Header | `Views/Sections/_HeaderMovimientos.cshtml` | Titulo, breadcrumb, acciones |
| Parcial Filtros | `Views/Sections/_FiltrosMovimientos.cshtml` | Controles de busqueda |
| Parcial Tabla | `Views/Sections/_TablaMovimientos.cshtml` | Tabla con EditorTemplate |
| EditorTemplate | `Views/EditorTemplates/MovimientoItemViewModel.cshtml` | Fila de movimiento |
| JS Externo | `wwwroot/js/features/movimientos-activo.js` | Solo UI (~100 lineas) |

**ViewModel Propuesto:**
```csharp
public class MovimientosViewModel
{
    public int ActivoId { get; set; }
    public string ActivoDescripcion { get; set; }

    // Filtros
    public int? Ano { get; set; }
    public int? Mes { get; set; }
    public byte? TipoMovimiento { get; set; }

    // Datos
    public List<MovimientoActivoItem> Movimientos { get; set; } = new();

    // Catalogos
    public Dictionary<byte, string> TiposMovimiento { get; set; } = new();

    // Propiedades computadas (calculos en C#, no en JS)
    public decimal TotalValorCompra => Movimientos.Sum(m => m.ValorCompra);
    public decimal TotalDepreciacion => Movimientos.Sum(m => m.Depreciacion);
    public decimal TotalValorNeto => TotalValorCompra - TotalDepreciacion;
}
```

**Reduccion Esperada:** ~400 lineas JS → ~80 lineas JS

---

### 1.2 GestionActivoFijo/Componentes.cshtml

**Estado Actual:**
- Lineas: 601
- JS estimado: ~450 lineas
- Anti-patrones: Calculos de totales en JS, innerHTML, estado global

**Problemas Especificos:**
```javascript
// PROBLEMA: Array global
let componentes = [];

// PROBLEMA: Calculos en cliente
let totalPorcentaje = 0, totalValorCompra = 0;
componentes.forEach(comp => {
    totalPorcentaje += pjeDivComp;
    totalValorCompra += valorCompra;
});

// PROBLEMA: innerHTML masivo
row.innerHTML = `<td>${comp.componenteNombre}</td>...`;
```

**Plan de Refactorizacion:**

| Componente | Archivo a Crear |
|------------|-----------------|
| ViewModel | `ComponentesActivoViewModel.cs` |
| Parcial Header | `Views/Sections/_HeaderComponentes.cshtml` |
| Parcial Tabla | `Views/Sections/_TablaComponentes.cshtml` |
| Parcial Totales | `Views/Sections/_TotalesComponentes.cshtml` |
| EditorTemplate | `Views/EditorTemplates/ComponenteItemViewModel.cshtml` |
| JS Externo | `wwwroot/js/features/componentes-activo.js` |

**ViewModel Propuesto:**
```csharp
public class ComponentesActivoViewModel
{
    public int ActivoId { get; set; }
    public List<ComponenteItem> Componentes { get; set; } = new();

    // Totales calculados en C# (NO en JavaScript)
    public decimal TotalPorcentaje => Componentes.Sum(c => c.PorcentajeDivision);
    public decimal TotalValorCompra => Componentes.Sum(c => c.ValorCompra);
    public decimal TotalDepAcumulada => Componentes.Sum(c => c.DepreciacionAcumulada);
    public decimal TotalValorNeto => TotalValorCompra - TotalDepAcumulada;

    // Validacion: porcentajes deben sumar 100%
    public bool PorcentajesValidos => Math.Abs(TotalPorcentaje - 100) < 0.01m;
}
```

**Reduccion Esperada:** ~450 lineas JS → ~60 lineas JS

---

### 1.3 ComponentesActivoFijo/Index.cshtml

**Estado Actual:**
- Lineas: 636
- JS estimado: ~150 lineas
- Anti-patrones: `calcularCampos()`, estado global, `document.createElement`

**Problemas Especificos:**
```javascript
// PROBLEMA: Calculos de negocio en JS
function calcularCampos() {
    const valorCompra = parseFloat(document.getElementById('valorCompra').value) || 0;
    const depAcum = parseFloat(document.getElementById('depAcum').value) || 0;
    document.getElementById('valorNeto').value = (valorCompra - depAcum).toFixed(2);
}

// PROBLEMA: Estado global
let datosActivoFijo = null;
let componenteActual = null;
let modificado = false;
```

**Plan de Refactorizacion:**

| Componente | Archivo a Crear |
|------------|-----------------|
| ViewModel | `ComponentesActivoFijoViewModel.cs` con IValidatableObject |
| Parcial Form | `Views/Sections/_FormComponente.cshtml` |
| Parcial Lista | `Views/Sections/_ListaComponentes.cshtml` |
| JS Externo | `wwwroot/js/features/componentes-activo-fijo.js` |

**Validaciones a mover a C#:**
```csharp
public class ComponenteFormViewModel : IValidatableObject
{
    [Required(ErrorMessage = "El valor de compra es obligatorio")]
    [Range(0.01, double.MaxValue, ErrorMessage = "El valor debe ser mayor a 0")]
    public decimal ValorCompra { get; set; }

    [Range(0, double.MaxValue)]
    public decimal DepreciacionAcumulada { get; set; }

    // Propiedad computada - NO calcular en JS
    public decimal ValorNeto => ValorCompra - DepreciacionAcumulada;

    public IEnumerable<ValidationResult> Validate(ValidationContext ctx)
    {
        if (DepreciacionAcumulada > ValorCompra)
            yield return new ValidationResult(
                "La depreciacion no puede ser mayor al valor de compra",
                new[] { nameof(DepreciacionAcumulada) });
    }
}
```

**Reduccion Esperada:** ~150 lineas JS → ~40 lineas JS

---

### 1.4 LibroCaja/Index.cshtml

**Estado Actual:**
- Lineas: 602
- JS estimado: ~400 lineas
- Anti-patrones: `registros=[]`, innerHTML masivo, formateos JS

**Problemas Especificos:**
```javascript
// PROBLEMA: Estado global
let registros = [];

// PROBLEMA: Renderizado completo en JS
tbody.innerHTML = registros.map((reg, index) => `
    <tr>
        <td>${index + 1}</td>
        <td>${reg.tipoOper === 1 ? 'I' : 'E'}</td>
        <td>${formatMonto(reg.ingreso)}</td>
        <td>${formatMonto(reg.egreso)}</td>
    </tr>
`).join('');

// PROBLEMA: Calculos en cliente
const totalIng = registros.reduce((sum, r) => sum + (r.ingreso || 0), 0);
const totalEgr = registros.reduce((sum, r) => sum + (r.egreso || 0), 0);
const saldo = totalIng - totalEgr;
```

**Plan de Refactorizacion:**

| Componente | Archivo a Crear |
|------------|-----------------|
| ViewModel | `LibroCajaViewModel.cs` |
| Parcial Header | `Views/Sections/_HeaderLibroCaja.cshtml` |
| Parcial Filtros | `Views/Sections/_FiltrosPeriodo.cshtml` |
| Parcial Tabla | `Views/Sections/_TablaRegistros.cshtml` |
| Parcial Totales | `Views/Sections/_TotalesLibroCaja.cshtml` |
| EditorTemplate | `Views/EditorTemplates/RegistroCajaItem.cshtml` |
| JS Externo | `wwwroot/js/features/libro-caja.js` |

**ViewModel Propuesto:**
```csharp
public class LibroCajaViewModel
{
    // Filtros
    public short Ano { get; set; }
    public byte Mes { get; set; }

    // Datos renderizados server-side (NO en JS)
    public List<RegistroCajaItem> Registros { get; set; } = new();

    // Totales calculados en C#
    public decimal TotalIngresos => Registros.Where(r => r.TipoOperacion == 1).Sum(r => r.Monto);
    public decimal TotalEgresos => Registros.Where(r => r.TipoOperacion == 2).Sum(r => r.Monto);
    public decimal Saldo => TotalIngresos - TotalEgresos;

    // Formateo en C# con Display
    [DisplayFormat(DataFormatString = "{0:N0}")]
    public decimal TotalIngresosFormateado => TotalIngresos;
}
```

**Reduccion Esperada:** ~400 lineas JS → ~50 lineas JS

---

## FASE 2: Modulos Criticos (Impacto Muy Alto, Esfuerzo Alto)

### 2.1 GestionActivoFijo/Index.cshtml

**Estado Actual:**
- Lineas: 1,628
- Modales: 33
- Llamadas AJAX: 118
- Funciones JS: 41

**Este es el archivo mas complejo del proyecto.**

**Plan de Refactorizacion:**

| Componente | Archivo a Crear | Lineas Estimadas |
|------------|-----------------|------------------|
| ViewModel | `GestionActivoFijoViewModel.cs` | 150 |
| Index simplificado | `Views/Index.cshtml` | 120 |
| **Secciones:** | | |
| Header | `Views/Sections/_Header.cshtml` | 80 |
| Filtros | `Views/Sections/_FiltrosBusqueda.cshtml` | 150 |
| Tabla | `Views/Sections/_TablaActivos.cshtml` | 200 |
| Toolbar | `Views/Sections/_ToolbarAcciones.cshtml` | 100 |
| Paginacion | `Views/Sections/_Paginacion.cshtml` | 60 |
| **Modales (33 → parciales):** | | |
| Modal Crear | `Views/Modals/_ModalCrearActivo.cshtml` | 200 |
| Modal Editar | `Views/Modals/_ModalEditarActivo.cshtml` | 200 |
| Modal Eliminar | `Views/Modals/_ModalConfirmarEliminar.cshtml` | 50 |
| Modal Depreciar | `Views/Modals/_ModalDepreciar.cshtml` | 150 |
| Modal Componentes | `Views/Modals/_ModalComponentes.cshtml` | 150 |
| Modal Movimientos | `Views/Modals/_ModalMovimientos.cshtml` | 150 |
| ... (27 modales mas) | `Views/Modals/_Modal*.cshtml` | ~1500 |
| **JS Externo:** | | |
| Modulo principal | `wwwroot/js/features/gestion-activo-fijo.js` | 400 |

**ViewModel Propuesto:**
```csharp
public class GestionActivoFijoViewModel : IValidatableObject
{
    // Estado
    public string Mode { get; set; } = "list";

    // Filtros de busqueda
    public string BuscarCodigo { get; set; }
    public string BuscarDescripcion { get; set; }
    public int? TipoActivo { get; set; }
    public int? Estado { get; set; }

    // Paginacion
    public int PaginaActual { get; set; } = 1;
    public int TotalPaginas { get; set; }
    public int TotalRegistros { get; set; }

    // Datos
    public List<ActivoFijoItem> Activos { get; set; } = new();

    // Catalogos precargados
    public Dictionary<int, string> TiposActivo { get; set; } = new();
    public Dictionary<int, string> EstadosActivo { get; set; } = new();
    public Dictionary<int, string> CentrosCosto { get; set; } = new();
    public Dictionary<int, string> AreasNegocio { get; set; } = new();

    // Totales
    public decimal TotalValorCompra => Activos.Sum(a => a.ValorCompra);
    public decimal TotalDepreciacion => Activos.Sum(a => a.DepreciacionAcumulada);
    public decimal TotalValorNeto => TotalValorCompra - TotalDepreciacion;

    // URLs para JS
    public ActivoFijoUrlsViewModel Urls { get; set; } = new();
}
```

**Reduccion Esperada:**
- Index: 1,628 → ~120 lineas
- JS: ~965 → ~400 lineas (modulo organizado)
- Modales: inline → 33 parciales reutilizables

---

### 2.2 ListarComprobantes/Index.cshtml

**Estado Actual:**
- Lineas: 1,631
- JS estimado: 1,205 lineas
- Modales: 14
- Funciones JS: 47
- Llamadas AJAX: 88

**Plan de Refactorizacion:**

| Componente | Archivo a Crear |
|------------|-----------------|
| ViewModel | `ListarComprobantesViewModel.cs` |
| Index | `Views/Index.cshtml` (~100 lineas) |
| Parcial Header | `Views/Sections/_Header.cshtml` |
| Parcial Filtros | `Views/Sections/_FiltrosComprobante.cshtml` |
| Parcial Tabla | `Views/Sections/_TablaComprobantes.cshtml` |
| Parcial Paginacion | `Views/Sections/_Paginacion.cshtml` |
| Modal Detalle | `Views/Modals/_ModalDetalleComprobante.cshtml` |
| ... (13 modales mas) | `Views/Modals/_Modal*.cshtml` |
| JS Externo | `wwwroot/js/features/listar-comprobantes.js` |

**Reduccion Esperada:**
- Index: 1,631 → ~100 lineas
- JS: 1,205 → ~300 lineas

---

### 2.3 PlanCuentas/Index.cshtml

**Estado Actual:**
- Lineas: 1,590
- JS estimado: 1,143 lineas
- Estructura de arbol manejada en JS

**Plan de Refactorizacion:**

| Componente | Archivo a Crear |
|------------|-----------------|
| ViewModel | `PlanCuentasViewModel.cs` |
| Index | `Views/Index.cshtml` (~100 lineas) |
| Parcial Header | `Views/Sections/_Header.cshtml` |
| Parcial Toolbar | `Views/Sections/_ToolbarBusqueda.cshtml` |
| Parcial Arbol | `Views/Sections/_ArbolCuentas.cshtml` |
| Parcial Acciones | `Views/Sections/_AccionesCRUD.cshtml` |
| Modal Nueva Cuenta | `Views/Modals/_ModalNuevaCuenta.cshtml` |
| Modal Editar | `Views/Modals/_ModalEditarCuenta.cshtml` |
| JS Externo | `wwwroot/js/features/plan-cuentas.js` |

**Nota:** El arbol de cuentas puede usar jsTree pero los datos deben venir server-side, no construirse en JS.

---

## FASE 3: Reportes y Balances

### 3.1 BalanceClasificado/Index.cshtml

**Estado Actual:**
- Lineas: 729
- JS estimado: ~130 lineas
- Anti-patrones: `balanceData=[]`, innerHTML, Math.abs en JS

**Plan de Refactorizacion:**

| Componente | Archivo a Crear |
|------------|-----------------|
| ViewModel | `BalanceClasificadoViewModel.cs` |
| Parcial Filtros | `Views/Sections/_FiltrosBalance.cshtml` |
| Parcial Tabla | `Views/Sections/_TablaBalance.cshtml` |
| Parcial Totales | `Views/Sections/_TotalesBalance.cshtml` |
| JS Externo | `wwwroot/js/features/balance-clasificado.js` |

**ViewModel con calculos server-side:**
```csharp
public class BalanceClasificadoViewModel
{
    public short Ano { get; set; }
    public byte Mes { get; set; }

    public List<CuentaBalanceItem> Activos { get; set; } = new();
    public List<CuentaBalanceItem> Pasivos { get; set; } = new();
    public List<CuentaBalanceItem> Patrimonio { get; set; } = new();

    // Totales calculados en C# (NO en JavaScript)
    public decimal TotalActivos => Activos.Sum(c => c.Saldo);
    public decimal TotalPasivos => Pasivos.Sum(c => c.Saldo);
    public decimal TotalPatrimonio => Patrimonio.Sum(c => c.Saldo);

    // Validacion contable
    public decimal Diferencia => TotalActivos - (TotalPasivos + TotalPatrimonio);
    public bool EstaCuadrado => Math.Abs(Diferencia) < 0.01m;
}
```

---

### 3.2 BalanceClasificadoComparativo/Index.cshtml

**Estado Actual:**
- Lineas: 725
- CSS inline: ~200 lineas
- Calculos de diferencias en JS

**Plan de Refactorizacion:**

| Componente | Archivo a Crear |
|------------|-----------------|
| ViewModel | `BalanceComparativoViewModel.cs` |
| CSS Externo | `wwwroot/css/features/balance-comparativo.css` |
| Parcial Filtros | `Views/Sections/_FiltrosComparativo.cshtml` |
| Parcial Tabla | `Views/Sections/_TablaComparativa.cshtml` |
| JS Externo | `wwwroot/js/features/balance-comparativo.js` |

**ViewModel con comparaciones server-side:**
```csharp
public class BalanceComparativoViewModel
{
    public short AnoPeriodo1 { get; set; }
    public byte MesPeriodo1 { get; set; }
    public short AnoPeriodo2 { get; set; }
    public byte MesPeriodo2 { get; set; }

    public List<CuentaComparativaItem> Cuentas { get; set; } = new();
}

public class CuentaComparativaItem
{
    public string Codigo { get; set; }
    public string Nombre { get; set; }
    public decimal SaldoPeriodo1 { get; set; }
    public decimal SaldoPeriodo2 { get; set; }

    // Calculos en C#, no en JS
    public decimal Diferencia => SaldoPeriodo2 - SaldoPeriodo1;
    public decimal PorcentajeVariacion => SaldoPeriodo1 != 0
        ? (Diferencia / Math.Abs(SaldoPeriodo1)) * 100
        : 0;
}
```

---

### 3.3 BalanceGeneral/Index.cshtml

**Estado Actual:**
- Lineas: 689
- Formulario 8 columnas
- JSON.stringify con filtros complejos

**Plan de Refactorizacion:**

| Componente | Archivo a Crear |
|------------|-----------------|
| ViewModel | `BalanceGeneralViewModel.cs` |
| Parcial Filtros | `Views/Sections/_FiltrosBalanceGeneral.cshtml` |
| Parcial Tabla | `Views/Sections/_TablaBalanceGeneral.cshtml` |
| JS Externo | `wwwroot/js/features/balance-general.js` |

---

### 3.4 BaseImponible14DCompleta/Index.cshtml

**Estado Actual:**
- Lineas: 680
- Calculos recursivos de totales en JS
- `expandedRows` estado global
- `copyToExcel()` en JS

**Plan de Refactorizacion:**

| Componente | Archivo a Crear |
|------------|-----------------|
| ViewModel | `BaseImponible14DViewModel.cs` |
| Parcial Header | `Views/Sections/_HeaderBaseImponible.cshtml` |
| Parcial Arbol | `Views/Sections/_ArbolBaseImponible.cshtml` |
| Parcial Acciones | `Views/Sections/_AccionesExportar.cshtml` |
| JS Externo | `wwwroot/js/features/base-imponible-14d.js` |

**Nota:** Los calculos recursivos de base imponible deben hacerse en el backend, enviando la estructura ya calculada a la vista.

---

## FASE 4: Vistas Adicionales

### 4.1 AnalisisVencimientos/Index.cshtml
- Mover validacion RUT a C# con [Remote] o atributo personalizado
- Extraer filtros a parcial

### 4.2 AuditoriaGeneral/Index.cshtml
- Tabla que dice `<!-- Se llenara con JavaScript -->` debe renderizarse server-side
- Combobox dinamicos con ViewComponent o parciales

### 4.3 CapitalPropioSimplificado/Index.cshtml
- `cargarDatos()` debe ser carga inicial en ViewModel
- `exportarExcel()` debe ser endpoint del controller

### 4.4 CapitalSimpleMini/Index.cshtml
- Tabla editable con EditorTemplates
- `dataOriginal`, `detallesModificados` en ViewModel

---

## Resumen de Impacto Esperado

| Metrica | Antes | Despues | Reduccion |
|---------|-------|---------|-----------|
| **GestionActivoFijo/Index** | 1,628 lineas | ~120 lineas | 93% |
| **ListarComprobantes/Index** | 1,631 lineas | ~100 lineas | 94% |
| **PlanCuentas/Index** | 1,590 lineas | ~100 lineas | 94% |
| **Total JS inline** | ~5,000 lineas | ~1,200 lineas | 76% |
| **Modales inline** | 47+ | 0 (todos parciales) | 100% |
| **Validaciones JS** | 34 funciones | 0 (todas en C#) | 100% |
| **Calculos JS** | 92 lugares | 0 (todos en C#) | 100% |

---

## Checklist de Refactorizacion por Vista

Para cada vista a refactorizar, seguir estos pasos:

- [ ] Crear ViewModel con propiedades tipadas
- [ ] Implementar IValidatableObject para validaciones de negocio
- [ ] Agregar DataAnnotations para validaciones de campo
- [ ] Agregar [Remote] para validaciones async
- [ ] Crear propiedades computadas para totales/calculos
- [ ] Extraer modales a carpeta `Views/Modals/`
- [ ] Extraer secciones a carpeta `Views/Sections/`
- [ ] Crear EditorTemplates para filas dinamicas
- [ ] Crear archivo JS externo en `wwwroot/js/features/`
- [ ] Actualizar Controller para usar ViewModel
- [ ] Actualizar Index.cshtml para usar parciales
- [ ] Compilar y verificar
- [ ] Probar funcionalidad completa

---

## Archivos de Referencia

El patron completo ya esta implementado en:

- **ViewModel:** `Features/NuevoComprobante/ComprobanteViewModel.cs`
- **Index simplificado:** `Features/NuevoComprobante/Views/Index.cshtml`
- **Parciales Modales:** `Features/NuevoComprobante/Views/Modals/_Modal*.cshtml`
- **Parciales Secciones:** `Features/NuevoComprobante/Views/Sections/_*.cshtml`
- **EditorTemplate:** `Features/NuevoComprobante/Views/EditorTemplates/MovimientoItemViewModel.cshtml`
- **JS Externo:** `wwwroot/js/features/nuevo-comprobante.js`
- **Controller:** `Features/NuevoComprobante/NuevoComprobanteController.cs`

Usar estos archivos como plantilla para las demas refactorizaciones.
