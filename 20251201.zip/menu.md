# Análisis Comparativo: Menú Actual vs Propuesta

## Resumen Ejecutivo

**La propuesta de menu.md es MEJOR** porque elimina ~35 items problemáticos que son modales de segundo nivel, redundantes o ayudas contextuales que no deberían tener acceso directo desde el menú.

---

## Comparación Detallada

### Estructura General

| Aspecto | Menú Actual (_Layout.cshtml) | Propuesta (menu.md) |
|---------|------------------------------|---------------------|
| **Secciones principales** | 6 | 10 |
| **Items totales** | ~180 | ~140 |
| **Modales 2do nivel** | ~25 | 0 |
| **Redundantes** | ~8 | 0 |
| **Ayudas contextuales** | ~4 | 0 |

### Secciones del Menú

| Menú Actual | Propuesta |
|-------------|-----------|
| 1. Preparación y Parámetros | 1. Inicio |
| 2. Operaciones Diarias | 2. Configuración |
| 3. Control & Reportes | 3. Operaciones Diarias |
| 4. Impuestos & Integración | 4. Libros Contables |
| 5. Cierre Contable | 5. Informes y Balances |
| 6. Herramientas | 6. Tributario |
| | 7. Integración SII |
| | 8. Cierre Contable |
| | 9. Administración |
| | 10. Ayuda |

---

## Items Problemáticos en Menú Actual

### 1. Modales de Segundo Nivel (requieren contexto/ID)

Estos items **NO deberían estar en el menú** porque fallan sin contexto previo:

| Controller | Problema | Estado en Propuesta |
|------------|----------|---------------------|
| `EdicionEntidad` | Necesita IdEntidad | ELIMINAR |
| `GestionCuotas` | Necesita IdDoc | Ya comentado |
| `MarcacionActivoFijo` | Necesita selección previa | ELIMINAR |
| `DetalleCapitalSimple` | Es drill-down | ELIMINAR |
| `CapitalSimpleAcumulado` | Es drill-down | ELIMINAR |
| `CapitalSimpleMini` | Es drill-down | ELIMINAR |
| `DetalleSaldoApertura` | Es drill-down | ELIMINAR |
| `DetalleBaseImponible14D` | Es drill-down | ELIMINAR |
| `SeguimientoMovimientos` | Es drill-down | ELIMINAR |
| `SeguimientoDocumentos` | Es drill-down | ELIMINAR |

### 2. Modales Internos de Configuración

Estos se acceden desde su pantalla padre, no directamente:

| Controller | Acceso Correcto | Estado en Propuesta |
|------------|-----------------|---------------------|
| `CuentasLibroCompras` | Desde CuentasDefinidas | ELIMINAR |
| `CuentasLibroVentas` | Desde CuentasDefinidas | ELIMINAR |
| `ConfiguracionPlanCuentas` | Desde CuentasDefinidas | ELIMINAR |
| `ConfiguracionPlanCuentas2019` | Desde CuentasDefinidas | ELIMINAR |
| `SolicitudSincronizacionSii` | Desde SincronizacionSii | ELIMINAR |
| `CopiarSincronizacion` | Desde SincronizacionSii | ELIMINAR |
| `EditarSincronizacion` | Desde SincronizacionSii | ELIMINAR |
| `ActualizacionGlosas` | Desde Glosas | ELIMINAR |

### 3. Herramientas Contextuales

Se usan dentro de otras pantallas, no como punto de entrada:

| Controller | Uso | Estado en Propuesta |
|------------|-----|---------------------|
| `ConversionMonedas` | Selector en comprobantes | ELIMINAR |
| `EjemploImportacion` | Ayuda en importaciones | ELIMINAR |
| `FormatoImportacionEntidades` | Ayuda en importaciones | ELIMINAR |
| `CompraVenta` | Se usa desde GestionDocumentos | ELIMINAR |

### 4. Redundantes/Duplicados

| Controller | Alternativa | Estado en Propuesta |
|------------|-------------|---------------------|
| `ImportarActivoFijoArchivo` | ImportarActivoFijo | ELIMINAR |
| `ImportarOtrosDocsCompleta` | ImportarOtrosDocs | ELIMINAR |
| `ReporteControlEmpresasAlt` | ReporteControlEmpresas | ELIMINAR |
| `ImportarEmpresas` | ImportarEmpresa | ELIMINAR |
| `ImportarDesdeArchivo` | ImportarEmpresa | ELIMINAR |
| `ConsultaComprobantes` | ListarComprobantes | ELIMINAR |
| `ListadoAtributos` | Acceder desde config | ELIMINAR |

### 5. Ayudas Contextuales

Deben mostrarse desde su pantalla relacionada:

| Controller | Mostrar Desde | Estado en Propuesta |
|------------|---------------|---------------------|
| `AyudaImportacionCartola` | ImportarCartolasBancarias | ELIMINAR |
| `AyudaBackup` | GenerarBackup | ELIMINAR |
| `InformacionAyudaEmpresas` | MantenimientoEmpresas | ELIMINAR |
| `InformacionAyuda` | Ayuda principal | ELIMINAR |

---

## Ventajas de la Propuesta

### 1. Sin Errores de Contexto
El usuario no puede acceder a pantallas que fallarán por falta de datos previos.

**Ejemplo actual problemático:**
```
Usuario hace clic en "Edición Entidad" → Error porque no hay IdEntidad
Usuario hace clic en "Detalle Capital Simple" → Pantalla vacía/error
```

### 2. Menú Más Limpio
- **22% menos items** (~180 → ~140)
- Menos scroll necesario
- Más fácil encontrar lo que busca

### 3. Flujo Contable Natural
La propuesta sigue el ciclo de trabajo:
```
Configurar → Operar → Consultar → Cerrar
```

### 4. Sin Redundancia
Un solo camino para cada funcionalidad, evitando confusión.

### 5. Mejor Organización
10 secciones temáticas claras vs 6 secciones mezcladas.

---

## Desventajas del Menú Actual

1. **Expone pantallas inutilizables** - Modales que requieren contexto
2. **Redundancia** - Múltiples formas de llegar a lo mismo
3. **Mezcla de niveles** - Combina puntos de entrada con sub-pantallas
4. **Confusión** - Usuario no sabe qué funciona directamente
5. **Mantenimiento difícil** - Más items que sincronizar

---

## Recomendación Final

| Criterio | Menú Actual | Propuesta |
|----------|-------------|-----------|
| Usabilidad | Regular | Buena |
| Claridad | Regular | Buena |
| Sin errores contexto | No | Sí |
| Mantenibilidad | Difícil | Fácil |
| Cantidad de items | Excesiva | Adecuada |
| **VEREDICTO** | **NO RECOMENDADO** | **RECOMENDADO** |

---

## Plan de Implementación

### Fase 1: Eliminar items problemáticos
Comentar o eliminar los ~35 items identificados en `_Layout.cshtml`.

### Fase 2: Reorganizar secciones
Agrupar según la estructura propuesta de 10 secciones.

### Fase 3: Validar accesos
Verificar que cada pantalla eliminada del menú sea accesible desde su pantalla padre.

---

## Items a Eliminar de _Layout.cshtml

```html
<!-- ELIMINAR - Modales de segundo nivel -->
EdicionEntidad
MarcacionActivoFijo
DetalleCapitalSimple
CapitalSimpleAcumulado
CapitalSimpleMini
DetalleSaldoApertura
DetalleBaseImponible14D
SeguimientoMovimientos
SeguimientoDocumentos

<!-- ELIMINAR - Modales internos de config -->
CuentasLibroCompras
CuentasLibroVentas
ConfiguracionPlanCuentas
ConfiguracionPlanCuentas2019
SolicitudSincronizacionSii
CopiarSincronizacion
EditarSincronizacion
ActualizacionGlosas

<!-- ELIMINAR - Herramientas contextuales -->
ConversionMonedas
EjemploImportacion
FormatoImportacionEntidades
CompraVenta

<!-- ELIMINAR - Redundantes -->
ImportarActivoFijoArchivo
ImportarOtrosDocsCompleta
ReporteControlEmpresasAlt
ImportarEmpresas
ImportarDesdeArchivo
ConsultaComprobantes
ListadoAtributos

<!-- ELIMINAR - Ayudas contextuales -->
AyudaImportacionCartola
AyudaBackup
InformacionAyudaEmpresas
InformacionAyuda
```

**Total: ~35 items a eliminar**

---

*Documento: Noviembre 2025*
*Conclusión: Implementar la propuesta de menú limpio*
