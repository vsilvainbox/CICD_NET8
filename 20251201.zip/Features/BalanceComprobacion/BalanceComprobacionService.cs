using App.Data;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Drawing;
using App.Exceptions;

namespace App.Features.BalanceComprobacion;

public class BalanceComprobacionService(LpContabContext context, ILogger<BalanceComprobacionService> logger) : IBalanceComprobacionService
{
    public async Task<BalanceComprobacionResponseDto> GenerarAsync(BalanceComprobacionRequestDto request, CancellationToken cancellationToken = default)
    {
        logger.LogInformation("Generando Balance de Comprobación para Empresa {EmpresaId}, Nivel {Nivel}, Período {Desde}-{Hasta}", 
            request.EmpresaId, request.Nivel, request.FechaDesde, request.FechaHasta);

        var fechaDesdeInt = int.Parse(request.FechaDesde.ToString("yyyyMMdd"));
        var fechaHastaInt = int.Parse(request.FechaHasta.ToString("yyyyMMdd"));

        // VB6: GenQueryPorNiveles - Genera query compleja que agrupa cuentas por niveles jerárquicos
        // El balance VB6 NO tiene saldos iniciales, solo movimientos del período
            
        // UNION 1: Todas las cuentas del nivel solicitado (sin movimientos)
        var todasCuentas = await context.Cuentas
            .Where(c => c.IdEmpresa == request.EmpresaId 
                        && c.Ano == request.Ano
                        && c.Nivel <= request.Nivel)
            .Select(c => new { 
                IdQ = 1,
                c.idCuenta, 
                c.Codigo, 
                c.Nivel, 
                c.Descripcion, 
                c.Clasificacion,
                Debe = 0.0,
                Haber = 0.0
            })
            .ToListAsync(cancellationToken);

        // UNION 2: Movimientos directos de cuentas del nivel seleccionado
        var movimientosDirectos = await (
            from cta in context.Cuentas
            join mov in context.MovComprobante on cta.idCuenta equals mov.IdCuenta
            join comp in context.Comprobante on new { mov.IdEmpresa, mov.Ano, IdComp = mov.IdComp } 
                equals new { comp.IdEmpresa, comp.Ano, IdComp = (int?)comp.IdComp }
            where cta.IdEmpresa == request.EmpresaId
                  && cta.Ano == request.Ano
                 && cta.Nivel <= request.Nivel
                 && comp.Fecha >= fechaDesdeInt
                 && comp.Fecha <= fechaHastaInt
                 && (request.SoloLibroOficial ? comp.Estado == 2 : (comp.Estado == 2 || comp.Estado == 3))
                 && (request.AreaNegocioId == null || mov.idAreaNeg == request.AreaNegocioId)
                 && (request.CentroCostoId == null || mov.idCCosto == request.CentroCostoId)
                 && (request.TipoAjuste == 1 
                     ? (comp.TipoAjuste == null || comp.TipoAjuste == 1 || comp.TipoAjuste == 3)
                     : (comp.TipoAjuste == 2 || comp.TipoAjuste == 3))
           group new { mov.Debe, mov.Haber } by new {
                cta.idCuenta, 
                cta.Codigo, 
                cta.Nivel, 
                cta.Descripcion, 
                cta.Clasificacion 
            } into g
            select new {
                IdQ = 2,
                g.Key.idCuenta,
                g.Key.Codigo,
                g.Key.Nivel,
                g.Key.Descripcion,
                g.Key.Clasificacion,
                Debe = g.Sum(x => x.Debe ?? 0),
                Haber = g.Sum(x => x.Haber ?? 0)
            }
        ).ToListAsync(cancellationToken);

        // UNION 3: Suma de cuentas hijas hacia cuentas padre (si nivel < máximo)
        var movimientosPadre = new List<dynamic>();
        if (request.Nivel < 5)
        {
            var padreList = await (
                from cta in context.Cuentas
                join mov in context.MovComprobante on cta.idCuenta equals mov.IdCuenta
                join comp in context.Comprobante on new { mov.IdEmpresa, mov.Ano, IdComp = mov.IdComp }
                    equals new { comp.IdEmpresa, comp.Ano, IdComp = (int?)comp.IdComp }
                join ctaPadre in context.Cuentas on cta.idPadre equals ctaPadre.idCuenta
                where ctaPadre.IdEmpresa == request.EmpresaId
                      && ctaPadre.Ano == request.Ano
                      && ctaPadre.Nivel == request.Nivel
                      && comp.Fecha >= fechaDesdeInt
                      && comp.Fecha <= fechaHastaInt
                      && (request.SoloLibroOficial ? comp.Estado == 2 : (comp.Estado == 2 || comp.Estado == 3))
                      && (request.AreaNegocioId == null || mov.idAreaNeg == request.AreaNegocioId)
                      && (request.CentroCostoId == null || mov.idCCosto == request.CentroCostoId)
                      && (request.TipoAjuste == 1
                          ? (comp.TipoAjuste == null || comp.TipoAjuste == 1 || comp.TipoAjuste == 3)
                          : (comp.TipoAjuste == 2 || comp.TipoAjuste == 3))
                group new { mov.Debe, mov.Haber } by new {
                    ctaPadre.idCuenta,
                    ctaPadre.Codigo,
                    ctaPadre.Nivel,
                    ctaPadre.Descripcion,
                    ctaPadre.Clasificacion
                } into g
                select new {
                    IdQ = 3,
                    g.Key.idCuenta,
                    g.Key.Codigo,
                    g.Key.Nivel,
                    g.Key.Descripcion,
                    g.Key.Clasificacion,
                    Debe = g.Sum(x => x.Debe ?? 0),
                    Haber = g.Sum(x => x.Haber ?? 0)
                }
            ).ToListAsync(cancellationToken);
                
            movimientosPadre = padreList.Cast<dynamic>().ToList();
        }

        // Combinar todas las UNIONs
        var todosMovimientos = todasCuentas.Cast<dynamic>()
            .Union(movimientosDirectos.Cast<dynamic>())
            .Union(movimientosPadre.Cast<dynamic>())
            .ToList();

        // Agrupar por cuenta y sumar
        var cuentasAgrupadas = todosMovimientos
            .GroupBy(x => new { 
                IdCuenta = (int?)x.idCuenta,
                Codigo = (string)x.Codigo, 
                Nivel = (int?)x.Nivel, 
                Descripcion = (string)x.Descripcion,
                Clasificacion = (int?)x.Clasificacion
            })
            .Select(g => new {
                g.Key.IdCuenta,
                g.Key.Codigo,
                g.Key.Nivel,
                g.Key.Descripcion,
                g.Key.Clasificacion,
                Debe = g.Sum(x => (double)x.Debe),
                Haber = g.Sum(x => (double)x.Haber)
            })
            .OrderBy(x => x.Codigo)
            .ToList();

        // Procesar filas según lógica VB6 LoadAll
        var filas = new List<BalanceComprobacionRowDto>();
        var totalesPorNivel = new Dictionary<int, (double Debe, double Haber, int Linea)>();
            
        foreach (var cta in cuentasAgrupadas)
        {
            var nivel = cta.Nivel ?? 0;
                
            // Solo mostrar cuentas del nivel seleccionado con movimientos (VB6 LoadAll lógica)
            if (nivel != request.Nivel || (cta.Debe == 0 && cta.Haber == 0))
            {
                continue;
            }

            var diff = cta.Debe - cta.Haber;
                
            var fila = new BalanceComprobacionRowDto
            {
                IdCuenta = cta.IdCuenta,
                Codigo = cta.Codigo ?? string.Empty,
                Nombre = cta.Descripcion ?? string.Empty,
                Nivel = nivel,
                Clasificacion = cta.Clasificacion,
                Debitos = (decimal)cta.Debe,
                Creditos = (decimal)cta.Haber,
                SaldoDeudor = diff > 0 ? (decimal)diff : 0,
                SaldoAcreedor = diff < 0 ? (decimal)Math.Abs(diff) : 0
            };

            filas.Add(fila);
        }

        // Calcular Sub Totales (solo nivel 1)
        var totales = new BalanceComprobacionTotalesDto();
        foreach (var fila in filas.Where(f => f.Nivel == 1))
        {
            totales.SubTotalDebitos += fila.Debitos;
            totales.SubTotalCreditos += fila.Creditos;
            totales.SubTotalSaldoDeudor += fila.SaldoDeudor;
            totales.SubTotalSaldoAcreedor += fila.SaldoAcreedor;
        }

        // Calcular Utilidad o Pérdida (VB6: GridTot(1))
        var diffDebCred = totales.SubTotalDebitos - totales.SubTotalCreditos;
        if (diffDebCred > 0)
        {
            totales.UtilidadPerdidaDebitos = diffDebCred;
        }
        else
        {
            totales.UtilidadPerdidaCreditos = Math.Abs(diffDebCred);
        }

        var diffSaldos = totales.SubTotalSaldoDeudor - totales.SubTotalSaldoAcreedor;
        if (diffSaldos > 0)
        {
            totales.UtilidadPerdidaSaldoDeudor = diffSaldos;
        }
        else
        {
            totales.UtilidadPerdidaSaldoAcreedor = Math.Abs(diffSaldos);
        }

        // Totales finales (VB6: GridTot(2))
        totales.TotalDebitos = totales.SubTotalDebitos + totales.UtilidadPerdidaDebitos;
        totales.TotalCreditos = totales.SubTotalCreditos + totales.UtilidadPerdidaCreditos;
        totales.TotalSaldoDeudor = totales.SubTotalSaldoDeudor + totales.UtilidadPerdidaSaldoDeudor;
        totales.TotalSaldoAcreedor = totales.SubTotalSaldoAcreedor + totales.UtilidadPerdidaSaldoAcreedor;

        logger.LogInformation("Balance generado: {Count} filas, Débitos={Debitos}, Créditos={Creditos}", 
            filas.Count, totales.TotalDebitos, totales.TotalCreditos);

        return new BalanceComprobacionResponseDto
        {
            Filas = filas,
            Totales = totales,
            Filtros = new BalanceComprobacionFiltroAplicadoDto
            {
                FechaDesde = request.FechaDesde,
                FechaHasta = request.FechaHasta,
                Nivel = request.Nivel,
                SoloLibroOficial = request.SoloLibroOficial,
                TipoAjuste = request.TipoAjuste
            }
        };
    }

    public async Task<BalanceComprobacionExportResponseDto> ExportarExcelAsync(BalanceComprobacionExportRequestDto request, CancellationToken cancellationToken = default)
    {
        logger.LogInformation("Exportando Balance de Comprobación a Excel para Empresa {EmpresaId}", request.EmpresaId);
            
        // Generar el balance primero
        var balance = await GenerarAsync(request, cancellationToken);
            
        // Obtener datos de la empresa
        var empresa = await context.Empresa
            .FirstOrDefaultAsync(e => e.Id == request.EmpresaId, cancellationToken);

        if (empresa == null)
        {
            throw new BusinessException($"Empresa {request.EmpresaId} no encontrada");
        }

        ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

        using var package = new ExcelPackage();
        var worksheet = package.Workbook.Worksheets.Add("Balance de Comprobación");

        int row = 1;

        // Encabezado empresa
        worksheet.Cells[row, 1].Value = empresa.Nombre;
        worksheet.Cells[row, 1].Style.Font.Bold = true;
        worksheet.Cells[row, 1].Style.Font.Size = 14;
        row++;

        worksheet.Cells[row, 1].Value = $"RUT: {empresa.Rut}";
        row++;

        // Título
        worksheet.Cells[row, 1].Value = "BALANCE DE COMPROBACIÓN Y SALDOS";
        worksheet.Cells[row, 1].Style.Font.Bold = true;
        worksheet.Cells[row, 1].Style.Font.Size = 12;
        row++;

        // Período
        worksheet.Cells[row, 1].Value = $"Período: {request.FechaDesde:dd/MM/yyyy} a {request.FechaHasta:dd/MM/yyyy}";
        row++;
        row++; // Línea en blanco

        // Encabezados de columnas
        int col = 1;
        if (request.MostrarCodigoCuenta)
        {
            worksheet.Cells[row, col++].Value = "Código";
        }
        worksheet.Cells[row, col++].Value = "Cuenta";
        worksheet.Cells[row, col++].Value = "Débitos";
        worksheet.Cells[row, col++].Value = "Créditos";
        worksheet.Cells[row, col++].Value = "Saldo Deudor";
        worksheet.Cells[row, col++].Value = "Saldo Acreedor";

        // Formato encabezados
        using (var range = worksheet.Cells[row, 1, row, col - 1])
        {
            range.Style.Font.Bold = true;
            range.Style.Fill.PatternType = ExcelFillStyle.Solid;
            range.Style.Fill.BackgroundColor.SetColor(Color.LightGray);
            range.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
            range.Style.Border.BorderAround(ExcelBorderStyle.Thin);
        }
        row++;

        // Filas de datos
        foreach (var fila in balance.Filas)
        {
            col = 1;
            if (request.MostrarCodigoCuenta)
            {
                worksheet.Cells[row, col++].Value = fila.Codigo;
            }
            worksheet.Cells[row, col++].Value = fila.Nombre;
            
            // Aplicar indentación según nivel
            if (fila.Nivel > 1)
            {
                worksheet.Cells[row, col - 1].Style.Indent = fila.Nivel - 1;
            }

            worksheet.Cells[row, col++].Value = fila.Debitos;
            worksheet.Cells[row, col++].Value = fila.Creditos;
            worksheet.Cells[row, col++].Value = fila.SaldoDeudor;
            worksheet.Cells[row, col++].Value = fila.SaldoAcreedor;

            // Formato números
            for (int i = (request.MostrarCodigoCuenta ? 3 : 2); i <= col - 1; i++)
            {
                worksheet.Cells[row, i].Style.Numberformat.Format = "#,##0";
                worksheet.Cells[row, i].Style.HorizontalAlignment = ExcelHorizontalAlignment.Right;
            }

            row++;
        }

        row++; // Línea en blanco antes de totales

        // Totales
        col = 1;
        if (request.MostrarCodigoCuenta) col++;
        
        // Sub Total
        worksheet.Cells[row, col].Value = "Sub Total";
        worksheet.Cells[row, col].Style.Font.Bold = true;
        worksheet.Cells[row, col + 1].Value = balance.Totales.SubTotalDebitos;
        worksheet.Cells[row, col + 2].Value = balance.Totales.SubTotalCreditos;
        worksheet.Cells[row, col + 3].Value = balance.Totales.SubTotalSaldoDeudor;
        worksheet.Cells[row, col + 4].Value = balance.Totales.SubTotalSaldoAcreedor;
        row++;

        // Utilidad o Pérdida
        worksheet.Cells[row, col].Value = "Utilidad o Pérdida";
        worksheet.Cells[row, col].Style.Font.Bold = true;
        worksheet.Cells[row, col + 1].Value = balance.Totales.UtilidadPerdidaDebitos;
        worksheet.Cells[row, col + 2].Value = balance.Totales.UtilidadPerdidaCreditos;
        worksheet.Cells[row, col + 3].Value = balance.Totales.UtilidadPerdidaSaldoDeudor;
        worksheet.Cells[row, col + 4].Value = balance.Totales.UtilidadPerdidaSaldoAcreedor;
        row++;

        // TOTALES
        worksheet.Cells[row, col].Value = "TOTALES";
        worksheet.Cells[row, col].Style.Font.Bold = true;
        worksheet.Cells[row, col + 1].Value = balance.Totales.TotalDebitos;
        worksheet.Cells[row, col + 2].Value = balance.Totales.TotalCreditos;
        worksheet.Cells[row, col + 3].Value = balance.Totales.TotalSaldoDeudor;
        worksheet.Cells[row, col + 4].Value = balance.Totales.TotalSaldoAcreedor;

        // Formato totales
        using (var range = worksheet.Cells[row - 2, col, row, col + 4])
        {
            range.Style.Font.Bold = true;
            range.Style.Fill.PatternType = ExcelFillStyle.Solid;
            range.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(217, 217, 217));
            
            for (int i = col + 1; i <= col + 4; i++)
            {
                worksheet.Cells[row - 2, i].Style.Numberformat.Format = "#,##0";
                worksheet.Cells[row - 1, i].Style.Numberformat.Format = "#,##0";
                worksheet.Cells[row, i].Style.Numberformat.Format = "#,##0";
                worksheet.Cells[row - 2, i].Style.HorizontalAlignment = ExcelHorizontalAlignment.Right;
                worksheet.Cells[row - 1, i].Style.HorizontalAlignment = ExcelHorizontalAlignment.Right;
                worksheet.Cells[row, i].Style.HorizontalAlignment = ExcelHorizontalAlignment.Right;
            }
        }

        // Ajustar ancho de columnas
        worksheet.Cells[worksheet.Dimension.Address].AutoFitColumns();

        var bytes = package.GetAsByteArray();
            
        return new BalanceComprobacionExportResponseDto
        {
            FileName = $"BalanceComprobacion_{request.FechaDesde:yyyyMMdd}_{request.FechaHasta:yyyyMMdd}.xlsx",
            ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            Content = bytes
        };
    }

    public async Task<BalanceComprobacionOpcionesDto> ObtenerOpcionesAsync(int empresaId, CancellationToken cancellationToken = default)
    {
        logger.LogInformation("Obteniendo opciones para Balance de Comprobación, Empresa {EmpresaId}", empresaId);
            
        var opciones = new BalanceComprobacionOpcionesDto
        {
            Niveles = Enumerable.Range(1, 5)
                .Select(n => new ComboItemDto { Value = n, Text = $"Nivel {n}" })
                .ToList(),

            TiposAjuste = new List<ComboItemDto>
            {
                new() { Value = 1, Text = "Financiero" },
                new() { Value = 2, Text = "Tributario" },
                new() { Value = 3, Text = "Ambos" }
            }
        };

        // Obtener áreas de negocio
        var areas = await context.AreaNegocio
            .Where(a => a.IdEmpresa == empresaId && a.Vigente == true)
            .OrderBy(a => a.Codigo)
            .Select(a => new ComboItemDto
            {
                Value = a.IdAreaNegocio,
                Text = $"{a.Codigo} - {a.Descripcion}"
            })
            .ToListAsync(cancellationToken);

        opciones.AreasNegocio = areas;

        // Obtener centros de costo
        var centros = await context.CentroCosto
            .Where(c => c.IdEmpresa == empresaId && c.Vigente == true)
            .OrderBy(c => c.Codigo)
            .Select(c => new ComboItemDto
            {
                Value = c.IdCCosto,
                Text = $"{c.Codigo} - {c.Descripcion}"
            })
            .ToListAsync(cancellationToken);

        opciones.CentrosCosto = centros;

        return opciones;
    }
}