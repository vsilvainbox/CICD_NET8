namespace App.Features.ConfiguracionHojasTimbraje;

/// <summary>
/// Service para configuración e impresión de hojas foliadas para timbraje
/// Migrado desde FrmPrtFoliacion.frm (VB6)
/// </summary>
public interface IConfiguracionHojasTimbrajeService
{
    /// <summary>
    /// Obtiene información de timbraje para una empresa
    /// Mapea función LoadAll() y variable global gFoliacion de VB6
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <returns>Información de timbraje o null si no existe</returns>
    Task<TimbrajeDto?> GetTimbrajeAsync(int empresaId);

    /// <summary>
    /// Valida el rango de folios antes de imprimir
    /// Mapea función Valida() de VB6
    /// </summary>
    /// <param name="dto">Datos del rango a validar</param>
    /// <returns>Resultado de validación con mensajes</returns>
    Task<ValidationResult> ValidarRangoFoliosAsync(ValidarRangoFoliosDto dto);

    /// <summary>
    /// Actualiza el último folio impreso en la base de datos
    /// Mapea UPDATE Timbraje en Bt_Print_Click de VB6
    /// </summary>
    /// <param name="dto">Datos para actualizar</param>
    /// <returns>Resultado de la operación</returns>
    Task<ValidationResult> ActualizarUltimoImpresoAsync(ActualizarImpresoDto dto);

    /// <summary>
    /// Genera datos para imprimir hojas foliadas (para PDF o window.print)
    /// Mapea función PrtHojasFoliadas() de VB6
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="desde">Folio inicial</param>
    /// <param name="hasta">Folio final</param>
    /// <param name="orientacion">Orientación: "vertical" o "horizontal"</param>
    /// <returns>Datos estructurados de las hojas</returns>
    Task<HojasTimbrajeDto> GenerarDatosHojasAsync(int empresaId, int desde, int hasta, string orientacion);

    /// <summary>
    /// Obtiene información de empresa para imprimir en hojas
    /// Mapea variable global gEmpresa de VB6
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <returns>Datos de empresa o null si no existe</returns>
    Task<EmpresaTimbrajeDto?> GetEmpresaTimbrajeAsync(int empresaId);
}