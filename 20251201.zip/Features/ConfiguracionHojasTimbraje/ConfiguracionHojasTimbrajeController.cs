using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Text.Json;
using App.Extensions;
using App.Helpers;

namespace App.Features.ConfiguracionHojasTimbraje;

[Authorize]

public class ConfiguracionHojasTimbrajeController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<ConfiguracionHojasTimbrajeController> logger) : Controller
{
    public Task<IActionResult> Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a la Configuración de Hojas de Timbraje";
            TempData["SwalType"] = "warning";
            return Task.FromResult<IActionResult>(RedirectToAction("Index", "SeleccionarEmpresa"));
        }

        // Extraer datos de HttpContext usando extensiones
        int empresaId = SessionHelper.EmpresaId;

        logger.LogInformation("Loading ConfiguracionHojasTimbraje for empresaId: {EmpresaId}", empresaId);

        ViewData["EmpresaId"] = empresaId;
        return Task.FromResult<IActionResult>(View());
    }

    // M�todo proxy para obtener datos de timbraje
    [HttpGet]
    public async Task<IActionResult> GetTimbraje(int empresaId)
    {
        logger.LogInformation("MVC Proxy: GetTimbraje for empresaId: {EmpresaId}", empresaId);

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionHojasTimbrajeApiController>(HttpContext, nameof(ConfiguracionHojasTimbrajeApiController.GetTimbraje), new { empresaId });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    // M�todo proxy para validar rango de folios
    [HttpPost]
    public async Task<IActionResult> Validar([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: Validar rango de folios");

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionHojasTimbrajeApiController>(HttpContext, nameof(ConfiguracionHojasTimbrajeApiController.Validar));
        var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }

    // M�todo proxy para actualizar �ltimo impreso
    [HttpPost]
    public async Task<IActionResult> Actualizar([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: Actualizar �ltimo impreso");

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionHojasTimbrajeApiController>(HttpContext, nameof(ConfiguracionHojasTimbrajeApiController.Actualizar));
        var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }
}