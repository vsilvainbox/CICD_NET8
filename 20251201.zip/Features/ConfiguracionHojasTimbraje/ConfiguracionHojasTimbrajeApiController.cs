using Microsoft.AspNetCore.Mvc;

namespace App.Features.ConfiguracionHojasTimbraje;

[ApiController]
[Route("[controller]/[action]")]
public class ConfiguracionHojasTimbrajeApiController(
    IConfiguracionHojasTimbrajeService service,
    ILogger<ConfiguracionHojasTimbrajeApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<TimbrajeDto>> GetTimbraje(int empresaId)
    {
        logger.LogInformation("API: GetTimbraje called with empresaId: {EmpresaId}", empresaId);

        {
            var timbraje = await service.GetTimbrajeAsync(empresaId);
            return Ok(timbraje);
        }
    }

    [HttpPost]
    public async Task<ActionResult<ValidationResult>> Validar([FromBody] ValidarRangoFoliosDto dto)
    {
        logger.LogInformation("API: Validar called");

        {
            var result = await service.ValidarRangoFoliosAsync(dto);
            return Ok(result);
        }
    }

    [HttpPost]
    public async Task<ActionResult<ValidationResult>> Actualizar([FromBody] ActualizarImpresoDto dto)
    {
        logger.LogInformation("API: Actualizar called");

        {
            var result = await service.ActualizarUltimoImpresoAsync(dto);
            return Ok(result);
        }
    }

    [HttpGet]
    public async Task<ActionResult<HojasTimbrajeDto>> GenerarHojas(
        int empresaId,
        [FromQuery] int desde,
        [FromQuery] int hasta,
        [FromQuery] string orientacion = "vertical")
    {
        logger.LogInformation("API: GenerarHojas called");

        {
            var hojas = await service.GenerarDatosHojasAsync(empresaId, desde, hasta, orientacion);
            return Ok(hojas);
        }
    }
}