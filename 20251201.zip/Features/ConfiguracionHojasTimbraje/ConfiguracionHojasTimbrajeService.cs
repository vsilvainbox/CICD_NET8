using App.Data;
using App.Exceptions;
using Microsoft.EntityFrameworkCore;

namespace App.Features.ConfiguracionHojasTimbraje;

public class ConfiguracionHojasTimbrajeService(
    LpContabContext context,
    ILogger<ConfiguracionHojasTimbrajeService> logger) : IConfiguracionHojasTimbrajeService
{
    public async Task<TimbrajeDto?> GetTimbrajeAsync(int empresaId)
    {
        logger.LogInformation("Getting timbraje for empresaId: {EmpresaId}", empresaId);

        {
            var timbraje = await context.Timbraje
                .FirstOrDefaultAsync(t => t.idEmpresa == empresaId);

            if (timbraje == null)
            {
                logger.LogWarning("No timbraje found for empresaId: {EmpresaId}", empresaId);
                return new TimbrajeDto { EmpresaId = empresaId, FolioDesde = 1 };
            }

            var dto = new TimbrajeDto
            {
                EmpresaId = empresaId,
                UltImpreso = timbraje.UltImpreso,
                FUltImpreso = timbraje.FUltImpreso,
                FUltImpresoDate = ConvertFromIntDate(timbraje.FUltImpreso),
                UltTimbrado = timbraje.UltTimbrado,
                FUltTimbrado = timbraje.FUltTimbrado,
                FUltTimbradoDate = ConvertFromIntDate(timbraje.FUltTimbrado),
                UltUsado = timbraje.UltUsado,
                FUltUsado = timbraje.FUltUsado,
                FUltUsadoDate = ConvertFromIntDate(timbraje.FUltUsado),
                FolioDesde = (timbraje.UltImpreso ?? 0) + 1
            };

            return dto;
        }
    }

    public async Task<ValidationResult> ValidarRangoFoliosAsync(ValidarRangoFoliosDto dto)
    {
        logger.LogInformation("Validating folio range for empresaId: {EmpresaId}, desde: {Desde}, hasta: {Hasta}",
            dto.EmpresaId, dto.Desde, dto.Hasta);

        {
            var timbraje = await context.Timbraje
                .FirstOrDefaultAsync(t => t.idEmpresa == dto.EmpresaId);
    
            // Validación: Hasta debe tener valor
            if (dto.Hasta <= 0)
            {
                return new ValidationResult
                {
                    IsValid = false,
                    ErrorMessage = "Debe ingresar el folio hasta el cual desea imprimir."
                };
            }

            // Validación: Desde no puede ser mayor que Hasta
            if (dto.Desde > dto.Hasta)
            {
                return new ValidationResult
                {
                    IsValid = false,
                    ErrorMessage = "Folio inicio no puede ser mayor al folio de término."
                };
            }

            if (timbraje != null)
            {
                // Error crítico: no puede reimprimir folios usados
                if (dto.Desde <= (timbraje.UltUsado ?? 0) || dto.Hasta <= (timbraje.UltUsado ?? 0))
                {
                    return new ValidationResult
                    {
                        IsValid = false,
                        ErrorMessage = "No puede volver a imprimir folio ya usados."
                    };
                }

                // Advertencia: reimprimir folios timbrados (pero permite continuar)
                if (dto.Desde <= (timbraje.UltTimbrado ?? 0) || dto.Hasta <= (timbraje.UltTimbrado ?? 0))
                {
                    return new ValidationResult
                    {
                        IsValid = true,
                        WarningMessage = "¡ATENCIÓN! Usted está indicando un número de folio menor o igual a un folio ya timbrado. ¿Está seguro de continuar?"
                    };
                }
            }

            return new ValidationResult { IsValid = true };
        }
    }

    public async Task<ValidationResult> ActualizarUltimoImpresoAsync(ActualizarImpresoDto dto)
    {
        logger.LogInformation("Updating ultimo impreso for empresaId: {EmpresaId}, ultImpreso: {UltImpreso}",
            dto.EmpresaId, dto.UltImpreso);

        if (!dto.ActualizarBD)
        {
            logger.LogInformation("Skip updating BD (ActualizarBD=false)");
            return new ValidationResult { IsValid = true };
        }

        {
            var timbraje = await context.Timbraje
                .FirstOrDefaultAsync(t => t.idEmpresa == dto.EmpresaId);

            if (timbraje == null)
            {
                // INSERT nuevo registro
                timbraje = new App.Data.Timbraje
                {
                    idEmpresa = dto.EmpresaId,
                    UltImpreso = dto.UltImpreso,
                    FUltImpreso = ConvertToIntDate(DateTime.Now)
                };
                context.Timbraje.Add(timbraje);
            }
            else
            {
                // UPDATE registro existente
                timbraje.UltImpreso = dto.UltImpreso;
                timbraje.FUltImpreso = ConvertToIntDate(DateTime.Now);
            }

            await context.SaveChangesAsync();

            logger.LogInformation("Successfully updated ultimo impreso for empresaId: {EmpresaId}", dto.EmpresaId);
            return new ValidationResult { IsValid = true };
        }
    }

    public async Task<HojasTimbrajeDto> GenerarDatosHojasAsync(int empresaId, int desde, int hasta, string orientacion)
    {
        logger.LogInformation("Generating hojas data for empresaId: {EmpresaId}, range: {Desde}-{Hasta}",
            empresaId, desde, hasta);

        {
            var empresa = await GetEmpresaTimbrajeAsync(empresaId);

            if (empresa == null)
            {
                throw new BusinessException($"Empresa {empresaId} no encontrada");
            }

            var hojas = new List<HojaFolioDto>();

            for (int i = desde; i <= hasta; i++)
            {
                hojas.Add(new HojaFolioDto
                {
                    Numero = i,
                    NumeroFormateado = i.ToString("D8")  // Formato 00000001
                });
            }

            return new HojasTimbrajeDto
            {
                Empresa = empresa,
                FolioDesde = desde,
                FolioHasta = hasta,
                Orientacion = orientacion,
                Hojas = hojas
            };
        }
    }

    public async Task<EmpresaTimbrajeDto?> GetEmpresaTimbrajeAsync(int empresaId)
    {
        logger.LogInformation("Getting empresa timbraje for empresaId: {EmpresaId}", empresaId);

        {
            // Nota: Empresa usa Id, no IdEmpresa
            var empresa = await context.Empresa
                .Where(e => e.Id == empresaId)
                .Select(e => new EmpresaTimbrajeDto
                {
                    Id = e.Id,
                    RazonSocial = e.RazonSocial ?? "",
                    Rut = e.Rut ?? "",
                    Direccion = (e.Calle ?? "") + (string.IsNullOrEmpty(e.Numero) ? "" : " " + e.Numero),
                    Ciudad = e.Ciudad,
                    Giro = e.Giro ?? "",
                    RepLegal1 = e.RepLegal1,
                    RutRepLegal1 = e.RutRepLegal1,
                    RepLegal2 = e.RepLegal2,
                    RutRepLegal2 = e.RutRepLegal2,
                    RepConjunta = e.RepConjunta == true
                })
                .FirstOrDefaultAsync();

            return empresa;
        }
    }

    private int ConvertToIntDate(DateTime date)
    {
        return (int)date.ToOADate();
    }

    private DateTime? ConvertFromIntDate(int? intDate)
    {
        if (!intDate.HasValue || intDate.Value == 0)
            return null;

        {
            return DateTime.FromOADate(intDate.Value);
        }
    }
}