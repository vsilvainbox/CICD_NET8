using Microsoft.AspNetCore.Mvc;

namespace App.Features.Ayuda;

/// <summary>
/// API Controller para el sistema de ayuda
/// Proporciona endpoints para obtener contenido de ayuda contextual
/// </summary>
[ApiController]
[Route("[controller]/[action]")]
public class AyudaApiController(IAyudaService service, ILogger<AyudaApiController> logger) : ControllerBase
{
    /// <summary>
    /// Obtiene contenido de ayuda para ajustes de aumentos
    /// </summary>
    /// <param name="contexto">Contexto desde donde se solicita la ayuda</param>
    /// <returns>Contenido de ayuda para ajustes de aumentos</returns>
    [HttpGet]
    public async Task<ActionResult<AyudaContentDto>> GetAjustesAumentos([FromQuery] string contexto = "")
    {
        logger.LogInformation("API: GetAjustesAumentos called with context: {Contexto}", contexto);

        {
            var content = await service.GetAjustesAumentosAsync(contexto);
            logger.LogInformation("API: Successfully retrieved ajustes aumentos content");
            return Ok(content);
        }
    }

    /// <summary>
    /// Obtiene contenido de ayuda para ajustes de disminuciones
    /// </summary>
    /// <param name="contexto">Contexto desde donde se solicita la ayuda</param>
    /// <returns>Contenido de ayuda para ajustes de disminuciones</returns>
    [HttpGet]
    public async Task<ActionResult<AyudaContentDto>> GetAjustesDisminuciones([FromQuery] string contexto = "")
    {
        logger.LogInformation("API: GetAjustesDisminuciones called with context: {Contexto}", contexto);

        {
            var content = await service.GetAjustesDisminucionesAsync(contexto);
            logger.LogInformation("API: Successfully retrieved ajustes disminuciones content");
            return Ok(content);
        }
    }

    /// <summary>
    /// Obtiene todos los tipos de ayuda disponibles
    /// </summary>
    /// <returns>Lista de tipos de ayuda disponibles</returns>
    [HttpGet]
    public async Task<ActionResult<IEnumerable<AyudaTipoDto>>> GetTiposAyuda()
    {
        logger.LogInformation("API: GetTiposAyuda called");

        {
            var tipos = await service.GetTiposAyudaAsync();
            logger.LogInformation("API: Successfully retrieved {Count} help types", tipos.Count());
            return Ok(tipos);
        }
    }

    /// <summary>
    /// Obtiene contenido de ayuda por tipo específico
    /// </summary>
    /// <param name="tipo">Tipo de ayuda (1=Aumentos, 2=Disminuciones)</param>
    /// <param name="contexto">Contexto desde donde se solicita</param>
    /// <returns>Contenido de ayuda correspondiente al tipo</returns>
    [HttpGet]
    public async Task<ActionResult<AyudaContentDto>> GetContenidoPorTipo(int tipo, [FromQuery] string contexto = "")
    {
        logger.LogInformation("API: GetContenidoPorTipo called with type: {Tipo}, context: {Contexto}", tipo, contexto);

        {
            if (!Enum.IsDefined(typeof(TipoAyuda), tipo))
            {
                logger.LogWarning("API: Invalid help type requested: {Tipo}", tipo);
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { $"Tipo de ayuda no válido: {tipo}" } });
            }

            var tipoAyuda = (TipoAyuda)tipo;
            var content = await service.GetContenidoPorTipoAsync(tipoAyuda, contexto);
                
            logger.LogInformation("API: Successfully retrieved content for help type: {TipoAyuda}", tipoAyuda);
            return Ok(content);
        }
    }

    /// <summary>
    /// Verifica si un tipo de ayuda existe
    /// </summary>
    /// <param name="tipo">Tipo de ayuda a verificar</param>
    /// <returns>True si el tipo existe, False en caso contrario</returns>
    [HttpGet]
    public async Task<ActionResult<bool>> ExisteTipoAyuda(int tipo)
    {
        logger.LogInformation("API: ExisteTipoAyuda called with type: {Tipo}", tipo);

        {
            if (!Enum.IsDefined(typeof(TipoAyuda), tipo))
            {
                logger.LogDebug("API: Help type {Tipo} does not exist", tipo);
                return Ok(false);
            }

            var tipoAyuda = (TipoAyuda)tipo;
            var existe = await service.ExisteTipoAyudaAsync(tipoAyuda);
                
            logger.LogDebug("API: Help type {Tipo} existence check result: {Existe}", tipo, existe);
            return Ok(existe);
        }
    }

    /// <summary>
    /// Endpoint de salud para verificar disponibilidad del servicio de ayuda
    /// </summary>
    /// <returns>Estado del servicio</returns>
    [HttpGet]
    public async Task<ActionResult<object>> Health()
    {
        logger.LogDebug("API: Health check called");

        {
            var tipos = await service.GetTiposAyudaAsync();
            var tiposCount = tipos.Count();
                
            var healthInfo = new
            {
                status = "healthy",
                service = "AyudaService",
                timestamp = DateTime.UtcNow,
                availableHelpTypes = tiposCount,
                version = "1.0.0"
            };

            logger.LogDebug("API: Health check completed successfully");
            return Ok(healthInfo);
        }
    }
}