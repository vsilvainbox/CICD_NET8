namespace App.Features.ConfiguracionActivoFijoIfrs;

public interface IConfiguracionActivoFijoIfrsService
{
    Task<ConfiguracionActivoFijoIfrsDto> GetConfiguracionAsync(int empresaId);
    Task<int> CreateGrupoAsync(CreateGrupoDto dto);
    Task<bool> UpdateGrupoAsync(UpdateGrupoDto dto);
    Task<bool> DeleteGrupoAsync(int idGrupo, int empresaId);
    Task<int> CreateComponenteAsync(CreateComponenteDto dto);
    Task<bool> UpdateComponenteAsync(UpdateComponenteDto dto);
    Task<bool> DeleteComponenteAsync(int idComp, int empresaId);
}
