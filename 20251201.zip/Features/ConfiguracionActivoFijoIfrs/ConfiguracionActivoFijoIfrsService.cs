using Microsoft.EntityFrameworkCore;
using App.Data;
using App.Exceptions;

namespace App.Features.ConfiguracionActivoFijoIfrs;

public class ConfiguracionActivoFijoIfrsService(
    LpContabContext context,
    ILogger<ConfiguracionActivoFijoIfrsService> logger) : IConfiguracionActivoFijoIfrsService
{
    public async Task<ConfiguracionActivoFijoIfrsDto> GetConfiguracionAsync(int empresaId)
    {
        logger.LogInformation("Getting configuración IFRS for empresa {EmpresaId}", empresaId);

        var grupos = await context.AFGrupos
            .Where(g => g.IdEmpresa == empresaId)
            .OrderBy(g => g.NombGrupo)
            .ToListAsync();

        var dto = new ConfiguracionActivoFijoIfrsDto
        {
            EmpresaId = empresaId,
            Grupos = new List<GrupoIfrsDto>()
        };

        foreach (var grupo in grupos)
        {
            // Contar activos del grupo
            var cantActivos = await context.ActFijoFicha
                .Where(f => f.IdGrupo == grupo.IdGrupo && f.IdEmpresa == empresaId)
                .CountAsync();

            // Cargar componentes
            var componentes = await context.AFComponentes
                .Where(c => c.IdGrupo == grupo.IdGrupo && c.IdEmpresa == empresaId)
                .OrderBy(c => c.NombComp)
                .ToListAsync();

            var componentesDto = new List<ComponenteIfrsDto>();
            foreach (var comp in componentes)
            {
                // Contar activos del componente
                var cantActivosComp = await context.ActFijoCompsFicha
                    .Where(f => f.IdComp == comp.IdComp && f.IdEmpresa == empresaId)
                    .CountAsync();

                componentesDto.Add(new ComponenteIfrsDto
                {
                    IdComp = comp.IdComp,
                    IdEmpresa = comp.IdEmpresa ?? empresaId,
                    IdGrupo = comp.IdGrupo ?? grupo.IdGrupo,
                    NombComp = comp.NombComp,
                    CantidadActivos = cantActivosComp
                });
            }

            dto.Grupos.Add(new GrupoIfrsDto
            {
                IdGrupo = grupo.IdGrupo,
                IdEmpresa = grupo.IdEmpresa ?? empresaId,
                NombGrupo = grupo.NombGrupo,
                CantidadActivos = cantActivos,
                Componentes = componentesDto
            });
        }

        return dto;
    }

    public async Task<int> CreateGrupoAsync(CreateGrupoDto dto)
    {
        logger.LogInformation("Creating grupo IFRS: {Nombre}", dto.NombGrupo);

        {
            var maxId = await context.AFGrupos
                .Where(g => g.IdEmpresa == dto.EmpresaId)
                .MaxAsync(g => (int?)g.IdGrupo) ?? 0;

            var nuevoGrupo = new AFGrupos
            {
                IdGrupo = maxId + 1,
                IdEmpresa = dto.EmpresaId,
                NombGrupo = dto.NombGrupo
            };

            context.AFGrupos.Add(nuevoGrupo);
            await context.SaveChangesAsync();

            logger.LogInformation("Grupo created with ID {IdGrupo}", nuevoGrupo.IdGrupo);
            return nuevoGrupo.IdGrupo;
        }
    }

    public async Task<bool> UpdateGrupoAsync(UpdateGrupoDto dto)
    {
        logger.LogInformation("Updating grupo {IdGrupo}", dto.IdGrupo);

        {
            var grupo = await context.AFGrupos
                .FirstOrDefaultAsync(g => g.IdGrupo == dto.IdGrupo && g.IdEmpresa == dto.EmpresaId);

            if (grupo == null)
            {
                logger.LogWarning("Grupo {IdGrupo} not found", dto.IdGrupo);
                throw new BusinessException("Grupo no encontrado");
            }

            grupo.NombGrupo = dto.NombGrupo;
            await context.SaveChangesAsync();

            logger.LogInformation("Grupo {IdGrupo} updated successfully", dto.IdGrupo);
            return true;
        }
    }

    public async Task<bool> DeleteGrupoAsync(int idGrupo, int empresaId)
    {
        logger.LogInformation("Deleting grupo {IdGrupo}", idGrupo);

        {
            // Validar que no tenga activos
            var cantActivos = await context.ActFijoFicha
                .Where(f => f.IdGrupo == idGrupo && f.IdEmpresa == empresaId)
                .CountAsync();

            if (cantActivos > 0)
            {
                logger.LogWarning("Cannot delete grupo {IdGrupo}: has {Count} activos", idGrupo, cantActivos);
                throw new BusinessException($"No es posible eliminar este Grupo. Hay {cantActivos} Activos Fijos que pertenecen a éste.");
            }

            // Eliminar grupo (cascada eliminará componentes)
            var grupo = await context.AFGrupos
                .FirstOrDefaultAsync(g => g.IdGrupo == idGrupo && g.IdEmpresa == empresaId);

            if (grupo == null)
            {
                logger.LogWarning("Grupo {IdGrupo} not found", idGrupo);
                throw new BusinessException("Grupo no encontrado");
            }

            context.AFGrupos.Remove(grupo);
            await context.SaveChangesAsync();

            logger.LogInformation("Grupo {IdGrupo} deleted successfully", idGrupo);
            return true;
        }
    }

    public async Task<int> CreateComponenteAsync(CreateComponenteDto dto)
    {
        logger.LogInformation("Creating componente IFRS: {Nombre}", dto.NombComp);

        {
            var maxId = await context.AFComponentes
                .Where(c => c.IdEmpresa == dto.EmpresaId)
                .MaxAsync(c => (int?)c.IdComp) ?? 0;

            var nuevoComponente = new AFComponentes
            {
                IdComp = maxId + 1,
                IdEmpresa = dto.EmpresaId,
                IdGrupo = dto.IdGrupo,
                NombComp = dto.NombComp
            };

            context.AFComponentes.Add(nuevoComponente);
            await context.SaveChangesAsync();

            logger.LogInformation("Componente created with ID {IdComp}", nuevoComponente.IdComp);
            return nuevoComponente.IdComp;
        }
    }

    public async Task<bool> UpdateComponenteAsync(UpdateComponenteDto dto)
    {
        logger.LogInformation("Updating componente {IdComp}", dto.IdComp);

        {
            var componente = await context.AFComponentes
                .FirstOrDefaultAsync(c => c.IdComp == dto.IdComp && c.IdEmpresa == dto.EmpresaId);

            if (componente == null)
            {
                logger.LogWarning("Componente {IdComp} not found", dto.IdComp);
                throw new BusinessException("Componente no encontrado");
            }

            componente.NombComp = dto.NombComp;
            await context.SaveChangesAsync();

            logger.LogInformation("Componente {IdComp} updated successfully", dto.IdComp);
            return true;
        }
    }

    public async Task<bool> DeleteComponenteAsync(int idComp, int empresaId)
    {
        logger.LogInformation("Deleting componente {IdComp}", idComp);

        {
            // Contar activos que usan este componente
            var cantActivos = await context.ActFijoCompsFicha
                .Where(f => f.IdComp == idComp && f.IdEmpresa == empresaId)
                .CountAsync();

            var componente = await context.AFComponentes
                .FirstOrDefaultAsync(c => c.IdComp == idComp && c.IdEmpresa == empresaId);

            if (componente == null)
            {
                logger.LogWarning("Componente {IdComp} not found", idComp);
                throw new BusinessException("Componente no encontrado");
            }

            // Eliminar componente y sus fichas
            context.AFComponentes.Remove(componente);

            // Eliminar fichas asociadas
            var fichas = await context.ActFijoCompsFicha
                .Where(f => f.IdComp == idComp && f.IdEmpresa == empresaId)
                .ToListAsync();

            context.ActFijoCompsFicha.RemoveRange(fichas);

            await context.SaveChangesAsync();

            logger.LogInformation("Componente {IdComp} deleted successfully (removed {Count} fichas)", idComp, fichas.Count);
            return true;
        }
    }
}
