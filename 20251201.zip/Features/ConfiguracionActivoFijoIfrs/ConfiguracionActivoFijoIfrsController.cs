using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Extensions;
using App.Helpers;

namespace App.Features.ConfiguracionActivoFijoIfrs;

public class ConfiguracionActivoFijoIfrsController(
    IHttpClientFactory httpClientFactory,
    ILogger<ConfiguracionActivoFijoIfrsController> logger,
    LinkGenerator linkGenerator) : Controller
{
    public IActionResult Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Configuración Activo Fijo IFRS";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        logger.LogInformation("ConfiguracionActivoFijoIfrs index accessed");
        int empresaId = SessionHelper.EmpresaId;
        ViewBag.EmpresaId = empresaId;
        return View();
    }

    // ===== M�TODOS PROXY PARA API =====

    [HttpGet]
    public async Task<IActionResult> GetConfig(int empresaId)
    {
        logger.LogInformation("Proxy: GetConfig - empresaId: {EmpresaId}", empresaId);

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionActivoFijoIfrsApiController>(HttpContext, nameof(ConfiguracionActivoFijoIfrsApiController.Get), new { empresaId });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    [HttpDelete]
    public async Task<IActionResult> DeleteGrupo(int id, int empresaId)
    {
        logger.LogInformation("Proxy: DeleteGrupo - id: {Id}, empresaId: {EmpresaId}", id, empresaId);

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionActivoFijoIfrsApiController>(HttpContext, nameof(ConfiguracionActivoFijoIfrsApiController.DeleteGrupo), new { idGrupo = id, empresaId });
        var (statusCode, content) = await client.ProxyRequestAsync(url!, null, HttpMethod.Delete);
        return StatusCode(statusCode, content);
    }

    [HttpPost]
    public async Task<IActionResult> CreateGrupo([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: CreateGrupo");

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionActivoFijoIfrsApiController>(HttpContext, nameof(ConfiguracionActivoFijoIfrsApiController.CreateGrupo), null);
        var (statusCode, content) = await client.ProxyRequestAsync(
            url!,
            request,
            HttpMethod.Post);
        return StatusCode(statusCode, content);
    }

    [HttpPut]
    public async Task<IActionResult> UpdateGrupo([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: UpdateGrupo");

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionActivoFijoIfrsApiController>(HttpContext, nameof(ConfiguracionActivoFijoIfrsApiController.UpdateGrupo), null);
        var (statusCode, content) = await client.ProxyRequestAsync(
            url!,
            request,
            HttpMethod.Put);
        return StatusCode(statusCode, content);
    }

    [HttpDelete]
    public async Task<IActionResult> DeleteComponente(int id, int empresaId)
    {
        logger.LogInformation("Proxy: DeleteComponente - id: {Id}, empresaId: {EmpresaId}", id, empresaId);

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionActivoFijoIfrsApiController>(HttpContext, nameof(ConfiguracionActivoFijoIfrsApiController.DeleteComponente), new { idComp = id, empresaId });
        var (statusCode, content) = await client.ProxyRequestAsync(url!, null, HttpMethod.Delete);
        return StatusCode(statusCode, content);
    }

    [HttpPost]
    public async Task<IActionResult> CreateComponente([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: CreateComponente");

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionActivoFijoIfrsApiController>(HttpContext, nameof(ConfiguracionActivoFijoIfrsApiController.CreateComponente), null);
        var (statusCode, content) = await client.ProxyRequestAsync(
            url!,
            request,
            HttpMethod.Post);
        return StatusCode(statusCode, content);
    }

    [HttpPut]
    public async Task<IActionResult> UpdateComponente([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: UpdateComponente");

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionActivoFijoIfrsApiController>(HttpContext, nameof(ConfiguracionActivoFijoIfrsApiController.UpdateComponente), null);
        var (statusCode, content) = await client.ProxyRequestAsync(
            url!,
            request,
            HttpMethod.Put);
        return StatusCode(statusCode, content);
    }
}