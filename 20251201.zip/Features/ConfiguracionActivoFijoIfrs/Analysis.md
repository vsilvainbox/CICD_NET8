# Legacy Analysis: Configuración Activo Fijo IFRS

## 📄 VB6: FrmConfigActFijoIFRS.frm
**Propósito:** Configuración jerárquica de Grupos y Componentes para Activos Fijos Financieros (IFRS)

### Estructura
- **Grupos** (`AFGrupos`): Categorías de activos fijos
- **Componentes** (`AFComponentes`): Items dentro de cada grupo

### Operaciones Grupos
- **Nuevo**: FrmGrupo.FNew() → INSERT AFGrupos
- **Editar**: FrmGrupo.FEdit() → UPDATE AFGrupos
- **Eliminar**: DELETE AFGrupos (valida no tenga activos en `ActFijoFicha`)

### Operaciones Componentes
- **Nuevo**: FrmComponente.FNew() → INSERT AFComponentes
- **Editar**: FrmComponente.FEdit() → UPDATE AFComponentes
- **Eliminar**: DELETE AFComponentes + ActFijoCompsFicha (valida referencias)

### Validaciones
- No eliminar grupo si tiene activos (`ActFijoFicha.IdGrupo`)
- Advertencia al eliminar componente si tiene activos (`ActFijoCompsFicha.IdComp`)
- Debe seleccionar grupo antes de agregar componente

**Entidades:** `AFGrupos`, `AFComponentes`, `ActFijoFicha`, `ActFijoCompsFicha`
**Modales:** `FrmGrupo.frm`, `FrmComponente.frm` (dialogs para nombre)


## 📄 VB6: FrmConfigActFijoIFRS.frm
**Propósito:** Configuración jerárquica de Grupos y Componentes para Activos Fijos Financieros (IFRS)

### Estructura
- **Grupos** (`AFGrupos`): Categorías de activos fijos
- **Componentes** (`AFComponentes`): Items dentro de cada grupo

### Operaciones Grupos
- **Nuevo**: FrmGrupo.FNew() → INSERT AFGrupos
- **Editar**: FrmGrupo.FEdit() → UPDATE AFGrupos
- **Eliminar**: DELETE AFGrupos (valida no tenga activos en `ActFijoFicha`)

### Operaciones Componentes
- **Nuevo**: FrmComponente.FNew() → INSERT AFComponentes
- **Editar**: FrmComponente.FEdit() → UPDATE AFComponentes
- **Eliminar**: DELETE AFComponentes + ActFijoCompsFicha (valida referencias)

### Validaciones
- No eliminar grupo si tiene activos (`ActFijoFicha.IdGrupo`)
- Advertencia al eliminar componente si tiene activos (`ActFijoCompsFicha.IdComp`)
- Debe seleccionar grupo antes de agregar componente

**Entidades:** `AFGrupos`, `AFComponentes`, `ActFijoFicha`, `ActFijoCompsFicha`
**Modales:** `FrmGrupo.frm`, `FrmComponente.frm` (dialogs para nombre)

