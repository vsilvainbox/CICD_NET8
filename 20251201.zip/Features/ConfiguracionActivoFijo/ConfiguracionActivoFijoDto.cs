namespace App.Features.ConfiguracionActivoFijo;

/// <summary>
/// DTO para la configuración de Activo Fijo
/// </summary>
public class ConfiguracionActivoFijoDto
{
    /// <summary>
    /// Indica si se debe considerar mes completo independiente de fecha inicio utilización
    /// </summary>
    public bool AFMesCompleto { get; set; }
}

/// <summary>
/// DTO para guardar la configuración
/// </summary>
public class SaveConfiguracionActivoFijoDto
{
    public int IdEmpresa { get; set; }
    public short Ano { get; set; }
    public bool AFMesCompleto { get; set; }
}

