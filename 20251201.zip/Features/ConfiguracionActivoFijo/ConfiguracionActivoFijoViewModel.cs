using System.ComponentModel.DataAnnotations;

namespace App.Features.ConfiguracionActivoFijo;

/// <summary>
/// ViewModel para la vista de configuración de Activo Fijo
/// </summary>
public class ConfiguracionActivoFijoViewModel
{
    /// <summary>
    /// ID de la empresa (usado para el formulario)
    /// </summary>
    [Required]
    public int IdEmpresa { get; set; }

    /// <summary>
    /// Año fiscal (usado para el formulario)
    /// </summary>
    [Required]
    public short Ano { get; set; }

    /// <summary>
    /// Indica si se debe considerar mes completo independiente de fecha inicio utilización
    /// </summary>
    [Display(Name = "Considerar Mes Completo")]
    public bool AFMesCompleto { get; set; }
}
