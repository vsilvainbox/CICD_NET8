using App.Data;
using App.Exceptions;
using Microsoft.EntityFrameworkCore;

namespace App.Features.ConfiguracionActivoFijo;

/// <summary>
/// Servicio para gestión de configuración de Activo Fijo
/// </summary>
public class ConfiguracionActivoFijoService(
    LpContabContext context,
    ILogger<ConfiguracionActivoFijoService> logger) : IConfiguracionActivoFijoService
{
    public async Task<ConfiguracionActivoFijoDto> GetConfiguracionAsync(int empresaId, short ano)
    {
        logger.LogInformation("Getting AF configuration for empresa {EmpresaId}, ano {Ano}", empresaId, ano);

        var param = await context.ParamEmpresa
            .FirstOrDefaultAsync(p => 
                p.IdEmpresa == empresaId && 
                p.Ano == ano && 
                p.Tipo == "AFMESCOMPT");

        var afMesCompleto = false;
        if (param != null && !string.IsNullOrEmpty(param.Valor))
        {
            // El valor se almacena como string "0" o "1"
            afMesCompleto = param.Valor == "1" || param.Valor.ToLower() == "true";
        }

        return new ConfiguracionActivoFijoDto
        {
            AFMesCompleto = afMesCompleto
        };
    }

    public async Task SaveConfiguracionAsync(SaveConfiguracionActivoFijoDto dto)
    {
        logger.LogInformation("Saving AF configuration for empresa {EmpresaId}, ano {Ano}", dto.IdEmpresa, dto.Ano);

        var param = await context.ParamEmpresa
            .FirstOrDefaultAsync(p => 
                p.IdEmpresa == dto.IdEmpresa && 
                p.Ano == dto.Ano && 
                p.Tipo == "AFMESCOMPT");

        var valorString = dto.AFMesCompleto ? "1" : "0";

        if (param != null)
        {
            // Actualizar registro existente
            param.Codigo = 0;
            param.Valor = valorString;
            context.ParamEmpresa.Update(param);
        }
        else
        {
            // Insertar nuevo registro
            var newParam = new App.Data.ParamEmpresa
            {
                IdEmpresa = dto.IdEmpresa,
                Ano = dto.Ano,
                Tipo = "AFMESCOMPT",
                Codigo = 0,
                Valor = valorString
            };
            await context.ParamEmpresa.AddAsync(newParam);
        }

        await context.SaveChangesAsync();
        logger.LogInformation("AF configuration saved successfully");
    }
}

