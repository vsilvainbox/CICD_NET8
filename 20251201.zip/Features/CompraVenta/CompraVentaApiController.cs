using Microsoft.AspNetCore.Mvc;

namespace App.Features.CompraVenta;

[ApiController]
[Route("[controller]/[action]")]
public class CompraVentaApiController(
    ICompraVentaService service,
    ILogger<CompraVentaApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IEnumerable<CompraVentaDto>>> GetAll(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        [FromQuery] byte? tipoLib = null,
        [FromQuery] int? mes = null)
    {
        logger.LogInformation("API: GetAll called with empresaId: {EmpresaId}, año: {Ano}, tipoLib: {TipoLib}, mes: {Mes}", 
            empresaId, ano, tipoLib, mes);
        
        {
            var documentos = await service.GetAllAsync(empresaId, ano, tipoLib, mes);
            logger.LogInformation("API: Returning {Count} documents", documentos.Count());
            return Ok(documentos);
        }
    }

    [HttpGet]
    public async Task<ActionResult<CompraVentaDto>> GetById(int id)
    {
        logger.LogInformation("API: GetById called with id: {Id}", id);
        
        {
            var documento = await service.GetByIdAsync(id);
            if (documento == null)
            {
                logger.LogWarning("API: Document {Id} not found", id);
                return NotFound(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "Documento no encontrado" } });
            }
            
            return Ok(documento);
        }
    }

    [HttpPost]
    public async Task<ActionResult<CompraVentaDto>> Create([FromBody] CompraVentaCreateDto dto)
    {
        logger.LogInformation("API: Create called for empresaId: {EmpresaId}, tipoDoc: {TipoDoc}", 
            dto.IdEmpresa, dto.TipoDoc);
        
        {
            var result = await service.CreateAsync(dto);
            if (result != null)
            {
                logger.LogInformation("API: Document created successfully with id: {Id}", result.IdDoc);
                return CreatedAtAction(nameof(GetById), new { id = result.IdDoc }, result);
            }

            logger.LogWarning("API: Failed to create document");
            return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "Error al crear el documento" } });
        }
    }

    [HttpPut]
    public async Task<ActionResult<CompraVentaDto>> Update(int id, [FromBody] CompraVentaUpdateDto dto)
    {
        logger.LogInformation("API: Update called for id: {Id}", id);
        
        {
            dto.IdDoc = id;  // Asegurar que el ID coincida
            var result = await service.UpdateAsync(dto);
            if (result != null)
            {
                logger.LogInformation("API: Document {Id} updated successfully", id);
                return Ok(result);
            }

            logger.LogWarning("API: Document {Id} not found for update", id);
            return NotFound(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "Documento no encontrado" } });
        }
    }

    [HttpDelete]
    public async Task<ActionResult<bool>> Delete(int id)
    {
        logger.LogInformation("API: Delete called for id: {Id}", id);
        
        {
            var result = await service.DeleteAsync(id);
            if (result)
            {
                logger.LogInformation("API: Document {Id} deleted successfully", id);
                return Ok(new { success = true, message = "Documento eliminado exitosamente" });
            }

            logger.LogWarning("API: Document {Id} not found for deletion", id);
            return NotFound(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "Documento no encontrado" } });
        }
    }

    [HttpGet]
    public ActionResult<IEnumerable<TipoDocumentoInfo>> GetTiposDocumento()
    {
        logger.LogInformation("API: GetTiposDocumento called");
        
        {
            var tipos = service.GetTiposDocumento();
            return Ok(tipos);
        }
    }

    [HttpPost]
    public Task<IActionResult> Centralizar(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        [FromQuery] byte tipoLib,
        [FromQuery] int mes)
    {
        logger.LogInformation("API: Centralizar called - empresaId: {EmpresaId}, ano: {Ano}, tipoLib: {TipoLib}, mes: {Mes}",
            empresaId, ano, tipoLib, mes);

        {
            // TODO: Implement centralization functionality
            return Task.FromResult<IActionResult>(StatusCode(501, new { swalType = "warning", swalTitle = "Atención", errors = new[] { "Funcionalidad de centralización no implementada aún" } }));
        }
    }

    [HttpGet]
    public async Task<IActionResult> Exportar(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        [FromQuery] byte tipoLib,
        [FromQuery] int mes)
    {
        logger.LogInformation(
            "API: Exportar called - empresaId: {EmpresaId}, ano: {Ano}, tipoLib: {TipoLib}, mes: {Mes}",
            empresaId, ano, tipoLib, mes);

        // Validate tipoLib (1=Compras, 2=Ventas)
        if (tipoLib != 1 && tipoLib != 2)
        {
            logger.LogWarning("API: Invalid tipoLib value: {TipoLib}. Must be 1 (Compras) or 2 (Ventas)", tipoLib);
            return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "Tipo de libro inválido. Debe ser 1 (Compras) o 2 (Ventas)." } });
        }

        {
            var excelBytes = await service.ExportToExcelAsync(empresaId, ano, tipoLib, mes);
            var fileName = $"LibroCompraVenta_{tipoLib}_{ano}_{mes:D2}.xlsx";

            logger.LogInformation("API: Excel generado exitosamente - {FileName}", fileName);
            return File(excelBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
        }
    }
}
