﻿# Análisis de Migración: FrmCompraVenta.frm

## 1. Análisis del Formulario VB6

### Propósito
Gestión integral de transacciones de compra y venta - permite registrar, modificar, eliminar y consultar todas las operaciones comerciales de la empresa con cálculo automático de impuestos y generación de asientos contables.

### Controles Principales Identificados

#### Información de Documento
- **cmbTipoDocumento**: ComboBox con tipos de documento (Factura, Boleta, NC, ND, etc.)
- **txtNumeroDocumento**: Número del documento
- **dtpFechaDocumento**: Fecha del documento
- **dtpFechaVencimiento**: Fecha de vencimiento
- **cmbMoneda**: Moneda (CLP, USD, EUR, UF)
- **txtTipoCambio**: Tipo de cambio para monedas extranjeras

#### Datos del Cliente/Proveedor
- **cmbEntidad**: ComboBox con clientes/proveedores
- **txtRutEntidad**: RUT de la entidad
- **txtRazonSocial**: Razón social
- **txtDireccion**: Dirección
- **txtTelefono**: Teléfono
- **txtEmail**: Email
- **cmbCondicionPago**: Condiciones de pago

#### Detalle de Productos/Servicios
- **grdDetalle**: Grilla con líneas del documento
  - Columnas: Código, Descripción, Cantidad, Precio Unitario, Descuento, Subtotal, IVA, Total
- **txtCodigoProducto**: Código del producto/servicio
- **txtDescripcionProducto**: Descripción
- **txtCantidad**: Cantidad
- **txtPrecioUnitario**: Precio unitario
- **txtDescuento**: Porcentaje de descuento
- **cmbImpuesto**: Tipo de impuesto (IVA, Exento, etc.)

#### Totales y Cálculos
- **txtSubtotal**: Subtotal antes de impuestos
- **txtDescuentoGlobal**: Descuento global al documento
- **txtIVA**: Total IVA
- **txtOtrosImpuestos**: Otros impuestos aplicables
- **txtTotal**: Total del documento
- **txtRetencion**: Retenciones aplicadas

#### Información Contable
- **cmbCuentaContable**: Cuenta contable principal
- **txtGlosa**: Glosa contable
- **cmbCentroCosto**: Centro de costo
- **txtProyecto**: Proyecto asociado

#### Controles de Acción
- **cmdNuevo**: Nuevo documento
- **cmdGrabar**: Guardar documento
- **cmdModificar**: Modificar documento
- **cmdEliminar**: Eliminar documento
- **cmdImprimir**: Imprimir documento
- **cmdEmail**: Enviar por email
- **cmdContabilizar**: Generar asiento contable

### Funcionalidades Identificadas

#### 1. Gestión de Documentos
- **Crear**: Nuevo documento con cálculo automático de totales
- **Leer**: Visualización con filtros y búsquedas
- **Actualizar**: Modificación de documentos no contabilizados
- **Eliminar**: Anulación lógica con trazabilidad

#### 2. Cálculos Automáticos
- Cálculo de subtotales por línea
- Aplicación de descuentos por línea y globales
- Cálculo automático de IVA y otros impuestos
- Conversión de monedas con tipo de cambio
- Validación de totales

#### 3. Validaciones de Negocio
- Verificación de stock disponible (para ventas)
- Validación de límites de crédito
- Verificación de precios según lista vigente
- Control de fechas (no futuras, período contable abierto)
- Validación de RUT y datos de entidades

#### 4. Integración Contable
- Generación automática de asientos contables
- Distribución por centros de costo
- Manejo de cuentas por pagar/cobrar
- Actualización de saldos de entidades

#### 5. Reportes y Documentos
- Impresión de facturas y documentos
- Envío por email en PDF
- Reportes de ventas y compras
- Listados por período y entidad

### Eventos Principales

#### Form_Load
```vb
- Inicializar controles y combos
- Cargar configuración de empresa
- Establecer permisos de usuario
- Configurar grilla de detalle
```

#### cmbTipoDocumento_Change
```vb
- Configurar numeración automática
- Establecer cuentas contables por defecto
- Definir comportamiento según tipo
- Habilitar/deshabilitar campos específicos
```

#### cmbEntidad_Change
```vb
- Cargar datos completos de la entidad
- Establecer condiciones de pago
- Verificar límite de crédito
- Cargar lista de precios aplicable
```

#### grdDetalle_AfterUpdate
```vb
- Recalcular totales de la línea
- Aplicar descuentos y impuestos
- Verificar stock disponible
- Actualizar totales del documento
```

#### cmdGrabar_Click
```vb
- Validar datos obligatorios
- Verificar integridad de cálculos
- Grabar en base de datos
- Actualizar numeración
- Generar asiento contable opcional
```

### Estructura de Datos

#### Tabla Principal: Documento
```sql
CREATE TABLE Documento (
    DocId INT IDENTITY(1,1) PRIMARY KEY,
    EmpId INT NOT NULL,
    DocTipo NVARCHAR(10) NOT NULL,
    DocNumero NVARCHAR(20) NOT NULL,
    DocFecha DATETIME NOT NULL,
    DocFechaVencimiento DATETIME,
    EntId INT NOT NULL,
    DocMoneda NVARCHAR(3) DEFAULT 'CLP',
    DocTipoCambio DECIMAL(10,4) DEFAULT 1,
    DocSubtotal DECIMAL(18,2) NOT NULL,
    DocDescuentoGlobal DECIMAL(18,2) DEFAULT 0,
    DocIVA DECIMAL(18,2) NOT NULL,
    DocOtrosImpuestos DECIMAL(18,2) DEFAULT 0,
    DocTotal DECIMAL(18,2) NOT NULL,
    DocEstado NVARCHAR(20) DEFAULT 'Pendiente',
    DocGlosa NVARCHAR(200),
    DocObservaciones NVARCHAR(500),
    DocContabilizado BIT DEFAULT 0,
    DocFechaContabilizacion DATETIME,
    DocAsientoId INT,
    DocFechaCreacion DATETIME DEFAULT GETDATE(),
    DocUsuarioCreacion NVARCHAR(50),
    DocActivo BIT DEFAULT 1
)
```

#### Tabla Detalle: DocumentoDetalle
```sql
CREATE TABLE DocumentoDetalle (
    DetId INT IDENTITY(1,1) PRIMARY KEY,
    DocId INT NOT NULL,
    DetLinea INT NOT NULL,
    ProdId INT,
    DetCodigo NVARCHAR(20),
    DetDescripcion NVARCHAR(100) NOT NULL,
    DetCantidad DECIMAL(10,2) NOT NULL,
    DetPrecioUnitario DECIMAL(18,2) NOT NULL,
    DetDescuento DECIMAL(5,2) DEFAULT 0,
    DetSubtotal DECIMAL(18,2) NOT NULL,
    DetIVA DECIMAL(18,2) NOT NULL,
    DetTotal DECIMAL(18,2) NOT NULL,
    DetObservaciones NVARCHAR(200)
)
```

## 2. Plan de Migración a ASP.NET Core MVC

### Arquitectura Propuesta

#### Models
- **DocumentoDto**: Transferencia de datos del documento principal
- **DocumentoDetalleDto**: Líneas de detalle del documento
- **DocumentoViewModel**: Vista completa con cálculos
- **DocumentoCreateModel**: Creación de documentos
- **DocumentoEditModel**: Edición de documentos
- **DocumentoSearchModel**: Filtros de búsqueda

#### Controller
- **CompraVentaController**: Controlador principal
- Acciones: Index, Create, Edit, Delete, Print, Email, Contabilizar

#### Views
- **Index.cshtml**: Lista de documentos con filtros
- **Create.cshtml**: Formulario de creación
- **Edit.cshtml**: Formulario de edición
- **_DocumentoDetalle.cshtml**: Partial para líneas de detalle

### Funcionalidades a Implementar

#### 1. Master-Detail Interface
- Formulario principal con datos del documento
- Grilla editable para líneas de detalle
- Cálculos automáticos en tiempo real
- Validaciones client/server-side

#### 2. Cálculos Dinámicos
- Recálculo automático al cambiar cantidades/precios
- Aplicación de descuentos por línea y globales
- Cálculo de impuestos según configuración
- Conversión de monedas automática

#### 3. Validaciones Avanzadas
- Verificación de stock en tiempo real
- Validación de límites de crédito
- Control de períodos contables
- Validación de RUT chileno

#### 4. Integración
- Búsqueda de productos con autocompletado
- Gestión de entidades (clientes/proveedores)
- Generación de asientos contables
- Actualización de inventarios

#### 5. Documentos y Reportes
- Generación de PDF para impresión
- Envío por email automático
- Reportes de ventas/compras
- Dashboard con métricas

### Consideraciones Técnicas

#### Performance
- Paginación server-side para grandes volúmenes
- Caché para entidades y productos frecuentes
- Índices optimizados en base de datos
- Validaciones asíncronas

#### UX/UI
- Interface responsive adaptable
- Autocompletado para búsquedas
- Validación en tiempo real
- Feedback visual de operaciones
- Shortcuts de teclado para productividad

#### Seguridad
- Validación exhaustiva de datos
- Autorización por roles y permisos
- Auditoria completa de transacciones
- Prevención de ataques comunes

### Cronograma de Implementación

1. **Fase 1**: Models y servicios base (4 horas)
2. **Fase 2**: Controller y APIs (4 horas)
3. **Fase 3**: Views y UI principal (6 horas)
4. **Fase 4**: Cálculos y validaciones (4 horas)
5. **Fase 5**: Reportes y documentos (3 horas)
6. **Fase 6**: Testing e integración (3 horas)

**Total estimado**: 24 horas de desarrollo

### Riesgos y Mitigaciones

#### Riesgos
- Complejidad de cálculos automáticos
- Performance con grandes volúmenes de datos
- Integración con sistema contable existente
- Migración de datos históricos

#### Mitigaciones
- Testing exhaustivo de cálculos
- Optimización de queries y caché
- APIs bien definidas para integración
- Scripts de migración incremental
- Validación con usuarios finales

## 3. Especificaciones de Implementación

### Endpoints API
```
GET  /CompraVenta                    - Lista de documentos
POST /CompraVenta/Create             - Crear documento
GET  /CompraVenta/Edit/{id}          - Obtener para edición
POST /CompraVenta/Edit/{id}          - Guardar edición
POST /CompraVenta/Delete/{id}        - Anular documento
POST /CompraVenta/Contabilizar/{id}  - Generar asiento
GET  /CompraVenta/Print/{id}         - Imprimir documento
POST /CompraVenta/Email/{id}         - Enviar por email
```

### Estados de Documento
- **Borrador**: Documento en construcción
- **Pendiente**: Documento grabado, no contabilizado
- **Contabilizado**: Documento con asiento generado
- **Anulado**: Documento anulado (no eliminar físicamente)
- **Pagado**: Documento completamente pagado

### Reglas de Negocio
1. Numeración automática por tipo de documento
2. Validación de stock para documentos de venta
3. Cálculo automático de impuestos según configuración
4. Control de límites de crédito para clientes
5. Solo documentos no contabilizados pueden modificarse
6. Anulación requiere permisos especiales
7. Fechas no pueden ser futuras ni de períodos cerrados
8. Tipo de cambio obligatorio para monedas extranjeras

### Casos de Prueba Críticos
1. Creación de factura con múltiples líneas
2. Aplicación de descuentos por línea y globales
3. Cálculo correcto de IVA y otros impuestos
4. Validación de stock insuficiente
5. Conversión de monedas extranjeras
6. Generación de asiento contable
7. Anulación de documento contabilizado
8. Validación de límite de crédito excedido
9. Carga masiva de productos desde Excel
10. Impresión y envío por emailalysis: Compra Venta

## ðŸ“„ InformaciÃ³n del Formulario VB6

**Archivo VB6:** `vb6/Contabilidad70/HyperContabilidad/FrmCompraVenta.frm`
**Fecha AnÃ¡lisis:** 2025-10-08
**Analista:** GeneraciÃ³n AutomÃ¡tica
**Complejidad:** Pendiente de anÃ¡lisis detallado

### PropÃ³sito del Formulario
Gestión compra venta



---

## ðŸš¨ ESTADO DEL ANÃLISIS

**âš ï¸ ANÃLISIS PENDIENTE - TEMPLATE GENERADO AUTOMÃTICAMENTE**

Este archivo fue generado automÃ¡ticamente como placeholder. Se requiere:

1. **AnÃ¡lisis exhaustivo del formulario VB6 original**
2. **DocumentaciÃ³n completa de controles UI**
3. **Mapeo de eventos y funciones**
4. **IdentificaciÃ³n de queries y acceso a datos**
5. **DocumentaciÃ³n de validaciones y reglas de negocio**
6. **DeterminaciÃ³n de mÃ©todos del Service**

---

## ðŸŽ¨ CONTROLES UI IDENTIFICADOS

### Textboxes (Campos de Entrada)
| Control VB6 | Propiedad Bound | Tipo | ValidaciÃ³n | PropÃ³sito |
|-------------|----------------|------|------------|-----------|
| *(Pendiente anÃ¡lisis VB6)* | | | | |

### ComboBoxes (Listas Desplegables)
| Control VB6 | Fuente Datos | Valor | Display | Evento Change |
|-------------|--------------|-------|---------|---------------|
| *(Pendiente anÃ¡lisis VB6)* | | | | |

### Grillas (MSFlexGrid, DataGrid, etc.)
| Control VB6 | Fuente Datos | Columnas | Eventos | Acciones |
|-------------|--------------|----------|---------|----------|
| *(Pendiente anÃ¡lisis VB6)* | | | | |

### Botones de AcciÃ³n
| BotÃ³n VB6 | Caption | Habilitado Si | AcciÃ³n | Mapeo .NET |
|-----------|---------|---------------|--------|------------|
| *(Pendiente anÃ¡lisis VB6)* | | | | |

**ðŸš¨ IMPORTANTE**: TODOS los botones del formulario VB6 deben ser documentados aquÃ­ sin excepciones.

---

## ðŸ”˜ EVENTOS IDENTIFICADOS

### Eventos de Formulario
| Evento VB6 | CuÃ¡ndo Ocurre | Acciones | Mapeo .NET |
|------------|---------------|----------|------------|
| Form_Load | Al abrir form | *(Pendiente anÃ¡lisis)* | *(Pendiente)* |

### Eventos de Botones
*(Documentar todos los eventos Click, DblClick, etc.)*

---

## ðŸ”§ FUNCIONES Y PROCEDIMIENTOS VB6

### Funciones PÃºblicas
*(Documentar cada funciÃ³n pÃºblica con firma, propÃ³sito y mapeo .NET)*

### Funciones Privadas
*(Documentar cada funciÃ³n privada con firma, propÃ³sito y mapeo .NET)*

---

## ðŸ’¾ ACCESO A DATOS VB6

### Queries Identificadas
*(Documentar cada query SQL con su contexto y mapeo a Entity Framework)*

---

## âœ… VALIDACIONES Y REGLAS DE NEGOCIO

### Validaciones de Campos
| Campo | Regla | Mensaje Error VB6 | Implementar en .NET |
|-------|-------|-------------------|---------------------|
| *(Pendiente anÃ¡lisis VB6)* | | | |

### Reglas de Negocio
*(Documentar todas las reglas de negocio especÃ­ficas del formulario)*

---

## ðŸ§® CÃLCULOS Y FÃ“RMULAS

*(Documentar todos los cÃ¡lculos, fÃ³rmulas y algoritmos)*

---

## ðŸš€ NAVEGACIÃ“N Y FLUJO

### Formularios Llamados
| Desde VB6 | Formulario Destino | ParÃ¡metros | Retorno | Mapeo .NET |
|-----------|-------------------|------------|---------|------------|
| *(Pendiente anÃ¡lisis VB6)* | | | | |

---

## ðŸ“Š EXPORTACIONES E IMPORTACIONES

*(Documentar funcionalidades de exportaciÃ³n/importaciÃ³n si existen)*

---

## ðŸŽ¯ MAPEO FINAL: MÃ‰TODOS .NET DETERMINADOS

### Interface del Service

```csharp
public interface ICompraVentaService
{
    // TODO: Determinar mÃ©todos basÃ¡ndose en anÃ¡lisis VB6 exhaustivo

    // MÃ©todos CRUD bÃ¡sicos (ajustar segÃºn necesidad real):
    Task<IEnumerable<CompraVentaDto>> GetAllAsync(int empresaId);
    Task<CompraVentaDto?> GetByIdAsync(int id);
    Task<ValidationResult> CreateAsync(CompraVentaCreateDto dto);
    Task<ValidationResult> UpdateAsync(int id, CompraVentaUpdateDto dto);
    Task<bool> DeleteAsync(int id);
}
```

**âš ï¸ IMPORTANTE**: Los mÃ©todos anteriores son solo un ejemplo. Los mÃ©todos reales deben determinarse basÃ¡ndose en el anÃ¡lisis exhaustivo del formulario VB6.

---

## âš ï¸ NOTAS IMPORTANTES Y OBSERVACIONES

### PrÃ³ximos Pasos Obligatorios

1. **Abrir y leer** el archivo VB6 original: `vb6/Contabilidad70/HyperContabilidad/FrmCompraVenta.frm`
2. **Documentar exhaustivamente** cada elemento del formulario
3. **Completar** todas las secciones de este Analysis.md
4. **Determinar** automÃ¡ticamente todos los mÃ©todos necesarios
5. **Validar** que el anÃ¡lisis es lo suficientemente detallado para implementar sin asumir

---

## âœ… CHECKLIST DE COMPLETITUD DEL ANÃLISIS

- [ ] Todos los controles UI documentados
- [ ] Todos los botones y eventos mapeados
- [ ] **TODOS los botones tienen "Mapeo .NET" definido** (sin excepciones)
- [ ] Todas las funciones VB6 identificadas
- [ ] Todos los queries SQL traducidos a EF Core
- [ ] Todas las validaciones documentadas
- [ ] Todas las reglas de negocio identificadas
- [ ] Todos los cÃ¡lculos documentados
- [ ] NavegaciÃ³n y flujos mapeados
- [ ] MÃ©todos .NET determinados
- [ ] Interface del Service definida

---

**âŒ ANÃLISIS INCOMPLETO - REQUIERE TRABAJO MANUAL**

Este template debe ser completado exhaustivamente antes de proceder con la implementaciÃ³n.
