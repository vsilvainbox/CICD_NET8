namespace App.Features.AcercaDelSistema;

public interface IAcercaDelSistemaService
{
    /// <summary>
    /// Obtiene la información del sistema para mostrar en "Acerca de"
    /// </summary>
    Task<AcercaDelSistemaDto> GetAsync();
}