using App.Data;
using App.Exceptions;
using Microsoft.EntityFrameworkCore;

namespace App.Features.ConfiguracionInformes;

/// <summary>
/// Servicio para gestión de configuración de informes
/// </summary>
public class ConfiguracionInformesService(
    LpContabContext context,
    ILogger<ConfiguracionInformesService> logger) : IConfiguracionInformesService
{
    // Constantes de opciones (bitmask)
    private const long OPT_ACTUSADO = 0x01;    // Actualizar automáticamente folios
    private const long OPT_NOPRTFECHA = 0x02;  // No imprimir fecha en reportes

    // Constantes de notas
    private const int C_INCNOTALIB = 0x01;  // Incluir en libros
    private const int C_INCNOTABAL = 0x02;  // Incluir en balances

    // Constantes
    private const int MAX_NIVELES = 5;
    private const string TIPO_NOTA_ART100 = "ART100";
    private const string TIPO_NOTA_ESPECIAL = "NOTAESP";

    /// <inheritdoc/>
    public async Task<ConfiguracionInformesResponse> GetConfiguracionAsync(GetConfiguracionInformesRequest request)
    {
        {
            logger.LogInformation("Obteniendo configuración de informes para Empresa: {EmpresaId}, Año: {Ano}",
                request.EmpresaId, request.Ano);

            var response = new ConfiguracionInformesResponse
            {
                Success = true
            };

            // Cargar notas
            response.NotaArticulo100 = await GetNotaAsync(request.EmpresaId, TIPO_NOTA_ART100);
            response.NotaEspecial = await GetNotaAsync(request.EmpresaId, TIPO_NOTA_ESPECIAL);

            // Cargar colores
            response.Colores = await GetColoresAsync(request.EmpresaId);

            // Cargar opciones de la empresa
            var empresa = await context.Empresa
                .FirstOrDefaultAsync(e => e.Id == request.EmpresaId && e.Ano == request.Ano);

            response.OpcionesBitmask = empresa?.Opciones;
            response.OpcionesDisponibles = GetOpcionesDisponibles(response.OpcionesBitmask ?? 0);

            // Cargar parámetro ODF - Incluir en Analítico
            var paramOdf = await context.ParamEmpresa
                .FirstOrDefaultAsync(p => p.Tipo == "INFANAODF"
                                          && p.IdEmpresa == request.EmpresaId);
            response.IncluirOdfEnAnalitico = paramOdf?.Valor;

            // Cargar parámetro ODF - Estado
            var paramEstado = await context.ParamEmpresa
                .FirstOrDefaultAsync(p => p.Tipo == "ESTADOODF"
                                          && p.IdEmpresa == request.EmpresaId);
            response.EstadoOdf = paramEstado?.Valor;
            response.EstadosDocumento = await GetEstadosDocumentoAsync();

            // Cargar membrete
            response.Membrete = await GetMembreteAsync(request.EmpresaId);

            // Cargar fecha comparativo
            var paramFecha = await context.ParamEmpresa
                .FirstOrDefaultAsync(p => p.Tipo == "FECHACOMPA"
                                          && p.IdEmpresa == request.EmpresaId
                                          && p.Ano == request.Ano);
            response.ActivarFechaComparativo = paramFecha?.Valor;

            return response;
        }
    }

    /// <inheritdoc/>
    public async Task<ConfiguracionInformesResponse> SaveConfiguracionAsync(ConfiguracionInformesRequest request)
    {
        using var transaction = await context.Database.BeginTransactionAsync();
        {
            logger.LogInformation("Guardando configuración de informes para Empresa: {EmpresaId}, Año: {Ano}",
                request.EmpresaId, request.Ano);

            // Guardar notas
            if (request.NotaArticulo100 != null)
            {
                await SaveNotaAsync(request.EmpresaId, TIPO_NOTA_ART100, request.NotaArticulo100);
            }

            if (request.NotaEspecial != null)
            {
                await SaveNotaAsync(request.EmpresaId, TIPO_NOTA_ESPECIAL, request.NotaEspecial);
            }

            // Guardar colores
            await SaveColoresAsync(request.EmpresaId, request.Colores);

            // Guardar opciones en Empresa
            var empresa = await context.Empresa
                .FirstOrDefaultAsync(e => e.Id == request.EmpresaId && e.Ano == request.Ano);

            if (empresa != null)
            {
                empresa.Opciones = request.OpcionesBitmask;
            }

            // Guardar parámetros ODF
            if (request.IncluirOdfEnAnalitico != null)
            {
                await SaveParametroAsync(request.EmpresaId, request.Ano, "INFANAODF",
                    request.IncluirOdfEnAnalitico);
            }

            if (request.EstadoOdf != null)
            {
                await SaveParametroAsync(request.EmpresaId, request.Ano, "ESTADOODF",
                    request.EstadoOdf);
            }

            // Guardar membrete
            if (request.Membrete != null)
            {
                // Validar membrete
                if (!string.IsNullOrWhiteSpace(request.Membrete.TituloMembrete1) &&
                    string.IsNullOrWhiteSpace(request.Membrete.Texto1))
                {
                    throw new BusinessException("Falta ingresar Texto 1 del membrete");
                }

                if (!string.IsNullOrWhiteSpace(request.Membrete.TituloMembrete2) &&
                    string.IsNullOrWhiteSpace(request.Membrete.Texto2))
                {
                    throw new BusinessException("Falta ingresar Texto 2 del membrete");
                }

                await SaveMembreteAsync(request.EmpresaId, request.Membrete);
            }

            // Guardar fecha comparativo
            if (request.ActivarFechaComparativo != null)
            {
                await SaveParametroAsync(request.EmpresaId, request.Ano, "FECHACOMPA",
                    request.ActivarFechaComparativo);
            }

            // Guardar registros por página (si aplica)
            if (request.RegistrosPorPagina.HasValue)
            {
                if (request.RegistrosPorPagina.Value < 100 || request.RegistrosPorPagina.Value > 1000)
                {
                    throw new BusinessException("Registros por página debe estar entre 100 y 1000");
                }
            }

            await context.SaveChangesAsync();
            await transaction.CommitAsync();

            logger.LogInformation("Configuración guardada exitosamente");

            return new ConfiguracionInformesResponse
            {
                Success = true,
                Message = "Configuración guardada exitosamente"
            };
        }
    }

    /// <inheritdoc/>
    public async Task<List<EstadoDocumentoDto>> GetEstadosDocumentoAsync()
    {
        // Estados hardcoded como en VB6
        return await Task.FromResult(new List<EstadoDocumentoDto>
        {
            new EstadoDocumentoDto { Id = 1, Nombre = "Pendiente" },
            new EstadoDocumentoDto { Id = 2, Nombre = "Aprobado" },
            new EstadoDocumentoDto { Id = 3, Nombre = "Centralizado" },
            new EstadoDocumentoDto { Id = 4, Nombre = "Anulado" },
            new EstadoDocumentoDto { Id = 5, Nombre = "Exento" }
        });
    }

    #region Métodos Privados

    private async Task<NotaDto?> GetNotaAsync(int empresaId, string tipo)
    {
        var nota = await context.Notas
            .FirstOrDefaultAsync(n => n.Tipo == tipo && n.IdEmpresa == empresaId);

        if (nota == null)
        {
            return new NotaDto
            {
                Tipo = tipo,
                IdEmpresa = empresaId,
                Nota = string.Empty,
                IncluirBalances = false,
                IncluirLibros = false,
                IncluirOtrosInformes = false
            };
        }

        return new NotaDto
        {
            Tipo = nota.Tipo,
            IdEmpresa = nota.IdEmpresa,
            Nota = nota.Nota,
            Incluir = nota.Incluir,
            IncluirInfo = nota.IncluirInfo,
            IncluirBalances = ((nota.Incluir ?? 0) & C_INCNOTABAL) != 0,
            IncluirLibros = ((nota.Incluir ?? 0) & C_INCNOTALIB) != 0,
            IncluirOtrosInformes = nota.IncluirInfo ?? false
        };
    }

    private async Task SaveNotaAsync(int empresaId, string tipo, NotaDto notaDto)
    {
        var nota = await context.Notas
            .FirstOrDefaultAsync(n => n.Tipo == tipo && n.IdEmpresa == empresaId);

        short incluir = 0;
        if (notaDto.IncluirLibros) incluir |= C_INCNOTALIB;
        if (notaDto.IncluirBalances) incluir |= C_INCNOTABAL;

        if (nota != null)
        {
            // Actualizar
            nota.Nota = notaDto.Nota;
            nota.Incluir = incluir;
            nota.IncluirInfo = notaDto.IncluirInfo;
        }
        else
        {
            // Crear
            nota = new App.Data.Notas
            {
                Tipo = tipo,
                IdEmpresa = empresaId,
                Nota = notaDto.Nota,
                Incluir = incluir,
                IncluirInfo = notaDto.IncluirInfo
            };
            context.Notas.Add(nota);
        }
    }

    private async Task<List<ColorNivelDto>> GetColoresAsync(int empresaId)
    {
        var colores = await context.Colores
            .Where(c => c.IdEmpresa == empresaId)
            .OrderBy(c => c.Nivel)
            .ToListAsync();

        var resultado = new List<ColorNivelDto>();

        for (short i = 1; i <= MAX_NIVELES; i++)
        {
            var color = colores.FirstOrDefault(c => c.Nivel == i);
            resultado.Add(new ColorNivelDto
            {
                Nivel = i,
                IdEmpresa = empresaId,
                Color = color?.Color,
                ColorHex = ColorToHex(color?.Color ?? 0)
            });
        }

        return resultado;
    }

    private async Task SaveColoresAsync(int empresaId, List<ColorNivelDto> colores)
    {
        foreach (var colorDto in colores)
        {
            var color = await context.Colores
                .FirstOrDefaultAsync(c => c.Nivel == colorDto.Nivel && c.IdEmpresa == empresaId);

            if (color != null)
            {
                // Actualizar
                color.Color = colorDto.Color;
            }
            else
            {
                // Crear
                color = new App.Data.Colores
                {
                    Nivel = colorDto.Nivel,
                    IdEmpresa = empresaId,
                    Color = colorDto.Color
                };
                context.Colores.Add(color);
            }
        }
    }

    private async Task<MembreteDto?> GetMembreteAsync(int empresaId)
    {
        var membrete = await context.Membrete
            .FirstOrDefaultAsync(m => m.IdEmpresa == empresaId);

        if (membrete == null)
        {
            return new MembreteDto
            {
                IdEmpresa = empresaId,
                TituloMembrete1 = string.Empty,
                TituloMembrete2 = string.Empty,
                Texto1 = string.Empty,
                Texto2 = string.Empty
            };
        }

        return new MembreteDto
        {
            IdEmpresa = membrete.IdEmpresa,
            TituloMembrete1 = membrete.TituloMembrete1,
            TituloMembrete2 = membrete.TituloMembrete2,
            Texto1 = membrete.Texto1,
            Texto2 = membrete.Texto2
        };
    }

    private async Task SaveMembreteAsync(int empresaId, MembreteDto membreteDto)
    {
        var membrete = await context.Membrete
            .FirstOrDefaultAsync(m => m.IdEmpresa == empresaId);

        if (membrete != null)
        {
            // Actualizar
            membrete.TituloMembrete1 = membreteDto.TituloMembrete1;
            membrete.TituloMembrete2 = membreteDto.TituloMembrete2;
            membrete.Texto1 = membreteDto.Texto1;
            membrete.Texto2 = membreteDto.Texto2;
        }
        else
        {
            // Crear
            membrete = new App.Data.Membrete
            {
                IdEmpresa = empresaId,
                TituloMembrete1 = membreteDto.TituloMembrete1,
                TituloMembrete2 = membreteDto.TituloMembrete2,
                Texto1 = membreteDto.Texto1,
                Texto2 = membreteDto.Texto2
            };
            context.Membrete.Add(membrete);
        }
    }

    private async Task SaveParametroAsync(int empresaId, short ano, string tipo, string valor)
    {
        var parametro = await context.ParamEmpresa
            .FirstOrDefaultAsync(p => p.Tipo == tipo
                                      && p.IdEmpresa == empresaId
                                      && (tipo == "FECHACOMPA" ? p.Ano == ano : true));

        if (parametro != null)
        {
            // Actualizar
            parametro.Valor = valor;
        }
        else
        {
            // Crear
            bool esParamEspecial = tipo == "INFANAODF" || tipo == "ESTADOODF" || tipo == "FECHACOMPA";
            short? codigo = null;
            short? anoParam = null;

            if (esParamEspecial)
            {
                codigo = 0;
            }
            else
            {
                codigo = 1;
            }

            if (tipo == "FECHACOMPA")
            {
                anoParam = ano;
            }
            else
            {
                anoParam = 0;
            }

            parametro = new App.Data.ParamEmpresa
            {
                Tipo = tipo,
                Codigo = codigo,
                Valor = valor,
                IdEmpresa = empresaId,
                Ano = anoParam
            };
            context.ParamEmpresa.Add(parametro);
        }
    }

    private List<OpcionDto> GetOpcionesDisponibles(int opcionesBitmask)
    {
        return new List<OpcionDto>
        {
            new OpcionDto
            {
                Valor = OPT_ACTUSADO,
                Descripcion = "Actualizar automáticamente folios usados en la impresión con papel foliado",
                Seleccionada = (opcionesBitmask & OPT_ACTUSADO) != 0
            },
            new OpcionDto
            {
                Valor = OPT_NOPRTFECHA,
                Descripcion = "No imprimir fecha en los reportes, sean estos oficiales o no",
                Seleccionada = (opcionesBitmask & OPT_NOPRTFECHA) != 0
            }
        };
    }

    private string ColorToHex(int color)
    {
        // Convertir color VB (BGR) a hex HTML (#RRGGBB)
        int r = color & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = (color >> 16) & 0xFF;
        return $"#{r:X2}{g:X2}{b:X2}";
    }

    #endregion
}