﻿namespace App.Features.BaseImponible;

/// <summary>
/// Interface para el servicio de Base Imponible Primera Categoría 14 TER A
/// </summary>
public interface IBaseImponibleService
{
    /// <summary>
    /// Obtiene la base imponible completa para una empresa y año
    /// </summary>
    Task<BaseImponibleDto> GetByEmpresaAnoAsync(int empresaId, short ano);

    /// <summary>
    /// Obtiene todos los items de la base imponible
    /// </summary>
    Task<IEnumerable<BaseImponibleItemDto>> GetItemsAsync(int empresaId, short ano);

    /// <summary>
    /// Guarda los cambios en la base imponible
    /// </summary>
    Task<BaseImponibleResultDto> SaveAsync(int empresaId, short ano, BaseImponibleSaveDto dto);

    /// <summary>
    /// Calcula todos los valores de la base imponible
    /// </summary>
    Task<BaseImponibleCalculoDto> CalculateValuesAsync(int empresaId, short ano);

    /// <summary>
    /// Calcula el total de ingresos
    /// </summary>
    Task<double> CalculateTotalIngresosAsync(int empresaId, short ano);

    /// <summary>
    /// Calcula el total de egresos
    /// </summary>
    Task<double> CalculateTotalEgresosAsync(int empresaId, short ano);

    /// <summary>
    /// Calcula la base imponible (ingresos - egresos)
    /// </summary>
    Task<double> CalculateBaseImponibleAsync(int empresaId, short ano);

    /// <summary>
    /// Obtiene valor desde cuentas con código F22
    /// </summary>
    Task<double> GetValorCuentaF22Async(int empresaId, short ano, short codigoF22, string tipo);

    /// <summary>
    /// Obtiene valor de ajustes extra libro caja
    /// </summary>
    Task<double> GetValorAjusteELCAsync(int empresaId, short ano, byte tipoAjuste, short item);

    /// <summary>
    /// Obtiene valor del crédito 33 bis
    /// </summary>
    Task<double> GetValorCredito33BisAsync(int empresaId, short ano);

    /// <summary>
    /// Exporta la base imponible a Excel
    /// </summary>
    Task<byte[]> ExportToExcelAsync(int empresaId, short ano);

    /// <summary>
    /// Genera reporte PDF de la base imponible
    /// </summary>
    Task<byte[]> GenerateReportPdfAsync(int empresaId, short ano);

    /// <summary>
    /// Valida los datos antes de guardar
    /// </summary>
    Task<BaseImponibleValidationResult> ValidateAsync(int empresaId, short ano);
}

/// <summary>
/// Resultado de validación para el servicio de Base Imponible
/// </summary>
public class BaseImponibleValidationResult
{
    public bool IsValid { get; set; }
    public List<string> Errors { get; set; } = new();
}