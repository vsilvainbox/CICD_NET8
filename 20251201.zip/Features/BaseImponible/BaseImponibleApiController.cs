using Microsoft.AspNetCore.Mvc;

namespace App.Features.BaseImponible;

/// <summary>
/// Controlador API para Base Imponible Primera Categoría 14 TER A
/// </summary>
[ApiController]
[Route("[controller]/[action]")]
public class BaseImponibleApiController(
    IBaseImponibleService service,
    ILogger<BaseImponibleApiController> logger) : ControllerBase
{
    /// <summary>
    /// Obtiene la base imponible completa para una empresa y año
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<BaseImponibleDto>> GetByEmpresaAno(int empresaId, short ano)
    {
        {
            logger.LogInformation("API: Obteniendo base imponible para empresa {EmpresaId} año {Ano}", empresaId, ano);

            var result = await service.GetByEmpresaAnoAsync(empresaId, ano);
            return Ok(result);
        }
    }

    /// <summary>
    /// Obtiene todos los items de la base imponible
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetItems(int empresaId, short ano)
    {
        {
            logger.LogInformation("API: Obteniendo items para empresa {EmpresaId} año {Ano}", empresaId, ano);

            var items = await service.GetItemsAsync(empresaId, ano);
            return Ok(items);
        }
    }

    /// <summary>
    /// Guarda los cambios en la base imponible
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<BaseImponibleResultDto>> Save(
        int empresaId,
        short ano,
        [FromBody] BaseImponibleSaveDto dto)
    {
        {
            if (dto == null)
            {
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "Datos inválidos" } });
            }

            logger.LogInformation("API: Guardando base imponible para empresa {EmpresaId} año {Ano}", empresaId, ano);

            var result = await service.SaveAsync(empresaId, ano, dto);

            if (result.Success)
            {
                return Ok(result);
            }
            else
            {
                return BadRequest(result);
            }
        }
    }

    /// <summary>
    /// Calcula todos los valores de la base imponible
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<BaseImponibleCalculoDto>> CalculateValues(int empresaId, short ano)
    {
        {
            logger.LogInformation("API: Calculando valores para empresa {EmpresaId} año {Ano}", empresaId, ano);

            var result = await service.CalculateValuesAsync(empresaId, ano);
            return Ok(result);
        }
    }

    /// <summary>
    /// Valida los datos de la base imponible
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<BaseImponibleValidationResult>> Validate(int empresaId, short ano)
    {
        {
            logger.LogInformation("API: Validando datos para empresa {EmpresaId} año {Ano}", empresaId, ano);

            var result = await service.ValidateAsync(empresaId, ano);
            return Ok(result);
        }
    }

    /// <summary>
    /// Exporta la base imponible a Excel
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ExportToExcel(int empresaId, short ano)
    {
        {
            logger.LogInformation("API: Exportando a Excel para empresa {EmpresaId} año {Ano}", empresaId, ano);

            var fileBytes = await service.ExportToExcelAsync(empresaId, ano);
            var fileName = $"BaseImponible_{empresaId}_{ano}_{DateTime.Now:yyyyMMddHHmmss}.xlsx";

            return File(fileBytes,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                fileName);
        }
    }

    /// <summary>
    /// Genera reporte PDF de la base imponible
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GenerateReportPdf(int empresaId, short ano)
    {
        {
            logger.LogInformation("API: Generando PDF para empresa {EmpresaId} año {Ano}", empresaId, ano);

            var fileBytes = await service.GenerateReportPdfAsync(empresaId, ano);

            if (fileBytes.Length == 0)
            {
                return StatusCode(501, new { swalType = "warning", swalTitle = "Atención", errors = new[] { "Generación de PDF no implementada" } });
            }

            var fileName = $"BaseImponible_{empresaId}_{ano}_{DateTime.Now:yyyyMMddHHmmss}.pdf";

            return File(fileBytes, "application/pdf", fileName);
        }
    }

    /// <summary>
    /// Obtiene el total de ingresos
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<double>> GetTotalIngresos(int empresaId, short ano)
    {
        {
            logger.LogInformation("API: Obteniendo total ingresos para empresa {EmpresaId} año {Ano}", empresaId, ano);

            var total = await service.CalculateTotalIngresosAsync(empresaId, ano);
            return Ok(new { total });
        }
    }

    /// <summary>
    /// Obtiene el total de egresos
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<double>> GetTotalEgresos(int empresaId, short ano)
    {
        {
            logger.LogInformation("API: Obteniendo total egresos para empresa {EmpresaId} año {Ano}", empresaId, ano);

            var total = await service.CalculateTotalEgresosAsync(empresaId, ano);
            return Ok(new { total });
        }
    }

}