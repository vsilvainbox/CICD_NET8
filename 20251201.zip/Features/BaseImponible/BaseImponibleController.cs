using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.BaseImponible;

/// <summary>
/// Controlador MVC para Base Imponible Primera Categoría 14 TER A
/// Refactorizado siguiendo patrón ASP.NET Core MVC
/// </summary>
public class BaseImponibleController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    IBaseImponibleService baseImponibleService,
    ILogger<BaseImponibleController> logger) : Controller
{
    /// <summary>
    /// Vista principal de la base imponible con ViewModel
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Base Imponible";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        logger.LogInformation("Accediendo a Base Imponible para empresa {EmpresaId} año {Ano}",
            SessionHelper.EmpresaId, SessionHelper.Ano);

        ViewData["Title"] = "Base Imponible Primera Categoría 14 TER A)";

        // Cargar datos y convertir a ViewModel
        var dto = await baseImponibleService.GetByEmpresaAnoAsync(SessionHelper.EmpresaId, SessionHelper.Ano);
        var viewModel = BaseImponibleViewModel.FromDto(dto);

        return View(viewModel);
    }

    /// <summary>
    /// Vista de impresión de la base imponible
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Print()
    {
        logger.LogInformation("Vista de impresión para empresa {EmpresaId} año {Ano}",
            SessionHelper.EmpresaId, SessionHelper.Ano);

        await Task.CompletedTask;
        return View();
    }

    [HttpGet]
    public async Task<IActionResult> GetData(int empresaId, short ano)
    {
        logger.LogInformation("Proxying GetData: empresaId={EmpresaId}, ano={Ano}", empresaId, ano);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<BaseImponibleApiController>(
            HttpContext,
            nameof(BaseImponibleApiController.GetByEmpresaAno),
            new { empresaId, ano });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    [HttpPost]
    public async Task<IActionResult> SaveData(int empresaId, short ano, [FromBody] JsonElement request)
    {
        logger.LogInformation("Proxying SaveData: empresaId={EmpresaId}, ano={Ano}", empresaId, ano);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<BaseImponibleApiController>(
            HttpContext,
            nameof(BaseImponibleApiController.Save),
            new { empresaId, ano });
        var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }

    [HttpGet]
    public async Task<IActionResult> ExportExcel(int empresaId, short ano)
    {
        logger.LogInformation("Proxying ExportExcel: empresaId={EmpresaId}, ano={Ano}", empresaId, ano);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<BaseImponibleApiController>(
            HttpContext,
            nameof(BaseImponibleApiController.ExportToExcel),
            new { empresaId, ano });
        var (fileBytes, contentType) = await client.DownloadFileAsync(url, HttpMethod.Get, null);

        return File(fileBytes, contentType);
    }

    /// <summary>
    /// Endpoint para actualizar un item con Model Binding (no JSON manual)
    /// Valida, recalcula y retorna valores formateados desde servidor
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ActualizarItem([FromForm] ActualizarItemRequest request)
    {
        logger.LogInformation("Actualizando item: Empresa={EmpresaId}, Año={Ano}, Tipo={Tipo}, Item={Item}, Valor={Valor}",
            request.EmpresaId, request.Ano, request.TipoBaseImp, request.IdItemBaseImp, request.Valor);

        // Validación con Model Binding
        if (!ModelState.IsValid)
        {
            var errores = ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage)
                .ToList();

            logger.LogWarning("Validación fallida: {Errores}", string.Join(", ", errores));

            return Json(new ActualizarItemResponse
            {
                Success = false,
                Message = string.Join(". ", errores)
            });
        }

        try
        {
            // Guardar cambio (solo Mayor Valor es editable)
            var saveDto = new BaseImponibleSaveDto
            {
                MayorValor = (double)request.Valor,
                ItemsActualizados = new List<BaseImponibleItemUpdateDto>()
            };

            var resultado = await baseImponibleService.SaveAsync(
                request.EmpresaId,
                request.Ano,
                saveDto);

            if (!resultado.Success)
            {
                logger.LogError("Error al guardar: {Message}", resultado.Message);
                return Json(new ActualizarItemResponse
                {
                    Success = false,
                    Message = resultado.Message
                });
            }

            // Recalcular valores con precisión decimal en servidor
            var dtoActualizado = await baseImponibleService.GetByEmpresaAnoAsync(
                request.EmpresaId,
                request.Ano);

            var viewModel = BaseImponibleViewModel.FromDto(dtoActualizado);

            // Retornar valores actualizados Y formateados desde servidor
            var response = new ActualizarItemResponse
            {
                Success = true,
                Message = "Valor actualizado correctamente",
                ValorActualizado = request.Valor,
                TotalIngresos = viewModel.TotalIngresos,
                TotalEgresos = viewModel.TotalEgresos,
                BaseImponible = viewModel.BaseImponibleCalculada,
                // Formateo server-side para consistencia
                ValorActualizadoFormateado = viewModel.MayorValorFormateado,
                TotalIngresosFormateado = viewModel.TotalIngresosFormateado,
                TotalEgresosFormateado = viewModel.TotalEgresosFormateado,
                BaseImponibleFormateada = viewModel.BaseImponibleFormateada
            };

            logger.LogInformation("Item actualizado exitosamente. Nueva base imponible: {Base}",
                response.BaseImponible);

            return Json(response);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error al actualizar item");
            return Json(new ActualizarItemResponse
            {
                Success = false,
                Message = "Error al procesar la actualización"
            });
        }
    }

    /// <summary>
    /// Partial View con tabla renderizada (servidor retorna HTML)
    /// Elimina necesidad de innerHTML en JavaScript
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetTablaPartial(int empresaId, short ano)
    {
        logger.LogInformation("Obteniendo tabla para empresa {EmpresaId} año {Ano}", empresaId, ano);

        try
        {
            var dto = await baseImponibleService.GetByEmpresaAnoAsync(empresaId, ano);
            var viewModel = BaseImponibleViewModel.FromDto(dto);

            return PartialView("_BaseImponibleTabla", viewModel);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error al obtener tabla");
            return StatusCode(500, "Error al cargar la tabla");
        }
    }

    /// <summary>
    /// Partial View con totales renderizados
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetTotalesPartial(int empresaId, short ano)
    {
        logger.LogInformation("Obteniendo totales para empresa {EmpresaId} año {Ano}", empresaId, ano);

        try
        {
            var dto = await baseImponibleService.GetByEmpresaAnoAsync(empresaId, ano);
            var viewModel = BaseImponibleViewModel.FromDto(dto);

            return PartialView("_BaseImponibleTotales", viewModel);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error al obtener totales");
            return StatusCode(500, "Error al cargar totales");
        }
    }
}
