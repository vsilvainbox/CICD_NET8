# Legacy Analysis: BaseImponible

## 📄 Información del Formulario VB6

**Archivo VB6:** `old/Contabilidad70/HyperContabilidad/FrmBaseImponible.frm`
**Fecha Análisis:** 2025-01-30
**Analista:** IA
**Complejidad:** Alta

### Propósito del Formulario
Gestión del cálculo y presentación de la Base Imponible Primera Categoría según el régimen 14 TER A del SII. El formulario permite visualizar y editar los valores de ingresos, egresos y calcular automáticamente la base imponible tributaria para la declaración de impuestos.

---

## 🎨 CONTROLES UI IDENTIFICADOS

### Grilla Principal (FEd2Grid)
| Control VB6 | Tipo | Propósito |
|-------------|------|-----------|
| Grid | FlexEdGrid2.FEd2Grid | Grilla principal para mostrar conceptos y valores |

### Botones de Acción
| Botón VB6 | Caption | Habilitado Si | Acción | Mapeo .NET |
|-----------|---------|---------------|--------|------------|
| Bt_OK | "Aceptar" | Siempre | Valida y guarda datos | SaveAsync() |
| Bt_Cancelar | "Cancelar" | Siempre | Cierra sin guardar | N/A (navegación) |
| Bt_Preview | (Icono Vista Previa) | Siempre | Vista previa de impresión | PreviewReportAsync() |
| Bt_Print | (Icono Imprimir) | Siempre | Imprime reporte | PrintReportAsync() |
| Bt_CopyExcel | (Icono Excel) | Siempre | Copia a Excel | ExportToExcelAsync() |
| Bt_Sum | (Icono Suma) | Siempre | Muestra calculadora de suma | ShowSumCalculator() |
| Bt_ConvMoneda | (Icono Moneda) | Siempre | Conversor de moneda | ShowCurrencyConverter() |
| Bt_Calc | (Icono Calculadora) | Siempre | Abre calculadora | ShowCalculator() |
| Bt_Calendar | (Icono Calendario) | Siempre | Muestra calendario | ShowCalendar() |

### Estructura de la Grilla
| Columna | Constante | Propósito | Ancho | Alineación |
|---------|-----------|-----------|-------|------------|
| C_ID | 0 | ID del registro | 0 (oculta) | - |
| C_TIPOBASEIMP | 1 | Tipo (1=Ingresos, 2=Egresos, 3=Totales) | 0 (oculta) | - |
| C_IDITEM | 2 | ID del item dentro del tipo | 0 (oculta) | - |
| C_CONCEPTO | 3 | Descripción del concepto | 9900 | Izquierda |
| C_VALOR | 4 | Valor del concepto | 1500 | Derecha |
| C_SUBTOTAL | 5 | Subtotal de la sección | 1500 | Derecha |
| C_FMT | 6 | Formato de línea | 0 (oculta) | - |
| C_COLOBLIGATORIA | 7 | Marcador de columna obligatoria | 0 (oculta) | - |
| C_UPD | 8 | Marcador de actualización | 0 (oculta) | - |

---

## 🔘 EVENTOS IDENTIFICADOS

### Eventos de Formulario
| Evento VB6 | Cuándo Ocurre | Acciones | Mapeo .NET |
|------------|---------------|----------|------------|
| Form_Load | Al abrir form | Configura grilla, carga datos | GetAllAsync() |

### Eventos de Grilla
| Control.Evento | Trigger | Acción VB6 | Mapeo .NET |
|----------------|---------|------------|------------|
| Grid.BeforeEdit | Antes de editar celda | Valida si celda es editable | ValidateEditableCell() |
| Grid.AcceptValue | Al aceptar valor | Formatea valor | FormatValue() |
| Grid.EditKeyPress | Al escribir en celda | Valida entrada numérica | ValidateNumericInput() |

---

## 🔧 FUNCIONES Y PROCEDIMIENTOS VB6

### Funciones Principales
| Función VB6 | Tipo | Propósito | Mapeo .NET Method |
|-------------|------|-----------|-------------------|
| SetUpGrid() | Private Sub | Configura columnas de grilla | InitializeGrid() |
| LoadAll() | Private Sub | Carga datos desde BD | GetAllAsync() |
| SaveAll() | Private Sub | Guarda todos los cambios | SaveAsync() |
| CalcTot() | Private Sub | Calcula totales | CalculateTotalsAsync() |
| valida() | Private Function→Boolean | Valida datos antes de guardar | ValidateAsync() |
| SetUpPrtGrid() | Private Sub | Configura impresión | SetupPrintConfiguration() |

### Funciones de Cálculo de Valores
Las siguientes funciones obtienen valores desde cuentas contables y ajustes:
- GetTotCta_CodF22_14Ter(codigo, tipo): Obtiene total de cuenta por código F22
- GetValAjustesELC(tipo, item): Obtiene valor de ajustes extra libro caja
- GetVal33Bis(): Obtiene crédito 33 bis
- GetTotCta_CodF22_14Ter_NC(codigo, tipo): Obtiene notas de crédito

---

## 💾 ACCESO A DATOS VB6

### Query 1: Obtener valor guardado
```vb
Q1 = "SELECT IdBaseImponible14Ter, Valor FROM BaseImponible14Ter "
Q1 = Q1 & " WHERE TipoBaseImp = " & tipo & " AND IdItemBaseImp = " & item
Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.id & " AND Ano = " & gEmpresa.Ano
```

**Mapeo Entity Framework:**
```csharp
await _context.BaseImponible14Ter
    .Where(b => b.TipoBaseImp == tipo
             && b.IdItemBaseImp == item
             && b.IdEmpresa == empresaId
             && b.Ano == ano)
    .FirstOrDefaultAsync();
```

### Query 2: Actualizar valor existente
```vb
Q1 = "UPDATE BaseImponible14Ter SET Valor = " & valor
Q1 = Q1 & " WHERE IdBaseImponible14Ter = " & id
Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.id & " AND Ano = " & gEmpresa.Ano
```

### Query 3: Insertar nuevo registro
```vb
Q1 = "INSERT INTO BaseImponible14Ter (IdBaseImponible14Ter, TipoBaseImp, IdItemBaseImp, Valor, IdEmpresa, Ano)"
Q1 = Q1 & " VALUES(" & MaxId & ", " & tipo & "," & item & "," & valor & "," & gEmpresa.id & "," & gEmpresa.Ano & ")"
```

### Query 4: Obtener máximo ID
```vb
Q1 = "SELECT Max(IdBaseImponible14Ter) FROM BaseImponible14Ter"
Q1 = Q1 & " WHERE IdEmpresa = " & gEmpresa.id & " AND Ano = " & gEmpresa.Ano
```

---

## ✅ VALIDACIONES Y REGLAS DE NEGOCIO

### Estructura de Datos
1. **Tipos de Base Imponible**:
   - BASEIMP_INGRESOS = 1: Sección de ingresos
   - BASEIMP_EGRESOS = 2: Sección de egresos
   - BASEIMP_TOTALES = 3: Sección de totales

2. **Items por Tipo**:
   - Ingresos: 7 items (0-6)
   - Egresos: 7 items (0-6)
   - Totales: 2 items (Base Imponible y Mayor Valor)

### Reglas de Cálculo
1. **Total Ingresos**: Suma de todos los valores de ingresos
2. **Total Egresos**: Suma de todos los valores de egresos
3. **Base Imponible**: Total Ingresos - Total Egresos
4. **Mayor Valor**: Campo editable por el usuario

### Campos Editables
- Solo el campo "Mayor Valor" (último row) es editable por el usuario
- Los demás valores se calculan automáticamente desde cuentas contables

---

## 🧮 CÁLCULOS Y FÓRMULAS

### Cálculo de Ingresos (Tipo 1)
| Item | Concepto | Fórmula |
|------|----------|---------|
| 0 | Total de ingresos anuales | Suma de items 1-6 |
| 1 | Ingresos percibidos | GetTotCta(628,"C") - AjustesELC(DEDUC,2) - NotasCredito(628,"D") |
| 2 | Ingreso diferido imputado | AjustesELC(AGREG,16) + AjustesELC(AGREG,17) + AjustesELC(AGREG,18) |
| 3 | Ingresos devengados | AjustesELC(AGREG,11) + AjustesELC(AGREG,12) + AjustesELC(AGREG,13) |
| 4 | Participaciones e intereses | GetTotCta(629,"C") + AjustesELC(AGREG,8) + AjustesELC(AGREG,9) |
| 5 | Otros ingresos | GetTotCta(651,"C") + AjustesELC(AGREG,15) + AjustesELC(AGREG,19) |
| 6 | Crédito activos fijos | GetVal33Bis() |

### Cálculo de Egresos (Tipo 2)
| Item | Concepto | Fórmula |
|------|----------|---------|
| 0 | Total de egresos anuales | Suma de items 1-6 |
| 1 | Costo directo | GetTotCta(630,"D") - AjustesELC(AGREG,1) - NotasCredito(630,"C") |
| 2 | Remuneraciones | GetTotCta(631,"D") |
| 3 | Adquisición activos | GetTotCta(632,"D") + AjustesELC(DEDUC,13) + AjustesELC(DEDUC,14) |
| 4 | Intereses pagados | GetTotCta(633,"D") |
| 5 | Pérdidas anteriores | AjustesELC(DEDUC,7) + AjustesELC(DEDUC,16) |
| 6 | Otros gastos | GetTotCta(635,"D") + AjustesELC(DEDUC,17) + AjustesELC(DEDUC,5) + AjustesELC(DEDUC,15) + AjustesELC(DEDUC,8) |

---

## 📊 EXPORTACIONES E IMPORTACIONES

### Exportación a Excel
- Botón Bt_CopyExcel copia toda la grilla al portapapeles en formato Excel
- Incluye encabezados y valores formateados

### Impresión
- Vista previa disponible con Bt_Preview
- Impresión directa con Bt_Print
- Configuración de orientación (vertical por defecto)
- Soporte para papel foliado

---

## 🎯 MAPEO FINAL: MÉTODOS .NET DETERMINADOS

### Interface del Service
```csharp
public interface IBaseImponibleService
{
    // Obtención de datos
    Task<BaseImponibleDto> GetByEmpresaAnoAsync(int empresaId, int ano);
    Task<IEnumerable<BaseImponibleItemDto>> GetItemsAsync(int empresaId, int ano);

    // Guardado
    Task<BaseImponibleResultDto> SaveAsync(int empresaId, int ano, BaseImponibleSaveDto dto);

    // Cálculos
    Task<BaseImponibleCalculoDto> CalculateValuesAsync(int empresaId, int ano);
    Task<decimal> CalculateTotalIngresosAsync(int empresaId, int ano);
    Task<decimal> CalculateTotalEgresosAsync(int empresaId, int ano);
    Task<decimal> CalculateBaseImponibleAsync(int empresaId, int ano);

    // Valores desde cuentas contables
    Task<decimal> GetValorCuentaF22Async(int empresaId, int ano, int codigoF22, string tipo);
    Task<decimal> GetValorAjusteELCAsync(int empresaId, int ano, int tipoAjuste, int item);
    Task<decimal> GetValorCredito33BisAsync(int empresaId, int ano);

    // Exportación
    Task<byte[]> ExportToExcelAsync(int empresaId, int ano);
    Task<byte[]> GenerateReportPdfAsync(int empresaId, int ano);

    // Validación
    Task<ValidationResult> ValidateAsync(int empresaId, int ano);
}
```

### Resumen de Mapeo
| Funcionalidad VB6 | Método .NET | Complejidad | Prioridad |
|-------------------|-------------|-------------|-----------|
| Form_Load → LoadAll | GetByEmpresaAnoAsync() | Alta | Alta |
| SaveAll | SaveAsync() | Media | Alta |
| CalcTot | CalculateValuesAsync() | Alta | Alta |
| GetTotCta_CodF22_14Ter | GetValorCuentaF22Async() | Alta | Alta |
| GetValAjustesELC | GetValorAjusteELCAsync() | Alta | Alta |
| GetVal33Bis | GetValorCredito33BisAsync() | Media | Alta |
| Bt_CopyExcel | ExportToExcelAsync() | Baja | Media |
| Bt_Print/Preview | GenerateReportPdfAsync() | Media | Media |
| valida | ValidateAsync() | Baja | Alta |

---

## ⚠️ NOTAS IMPORTANTES Y OBSERVACIONES

### Peculiaridades del Form VB6
- Usa grid especial FlexEdGrid2 con capacidad de edición inline
- Solo permite editar el campo "Mayor Valor" en la sección de totales
- Los valores se calculan automáticamente desde múltiples fuentes (cuentas contables, ajustes, créditos)
- Formato de números con separadores de miles
- Maneja 3 tipos de registros con estructura diferente cada uno

### Decisiones de Diseño
- **Cálculos complejos**: Los valores vienen de múltiples tablas, implementar servicios auxiliares
- **Grid de solo lectura**: Excepto el campo Mayor Valor, todo es calculado
- **Persistencia**: Solo guarda los valores calculados, no las fórmulas
- **Estructura fija**: Los conceptos están hardcodeados, no son dinámicos

### Dependencias a Migrar
- GetTotCta_CodF22_14Ter: Requiere acceso a tabla de cuentas contables
- GetValAjustesELC: Requiere acceso a tabla de ajustes extra libro caja
- GetVal33Bis: Requiere cálculo de crédito fiscal especial

---

## ✅ CHECKLIST DE COMPLETITUD DEL ANÁLISIS

- [x] Todos los controles UI documentados
- [x] Todos los botones y eventos mapeados
- [x] Todas las funciones VB6 identificadas
- [x] Todos los queries SQL traducidos a EF Core
- [x] Todas las validaciones documentadas
- [x] Todas las reglas de negocio identificadas
- [x] Todos los cálculos documentados
- [x] Navegación y flujos mapeados
- [x] Métodos .NET determinados
- [x] Interface del Service definida

---

**✅ ANÁLISIS COMPLETO - LISTO PARA IMPLEMENTACIÓN**