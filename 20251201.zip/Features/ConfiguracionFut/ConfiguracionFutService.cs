using Microsoft.EntityFrameworkCore;
using App.Data;
using App.Exceptions;

namespace App.Features.ConfiguracionFut;

public class ConfiguracionFutService(
    LpContabContext context,
    ILogger<ConfiguracionFutService> logger) : IConfiguracionFutService
{
    public async Task<ConfiguracionFutDto> GetConfiguracionAsync(int empresaId)
    {
        logger.LogInformation("Getting configuración FUT for empresa {EmpresaId}", empresaId);

        var empresa = await context.Empresa
            .Where(e => e.Id == empresaId)
            .Select(e => new { e.TipoContrib, e.TContribFUT })
            .FirstOrDefaultAsync();

        if (empresa == null)
        {
            logger.LogWarning("Empresa {EmpresaId} not found", empresaId);
            throw new BusinessException("Empresa no encontrada");
        }

        var tipoContrib = empresa.TContribFUT ?? empresa.TipoContrib ?? 0;
        var nombreTipo = GetNombreTipoContribuyente(tipoContrib);

        return new ConfiguracionFutDto
        {
            TipoContribuyente = tipoContrib,
            NombreTipoContribuyente = nombreTipo,
            HrFutDisponible = false,
            MensajeEstado = "Módulo HR-FUT no disponible. Se requiere integración con Hyper Remuneraciones."
        };
    }

    public async Task<bool> IsHrFutDisponibleAsync()
    {
        // Verificar si existe la tabla HR_FutGrItems
        // Por ahora siempre retorna false hasta que se implemente la integración
        await Task.CompletedTask;
        return false;
    }

    private string GetNombreTipoContribuyente(int tipo)
    {
        return tipo switch
        {
            1 => "Sociedad Anónima Abierta",
            2 => "Sociedad Anónima Cerrada",
            3 => "Sociedad por Acción",
            4 => "Soc. Personas 1ª Categoría",
            5 => "Empresario Individual (EIRL)",
            6 => "Empresario Individual",
            _ => "No definido"
        };
    }
}
