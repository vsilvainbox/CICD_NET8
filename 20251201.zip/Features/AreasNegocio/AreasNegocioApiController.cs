using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Drawing;

namespace App.Features.AreasNegocio;

[ApiController]
[Route("[controller]/[action]")]
public class AreasNegocioApiController(IAreasNegocioService service, ILogger<AreasNegocioApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IEnumerable<AreasNegocioDto>>> GetAll([FromQuery] int empresaId)
    {
        {
            logger.LogInformation("GetAll: Obteniendo áreas de negocio para empresaId={EmpresaId}", empresaId);

            if (empresaId <= 0)
            {
                logger.LogWarning("GetAll: EmpresaId inválido={EmpresaId}", empresaId);
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "EmpresaId es requerido y debe ser mayor a 0" } });
            }

            var areas = await service.GetAllAsync(empresaId);
            return Ok(areas);
        }
    }

    [HttpGet]
    public async Task<ActionResult<AreasNegocioDto>> GetById(int id, [FromQuery] int empresaId)
    {
        {
            logger.LogInformation("GetById: Obteniendo área de negocio id={Id}, empresaId={EmpresaId}", id, empresaId);

            if (empresaId <= 0)
            {
                logger.LogWarning("GetById: EmpresaId inválido={EmpresaId}", empresaId);
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "EmpresaId es requerido y debe ser mayor a 0" } });
            }

            var area = await service.GetByIdAsync(id, empresaId);

            if (area == null)
            {
                logger.LogWarning("GetById: Área de negocio no encontrada id={Id}, empresaId={EmpresaId}", id, empresaId);
                return NotFound(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "Área de negocio no encontrada" } });
            }

            return Ok(area);
        }
    }

    [HttpPost]
    public async Task<ActionResult<AreasNegocioDto>> Create([FromQuery] int empresaId, [FromBody] AreasNegocioCreateDto dto)
    {
        {
            logger.LogInformation("Create: Creando área de negocio codigo={Codigo}, empresaId={EmpresaId}",
                dto.Codigo, empresaId);

            if (empresaId <= 0)
            {
                logger.LogWarning("Create: EmpresaId inválido={EmpresaId}", empresaId);
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "EmpresaId es requerido y debe ser mayor a 0" } });
            }

            if (!ModelState.IsValid)
            {
                logger.LogWarning("Create: Modelo inválido empresaId={EmpresaId}", empresaId);
                return BadRequest(ModelState);
            }

            var area = await service.CreateAsync(empresaId, dto);
            logger.LogInformation("Create: Área de negocio creada exitosamente id={Id}, codigo={Codigo}",
                area.IdAreaNegocio, area.Codigo);

            return CreatedAtAction(nameof(GetById), new { id = area.IdAreaNegocio, empresaId }, area);
        }
    }

    [HttpPut]
    public async Task<ActionResult<AreasNegocioDto>> Update(int id, [FromQuery] int empresaId, [FromBody] AreasNegocioUpdateDto dto)
    {
        {
            logger.LogInformation("Update: Actualizando área de negocio id={Id}, codigo={Codigo}, empresaId={EmpresaId}",
                id, dto.Codigo, empresaId);

            if (empresaId <= 0)
            {
                logger.LogWarning("Update: EmpresaId inválido={EmpresaId}", empresaId);
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "EmpresaId es requerido y debe ser mayor a 0" } });
            }

            if (!ModelState.IsValid)
            {
                logger.LogWarning("Update: Modelo inválido id={Id}, empresaId={EmpresaId}", id, empresaId);
                return BadRequest(ModelState);
            }

            var area = await service.UpdateAsync(id, empresaId, dto);
            logger.LogInformation("Update: Área de negocio actualizada exitosamente id={Id}, codigo={Codigo}",
                area.IdAreaNegocio, area.Codigo);

            return Ok(area);
        }
    }

    [HttpDelete]
    public async Task<ActionResult> Delete(int id, [FromQuery] int empresaId)
    {
        {
            logger.LogInformation("Delete: Eliminando área de negocio id={Id}, empresaId={EmpresaId}", id, empresaId);

            if (empresaId <= 0)
            {
                logger.LogWarning("Delete: EmpresaId inválido={EmpresaId}", empresaId);
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "EmpresaId es requerido y debe ser mayor a 0" } });
            }

            var result = await service.DeleteAsync(id, empresaId);

            if (!result)
            {
                logger.LogWarning("Delete: Área de negocio no encontrada id={Id}, empresaId={EmpresaId}", id, empresaId);
                return NotFound(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "Área de negocio no encontrada" } });
            }

            logger.LogInformation("Delete: Área de negocio eliminada exitosamente id={Id}", id);
            return NoContent();
        }
    }

    /// <summary>
    /// Exporta las áreas de negocio a Excel
    /// GET /api/AreasNegocio/ExportToExcel
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ExportToExcel([FromQuery] int empresaId)
    {
        {
            logger.LogInformation("ExportToExcel: Exportando áreas de negocio para empresaId={EmpresaId}", empresaId);

            if (empresaId <= 0)
            {
                logger.LogWarning("ExportToExcel: EmpresaId inválido={EmpresaId}", empresaId);
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "EmpresaId es requerido y debe ser mayor a 0" } });
            }

            var areas = await service.GetAllAsync(empresaId);

            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            using var package = new ExcelPackage();
            var worksheet = package.Workbook.Worksheets.Add("Áreas de Negocio");

            int row = 1;

            // Título
            worksheet.Cells[row, 1].Value = "ÁREAS DE NEGOCIO";
            worksheet.Cells[row, 1].Style.Font.Bold = true;
            worksheet.Cells[row, 1].Style.Font.Size = 14;
            row++;
            row++; // Línea en blanco

            // Encabezados
            worksheet.Cells[row, 1].Value = "Código";
            worksheet.Cells[row, 2].Value = "Descripción";
            worksheet.Cells[row, 3].Value = "Estado";

            // Formato encabezados
            using (var range = worksheet.Cells[row, 1, row, 3])
            {
                range.Style.Font.Bold = true;
                range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                range.Style.Fill.BackgroundColor.SetColor(Color.LightGray);
                range.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                range.Style.Border.BorderAround(ExcelBorderStyle.Thin);
            }
            row++;

            // Datos
            foreach (var area in areas)
            {
                worksheet.Cells[row, 1].Value = area.Codigo;
                worksheet.Cells[row, 2].Value = area.Descripcion;
                worksheet.Cells[row, 3].Value = area.Vigente == true ? "Vigente" : "No Vigente";
                row++;
            }

            // Ajustar ancho de columnas
            worksheet.Cells[worksheet.Dimension.Address].AutoFitColumns();

            var bytes = package.GetAsByteArray();
            var fileName = $"AreasNegocio_{empresaId}_{DateTime.Now:yyyyMMdd}.xlsx";

            logger.LogInformation("ExportToExcel: Exportación exitosa, {Count} áreas exportadas", areas.Count());
            return File(bytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
        }
    }
}
