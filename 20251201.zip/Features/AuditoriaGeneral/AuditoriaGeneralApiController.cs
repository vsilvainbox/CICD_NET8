using Microsoft.AspNetCore.Mvc;

namespace App.Features.AuditoriaGeneral;

[ApiController]
[Route("[controller]/[action]")]
public class AuditoriaGeneralApiController(IAuditoriaGeneralService service, ILogger<AuditoriaGeneralApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetAll(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        [FromQuery] int? fechaOperDesde,
        [FromQuery] int? fechaOperHasta,
        [FromQuery] int? fechaCompDesde,
        [FromQuery] int? fechaCompHasta,
        [FromQuery] int? numeroComp,
        [FromQuery] int? idUsuario,
        [FromQuery] int? idOper,
        [FromQuery] int? tipoComp,
        [FromQuery] int? tipoAjuste)
    {
        {
            if (empresaId <= 0 || ano <= 0)
            {
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "EmpresaId y Ano son requeridos" } });
            }

            logger.LogInformation("API: Getting auditoría general for empresa {EmpresaId}, año {Ano}", empresaId, ano);

            var filtros = new AuditoriaFiltrosDto
            {
                FechaOperDesde = fechaOperDesde,
                FechaOperHasta = fechaOperHasta,
                FechaCompDesde = fechaCompDesde,
                FechaCompHasta = fechaCompHasta,
                NumeroComp = numeroComp,
                IdUsuario = idUsuario,
                IdOper = idOper,
                TipoComp = tipoComp,
                TipoAjuste = tipoAjuste
            };

            var validation = service.ValidateFilters(filtros, ano);
            if (!validation.IsValid)
            {
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { validation.ErrorMessage } });
            }

            var result = await service.GetAllAsync(empresaId, ano, filtros);
            return Ok(result);
        }
    }

    [HttpGet]
    public async Task<IActionResult> GetUsuarios()
    {
        {
            logger.LogInformation("API: Getting usuarios for combo");
            var result = await service.GetUsuariosAsync();
            return Ok(result);
        }
    }

    [HttpGet]
    public async Task<IActionResult> GetOperaciones()
    {
        {
            logger.LogInformation("API: Getting operaciones for combo");
            var result = await service.GetOperacionesAsync();
            return Ok(result);
        }
    }

    [HttpGet]
    public async Task<IActionResult> GetTiposComprobante()
    {
        {
            logger.LogInformation("API: Getting tipos comprobante for combo");
            var result = await service.GetTiposComprobanteAsync();
            return Ok(result);
        }
    }

    [HttpGet]
    public async Task<IActionResult> GetTiposAjuste()
    {
        {
            logger.LogInformation("API: Getting tipos ajuste for combo");
            var result = await service.GetTiposAjusteAsync();
            return Ok(result);
        }
    }

    [HttpPost]
    public async Task<IActionResult> CanDeleteImported([FromBody] DeleteImportedRequestDto request)
    {
        {
            if (request == null || request.IdComp <= 0 || request.EmpresaId <= 0 || request.Ano <= 0)
            {
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "IdComp, EmpresaId y Ano son requeridos" } });
            }

            var result = await service.CanDeleteImportedAsync(request.IdComp, request.EmpresaId, request.Ano);
                
            if (result.IsValid)
            {
                return Ok(new { canDelete = true, message = result.Message });
            }
            else
            {
                return Ok(new { canDelete = false, message = result.ErrorMessage });
            }
        }
    }

    [HttpPost]
    public async Task<IActionResult> DeleteImported([FromBody] DeleteImportedRequestDto request)
    {
        {
            if (request == null || request.IdComp <= 0 || request.EmpresaId <= 0 || request.Ano <= 0 || request.IdUsuario <= 0)
            {
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "IdComp, EmpresaId, Ano y IdUsuario son requeridos" } });
            }

            logger.LogInformation("API: Deleting imported comprobante {IdComp}", request.IdComp);

            var result = await service.DeleteImportedAsync(request.IdComp, request.EmpresaId, request.Ano, request.IdUsuario);
                
            if (result.IsValid)
            {
                return Ok(new { success = true, message = result.Message });
            }
            else
            {
                return BadRequest(new { success = false, message = result.ErrorMessage });
            }
        }
    }

    [HttpPost]
    public async Task<IActionResult> ExportToExcel([FromBody] AuditoriaGeneralRequestDto request)
    {
        {
            if (request == null || request.EmpresaId <= 0 || request.Ano <= 0)
            {
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "EmpresaId y Ano son requeridos" } });
            }

            logger.LogInformation("API: Exporting auditoría general to Excel for empresa {EmpresaId}, año {Ano}", request.EmpresaId, request.Ano);

            var result = await service.ExportToExcelAsync(request.EmpresaId, request.Ano, request.Filtros);
            var fileName = $"AuditoriaGeneral_{request.Ano}_{DateTime.Now:yyyyMMddHHmm}.xlsx";

            return File(result, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
        }
    }
}