using Microsoft.AspNetCore.Mvc;
using App.Helpers;
using App.Extensions;

namespace App.Features.ActualizacionGlosas;


public class ActualizacionGlosasController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<ActualizacionGlosasController> logger) : Controller
{
    public IActionResult Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Actualización de Glosas";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        // Obtener empresaId y ano desde la sesión
        var empresaId = SessionHelper.EmpresaId;
        var ano = SessionHelper.Ano;

        logger.LogInformation("Loading ActualizacionGlosas index for empresaId: {EmpresaId}, ano: {Ano}",
            empresaId, ano);

        ViewData["EmpresaId"] = empresaId;
        ViewData["Ano"] = ano;

        return View();
    }

    [HttpGet]
    public async Task<IActionResult> GetDatos(int empresaId)
    {
        logger.LogInformation("ActualizacionGlosas: GetDatos proxy called for empresaId: {EmpresaId}", empresaId);

        {
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<ActualizacionGlosasApiController>(
                HttpContext,
                nameof(ActualizacionGlosasApiController.GetDatos),
                new { empresaId }
            );

            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    [HttpPut]
    public async Task<IActionResult> UpdateGlosa(int id, [FromBody] System.Text.Json.JsonElement request)
    {
        logger.LogInformation("ActualizacionGlosas: UpdateGlosa proxy called for id: {Id}", id);

        {
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<ActualizacionGlosasApiController>(
                HttpContext,
                nameof(ActualizacionGlosasApiController.UpdateGlosa),
                new { id }
            );

            var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Put);
            return StatusCode(statusCode, content);
        }
    }

    [HttpPost]
    public async Task<IActionResult> CreateGlosa([FromBody] System.Text.Json.JsonElement request)
    {
        logger.LogInformation("ActualizacionGlosas: CreateGlosa proxy called");

        {
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<ActualizacionGlosasApiController>(
                HttpContext,
                nameof(ActualizacionGlosasApiController.CreateGlosa)
            );

            var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }
}
