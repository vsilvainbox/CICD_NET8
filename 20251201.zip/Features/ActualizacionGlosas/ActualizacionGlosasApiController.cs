using Microsoft.AspNetCore.Mvc;

namespace App.Features.ActualizacionGlosas;

[ApiController]
[Route("[controller]/[action]")]
public class ActualizacionGlosasApiController(
    IActualizacionGlosasService service,
    ILogger<ActualizacionGlosasApiController> logger) : ControllerBase
{
    [HttpPost]
    public async Task<ActionResult<GuardarGlosaResponse>> CreateGlosa([FromBody] GuardarGlosaRequest request)
    {
        logger.LogInformation("API: CreateGlosa called for empresaId: {EmpresaId}", request.IdEmpresa);

        {
            var result = await service.CrearGlosaAsync(request.Glosa, request.IdEmpresa);

            if (!result.Success)
            {
                return BadRequest(result);
            }

            return Ok(result);
        }
    }

    [HttpGet]
    public async Task<ActionResult<List<GlosaDto>>> GetDatos([FromQuery] int empresaId)
    {
        logger.LogInformation("API: GetDatos called for empresaId: {EmpresaId}", empresaId);

        {
            var glosas = await service.GetAllAsync(empresaId);
            return Ok(glosas);
        }
    }

    [HttpPut]
    public async Task<ActionResult<GuardarGlosaResponse>> UpdateGlosa(int id, [FromBody] GuardarGlosaRequest request)
    {
        logger.LogInformation("API: UpdateGlosa called for idGlosa: {IdGlosa}, empresaId: {EmpresaId}", 
            id, request.IdEmpresa);

        {
            if (request.IdGlosa.HasValue && request.IdGlosa.Value != id)
            {
                return BadRequest(new GuardarGlosaResponse
                {
                    Success = false,
                    Message = "El ID de la glosa no coincide"
                });
            }

            var result = await service.ActualizarGlosaAsync(id, request.Glosa, request.IdEmpresa);

            if (!result.Success)
            {
                return BadRequest(result);
            }

            return Ok(result);
        }
    }

    [HttpGet]
    public async Task<ActionResult<GlosaDto>> ObtenerGlosa(int id, [FromQuery] int empresaId)
    {
        logger.LogInformation("API: ObtenerGlosa called for idGlosa: {IdGlosa}, empresaId: {EmpresaId}", 
            id, empresaId);

        {
            var glosa = await service.ObtenerGlosaAsync(id, empresaId);

            if (glosa == null)
            {
                return NotFound(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "Glosa no encontrada" } });
            }

            return Ok(glosa);
        }
    }

    [HttpHead("{id}")]
    public async Task<ActionResult> ExisteGlosa(int id, [FromQuery] int empresaId)
    {
        logger.LogInformation("API: ExisteGlosa called for idGlosa: {IdGlosa}, empresaId: {EmpresaId}", 
            id, empresaId);

        {
            var existe = await service.ExisteGlosaAsync(id, empresaId);

            if (existe)
            {
                return Ok();
            }

            return NotFound();
        }
    }
}
