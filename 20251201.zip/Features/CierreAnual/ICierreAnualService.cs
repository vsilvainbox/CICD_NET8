﻿namespace App.Features.CierreAnual;

/// <summary>
/// Interfaz de servicio para cierre anual (cierre de ejercicio)
/// Migrado desde VB6 FrmCierreAnual.frm
/// </summary>
public interface ICierreAnualService
{
    /// <summary>
    /// Obtiene el estado del cierre anual para una empresa y año
    /// Mapea a: Form_Load() en VB6
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año a cerrar</param>
    /// <returns>Estado del cierre con información relevante</returns>
    Task<CierreAnualStatusDto> GetCloseStatusAsync(int empresaId, short ano);

    /// <summary>
    /// Valida si los libros anuales han sido impresos
    /// Mapea a: LibAnualesImpresos(True) en VB6
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año a cerrar</param>
    /// <returns>Resultado de validación</returns>
    Task<ValidationResult> ValidateAnnualBooksPrintedAsync(int empresaId, short ano);

    /// <summary>
    /// Ejecuta el proceso completo de cierre anual
    /// Mapea a: Bt_CerrarAno_Click() en VB6
    /// PROCESO IRREVERSIBLE - Cierra todos los meses, calcula IVA, almacena correlativos
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año a cerrar</param>
    /// <param name="progress">Opcional: interfaz para reportar progreso</param>
    /// <returns>Resultado del cierre con detalles</returns>
    Task<CierreAnualResultDto> ExecuteAnnualCloseAsync(int empresaId, short ano, IProgress<CierreAnualProgressDto>? progress = null);

    /// <summary>
    /// Obtiene los últimos correlativos de comprobantes para el año
    /// Mapea a: STEP 3 en Bt_CerrarAno_Click() - Get Last Correlative Number
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año</param>
    /// <returns>Últimos correlativos por tipo</returns>
    Task<LastCorrelativosDto> GetLastCorrelativosAsync(int empresaId, short ano);

    /// <summary>
    /// Calcula el remanente de IVA crédito en UTM para traspaso al próximo año
    /// Mapea a: STEP 5 en Bt_CerrarAno_Click() - Calculate IVA Remainder
    /// CÁLCULO COMPLEJO: Involucra todos los meses del año
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año</param>
    /// <returns>Remanente IVA en UTM</returns>
    Task<double?> CalculateIvaRemainderAsync(int empresaId, short ano);

    /// <summary>
    /// Calcula el saldo final del Libro de Caja
    /// Mapea a: STEP 6 en Bt_CerrarAno_Click() - Calculate Final Libro Caja Balance
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año</param>
    /// <returns>Saldo final (Ingresos - Egresos)</returns>
    Task<double?> CalculateFinalLibroCajaBalanceAsync(int empresaId, short ano);

    /// <summary>
    /// Cierra todos los meses abiertos del año
    /// Mapea a: STEP 4 en Bt_CerrarAno_Click() - Close All Open Months
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año</param>
    /// <returns>Número de meses cerrados</returns>
    Task<int> CloseAllOpenMonthsAsync(int empresaId, short ano);

    /// <summary>
    /// Obtiene una vista previa del cierre sin ejecutarlo
    /// Muestra qué meses se cerrarán, correlativos, saldos estimados
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año</param>
    /// <returns>Vista previa con información estimada</returns>
    Task<CierreAnualPreviewDto> GetClosePreviewAsync(int empresaId, short ano);

    /// <summary>
    /// Traspasa configuraciones SII de diciembre a enero del próximo año
    /// Mapea a: STEP 8 en Bt_CerrarAno_Click() - Transfer SII Configurations
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año actual</param>
    /// <returns>Número de configuraciones traspasadas</returns>
    Task<int> TransferSiiConfigurationsAsync(int empresaId, short ano);
}
