# Legacy Analysis: Capital Simple Acumulado

## 📄 Información del Formulario VB6

**Archivo VB6:** `FrmDetCapPropioSimplAcum.frm` (600 líneas)  
**Complejidad:** Media  
**Propósito:** Gestión de valores anuales acumulados de componentes del Capital Propio Tributario Simplificado

---

## 🎯 FUNCIONALIDAD PRINCIPAL

Formulario modal para gestionar valores acumulados anuales de un tipo específico de componente CPS:
- **Rango:** Desde 2017 hasta año actual de la empresa
- **Grilla editable:** Un valor por año
- **Persistencia:** Tabla `CapPropioSimplAnual`
- **Cálculo total:** Suma automática de todos los años
- **Modal:** Retorna `vbOK` o `vbCancel` con valor total

---

## 🎨 CONTROLES UI

### Grilla Editable (FEd3Grid)
- **5 columnas:**
  - C_ID (0): IdCapPropioSimplAnual (oculta)
  - C_ANO (1): Año (4900 width, center)
  - C_VALOR (2): Valor editable (1500 width, right)
  - C_INGRESOMANUAL (3): Flag manual (oculta)
  - C_UPDATE (4): Estado fila I/U/D (oculta)
- **Rows dinámicas:** Desde 2017 hasta gEmpresa.Ano
- **Editable:** Solo C_VALOR si IngresoManual = 1

### Textbox
- Tx_Total: Total acumulado (readonly, ubicado bajo grilla)

### Botones (10 total)
- Bt_Preview: Vista previa
- Bt_Print: Imprimir
- Bt_CopyExcel: Copiar a Excel
- Bt_Sum: Suma seleccionados
- Bt_ConvMoneda: Convertir moneda
- Bt_Calc: Calculadora
- Bt_Calendar: Calendario
- Bt_OK: Guardar y cerrar (vbOK)
- Bt_Cancel: Cancelar sin guardar (vbCancel)

---

## 💾 ACCESO A DATOS

### Query LoadAll
```sql
SELECT IdCapPropioSimplAnual, AnoValor, Valor, IngresoManual
FROM CapPropioSimplAnual
WHERE IdEmpresa = ? 
  AND TipoDetCPS = ?
ORDER BY AnoValor
```

### SaveAll - INSERT
```sql
INSERT INTO CapPropioSimplAnual (TipoDetCPS, IngresoManual, AnoValor, Valor, IdEmpresa)
VALUES (?, 1, ?, ?, ?)
```

### SaveAll - UPDATE
```sql
UPDATE CapPropioSimplAnual SET
  Valor = ?,
  IngresoManual = 1
WHERE IdCapPropioSimplAnual = ?
  AND TipoDetCPS = ?
  AND AnoValor = ?
  AND IdEmpresa = ?
```

---

## 🔧 LÓGICA DE NEGOCIO

### Form_Load
1. Establece caption dinámico: "Acumulado Anual " + gTipoDetCapPropioSimpl(lTipoDetCapPropioSimpl)
2. Genera filas desde 2017 hasta gEmpresa.Ano
3. Carga valores existentes desde CapPropioSimplAnual
4. Calcula total automático

### Grid_BeforeEdit
- Solo permite editar si IngresoManual <> 0
- Si IngresoManual = 0, el valor viene de cálculos automáticos (no editable)

### Grid_AcceptValue
- Formatea valor numérico
- Marca fila como FGR_U (Update)
- Recalcula total

### SaveAll
- Recorre todas las filas
- INSERT si C_UPDATE = FGR_I
- UPDATE si C_UPDATE = FGR_U
- Guarda lValorAno (valor del año actual) para retornar

### CalcTot
- Suma todos los valores de C_VALOR
- Actualiza Tx_Total

---

## 🔧 MÉTODOS .NET

### ICapitalSimpleAcumuladoService
```csharp
Task<List<ValorAnualDto>> ObtenerValoresAnualesAsync(int empresaId, int tipoDetCPS);
Task GuardarValoresAnualesAsync(int empresaId, int tipoDetCPS, List<ValorAnualDto> valores);
Task<decimal> ObtenerValorAnoActualAsync(int empresaId, int ano, int tipoDetCPS);
```

### DTOs
```csharp
public class ValorAnualDto
{
    public int IdCapPropioSimplAnual { get; set; }
    public int AnoValor { get; set; }
    public decimal Valor { get; set; }
    public bool IngresoManual { get; set; }
    public bool EsEditable => IngresoManual;
}
```

---

## ✅ MAPEO COMPLETO

| Funcionalidad VB6 | .NET | Complejidad |
|-------------------|------|-------------|
| FEdit(TipoDetCPS) | Modal Component | Media |
| Form_Load → LoadAll | ObtenerValoresAnualesAsync() | Baja |
| Bt_OK → SaveAll | GuardarValoresAnualesAsync() | Media |
| Grid_AcceptValue | Cliente (JS) | Baja |
| CalcTot | Suma en cliente | Baja |
| Tx_Total | Display computed | Baja |

**✅ ANÁLISIS COMPLETO**

