using Microsoft.AspNetCore.Mvc;

namespace App.Features.BalanceDesglosado;

/// <summary>
/// API Controller para Balance Desglosado
/// </summary>
[ApiController]
[Route("[controller]/[action]")]
public class BalanceDesglosadoApiController(
    IBalanceDesglosadoService service,
    ILogger<BalanceDesglosadoApiController> logger) : ControllerBase
{
    /// <summary>
    /// Genera el balance desglosado según los filtros especificados
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<BalanceDesglosadoResponse>> Generar([FromBody] BalanceDesglosadoRequest request)
    {
        {
            logger.LogInformation("API: Generando balance desglosado para empresa {EmpresaId}", request.EmpresaId);

            var balance = await service.GenerarBalanceAsync(request);

            logger.LogInformation("API: Balance generado con {Count} filas", balance.Filas.Count);
            return Ok(balance);
        }
    }

    /// <summary>
    /// Obtiene las opciones de filtros disponibles
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<BalanceDesglosadoOpciones>> GetOpciones(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        [FromQuery] string tipoDesglose = "AREANEG")
    {
        {
            logger.LogInformation("API: Obteniendo opciones para empresa {EmpresaId}, tipo {TipoDesglose}", 
                empresaId, tipoDesglose);

            var opciones = await service.GetOpcionesFiltrosAsync(empresaId, ano, tipoDesglose);

            return Ok(opciones);
        }
    }

    /// <summary>
    /// Exporta el balance desglosado a Excel
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> ExportarExcel([FromBody] BalanceDesglosadoRequest request)
    {
        {
            logger.LogInformation("API: Exportando balance a Excel para empresa {EmpresaId}", request.EmpresaId);

            var result = await service.ExportarExcelAsync(request);

            return File(result.FileContents, result.ContentType, result.FileName);
        }
    }

    /// <summary>
    /// Valida los filtros del balance
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<object>> ValidarFiltros([FromBody] BalanceDesglosadoRequest request)
    {
        {
            var (isValid, errors) = await service.ValidarFiltrosAsync(request);

            return Ok(new { isValid, errors });
        }
    }
}

