using App.Data;
using App.Exceptions;
using App.Helpers;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;
using OfficeOpenXml.Style;

namespace App.Features.BalanceDesglosado;

/// <summary>
/// Servicio para generar balances desglosados por Área de Negocio o Centro de Costo
/// </summary>
public class BalanceDesglosadoService(LpContabContext context, ILogger<BalanceDesglosadoService> logger) : IBalanceDesglosadoService
{
    private const int CLASCTA_ACTIVO = 1;
    private const int CLASCTA_PASIVO = 2;
    private const int CLASCTA_RESULTADO = 3;
    private const int TAJUSTE_FINANCIERO = 1;
    private const int TAJUSTE_TRIBUTARIO = 2;
    private const int TAJUSTE_AMBOS = 3;

    public async Task<BalanceDesglosadoResponse> GenerarBalanceAsync(BalanceDesglosadoRequest request)
    {
        {
            logger.LogInformation("Generando balance desglosado para empresa {EmpresaId}, tipo {TipoDesglose}", 
                request.EmpresaId, request.TipoDesglose);

            // Validar filtros
            var validation = await ValidarFiltrosAsync(request);
            if (!validation.IsValid)
            {
                throw new BusinessException(validation.Errors);
            }

            // Obtener cuentas según nivel
            var cuentas = await ObtenerCuentasAsync(request);

            // Obtener lista de desgloses (áreas de negocio o centros de costo)
            var desgloses = await ObtenerDesglosesAsync(request);

            // Generar filas del balance
            var filas = new List<BalanceDesglosadoRow>();
            var totalesPorDesglose = new Dictionary<string, decimal>();
            decimal totalSinDesglose = 0;
            decimal totalGeneral = 0;

            // Inicializar totales por desglose
            foreach (var desglose in desgloses)
            {
                totalesPorDesglose[desglose.Descripcion] = 0;
            }

            // Procesar cuentas por nivel
            string codigoPadreNivel1 = "";
            decimal[] totalesNivel1 = new decimal[desgloses.Count + 2]; // +2 para sin desglose y total

            foreach (var cuenta in cuentas.OrderBy(c => c.Codigo))
            {
                // Detectar cambio de cuenta nivel 1 (para insertar totales)
                if (cuenta.Nivel == 1)
                {
                    if (!string.IsNullOrEmpty(codigoPadreNivel1))
                    {
                        // Insertar total de clasificación anterior
                        var filaTotalClasif = CrearFilaTotalClasificacion(codigoPadreNivel1, totalesNivel1, desgloses);
                        filas.Add(filaTotalClasif);

                        // Agregar línea en blanco
                        filas.Add(new BalanceDesglosadoRow { EsVisible = true, NombreCuenta = "" });

                        // Resetear totales
                        Array.Clear(totalesNivel1, 0, totalesNivel1.Length);
                    }
                    codigoPadreNivel1 = cuenta.Codigo;
                }

                // Calcular saldos por desglose para la cuenta
                var saldosPorDesglose = new Dictionary<string, decimal>();
                decimal saldoSinDesglose = 0;
                decimal saldoTotal = 0;
                decimal debe = 0;
                decimal haber = 0;

                foreach (var desglose in desgloses)
                {
                    var movimientos = await ObtenerMovimientosPorDesgloseAsync(request, cuenta.idCuenta, desglose.Id);
                    debe += movimientos.Debe;
                    haber += movimientos.Haber;

                    decimal saldo = CalcularSaldo(cuenta.Clasificacion ?? CLASCTA_ACTIVO, movimientos.Debe, movimientos.Haber);
                    saldosPorDesglose[desglose.Descripcion] = saldo;
                    saldoTotal += saldo;

                    // Acumular en totales nivel 1
                    int idx = desgloses.IndexOf(desglose);
                    if (idx >= 0) totalesNivel1[idx] += saldo;
                }

                // Movimientos sin desglose (IdAreaNeg = 0 o IdCCosto = 0)
                var movimientosSinDesglose = await ObtenerMovimientosPorDesgloseAsync(request, cuenta.idCuenta, 0);
                debe += movimientosSinDesglose.Debe;
                haber += movimientosSinDesglose.Haber;

                saldoSinDesglose = CalcularSaldo(cuenta.Clasificacion ?? CLASCTA_ACTIVO, movimientosSinDesglose.Debe, movimientosSinDesglose.Haber);
                saldoTotal += saldoSinDesglose;

                // Acumular en total sin desglose
                totalesNivel1[desgloses.Count] += saldoSinDesglose;

                // Saldo total
                decimal saldoFinal = CalcularSaldo(cuenta.Clasificacion ?? CLASCTA_ACTIVO, debe, haber);
                totalesNivel1[desgloses.Count + 1] += saldoFinal;

                var fila = new BalanceDesglosadoRow
                {
                    Nivel = cuenta.Nivel ?? 0,
                    CodigoCuenta = cuenta.Codigo,
                    NombreCuenta = cuenta.Descripcion ?? "",
                    Saldo = saldoFinal,
                    SaldosPorDesglose = saldosPorDesglose,
                    SaldoSinDesglose = saldoSinDesglose,
                    SaldoTotal = saldoFinal,
                    TipoCuenta = cuenta.Clasificacion ?? CLASCTA_ACTIVO,
                    IdCuenta = cuenta.idCuenta,
                    EsNivel1 = cuenta.Nivel == 1,
                    EsVisible = true,
                    Debe = debe,
                    Haber = haber
                };

                // Aplicar filtro de solo nivel seleccionado
                if (request.VerSoloNivelSeleccionado && cuenta.Nivel != request.Nivel && cuenta.Nivel != 1)
                {
                    fila.EsVisible = false;
                }

                // Ocultar filas sin movimientos
                if (saldoFinal == 0 && !fila.EsNivel1 && saldosPorDesglose.Values.All(v => v == 0) && saldoSinDesglose == 0)
                {
                    fila.EsVisible = false;
                }

                filas.Add(fila);
            }

            // Agregar total de última clasificación
            if (!string.IsNullOrEmpty(codigoPadreNivel1))
            {
                var filaTotalClasif = CrearFilaTotalClasificacion(codigoPadreNivel1, totalesNivel1, desgloses);
                filas.Add(filaTotalClasif);
            }

            // ✅ FUNCIONALIDAD #18: Cálculo jerárquico de totales (5 niveles)
            logger.LogInformation("Aplicando cálculo jerárquico de totales...");
            AplicarCalculoJerarquico(filas, desgloses.Count);

            // ✅ FUNCIONALIDAD #19: Insertar "Resultado del Ejercicio"
            logger.LogInformation("Insertando resultado del ejercicio...");
            var totalesClasificacion = CalcularTotalesClasificacion(filas, desgloses);
            InsertarResultadoDelEjercicio(filas, totalesClasificacion, desgloses);

            // Calcular totales finales
            foreach (var desglose in desgloses)
            {
                int idx = desgloses.IndexOf(desglose);
                totalesPorDesglose[desglose.Descripcion] = totalesNivel1[idx];
            }
            totalSinDesglose = totalesNivel1[desgloses.Count];
            totalGeneral = totalesNivel1[desgloses.Count + 1];

            var response = new BalanceDesglosadoResponse
            {
                Filas = filas,
                TotalesPorDesglose = totalesPorDesglose,
                TotalSinDesglose = totalSinDesglose,
                TotalGeneral = totalGeneral,
                Filtros = new BalanceDesglosadoFiltros
                {
                    FechaDesde = request.FechaDesde,
                    FechaHasta = request.FechaHasta,
                    Nivel = request.Nivel,
                    TipoAjuste = request.TipoAjuste,
                    TipoAjusteDescripcion = request.TipoAjuste == TAJUSTE_FINANCIERO ? "Financiero" : "Tributario",
                    TipoDesglose = request.TipoDesglose,
                    TipoDesgloseDescripcion = request.TipoDesglose == "AREANEG" ? "Área de Negocio" : "Centro de Costo",
                    NombresDesglose = desgloses.Select(d => d.Descripcion).ToList(),
                    VerCodigoCuenta = request.VerCodigoCuenta,
                    VerSubTotales = request.VerSubTotales,
                    VerSoloNivelSeleccionado = request.VerSoloNivelSeleccionado,
                    VerColumnaSinDesglose = request.VerColumnaSinDesglose
                }
            };

            logger.LogInformation("Balance desglosado generado con {Count} filas", filas.Count);
            return response;
        }
    }

    public async Task<BalanceDesglosadoOpciones> GetOpcionesFiltrosAsync(int empresaId, short ano, string tipoDesglose)
    {
        {
            logger.LogInformation("Obteniendo opciones de filtros para empresa {EmpresaId}, tipo {TipoDesglose}", 
                empresaId, tipoDesglose);

            var opciones = new BalanceDesglosadoOpciones();

            // Niveles (del 2 en adelante)
            opciones.Niveles = new List<NivelOption>
            {
                new NivelOption { Valor = 2, Descripcion = "Nivel 2" },
                new NivelOption { Valor = 3, Descripcion = "Nivel 3" },
                new NivelOption { Valor = 4, Descripcion = "Nivel 4" },
                new NivelOption { Valor = 5, Descripcion = "Nivel 5" }
            };

            // Tipos de ajuste
            opciones.TiposAjuste = new List<TipoAjusteOption>
            {
                new TipoAjusteOption { Valor = TAJUSTE_FINANCIERO, Descripcion = "Financiero" },
                new TipoAjusteOption { Valor = TAJUSTE_TRIBUTARIO, Descripcion = "Tributario" }
            };

            // Desgloses (áreas de negocio o centros de costo)
            if (tipoDesglose == "AREANEG")
            {
                var areas = await context.AreaNegocio
                    .Where(a => a.IdEmpresa == empresaId)
                    .OrderBy(a => a.Codigo)
                    .Select(a => new DesgloseOption
                    {
                        Id = a.IdAreaNegocio,
                        Codigo = a.Codigo,
                        Descripcion = a.Descripcion ?? ""
                    })
                    .ToListAsync();
                opciones.Desgloses = areas;
            }
            else // CCOSTO
            {
                var centros = await context.CentroCosto
                    .Where(c => c.IdEmpresa == empresaId)
                    .OrderBy(c => c.Codigo)
                    .Select(c => new DesgloseOption
                    {
                        Id = c.IdCCosto,
                        Codigo = c.Codigo,
                        Descripcion = c.Descripcion ?? ""
                    })
                    .ToListAsync();
                opciones.Desgloses = centros;
            }

            return opciones;
        }
    }

    public async Task<BalanceDesglosadoExportResult> ExportarExcelAsync(BalanceDesglosadoRequest request)
    {
        {
            logger.LogInformation("Exportando balance desglosado a Excel para empresa {EmpresaId}", request.EmpresaId);

            var balance = await GenerarBalanceAsync(request);

            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            using var package = new ExcelPackage();
            var worksheet = package.Workbook.Worksheets.Add("Balance Desglosado");

            int row = 1;

            // Encabezado
            worksheet.Cells[row, 1].Value = $"Balance Clasificado Desglosado por {balance.Filtros.TipoDesgloseDescripcion}";
            worksheet.Cells[row, 1].Style.Font.Bold = true;
            worksheet.Cells[row, 1].Style.Font.Size = 14;
            row += 2;

            // Filtros
            worksheet.Cells[row, 1].Value = $"Periodo: {balance.Filtros.FechaDesde:dd/MM/yyyy} a {balance.Filtros.FechaHasta:dd/MM/yyyy}";
            row++;
            worksheet.Cells[row, 1].Value = $"Tipo Ajuste: {balance.Filtros.TipoAjusteDescripcion}";
            row++;
            worksheet.Cells[row, 1].Value = $"Nivel: {balance.Filtros.Nivel}";
            row += 2;

            // Headers
            int col = 1;
            if (balance.Filtros.VerCodigoCuenta)
            {
                worksheet.Cells[row, col++].Value = "Código Cuenta";
            }
            worksheet.Cells[row, col++].Value = "Cuenta";

            if (balance.Filtros.VerColumnaSinDesglose)
            {
                worksheet.Cells[row, col++].Value = $"Sin {balance.Filtros.TipoDesgloseDescripcion}";
            }

            foreach (var nombreDesglose in balance.Filtros.NombresDesglose)
            {
                worksheet.Cells[row, col++].Value = nombreDesglose;
            }

            worksheet.Cells[row, col++].Value = "Saldo Total";

            // Estilo headers
            using (var range = worksheet.Cells[row, 1, row, col - 1])
            {
                range.Style.Font.Bold = true;
                range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                range.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightGray);
            }
            row++;

            // Datos
            foreach (var fila in balance.Filas.Where(f => f.EsVisible))
            {
                col = 1;
                if (balance.Filtros.VerCodigoCuenta)
                {
                    worksheet.Cells[row, col++].Value = fila.CodigoCuenta;
                }

                string nombreCuenta = fila.NombreCuenta;
                if (fila.Nivel > 1)
                {
                    nombreCuenta = new string(' ', (fila.Nivel - 1) * 2) + nombreCuenta;
                }
                worksheet.Cells[row, col++].Value = nombreCuenta;

                if (balance.Filtros.VerColumnaSinDesglose)
                {
                    worksheet.Cells[row, col++].Value = fila.SaldoSinDesglose;
                    worksheet.Cells[row, col - 1].Style.Numberformat.Format = "#,##0.00";
                }

                foreach (var nombreDesglose in balance.Filtros.NombresDesglose)
                {
                    if (fila.SaldosPorDesglose.ContainsKey(nombreDesglose))
                    {
                        worksheet.Cells[row, col].Value = fila.SaldosPorDesglose[nombreDesglose];
                        worksheet.Cells[row, col].Style.Numberformat.Format = "#,##0.00";
                    }
                    col++;
                }

                worksheet.Cells[row, col].Value = fila.SaldoTotal;
                worksheet.Cells[row, col].Style.Numberformat.Format = "#,##0.00";

                // Negrita para nivel 1 y totales
                if (fila.EsNivel1 || fila.EsTotalClasificacion)
                {
                    using (var range = worksheet.Cells[row, 1, row, col])
                    {
                        range.Style.Font.Bold = true;
                    }
                }

                row++;
            }

            // Fila de totales
            col = 1;
            if (balance.Filtros.VerCodigoCuenta) col++;
            worksheet.Cells[row, col++].Value = "TOTAL";
            worksheet.Cells[row, col - 1].Style.Font.Bold = true;

            if (balance.Filtros.VerColumnaSinDesglose)
            {
                worksheet.Cells[row, col].Value = balance.TotalSinDesglose;
                worksheet.Cells[row, col].Style.Numberformat.Format = "#,##0.00";
                worksheet.Cells[row, col].Style.Font.Bold = true;
                col++;
            }

            foreach (var nombreDesglose in balance.Filtros.NombresDesglose)
            {
                if (balance.TotalesPorDesglose.ContainsKey(nombreDesglose))
                {
                    worksheet.Cells[row, col].Value = balance.TotalesPorDesglose[nombreDesglose];
                    worksheet.Cells[row, col].Style.Numberformat.Format = "#,##0.00";
                    worksheet.Cells[row, col].Style.Font.Bold = true;
                }
                col++;
            }

            worksheet.Cells[row, col].Value = balance.TotalGeneral;
            worksheet.Cells[row, col].Style.Numberformat.Format = "#,##0.00";
            worksheet.Cells[row, col].Style.Font.Bold = true;

            // Ajustar ancho de columnas
            worksheet.Cells[worksheet.Dimension.Address].AutoFitColumns();

            var result = new BalanceDesglosadoExportResult
            {
                FileContents = package.GetAsByteArray(),
                FileName = $"BalanceDesglosado_{request.TipoDesglose}_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx"
            };

            logger.LogInformation("Excel generado exitosamente: {FileName}", result.FileName);
            return result;
        }
    }

    public async Task<(bool IsValid, List<string> Errors)> ValidarFiltrosAsync(BalanceDesglosadoRequest request)
    {
        var errors = new List<string>();

        if (request.FechaDesde > request.FechaHasta)
        {
            errors.Add("Fecha de inicio es posterior a la fecha de término");
        }

        if (request.FechaDesde.Year != request.Ano)
        {
            errors.Add("La fecha de inicio no corresponde al periodo actual");
        }

        if (request.FechaHasta.Year != request.Ano)
        {
            errors.Add("La fecha de término no corresponde al periodo actual");
        }

        if (request.Nivel < 2 || request.Nivel > 5)
        {
            errors.Add("Nivel debe estar entre 2 y 5");
        }

        var empresaExiste = await context.Empresa.AnyAsync(e => e.Id == request.EmpresaId);
        if (!empresaExiste)
        {
            errors.Add("Empresa no encontrada");
        }

        return (errors.Count == 0, errors);
    }

    // Métodos privados auxiliares

    private async Task<List<App.Data.Cuentas>> ObtenerCuentasAsync(BalanceDesglosadoRequest request)
    {
        var query = context.Cuentas
            .Where(c => c.IdEmpresa == request.EmpresaId)
            .Where(c => c.Nivel <= request.Nivel)
            .Where(c => c.Clasificacion == (byte?)CLASCTA_ACTIVO || c.Clasificacion == (byte?)CLASCTA_PASIVO);

        return await query.OrderBy(c => c.Codigo).ToListAsync();
    }

    private async Task<List<DesgloseOption>> ObtenerDesglosesAsync(BalanceDesglosadoRequest request)
    {
        if (request.TipoDesglose == "AREANEG")
        {
            var query = context.AreaNegocio
                .Where(a => a.IdEmpresa == request.EmpresaId);

            if (request.IdsDesglose.Any())
            {
                query = query.Where(a => request.IdsDesglose.Contains(a.IdAreaNegocio));
            }

            return await query
                .OrderBy(a => a.Codigo)
                .Select(a => new DesgloseOption
                {
                    Id = a.IdAreaNegocio,
                    Codigo = a.Codigo,
                    Descripcion = a.Descripcion ?? ""
                })
                .ToListAsync();
        }
        else // CCOSTO
        {
            var query = context.CentroCosto
                .Where(c => c.IdEmpresa == request.EmpresaId);

            if (request.IdsDesglose.Any())
            {
                query = query.Where(c => request.IdsDesglose.Contains(c.IdCCosto));
            }

            return await query
                .OrderBy(c => c.Codigo)
                .Select(c => new DesgloseOption
                {
                    Id = c.IdCCosto,
                    Codigo = c.Codigo,
                    Descripcion = c.Descripcion ?? ""
                })
                .ToListAsync();
        }
    }

    private async Task<(decimal Debe, decimal Haber)> ObtenerMovimientosPorDesgloseAsync(
        BalanceDesglosadoRequest request, long idCuenta, int idDesglose)
    {
        var fechaDesde = DateOnly.FromDateTime(request.FechaDesde);
        var fechaHasta = DateOnly.FromDateTime(request.FechaHasta);

        var fechaDesdeInt = DateHelper.ToInteger(request.FechaDesde);
        var fechaHastaInt = DateHelper.ToInteger(request.FechaHasta);
            
        var query = from m in context.MovComprobante
            join c in context.Comprobante
                on new { IdComp = m.IdComp, IdEmpresa = m.IdEmpresa, Ano = m.Ano }
                equals new { IdComp = (int?)c.IdComp, IdEmpresa = c.IdEmpresa, Ano = c.Ano }
            where m.IdCuenta == idCuenta
                  && c.IdEmpresa == request.EmpresaId
                  && c.Fecha >= fechaDesdeInt && c.Fecha <= fechaHastaInt
            select new { m, c };

        // Filtro de tipo de ajuste
        if (request.TipoAjuste == TAJUSTE_FINANCIERO)
        {
            query = query.Where(x => x.c.TipoAjuste == null ||
                                     x.c.TipoAjuste == (byte?)TAJUSTE_FINANCIERO ||
                                     x.c.TipoAjuste == (byte?)TAJUSTE_AMBOS);
        }
        else if (request.TipoAjuste == TAJUSTE_TRIBUTARIO)
        {
            query = query.Where(x => x.c.TipoAjuste == (byte?)TAJUSTE_TRIBUTARIO ||
                                     x.c.TipoAjuste == (byte?)TAJUSTE_AMBOS);
        }

        // Filtro de desglose
        if (request.TipoDesglose == "AREANEG")
        {
            if (idDesglose == 0)
            {
                query = query.Where(x => x.m.idAreaNeg == null || x.m.idAreaNeg == 0);
            }
            else
            {
                query = query.Where(x => x.m.idAreaNeg == idDesglose);
            }
        }
        else // CCOSTO
        {
            if (idDesglose == 0)
            {
                query = query.Where(x => x.m.idCCosto == null || x.m.idCCosto == 0);
            }
            else
            {
                query = query.Where(x => x.m.idCCosto == idDesglose);
            }
        }

        var movimientos = await query.Select(x => x.m).ToListAsync();

        decimal debe = (decimal)movimientos.Sum(m => m.Debe ?? 0);
        decimal haber = (decimal)movimientos.Sum(m => m.Haber ?? 0);

        return (debe, haber);
    }

    private decimal CalcularSaldo(int clasificacion, decimal debe, decimal haber)
    {
        if (clasificacion == CLASCTA_ACTIVO)
        {
            return debe - haber;
        }
        else // PASIVO o RESULTADO
        {
            return haber - debe;
        }
    }

    private BalanceDesglosadoRow CrearFilaTotalClasificacion(string codigoPadre, decimal[] totales, List<DesgloseOption> desgloses)
    {
        var fila = new BalanceDesglosadoRow
        {
            Nivel = 1,
            CodigoCuenta = "",
            NombreCuenta = $"TOTAL {ObtenerNombreClasificacion(codigoPadre)}",
            EsTotalClasificacion = true,
            EsVisible = true,
            SaldoSinDesglose = totales[desgloses.Count],
            SaldoTotal = totales[desgloses.Count + 1],
            SaldosPorDesglose = new Dictionary<string, decimal>()
        };

        for (int i = 0; i < desgloses.Count; i++)
        {
            fila.SaldosPorDesglose[desgloses[i].Descripcion] = totales[i];
        }

        return fila;
    }

    private string ObtenerNombreClasificacion(string codigoPadre)
    {
        // Esta es una simplificación, en VB6 se obtiene el nombre real de la cuenta
        if (codigoPadre.StartsWith("1")) return "ACTIVO";
        if (codigoPadre.StartsWith("2")) return "PASIVO";
        if (codigoPadre.StartsWith("3")) return "PATRIMONIO";
        if (codigoPadre.StartsWith("4")) return "INGRESOS";
        if (codigoPadre.StartsWith("5")) return "COSTOS";
        if (codigoPadre.StartsWith("6")) return "GASTOS";
        return "TOTAL";
    }

    /// <summary>
    /// ✅ FUNCIONALIDAD #18: Cálculo jerárquico de totales (5 niveles)
    /// Replica el algoritmo VB6 de 4 loops anidados para propagar saldos desde niveles inferiores hacia superiores
    /// </summary>
    private void AplicarCalculoJerarquico(List<BalanceDesglosadoRow> filas, int numDesgloses)
    {
        logger.LogInformation("Iniciando cálculo jerárquico - Total filas: {Count}", filas.Count);

        // Iterar sobre todas las filas para propagar saldos hacia arriba
        for (int i = 0; i < filas.Count; i++)
        {
            var fila = filas[i];
            if (fila.Nivel < 2) continue; // Solo procesar niveles 2-5
                
            // Obtener código del padre según el nivel
            string codigoPadre = fila.Nivel switch
            {
                2 => ObtenerNivel1(fila.CodigoCuenta),
                3 => ObtenerNivel2(fila.CodigoCuenta),
                4 => ObtenerNivel3(fila.CodigoCuenta),
                5 => ObtenerNivel4(fila.CodigoCuenta),
                _ => ""
            };

            if (string.IsNullOrEmpty(codigoPadre)) continue;

            // Buscar fila del padre (hacia atrás)
            for (int j = i - 1; j >= 0; j--)
            {
                var filaPadre = filas[j];
                if (filaPadre.CodigoCuenta == codigoPadre)
                {
                    // Propagar saldos de cada desglose
                    foreach (var kvp in fila.SaldosPorDesglose)
                    {
                        if (filaPadre.SaldosPorDesglose.ContainsKey(kvp.Key))
                        {
                            filaPadre.SaldosPorDesglose[kvp.Key] += kvp.Value;
                        }
                        else
                        {
                            filaPadre.SaldosPorDesglose[kvp.Key] = kvp.Value;
                        }
                    }

                    // Propagar saldo sin desglose
                    filaPadre.SaldoSinDesglose += fila.SaldoSinDesglose;

                    // Propagar saldo total
                    filaPadre.SaldoTotal += fila.SaldoTotal;
                    filaPadre.Saldo += fila.Saldo;

                    logger.LogDebug("Propagado: {Hijo} ({NivelHijo}) → {Padre} ({NivelPadre}), Saldo: {Saldo}", 
                        fila.CodigoCuenta, fila.Nivel, filaPadre.CodigoCuenta, filaPadre.Nivel, fila.Saldo);
                    break;
                }
            }
        }

        logger.LogInformation("Cálculo jerárquico completado");
    }

    /// <summary>
    /// Obtiene código de cuenta nivel 1 a partir de código completo
    /// </summary>
    private string ObtenerNivel1(string codigo)
    {
        if (string.IsNullOrEmpty(codigo)) return "";
        var partes = codigo.Split(new[] { '.', '-' }, StringSplitOptions.RemoveEmptyEntries);
        return partes.Length > 0 ? partes[0] : "";
    }

    /// <summary>
    /// Obtiene código de cuenta nivel 2 a partir de código completo
    /// </summary>
    private string ObtenerNivel2(string codigo)
    {
        if (string.IsNullOrEmpty(codigo)) return "";
        var partes = codigo.Split(new[] { '.', '-' }, StringSplitOptions.RemoveEmptyEntries);
        return partes.Length >= 2 ? string.Join(".", partes.Take(2)) : "";
    }

    /// <summary>
    /// Obtiene código de cuenta nivel 3 a partir de código completo
    /// </summary>
    private string ObtenerNivel3(string codigo)
    {
        if (string.IsNullOrEmpty(codigo)) return "";
        var partes = codigo.Split(new[] { '.', '-' }, StringSplitOptions.RemoveEmptyEntries);
        return partes.Length >= 3 ? string.Join(".", partes.Take(3)) : "";
    }

    /// <summary>
    /// Obtiene código de cuenta nivel 4 a partir de código completo
    /// </summary>
    private string ObtenerNivel4(string codigo)
    {
        if (string.IsNullOrEmpty(codigo)) return "";
        var partes = codigo.Split(new[] { '.', '-' }, StringSplitOptions.RemoveEmptyEntries);
        return partes.Length >= 4 ? string.Join(".", partes.Take(4)) : "";
    }

    /// <summary>
    /// Calcula totales por clasificación (Activo, Pasivo, Ganancia, Pérdida, Patrimonio)
    /// </summary>
    private Dictionary<string, Dictionary<string, decimal>> CalcularTotalesClasificacion(
        List<BalanceDesglosadoRow> filas, List<DesgloseOption> desgloses)
    {
        var totales = new Dictionary<string, Dictionary<string, decimal>>
        {
            ["Activo"] = new Dictionary<string, decimal>(),
            ["Pasivo"] = new Dictionary<string, decimal>(),
            ["Ganancia"] = new Dictionary<string, decimal>(),
            ["Perdida"] = new Dictionary<string, decimal>(),
            ["Patrimonio"] = new Dictionary<string, decimal>()
        };

        // Inicializar desgloses
        foreach (var desglose in desgloses)
        {
            totales["Activo"][desglose.Descripcion ?? ""] = 0;
            totales["Pasivo"][desglose.Descripcion ?? ""] = 0;
            totales["Ganancia"][desglose.Descripcion ?? ""] = 0;
            totales["Perdida"][desglose.Descripcion ?? ""] = 0;
            totales["Patrimonio"][desglose.Descripcion ?? ""] = 0;
        }

        // Acumular por clasificación (solo filas de nivel 1)
        foreach (var fila in filas.Where(f => f.Nivel == 1 && !f.EsTotalClasificacion))
        {
            string clasificacion = DeterminarClasificacion(fila.CodigoCuenta);
                
            foreach (var kvp in fila.SaldosPorDesglose)
            {
                if (totales.ContainsKey(clasificacion) && totales[clasificacion].ContainsKey(kvp.Key))
                {
                    totales[clasificacion][kvp.Key] += kvp.Value;
                }
            }
        }

        return totales;
    }

    /// <summary>
    /// Determina clasificación según código de cuenta (simplificado)
    /// </summary>
    private string DeterminarClasificacion(string codigo)
    {
        if (string.IsNullOrEmpty(codigo)) return "Activo";
            
        if (codigo.StartsWith("1")) return "Activo";
        if (codigo.StartsWith("2")) return "Pasivo";
        if (codigo.StartsWith("3")) return "Patrimonio";
        if (codigo.StartsWith("4")) return "Ganancia";
        if (codigo.StartsWith("5") || codigo.StartsWith("6")) return "Perdida";
            
        return "Activo";
    }

    /// <summary>
    /// ✅ FUNCIONALIDAD #19: Inserción automática de "Resultado del Ejercicio"
    /// Calcula Resultado = Ganancias - Pérdidas e inserta fila en sección Patrimonio
    /// </summary>
    private void InsertarResultadoDelEjercicio(
        List<BalanceDesglosadoRow> filas, 
        Dictionary<string, Dictionary<string, decimal>> totalesClasificacion,
        List<DesgloseOption> desgloses)
    {
        logger.LogInformation("Insertando resultado del ejercicio...");

        // Calcular resultado por cada desglose
        var resultadosPorDesglose = new Dictionary<string, decimal>();
        decimal resultadoSinDesglose = 0;
        decimal resultadoTotal = 0;

        foreach (var desglose in desgloses)
        {
            string desc = desglose.Descripcion ?? "";
            decimal ganancia = totalesClasificacion["Ganancia"].GetValueOrDefault(desc, 0);
            decimal perdida = totalesClasificacion["Perdida"].GetValueOrDefault(desc, 0);
            decimal resultado = ganancia - perdida;
                
            resultadosPorDesglose[desc] = resultado;
            resultadoTotal += resultado;
                
            logger.LogDebug("Resultado {Desglose}: Ganancia={Ganancia}, Perdida={Perdida}, Resultado={Resultado}",
                desc, ganancia, perdida, resultado);
        }

        // Buscar primera cuenta de Patrimonio para insertar después
        int indiceInsercion = -1;
        for (int i = 0; i < filas.Count; i++)
        {
            if (filas[i].CodigoCuenta.StartsWith("3") && !filas[i].EsTotalClasificacion)
            {
                indiceInsercion = i + 1;
                break;
            }
        }

        if (indiceInsercion == -1)
        {
            logger.LogWarning("No se encontró sección de Patrimonio para insertar Resultado del Ejercicio");
            return;
        }

        // Crear fila de Resultado del Ejercicio
        var filaResultado = new BalanceDesglosadoRow
        {
            Nivel = 2, // Nivel 2 para que aparezca indentado
            CodigoCuenta = "3.99", // Código especial
            NombreCuenta = "RESULTADO DEL EJERCICIO",
            Saldo = resultadoTotal,
            SaldosPorDesglose = resultadosPorDesglose,
            SaldoSinDesglose = resultadoSinDesglose,
            SaldoTotal = resultadoTotal,
            TipoCuenta = CLASCTA_PASIVO, // Se trata como pasivo
            IdCuenta = 0, // Sin ID real
            EsNivel1 = false,
            EsVisible = true,
            EsResultadoEjercicio = true,
            Debe = 0,
            Haber = 0
        };

        filas.Insert(indiceInsercion, filaResultado);
            
        logger.LogInformation("Resultado del Ejercicio insertado en índice {Indice}, Resultado Total: {Total}",
            indiceInsercion, resultadoTotal);

        // Actualizar totales de Patrimonio para incluir el resultado
        for (int i = 0; i < filas.Count; i++)
        {
            if (filas[i].CodigoCuenta.StartsWith("3") && filas[i].Nivel == 1 && !filas[i].EsTotalClasificacion)
            {
                foreach (var kvp in resultadosPorDesglose)
                {
                    if (filas[i].SaldosPorDesglose.ContainsKey(kvp.Key))
                    {
                        filas[i].SaldosPorDesglose[kvp.Key] += kvp.Value;
                    }
                }
                filas[i].SaldoTotal += resultadoTotal;
                filas[i].Saldo += resultadoTotal;
                break;
            }
        }
    }
}