using System.ComponentModel.DataAnnotations;

namespace App.Features.BalanceDesglosado;

public class BalanceDesglosadoRequest
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }

    [Display(Name = "Desde")]
    [DataType(DataType.Date)]
    public DateTime FechaDesde { get; set; }

    [Display(Name = "Hasta")]
    [DataType(DataType.Date)]
    public DateTime FechaHasta { get; set; }

    [Display(Name = "Nivel cuentas")]
    public int Nivel { get; set; }

    [Display(Name = "Tipo Ajuste")]
    public int TipoAjuste { get; set; }

    public string TipoDesglose { get; set; } = "AREANEG"; // AREANEG o CCOSTO
    public List<int> IdsDesglose { get; set; } = new();

    [Display(Name = "Ver código cuenta")]
    public bool VerCodigoCuenta { get; set; }

    [Display(Name = "Ver subtotales")]
    public bool VerSubTotales { get; set; }

    [Display(Name = "Solo nivel seleccionado")]
    public bool VerSoloNivelSeleccionado { get; set; }

    [Display(Name = "Ver columna sin desglose")]
    public bool VerColumnaSinDesglose { get; set; }
}

public class BalanceDesglosadoResponse
{
    public List<BalanceDesglosadoRow> Filas { get; set; } = new();
    public Dictionary<string, decimal> TotalesPorDesglose { get; set; } = new();
    public decimal TotalSinDesglose { get; set; }
    public decimal TotalGeneral { get; set; }
    public BalanceDesglosadoFiltros? Filtros { get; set; }
}

public class BalanceDesglosadoRow
{
    public int Nivel { get; set; }
    public string? CodigoCuenta { get; set; }
    public string? NombreCuenta { get; set; }
    public decimal Saldo { get; set; }
    public Dictionary<string, decimal> SaldosPorDesglose { get; set; } = new();
    public decimal SaldoSinDesglose { get; set; }
    public decimal SaldoTotal { get; set; }
    public int TipoCuenta { get; set; }
    public long IdCuenta { get; set; }
    public bool EsNivel1 { get; set; }
    public bool EsVisible { get; set; }
    public decimal Debe { get; set; }
    public decimal Haber { get; set; }
    public bool EsTotalClasificacion { get; set; }
    /// <summary>
    /// ? Indica si esta fila es el "Resultado del Ejercicio" (funcionalidad #19)
    /// </summary>
    public bool EsResultadoEjercicio { get; set; }
}

public class BalanceDesglosadoFiltros
{
    public DateTime FechaDesde { get; set; }
    public DateTime FechaHasta { get; set; }
    public int Nivel { get; set; }
    public int TipoAjuste { get; set; }
    public string? TipoAjusteDescripcion { get; set; }
    public string? TipoDesglose { get; set; }
    public string? TipoDesgloseDescripcion { get; set; }
    public List<string> NombresDesglose { get; set; } = new();
    public bool VerCodigoCuenta { get; set; }
    public bool VerSubTotales { get; set; }
    public bool VerSoloNivelSeleccionado { get; set; }
    public bool VerColumnaSinDesglose { get; set; }
}

public class BalanceDesglosadoOpciones
{
    public List<NivelOption> Niveles { get; set; } = new();
    public List<TipoAjusteOption> TiposAjuste { get; set; } = new();
    public List<DesgloseOption> Desgloses { get; set; } = new();
}

public class NivelOption
{
    public int Valor { get; set; }
    public string? Descripcion { get; set; }
}

public class TipoAjusteOption
{
    public int Valor { get; set; }
    public string? Descripcion { get; set; }
}

public class DesgloseOption
{
    public int Id { get; set; }
    public string? Codigo { get; set; }
    public string? Descripcion { get; set; }
}

public class BalanceDesglosadoExportResult
{
    public byte[] Data { get; set; } = Array.Empty<byte>();
    public byte[] FileContents { get; set; } = Array.Empty<byte>();
    public string FileName { get; set; } = "";
    public string ContentType { get; set; } = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
}
