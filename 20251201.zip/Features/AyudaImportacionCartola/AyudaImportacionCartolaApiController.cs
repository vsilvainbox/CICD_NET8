using Microsoft.AspNetCore.Mvc;

namespace App.Features.AyudaImportacionCartola;

[ApiController]
[Route("[controller]/[action]")]
public class AyudaImportacionCartolaApiController(
    IAyudaImportacionCartolaService service,
    ILogger<AyudaImportacionCartolaApiController> logger) : ControllerBase
{
    /// <summary>
    /// Obtiene la información completa de ayuda para importación de cartolas
    /// </summary>
    /// <returns>Datos de ayuda con título, instrucciones y campos</returns>
    [HttpGet]
    public async Task<ActionResult<AyudaImportacionCartolaDto>> GetAyudaImportacion()
    {
        logger.LogInformation("API: GetAyudaImportacion called");

        {
            var ayuda = await service.GetAyudaImportacionAsync();
            logger.LogInformation("API: Returning ayuda importacion data");
            return Ok(ayuda);
        }
    }

    /// <summary>
    /// Obtiene solo la lista de campos y formatos
    /// </summary>
    /// <returns>Lista de campos de importación</returns>
    [HttpGet]
    public async Task<ActionResult<IEnumerable<CampoFormatoDto>>> GetCampos()
    {
        logger.LogInformation("API: GetCampos called");

        {
            var campos = await service.GetCamposFormatoAsync();
            logger.LogInformation("API: Returning {Count} campos", campos.Count());
            return Ok(campos);
        }
    }

    /// <summary>
    /// Genera texto formateado para clipboard (compatible con Excel)
    /// </summary>
    /// <returns>Texto tabulado para copiar</returns>
    [HttpGet]
    public async Task<ActionResult<ClipboardResponseDto>> GetClipboardData()
    {
        logger.LogInformation("API: GetClipboardData called");

        {
            var clipboardText = await service.GenerateClipboardTextAsync();
            var response = new ClipboardResponseDto
            {
                ClipboardText = clipboardText,
                Success = true,
                Message = "Datos listos para copiar al portapapeles"
            };

            logger.LogInformation("API: Successfully generated clipboard data");
            return Ok(response);
        }
    }
}