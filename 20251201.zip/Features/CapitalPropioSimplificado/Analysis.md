# Legacy Analysis: Capital Propio Simplificado

## 📄 Información del Formulario VB6

**Archivo VB6:** `FrmCapPropioSimpl.frm` (1352 líneas)  
**Complejidad:** Alta  
**Propósito:** Gestión y cálculo del Capital Propio Tributario Simplificado según Art. 14 D de la Ley de Renta

---

## 🎯 FUNCIONALIDAD PRINCIPAL

Cálculo y seguimiento del Capital Propio Tributario (CPT) Simplificado para empresas bajo régimen Art. 14 D:
- **Dos modalidades:** General y Variación Anual
- **Componentes múltiples:** 17+ items tributarios (aumentos, disminuciones, ajustes)
- **Edición detallada:** DblClick en cada item abre form específico
- **Cálculo automático:** Suma/resta según signo de cada componente
- **Persistencia:** Guarda en EmpresasAno al cerrar
- **Pro Pyme:** Diferencias entre General (14DN3) y Transparente (14DN8)

---

## 🎨 CONTROLES UI

### Grilla Editable (FEd3Grid)
- **5 columnas:** Título, Monto, Signo, Fmt, Obligatoria
- **Rows dinámicas:** ~30-40 items según tipo empresa
- **Editable:** Solo campos específicos (Reposición Pérdida, CPT Año Anterior)
- **DblClick:** Abre detalle de cada componente

### Textboxes
- Tx_CapPropio: Label "Capital Propio Tributario Simplificado"
- Tx_TotCapPropio: Total calculado (readonly, color rojo, negrita)

### Botones (13 total)
- Bt_Preview: Vista previa
- Bt_Print: Imprimir
- Bt_CopyExcel: Copiar a Excel
- Bt_Sum: Suma seleccionados
- Bt_ConvMoneda: Convertir moneda
- Bt_Calc: Calculadora
- Bt_Calendar: Calendario
- Bt_Manual: Manual CPT (PDF)
- Bt_Cerrar: Cerrar y guardar

---

## 🧮 COMPONENTES DEL CPT

### Componentes Base (Siempre)
1. **Capital Aportado** (lRowCapAportado) [+]
2. **Aumentos Posteriores Capital** (lRowAumentosCapital) [+]
3. **Base Imponible Ejercicio** (lRowBaseImp) [+/-]
4. **Disminuciones Formales Capital** (lRowDisminucionesCapital) [-]
5. **Gastos Pagados no Gravados Art 21** (lRowGastosRechazados) [-]
6. **Retiros o Dividendos** (lRowRetDiv) [-]
7. **Ingreso Diferido** (lRowIngresoDiferido) [-]
8. **Más Otros Ajustes** (lRowOtrosAjustesAumentos) [+]
9. **Menos Otros Ajustes** (lRowOtrosAjustesDisminuciones) [-]

### Solo Pro Pyme General (14DN3)
10. **Rentas Exentas INR Propios** (lRowINRPropios) [+]
11. **Pérdida INR Propios** (lRowINRPropiosPerdidas) [-]
12. **Participaciones Recibidas** (lRowParticipaciones) [+]
13. **Utilidades Imputadas Pérdida** (lRowUtilidadesPerdida) [-]
14. **Incentivo Ahorro Art 14E** (lRowIncentivoAhorro) [+]
15. **Base IDPC Voluntario** (lRowIDPCVoluntario) [+]
16. **CTD Imputable IPE** (lRowCTDImputableIPE) [-] (hasta 2021)

### Solo Pro Pyme Transparente (14DN8)
17. **Crédito Activos Fijos Art 33bis** (lRowCredActFijos) [-]
18. **Crédito Participaciones** (lRowCredParticipaciones) [-]

### Solo Variación Anual
19. **CPT Inicio Ejercicio** (lRowCapPropioTribAnoAnt) [+/-]
20. **Reposición Pérdida Arrastre** (lRowRepPerdidaArrastre) [+]

---

## 💾 ACCESO A DATOS

### Query LoadAll
```sql
SELECT CPS_CapPropioTribAnoAnt, CPS_CapitalAportado, 
       CPS_BaseImpPrimCat_14DN3, CPS_BaseImpPrimCat_14DN8,
       CPS_Participaciones, CPS_Disminuciones, CPS_GastosRechazados,
       CPS_RetirosDividendos, CPS_RepPerdidaArrastre, 
       CPS_CapPropioSimplificado, CPS_CapPropioSimplVarAnual,
       ... (24 campos total)
FROM EmpresasAno 
WHERE IdEmpresa = ? AND Ano = ?
```

### Update al Cerrar
```sql
UPDATE EmpresasAno SET
  CPS_CapPropioSimplificado = ? (o CPS_CapPropioSimplVarAnual),
  CPS_BaseImpPrimCat_14DN3 = ?,
  CPS_BaseImpPrimCat_14DN8 = ?,
  CPS_CapPropioTribAnoAnt = ?,
  CPS_RepPerdidaArrastre = ?
WHERE IdEmpresa = ? AND Ano = ?
```

---

## 🔧 MÉTODOS .NET

### ICapitalPropioSimplificadoService
```csharp
Task<CapitalPropioSimplificadoDto> ObtenerCPSAsync(int empresaId, int ano, TipoInformeCPS tipo);
Task GuardarCPSAsync(int empresaId, int ano, CapitalPropioSimplificadoDto datos);
Task<decimal> CalcularTotalCPSAsync(CapitalPropioSimplificadoDto datos);
```

### Enums
```csharp
public enum TipoInformeCPS
{
    General = 0,
    VariacionAnual = 1
}
```

---

## ✅ MAPEO COMPLETO

| Funcionalidad VB6 | .NET | Complejidad |
|-------------------|------|-------------|
| Form_Load → LoadAll | ObtenerCPSAsync() | Alta |
| Bt_Cerrar → Update | GuardarCPSAsync() | Media |
| CalcTot | CalcularTotalCPSAsync() | Media |
| Grid_DblClick → Forms | Modals para detalle | Alta |
| Bt_CopyExcel | ExportarExcelAsync() | Baja |
| Bt_Preview/Print | CSS @media print | Baja |

**✅ ANÁLISIS COMPLETO**

