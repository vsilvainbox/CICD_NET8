# 📊 Reporte de Gaps: Capital Propio Simplificado
## Comparación VB6 → .NET 9

**Fecha de análisis:** 28 de noviembre de 2025
**Feature:** CapitalPropioSimplificado
**Estado general:** 60.5% PARIDAD

**Archivos analizados:**
- VB6: `D:\vb6\Contabilidad70\HyperContabilidad\FrmCapPropioSimpl.frm`
- .NET: `D:\deploy\Features\CapitalPropioSimplificado\*`

---

## 📋 Resumen Ejecutivo

| Categoría | Total Aspectos | ✅ OK | ⚠️ Parcial | ❌ Falta | % Paridad |
|-----------|:--------------:|:-----:|:----------:|:--------:|:---------:|
| **1. Inputs/Dependencias** | 6 | 4 | 2 | 0 | 83% |
| **2. Datos y Persistencia** | 10 | 7 | 1 | 2 | 75% |
| **3. Acciones y Operaciones** | 6 | 3 | 1 | 2 | 58% |
| **4. Validaciones** | 6 | 1 | 2 | 3 | 33% |
| **5. Cálculos y Lógica** | 5 | 4 | 1 | 0 | 90% |
| **6. Interfaz y UX** | 5 | 3 | 1 | 1 | 70% |
| **7. Seguridad** | 2 | 0 | 0 | 2 | 0% |
| **8. Manejo de Errores** | 2 | 1 | 1 | 0 | 75% |
| **9. Outputs/Salidas** | 6 | 2 | 0 | 4 | 33% |
| **10. Paridad Controles UI** | 6 | 4 | 1 | 1 | 79% |
| **11. Grids y Columnas** | 2 | 2 | 0 | 0 | 100% |
| **12. Eventos e Interacción** | 5 | 1 | 1 | 3 | 30% |
| **13. Estados y Modos** | 3 | 3 | 0 | 0 | 100% |
| **14. Inicialización** | 3 | 2 | 0 | 1 | 67% |
| **15. Filtros y Búsqueda** | 2 | 0 | 0 | 2 | 0% |
| **16. Reportes e Impresión** | 2 | 1 | 0 | 1 | 50% |
| **17. Reglas de Negocio** | 4 | 4 | 0 | 0 | 100% |
| **18. Flujos de Trabajo** | 3 | 2 | 1 | 0 | 83% |
| **19. Integraciones** | 3 | 0 | 0 | 3 | 0% |
| **20. Mensajes al Usuario** | 2 | 1 | 1 | 0 | 75% |
| **21. Casos Borde** | 3 | 2 | 1 | 0 | 83% |
| **TOTAL** | **86** | **47** | **14** | **25** | **60.5%** |

---

## 1️⃣ INPUTS / DEPENDENCIAS DE ENTRADA (6 aspectos)

### ✅ 1. Variables globales
**VB6:**
```vb
' Usa: gEmpresa, gEmpresa.id, gEmpresa.Ano, gEmpresa.ProPymeGeneral, gEmpresa.ProPymeTransp
' Líneas 345-356, 468, 548-551
```

**NET:**
```csharp
// SessionHelper.EmpresaId, SessionHelper.Ano (línea 4-5 Index.cshtml)
// Se pasa explícitamente como parámetros a Service (líneas 12-13, 26-36)
```

**Estado:** ✅ **PARIDAD COMPLETA**
El acceso a empresa/año se hace de forma equivalente vía Session y parámetros explícitos.

---

### ⚠️ 2. Parámetros de entrada
**VB6:**
```vb
' FView(ByVal TipoInforme As Integer) - línea 327-333
' Recibe modo al abrir form (General o VariacionAnual)
```

**NET:**
```csharp
// Index(TipoInformeCPS tipoInforme = TipoInformeCPS.General) - línea 12
// ViewData["TipoInforme"] = (int)tipoInforme; - línea 17
```

**Estado:** ⚠️ **PARCIAL**
- ✅ Parámetro tipoInforme existe y funciona
- ❌ FALTA: No se respeta el valor inicial desde URL (siempre carga como General en UI)

---

### ✅ 3. Configuraciones
**VB6:**
```vb
' GetIniString(gIniFile, "Msg", "14DN8Ingresos", "0") - líneas 403-408
' Mensaje de advertencia para 14DN8
```

**NET:**
```csharp
// No requiere appsettings para esta feature específica
```

**Estado:** ✅ **PARIDAD COMPLETA** (N/A - mensaje se muestra siempre en VB6 después de primera vez)

---

### ✅ 4. Estado previo requerido
**VB6:**
```vb
' Form requiere gEmpresa.id, gEmpresa.Ano para funcionar
```

**NET:**
```csharp
// Requiere SessionHelper.EmpresaId, SessionHelper.Ano
// Verificado en líneas 4-5 de Index.cshtml
```

**Estado:** ✅ **PARIDAD COMPLETA**

---

### ✅ 5. Datos maestros necesarios
**VB6:**
```vb
' Consulta EmpresasAno para obtener datos (líneas 463-470)
' Consulta año anterior si existe (líneas 485-497)
```

**NET:**
```csharp
// context.EmpresasAno (líneas 16-28)
// Consulta año anterior (líneas 71-86)
```

**Estado:** ✅ **PARIDAD COMPLETA**

---

### ⚠️ 6. Conexión/Sesión
**VB6:**
```vb
' DbMain - conexión compartida global
' Usada en OpenRs(DbMain, Q1) - línea 470
```

**NET:**
```csharp
// LpContabContext context - inyectado por DI (línea 7)
```

**Estado:** ⚠️ **PARCIAL**
- ✅ Contexto de BD funciona
- ⚠️ No se valida si hay conexión activa antes de operar

**Paridad categoría:** 83% (5/6 aspectos OK)

---

## 2️⃣ DATOS Y PERSISTENCIA (10 aspectos)

### ✅ 7. Queries SELECT
**VB6:**
```vb
' Línea 463-468: SELECT CPS_* FROM EmpresasAno
' Línea 485-486: SELECT CPS_CapPropioTrib FROM EmpresasAno año anterior
```

**NET:**
```csharp
// Línea 16-17: context.EmpresasAno.FirstOrDefaultAsync()
// Línea 72-73: Consulta año anterior
```

**Estado:** ✅ **PARIDAD COMPLETA** - Todos los campos se consultan correctamente

---

### ❌ 8. Queries INSERT
**VB6:**
```vb
' No hay inserts (solo updates en EmpresasAno existente)
```

**NET:**
```csharp
// No hay inserts (solo updates)
```

**Estado:** ✅ **N/A** - No aplica para esta feature

---

### ✅ 9. Queries UPDATE
**VB6:**
```vb
' Líneas 336-358: UpdateSQL en bt_Cerrar_Click
' Actualiza: CPS_CapPropioSimplificado, CPS_CapPropioSimplVarAnual,
'            CPS_BaseImpPrimCat_14DN3, CPS_BaseImpPrimCat_14DN8,
'            CPS_CapPropioTribAnoAnt, CPS_RepPerdidaArrastre
```

**NET:**
```csharp
// Líneas 94-140: GuardarCPSAsync
// Actualiza mismos campos vía EF Core SaveChangesAsync (línea 136)
```

**Estado:** ✅ **PARIDAD COMPLETA**

---

### ❌ 10. Queries DELETE
**VB6:**
```vb
' Líneas 576-580, 604, 632, 660: DeleteSQL para DetCapPropioSimpl y CapPropioSimplAnual
' Se ejecutan cuando ProPymeTransp y hay datos INR/Participaciones que no aplican
```

**NET:**
```csharp
// ❌ NO IMPLEMENTADO - No hay lógica de limpieza de datos por tipo empresa
```

**Estado:** ❌ **GAP CRÍTICO**
Falta la limpieza de registros de detalle cuando cambia tipo de empresa.

---

### ❌ 11. Stored Procedures
**VB6:**
```vb
' No usa stored procedures en este form
```

**NET:**
```csharp
// No usa stored procedures
```

**Estado:** ✅ **N/A**

---

### ✅ 12. Tablas accedidas
**VB6:**
- `EmpresasAno` (líneas 339, 463, 485)
- `DetCapPropioSimpl` (líneas 577, 604, etc.) - Tabla de detalle
- `CapPropioSimplAnual` (líneas 580, 607, etc.) - Acumulados anuales
- `Empresas` (implícito por gEmpresa)

**NET:**
- `EmpresasAno` ✅
- `DetCapPropioSimpl` ❌ NO ACCEDIDA
- `CapPropioSimplAnual` ❌ NO ACCEDIDA
- `Empresas` ✅

**Estado:** ⚠️ **PARCIAL** - Faltan 2 tablas relacionadas de detalle

---

### ✅ 13. Campos leídos
**VB6 lee 24 campos de EmpresasAno:**
- CPS_CapPropioTribAnoAnt
- CPS_CapitalAportado
- CPS_BaseImpPrimCat_14DN3
- CPS_BaseImpPrimCat_14DN8
- CPS_Participaciones
- CPS_Disminuciones
- CPS_GastosRechazados
- CPS_RetirosDividendos
- CPS_RepPerdidaArrastre
- CPS_CapPropioSimplificado
- CPS_CapPropioSimplVarAnual
- CPS_AumentosCapital
- CPS_INRPropios
- CPS_INRPropiosPerdidas
- CPS_OtrosAjustesAumentos
- CPS_OtrosAjustesDisminuciones
- CPS_UtilidadesPerdida
- CPS_IngresoDiferido
- CPS_CTDImputableIPE
- CPS_IncentivoAhorro
- CPS_IDPCVoluntario
- CPS_CredActFijos
- CPS_CredParticipaciones
- CPS_CapPropioTrib (de año anterior)

**NET lee 24 campos (líneas 43-66):**
Todos los campos VB6 ✅

**Estado:** ✅ **PARIDAD COMPLETA**

---

### ✅ 14. Campos escritos
**VB6 escribe 6 campos (líneas 341-355):**
- CPS_CapPropioSimplificado
- CPS_CapPropioSimplVarAnual
- CPS_BaseImpPrimCat_14DN3
- CPS_BaseImpPrimCat_14DN8
- CPS_CapPropioTribAnoAnt
- CPS_RepPerdidaArrastre

**NET escribe los mismos 6 campos (líneas 110-133):**
Todos ✅

**Estado:** ✅ **PARIDAD COMPLETA**

---

### ✅ 15. Transacciones
**VB6:**
```vb
' No usa transacciones explícitas (cada UPDATE es atómico)
```

**NET:**
```csharp
// SaveChangesAsync() maneja transacción implícita (línea 136)
```

**Estado:** ✅ **PARIDAD COMPLETA**

---

### ✅ 16. Concurrencia
**VB6:**
```vb
' No maneja bloqueos explícitos
```

**NET:**
```csharp
// EF Core optimistic concurrency (por defecto)
```

**Estado:** ✅ **PARIDAD COMPLETA**

**Paridad categoría:** 75% (7/10 aspectos OK, 1 parcial)

---

## 3️⃣ ACCIONES Y OPERACIONES (6 aspectos)

### ✅ 17. Botones/Acciones
**VB6:**
```vb
' Bt_Cerrar_Click       - línea 335 - Guardar y cerrar
' Bt_Preview_Click      - línea 905 - Vista previa impresión
' Bt_Print_Click        - línea 928 - Imprimir
' Bt_CopyExcel_Click    - línea 945 - Copiar a Excel
' Bt_Sum_Click          - línea 950 - Sumar seleccionados
' Bt_ConvMoneda_Click   - línea 960 - Convertir moneda
' Bt_Calc_Click         - línea 971 - Calculadora
' Bt_Calendar_Click     - línea 975 - Calendario
' Bt_Manual_Click       - línea 363 - Manual PDF (oculto)
```

**NET:**
```cshtml
<!-- Líneas 49-72: -->
<!-- cargarDatos()        - Cargar datos -->
<!-- window.print()       - Imprimir ✅ -->
<!-- exportarExcel()      - Exportar ✅ -->
<!-- guardarDatos()       - Guardar ✅ -->
<!-- cerrarFormulario()   - Cerrar ✅ -->
```

**Estado:** ⚠️ **PARCIAL**
- ✅ Cerrar, Imprimir, Exportar, Guardar existen
- ❌ FALTA: Bt_Sum (sumar seleccionados)
- ❌ FALTA: Bt_ConvMoneda (convertir moneda)
- ❌ FALTA: Bt_Calc (calculadora)
- ❌ FALTA: Bt_Calendar (calendario)
- ❌ FALTA: Bt_Manual (manual PDF)

---

### ✅ 18. Operaciones CRUD
**VB6:**
- **Ver:** FView() - línea 327 - ✅
- **Guardar:** bt_Cerrar_Click - línea 335 - ✅
- **No hay:** Nuevo, Eliminar (formulario de cálculo, no CRUD de registros)

**NET:**
- **Ver:** Index GET - línea 12 - ✅
- **Obtener datos:** Obtener API - línea 12 - ✅
- **Guardar:** Guardar API - línea 26 - ✅

**Estado:** ✅ **PARIDAD COMPLETA**

---

### ❌ 19. Operaciones especiales
**VB6:**
```vb
' Grid_DblClick - líneas 1050-1285 - Abrir formularios de detalle
' - FrmCapitalAportado (línea 1068)
' - FrmDetCapPropioSimpl con diferentes TipoDetCPS (líneas 1078-1280)
' - FrmBaseImponible14D (línea 1090)
' - FrmDetCapPropioSimplMini (línea 1268)
' Total: 21 items con drill-down a detalle
```

**NET:**
```javascript
// ❌ NO IMPLEMENTADO - No hay modales de detalle ni drill-down
```

**Estado:** ❌ **GAP CRÍTICO**
Falta toda la funcionalidad de drill-down a formularios de detalle.

---

### ❌ 20. Búsquedas
**VB6:**
```vb
' No tiene búsqueda (es formulario de cálculo/reporte)
```

**NET:**
```csharp
// No tiene búsqueda
```

**Estado:** ✅ **N/A**

---

### ✅ 21. Ordenamiento
**VB6:**
```vb
' No aplica (items en orden fijo predefinido)
```

**NET:**
```javascript
// No aplica (orden fijo)
```

**Estado:** ✅ **N/A**

---

### ✅ 22. Paginación
**VB6:**
```vb
' No aplica (reporte de ~20 líneas fijas)
```

**NET:**
```javascript
// No aplica
```

**Estado:** ✅ **N/A**

**Paridad categoría:** 58% (3/6 aspectos OK, 1 parcial)

---

## 4️⃣ VALIDACIONES (6 aspectos)

### ❌ 23. Campos requeridos
**VB6:**
```vb
' No hay validaciones explícitas de requeridos (todos opcionales)
```

**NET:**
```csharp
// No hay validaciones [Required]
```

**Estado:** ✅ **PARIDAD COMPLETA** (ninguno valida porque todos son opcionales)

---

### ❌ 24. Validación de rangos
**VB6:**
```vb
' CalcTot líneas 1314-1318: if Total < 0 Then Total = 0
' Grid_EditKeyPress línea 1328-1332: KeyNumPos (solo positivos) para RepPerdidaArrastre
' Grid_EditKeyPress línea 1330-1332: KeyNum (permite negativos) para CapPropioTribAnoAnt
```

**NET:**
```csharp
// Línea 188: if (total < 0) total = 0; ✅
// ❌ NO validación en inputs de que sean numéricos
// ❌ NO validación de rangos en frontend
```

**Estado:** ⚠️ **PARCIAL**
- ✅ Validación total >= 0
- ❌ FALTA: Validación KeyPress numérico en inputs

---

### ❌ 25. Validación de formato
**VB6:**
```vb
' KeyNumPos, KeyNum - validan entrada numérica en tiempo real (líneas 1329, 1331)
```

**NET:**
```javascript
// ❌ NO IMPLEMENTADO
// Los inputs son type="text", no type="number"
// No hay validación de formato en actualizarMonto() línea 330
```

**Estado:** ❌ **GAP MEDIO**
Falta validación de formato numérico en inputs.

---

### ❌ 26. Validación de longitud
**VB6:**
```vb
' No aplica (campos numéricos)
```

**NET:**
```csharp
// No aplica
```

**Estado:** ✅ **N/A**

---

### ❌ 27. Validaciones custom
**VB6:**
```vb
' Grid_BeforeEdit líneas 1035-1048:
' Solo permite editar RepPerdidaArrastre y CapPropioTribAnoAnt (si no hay año anterior)
' Resto de campos son NO editables directamente en grid
```

**NET:**
```javascript
// Línea 307-314: Todos los campos son editables si editable=true
// ❌ NO IMPLEMENTADO: Lógica de cuáles campos son editables según condiciones
```

**Estado:** ❌ **GAP CRÍTICO**
En VB6 la mayoría de campos NO son editables en el grid (solo vía doble-click a detalle).
En .NET todos aparecen como editables.

---

### ⚠️ 28. Manejo de nulos
**VB6:**
```vb
' vFld() para campos, IIf(Not Rs.EOF, ..., 0) - líneas 489, 512, 523, etc.
```

**NET:**
```csharp
// empresaAno.CPS_CapitalAportado ?? 0 - líneas 43-66
// Manejo adecuado con ?? operator
```

**Estado:** ✅ **PARIDAD COMPLETA**

**Paridad categoría:** 33% (1/6 aspectos OK, 2 parciales)

---

## 5️⃣ CÁLCULOS Y LÓGICA (5 aspectos)

### ✅ 29. Funciones de cálculo
**VB6:**
```vb
' CalcTot() - líneas 1286-1324
' Suma/resta todos los componentes según signo
```

**NET:**
```csharp
// CalcularTotalCPSAsync() - líneas 142-191
// Misma lógica de suma/resta
```

**Estado:** ✅ **PARIDAD COMPLETA**

---

### ✅ 30. Redondeos
**VB6:**
```vb
' Format(..., NUMFMT) - sin decimales (implícito enteros)
' vFmt() devuelve Double sin redondeo explícito
```

**NET:**
```csharp
// decimal sin redondeo explícito
// formatNumber() redondea con Math.round (línea 445)
```

**Estado:** ✅ **PARIDAD COMPLETA**

---

### ✅ 31. Campos calculados
**VB6:**
```vb
' Total calculado en CalcTot() línea 1286
' Actualiza Tx_TotCapPropio y Grid.TextMatrix líneas 1320-1322
```

**NET:**
```csharp
// BaseImponible (computed property línea 48)
// CapitalPropioSimplificado calculado (línea 88)
```

**Estado:** ✅ **PARIDAD COMPLETA**

---

### ⚠️ 32. Dependencias campos
**VB6:**
```vb
' Grid_AcceptValue líneas 1027-1033: Al cambiar valor → CalcTot()
' Recalcula total automáticamente
```

**NET:**
```javascript
// actualizarMonto() línea 330 → recalcularTotal() línea 333
// ⚠️ recalcularTotal() está vacío (línea 336-338 TODO)
```

**Estado:** ⚠️ **PARCIAL**
- ✅ Estructura existe
- ❌ FALTA: Implementar recalcularTotal()

---

### ✅ 33. Valores por defecto
**VB6:**
```vb
' Form_Load líneas 386-411: No asigna defaults (todo viene de BD)
```

**NET:**
```csharp
// Dto con defaults = 0 (líneas 22-28)
```

**Estado:** ✅ **PARIDAD COMPLETA**

**Paridad categoría:** 90% (4/5 aspectos OK, 1 parcial)

---

## 6️⃣ INTERFAZ Y UX (5 aspectos)

### ✅ 34. Combos/Listas
**VB6:**
```vb
' No tiene combos (solo grid con valores calculados)
```

**NET:**
```javascript
// Radio buttons para tipo informe (líneas 38-47)
```

**Estado:** ✅ **MEJORA** - UI más moderna con radio buttons

---

### ✅ 35. Mensajes usuario
**VB6:**
```vb
' Línea 399: MsgBox1 "Este informe se genera con comprobantes APROBADO"
' Línea 406: MsgBox1 sobre 14DN8 no obligatorio < 50.000 UF
' Línea 374: MsgBox1 "No se encontró Manual PDF"
```

**NET:**
```javascript
// Líneas 120-133: Advertencias en cards (siempre visibles)
// SweetAlert para errores (líneas 215-220, 362-367)
```

**Estado:** ✅ **MEJORA** - Mensajes informativos siempre visibles, mejores alertas

---

### ⚠️ 36. Confirmaciones
**VB6:**
```vb
' No tiene confirmaciones (guardar es automático al cerrar)
```

**NET:**
```javascript
// ❌ NO pide confirmación al guardar
// ⚠️ Debería pedir confirmación al cerrar sin guardar
```

**Estado:** ⚠️ **PARCIAL**
Falta confirmación "¿Desea guardar cambios?" al cerrar sin guardar.

---

### ✅ 37. Habilitaciones UI
**VB6:**
```vb
' Grid_BeforeEdit líneas 1035-1048:
' - Solo editable si TipoInforme = VariacionAnual
' - Solo RepPerdidaArrastre y CapPropioTribAnoAnt editables
' Resto requiere doble-click (abre modal)
```

**NET:**
```javascript
// Líneas 307-314: Todos marcados editable=true
// ❌ NO respeta lógica de qué campos son editables según TipoInforme
```

**Estado:** ❌ **GAP MEDIO**
Todos los campos son editables cuando no deberían serlo.

---

### ✅ 38. Formatos display
**VB6:**
```vb
' Format(..., NUMFMT) - formato numérico chileno (líneas 489, 512, etc.)
```

**NET:**
```javascript
// formatNumber() con Intl.NumberFormat('es-CL') - líneas 440-446
```

**Estado:** ✅ **PARIDAD COMPLETA**

**Paridad categoría:** 70% (3.5/5 aspectos OK)

---

## 7️⃣ SEGURIDAD (2 aspectos)

### ❌ 39. Permisos requeridos
**VB6:**
```vb
' No verifica permisos explícitos (asume usuario tiene acceso)
```

**NET:**
```csharp
// ❌ NO HAY [Authorize] en controllers
// ❌ NO verifica permisos
```

**Estado:** ❌ **GAP CRÍTICO**
Feature completamente sin control de permisos.

---

### ❌ 40. Validación acceso
**VB6:**
```vb
' No valida nivel de usuario
```

**NET:**
```csharp
// No valida acceso
```

**Estado:** ❌ **GAP CRÍTICO**
Sin validación de acceso.

**Paridad categoría:** 0% (0/2 aspectos OK)

---

## 8️⃣ MANEJO DE ERRORES (2 aspectos)

### ✅ 41. Captura errores
**VB6:**
```vb
' No tiene On Error explícito (confía en manejo global)
' Rc = ExistFile(Buf) línea 371 - verifica archivo antes de abrir
```

**NET:**
```csharp
// try/catch en guardarDatos() línea 340
// try/catch en exportarExcel() línea 372
// try/catch en cargarDatos() línea 200
```

**Estado:** ✅ **MEJORA** - Mejor manejo de errores en .NET

---

### ⚠️ 42. Mensajes de error
**VB6:**
```vb
' MsgBox1 "Error X al abrir archivo" línea 379
```

**NET:**
```javascript
// Swal.fire con mensajes descriptivos (líneas 215-220, 362-367)
// ⚠️ Mensaje genérico "Se produjo un error" podría ser más específico
```

**Estado:** ⚠️ **PARCIAL** - Buenos mensajes pero podrían ser más específicos

**Paridad categoría:** 75% (1/2 aspectos OK, 1 parcial)

---

## 9️⃣ OUTPUTS / SALIDAS (6 aspectos)

### ✅ 43. Datos de retorno
**VB6:**
```vb
' Actualiza EmpresasAno al cerrar (líneas 336-360)
' Variable lTotalCapPropioSimplificado (línea 325)
```

**NET:**
```csharp
// GuardarCPSAsync actualiza BD (líneas 94-140)
// Retorna confirmation message (línea 32)
```

**Estado:** ✅ **PARIDAD COMPLETA**

---

### ⚠️ 44. Exportar Excel
**VB6:**
```vb
' Bt_CopyExcel_Click línea 945: LP_FGr2Clip(Grid, Me.Caption)
' Copia grid completo al portapapeles para pegar en Excel
```

**NET:**
```javascript
// exportarExcel() líneas 371-429
// ⚠️ Exporta CSV, no formato Excel nativo
```

**Estado:** ⚠️ **PARCIAL**
- ✅ Funcionalidad de exportar existe
- ⚠️ CSV en lugar de Excel nativo (pero funcional)

---

### ❌ 45. Exportar PDF
**VB6:**
```vb
' Bt_Preview_Click línea 905: Vista previa con gPrtReportes
' Bt_Print_Click línea 928: Impresión directa
' Genera PDF vía PrtFlexGrid (líneas 916, 936)
```

**NET:**
```javascript
// window.print() línea 57
// ❌ NO genera PDF, solo imprime navegador
// ⚠️ Estilos @media print (líneas 454-515) pero no es PDF
```

**Estado:** ❌ **GAP MEDIO**
No hay generación de PDF real, solo impresión browser.

---

### ❌ 46. Exportar CSV/Texto
**VB6:**
```vb
' No exporta CSV (solo clipboard/Excel)
```

**NET:**
```javascript
// exportarExcel() genera CSV (líneas 383-410) ✅
```

**Estado:** ✅ **MEJORA** - .NET tiene CSV que VB6 no tenía

---

### ✅ 47. Impresión
**VB6:**
```vb
' SetUpPrtGrid líneas 987-1025: Configura impresión
' Titulos, Encabezados, ColWidth, formato
' Bt_Print_Click línea 928: Imprime
```

**NET:**
```javascript
// window.print() línea 57
// @media print estilos (líneas 454-515)
```

**Estado:** ✅ **PARIDAD COMPLETA** - Funcionalidad equivalente

---

### ❌ 48. Llamadas a otros módulos
**VB6:**
```vb
' Grid_DblClick líneas 1050-1285:
' - FrmCapitalAportado (línea 1068)
' - FrmDetCapPropioSimpl (líneas 1078, 1103, 1117, 1130, 1139, 1159, 1170, 1184, 1195, 1205, 1217, 1230, 1243, 1256)
' - FrmBaseImponible14D (línea 1090)
' - FrmDetCapPropioSimplMini (línea 1268)
' - FrmSumSimple (línea 953)
' - FrmConverMoneda (línea 964)
' - FrmCalendar (línea 979)
```

**NET:**
```javascript
// ❌ NO HAY llamadas a modales/componentes detalle
```

**Estado:** ❌ **GAP CRÍTICO**
Falta toda la integración con formularios de detalle.

**Paridad categoría:** 33% (2/6 aspectos OK)

---

## 🔟 PARIDAD DE CONTROLES UI (6 aspectos)

### ✅ 49. TextBoxes
**VB6:**
```vb
' Tx_CapPropio (línea 40) - Solo lectura, muestra título
' Tx_TotCapPropio (línea 60) - Solo lectura, muestra total
```

**NET:**
```cshtml
<!-- Línea 112: <span id="totalCPS"> muestra total ✅ -->
<!-- Línea 23: h1 muestra título ✅ -->
```

**Estado:** ✅ **PARIDAD COMPLETA**

---

### ✅ 50. Labels/Etiquetas
**VB6:**
```vb
' Label1(0) líneas 88-96: "Este informe se genera con APROBADO"
' Label1(1) líneas 98-106: "Recuerde presionar Aceptar"
' Labels en grid via Grid.TextMatrix(Row, C_TITULO)
```

**NET:**
```cshtml
<!-- Líneas 120-133: Advertencias en divs ✅ -->
<!-- Línea 92: th "Componente" ✅ -->
<!-- Línea 307: td con título componente ✅ -->
```

**Estado:** ✅ **PARIDAD COMPLETA**

---

### ❌ 51. ComboBoxes/Selects
**VB6:**
```vb
' No tiene combos
```

**NET:**
```cshtml
<!-- Radio buttons líneas 38-47 para tipo informe ✅ -->
```

**Estado:** ✅ **MEJORA** - .NET tiene selección de tipo que VB6 no tiene visible

---

### ✅ 52. Grids/Tablas
**VB6:**
```vb
' Grid FEd3Grid (línea 19) - Grid editable principal
' Grid1 MSFlexGrid (línea 266) - Grid oculto para impresión
' Configuración en SetUpGrid líneas 413-433
' 5 columnas: C_TITULO, C_MONTO, C_SIGNO, C_FMT, C_OBLIGATORIA
```

**NET:**
```cshtml
<!-- table líneas 88-106 ✅ -->
<!-- 3 columnas: Componente, Monto, Signo ✅ -->
<!-- tbody#bodyComponentes llenado con JS ✅ -->
```

**Estado:** ✅ **PARIDAD COMPLETA** - Funcionalidad equivalente

---

### ⚠️ 53. CheckBoxes
**VB6:**
```vb
' No tiene checkboxes
```

**NET:**
```cshtml
<!-- No tiene checkboxes -->
```

**Estado:** ✅ **N/A**

---

### ✅ 54. Campos ocultos/IDs
**VB6:**
```vb
' Grid.TextMatrix(Row, C_FMT) - Columna oculta con formato (línea 426)
' Grid.TextMatrix(Row, C_OBLIGATORIA) - Columna oculta marcador (línea 427)
' lRowCapAportado, lRowBaseImp, etc. - Variables con índices de fila
```

**NET:**
```javascript
// datosActuales (línea 165) - Objeto con todos los datos ✅
// empresaId, ano (líneas 163-164) - Constantes JS ✅
```

**Estado:** ✅ **PARIDAD COMPLETA**

**Paridad categoría:** 79% (4.5/6 aspectos OK)

---

## 1️⃣1️⃣ GRIDS Y COLUMNAS (2 aspectos)

### ✅ 55. Columnas del grid
**VB6:**
```vb
' C_TITULO (ancho 5600) - Nombre componente
' C_MONTO (ancho 1500) - Valor numérico
' C_SIGNO (ancho 400) - +, -, +/-
' C_FMT (ancho 0) - Oculta, formato
' C_OBLIGATORIA (ancho 0) - Oculta, marcador
```

**NET:**
```cshtml
<!-- th "Componente" (px-6) -->
<!-- th "Monto ($)" (width 200px) -->
<!-- th "Signo" (width 80px) -->
```

**Estado:** ✅ **PARIDAD COMPLETA** - Mismas columnas visibles

---

### ✅ 56. Datos del grid
**VB6:**
```vb
' LoadAll líneas 435-903: Llena grid con 21 componentes
' Orden fijo según lógica de negocio
```

**NET:**
```javascript
// renderizarComponentes() líneas 228-296
// Mismo orden y mismos componentes ✅
```

**Estado:** ✅ **PARIDAD COMPLETA**

**Paridad categoría:** 100% (2/2 aspectos OK)

---

## 1️⃣2️⃣ EVENTOS E INTERACCIÓN (5 aspectos)

### ✅ 57. Doble clic
**VB6:**
```vb
' Grid_DblClick líneas 1050-1285
' Abre formularios de detalle según fila clickeada
' 21 casos diferentes (Case lRowCapAportado, lRowBaseImp, etc.)
```

**NET:**
```javascript
// ❌ NO IMPLEMENTADO
// No hay eventos dblclick en la tabla
```

**Estado:** ❌ **GAP CRÍTICO**
Funcionalidad principal de drill-down falta completamente.

---

### ❌ 58. Teclas especiales
**VB6:**
```vb
' No implementa teclas especiales (F2, F3, etc.)
```

**NET:**
```javascript
// No implementa teclas especiales
```

**Estado:** ✅ **N/A**

---

### ⚠️ 59. Eventos Change
**VB6:**
```vb
' Grid_AcceptValue líneas 1027-1033: Al cambiar valor → CalcTot()
```

**NET:**
```javascript
// actualizarMonto() línea 330 → onchange
// ⚠️ recalcularTotal() vacío (línea 336)
```

**Estado:** ⚠️ **PARCIAL** - Evento existe pero función incompleta

---

### ❌ 60. Menú contextual
**VB6:**
```vb
' No tiene menú contextual
```

**NET:**
```javascript
// No tiene menú contextual
```

**Estado:** ✅ **N/A**

---

### ❌ 61. Modales Lookup
**VB6:**
```vb
' Grid_DblClick abre 21 modales diferentes (líneas 1050-1285)
' Flujo: DblClick → Set Frm = New FrmXXX → Frm.FEdit(..., valor) → If Rc = vbOK actualiza
```

**NET:**
```javascript
// ❌ NO IMPLEMENTADO
```

**Estado:** ❌ **GAP CRÍTICO**
Sistema completo de modales de detalle no existe.

**Paridad categoría:** 30% (1/5 aspectos OK, 1 parcial)

---

## 1️⃣3️⃣ ESTADOS Y MODOS DEL FORMULARIO (3 aspectos)

### ✅ 62. Modos del form
**VB6:**
```vb
' lTipoInforme = CPS_TIPOINFO_GENERAL (0) o CPS_TIPOINFO_VARANUAL (1)
' Línea 301, 327-333
' Afecta qué campos se muestran y calculan
```

**NET:**
```csharp
// TipoInformeCPS enum (líneas 3-7)
// tipoInforme parámetro (línea 12)
// Misma lógica condicional (líneas 70, 110, 130, 181)
```

**Estado:** ✅ **PARIDAD COMPLETA**

---

### ✅ 63. Controles por modo
**VB6:**
```vb
' If lTipoInforme = CPS_TIPOINFO_VARANUAL Then - líneas 479-502, 532-541
' Muestra filas adicionales: CPT año anterior, Reposición pérdida
' Grid_BeforeEdit líneas 1036-1046: Solo editable si VariacionAnual
```

**NET:**
```javascript
// if (datosActuales.tipoInforme === 1) - líneas 233-246
// Renderiza filas adicionales condicionalmente ✅
```

**Estado:** ✅ **PARIDAD COMPLETA**

---

### ✅ 64. Orden de tabulación
**VB6:**
```vb
' Grid TabIndex = 0 (línea 22)
' No se especifica orden explícito (default de VB6)
```

**NET:**
```cshtml
<!-- Orden natural del DOM -->
<!-- Radio buttons → botón Cargar → inputs tabla → botones acción -->
```

**Estado:** ✅ **PARIDAD COMPLETA**

**Paridad categoría:** 100% (3/3 aspectos OK)

---

## 1️⃣4️⃣ INICIALIZACIÓN Y CARGA (3 aspectos)

### ✅ 65. Carga inicial
**VB6:**
```vb
' Form_Load líneas 386-411:
' - SetUpGrid (línea 395)
' - LoadAll (línea 397)
' - MsgBox advertencias (líneas 399, 402-408)
```

**NET:**
```cshtml
<!-- NO carga automáticamente (línea 449 comentada) ✅ -->
<!-- Usuario debe seleccionar tipo y presionar "Cargar" ✅ -->
<!-- cargarDatos() línea 190 hace carga manual -->
```

**Estado:** ✅ **MEJORA** - Carga manual es mejor UX (no automática)

---

### ✅ 66. Valores por defecto
**VB6:**
```vb
' Todo viene de BD (líneas 463-893)
' No asigna defaults hardcodeados
```

**NET:**
```csharp
// new CapitalPropioSimplificadoDto con defaults = 0 (líneas 22-28)
```

**Estado:** ✅ **PARIDAD COMPLETA**

---

### ❌ 67. Llenado de combos
**VB6:**
```vb
' No tiene combos para llenar
```

**NET:**
```cshtml
<!-- No tiene combos -->
<!-- Radio buttons son estáticos (líneas 38-47) -->
```

**Estado:** ✅ **N/A**

**Paridad categoría:** 67% (2/3 aspectos OK)

---

## 1️⃣5️⃣ FILTROS Y BÚSQUEDA (2 aspectos)

### ❌ 68. Campos de filtro
**VB6:**
```vb
' No tiene filtros (formulario de cálculo único)
```

**NET:**
```cshtml
<!-- No tiene filtros -->
```

**Estado:** ✅ **N/A**

---

### ❌ 69. Criterios de búsqueda
**VB6:**
```vb
' No tiene búsqueda
```

**NET:**
```csharp
// No tiene búsqueda
```

**Estado:** ✅ **N/A**

**Paridad categoría:** 0% (N/A)

---

## 1️⃣6️⃣ REPORTES E IMPRESIÓN (2 aspectos)

### ✅ 70. Reportes disponibles
**VB6:**
```vb
' Bt_Preview_Click línea 905: Vista previa con PrtFlexGrid
' Bt_Print_Click línea 928: Impresión directa
' SetUpPrtGrid líneas 987-1025: Configura reporte
' Titulos: "Capital Propio Tributario Simplificado General/Variación Anual"
' Encabezado: "Al 31 de Diciembre {año}"
```

**NET:**
```javascript
// window.print() línea 57
// @media print estilos líneas 454-515
// body::before genera título (líneas 488-495)
```

**Estado:** ✅ **PARIDAD COMPLETA**

---

### ❌ 71. Parámetros de reporte
**VB6:**
```vb
' SetUpPrtGrid recibe:
' - lTipoInforme → Cambia título (líneas 998-1004)
' - gEmpresa.Ano → En encabezado (línea 1007)
' - Grid → Datos a imprimir (línea 996)
```

**NET:**
```javascript
// ❌ NO se pasa año ni tipo explícitamente a impresión
// ⚠️ Imprime lo que ve en pantalla (correcto) pero sin parámetros dinámicos
```

**Estado:** ❌ **GAP MENOR**
Falta pasar parámetros explícitos (año, tipo) al título de impresión.

**Paridad categoría:** 50% (1/2 aspectos OK)

---

## 1️⃣7️⃣ REGLAS DE NEGOCIO (4 aspectos)

### ✅ 72. Umbrales y límites
**VB6:**
```vb
' Total >= 0: líneas 1314-1318
```

**NET:**
```csharp
// if (total < 0) total = 0; línea 188
```

**Estado:** ✅ **PARIDAD COMPLETA**

---

### ✅ 73. Fórmulas de cálculo
**VB6:**
```vb
' CalcTot líneas 1286-1324:
' Total = CapAportado + Aumentos + BaseImp + Participaciones
'       - UtilidadesPerdida - Disminuciones - GastosRechazados
'       - RetDiv + INRPropios - INRPropiosPerdidas
'       + OtrosAjustes+ - OtrosAjustes-
'       - IngresoDiferido - CTDImputableIPE
'       + IncentivoAhorro + IDPCVoluntario
'       - CredActFijos - CredParticipaciones
'       + [CapPropioTribAnoAnt + RepPerdidaArrastre si VariacionAnual]
```

**NET:**
```csharp
// CalcularTotalCPSAsync líneas 142-191
// Misma fórmula exacta ✅
```

**Estado:** ✅ **PARIDAD COMPLETA**

---

### ✅ 74. Condiciones de negocio
**VB6:**
```vb
' If gEmpresa.ProPymeGeneral Then - líneas 548, 558, 585, 612, 640, 743, 769
'   → Usa 14DN3, muestra INRPropios, Participaciones, Incentivos, IDPC
' ElseIf gEmpresa.ProPymeTransp Then - líneas 573, 600, 628, 656, 757, 783, 795, 821
'   → Usa 14DN8, muestra CredActFijos, CredParticipaciones
' If lTipoInforme = VariacionAnual Then - líneas 479, 532, 1308
'   → Muestra CPT año anterior, Reposición pérdida
' If gEmpresa.Ano > 2021 And ProPymeTransp Then - líneas 726-740
'   → NO muestra CTDImputableIPE
```

**NET:**
```csharp
// if (datos.EsProPymeGeneral) líneas 158-171 ✅
// if (datos.EsProPymeTransparente) líneas 174-178 ✅
// if (datos.TipoInforme == VariacionAnual) líneas 70, 130, 181 ✅
// if (datos.Ano <= 2021) línea 167 ✅ (lógica invertida correcta)
```

**Estado:** ✅ **PARIDAD COMPLETA**

---

### ✅ 75. Restricciones
**VB6:**
```vb
' Grid_BeforeEdit líneas 1036-1046:
' Solo permite editar RepPerdidaArrastre y CapPropioTribAnoAnt
' Resto NO editable directamente (requiere doble-click a detalle)
```

**NET:**
```javascript
// ⚠️ Todos los campos marcados editable=true (línea 239, 241, etc.)
// ❌ NO respeta restricción de edición directa
```

**Estado:** ⚠️ **PARCIAL**
- ✅ Restricción de negocio identificada
- ❌ FALTA: Implementar restricción en UI

**Paridad categoría:** 100% (4/4 aspectos OK)

---

## 1️⃣8️⃣ FLUJOS DE TRABAJO (3 aspectos)

### ✅ 76. Secuencia de estados
**VB6:**
```vb
' Flujo simple:
' 1. Abrir formulario (FView)
' 2. Ver datos calculados (LoadAll)
' 3. [Opcional] Editar detalles (DblClick)
' 4. Cerrar y guardar (bt_Cerrar_Click)
```

**NET:**
```javascript
// Flujo:
// 1. Cargar vista (Index)
// 2. Seleccionar tipo y presionar Cargar (cargarDatos)
// 3. Ver datos
// 4. [Opcional] Editar valores
// 5. Guardar (guardarDatos)
// 6. Cerrar (cerrarFormulario)
```

**Estado:** ✅ **PARIDAD COMPLETA** - Flujo equivalente

---

### ⚠️ 77. Acciones por estado
**VB6:**
```vb
' Todas las acciones disponibles siempre:
' - Preview, Print, CopyExcel, Sum, ConvMoneda, Calc, Calendar
' - DblClick para editar detalles
' - Cerrar (guarda automático)
```

**NET:**
```javascript
// Estado inicial: Solo "Cargar" habilitado (líneas 138-156) ✅
// Estado cargado: Todas las acciones (líneas 49-72) ✅
// ❌ NO deshabilita "Guardar" si no hay cambios
```

**Estado:** ⚠️ **PARCIAL**
- ✅ Estados visibles diferentes
- ❌ Falta deshabilitar acciones según estado

---

### ✅ 78. Transiciones válidas
**VB6:**
```vb
' Inicial → Cargado (automático en Form_Load)
' Cargado → Guardado (bt_Cerrar_Click)
```

**NET:**
```javascript
// Inicial → Cargado (manual con cargarDatos)
// Cargado → Guardado (manual con guardarDatos)
```

**Estado:** ✅ **PARIDAD COMPLETA**

**Paridad categoría:** 83% (2/3 aspectos OK, 1 parcial)

---

## 1️⃣9️⃣ INTEGRACIONES ENTRE MÓDULOS (3 aspectos)

### ❌ 79. Llamadas a otros módulos
**VB6:**
```vb
' Grid_DblClick líneas 1050-1285 llama a:
' 1. FrmCapitalAportado.FEdit(valor) - línea 1068
' 2. FrmDetCapPropioSimpl.FEdit(TipoDetCPS, codigo, tipoInforme, valor) - 14 llamadas
' 3. FrmBaseImponible14D.FEdit(tipoInforme, valor) - línea 1090
' 4. FrmDetCapPropioSimplMini.FEdit(TipoDetCPS, tipoInforme, valor) - línea 1271
' 5. FrmSumSimple.FViewSum(Grid) - línea 955
' 6. FrmConverMoneda.FView(valor) - línea 965
' 7. FrmCalendar.SelDate(Fecha) - línea 981
```

**NET:**
```javascript
// ❌ NO HAY llamadas a modales/componentes
```

**Estado:** ❌ **GAP CRÍTICO**
Falta integración completa con 7 módulos diferentes.

---

### ❌ 80. Parámetros de integración
**VB6:**
```vb
' FrmDetCapPropioSimpl.FEdit recibe:
' - TipoDetCPS (CPS_PARTICIPACIONES, CPS_AUMENTOSCAP, etc.)
' - codigo (893, 629, 894, 990, etc.) - Código de ayuda
' - lTipoInforme
' - ByRef valor (retorna valor calculado)
```

**NET:**
```javascript
// ❌ NO IMPLEMENTADO
```

**Estado:** ❌ **GAP CRÍTICO**

---

### ❌ 81. Datos compartidos/retorno
**VB6:**
```vb
' If Rc = vbOK Then Grid.TextMatrix(Row, C_MONTO) = Format(valor, NUMFMT)
' Parámetro ByRef valor es modificado por modal
' Líneas 1072-1074, 1082-1084, etc.
```

**NET:**
```javascript
// ❌ NO IMPLEMENTADO
```

**Estado:** ❌ **GAP CRÍTICO**
Sistema completo de paso de parámetros/retorno falta.

**Paridad categoría:** 0% (0/3 aspectos OK)

---

## 2️⃣0️⃣ MENSAJES AL USUARIO (2 aspectos)

### ✅ 82. Mensajes de error
**VB6:**
```vb
' MsgBox1 "No se encontró Manual PDF" - línea 374
' MsgBox1 "Error X al abrir archivo" - línea 379
```

**NET:**
```javascript
// Swal.fire "Error al Cargar" líneas 215-220
// Swal.fire "Error al Guardar" líneas 362-367
// Swal.fire "Error exportar" líneas 421-428
```

**Estado:** ✅ **MEJORA** - Mensajes más amigables con SweetAlert

---

### ⚠️ 83. Mensajes de confirmación
**VB6:**
```vb
' No pide confirmación (guardar es automático al cerrar)
```

**NET:**
```javascript
// No pide confirmación al guardar
// ⚠️ Debería preguntar "¿Guardar cambios?" al cerrar si hay cambios
```

**Estado:** ⚠️ **PARCIAL**
Falta confirmación antes de acciones destructivas.

**Paridad categoría:** 75% (1/2 aspectos OK, 1 parcial)

---

## 2️⃣1️⃣ CASOS BORDE Y VALORES ESPECIALES (3 aspectos)

### ✅ 84. Valores cero
**VB6:**
```vb
' Permite valores = 0 (no valida)
' CalcTot acepta componentes en 0
```

**NET:**
```csharp
// Permite valores = 0 (defaults a 0)
```

**Estado:** ✅ **PARIDAD COMPLETA**

---

### ✅ 85. Valores negativos
**VB6:**
```vb
' CapPropioTribAnoAnt permite negativos (KeyNum línea 1331)
' RepPerdidaArrastre solo positivos (KeyNumPos línea 1329)
' Total si < 0 → 0 (líneas 1314-1318)
```

**NET:**
```csharp
// Total si < 0 → 0 (línea 188) ✅
// ⚠️ NO valida en inputs si deben ser positivos o permiten negativos
```

**Estado:** ⚠️ **PARCIAL**
- ✅ Total >= 0 validado
- ❌ Falta validar inputs individuales

---

### ✅ 86. Valores nulos/vacíos
**VB6:**
```vb
' IIf(Not Rs.EOF, Format(vFld(Rs("campo")), NUMFMT), 0)
' vFld maneja nulos → 0
```

**NET:**
```csharp
// empresaAno.CPS_CapitalAportado ?? 0
// Manejo correcto con null-coalescing
```

**Estado:** ✅ **PARIDAD COMPLETA**

**Paridad categoría:** 83% (2/3 aspectos OK, 1 parcial)

---

## 📊 RESUMEN DE GAPS

### 🔴 Gaps Críticos (Bloquean funcionalidad core)

| # | Gap | VB6 | .NET | Impacto |
|---|-----|-----|------|---------|
| 1 | **Grid_DblClick - Drill-down a detalles** | 21 formularios modales de detalle (líneas 1050-1285) | ❌ NO IMPLEMENTADO | **CRÍTICO** - Usuario no puede ver/editar detalles de componentes |
| 2 | **Integraciones con módulos** | 7 módulos integrados (Capital Aportado, Base Imponible, Detalle CPS, etc.) | ❌ NO IMPLEMENTADO | **CRÍTICO** - Funcionalidad principal falta |
| 3 | **Limpieza de datos por tipo empresa** | DeleteSQL DetCapPropioSimpl/CapPropioSimplAnual (líneas 577-843) | ❌ NO IMPLEMENTADO | **CRÍTICO** - Puede mostrar datos incorrectos según tipo empresa |
| 4 | **Control de permisos** | Asume usuario tiene acceso | ❌ NO HAY [Authorize] ni validación | **CRÍTICO** - Feature sin seguridad |
| 5 | **Validación de edición directa** | Solo 2 campos editables directamente (líneas 1036-1046) | Todos editables | **CRÍTICO** - Usuario puede corromper datos editando campos calculados |

---

### 🟠 Gaps Medios (Funcionalidad secundaria afectada)

| # | Gap | VB6 | .NET | Impacto |
|---|-----|-----|------|---------|
| 6 | **Exportar PDF** | Genera PDF vía PrtFlexGrid | Solo window.print() | **MEDIO** - Falta generación de PDF real |
| 7 | **Validación formato numérico** | KeyNum/KeyNumPos en tiempo real | No valida formato en inputs | **MEDIO** - Usuario puede ingresar texto |
| 8 | **Herramientas auxiliares** | Calculadora, Convertir Moneda, Calendario, Suma | ❌ NO IMPLEMENTADO | **MEDIO** - UX menos rica |
| 9 | **Manual PDF** | Bt_Manual abre PDF ayuda | ❌ NO IMPLEMENTADO | **MEDIO** - Falta documentación en línea |
| 10 | **recalcularTotal()** | CalcTot() funcional | Función vacía (TODO línea 336) | **MEDIO** - No actualiza total al editar |

---

### 🟡 Gaps Menores (UX diferente, workarounds existen)

| # | Gap | VB6 | .NET | Impacto |
|---|-----|-----|------|---------|
| 11 | **Confirmación al cerrar** | Guarda automático | No pide confirmación | **MENOR** - Riesgo de pérdida datos |
| 12 | **Parámetros de reporte** | Títulos dinámicos con año/tipo | Título estático en impresión | **MENOR** - Estético |
| 13 | **Deshabilitar acciones por estado** | Todas siempre disponibles | Todas siempre disponibles | **MENOR** - UX podría mejorar |
| 14 | **Exportar Excel nativo** | Clipboard para pegar en Excel | CSV descargable | **MENOR** - CSV funciona igual |

---

### ✅ Mejoras sobre VB6

| # | Mejora | Descripción |
|---|--------|-------------|
| 1 | **Carga manual vs automática** | .NET requiere seleccionar tipo y presionar "Cargar" (mejor UX que carga automática) |
| 2 | **Mensajes siempre visibles** | Advertencias APROBADO/Aceptar siempre visibles (mejor que MsgBox una sola vez) |
| 3 | **SweetAlert vs MsgBox** | Alertas modernas más amigables |
| 4 | **Exportar CSV** | .NET tiene CSV que VB6 no tenía |
| 5 | **Arquitectura API** | Separación Controller/Service/Dto vs lógica en form |
| 6 | **Async/Await** | Mejor manejo asíncrono que OpenRs bloqueante |
| 7 | **Responsive design** | Tabla adaptable vs grid fijo |
| 8 | **Estilos @media print** | Impresión estilizada vs impresión básica |

---

## ✅ CONCLUSIÓN

### Veredicto Final
**Estado:** 🟠 **NO ACEPTABLE PARA PRODUCCIÓN**
**Paridad:** 60.5% (52/86 aspectos OK o parciales)

### Análisis de Riesgo

#### 🔴 Bloqueadores de Release (5 gaps críticos)
1. **Drill-down a detalles** - Funcionalidad CORE faltante
2. **Integraciones módulos** - 7 módulos sin integrar
3. **Limpieza datos tipo empresa** - Riesgo integridad datos
4. **Seguridad** - Sin control de acceso
5. **Validación edición** - Riesgo corrupción datos

#### 🟠 Recomendaciones

**Prioridad ALTA (antes de release):**
1. Implementar sistema de modales para drill-down (Gap #1)
2. Integrar módulos FrmCapitalAportado, FrmBaseImponible14D, FrmDetCapPropioSimpl (Gap #2)
3. Agregar [Authorize] y validación de permisos (Gap #4)
4. Implementar validación de campos editables vs solo-lectura (Gap #5)
5. Implementar recalcularTotal() (Gap #10)

**Prioridad MEDIA (post-release):**
1. Agregar generación PDF real (Gap #6)
2. Validar formato numérico en inputs (Gap #7)
3. Agregar herramientas auxiliares (Calculadora, etc.) (Gap #8)
4. Implementar limpieza datos por tipo empresa (Gap #3)

**Prioridad BAJA (opcional):**
1. Confirmación al cerrar (Gap #11)
2. Parámetros dinámicos en impresión (Gap #12)
3. Manual PDF integrado (Gap #9)

### Esfuerzo Estimado para Paridad Completa

| Fase | Gaps a Resolver | Esfuerzo | Días Dev |
|------|----------------|----------|----------|
| **Fase 1: Críticos** | 5 gaps críticos | **ALTO** | 15-20 días |
| **Fase 2: Medios** | 5 gaps medios | **MEDIO** | 8-10 días |
| **Fase 3: Menores** | 4 gaps menores | **BAJO** | 3-5 días |
| **TOTAL** | 14 gaps | | **26-35 días** |

### Paridad por Categoría (Top 5 peores)

1. 🔴 **Seguridad:** 0% - Sin implementar
2. 🔴 **Filtros/Búsqueda:** 0% (N/A)
3. 🔴 **Integraciones:** 0% - Gap crítico
4. 🟠 **Eventos/Interacción:** 30% - Falta drill-down
5. 🟠 **Validaciones:** 33% - Faltan validaciones clave

### Paridad por Categoría (Top 5 mejores)

1. ✅ **Grids y Columnas:** 100%
2. ✅ **Estados y Modos:** 100%
3. ✅ **Reglas de Negocio:** 100%
4. ✅ **Cálculos y Lógica:** 90%
5. ✅ **Flujos de Trabajo:** 83%

---

**Generado por:** Claude Code (Análisis automatizado VB6 → .NET)
**Metodología:** D:\auditoria-gaps.md (86 aspectos)
**Fecha:** 28 de noviembre de 2025
