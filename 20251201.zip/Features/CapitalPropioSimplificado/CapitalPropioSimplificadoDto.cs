namespace App.Features.CapitalPropioSimplificado;

public enum TipoInformeCPS
{
    General = 0,
    VariacionAnual = 1
}

public class CapitalPropioSimplificadoDto
{
    // Info b�sica
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public TipoInformeCPS TipoInforme { get; set; }
    public bool EsProPymeGeneral { get; set; }
    public bool EsProPymeTransparente { get; set; }

    // Componentes base (siempre)
    public decimal CapitalAportado { get; set; }
    public decimal AumentosCapital { get; set; }
    public decimal BaseImponible14DN3 { get; set; }
    public decimal BaseImponible14DN8 { get; set; }
    public decimal DisminucionesCapital { get; set; }
    public decimal GastosRechazados { get; set; }
    public decimal RetirosDividendos { get; set; }
    public decimal IngresoDiferido { get; set; }
    public decimal OtrosAjustesAumentos { get; set; }
    public decimal OtrosAjustesDisminuciones { get; set; }

    // Solo Pro Pyme General
    public decimal INRPropios { get; set; }
    public decimal INRPropiosPerdidas { get; set; }
    public decimal Participaciones { get; set; }
    public decimal UtilidadesPerdida { get; set; }
    public decimal CTDImputableIPE { get; set; }
    public decimal IncentivoAhorro { get; set; }
    public decimal IDPCVoluntario { get; set; }

    // Solo Pro Pyme Transparente
    public decimal CredActFijos { get; set; }
    public decimal CredParticipaciones { get; set; }

    // Solo Variaci�n Anual
    public decimal CapPropioTribAnoAnt { get; set; }
    public decimal RepPerdidaArrastre { get; set; }

    // Calculados
    public decimal BaseImponible => EsProPymeGeneral ? BaseImponible14DN3 : BaseImponible14DN8;
    public decimal CapitalPropioSimplificado { get; set; }
}

public class ComponenteCPSDto
{
    public string Titulo { get; set; } = string.Empty;
    public decimal Monto { get; set; }
    public string Signo { get; set; } = string.Empty; // "+", "-", "+/-"
    public bool Editable { get; set; }
    public bool Visible { get; set; } = true;
    public string Campo { get; set; } = string.Empty;
}