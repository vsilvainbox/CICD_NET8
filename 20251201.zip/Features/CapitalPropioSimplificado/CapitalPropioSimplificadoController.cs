using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Extensions;

namespace App.Features.CapitalPropioSimplificado;

public class CapitalPropioSimplificadoController(
    ILogger<CapitalPropioSimplificadoController> logger,
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator) : Controller
{
    public IActionResult Index(TipoInformeCPS tipoInforme = TipoInformeCPS.General)
    {
        logger.LogInformation("Cargando vista Capital Propio Simplificado");

            
        ViewData["TipoInforme"] = (int)tipoInforme;

        return View();
    }

    /// <summary>
    /// Proxy MVC: Obtener Capital Propio Simplificado
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Obtener(int empresaId, short ano, int tipoInforme)
    {
        logger.LogInformation("MVC Proxy: Obtener CPS - EmpresaId: {EmpresaId}, Ano: {Ano}, TipoInforme: {TipoInforme}",
            empresaId, ano, tipoInforme);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<CapitalPropioSimplificadoApiController>(
            HttpContext,
            nameof(CapitalPropioSimplificadoApiController.Obtener),
            new { empresaId, ano, tipoInforme });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Proxy MVC: Guardar Capital Propio Simplificado
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Guardar([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: Guardar CPS");

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<CapitalPropioSimplificadoApiController>(
            HttpContext,
            nameof(CapitalPropioSimplificadoApiController.Guardar));
        var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }
}