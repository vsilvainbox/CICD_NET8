# Análisis de Balance Ejecutivo (FrmBalClasifEjec.frm)

## 1. PROPÓSITO DEL FORMULARIO

El formulario `FrmBalClasifEjec` genera un **Balance General Clasificado en formato ejecutivo** para presentación gerencial. Características principales:

- Formato paralelo: Activos a la izquierda, Pasivos a la derecha
- Agrupación por Circulante/No Circulante
- Filtros: Fecha, Tipo Ajuste, Área de Negocio, Centro de Costo, Nivel de cuentas
- Opción de mostrar solo saldos vigentes (oculta cuentas con saldo cero)
- Incluye cálculo automático de Resultado del Ejercicio en Patrimonio
- Exportación a Excel y envío por correo
- Impresión con pie de firma

## 2. DATOS Y ESTRUCTURAS

### Entidades Involucradas

#### Comprobante
- Fecha: Rango de fechas del reporte
- TipoAjuste: Financiero/Tributario/Ambos
- Estado: Para Libro Oficial solo Aprobados

#### MovComprobante
- IdAreaNeg: Filtro opcional
- IdCCosto: Filtro opcional
- Debe/Haber: Movimientos contables

#### Cuentas
- Codigo: Código de cuenta
- Descripcion: Nombre de cuenta
- Nivel: Jerarquía de cuentas (1-5)
- Clasificacion: ACTIVO/PASIVO/RESULTADO

### Constantes de Columnas

```vb
' Grid principal (invisible)
C_CODIGO = 0         ' Código cuenta
C_CUENTA = 1         ' Descripción cuenta
C_VALOR = 2          ' Saldo calculado
C_NIVEL = 3          ' Nivel jerárquico
C_IDCUENTA = 4       ' ID cuenta
C_CLASCTA = 5        ' Clasificación
C_DEBITOS = 6        ' Total débitos (hidden)
C_CREDITOS = 7       ' Total créditos (hidden)
C_INTER = 8          ' Columna intermedia separador
C_CODIGO_P = 9       ' Código cuenta Pasivo
C_CUENTA_P = 10      ' Descripción cuenta Pasivo
C_VALOR_P = 11       ' Saldo Pasivo
C_NIVEL_P = 12       ' Nivel Pasivo
C_IDCUENTA_P = 13    ' ID cuenta Pasivo
C_CLASCTA_P = 14     ' Clasificación Pasivo
C_DEBITOS_P = 15     ' Débitos Pasivo (hidden)
C_CREDITOS_P = 16    ' Créditos Pasivo (hidden)
C_FMT = 17           ' Formato (hidden)
```

## 3. OPERACIONES PRINCIPALES

### 3.1. Generación del Reporte (LoadAll)

**Proceso**:

1. **Construcción de Query SQL**:
   - Llama a `GenQueryPorNiveles()` con filtros
   - Agrupa movimientos por cuenta hasta el nivel seleccionado
   - Filtra por fecha, tipo ajuste, área negocio, centro costo

2. **Carga en Grid Principal** (invisible):
   - Recorre cuentas ordenadas jerárquicamente
   - Calcula totales por nivel (Debe - Haber)
   - Identifica cuentas especiales:
     - Activo Circulante/Corriente
     - Total Activos
     - Pasivo Circulante/Corriente
     - Total Pasivos
     - Patrimonio
   - Inserta línea de Resultado del Ejercicio si corresponde

3. **Cálculo de Saldos**:
   - Activos: Debe - Haber
   - Pasivos: Haber - Debe
   - Resultado Ejercicio: Total Activos - Total Pasivos

4. **Generación de Grid Paralelo** (visible):
   - Llama a `SetParallelGrid_SinValCero()` o `SetParallelGrid_ConValCero()`
   - Distribuye cuentas en dos columnas (Activo | Pasivo)
   - Alinea cuentas circulantes y no circulantes
   - Rellena espacios vacíos para alineación

### 3.2. Grid Paralelo Sin Valores Cero

**Función**: `SetParallelGrid_SinValCero()`

Proceso:

1. Identifica filas clave:
   - `RowActCirculante`: Total Activo Circulante
   - `RowPasCirculante`: Total Pasivo Circulante
   - `RowActTotal`: Total Activos
   - `RowPasTotal`: Total Pasivos

2. Cuenta líneas visibles (saldo ≠ 0):
   - `NActCirculante`: # líneas activo circulante
   - `NPasCirculante`: # líneas pasivo circulante

3. Copia cuentas con saldo > 0:
   - Lado izquierdo: Activos (columnas 0-7)
   - Lado derecho: Pasivos (columnas 9-16)

4. Rellena espacios vacíos para alinear totales

5. Aplica formatos:
   - Negrita para totales
   - Colores según nivel (gColores array)

### 3.3. Grid Paralelo Con Valores Cero

**Función**: `SetParallelGrid_ConValCero()`

Similar a Sin Valores Cero pero:
- No filtra por saldo
- Copia todas las cuentas
- Mantiene alineación fija

### 3.4. Impresión

**Configuración**:
- Orientación: Horizontal (Landscape)
- Encabezado:
  - Título: "Balance General Clasificado"
  - Subtítulo: Rango de fechas
  - Filtros activos (Área Negocio, Centro Costo)
- Pie de página: Firma (Contador, Rep. Legal) si está configurada

**Función**: `PrtPieBalanceFirma()`

### 3.5. Exportación

- **Excel**: `LP_FGr2Clip_Membr()` - Copia con formato membrete
- **Email**: `Export_SendEmail()` - Genera archivo adjunto y abre diálogo

## 4. REGLAS DE NEGOCIO

### 4.1. Clasificación de Cuentas

- **CLASCTA_ACTIVO** (1): Activos
- **CLASCTA_PASIVO** (2): Pasivos
- **CLASCTA_RESULTADO** (3): Resultado (no se muestra, solo para cálculo)

### 4.2. Tipos de Ajuste

- **TAJUSTE_FINANCIERO** (1): Ajustes financieros
- **TAJUSTE_TRIBUTARIO** (2): Ajustes tributarios
- **TAJUSTE_AMBOS** (3): Ambos tipos

Si se selecciona Financiero: incluye NULL y tipos 1 y 3
Si se selecciona Tributario: incluye tipos 2 y 3

### 4.3. Libro Oficial

Si está activado:
- Solo comprobantes Aprobados (no Pendientes)
- No imprime fecha en reporte
- Registra en log de impresiones
- Deshabilita filtros de Área Negocio y Centro de Costo

### 4.4. Resultado del Ejercicio

Se calcula automáticamente:
```
Resultado = Total Activos - Total Pasivos
```

Se inserta en la jerarquía de Patrimonio si existe la cuenta de Resultado del Ejercicio definida en configuración básica.

### 4.5. Alineación de Cuentas

**Reglas de alineación vertical**:
- Activo Circulante se alinea con Pasivo Circulante
- Total Activo Circulante se alinea con Total Pasivo Circulante
- Total Activos se alinea con Total Pasivos
- Se rellenan espacios vacíos entre secciones

## 5. MAPEO A .NET 9

### DTOs Necesarios

```csharp
public class BalanceEjecutivoDto
{
    public DateTime FechaDesde { get; set; }
    public DateTime FechaHasta { get; set; }
    public int TipoAjuste { get; set; }
    public int? IdAreaNegocio { get; set; }
    public int? IdCentroCosto { get; set; }
    public int Nivel { get; set; }
    public bool LibroOficial { get; set; }
    public bool SaldosVigentes { get; set; }
}

public class CuentaBalanceDto
{
    public int IdCuenta { get; set; }
    public string Codigo { get; set; }
    public string Descripcion { get; set; }
    public int Nivel { get; set; }
    public int Clasificacion { get; set; }
    public decimal Debe { get; set; }
    public decimal Haber { get; set; }
    public decimal Saldo { get; set; }
    public bool EsTotal { get; set; }
    public string Formato { get; set; } // "B" = Bold, "C{color}" = Color
}

public class BalanceEjecutivoResultadoDto
{
    public List<CuentaBalanceDto> Activos { get; set; }
    public List<CuentaBalanceDto> Pasivos { get; set; }
    public decimal TotalActivos { get; set; }
    public decimal TotalPasivos { get; set; }
    public decimal ResultadoEjercicio { get; set; }
}
```

### Service Interface

```csharp
public interface IBalanceEjecutivoService
{
    Task<BalanceEjecutivoResultadoDto> GenerarBalanceAsync(BalanceEjecutivoDto filtros);
    Task<byte[]> ExportarExcelAsync(BalanceEjecutivoDto filtros);
    Task<byte[]> ExportarPdfAsync(BalanceEjecutivoDto filtros);
}
```

### Endpoints API

```
POST /api/balance-ejecutivo/generar       - Genera balance con filtros
POST /api/balance-ejecutivo/exportar/excel - Exporta a Excel
POST /api/balance-ejecutivo/exportar/pdf   - Exporta a PDF
```

### Vista MVC

**Ruta**: `/BalanceEjecutivo/Index`

**Componentes**:

1. **Frame de Filtros**:
   - Fecha Desde/Hasta (date pickers)
   - Tipo Ajuste (dropdown)
   - Nivel de cuentas (dropdown 2-5)
   - Área de Negocio (dropdown opcional)
   - Centro de Costo (dropdown opcional)
   - ☐ Libro Oficial
   - ☐ Saldos Vigentes (oculta cuentas con saldo 0)
   - Botón "Listar"

2. **Grid Paralelo**:
   - Columna izquierda: ACTIVOS
     - Código | Cuenta | Saldo
   - Columna separadora (vacía, 60px)
   - Columna derecha: PASIVOS
     - Código | Cuenta | Saldo

3. **Toolbar**:
   - Ver Libro Mayor (doble-click en cuenta)
   - Vista Previa
   - Imprimir
   - Copiar a Excel
   - Enviar por Email
   - Sumar seleccionados
   - Calculadora
   - Convertir Moneda
   - Calendario
   - ☐ Ver Código Cuenta
   - Cerrar

4. **Estilos**:
   - Totales en negrita
   - Colores por nivel según configuración
   - Indentación según nivel (2 espacios por nivel)

## 6. CONSIDERACIONES TÉCNICAS

### 6.1. Query SQL Compleja

La función `GenQueryPorNiveles()` genera un SQL dinámico que:
- Agrupa movimientos por cuenta
- Considera jerarquía de niveles
- Filtra por múltiples criterios
- Calcula totales acumulados

En .NET, se puede replicar con:
```csharp
var query = from mc in _context.MovComprobante
            join c in _context.Comprobante on mc.IdCompr equals c.IdCompr
            join ct in _context.Cuentas on mc.IdCuenta equals ct.IdCuenta
            where c.Fecha >= fechaDesde && c.Fecha <= fechaHasta
                  && c.IdEmpresa == idEmpresa
                  && ct.Nivel <= nivelMax
            group mc by new { ct.IdCuenta, ct.Codigo, ct.Descripcion, ct.Nivel, ct.Clasificacion }
            into g
            select new CuentaBalanceDto
            {
                IdCuenta = g.Key.IdCuenta,
                Codigo = g.Key.Codigo,
                Descripcion = g.Key.Descripcion,
                Nivel = g.Key.Nivel,
                Clasificacion = g.Key.Clasificacion,
                Debe = g.Sum(x => x.Debe ?? 0),
                Haber = g.Sum(x => x.Haber ?? 0)
            };
```

### 6.2. Cálculo de Jerarquías

Requiere algoritmo recursivo para:
- Acumular totales de hijos a padres
- Identificar niveles superiores
- Insertar líneas de totales

### 6.3. Formato de Dos Columnas

En web, se puede lograr con:
- CSS Grid o Flexbox
- Dos tablas lado a lado
- Sincronización de alturas de filas

### 6.4. Exportación a Excel

Usar librerías como:
- **EPPlus** (recomendado)
- **ClosedXML**
- **NPOI**

### 6.5. Generación de PDF

Usar librerías como:
- **iTextSharp** / **iText 7**
- **QuestPDF** (recomendado, más moderno)
- **PdfSharp**

## 7. CASOS DE USO PRINCIPALES

### CU1: Generar Balance Ejecutivo

1. Usuario selecciona filtros:
   - Fecha Desde: 01/01/2024
   - Fecha Hasta: 31/12/2024
   - Tipo Ajuste: Financiero
   - Nivel: 3
   - Saldos Vigentes: ☑

2. Usuario hace click en "Listar"

3. Sistema:
   - Consulta movimientos contables
   - Agrupa por cuenta hasta nivel 3
   - Calcula saldos (Debe - Haber)
   - Oculta cuentas con saldo 0
   - Identifica secciones (Circulante, Total)
   - Calcula Resultado del Ejercicio
   - Genera grid paralelo (Activo | Pasivo)

4. Sistema muestra balance

### CU2: Imprimir Balance

1. Usuario hace click en "Imprimir"

2. Sistema muestra diálogo de configuración:
   - Orientación: Horizontal
   - ☐ Papel Foliado
   - ☐ Información Preliminar

3. Usuario confirma

4. Sistema:
   - Genera reporte en orientación horizontal
   - Incluye encabezado con logo y datos empresa
   - Incluye filtros aplicados
   - Incluye pie de firma si está configurado
   - Envía a impresora

5. Si es Libro Oficial con papel foliado:
   - Registra en log de impresiones
   - Actualiza folio último usado

### CU3: Exportar a Excel

1. Usuario hace click en "Copiar a Excel"

2. Sistema:
   - Copia grid al portapapeles con formato
   - Incluye encabezado con filtros

3. Usuario abre Excel y pega

4. Sistema muestra confirmación

### CU4: Ver Libro Mayor de Cuenta

1. Usuario hace doble-click en una cuenta

2. Sistema:
   - Identifica IdCuenta
   - Abre modal de Libro Mayor
   - Filtra por rango de fechas del balance
   - Aplica tipo de ajuste seleccionado

3. Usuario revisa movimientos de la cuenta

## 8. NOTAS DE MIGRACIÓN

1. **Funciones VB6 a portar**:
   - `GenQueryPorNiveles()`: Genera SQL dinámico → EF Core LINQ
   - `SetParallelGrid_SinValCero()`: Algoritmo de alineación → JavaScript/C#
   - `AddResEjercicio()`: Inserta resultado del ejercicio → Lógica del servicio
   - `ReadResEje()`: Lee jerarquía de resultado → Configuración empresa

2. **Configuración de Cuentas Básicas**:
   - `gCtasBas.IdCtaPatrimonio`: ID cuenta Patrimonio
   - `gCtasBas.IdCtaResEje`: ID cuenta Resultado Ejercicio
   - Verificar existencia en tabla CtasBasicas

3. **Colores por Nivel**:
   - `gColores(1..5)`: Array de colores RGB
   - Leer desde tabla Colores
   - Convertir RGB a HEX para CSS

4. **Formato de Valores**:
   - `NEGNUMFMT`: Formato con paréntesis para negativos
   - `BL_NUMFMT`: Formato de balance
   - En .NET usar String.Format o interpolación

5. **Grid Paralelo en Web**:
   - Considerar tabla HTML con dos tbody
   - CSS Grid para alineación
   - JavaScript para sincronización de scroll

6. **Impresión con Firma**:
   - Verificar tabla Firmas
   - Cargar imágenes de firma
   - Incluir en footer del reporte

7. **Exportación**:
   - EPPlus para Excel con formato
   - QuestPDF para PDF profesional
   - Mantener estructura de dos columnas

8. **Performance**:
   - Índices en MovComprobante (Fecha, IdEmpresa)
   - Caché de configuraciones (Colores, Cuentas Básicas)
   - Paginación si hay muchas cuentas

9. **Testing**:
   - Probar con diferentes niveles (2-5)
   - Validar cálculos de totales
   - Verificar alineación de cuentas
   - Comprobar con datos reales

10. **Responsive**:
    - Difícil mantener formato paralelo en móvil
    - Considerar vista apilada para pantallas pequeñas
    - Priorizar vista de escritorio para reportes ejecutivos

## 9. COMPLEJIDAD ESTIMADA

- **Alta**: Lógica de generación de reportes financieros
- **Alta**: Algoritmo de grid paralelo con alineación
- **Media**: Exportación con formato
- **Media**: Integración con configuración de empresa
- **Tiempo estimado**: 16-20 horas de desarrollo + testing

## 10. DEPENDENCIAS

- Tabla Cuentas con jerarquía completa
- Tabla MovComprobante con movimientos contables
- Tabla Comprobante con fechas y tipos
- Tabla AreaNegocio (opcional)
- Tabla CentroCosto (opcional)
- Tabla Colores para formato
- Tabla CtasBasicas para cuentas especiales
- Tabla Firmas para impresión (opcional)

## 11. RECOMENDACIONES

1. **Dividir en Fases**:
   - Fase 1: Generación básica del balance
   - Fase 2: Filtros y opciones
   - Fase 3: Exportación e impresión
   - Fase 4: Formato ejecutivo paralelo

2. **Testing Extensivo**:
   - Balance debe cuadrar siempre (Activo = Pasivo + Resultado)
   - Validar con datos de diferentes empresas
   - Comparar con reportes VB6 existentes

3. **Documentación**:
   - Explicar lógica de cálculo
   - Documentar algoritmo de alineación
   - Guía de usuario para interpretar balance

4. **Performance**:
   - Considerar caché para balances frecuentes
   - Optimizar queries con índices apropiados
   - Limitar rango de fechas razonable

5. **UX**:
   - Indicadores de progreso para cálculos largos
   - Preview antes de imprimir
   - Tooltips explicativos en cuentas
