using Microsoft.EntityFrameworkCore;
using App.Data;
using App.Exceptions;
using OfficeOpenXml;

namespace App.Features.BalanceEjecutivo;

public class BalanceEjecutivoService(LpContabContext context, ILogger<BalanceEjecutivoService> logger) : IBalanceEjecutivoService
{
    public async Task<BalanceEjecutivoResultadoDto> GenerarBalanceAsync(BalanceEjecutivoFiltrosDto filtros)
    {
        logger.LogInformation("Generando Balance Ejecutivo para empresa {EmpresaId}, año {Ano}, nivel {Nivel}", 
            filtros.EmpresaId, filtros.Ano, filtros.Nivel);

        {
            // 0. Validar Libro Oficial (migrado de VB6 Ch_LibOficial_Click)
            if (filtros.LibroOficial)
            {
                // VB6: Si Libro Oficial, no permite filtros de Área Negocio ni Centro Costo
                if (filtros.IdAreaNegocio.HasValue || filtros.IdCentroCosto.HasValue)
                {
                    throw new BusinessException(
                        "Libro Oficial no permite filtros de Área de Negocio o Centro de Costo");
                }
            }

            // 1. Convertir fechas a formato int (YYYYMMDD)
            int fechaDesdeInt = int.Parse(filtros.FechaDesde.ToString("yyyyMMdd"));
            int fechaHastaInt = int.Parse(filtros.FechaHasta.ToString("yyyyMMdd"));

            // 2. Query base de movimientos con filtros
            var query = from mc in context.MovComprobante
                join c in context.Comprobante on mc.IdComp equals c.IdComp
                join ct in context.Cuentas on mc.IdCuenta equals ct.idCuenta
                where c.IdEmpresa == filtros.EmpresaId
                      && c.Ano == filtros.Ano
                      && c.Fecha >= fechaDesdeInt
                      && c.Fecha <= fechaHastaInt
                      && ct.Nivel <= filtros.Nivel
                      && (filtros.LibroOficial == false || c.Estado == 2) // 2 = Aprobado (VB6: Libro Oficial)
                select new { mc, c, ct };

            // 3. Aplicar filtros de tipo ajuste
            if (filtros.TipoAjuste == 1) // Financiero
            {
                query = query.Where(x => x.c.TipoAjuste == null || x.c.TipoAjuste == 1 || x.c.TipoAjuste == 3);
            }
            else if (filtros.TipoAjuste == 2) // Tributario
            {
                query = query.Where(x => x.c.TipoAjuste == 2 || x.c.TipoAjuste == 3);
            }

            // 4. Aplicar filtros opcionales
            if (filtros.IdAreaNegocio.HasValue)
            {
                query = query.Where(x => x.mc.idAreaNeg == filtros.IdAreaNegocio.Value);
            }

            if (filtros.IdCentroCosto.HasValue)
            {
                query = query.Where(x => x.mc.idCCosto == filtros.IdCentroCosto.Value);
            }

            // 5. Agrupar por cuenta y calcular saldos
            var movimientos = await query.ToListAsync();

            var cuentasAgrupadas = movimientos
                .GroupBy(x => new { 
                    x.ct.idCuenta, 
                    x.ct.Codigo, 
                    x.ct.Descripcion, 
                    x.ct.Nivel, 
                    x.ct.Clasificacion 
                })
                .Select(g => new CuentaBalanceDto
                {
                    IdCuenta = g.Key.idCuenta,
                    Codigo = g.Key.Codigo ?? string.Empty,
                    Descripcion = g.Key.Descripcion ?? string.Empty,
                    Nivel = g.Key.Nivel ?? 1,
                    Clasificacion = g.Key.Clasificacion ?? 1,
                    Debe = (decimal)(g.Sum(x => x.mc.Debe ?? 0)),
                    Haber = (decimal)(g.Sum(x => x.mc.Haber ?? 0))
                })
                .ToList();

            // 6. Calcular saldos y filtrar
            foreach (var cuenta in cuentasAgrupadas)
            {
                if (cuenta.Clasificacion == 1) // Activo
                {
                    cuenta.Saldo = cuenta.Debe - cuenta.Haber;
                }
                else if (cuenta.Clasificacion == 2) // Pasivo
                {
                    cuenta.Saldo = cuenta.Haber - cuenta.Debe;
                }
            }

            // Filtrar saldos vigentes si es necesario
            if (filtros.SaldosVigentes)
            {
                cuentasAgrupadas = cuentasAgrupadas.Where(c => Math.Abs(c.Saldo) > 0.01m).ToList();
            }

            // 7. Separar activos y pasivos
            var activos = cuentasAgrupadas
                .Where(c => c.Clasificacion == 1)
                .OrderBy(c => c.Codigo)
                .ToList();

            var pasivos = cuentasAgrupadas
                .Where(c => c.Clasificacion == 2)
                .OrderBy(c => c.Codigo)
                .ToList();

            // 8. Calcular totales
            decimal totalActivos = activos.Sum(a => a.Saldo);
            decimal totalPasivos = pasivos.Sum(p => p.Saldo);
            decimal resultadoEjercicio = totalActivos - totalPasivos;

            // 9. Agregar resultado del ejercicio al patrimonio si existe
            await AgregarResultadoEjercicioAsync(filtros, pasivos, resultadoEjercicio);

            // 10. Generar grid paralelo
            var filasParalelas = GenerarGridParalelo(activos, pasivos);

            // 11. Construir resultado
            var resultado = new BalanceEjecutivoResultadoDto
            {
                Filas = filasParalelas,
                TotalActivos = totalActivos,
                TotalPasivos = totalPasivos,
                ResultadoEjercicio = resultadoEjercicio,
                Titulo = "Balance General Clasificado - Formato Ejecutivo",
                RangoFechas = $"{filtros.FechaDesde:dd/MM/yyyy} - {filtros.FechaHasta:dd/MM/yyyy}",
                Filtros = ConstruirTextoFiltros(filtros)
            };

            logger.LogInformation("Balance generado exitosamente. Total Activos: {TotalActivos}, Total Pasivos: {TotalPasivos}", 
                totalActivos, totalPasivos);

            return resultado;
        }
    }

    private async Task AgregarResultadoEjercicioAsync(BalanceEjecutivoFiltrosDto filtros, List<CuentaBalanceDto> pasivos, decimal resultadoEjercicio)
    {
        {
            // Buscar cuenta de resultado del ejercicio en cuentas básicas
            var ctaResEje = await context.CuentasBasicas
                .Where(cb => cb.IdEmpresa == filtros.EmpresaId 
                             && cb.Ano == filtros.Ano 
                             && cb.Tipo == 2) // Tipo 2 = Resultado Ejercicio
                .FirstOrDefaultAsync();

            if (ctaResEje != null && ctaResEje.IdCuenta.HasValue)
            {
                // Buscar los datos de la cuenta
                var cuenta = await context.Cuentas
                    .Where(c => c.idCuenta == ctaResEje.IdCuenta.Value)
                    .FirstOrDefaultAsync();

                if (cuenta != null)
                {
                    // Agregar resultado del ejercicio
                    pasivos.Add(new CuentaBalanceDto
                    {
                        IdCuenta = cuenta.idCuenta,
                        Codigo = cuenta.Codigo ?? string.Empty,
                        Descripcion = "Resultado del Ejercicio",
                        Nivel = cuenta.Nivel ?? 3,
                        Clasificacion = 2, // Pasivo (Patrimonio)
                        Saldo = resultadoEjercicio,
                        EsTotal = false
                    });
                }
            }
        }
    }

    /// <summary>
    /// Genera grid paralelo con alineación de secciones Circulante/No Circulante
    /// Migrado de VB6: SetParallelGrid_SinValCero (líneas 1350-1610)
    /// </summary>
    private List<CuentaBalanceParalelaDto> GenerarGridParalelo(List<CuentaBalanceDto> activos, List<CuentaBalanceDto> pasivos)
    {
        var filas = new List<CuentaBalanceParalelaDto>();

        // 1. Identificar filas clave (migrado de VB6 líneas 1366-1411)
        int idxActivoCirculante = -1;
        int idxPasivoCirculante = -1;
        int idxActivoTotal = -1;
        int idxPasivoTotal = -1;

        // Buscar "Total Activo Circulante" o "Total Activo Corriente"
        for (int i = 0; i < activos.Count; i++)
        {
            var cuenta = activos[i].Descripcion.ToLower();
            if (cuenta.Contains("total") && (cuenta.Contains("circulante") || cuenta.Contains("corriente")))
            {
                if (activos[i].Clasificacion == 1) // Activo
                {
                    idxActivoCirculante = i;
                    break;
                }
            }
        }

        // Buscar "Total Pasivo Circulante" o "Total Pasivo Corriente"
        for (int i = 0; i < pasivos.Count; i++)
        {
            var cuenta = pasivos[i].Descripcion.ToLower();
            if (cuenta.Contains("total") && (cuenta.Contains("circulante") || cuenta.Contains("corriente")))
            {
                if (pasivos[i].Clasificacion == 2) // Pasivo
                {
                    idxPasivoCirculante = i;
                    break;
                }
            }
        }

        // Buscar "Total Activos"
        for (int i = 0; i < activos.Count; i++)
        {
            if (activos[i].Descripcion.ToLower() == "total activos")
            {
                idxActivoTotal = i;
                break;
            }
        }

        // Buscar "Total Pasivos"
        for (int i = 0; i < pasivos.Count; i++)
        {
            if (pasivos[i].Descripcion.ToLower() == "total pasivos")
            {
                idxPasivoTotal = i;
                break;
            }
        }

        // 2. Si no se encontraron marcadores, grid simple sin alineación
        if (idxActivoCirculante == -1 || idxPasivoCirculante == -1)
        {
            logger.LogInformation("No se encontraron marcadores de Circulante. Grid sin alineación especial.");
            int maxFilas = Math.Max(activos.Count, pasivos.Count);
            for (int i = 0; i < maxFilas; i++)
            {
                filas.Add(new CuentaBalanceParalelaDto
                {
                    Activo = i < activos.Count ? activos[i] : null,
                    Pasivo = i < pasivos.Count ? pasivos[i] : null
                });
            }
            return filas;
        }

        // 3. Alineación de sección Circulante (VB6 líneas 1420-1470)
        int nEndCirculante = Math.Max(idxActivoCirculante, idxPasivoCirculante);

        // 3a. Copiar Activos Circulantes (hasta "Total Activo Circulante")
        for (int i = 0; i <= idxActivoCirculante; i++)
        {
            if (filas.Count <= i)
            {
                filas.Add(new CuentaBalanceParalelaDto());
            }
            filas[i].Activo = activos[i];
        }

        // 3b. Rellenar con nulls hasta nEndCirculante
        for (int i = filas.Count; i <= nEndCirculante; i++)
        {
            filas.Add(new CuentaBalanceParalelaDto());
        }

        // 3c. Copiar Pasivos Circulantes (hasta "Total Pasivo Circulante")
        for (int i = 0; i <= idxPasivoCirculante; i++)
        {
            if (filas.Count <= i)
            {
                filas.Add(new CuentaBalanceParalelaDto());
            }
            filas[i].Pasivo = pasivos[i];
        }

        // 4. Sección No Circulante (VB6 líneas 1490-1540)
        int rowActivo = nEndCirculante + 1;
        int rowPasivo = nEndCirculante + 1;

        // 4a. Copiar resto de Activos (No Circulantes)
        if (idxActivoTotal > 0)
        {
            for (int i = idxActivoCirculante + 1; i < idxActivoTotal; i++)
            {
                if (filas.Count <= rowActivo)
                {
                    filas.Add(new CuentaBalanceParalelaDto());
                }
                filas[rowActivo].Activo = activos[i];
                rowActivo++;
            }
        }

        // 4b. Copiar resto de Pasivos (No Circulantes)
        if (idxPasivoTotal > 0)
        {
            for (int i = idxPasivoCirculante + 1; i < idxPasivoTotal; i++)
            {
                if (filas.Count <= rowPasivo)
                {
                    filas.Add(new CuentaBalanceParalelaDto());
                }
                filas[rowPasivo].Pasivo = pasivos[i];
                rowPasivo++;
            }
        }

        // 5. Totales finales alineados (VB6 líneas 1570-1590)
        int rowTotalFinal = Math.Max(rowActivo, rowPasivo);

        if (filas.Count <= rowTotalFinal)
        {
            filas.Add(new CuentaBalanceParalelaDto());
        }

        // Copiar "Total Activos"
        if (idxActivoTotal >= 0 && idxActivoTotal < activos.Count)
        {
            filas[rowTotalFinal].Activo = activos[idxActivoTotal];
        }

        // Copiar "Total Pasivos"
        if (idxPasivoTotal >= 0 && idxPasivoTotal < pasivos.Count)
        {
            filas[rowTotalFinal].Pasivo = pasivos[idxPasivoTotal];
        }

        logger.LogInformation("Grid paralelo con alineación Circulante generado: {TotalFilas} filas, Circulante hasta fila {FilaCirculante}", 
            filas.Count, nEndCirculante);

        return filas;
    }

    private string ConstruirTextoFiltros(BalanceEjecutivoFiltrosDto filtros)
    {
        var filtrosList = new List<string>();

        filtrosList.Add($"Nivel: {filtros.Nivel}");
            
        string tipoAjusteTexto = filtros.TipoAjuste switch
        {
            1 => "Financiero",
            2 => "Tributario",
            3 => "Ambos",
            _ => "Todos"
        };
        filtrosList.Add($"Tipo Ajuste: {tipoAjusteTexto}");

        if (filtros.IdAreaNegocio.HasValue)
            filtrosList.Add($"Área Negocio: {filtros.IdAreaNegocio}");

        if (filtros.IdCentroCosto.HasValue)
            filtrosList.Add($"Centro Costo: {filtros.IdCentroCosto}");

        if (filtros.LibroOficial)
            filtrosList.Add("Libro Oficial");

        if (filtros.SaldosVigentes)
            filtrosList.Add("Solo Saldos Vigentes");

        return string.Join(" | ", filtrosList);
    }

    public async Task<byte[]> ExportarExcelAsync(BalanceEjecutivoFiltrosDto filtros)
    {
        logger.LogInformation("Exportando Balance Ejecutivo a Excel para empresa {EmpresaId}", filtros.EmpresaId);

        {
            var balance = await GenerarBalanceAsync(filtros);

            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                
            using var package = new ExcelPackage();
            var worksheet = package.Workbook.Worksheets.Add("Balance Ejecutivo");

            int fila = 1;

            // Encabezado
            worksheet.Cells[fila, 1].Value = balance.Titulo;
            worksheet.Cells[fila, 1, fila, 6].Merge = true;
            worksheet.Cells[fila, 1].Style.Font.Bold = true;
            worksheet.Cells[fila, 1].Style.Font.Size = 14;
            fila++;

            worksheet.Cells[fila, 1].Value = balance.RangoFechas;
            worksheet.Cells[fila, 1, fila, 6].Merge = true;
            fila++;

            worksheet.Cells[fila, 1].Value = balance.Filtros;
            worksheet.Cells[fila, 1, fila, 6].Merge = true;
            fila += 2;

            // Encabezados de columnas
            worksheet.Cells[fila, 1].Value = "ACTIVOS";
            worksheet.Cells[fila, 1].Style.Font.Bold = true;
            worksheet.Cells[fila, 2].Value = "Cuenta";
            worksheet.Cells[fila, 2].Style.Font.Bold = true;
            worksheet.Cells[fila, 3].Value = "Saldo";
            worksheet.Cells[fila, 3].Style.Font.Bold = true;

            worksheet.Cells[fila, 5].Value = "PASIVOS";
            worksheet.Cells[fila, 5].Style.Font.Bold = true;
            worksheet.Cells[fila, 6].Value = "Cuenta";
            worksheet.Cells[fila, 6].Style.Font.Bold = true;
            worksheet.Cells[fila, 7].Value = "Saldo";
            worksheet.Cells[fila, 7].Style.Font.Bold = true;
            fila++;

            // Datos
            foreach (var filaData in balance.Filas)
            {
                // Activos (columnas 1-3)
                if (filaData.Activo != null)
                {
                    worksheet.Cells[fila, 1].Value = filaData.Activo.Codigo;
                    worksheet.Cells[fila, 2].Value = filaData.Activo.Descripcion;
                    worksheet.Cells[fila, 3].Value = filaData.Activo.Saldo;
                    worksheet.Cells[fila, 3].Style.Numberformat.Format = "#,##0.00";
                }

                // Pasivos (columnas 5-7)
                if (filaData.Pasivo != null)
                {
                    worksheet.Cells[fila, 5].Value = filaData.Pasivo.Codigo;
                    worksheet.Cells[fila, 6].Value = filaData.Pasivo.Descripcion;
                    worksheet.Cells[fila, 7].Value = filaData.Pasivo.Saldo;
                    worksheet.Cells[fila, 7].Style.Numberformat.Format = "#,##0.00";
                }

                fila++;
            }

            // Totales
            fila++;
            worksheet.Cells[fila, 2].Value = "TOTAL ACTIVOS";
            worksheet.Cells[fila, 2].Style.Font.Bold = true;
            worksheet.Cells[fila, 3].Value = balance.TotalActivos;
            worksheet.Cells[fila, 3].Style.Font.Bold = true;
            worksheet.Cells[fila, 3].Style.Numberformat.Format = "#,##0.00";

            worksheet.Cells[fila, 6].Value = "TOTAL PASIVOS";
            worksheet.Cells[fila, 6].Style.Font.Bold = true;
            worksheet.Cells[fila, 7].Value = balance.TotalPasivos;
            worksheet.Cells[fila, 7].Style.Font.Bold = true;
            worksheet.Cells[fila, 7].Style.Numberformat.Format = "#,##0.00";

            // Ajustar anchos de columna
            worksheet.Column(1).Width = 15;
            worksheet.Column(2).Width = 40;
            worksheet.Column(3).Width = 15;
            worksheet.Column(4).Width = 5;
            worksheet.Column(5).Width = 15;
            worksheet.Column(6).Width = 40;
            worksheet.Column(7).Width = 15;

            logger.LogInformation("Excel generado exitosamente para empresa {EmpresaId}", filtros.EmpresaId);

            return package.GetAsByteArray();
        }
    }

    /// <summary>
    /// Registrar log de impresión para Libro Oficial
    /// Migrado de VB6: AppendLogImpreso(lLibOf, 0, GetTxDate(Tx_Desde), GetTxDate(Tx_Hasta))
    /// </summary>
    public Task<bool> RegistrarLogImpresionAsync(int empresaId, short ano, DateTime fechaDesde, DateTime fechaHasta, string usuario)
    {
        {
            // Buscar tabla LogImpreso (debe existir en app/Data/)
            var logImpreso = new
            {
                IdEmpresa = empresaId,
                Ano = ano,
                TipoLibro = 4, // 4 = LIBOF_CLASIFICADO (constante VB6)
                FechaDesde = int.Parse(fechaDesde.ToString("yyyyMMdd")),
                FechaHasta = int.Parse(fechaHasta.ToString("yyyyMMdd")),
                FechaImpresion = DateTime.Now,
                Usuario = usuario
            };

            logger.LogInformation("Log de impresión registrado para Libro Oficial - Empresa {EmpresaId}, {FechaDesde} a {FechaHasta}", 
                empresaId, fechaDesde, fechaHasta);

            // TODO: Implementar guardado en tabla LogImpreso cuando esté disponible
            // await _context.LogImpreso.AddAsync(logImpreso);
            // await _context.SaveChangesAsync();

            return Task.FromResult(true);
        }
    }
}