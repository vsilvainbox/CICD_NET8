using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.BalanceEjecutivo;

public class BalanceEjecutivoController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<BalanceEjecutivoController> logger) : Controller
{
    public Task<IActionResult> Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder al Balance Ejecutivo";
            TempData["SwalType"] = "warning";
            return Task.FromResult<IActionResult>(RedirectToAction("Index", "SeleccionarEmpresa"));
        }

        logger.LogInformation("Loading BalanceEjecutivo Index for empresaId: {EmpresaId}, ano: {Ano}", SessionHelper.EmpresaId, SessionHelper.Ano);

        ViewData["EmpresaId"] = SessionHelper.EmpresaId;
        ViewData["Ano"] = SessionHelper.Ano;

        return Task.FromResult<IActionResult>(View());
    }

    [HttpPost]
    public async Task<IActionResult> GenerarBalance([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC: GenerarBalance proxy called for empresaId: {EmpresaId}", SessionHelper.EmpresaId);

        {
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<BalanceEjecutivoApiController>(
                HttpContext,
                nameof(BalanceEjecutivoApiController.GenerarBalance));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    [HttpPost]
    public async Task<IActionResult> ExportarExcel([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC: ExportarExcel proxy called for empresaId: {EmpresaId}", SessionHelper.EmpresaId);

        {
            var client = httpClientFactory.CreateClient();

            // Extraer nombre de usuario desde HttpContext
            var usuario = HttpContext.User?.Identity?.Name ?? "Sistema";

            var url = linkGenerator.GetApiUrl<BalanceEjecutivoApiController>(
                HttpContext,
                nameof(BalanceEjecutivoApiController.ExportarExcel),
                new { usuario });
            var (fileBytes, contentType) = await client.DownloadFileAsync(
                url, HttpMethod.Post, request);

            var fileName = "BalanceEjecutivo.xlsx";
            return File(fileBytes, contentType, fileName);
        }
    }
}