using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Extensions;
using App.Helpers;

namespace App.Features.ConfiguracionFirmaInformes;

public class ConfiguracionFirmaInformesController(
    IHttpClientFactory httpClientFactory,
    ILogger<ConfiguracionFirmaInformesController> logger,
    LinkGenerator linkGenerator) : Controller
{
    public async Task<IActionResult> Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a la Configuración de Firma de Informes";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        // Extraer datos de HttpContext usando extensiones
        int empresaId = SessionHelper.EmpresaId;
        int ano = SessionHelper.Ano;

        logger.LogInformation("Loading ConfiguracionFirmaInformes for empresa {EmpresaId}, año {Ano}", empresaId, ano);

        ViewData["EmpresaId"] = empresaId;
        ViewData["Ano"] = ano;

        var url = linkGenerator.GetApiUrl<ConfiguracionFirmaInformesApiController>(
            HttpContext,
            nameof(ConfiguracionFirmaInformesApiController.GetConfiguracion),
            new { empresaId, ano });

        var config = await httpClientFactory
            .CreateClient()
            .GetFromApiAsync<ConfiguracionFirmaInformesDto>(url!);

        return View(config);
    }

    [HttpPost]
    public async Task<IActionResult> UploadFirma([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: UploadFirma called");

        var url = linkGenerator.GetApiUrl<ConfiguracionFirmaInformesApiController>(
            HttpContext,
            nameof(ConfiguracionFirmaInformesApiController.UploadFirma));

        var (statusCode, content) = await httpClientFactory
            .CreateClient()
            .ProxyRequestAsync(url!, request, HttpMethod.Post);

        return new ContentResult
        {
            Content = content,
            ContentType = "application/json",
            StatusCode = statusCode
        };
    }

    [HttpDelete]
    public async Task<IActionResult> DeleteFirma([FromQuery] int empresaId, [FromQuery] short ano, [FromQuery] string tipo)
    {
        logger.LogInformation("MVC Proxy: DeleteFirma called for empresa {EmpresaId}, tipo {Tipo}", empresaId, tipo);

        var url = linkGenerator.GetApiUrl<ConfiguracionFirmaInformesApiController>(
            HttpContext,
            nameof(ConfiguracionFirmaInformesApiController.DeleteFirma),
            new { empresaId, ano, tipo });

        var (statusCode, content) = await httpClientFactory
            .CreateClient()
            .ProxyRequestAsync(url!, null, HttpMethod.Delete);

        return new ContentResult
        {
            Content = content,
            ContentType = "application/json",
            StatusCode = statusCode
        };
    }
}
