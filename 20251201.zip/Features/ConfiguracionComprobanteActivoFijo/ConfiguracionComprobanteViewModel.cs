using System.ComponentModel.DataAnnotations;

namespace App.Features.ConfiguracionComprobanteActivoFijo;

/// <summary>
/// ViewModel principal para la configuracion de comprobante de activo fijo
/// </summary>
public class ConfiguracionComprobanteViewModel
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }

    // Valores del activo fijo (inicializados externamente)
    public decimal ValorRazonable { get; set; }
    public decimal ValorInicial { get; set; }
    public decimal ValorDelBien { get; set; }
    public decimal ValorLibro { get; set; }
    public decimal ValorResidual { get; set; }
    public decimal ValorDepreciar { get; set; }
    public decimal ValorLibroAntRevalor { get; set; }
    public decimal ValorLibroDespRevalo { get; set; }

    // Lineas del comprobante
    public List<LineaComprobanteItem> Lineas { get; set; } = new();

    // Nueva linea en edicion (para el formulario)
    public NuevaLineaForm NuevaLinea { get; set; } = new();

    // Propiedades calculadas
    public decimal TotalDebe => Lineas.Sum(l => l.Debe);
    public decimal TotalHaber => Lineas.Sum(l => l.Haber);
    public decimal Diferencia => TotalDebe - TotalHaber;
    public bool EstaCuadrado => TotalDebe == TotalHaber;

    // Propiedades formateadas para la vista (servidor controla el formato)
    public string TotalDebeFormateado => TotalDebe.ToString("N2");
    public string TotalHaberFormateado => TotalHaber.ToString("N2");
    public string DiferenciaFormateada => Diferencia.ToString("N2");

    // Propiedades auxiliares para la vista
    public string EstadoCuadrado => EstaCuadrado ? "Cuadrado" : "Descuadrado";
    public string ClaseCuadrado => EstaCuadrado ? "text-green-600" : "text-red-600";

    // Valores del activo formateados
    public string ValorRazonableFormateado => ValorRazonable.ToString("N2");
    public string ValorInicialFormateado => ValorInicial.ToString("N2");
    public string ValorDelBienFormateado => ValorDelBien.ToString("N2");
    public string ValorLibroFormateado => ValorLibro.ToString("N2");
    public string ValorResidualFormateado => ValorResidual.ToString("N2");
    public string ValorDepreciarFormateado => ValorDepreciar.ToString("N2");
    public string ValorLibroAntRevalorFormateado => ValorLibroAntRevalor.ToString("N2");
    public string ValorLibroDespRevaloFormateado => ValorLibroDespRevalo.ToString("N2");

    // Checkboxes ya usados (servidor rastrea el estado)
    public HashSet<string> CheckboxesUsados { get; set; } = new();
}

/// <summary>
/// Formulario para nueva linea (usado en la vista principal)
/// </summary>
public class NuevaLineaForm
{
    public int? IdCuenta { get; set; }
    public string CodCuenta { get; set; } = string.Empty;
    public string DescCuenta { get; set; } = string.Empty;
    public string TipoMovimiento { get; set; } = string.Empty;
    public bool UsarValorRazonable { get; set; }
    public bool UsarValorInicial { get; set; }
    public bool UsarValorDelBien { get; set; }
    public bool UsarValorLibro { get; set; }
    public bool UsarValorResidual { get; set; }
    public bool UsarValorDepreciar { get; set; }
    public bool UsarValorLibroAntRevalor { get; set; }
    public bool UsarValorLibroDespRevalo { get; set; }

    public string CuentaDisplay => !string.IsNullOrEmpty(CodCuenta)
        ? $"{CodCuenta} - {DescCuenta}"
        : string.Empty;
}

/// <summary>
/// ViewModel para agregar una nueva linea al comprobante
/// </summary>
public class AgregarLineaRequest : IValidatableObject
{
    [Required(ErrorMessage = "Debe seleccionar una cuenta")]
    public int? IdCuenta { get; set; }

    public string CodCuenta { get; set; } = string.Empty;
    public string DescCuenta { get; set; } = string.Empty;

    [Required(ErrorMessage = "Debe seleccionar Debe o Haber")]
    public string? TipoMovimiento { get; set; } // "Debe" o "Haber"

    // Checkboxes de valores
    public bool UsarValorRazonable { get; set; }
    public bool UsarValorInicial { get; set; }
    public bool UsarValorDelBien { get; set; }
    public bool UsarValorLibro { get; set; }
    public bool UsarValorResidual { get; set; }
    public bool UsarValorDepreciar { get; set; }
    public bool UsarValorLibroAntRevalor { get; set; }
    public bool UsarValorLibroDespRevalo { get; set; }

    // Valores del activo (para calcular monto)
    public decimal ValorRazonable { get; set; }
    public decimal ValorInicial { get; set; }
    public decimal ValorDelBien { get; set; }
    public decimal ValorLibro { get; set; }
    public decimal ValorResidual { get; set; }
    public decimal ValorDepreciar { get; set; }
    public decimal ValorLibroAntRevalor { get; set; }
    public decimal ValorLibroDespRevalo { get; set; }

    // Propiedad calculada: monto segun checkboxes
    public decimal MontoCalculado
    {
        get
        {
            decimal monto = 0;
            if (UsarValorRazonable) monto += ValorRazonable;
            if (UsarValorInicial) monto += ValorInicial;
            if (UsarValorDelBien) monto += ValorDelBien;
            if (UsarValorLibro) monto += ValorLibro;
            if (UsarValorResidual) monto += ValorResidual;
            if (UsarValorDepreciar) monto += ValorDepreciar;
            if (UsarValorLibroAntRevalor) monto += ValorLibroAntRevalor;
            if (UsarValorLibroDespRevalo) monto += ValorLibroDespRevalo;
            return monto;
        }
    }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        // Validar que se haya seleccionado al menos un valor
        bool algunValorSeleccionado = UsarValorRazonable || UsarValorInicial || UsarValorDelBien ||
                                      UsarValorLibro || UsarValorResidual || UsarValorDepreciar ||
                                      UsarValorLibroAntRevalor || UsarValorLibroDespRevalo;

        if (!algunValorSeleccionado)
        {
            yield return new ValidationResult(
                "Debe seleccionar al menos un valor del activo fijo",
                new[] { nameof(UsarValorRazonable) });
        }

        // Validar que TipoMovimiento sea "Debe" o "Haber"
        if (TipoMovimiento != "Debe" && TipoMovimiento != "Haber")
        {
            yield return new ValidationResult(
                "Debe seleccionar Debe o Haber",
                new[] { nameof(TipoMovimiento) });
        }
    }
}

/// <summary>
/// Representa una linea del comprobante
/// </summary>
public class LineaComprobanteItem
{
    public int IdCuenta { get; set; }
    public string CodCuenta { get; set; } = string.Empty;
    public string DescCuenta { get; set; } = string.Empty;
    public decimal Debe { get; set; }
    public decimal Haber { get; set; }

    // Propiedades formateadas
    public string DebeFormateado => Debe > 0 ? Debe.ToString("N2") : "0,00";
    public string HaberFormateado => Haber > 0 ? Haber.ToString("N2") : "0,00";

    // Para identificar que valores se usaron en esta linea
    public List<string> ValoresUsados { get; set; } = new();
}

/// <summary>
/// Request para crear el comprobante con todas las lineas
/// </summary>
public class CrearComprobanteRequest : IValidatableObject
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }

    [Required(ErrorMessage = "Debe agregar al menos una linea al comprobante")]
    [MinLength(1, ErrorMessage = "Debe agregar al menos una linea al comprobante")]
    public List<LineaComprobanteItem> Lineas { get; set; } = new();

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        // Validar que el comprobante este cuadrado
        var totalDebe = Lineas.Sum(l => l.Debe);
        var totalHaber = Lineas.Sum(l => l.Haber);

        if (totalDebe != totalHaber)
        {
            yield return new ValidationResult(
                $"El comprobante no esta cuadrado. Debe: {totalDebe:N2}, Haber: {totalHaber:N2}",
                new[] { nameof(Lineas) });
        }
    }
}
