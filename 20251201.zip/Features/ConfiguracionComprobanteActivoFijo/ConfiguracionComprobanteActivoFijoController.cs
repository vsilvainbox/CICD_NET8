using Microsoft.AspNetCore.Mvc;
using App.Helpers;
using App.Extensions;
using App.Features.PlanCuentas;

namespace App.Features.ConfiguracionComprobanteActivoFijo;


public class ConfiguracionComprobanteActivoFijoController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<ConfiguracionComprobanteActivoFijoController> logger) : Controller
{
    public IActionResult Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Configuración Comprobante Activo Fijo";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        logger.LogInformation("Loading ConfiguracionComprobanteActivoFijo for empresaId: {EmpresaId}, ano: {Ano}", SessionHelper.EmpresaId, SessionHelper.Ano);

        var model = new ConfiguracionComprobanteViewModel
        {
            EmpresaId = SessionHelper.EmpresaId,
            Ano = SessionHelper.Ano
        };

        return View(model);
    }

    /// <summary>
    /// Obtiene el plan de cuentas y retorna el partial view del selector
    /// GET /ConfiguracionComprobanteActivoFijo/GetSelectorCuentas
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetSelectorCuentas(int empresaId, short ano)
    {
        logger.LogInformation("ConfiguracionComprobanteActivoFijo: GetSelectorCuentas for empresaId={EmpresaId}, ano={Ano}", empresaId, ano);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<PlanCuentasApiController>(
            HttpContext,
            nameof(PlanCuentasApiController.GetAll),
            new { empresaId, ano });

        var cuentas = await client.GetFromApiAsync<List<dynamic>>(url!);

        return PartialView("Sections/_SelectorCuentas", cuentas);
    }

    /// <summary>
    /// Proxy para obtener plan de cuentas (JSON para compatibilidad)
    /// GET /ConfiguracionComprobanteActivoFijo/GetPlanCuentas
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetPlanCuentas(int empresaId, short ano)
    {
        logger.LogInformation("ConfiguracionComprobanteActivoFijo: GetPlanCuentas proxy called for empresaId={EmpresaId}, ano={Ano}", empresaId, ano);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<PlanCuentasApiController>(
            HttpContext,
            nameof(PlanCuentasApiController.GetAll),
            new { empresaId, ano });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Agrega una linea al comprobante y retorna el modelo actualizado
    /// POST /ConfiguracionComprobanteActivoFijo/AgregarLinea
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult AgregarLinea(ConfiguracionComprobanteViewModel model)
    {
        logger.LogInformation("AgregarLinea: IdCuenta={IdCuenta}, TipoMovimiento={TipoMovimiento}",
            model.NuevaLinea.IdCuenta, model.NuevaLinea.TipoMovimiento);

        // Validar nueva linea
        if (!model.NuevaLinea.IdCuenta.HasValue)
        {
            ModelState.AddModelError("NuevaLinea.IdCuenta", "Debe seleccionar una cuenta");
        }

        if (string.IsNullOrEmpty(model.NuevaLinea.TipoMovimiento))
        {
            ModelState.AddModelError("NuevaLinea.TipoMovimiento", "Debe seleccionar Debe o Haber");
        }

        bool algunCheckboxSeleccionado = model.NuevaLinea.UsarValorRazonable ||
            model.NuevaLinea.UsarValorInicial || model.NuevaLinea.UsarValorDelBien ||
            model.NuevaLinea.UsarValorLibro || model.NuevaLinea.UsarValorResidual ||
            model.NuevaLinea.UsarValorDepreciar || model.NuevaLinea.UsarValorLibroAntRevalor ||
            model.NuevaLinea.UsarValorLibroDespRevalo;

        if (!algunCheckboxSeleccionado)
        {
            ModelState.AddModelError("NuevaLinea", "Debe seleccionar al menos un valor del activo");
        }

        if (!ModelState.IsValid)
        {
            var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).ToList();
            TempData["ValidationErrors"] = string.Join(", ", errors);
            return PartialView("Sections/_FormularioNuevaLinea", model);
        }

        // Calcular monto en el servidor
        decimal monto = 0;
        var valoresUsados = new List<string>();

        if (model.NuevaLinea.UsarValorRazonable)
        {
            monto += model.ValorRazonable;
            valoresUsados.Add("ValorRazonable");
            model.CheckboxesUsados.Add("ckValorRazonable");
        }
        if (model.NuevaLinea.UsarValorInicial)
        {
            monto += model.ValorInicial;
            valoresUsados.Add("ValorInicial");
            model.CheckboxesUsados.Add("ckValorInicial");
        }
        if (model.NuevaLinea.UsarValorDelBien)
        {
            monto += model.ValorDelBien;
            valoresUsados.Add("ValorDelBien");
            model.CheckboxesUsados.Add("ckValorBien");
        }
        if (model.NuevaLinea.UsarValorLibro)
        {
            monto += model.ValorLibro;
            valoresUsados.Add("ValorLibro");
            model.CheckboxesUsados.Add("ckValorLibro");
        }
        if (model.NuevaLinea.UsarValorResidual)
        {
            monto += model.ValorResidual;
            valoresUsados.Add("ValorResidual");
            model.CheckboxesUsados.Add("ckValorResidual");
        }
        if (model.NuevaLinea.UsarValorDepreciar)
        {
            monto += model.ValorDepreciar;
            valoresUsados.Add("ValorDepreciar");
            model.CheckboxesUsados.Add("ckValorDepreciar");
        }
        if (model.NuevaLinea.UsarValorLibroAntRevalor)
        {
            monto += model.ValorLibroAntRevalor;
            valoresUsados.Add("ValorLibroAntRevalor");
            model.CheckboxesUsados.Add("ckValorLibroAntRevalor");
        }
        if (model.NuevaLinea.UsarValorLibroDespRevalo)
        {
            monto += model.ValorLibroDespRevalo;
            valoresUsados.Add("ValorLibroDespRevalo");
            model.CheckboxesUsados.Add("ckValorLibroDespRevalo");
        }

        // Crear nueva linea
        var nuevaLinea = new LineaComprobanteItem
        {
            IdCuenta = model.NuevaLinea.IdCuenta!.Value,
            CodCuenta = model.NuevaLinea.CodCuenta,
            DescCuenta = model.NuevaLinea.DescCuenta,
            Debe = model.NuevaLinea.TipoMovimiento == "Debe" ? monto : 0,
            Haber = model.NuevaLinea.TipoMovimiento == "Haber" ? monto : 0,
            ValoresUsados = valoresUsados
        };

        // Agregar a la lista
        model.Lineas.Add(nuevaLinea);

        // Limpiar formulario de nueva linea
        model.NuevaLinea = new NuevaLineaForm();

        // Guardar estado en session
        HttpContext.Session.SetObject("ConfiguracionComprobanteState", model);

        logger.LogInformation("Linea agregada exitosamente. Total lineas: {Count}", model.Lineas.Count);

        // Retornar vista completa actualizada
        return PartialView("Sections/_ContenidoCompleto", model);
    }

    /// <summary>
    /// Elimina una linea del comprobante
    /// POST /ConfiguracionComprobanteActivoFijo/EliminarLinea
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult EliminarLinea(ConfiguracionComprobanteViewModel model, int index)
    {
        logger.LogInformation("EliminarLinea: index={Index}, total lineas={Count}", index, model.Lineas.Count);

        if (index >= 0 && index < model.Lineas.Count)
        {
            // Obtener valores usados de la linea a eliminar
            var lineaEliminada = model.Lineas[index];

            // Remover checkboxes usados
            foreach (var valor in lineaEliminada.ValoresUsados)
            {
                var checkboxId = ObtenerCheckboxId(valor);
                model.CheckboxesUsados.Remove(checkboxId);
            }

            // Eliminar linea
            model.Lineas.RemoveAt(index);

            // Guardar estado en session
            HttpContext.Session.SetObject("ConfiguracionComprobanteState", model);

            logger.LogInformation("Linea eliminada exitosamente. Total lineas restantes: {Count}", model.Lineas.Count);
        }

        // Retornar vista completa actualizada
        return PartialView("Sections/_ContenidoCompleto", model);
    }

    /// <summary>
    /// Refresca el grid de lineas
    /// POST /ConfiguracionComprobanteActivoFijo/RefrescarGrid
    /// </summary>
    [HttpPost]
    public IActionResult RefrescarGrid([FromBody] ConfiguracionComprobanteViewModel model)
    {
        return PartialView("Sections/_LineasComprobanteGrid", model);
    }

    /// <summary>
    /// Restaura el estado desde la sesion
    /// GET /ConfiguracionComprobanteActivoFijo/RestaurarEstado
    /// </summary>
    [HttpGet]
    public IActionResult RestaurarEstado()
    {
        var state = HttpContext.Session.GetObject<ConfiguracionComprobanteViewModel>("ConfiguracionComprobanteState");
        if (state == null)
        {
            state = new ConfiguracionComprobanteViewModel
            {
                EmpresaId = SessionHelper.EmpresaId,
                Ano = SessionHelper.Ano
            };
        }
        return PartialView("Sections/_ContenidoCompleto", state);
    }

    /// <summary>
    /// Valida y crea el comprobante
    /// POST /ConfiguracionComprobanteActivoFijo/CrearComprobante
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult CrearComprobante(CrearComprobanteRequest request)
    {
        if (!ModelState.IsValid)
        {
            TempData["SwalError"] = string.Join(", ", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
            TempData["SwalType"] = "error";
            return RedirectToAction("Index");
        }

        logger.LogInformation("Creando comprobante de activo fijo con {Count} lineas", request.Lineas.Count);

        // Guardar en session para pasar al modulo de comprobantes
        HttpContext.Session.SetObject("LineasComprobanteActivoFijo", request.Lineas);

        return RedirectToAction("Index", "Comprobantee", new { empresaId = request.EmpresaId, tipoOrigen = "ActivoFijo" });
    }

    private static List<string> ObtenerValoresUsados(AgregarLineaRequest request)
    {
        var valores = new List<string>();
        if (request.UsarValorRazonable) valores.Add("ValorRazonable");
        if (request.UsarValorInicial) valores.Add("ValorInicial");
        if (request.UsarValorDelBien) valores.Add("ValorDelBien");
        if (request.UsarValorLibro) valores.Add("ValorLibro");
        if (request.UsarValorResidual) valores.Add("ValorResidual");
        if (request.UsarValorDepreciar) valores.Add("ValorDepreciar");
        if (request.UsarValorLibroAntRevalor) valores.Add("ValorLibroAntRevalor");
        if (request.UsarValorLibroDespRevalo) valores.Add("ValorLibroDespRevalo");
        return valores;
    }

    private static string ObtenerCheckboxId(string valor)
    {
        return valor switch
        {
            "ValorRazonable" => "ckValorRazonable",
            "ValorInicial" => "ckValorInicial",
            "ValorDelBien" => "ckValorBien",
            "ValorLibro" => "ckValorLibro",
            "ValorResidual" => "ckValorResidual",
            "ValorDepreciar" => "ckValorDepreciar",
            "ValorLibroAntRevalor" => "ckValorLibroAntRevalor",
            "ValorLibroDespRevalo" => "ckValorLibroDespRevalo",
            _ => string.Empty
        };
    }
}
