# BalanceClasificado - Análisis Exhaustivo VB6 - PARTE 1: ESTRUCTURA

**Fecha:** 11 de Octubre de 2025  
**Formulario VB6:** `FrmBalClasif.frm` (1,840 líneas)  
**Analista:** Claude + AI Code Agent

---

## 📋 RESUMEN EJECUTIVO

Este formulario genera reportes financieros clasificados por tipo de cuenta (Activo, Pasivo, Patrimonio, Resultado). Es una de las funcionalidades **CRÍTICAS** del sistema contable.

### Tipos de Reportes Generados:
1. **Balance General Clasificado** - Activos vs Pasivos + Patrimonio
2. **Estado de Resultados Clasificado** - Ingresos vs Gastos  
3. **Balance Mensual** - Columnas por mes (1-12)
4. **Balance Comparativo** - Comparación multi-período

### Modalidades:
- **Libro Oficial**: Solo comprobantes APROBADOS, papel foliado, registro de impresión
- **Libro Provisorio**: APROBADOS + PENDIENTES, sin papel foliado

---

## 🎯 VARIABLES GLOBALES

```vb6
Private lCaption As String          ' Título del formulario
Private lMes As Integer             ' Mes actual (1-12)
Private lBalClasif As Boolean       ' TRUE=Balance, FALSE=Estado Resultados
Private lMensual As Boolean         ' TRUE=columnas mensuales
Private lComparativo As Boolean     ' TRUE=multi-período
Private lOrientacion As Integer     ' ORIENT_VER(1) o ORIENT_HOR(2)
Private lPapelFoliado As Boolean    ' TRUE=papel foliado
Private lInfoPreliminar As Boolean  ' Info preliminar impresión
Private lClasCta As String          ' Clasificaciones filtradas ("1,2,3")
Private lLibOf As Integer           ' Código libro oficial
```

### Constantes Críticas:
```vb6
' Orientación
ORIENT_VER = 1
ORIENT_HOR = 2

' Clasificaciones de Cuenta
CLASCTA_ACTIVO = 1
CLASCTA_PASIVO = 2
CLASCTA_RESULTADO = 3
CLASCTA_ORDEN = 4

' Estados de Comprobante
EC_APROBADO = 1
EC_PENDIENTE = 2
EC_ANULADO = 3

' Tipos de Ajuste
TAJUSTE_FINANCIERO = 1
TAJUSTE_TRIBUTARIO = 2
TAJUSTE_AMBOS = 3

' Libros Oficiales
LIBOF_BALANCEGRAL = 8  ' Constante para Balance General
```

---

## 🖼️ CONTROLES UI - GRID PRINCIPAL

### MSFlexGrid "Grid"
```vb6
Dimensiones: 6075 x 10155 twips
Rows: 25 (inicial, crece dinámicamente)
Cols: 9 base (+ hasta 12 columnas mensuales)
FixedRows: 1
FixedCols: 0
AllowUserResizing: flexResizeColumns (2)
ScrollBars: flexScrollBarBoth (3)
```

### Columnas del Grid:
```vb6
Const C_IDCUENTA = 0   ' IdCuenta (oculta, Width=0)
Const C_CODIGO = 1     ' Código cuenta (Width=1500)
Const C_CUENTA = 2     ' Descripción (Width=3500)
Const C_DEBITOS = 3    ' Total Débitos (Width=1400)
Const C_CREDITOS = 4   ' Total Créditos (Width=1400)
Const C_SALDO = 5      ' Saldo (Width=1400)
Const C_NIVEL = 6      ' Nivel jerarquía (oculta)
Const C_CLASCTA = 7    ' Clasificación (oculta)
Const C_FMT = 8        ' Formato B/I (oculta)
Const C_INI_MES = 9    ' Primera columna mensual
```

**Formato de Valores:**
```vb6
NEGNUMFMT = "#,##0;-#,##0"  ' Formato números con negativo
```

---

## 🎛️ CONTROLES UI - FILTROS (Frame2)

### TextBox: Tx_Desde
```vb6
Purpose: Fecha inicio período
Format: dd/mm/yyyy
Default: 01/01/[AñoEmpresa] (Form_Load)
Validaciones:
  - Debe ser <= Tx_Hasta
  - Debe pertenecer a gEmpresa.Ano
  - Solo acepta números y /
Events:
  - tx_Desde_Change(): Habilita Bt_Buscar
  - Tx_Desde_LostFocus(): Valida formato
  - Tx_Desde_KeyPress(KeyAscii): Filtra entrada
```

### TextBox: Tx_Hasta  
```vb6
Purpose: Fecha término período
Format: dd/mm/yyyy
Default: Último día mes actual (Form_Load)
Validaciones: Idénticas a Tx_Desde
```

### Button: Bt_Fecha(0) y Bt_Fecha(1)
```vb6
Purpose: Abrir calendario visual
Icon: Calendar
Handler: Bt_Fecha_Click(Index As Integer)
  Fecha = FInputDate("", GetTxDate(IIf(Index=0, Tx_Desde, Tx_Hasta)))
  If Fecha >= 0 Then
    Call SetTxDate(IIf(Index=0, Tx_Desde, Tx_Hasta), Fecha)
  End If
```

### ComboBox: Cb_Nivel
```vb6
Purpose: Nivel de detalle cuentas (2-5)
Population (Form_Load):
  If gNiveles.nNiveles >= 3 Then
    Call FillNivel(Cb_Nivel, 3)  ' Default nivel 3
  Else
    Call FillNivel(Cb_Nivel, gNiveles.nNiveles)
  End If
  Cb_Nivel.RemoveItem(0)  ' Elimina nivel 1
Event: Cb_Nivel_Click() - Sin acción (requiere Bt_Buscar)
```

### ComboBox: Cb_TipoAjuste
```vb6
Purpose: Filtro tipo ajuste contable
Options (Form_Load):
  AddItem(Cb_TipoAjuste, gTipoAjuste(TAJUSTE_FINANCIERO), 1)
  AddItem(Cb_TipoAjuste, gTipoAjuste(TAJUSTE_TRIBUTARIO), 2)
  CbSelItem(Cb_TipoAjuste, TAJUSTE_FINANCIERO)  ' Default
Filter Logic:
  If TipoAjuste = FINANCIERO Then
    WHERE (TipoAjuste IS NULL OR TipoAjuste IN (1,3))
  Else
    WHERE TipoAjuste IN (2,3)
```

### ComboBox: Cb_AreaNeg
```vb6
Purpose: Filtro Área de Negocio
Population: Call FillCbAreaNeg(Cb_AreaNeg, False)
  - False = incluir opción "TODAS"
Filter: WHERE MovComprobante.idAreaNeg = [Value]
Event: Cb_AreaNeg_Click() - Sin acción (requiere Bt_Buscar)
```

### ComboBox: Cb_CCosto
```vb6
Purpose: Filtro Centro de Costo
Population: Call FillCbCCosto(Cb_CCosto, False)
  - False = incluir opción "TODOS"
Filter: WHERE MovComprobante.idCCosto = [Value]
Event: Cb_CCosto_Click() - Sin acción (requiere Bt_Buscar)
```

---

## ☑️ CONTROLES UI - CHECKBOXES

### CheckBox: Ch_LibOficial
```vb6
Purpose: Marcar como Libro Oficial
Default: Unchecked (0)
Visible: Only if lBalClasif = TRUE
  - Hidden para Estado de Resultados
Checked:
  Filter: WHERE Comprobante.Estado = 1 (EC_APROBADO)
  Message: "Libro Oficial: solo comprobantes APROBADOS"
  Habilita: lPapelFoliado = TRUE en impresión
  Registra: Call AddLogImpresion() al imprimir
Unchecked:
  Filter: WHERE Comprobante.Estado IN (1,2)
Event: Ch_LibOficial_Click() - Sin acción (requiere Bt_Buscar)
```

### CheckBox: Ch_VerCodCuenta
```vb6
Purpose: Mostrar/ocultar columna código
Default: Checked (1) en Form_Load
Event: Ch_VerCodCuenta_Click()
  If Ch_VerCodCuenta = 1 Then
    Grid.ColWidth(C_CODIGO) = G_CODWIDTH
  Else
    Grid.ColWidth(C_CODIGO) = 0
  End If
```

### CheckBox: Ch_VerSubTot
```vb6
Purpose: Mostrar/ocultar subtotales RESULTADO
Default: Checked (1)
Visible: Only if lBalClasif = FALSE
  - Hidden para Balance Clasificado
Event: Ch_VerSubTot_Click()
  For i = 1 To Grid.rows - 1
    If Grid.TextMatrix(i, C_IDCUENTA) = TOT_CUENTA Then
      If Grid.TextMatrix(i, C_CLASCTA) = CLASCTA_RESULTADO Then
        If Ch_VerSubTot = 0 Then
          Grid.RowHeight(i) = 0
        Else
          Grid.RowHeight(i) = Grid.RowHeight(0)
        End If
      End If
    End If
  Next i
```

---

## 🔘 BOTONES TOOLBAR

### Bt_Buscar (Listar)
```vb6
Caption: "Listar" / Icon: Search
Purpose: Generar reporte con filtros
Enabled: Always (se deshabilita durante LoadAll)
Handler: Bt_Buscar_Click()
Action: Call LoadAll()
Validation: Ver PARTE 2
```

### Bt_CopyExcel
```vb6
Caption: "Copiar a Excel"
Purpose: Copiar grid al portapapeles
Handler: Bt_CopyExcel_Click()
Action: LP_FGr2Clip_Membr(Grid, "Fecha Inicio: " & Tx_Desde & "...")
Enabled: Bt_Buscar.Enabled = FALSE (ya listado)
```

### Bt_Email
```vb6
Caption: "Enviar Email"
Handler: Bt_Email_Click()
Action:
  vAjunto = Export_SendEmail(Grid, GridTot, Nothing, Nothing,
                             lCaption & "_" & Tx_Desde & "_" & Tx_Hasta,
                             "Fecha Inicio...", C_CODIGO)
  Set Frm = New FrmEmailAccount
  If Frm.FEdit(vAjunto) Then Frm.Show
```

### Bt_Preview
```vb6
Caption: "Vista Previa"
Handler: Bt_Preview_Click()
Action:
  1. lPapelFoliado = FALSE
  2. Call SetUpPrtGrid()
  3. Pag = gPrtLibros.PrtFlexGrid(Frm)
  4. Call PrtPieBalanceFirma(Frm, Pag, ..., 0)
Enabled: Bt_Buscar.Enabled = FALSE
```

### Bt_Print
```vb6
Caption: "Imprimir"
Handler: Bt_Print_Click()
Validation: Ver PARTE 2 (verifica log impresión)
Action: Ver PARTE 2 (impresión oficial)
```

### Bt_VerLibMayor
```vb6
Caption: "Ver Libro Mayor"
Purpose: Ver detalle cuenta seleccionada
Handler: Bt_VerLibMayor_Click()
Enabled: Grid.Row > 0 AND IdCuenta > 0
Action:
  lIdCuenta = Val(Grid.TextMatrix(Grid.Row, C_IDCUENTA))
  Set Frm = New FrmLibMayor
  Call Frm.FView(lIdCuenta, GetTxDate(Tx_Desde), GetTxDate(Tx_Hasta))
```

### Otros Botones
```vb6
Bt_Sum: Abre calculadora Windows
Bt_ConvMoneda: Conversor de moneda
Bt_Calc: Calculadora científica
Bt_Calendar: Calendario Windows
bt_Cerrar: Unload Me
```

---

## 🚀 FUNCIONES PÚBLICAS DE ENTRADA

### FViewBalClasif
```vb6
Public Function FViewBalClasif(Optional ByVal Mes As Integer = 0)
  lBalClasif = True
  lMensual = False
  lComparativo = False
  lCaption = "Balance General Clasificado"
  lClasCta = "1,2"  ' ACTIVO + PASIVO
  lLibOf = LIBOF_BALANCEGRAL
  If Mes > 0 Then lMes = Mes
  Me.Show vbModal
End Function
```

### FViewEstResultClasif
```vb6
Public Function FViewEstResultClasif(Optional ByVal Mes As Integer = 0)
  lBalClasif = False
  lMensual = False
  lComparativo = False
  lCaption = "Estado de Resultados Clasificado"
  lClasCta = "3"  ' RESULTADO
  lLibOf = 0
  If Mes > 0 Then lMes = Mes
  Me.Show vbModal
End Function
```

### FViewEstResultMensual
```vb6
Public Function FViewEstResultMensual(Optional ByVal Mes As Integer = 0)
  lBalClasif = False
  lMensual = True
  lComparativo = False
  lCaption = "Estado de Resultados Mensual"
  lClasCta = "3"
  lLibOf = 0
  If Mes > 0 Then lMes = Mes
  Me.Show vbModal
End Function
```

### FViewEstResultComparativo
```vb6
Public Function FViewEstResultComparativo(Optional ByVal Mes As Integer = 0)
  lBalClasif = False
  lMensual = True
  lComparativo = True
  lCaption = "Estado de Resultados Comparativo"
  lClasCta = "3"
  lLibOf = 0
  If Mes > 0 Then lMes = Mes
  Me.Show vbModal
End Function
```

---

## ⚙️ FORM_LOAD - INICIALIZACIÓN

```vb6
Private Sub Form_Load()
  ' 1. Determinar mes actual
  MesActual = GetMesActual()
  If lMes = 0 Then
    If MesActual > 0 Then
      lMes = MesActual
    Else
      lMes = GetUltimoMesConComps()
    End If
  End If
  
  ' 2. Establecer fechas por defecto
  ActDate = DateSerial(gEmpresa.Ano, lMes, 1)
  Call FirstLastMonthDay(ActDate, D1, D2)
  Call SetTxDate(Tx_Desde, DateSerial(gEmpresa.Ano, 1, 1))  ' 01/01
  Call SetTxDate(Tx_Hasta, D2)  ' Último día mes
  
  Me.Caption = lCaption
  
  ' 3. Configurar grid
  Call SetUpGrid
  
  ' 4. Llenar combos
  If gNiveles.nNiveles >= 3 Then
    Call FillNivel(Cb_Nivel, 3)
  Else
    Call FillNivel(Cb_Nivel, gNiveles.nNiveles)
  End If
  Cb_Nivel.RemoveItem(0)  ' Elimina nivel 1
  
  Call FillCbAreaNeg(Cb_AreaNeg, False)
  Call FillCbCCosto(Cb_CCosto, False)
  
  Call AddItem(Cb_TipoAjuste, gTipoAjuste(TAJUSTE_FINANCIERO), 1)
  Call AddItem(Cb_TipoAjuste, gTipoAjuste(TAJUSTE_TRIBUTARIO), 2)
  Call CbSelItem(Cb_TipoAjuste, TAJUSTE_FINANCIERO)
  
  ' 5. Configurar orientación
  If lMensual Then
    If lComparativo Then
      lOrientacion = ORIENT_VER
    Else
      lOrientacion = ORIENT_HOR
    End If
  Else
    lOrientacion = ORIENT_VER
  End If
  
  ' 6. Configurar checkboxes
  Ch_VerCodCuenta = 1
  Ch_VerSubTot.visible = False
  
  If lBalClasif = False Then
    Ch_LibOficial.visible = False
    Ch_VerSubTot.visible = True
    Ch_VerSubTot = 1
  End If
  
  ' 7. Cargar datos
  Call ReadResEje
  Call LoadAll
  Call SetupPriv
End Sub
```

---

**CONTINÚA EN:** `Analysis-Part2-EventHandlers.md`
