﻿namespace App.Features.BalanceClasificado;

/// <summary>
/// Interface para el servicio de Balance Clasificado
/// </summary>
public interface IBalanceClasificadoService
{
    /// <summary>
    /// Genera el balance clasificado según los filtros especificados
    /// </summary>
    Task<BalanceClasificadoResponse> GenerarBalanceAsync(BalanceClasificadoRequest request);

    /// <summary>
    /// Obtiene las opciones disponibles para los filtros
    /// </summary>
    Task<BalanceClasificadoOpciones> GetOpcionesFiltrosAsync(int empresaId, short ano);

    /// <summary>
    /// Exporta el balance clasificado a Excel o PDF
    /// </summary>
    Task<BalanceClasificadoExportResponse> ExportarBalanceAsync(BalanceClasificadoExportRequest request);

    /// <summary>
    /// Calcula la suma de movimientos para las cuentas seleccionadas
    /// </summary>
    Task<SumaMovimientosResponse> CalcularSumaMovimientosAsync(SumaMovimientosRequest request);

    /// <summary>
    /// Obtiene el libro mayor para una cuenta específica
    /// </summary>
    Task<object> GetLibroMayorAsync(int empresaId, short ano, int idCuenta, DateTime fechaDesde, DateTime fechaHasta);

    /// <summary>
    /// Valida los filtros del balance clasificado
    /// </summary>
    Task<ValidationResult> ValidarFiltrosAsync(BalanceClasificadoRequest request);

    /// <summary>
    /// Obtiene el balance clasificado en formato de vista previa (primeras 100 filas)
    /// </summary>
    Task<BalanceClasificadoResponse> GetVistaPreviaAsync(BalanceClasificadoRequest request);

    /// <summary>
    /// Obtiene estadísticas del balance clasificado
    /// </summary>
    Task<object> GetEstadisticasAsync(BalanceClasificadoRequest request);

    /// <summary>
    /// Verifica si el libro oficial ya ha sido impreso para el período especificado
    /// </summary>
    Task<bool> VerificarLibroOficialAsync(int empresaId, short ano, DateTime fechaDesde, DateTime fechaHasta);

    /// <summary>
    /// Registra la impresión oficial del Balance Clasificado en el log de auditoría
    /// </summary>
    Task RegistrarImpresionOficialAsync(int empresaId, short ano, DateTime fechaDesde, DateTime fechaHasta, 
        string usuario, int? numPagIni = null, int? numPagFin = null);
}