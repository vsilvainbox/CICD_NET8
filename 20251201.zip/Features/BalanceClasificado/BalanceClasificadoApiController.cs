using Microsoft.AspNetCore.Mvc;

namespace App.Features.BalanceClasificado;

/// <summary>
/// API Controller para Balance Clasificado
/// </summary>
[ApiController]
[Route("[controller]/[action]")]
public class BalanceClasificadoApiController(
    IBalanceClasificadoService service,
    ILogger<BalanceClasificadoApiController> logger) : ControllerBase
{
    /// <summary>
    /// Genera el balance clasificado
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<BalanceClasificadoResponse>> GenerarBalance([FromBody] BalanceClasificadoRequest request)
    {
        {
            logger.LogInformation("Generando balance clasificado. Empresa: {EmpresaId}, año: {Ano}, Nivel: {Nivel}, FechaCorte: {FechaCorte}, LibroOficial: {LibroOficial}", 
                request.EmpresaId, request.Ano, request.NivelDetalle, request.FechaCorte, request.LibroOficial);
            var result = await service.GenerarBalanceAsync(request);
            logger.LogInformation("Balance generado. Filas: {Filas}, TotalActivo: {Activo}, TotalPasivo: {Pasivo}", 
                result.Balance?.Filas?.Count ?? 0, result.Balance?.TotalActivo ?? 0, result.Balance?.TotalPasivo ?? 0);
            return Ok(result);
        }
    }

    /// <summary>
    /// Obtiene las opciones de filtros
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<BalanceClasificadoOpciones>> GetOpcionesFiltros(
        [FromQuery] int empresaId, 
        [FromQuery] short ano)
    {
        {
            var opciones = await service.GetOpcionesFiltrosAsync(empresaId, ano);
            return Ok(opciones);
        }
    }

    /// <summary>
    /// Exporta el balance clasificado
    /// </summary>
    [HttpPost]
    public async Task<ActionResult> ExportarBalance([FromBody] BalanceClasificadoExportRequest request)
    {
        {
            var result = await service.ExportarBalanceAsync(request);
            return File(result.FileContent, result.ContentType, result.FileName);
        }
    }

    /// <summary>
    /// Calcula la suma de movimientos seleccionados
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<SumaMovimientosResponse>> CalcularSumaMovimientos([FromBody] SumaMovimientosRequest request)
    {
        {
            var result = await service.CalcularSumaMovimientosAsync(request);
            return Ok(result);
        }
    }

    /// <summary>
    /// Obtiene el libro mayor para una cuenta
    /// </summary>
    [HttpGet]
    public async Task<ActionResult> GetLibroMayor(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        [FromQuery] int idCuenta,
        [FromQuery] DateTime fechaDesde,
        [FromQuery] DateTime fechaHasta)
    {
        {
            var result = await service.GetLibroMayorAsync(empresaId, ano, idCuenta, fechaDesde, fechaHasta);
            return Ok(result);
        }
    }

    /// <summary>
    /// Valida los filtros del balance
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<ValidationResult>> ValidarFiltros([FromBody] BalanceClasificadoRequest request)
    {
        {
            var result = await service.ValidarFiltrosAsync(request);
            return Ok(result);
        }
    }

    /// <summary>
    /// Obtiene vista previa del balance (primeras 100 filas)
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<BalanceClasificadoResponse>> GetVistaPrevia([FromBody] BalanceClasificadoRequest request)
    {
        {
            var result = await service.GetVistaPreviaAsync(request);
            return Ok(result);
        }
    }

    /// <summary>
    /// Obtiene estadísticas del balance
    /// </summary>
    [HttpPost]
    public async Task<ActionResult> GetEstadisticas([FromBody] BalanceClasificadoRequest request)
    {
        {
            var result = await service.GetEstadisticasAsync(request);
            return Ok(result);
        }
    }
}