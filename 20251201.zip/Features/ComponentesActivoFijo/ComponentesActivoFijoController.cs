using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Extensions;
using App.Helpers;

namespace App.Features.ComponentesActivoFijo;

public class ComponentesActivoFijoController(
    IHttpClientFactory httpClientFactory,
    ILogger<ComponentesActivoFijoController> logger,
    LinkGenerator linkGenerator) : Controller
{
    public IActionResult Index(int idActFijo)
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Componentes de Activo Fijo";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        // Obtener empresaId y ano desde la sesión
        int empresaId = SessionHelper.EmpresaId;
        int ano = SessionHelper.Ano;

        logger.LogInformation("Loading ComponentesActivoFijo for IdActFijo: {IdActFijo}, EmpresaId: {EmpresaId}, Ano: {Ano}",
            idActFijo, empresaId, ano);

        ViewData["IdActFijo"] = idActFijo;
        ViewData["EmpresaId"] = empresaId;
        ViewData["Ano"] = ano;

        return View();
    }

    [HttpGet]
    public async Task<IActionResult> GetDatos(int idActFijo, int empresaId, short ano)
    {
        logger.LogInformation("MVC Proxy: GetDatos for IdActFijo: {IdActFijo}", idActFijo);

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ComponentesActivoFijoApiController>(
            HttpContext,
            nameof(ComponentesActivoFijoApiController.GetDatos),
            new { idActFijo, empresaId, ano });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    [HttpGet]
    public async Task<IActionResult> GetDisponibles(int idGrupo, int idActFijo, int empresaId, short ano)
    {
        logger.LogInformation("MVC Proxy: GetDisponibles for IdGrupo: {IdGrupo}", idGrupo);

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ComponentesActivoFijoApiController>(
            HttpContext,
            nameof(ComponentesActivoFijoApiController.GetDisponibles),
            new { idGrupo, idActFijo, empresaId, ano });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    [HttpPost]
    public async Task<IActionResult> Guardar([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: Guardar component");

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ComponentesActivoFijoApiController>(
            HttpContext,
            nameof(ComponentesActivoFijoApiController.Guardar));
        var (statusCode, content) = await client.ProxyRequestAsync(url!, request!, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }

    [HttpDelete]
    public async Task<IActionResult> Eliminar(int idCompFicha, int empresaId, short ano)
    {
        logger.LogInformation("MVC Proxy: Eliminar for IdCompFicha: {IdCompFicha}", idCompFicha);

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ComponentesActivoFijoApiController>(
            HttpContext,
            nameof(ComponentesActivoFijoApiController.Eliminar),
            new { idCompFicha, empresaId, ano });
        var (statusCode, content) = await client.ProxyRequestAsync(url!, null, HttpMethod.Delete);
        return StatusCode(statusCode, content);
    }

    [HttpPost]
    public async Task<IActionResult> SinDetComps([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: SinDetComps");

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ComponentesActivoFijoApiController>(
            HttpContext,
            nameof(ComponentesActivoFijoApiController.ActualizarSinDetComps));
        var (statusCode, content) = await client.ProxyRequestAsync(url!, request!, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }
}
