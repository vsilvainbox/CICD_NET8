﻿namespace App.Features.ConfiguracionImpuestosAdicionales;

/// <summary>
/// Interface para servicio de configuración de impuestos adicionales
/// </summary>
public interface IConfiguracionImpuestosAdicionalesService
{
    /// <summary>
    /// Obtiene la configuración de impuestos adicionales para una empresa
    /// </summary>
    Task<ConfiguracionImpuestosResponse> GetConfiguracionAsync(GetConfiguracionRequest request);

    /// <summary>
    /// Guarda la configuración de impuestos adicionales
    /// </summary>
    Task<ConfiguracionImpuestosResponse> SaveConfiguracionAsync(SaveConfiguracionRequest request);

    /// <summary>
    /// Obtiene los tipos de valores (impuestos) disponibles para configurar
    /// </summary>
    Task<List<TipoValorDisponibleDto>> GetTiposValoresDisponiblesAsync(byte tipoLib);

    /// <summary>
    /// Obtiene los impuestos configurados para selección en documento
    /// </summary>
    Task<List<ImpuestoAdicionalDto>> GetImpuestosParaSeleccionAsync(SeleccionarImpuestosRequest request);

    /// <summary>
    /// Asigna una cuenta contable a un tipo de impuesto
    /// </summary>
    Task<ConfiguracionImpuestosResponse> AsignarCuentaAsync(AsignarCuentaRequest request);

    /// <summary>
    /// Elimina la configuración de un impuesto adicional
    /// </summary>
    Task<ConfiguracionImpuestosResponse> EliminarImpuestoAsync(EliminarImpuestoRequest request);

    /// <summary>
    /// Copia la configuración de impuestos de una empresa a otra
    /// </summary>
    Task<ConfiguracionImpuestosResponse> CopiarConfiguracionAsync(CopiarConfiguracionRequest request);

    /// <summary>
    /// Valida que un impuesto esté correctamente configurado
    /// </summary>
    Task<(bool isValid, string message)> ValidarImpuestoAsync(int empresaId, short ano, byte tipoLib, short tipoValor);
}