using Microsoft.AspNetCore.Mvc;

namespace App.Features.ConfiguracionImpuestosAdicionales;

/// <summary>
/// API Controller para configuración de impuestos adicionales
/// </summary>
[ApiController]
[Route("[controller]/[action]")]
public class ConfiguracionImpuestosAdicionalesApiController(
    IConfiguracionImpuestosAdicionalesService service,
    ILogger<ConfiguracionImpuestosAdicionalesApiController> logger) : ControllerBase
{
    /// <summary>
    /// Obtiene la configuración de impuestos adicionales
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<ConfiguracionImpuestosResponse>> GetImpuestosAdicionales(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        [FromQuery] byte tipoLib)
    {
        {
            var request = new GetConfiguracionRequest
            {
                EmpresaId = empresaId,
                Ano = ano,
                TipoLib = tipoLib
            };

            var response = await service.GetConfiguracionAsync(request);
            return Ok(response);
        }
    }

    /// <summary>
    /// Guarda la configuración de impuestos adicionales
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<ConfiguracionImpuestosResponse>> GuardarConfiguracion(
        [FromBody] SaveConfiguracionRequest request)
    {
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage)
                    .ToArray();
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors });
            }

            var response = await service.SaveConfiguracionAsync(request);

            if (!response.Success)
            {
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { response.Message ?? "Error al guardar la configuración" } });
            }

            return Ok(response);
        }
    }

    /// <summary>
    /// Obtiene los tipos de valores disponibles para configurar
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<List<TipoValorDisponibleDto>>> GetTiposValores(
        [FromQuery] byte tipoLib)
    {
        {
            var tiposValores = await service.GetTiposValoresDisponiblesAsync(tipoLib);
            return Ok(tiposValores);
        }
    }

    /// <summary>
    /// Obtiene los impuestos para selección en documento
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<List<ImpuestoAdicionalDto>>> GetImpuestosParaSeleccion(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        [FromQuery] byte tipoLib,
        [FromQuery] byte tipoDoc)
    {
        {
            var request = new SeleccionarImpuestosRequest
            {
                EmpresaId = empresaId,
                Ano = ano,
                TipoLib = tipoLib,
                TipoDoc = tipoDoc
            };

            var impuestos = await service.GetImpuestosParaSeleccionAsync(request);
            return Ok(impuestos);
        }
    }

    /// <summary>
    /// Asigna una cuenta contable a un tipo de impuesto
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<ConfiguracionImpuestosResponse>> AsignarCuenta(
        [FromBody] AsignarCuentaRequest request)
    {
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage)
                    .ToArray();
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors });
            }

            var response = await service.AsignarCuentaAsync(request);

            if (!response.Success)
            {
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { response.Message ?? "Error al asignar la cuenta" } });
            }

            return Ok(response);
        }
    }

    /// <summary>
    /// Elimina la configuración de un impuesto
    /// </summary>
    [HttpDelete]
    public async Task<ActionResult<ConfiguracionImpuestosResponse>> EliminarImpuesto(
        int idImpAdic,
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        {
            var request = new EliminarImpuestoRequest
            {
                IdImpAdic = idImpAdic,
                EmpresaId = empresaId,
                Ano = ano
            };

            var response = await service.EliminarImpuestoAsync(request);

            if (!response.Success)
            {
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { response.Message ?? "Error al eliminar el impuesto" } });
            }

            return Ok(response);
        }
    }

    /// <summary>
    /// Copia la configuración de una empresa a otra
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<ConfiguracionImpuestosResponse>> CopiarConfiguracion(
        [FromBody] CopiarConfiguracionRequest request)
    {
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage)
                    .ToArray();
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors });
            }

            var response = await service.CopiarConfiguracionAsync(request);

            if (!response.Success)
            {
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { response.Message ?? "Error al copiar la configuración" } });
            }

            return Ok(response);
        }
    }

    /// <summary>
    /// Valida la configuración de un impuesto
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<object>> ValidarImpuesto(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        [FromQuery] byte tipoLib,
        [FromQuery] short tipoValor)
    {
        {
            var (isValid, message) = await service.ValidarImpuestoAsync(empresaId, ano, tipoLib, tipoValor);
                
            return Ok(new
            {
                isValid,
                message
            });
        }
    }
}