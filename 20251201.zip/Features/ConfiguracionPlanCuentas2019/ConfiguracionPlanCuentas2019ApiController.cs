using Microsoft.AspNetCore.Mvc;

namespace App.Features.ConfiguracionPlanCuentas2019;

[ApiController]
[Route("[controller]/[action]")]
public class ConfiguracionPlanCuentas2019ApiController(
    IConfiguracionPlanCuentas2019Service service,
    ILogger<ConfiguracionPlanCuentas2019ApiController> logger) : ControllerBase
{
    /// <summary>
    /// Valida prerequisitos para aplicar el plan de cuentas 2019
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<ValidacionPrerequisitosResult>> ValidarPrerequisitos(int empresaId, short ano)
    {
        logger.LogInformation("API: ValidarPrerequisitos called for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var result = await service.ValidarPrerequisitosAsync(empresaId, ano);
            return Ok(result);
        }
    }

    /// <summary>
    /// Obtiene vista previa del plan de cuentas PERSONALIZADO
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<PreviewPlanResult>> ObtenerVistaPrevia()
    {
        logger.LogInformation("API: ObtenerVistaPrevia called");

        {
            var result = await service.ObtenerVistaPreviaAsync();
            return Ok(result);
        }
    }

    /// <summary>
    /// Aplica el plan de cuentas PERSONALIZADO 2019
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<AplicarPlanResponse>> AplicarPlan([FromBody] AplicarPlanRequest request)
    {
        logger.LogInformation("API: AplicarPlan called for empresaId: {EmpresaId}, ano: {Ano}, confirm: {Confirm}",
            request.EmpresaId, request.Ano, request.ConfirmarSobreescritura);

        {
            var result = await service.AplicarPlanPersonalizadoAsync(
                request.EmpresaId,
                request.Ano,
                request.ConfirmarSobreescritura);

            if (!result.Success)
            {
                return BadRequest(result);
            }

            return Ok(result);
        }
    }
}
