using System.ComponentModel.DataAnnotations;

namespace App.Features.CapitalSimpleMini;

/// <summary>
/// DTO para Capital Propio Simplificado Mini - Vista completa
/// </summary>
public class CapitalSimpleMiniDto
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public byte TipoDetCps { get; set; }
    public int TipoInforme { get; set; }
    public string Titulo { get; set; } = string.Empty;
    public bool MostrarBotonAcumulado { get; set; }
        
    public List<AcumuladoAnualDto> AcumuladosAnteriores { get; set; } = new List<AcumuladoAnualDto>();
    public List<DetalleCapitalDto> DetallesAnoActual { get; set; } = new List<DetalleCapitalDto>();
        
    public decimal TotalAno { get; set; }
    public decimal TotalAcumulado { get; set; }
}

/// <summary>
/// Acumulado anual de años anteriores
/// </summary>
public class AcumuladoAnualDto
{
    public int AnoValor { get; set; }
    public decimal Valor { get; set; }
}

/// <summary>
/// Detalle de capital del año actual
/// </summary>
public class DetalleCapitalDto
{
    public int IdDetCapPropioSimpl { get; set; }
    public bool? IngresoManual { get; set; }
    public DateTime? Fecha { get; set; }
    public string Descrip { get; set; } = string.Empty;
    public decimal Valor { get; set; }
    public bool IsNew { get; set; }
    public bool IsModified { get; set; }
    public bool IsDeleted { get; set; }
}

/// <summary>
/// DTO para guardar cambios
/// </summary>
public class CapitalSimpleMiniSaveDto
{
    [Required]
    public int EmpresaId { get; set; }
        
    [Required]
    public short Ano { get; set; }
        
    [Required]
    public byte TipoDetCps { get; set; }
        
    public List<DetalleCapitalDto> Detalles { get; set; } = new List<DetalleCapitalDto>();
}

/// <summary>
/// DTO para resultado de cálculo de totales
/// </summary>
public class CalculoTotalesDto
{
    public decimal TotalAno { get; set; }
    public decimal TotalAcumulado { get; set; }
}

/// <summary>
/// DTO para resultado de validación
/// </summary>
public class ValidationResult
{
    public bool IsValid { get; set; }
    public List<string> Errors { get; set; } = new List<string>();
    public string ErrorMessage => string.Join(", ", Errors);
}