using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.BaseImponible14DCompleta;

/// <summary>
/// Controlador MVC para Base Imponible 14D Completa
/// REFACTORIZADO: Usa ViewModels, Model Binding, server-side rendering
/// </summary>
public class BaseImponible14DCompletaController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<BaseImponible14DCompletaController> logger) : Controller
{
    /// <summary>
    /// Vista principal de la base imponible 14D completa
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Index(bool expandirTodo = false, bool modoSaldosVigentes = false)
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Base Imponible 14D Completa";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        try
        {
            logger.LogInformation("Accediendo a Base Imponible 14D Completa para empresa {EmpresaId} año {Ano}",
                SessionHelper.EmpresaId, SessionHelper.Ano);

            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<BaseImponible14DCompletaApiController>(
                HttpContext,
                nameof(BaseImponible14DCompletaApiController.GetByEmpresaAno),
                new { empresaId = SessionHelper.EmpresaId, ano = SessionHelper.Ano });

            var dto = await client.GetFromApiAsync<BaseImponible14DCompletaDto>(url!);

            // Mapear DTO a ViewModel
            var viewModel = MapearDtoAViewModel(dto, expandirTodo, modoSaldosVigentes);

            return View(viewModel);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error al cargar Base Imponible 14D");
            TempData["SwalError"] = "Error al cargar los datos de la base imponible";
            TempData["SwalType"] = "error";
            return RedirectToAction("Index", "Home");
        }
    }

    /// <summary>
    /// Vista de detalle para edición de valores manuales
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> EditarDetalle(int codigo, string descripcion)
    {
        {
            logger.LogInformation("Editando detalle c�digo {Codigo} para empresa {EmpresaId} año {Ano}",
                codigo, SessionHelper.EmpresaId, SessionHelper.Ano);

            ViewData["EmpresaId"] = SessionHelper.EmpresaId;
            ViewData["Ano"] = SessionHelper.Ano;
            ViewData["Codigo"] = codigo;
            ViewData["Descripcion"] = descripcion ?? string.Empty;

            await Task.CompletedTask;
            return View();
        }
    }

    /// <summary>
    /// Vista de impresión
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Print()
    {
        {
            logger.LogInformation("Vista de impresión para empresa {EmpresaId} año {Ano}",
                SessionHelper.EmpresaId, SessionHelper.Ano);

            ViewData["EmpresaId"] = SessionHelper.EmpresaId;
            ViewData["Ano"] = SessionHelper.Ano;

            await Task.CompletedTask;
            return View();
        }
    }

    /// <summary>
    /// Vista de asistente PPM (para año >= 2022)
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> AsistentePPM()
    {
        {
            if (SessionHelper.Ano < 2022)
            {
                TempData["Warning"] = "El asistente PPM est� disponible solo para años 2022 en adelante";
                return RedirectToAction("Index");
            }

            logger.LogInformation("Abriendo asistente PPM para empresa {EmpresaId} año {Ano}",
                SessionHelper.EmpresaId, SessionHelper.Ano);

            ViewData["EmpresaId"] = SessionHelper.EmpresaId;
            ViewData["Ano"] = SessionHelper.Ano;

            await Task.CompletedTask;
            return View();
        }
    }

    /// <summary>
    /// Proxy para obtener datos de base imponible
    /// GET /BaseImponible14DCompleta/GetData
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetData(int empresaId, short ano)
    {
        logger.LogInformation("BaseImponible14DCompleta: GetData proxy called");
        {
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<BaseImponible14DCompletaApiController>(HttpContext, nameof(BaseImponible14DCompletaApiController.GetByEmpresaAno), new { empresaId, ano });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Proxy para obtener saldos vigentes
    /// GET /BaseImponible14DCompleta/GetSaldosVigentes
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetSaldosVigentes(int empresaId, short ano)
    {
        logger.LogInformation("BaseImponible14DCompleta: GetSaldosVigentes proxy called");
        {
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<BaseImponible14DCompletaApiController>(HttpContext, nameof(BaseImponible14DCompletaApiController.GetWithNonZeroValues), new { empresaId, ano });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Proxy para actualizar item
    /// PUT /BaseImponible14DCompleta/UpdateItem
    /// </summary>
    [HttpPut]
    public async Task<IActionResult> UpdateItem([FromBody] JsonElement request)
    {
        logger.LogInformation("BaseImponible14DCompleta: UpdateItem proxy called");
        {
            var empresaId = request.GetProperty("empresaId").GetInt32();
            var ano = request.GetProperty("ano").GetInt32();
            var codigo = request.GetProperty("codigo").GetString();

            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<BaseImponible14DCompletaApiController>(HttpContext, nameof(BaseImponible14DCompletaApiController.UpdateItemValue), new { empresaId, ano, codigo });
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Put);
            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// Proxy para guardar toda la base imponible
    /// POST /BaseImponible14DCompleta/Save
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Save([FromBody] JsonElement request)
    {
        logger.LogInformation("BaseImponible14DCompleta: Save proxy called");
        {
            var empresaId = request.GetProperty("empresaId").GetInt32();
            var ano = request.GetProperty("ano").GetInt32();

            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<BaseImponible14DCompletaApiController>(HttpContext, nameof(BaseImponible14DCompletaApiController.Save), new { empresaId, ano });
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// Proxy para exportar a Excel
    /// GET /BaseImponible14DCompleta/ExportExcel
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ExportExcel(int empresaId, short ano)
    {
        logger.LogInformation("BaseImponible14DCompleta: ExportExcel proxy called");
        {
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<BaseImponible14DCompletaApiController>(HttpContext, nameof(BaseImponible14DCompletaApiController.ExportToExcel), new { empresaId, ano });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Vista de saldos vigentes (solo items con valores)
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> SaldosVigentes(int empresaId, short ano)
    {
        try
        {
            logger.LogInformation("Cargando saldos vigentes para empresa {EmpresaId} año {Ano}", empresaId, ano);

            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<BaseImponible14DCompletaApiController>(
                HttpContext,
                nameof(BaseImponible14DCompletaApiController.GetWithNonZeroValues),
                new { empresaId, ano });

            var dto = await client.GetFromApiAsync<BaseImponible14DCompletaDto>(url!);

            // Mapear DTO a ViewModel con modo saldos vigentes
            var viewModel = MapearDtoAViewModel(dto, expandirTodo: true, modoSaldosVigentes: true);

            return View("Index", viewModel);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error al cargar saldos vigentes");
            TempData["SwalError"] = "Error al cargar los saldos vigentes";
            TempData["SwalType"] = "error";
            return RedirectToAction("Index");
        }
    }

    /// <summary>
    /// Actualizar valor de un item (con Model Binding y validación de cultura)
    /// POST /BaseImponible14DCompleta/ActualizarValor
    /// REFACTORIZADO: Recibe valor como string, parsea con cultura chilena en servidor
    /// Elimina parseFloat del cliente - parsing seguro server-side
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ActualizarValor([FromForm] EditarValorRequest request)
    {
        // Model Binding + IValidatableObject ejecuta la validación automáticamente
        if (!ModelState.IsValid)
        {
            var errors = ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage)
                .ToList();

            logger.LogWarning("Validación fallida al actualizar valor código {Codigo}: {Errors}",
                request.Codigo, string.Join(", ", errors));

            return Json(new
            {
                success = false,
                errors = errors,
                swalType = "warning",
                swalTitle = "Validación",
                swalText = errors.FirstOrDefault() ?? "Datos inválidos"
            });
        }

        try
        {
            logger.LogInformation(
                "Actualizando valor código {Codigo} = {Valor} (formato: {ValorFormateado}) para empresa {EmpresaId} año {Ano}",
                request.Codigo,
                request.Valor,
                request.Valor.ToString("N2", new System.Globalization.CultureInfo("es-CL")),
                request.EmpresaId,
                request.Ano);

            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<BaseImponible14DCompletaApiController>(
                HttpContext,
                nameof(BaseImponible14DCompletaApiController.UpdateItemValue),
                new { empresaId = request.EmpresaId, ano = request.Ano, codigo = request.Codigo });

            var updateDto = new { valor = request.Valor };
            var (statusCode, content) = await client.ProxyRequestAsync(url!, updateDto, HttpMethod.Put);

            if (statusCode >= 200 && statusCode < 300)
            {
                // Retornar valor parseado y formateado para que el cliente lo use sin modificación
                return Json(new
                {
                    success = true,
                    valor = request.Valor,
                    valorFormateado = request.Valor.ToString("N2", new System.Globalization.CultureInfo("es-CL")),
                    message = "Valor actualizado correctamente",
                    swalType = "success",
                    swalTitle = "Guardado",
                    swalText = "El valor se actualizó correctamente"
                });
            }

            return StatusCode(statusCode, content);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error al actualizar valor código {Codigo}", request.Codigo);
            return Json(new
            {
                success = false,
                message = "Error al actualizar el valor",
                swalType = "error",
                swalTitle = "Error",
                swalText = "No se pudo guardar el valor. Por favor, intente nuevamente."
            });
        }
    }

    /// <summary>
    /// Mapear DTO de API a ViewModel para la vista
    /// </summary>
    private BaseImponible14DCompletaViewModel MapearDtoAViewModel(
        BaseImponible14DCompletaDto dto,
        bool expandirTodo,
        bool modoSaldosVigentes)
    {
        var viewModel = new BaseImponible14DCompletaViewModel
        {
            EmpresaId = dto.IdEmpresa,
            Ano = dto.Ano,
            NombreEmpresa = dto.NombreEmpresa,
            Regimen = dto.Regimen,
            ProPymeGeneral = dto.ProPymeGeneral,
            ProPymeTransp = dto.ProPymeTransp,
            PeriodoCerrado = dto.PeriodoCerrado,
            TotalIngresos = dto.TotalIngresos,
            TotalEgresos = dto.TotalEgresos,
            BaseImponible = dto.BaseImponible,
            ModoSaldosVigentes = modoSaldosVigentes,
            Secciones = dto.Secciones.Select(s => new BaseImponible14DSeccionViewModel
            {
                Nivel = s.Nivel,
                Titulo = s.Titulo,
                Subtotal = s.Subtotal,
                Expandida = s.Expandida || expandirTodo,
                Items = s.Items.Select(i => MapearItemDtoAViewModel(i, expandirTodo)).ToList()
            }).ToList()
        };

        // Construir set de nodos expandidos
        if (expandirTodo)
        {
            foreach (var seccion in viewModel.Secciones)
            {
                AgregarNodosExpandidos(seccion.Items, viewModel.NodosExpandidos);
            }
        }

        return viewModel;
    }

    /// <summary>
    /// Mapear item DTO a ViewModel recursivamente
    /// </summary>
    private BaseImponible14DItemViewModel MapearItemDtoAViewModel(BaseImponible14DItemDto dto, bool expandirTodo)
    {
        return new BaseImponible14DItemViewModel
        {
            IdBaseImponible14D = dto.IdBaseImponible14D,
            IdEmpresa = dto.IdEmpresa,
            Ano = dto.Ano,
            Tipo = dto.Tipo,
            Nivel = dto.Nivel,
            Codigo = dto.Codigo,
            Descripcion = dto.Descripcion,
            Valor = dto.Valor,
            FormaIngreso = dto.FormaIngreso,
            EsEditable = dto.EsEditable,
            EsSubtotal = dto.EsSubtotal,
            EsNegrita = dto.EsNegrita,
            EsVisible = dto.EsVisible,
            ColorTexto = dto.ColorTexto,
            TieneHijos = dto.TieneHijos,
            Expandido = dto.Expandido || expandirTodo,
            CodigoEspejo = dto.CodigoEspejo,
            Hijos = dto.Hijos.Select(h => MapearItemDtoAViewModel(h, expandirTodo)).ToList()
        };
    }

    /// <summary>
    /// Agregar códigos de nodos expandidos al set
    /// </summary>
    private void AgregarNodosExpandidos(List<BaseImponible14DItemViewModel> items, HashSet<int> nodosExpandidos)
    {
        foreach (var item in items)
        {
            if (item.TieneHijos && item.Nivel <= 4)
            {
                nodosExpandidos.Add(item.Codigo);
            }

            if (item.Hijos.Any())
            {
                AgregarNodosExpandidos(item.Hijos, nodosExpandidos);
            }
        }
    }
}