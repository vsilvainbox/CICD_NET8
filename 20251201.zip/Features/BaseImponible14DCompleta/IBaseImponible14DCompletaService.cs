﻿namespace App.Features.BaseImponible14DCompleta;

/// <summary>
/// Interface para servicio de Base Imponible 14D Completa
/// </summary>
public interface IBaseImponible14DCompletaService
{
    // Carga principal
    Task<BaseImponible14DCompletaDto> GetByEmpresaAnoAsync(int empresaId, short ano);
    Task<IEnumerable<BaseImponible14DItemDto>> GetHierarchicalStructureAsync(int empresaId, short ano);

    // Operaciones CRUD
    Task<BaseImponible14DResultDto> SaveAsync(int empresaId, short ano, BaseImponible14DSaveDto dto);
    Task<BaseImponible14DItemDto> UpdateItemValueAsync(int empresaId, short ano, short codigo, decimal valor);

    // Cálculos principales
    Task<decimal> CalculateTotalTaxBaseAsync(int empresaId, short ano);
    Task RecalculateHierarchyAsync(int empresaId, short ano);
    Task<IEnumerable<BaseImponible14DItemDto>> CalculateAutomaticValuesAsync(int empresaId, short ano);

    // Valores específicos de cuentas y traspasos
    Task<decimal> GetPerceivedPaidIncomeAsync(int empresaId, short ano, int tipoOperCaja, string regimen);
    Task<decimal> GetPreviousAccruedAsync(int empresaId, short ano, int tipoOperCaja, string regimen);
    Task<decimal> GetPaidInventoryAsync(int empresaId, short ano, int tipoOperCaja, bool incluirNotas = true);
    Task<decimal> GetPerceivedPaidPurchasesAsync(int empresaId, short ano, int tipoOperCaja, string regimen);
    Task<decimal> GetAccountTotalF22Async(int empresaId, short ano, int codigoF22, string tipo);
    Task<decimal> LoadAdjustmentValuesAsync(int empresaId, short ano, int tipoAjuste, int idItem, int tipoComp);
    Task<decimal> GetELCAdjustmentsAsync(int empresaId, short ano, int tipoAjuste, int item);
    Task<decimal> GetCredit33BisAsync(int empresaId, short ano);
    Task<decimal> GetDepreciableFixedAssetsAsync(int empresaId, short ano, int tipoOperCaja);
    Task<decimal> GetCreditNotesF22Async(int empresaId, short ano, int codigoF22, string tipo);
    Task<decimal> GetInventoryCreditNotesAsync(int empresaId, short ano);
    Task<decimal> CalculateNonRecoverableVATAsync(int empresaId, short ano);
    Task<decimal> GetPPMAdjustmentAsync(int empresaId, short ano);
    Task<decimal> GetPreviousYearLossAsync(int empresaId, short ano);

    // Filtros y vistas
    Task<BaseImponible14DCompletaDto> GetItemsWithBalancesAsync(int empresaId, short ano); // Saldos Vigentes
    Task<IEnumerable<BaseImponible14DItemDto>> GetWithNonZeroValuesAsync(int empresaId, short ano);
    Task<IEnumerable<BaseImponible14DItemDto>> FilterByRegimeAsync(int empresaId, short ano, string regime);
    Task<BaseImponible14DCompletaDto> ApplyFiltersAsync(int empresaId, short ano, BaseImponible14DFiltroDto filtro);

    // Validaciones
    Task<BaseImponible14DValidationResult> ValidateAsync(int empresaId, short ano);
    Task<bool> IsPeriodOpenAsync(int empresaId, short ano);

    // Exportación
    Task<byte[]> ExportToExcelAsync(int empresaId, short ano);
    Task<byte[]> GeneratePrintPreviewAsync(int empresaId, short ano);

    // Utilidades
    Task UpdateMirrorValuesAsync(int empresaId, short ano, short codigoOrigen);
    Task ClearDetailsByCodeAsync(int empresaId, short ano, int codigo);
    Task<BaseImponible14DCalculoDto> GetDetailedCalculationAsync(int empresaId, short ano);
}