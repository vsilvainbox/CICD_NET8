namespace App.Features.BaseImponible14DCompleta;

/// <summary>
/// DTO principal para Base Imponible 14D Completa
/// </summary>
public class BaseImponible14DCompletaDto
{
    public int IdEmpresa { get; set; }
    public short Ano { get; set; }
    public string NombreEmpresa { get; set; } = string.Empty;
    public string Regimen { get; set; } = string.Empty; // 14DN3 o 14DN8
    public bool? ProPymeGeneral { get; set; }
    public bool? ProPymeTransp { get; set; }
    public decimal BaseImponible { get; set; }
    public bool PeriodoCerrado { get; set; }
    public List<BaseImponible14DSeccionDto> Secciones { get; set; } = new();
    public decimal TotalIngresos { get; set; }
    public decimal TotalEgresos { get; set; }
}

/// <summary>
/// DTO para sección jerárquica
/// </summary>
public class BaseImponible14DSeccionDto
{
    public byte Nivel { get; set; }
    public string Titulo { get; set; } = string.Empty;
    public decimal Subtotal { get; set; }
    public bool Expandida { get; set; } = true;
    public List<BaseImponible14DItemDto> Items { get; set; } = new();
}

/// <summary>
/// DTO para item individual de Base Imponible 14D
/// </summary>
public class BaseImponible14DItemDto
{
    public int IdBaseImponible14D { get; set; }
    public int IdEmpresa { get; set; }
    public short Ano { get; set; }
    public byte Tipo { get; set; } // 1=Ingreso, 2=Egreso
    public byte Nivel { get; set; } // 1-5
    public short Codigo { get; set; }
    public string Descripcion { get; set; } = string.Empty;
    public decimal Valor { get; set; }
    public byte FormaIngreso { get; set; } // Manual, Traspaso, etc.
    public bool EsEditable { get; set; }
    public bool EsSubtotal { get; set; }
    public bool EsNegrita { get; set; }
    public bool EsVisible { get; set; } = true;
    public string ColorTexto { get; set; } = string.Empty;
    public bool TieneHijos { get; set; }
    public bool Expandido { get; set; } = true;
    public int? CodigoEspejo { get; set; } // Para items espejo (8100-8300, etc.)
    public List<BaseImponible14DItemDto> Hijos { get; set; } = new();
}

/// <summary>
/// DTO para guardar cambios
/// </summary>
public class BaseImponible14DSaveDto
{
    public List<BaseImponible14DItemUpdateDto> ItemsActualizados { get; set; } = new();
}

/// <summary>
/// DTO para actualizar un item
/// </summary>
public class BaseImponible14DItemUpdateDto
{
    public short Codigo { get; set; }
    public decimal Valor { get; set; }
}

/// <summary>
/// DTO para resultado de guardado
/// </summary>
public class BaseImponible14DResultDto
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public int RegistrosActualizados { get; set; }
    public int RegistrosInsertados { get; set; }
    public decimal BaseImponibleCalculada { get; set; }
}

/// <summary>
/// DTO para cálculo detallado
/// </summary>
public class BaseImponible14DCalculoDto
{
    public Dictionary<string, decimal> DetalleIngresos { get; set; } = new();
    public Dictionary<string, decimal> DetalleEgresos { get; set; } = new();
    public decimal TotalIngresos { get; set; }
    public decimal TotalEgresos { get; set; }
    public decimal BaseImponible { get; set; }
    public decimal IVAIrrecuperable { get; set; }
    public decimal PPMAjuste { get; set; }
    public decimal PerdidaAnoAnterior { get; set; }
}

/// <summary>
/// Enums para tipos y formas de ingreso
/// </summary>
public enum TipoBaseImponible14D
{
    Ingreso = 1,
    Egreso = 2
}

public enum FormaIngreso14D
{
    Manual = 1,
    Traspaso = 2,
    TraspasoAjuste = 3,
    TraspasoLibCaja = 4,
    Ambos = 5,
    AmbosAjuste = 6
}

public enum NivelJerarquico14D
{
    BaseImponible = 1,
    SeccionPrincipal = 2,
    Subseccion = 3,
    Categoria = 4,
    ItemFinal = 5
}

/// <summary>
/// Constantes para regímenes tributarios
/// </summary>
public static class RegimenesTributarios
{
    public const string FTE_14DN3 = "14DN3";
    public const string FTE_14DN8 = "14DN8";
    public const string FTE_14A = "14A";
}

/// <summary>
/// Códigos especiales que tienen tratamiento específico
/// </summary>
public static class CodigosEspeciales14D
{
    // Códigos espejo
    public const short Codigo8100 = 8100;
    public const short Codigo8300 = 8300;

    // Serie de traspasos
    public const short Codigo7400 = 7400;
    public const short Codigo7500 = 7500;
    public const short Codigo7600 = 7600;
    public const short Codigo7700 = 7700;
    public const short Codigo7800 = 7800;
    public const short Codigo7900 = 7900;

    // Contrapartida de traspasos
    public const short Codigo10800 = 10800;
    public const short Codigo10900 = 10900;
    public const short Codigo11000 = 11000;
    public const short Codigo11100 = 11100;
    public const short Codigo11200 = 11200;
    public const short Codigo11300 = 11300;

    // Otros especiales
    public const short PPM = 2800;
    public const short PerdidaAnterior = 9600;
    public const short Existencias = 5200;
}

/// <summary>
/// DTO para filtros de búsqueda
/// </summary>
public class BaseImponible14DFiltroDto
{
    public bool SoloConValores { get; set; }
    public string Regimen { get; set; } = string.Empty;
    public short? NivelMaximo { get; set; }
    public bool ExpandirTodo { get; set; }
}

/// <summary>
/// Resultado de validación
/// </summary>
public class BaseImponible14DValidationResult
{
    public bool IsValid { get; set; }
    public List<string> Errors { get; set; } = new();
    public string ErrorMessage => string.Join(", ", Errors);
}