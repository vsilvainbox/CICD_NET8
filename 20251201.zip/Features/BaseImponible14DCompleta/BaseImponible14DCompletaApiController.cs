using Microsoft.AspNetCore.Mvc;

namespace App.Features.BaseImponible14DCompleta;

/// <summary>
/// Controlador API para Base Imponible 14D Completa
/// </summary>
[ApiController]
[Route("[controller]/[action]")]
public class BaseImponible14DCompletaApiController(
    IBaseImponible14DCompletaService service,
    ILogger<BaseImponible14DCompletaApiController> logger) : ControllerBase
{
    /// <summary>
    /// Obtiene la base imponible 14D completa para una empresa y año
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<BaseImponible14DCompletaDto>> GetByEmpresaAno(int empresaId, short ano)
    {
        {
            logger.LogInformation("API: Obteniendo base imponible 14D para empresa {EmpresaId} año {Ano}", empresaId, ano);

            var result = await service.GetByEmpresaAnoAsync(empresaId, ano);
            return Ok(result);
        }
    }

    /// <summary>
    /// Obtiene la estructura jerárquica
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<IEnumerable<BaseImponible14DItemDto>>> GetHierarchicalStructure(int empresaId, short ano)
    {
        {
            logger.LogInformation("API: Obteniendo estructura jerárquica para empresa {EmpresaId} año {Ano}", empresaId, ano);

            var result = await service.GetHierarchicalStructureAsync(empresaId, ano);
            return Ok(result);
        }
    }

    /// <summary>
    /// Guarda los cambios en la base imponible
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<BaseImponible14DResultDto>> Save(
        int empresaId,
        short ano,
        [FromBody] BaseImponible14DSaveDto dto)
    {
        {
            if (dto == null)
            {
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "Datos inválidos" } });
            }

            logger.LogInformation("API: Guardando base imponible 14D para empresa {EmpresaId} año {Ano}", empresaId, ano);

            var result = await service.SaveAsync(empresaId, ano, dto);

            if (result.Success)
            {
                return Ok(result);
            }
            else
            {
                return BadRequest(result);
            }
        }
    }

    /// <summary>
    /// Actualiza el valor de un item específico
    /// </summary>
    [HttpPut]
    public async Task<ActionResult<BaseImponible14DItemDto>> UpdateItemValue(
        int empresaId,
        short ano,
        short codigo,
        [FromBody] decimal valor)
    {
        {
            logger.LogInformation("API: Actualizando valor código {Codigo} = {Valor}", codigo, valor);

            var result = await service.UpdateItemValueAsync(empresaId, ano, codigo, valor);
            return Ok(result);
        }
    }

    /// <summary>
    /// Recalcula la jerarquía completa
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> RecalculateHierarchy(int empresaId, short ano)
    {
        {
            logger.LogInformation("API: Recalculando jerarquía para empresa {EmpresaId} año {Ano}", empresaId, ano);

            await service.RecalculateHierarchyAsync(empresaId, ano);
            return Ok(new { message = "Jerarquía recalculada exitosamente" });
        }
    }

    /// <summary>
    /// Obtiene items con valores no cero (Saldos Vigentes)
    /// VB6: Bt_SaldosVig_Click() -> SaldosVigentes()
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<BaseImponible14DCompletaDto>> GetWithNonZeroValues(int empresaId, short ano)
    {
        {
            logger.LogInformation("API: Obteniendo saldos vigentes para empresa {EmpresaId} año {Ano}", empresaId, ano);

            var result = await service.GetItemsWithBalancesAsync(empresaId, ano);
            return Ok(result);
        }
    }

    /// <summary>
    /// Aplica filtros a la base imponible
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<BaseImponible14DCompletaDto>> ApplyFilters(
        int empresaId,
        short ano,
        [FromBody] BaseImponible14DFiltroDto filtro)
    {
        {
            logger.LogInformation("API: Aplicando filtros para empresa {EmpresaId} año {Ano}", empresaId, ano);

            var result = await service.ApplyFiltersAsync(empresaId, ano, filtro);
            return Ok(result);
        }
    }

    /// <summary>
    /// Valida los datos
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<BaseImponible14DValidationResult>> Validate(int empresaId, short ano)
    {
        {
            logger.LogInformation("API: Validando datos para empresa {EmpresaId} año {Ano}", empresaId, ano);

            var result = await service.ValidateAsync(empresaId, ano);
            return Ok(result);
        }
    }

    /// <summary>
    /// Exporta a Excel
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ExportToExcel(int empresaId, short ano)
    {
        {
            logger.LogInformation("API: Exportando a Excel para empresa {EmpresaId} año {Ano}", empresaId, ano);

            var fileBytes = await service.ExportToExcelAsync(empresaId, ano);
            var fileName = $"BaseImponible14D_{empresaId}_{ano}_{DateTime.Now:yyyyMMddHHmmss}.xlsx";

            return File(fileBytes,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                fileName);
        }
    }

    /// <summary>
    /// Genera vista previa de impresión
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GeneratePrintPreview(int empresaId, short ano)
    {
        {
            logger.LogInformation("API: Generando vista previa para empresa {EmpresaId} año {Ano}", empresaId, ano);

            var fileBytes = await service.GeneratePrintPreviewAsync(empresaId, ano);

            return File(fileBytes,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                $"Preview_BaseImponible14D_{empresaId}_{ano}.xlsx");
        }
    }

    /// <summary>
    /// Obtiene cálculo detallado
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<BaseImponible14DCalculoDto>> GetDetailedCalculation(int empresaId, short ano)
    {
        {
            logger.LogInformation("API: Obteniendo cálculo detallado para empresa {EmpresaId} año {Ano}", empresaId, ano);

            var result = await service.GetDetailedCalculationAsync(empresaId, ano);
            return Ok(result);
        }
    }

    /// <summary>
    /// Verifica si el período está abierto
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<bool>> IsPeriodOpen(int empresaId, short ano)
    {
        {
            logger.LogInformation("API: Verificando período abierto para empresa {EmpresaId} año {Ano}", empresaId, ano);

            var isOpen = await service.IsPeriodOpenAsync(empresaId, ano);
            return Ok(new { periodoAbierto = isOpen });
        }
    }

    /// <summary>
    /// Calcula valores automáticos
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<IEnumerable<BaseImponible14DItemDto>>> CalculateAutomaticValues(int empresaId, short ano)
    {
        {
            logger.LogInformation("API: Calculando valores automáticos para empresa {EmpresaId} año {Ano}", empresaId, ano);

            var result = await service.CalculateAutomaticValuesAsync(empresaId, ano);
            return Ok(result);
        }
    }

}