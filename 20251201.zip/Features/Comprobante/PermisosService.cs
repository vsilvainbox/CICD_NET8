using App.Data;
using Microsoft.EntityFrameworkCore;

namespace App.Features.Comprobante;

/// <summary>
/// Servicio de permisos y privilegios de usuario
/// Implementa lógica VB6 de ChkPriv() y verificación de privilegios
/// </summary>
public class PermisosService(LpContabContext context, ILogger<PermisosService> logger) : IPermisosService
{
    // Constantes VB6 de privilegios (mapeo de MDI_Menu.bas)
    // PRV_ADM_COMP = 2^5 = 32 (privilegio para anular comprobantes)
    private const int PRV_ADM_COMP = 32;

    /// <summary>
    /// Verifica si el usuario tiene privilegio para anular comprobantes
    /// VB6: If Not ChkPriv(PRV_ADM_COMP) Then
    /// Línea VB6: 4559-4562 en FrmComprobante.frm
    /// </summary>
    public async Task<bool> TienePrivilegioAnularAsync(int idUsuario, int idEmpresa)
    {
        logger.LogInformation("Verificando privilegio anular para usuario {IdUsuario} en empresa {IdEmpresa}", 
            idUsuario, idEmpresa);

        {
            // PASO 1: Verificar si es administrador del sistema (PrivAdm = -1)
            var usuario = await context.Usuarios
                .AsNoTracking()
                .FirstOrDefaultAsync(u => u.IdUsuario == idUsuario);

            if (usuario == null)
            {
                logger.LogWarning("Usuario {IdUsuario} no encontrado", idUsuario);
                return false;
            }

            // Administrador tiene todos los privilegios
            if (usuario.PrivAdm == -1)
            {
                logger.LogInformation("Usuario {IdUsuario} es administrador del sistema - privilegio concedido", 
                    idUsuario);
                return true;
            }

            // PASO 2: Obtener perfil del usuario para la empresa
            var usuarioEmpresa = await context.UsuarioEmpresa
                .AsNoTracking()
                .FirstOrDefaultAsync(ue => ue.idUsuario == idUsuario && ue.idEmpresa == idEmpresa);

            if (usuarioEmpresa?.idPerfil == null)
            {
                logger.LogWarning("Usuario {IdUsuario} no tiene perfil asignado en empresa {IdEmpresa}", 
                    idUsuario, idEmpresa);
                return false;
            }

            // PASO 3: Obtener privilegios del perfil
            var perfil = await context.Perfiles
                .AsNoTracking()
                .FirstOrDefaultAsync(p => p.IdPerfil == usuarioEmpresa.idPerfil);

            if (perfil == null)
            {
                logger.LogWarning("Perfil {IdPerfil} no encontrado para usuario {IdUsuario}",
                    usuarioEmpresa.idPerfil, idUsuario);
                return false;
            }

            int privilegios = perfil.Privilegios ?? 0;

            // PASO 4: Verificar bit de privilegio PRV_ADM_COMP (operación AND bit a bit)
            // VB6: ChkPriv = (Privilegios And PRV_ADM_COMP) <> 0
            bool tienePrivilegio = (privilegios & PRV_ADM_COMP) != 0;

            logger.LogInformation(
                "Usuario {IdUsuario} en empresa {IdEmpresa}: Perfil={IdPerfil}, Privilegios={Privilegios}, TienePrivilegioAnular={TienePrivilegio}",
                idUsuario, idEmpresa, perfil.IdPerfil, privilegios, tienePrivilegio);

            return tienePrivilegio;
        }
    }

    /// <summary>
    /// Verifica si el usuario es administrador del sistema
    /// VB6: PrivAdm = -1
    /// </summary>
    public async Task<bool> EsAdministradorAsync(int idUsuario)
    {
        logger.LogInformation("Verificando si usuario {IdUsuario} es administrador", idUsuario);

        {
            var usuario = await context.Usuarios
                .AsNoTracking()
                .FirstOrDefaultAsync(u => u.IdUsuario == idUsuario);

            bool esAdmin = usuario?.PrivAdm == -1;

            logger.LogInformation("Usuario {IdUsuario} es administrador: {EsAdmin}", idUsuario, esAdmin);

            return esAdmin;
        }
    }

    /// <summary>
    /// Obtiene los privilegios completos del usuario para una empresa
    /// VB6: Perfiles.Privilegios (máscara de bits)
    /// </summary>
    public async Task<int> GetPrivilegiosAsync(int idUsuario, int idEmpresa)
    {
        logger.LogInformation("Obteniendo privilegios de usuario {IdUsuario} en empresa {IdEmpresa}", 
            idUsuario, idEmpresa);

        {
            // Administrador tiene todos los privilegios (máscara completa)
            var usuario = await context.Usuarios
                .AsNoTracking()
                .FirstOrDefaultAsync(u => u.IdUsuario == idUsuario);

            if (usuario?.PrivAdm == -1)
            {
                logger.LogInformation("Usuario {IdUsuario} es administrador - privilegios completos", idUsuario);
                return int.MaxValue; // Todos los privilegios
            }

            // Obtener privilegios del perfil
            var usuarioEmpresa = await context.UsuarioEmpresa
                .AsNoTracking()
                .FirstOrDefaultAsync(ue => ue.idUsuario == idUsuario && ue.idEmpresa == idEmpresa);

            if (usuarioEmpresa?.idPerfil == null)
            {
                logger.LogWarning("Usuario {IdUsuario} no tiene perfil en empresa {IdEmpresa}", 
                    idUsuario, idEmpresa);
                return 0; // Sin privilegios
            }

            var perfil = await context.Perfiles
                .AsNoTracking()
                .FirstOrDefaultAsync(p => p.IdPerfil == usuarioEmpresa.idPerfil);

            int privilegios = perfil?.Privilegios ?? 0;

            logger.LogInformation("Privilegios de usuario {IdUsuario} en empresa {IdEmpresa}: {Privilegios}", 
                idUsuario, idEmpresa, privilegios);

            return privilegios;
        }
    }
}