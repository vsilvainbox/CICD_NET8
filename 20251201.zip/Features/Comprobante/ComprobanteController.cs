using Microsoft.AspNetCore.Mvc;
using App.Extensions;
using System.Text.Json;
using App.Helpers;
using App.Features.Glosas;

namespace App.Features.Comprobante;


public class ComprobanteController(
    IHttpClientFactory httpClientFactory,
    ILogger<ComprobanteController> logger,
    LinkGenerator linkGenerator,
    IComprobanteService comprobanteService) : Controller
{
    // ==================== VISTA PRINCIPAL (LISTADO) ====================

    /// <summary>
    /// Lista de comprobantes (Index de la feature)
    /// </summary>
    [HttpGet]
    public IActionResult Index()
    {
        if (!SessionHelper.TieneEmpresaSeleccionada)
        {
            logger.LogWarning("Intento de acceso a Comprobante/Index sin empresa seleccionada. UsuarioId: {UsuarioId}", SessionHelper.UsuarioId);
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Comprobantes";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        logger.LogInformation("Loading Comprobante index (List) for empresa {EmpresaId}, año {Ano}",
            SessionHelper.EmpresaId, SessionHelper.Ano);

        ViewData["EmpresaId"] = SessionHelper.EmpresaId;
        ViewData["Ano"] = SessionHelper.Ano;
        ViewData["Title"] = "Comprobantes";

        return View();
    }

    // ==================== ENDPOINTS PARA LISTADO ====================

    /// <summary>
    /// Obtiene tipos de comprobante para filtros de listado
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetTiposComprobanteList()
    {
        logger.LogInformation("Proxy: GetTiposComprobanteList");
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<App.Features.ListarComprobantes.ListarComprobantesApiController>(
            HttpContext,
            nameof(App.Features.ListarComprobantes.ListarComprobantesApiController.GetTiposComprobante));
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Obtiene estados de comprobante para filtros de listado
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetEstadosComprobanteList()
    {
        logger.LogInformation("Proxy: GetEstadosComprobanteList");
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<App.Features.ListarComprobantes.ListarComprobantesApiController>(
            HttpContext,
            nameof(App.Features.ListarComprobantes.ListarComprobantesApiController.GetEstadosComprobante));
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Obtiene tipos de ajuste para filtros de listado
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetTiposAjusteList()
    {
        logger.LogInformation("Proxy: GetTiposAjusteList");
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<App.Features.ListarComprobantes.ListarComprobantesApiController>(
            HttpContext,
            nameof(App.Features.ListarComprobantes.ListarComprobantesApiController.GetTiposAjuste));
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Obtiene tipos de documento para filtros de listado
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetTiposDocumentoList(int? tipoLib)
    {
        logger.LogInformation("Proxy: GetTiposDocumentoList with tipoLib: {TipoLib}", tipoLib);
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<App.Features.ListarComprobantes.ListarComprobantesApiController>(
            HttpContext,
            nameof(App.Features.ListarComprobantes.ListarComprobantesApiController.GetTiposDocumento),
            tipoLib.HasValue ? new { tipoLib = tipoLib.Value } : null);
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Obtiene cuentas para filtros de listado
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetCuentasList()
    {
        var empresaId = SessionHelper.EmpresaId;
        var ano = SessionHelper.Ano;
        logger.LogInformation("Proxy: GetCuentasList for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<App.Features.ListarComprobantes.ListarComprobantesApiController>(
            HttpContext,
            nameof(App.Features.ListarComprobantes.ListarComprobantesApiController.GetCuentas),
            new { empresaId, ano });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Obtiene entidades para filtros de listado
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetEntidadesList()
    {
        var empresaId = SessionHelper.EmpresaId;
        logger.LogInformation("Proxy: GetEntidadesList for empresaId: {EmpresaId}", empresaId);
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<App.Features.ListarComprobantes.ListarComprobantesApiController>(
            HttpContext,
            nameof(App.Features.ListarComprobantes.ListarComprobantesApiController.GetEntidades),
            new { empresaId });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Obtiene sucursales para filtros de listado
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetSucursalesList()
    {
        var empresaId = SessionHelper.EmpresaId;
        logger.LogInformation("Proxy: GetSucursalesList for empresaId: {EmpresaId}", empresaId);
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<App.Features.ListarComprobantes.ListarComprobantesApiController>(
            HttpContext,
            nameof(App.Features.ListarComprobantes.ListarComprobantesApiController.GetSucursales),
            new { empresaId });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Busca comprobantes con filtros
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> BuscarComprobantes([FromBody] JsonElement filters)
    {
        var empresaId = SessionHelper.EmpresaId;
        var ano = SessionHelper.Ano;
        logger.LogInformation("Proxy: BuscarComprobantes for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<App.Features.ListarComprobantes.ListarComprobantesApiController>(
            HttpContext,
            nameof(App.Features.ListarComprobantes.ListarComprobantesApiController.Buscar),
            new { empresaId, ano });
        var (statusCode, content) = await client.ProxyRequestAsync(url!, filters, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }

    /// <summary>
    /// Obtiene detalle de un comprobante para el modal
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetDetalleComprobante(int idComp)
    {
        var empresaId = SessionHelper.EmpresaId;
        var ano = SessionHelper.Ano;
        logger.LogInformation("Proxy: GetDetalleComprobante for idComp: {IdComp}, empresaId: {EmpresaId}, ano: {Ano}", idComp, empresaId, ano);
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<App.Features.ListarComprobantes.ListarComprobantesApiController>(
            HttpContext,
            nameof(App.Features.ListarComprobantes.ListarComprobantesApiController.GetDetalle),
            new { idComp, empresaId, ano });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Elimina un comprobante
    /// </summary>
    [HttpDelete]
    public async Task<IActionResult> DeleteComprobante(int id)
    {
        var empresaId = SessionHelper.EmpresaId;
        var ano = SessionHelper.Ano;
        logger.LogInformation("Proxy: DeleteComprobante for id: {Id}, empresaId: {EmpresaId}, ano: {Ano}", id, empresaId, ano);
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<App.Features.ListarComprobantes.ListarComprobantesApiController>(
            HttpContext,
            nameof(App.Features.ListarComprobantes.ListarComprobantesApiController.Delete),
            new { idComp = id, empresaId, ano });
        var (statusCode, content) = await client.ProxyRequestAsync(url!, null, HttpMethod.Delete);
        return StatusCode(statusCode, content);
    }

    /// <summary>
    /// Cambia estado de múltiples comprobantes
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> CambiarEstadoComprobantes([FromBody] JsonElement data)
    {
        var empresaId = SessionHelper.EmpresaId;
        var ano = SessionHelper.Ano;
        logger.LogInformation("Proxy: CambiarEstadoComprobantes for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<App.Features.ListarComprobantes.ListarComprobantesApiController>(
            HttpContext,
            nameof(App.Features.ListarComprobantes.ListarComprobantesApiController.CambiarEstado),
            new { empresaId, ano });
        var (statusCode, content) = await client.ProxyRequestAsync(url!, data, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }

    /// <summary>
    /// Actualiza glosa de múltiples comprobantes
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> ActualizarGlosaComprobantes([FromBody] JsonElement data)
    {
        var empresaId = SessionHelper.EmpresaId;
        var ano = SessionHelper.Ano;
        logger.LogInformation("Proxy: ActualizarGlosaComprobantes for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<App.Features.ListarComprobantes.ListarComprobantesApiController>(
            HttpContext,
            nameof(App.Features.ListarComprobantes.ListarComprobantesApiController.ActualizarGlosa),
            new { empresaId, ano });
        var (statusCode, content) = await client.ProxyRequestAsync(url!, data, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }

    /// <summary>
    /// Convierte moneda de múltiples comprobantes
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> ConvertirMonedaComprobantes([FromBody] JsonElement data)
    {
        var empresaId = SessionHelper.EmpresaId;
        var ano = SessionHelper.Ano;
        logger.LogInformation("Proxy: ConvertirMonedaComprobantes for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<App.Features.ListarComprobantes.ListarComprobantesApiController>(
            HttpContext,
            nameof(App.Features.ListarComprobantes.ListarComprobantesApiController.ConvertirMoneda),
            new { empresaId, ano });
        var (statusCode, content) = await client.ProxyRequestAsync(url!, data, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }

    /// <summary>
    /// Calcula total de comprobantes seleccionados
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> CalcularTotalComprobantes([FromBody] JsonElement selectedIds)
    {
        var empresaId = SessionHelper.EmpresaId;
        var ano = SessionHelper.Ano;
        logger.LogInformation("Proxy: CalcularTotalComprobantes for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<App.Features.ListarComprobantes.ListarComprobantesApiController>(
            HttpContext,
            nameof(App.Features.ListarComprobantes.ListarComprobantesApiController.CalcularTotal),
            new { empresaId, ano });
        var (statusCode, content) = await client.ProxyRequestAsync(url!, selectedIds, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }

    /// <summary>
    /// Traspasa comprobantes al mes siguiente
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> TraspasarComprobantes([FromBody] JsonElement data)
    {
        var empresaId = SessionHelper.EmpresaId;
        var ano = SessionHelper.Ano;
        logger.LogInformation("Proxy: TraspasarComprobantes for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<App.Features.ListarComprobantes.ListarComprobantesApiController>(
            HttpContext,
            nameof(App.Features.ListarComprobantes.ListarComprobantesApiController.Traspasar),
            new { empresaId, ano });
        var (statusCode, content) = await client.ProxyRequestAsync(url!, data, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }

    /// <summary>
    /// Exporta comprobantes a Excel
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> ExportarComprobantes([FromQuery] bool conDetalle, [FromBody] object filters)
    {
        var empresaId = SessionHelper.EmpresaId;
        var ano = SessionHelper.Ano;
        logger.LogInformation("Proxy: ExportarComprobantes for empresaId: {EmpresaId}, ano: {Ano}, conDetalle: {ConDetalle}",
            empresaId, ano, conDetalle);
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<App.Features.ListarComprobantes.ListarComprobantesApiController>(
            HttpContext,
            nameof(App.Features.ListarComprobantes.ListarComprobantesApiController.Exportar),
            new { empresaId, ano, conDetalle });
        var (fileBytes, contentType) = await client.DownloadFileAsync(url, HttpMethod.Post, filters);
        return File(fileBytes, contentType, $"comprobantes_{empresaId}_{ano}.xlsx");
    }

    // ==================== CREAR/EDITAR COMPROBANTE ====================

    /// <summary>
    /// Nuevo comprobante o plantilla
    /// </summary>
    /// <param name="esTipo">Si es true, crea una plantilla (CT_Comprobante). VB6: FrmComprobante.FNew(True)</param>
    [HttpGet]
    public async Task<IActionResult> Create(bool esTipo = false)
    {
        // Validar que haya empresa seleccionada
        if (!SessionHelper.TieneEmpresaSeleccionada)
        {
            logger.LogWarning("Intento de acceso a Comprobante/Create sin empresa seleccionada. UsuarioId: {UsuarioId}", SessionHelper.UsuarioId);
            TempData["SwalError"] = esTipo
                ? "Debe seleccionar una empresa antes de crear una plantilla"
                : "Debe seleccionar una empresa antes de crear un comprobante";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        logger.LogInformation("Loading Comprobante Create for empresaId: {EmpresaId}, ano: {Ano}, usuarioId: {UsuarioId}, esTipo: {EsTipo}",
            SessionHelper.EmpresaId, SessionHelper.Ano, SessionHelper.UsuarioId, esTipo);

        var viewModel = await CrearViewModelBaseAsync(isTemplate: esTipo);
        return View("Create", viewModel);
    }

    /// <summary>
    /// Crea el ViewModel base con todos los catalogos y datos de sesion precargados
    /// Carga el correlativo sugerido desde el servicio (server-side)
    /// Para Edit/View: carga los datos del comprobante existente desde el servicio
    /// </summary>
    /// <param name="idComp">ID del comprobante/plantilla a editar</param>
    /// <param name="isReadOnly">Si es true, la vista es solo lectura</param>
    /// <param name="tipo">Tipo de comprobante para sugerir correlativo</param>
    /// <param name="isTemplate">Si es true, trabaja con CT_Comprobante (plantillas)</param>
    private async Task<ComprobanteViewModel> CrearViewModelBaseAsync(int? idComp = null, bool isReadOnly = false, byte? tipo = null, bool isTemplate = false)
    {
        var empresaId = SessionHelper.EmpresaId;
        var ano = (short)SessionHelper.Ano;

        var viewModel = new ComprobanteViewModel
        {
            IdComp = idComp,
            IsReadOnly = isReadOnly,
            IsTemplate = isTemplate,
            EmpresaId = empresaId,
            Ano = ano,
            UsuarioId = SessionHelper.UsuarioId,
            TiposComprobante = TipoComprobanteConstants.Nombres,
            EstadosComprobante = EstadoComprobanteConstants.Nombres,
            TiposLibro = TipoLibroConstants.Nombres,
            EstadosDocumento = EstadoDocumentoConstants.Nombres,
            Monedas = MonedaConstants.Nombres
        };

        // Si tiene idComp, cargar datos del comprobante/plantilla existente
        if (idComp.HasValue)
        {
            if (isTemplate)
            {
                // Cargar plantilla desde CT_Comprobante
                var plantilla = await comprobanteService.GetVoucherTypeByIdAsync(idComp.Value, empresaId);
                if (plantilla != null)
                {
                    viewModel.Nombre = plantilla.Nombre;
                    viewModel.Tipo = (byte)(plantilla.Tipo ?? 0);
                    viewModel.Glosa = plantilla.Glosa ?? string.Empty;

                    // Cargar movimientos de la plantilla
                    viewModel.Movimientos = plantilla.Movimientos?.Select(m => new MovimientoItemViewModel
                    {
                        IdMov = m.IdMov,
                        IdCuenta = m.IdCuenta ?? 0,
                        CodigoCuenta = m.CodCuenta,
                        NombreCuenta = m.NombreCuenta,
                        Debe = (double)(m.Debe ?? 0),
                        Haber = (double)(m.Haber ?? 0),
                        Glosa = m.Glosa,
                        IdCCosto = m.IdCCosto,
                        NombreCentroCosto = m.NombreCentroCosto,
                        IdAreaNegocio = m.IdAreaNeg,
                        NombreAreaNegocio = m.NombreAreaNegocio
                    }).ToList() ?? new List<MovimientoItemViewModel>();

                    logger.LogInformation("Loaded template {IdComp} '{Nombre}' with {MovCount} movements (ReadOnly: {IsReadOnly})",
                        idComp, plantilla.Nombre, viewModel.Movimientos.Count, isReadOnly);
                }
                else
                {
                    logger.LogWarning("Template {IdComp} not found", idComp);
                }
            }
            else
            {
                // Cargar comprobante normal
                var comprobante = await comprobanteService.GetByIdAsync(idComp.Value);
                if (comprobante != null)
                {
                    viewModel.Correlativo = comprobante.Correlativo;
                    viewModel.CorrelativoSugerido = comprobante.Correlativo;
                    viewModel.Fecha = comprobante.Fecha;
                    viewModel.Tipo = comprobante.Tipo;
                    viewModel.Estado = comprobante.Estado;
                    viewModel.Glosa = comprobante.Glosa;
                    viewModel.ImpResumido = comprobante.ImpResumido ?? false;
                    viewModel.OtrosIngEg14TER = comprobante.OtrosIngEg14TER ?? false;
                    viewModel.TipoAjuste = comprobante.TipoAjuste;

                    // Cargar movimientos
                    viewModel.Movimientos = comprobante.Movimientos.Select(m => new MovimientoItemViewModel
                    {
                        IdMov = m.IdMov,
                        IdCuenta = m.IdCuenta ?? 0,
                        CodigoCuenta = m.CodigoCuenta,
                        NombreCuenta = m.NombreCuenta,
                        Debe = m.Debe ?? 0,
                        Haber = m.Haber ?? 0,
                        Glosa = m.Glosa,
                        IdDoc = m.IdDoc,
                        TipoDocumento = m.TipoDocDiminutivo,
                        NumeroDocumento = m.NumDocumento,
                        EntidadNombre = m.NombreEntidad,
                        IdCCosto = m.IdCCosto,
                        NombreCentroCosto = m.NombreCCosto,
                        IdAreaNegocio = m.IdAreaNegocio,
                        NombreAreaNegocio = m.NombreAreaNegocio,
                        IdDocCuota = m.IdDocCuota,
                        TieneActivoFijo = m.TieneActivoFijo
                    }).ToList();

                    logger.LogInformation("Loaded comprobante {IdComp} with {MovCount} movements (ReadOnly: {IsReadOnly})",
                        idComp, viewModel.Movimientos.Count, isReadOnly);
                }
                else
                {
                    logger.LogWarning("Comprobante {IdComp} not found", idComp);
                }
            }
        }
        else
        {
            // Modo nuevo
            if (!isTemplate)
            {
                // Solo para comprobantes normales: cargar correlativo sugerido
                var correlativoSugerido = await comprobanteService.GetNextCorrelativeAsync(empresaId, ano, tipo);
                viewModel.Estado = EstadoComprobanteConstants.Aprobado;
                viewModel.Fecha = DateTime.Today;
                viewModel.Correlativo = correlativoSugerido;
                viewModel.CorrelativoSugerido = correlativoSugerido;
            }
            // Para plantillas nuevas, no necesitamos correlativo ni fecha
        }

        return viewModel;
    }

    /// <summary>
    /// Carga las constantes de tipos, estados y monedas en ViewData para la vista (legacy)
    /// </summary>
    private void CargarConstantesEnViewData()
    {
        ViewData["TiposComprobante"] = TipoComprobanteConstants.Nombres;
        ViewData["EstadosComprobante"] = EstadoComprobanteConstants.Nombres;
        ViewData["TiposLibro"] = TipoLibroConstants.Nombres;
        ViewData["EstadosDocumento"] = EstadoDocumentoConstants.Nombres;
        ViewData["Monedas"] = MonedaConstants.Nombres;
        ViewData["EstadoDefault"] = EstadoComprobanteConstants.Aprobado;
    }

    /// <summary>
    /// Devuelve una fila de movimiento renderizada con EditorTemplate (para agregar dinamicamente)
    /// </summary>
    [HttpGet]
    public IActionResult GetMovimientoRow(int index)
    {
        var movimiento = new MovimientoItemViewModel();

        // Configurar el prefijo para que genere nombres como Movimientos[index].Campo
        ViewData.TemplateInfo.HtmlFieldPrefix = $"Movimientos[{index}]";
        ViewData["IsView"] = false;
        ViewData["Index"] = index;

        return PartialView("EditorTemplates/MovimientoItemViewModel", movimiento);
    }

    /// <summary>
    /// Busca una cuenta por codigo y devuelve sus datos (para autocomplete)
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> BuscarCuenta(string codigo)
    {
        if (string.IsNullOrWhiteSpace(codigo))
        {
            return Json(new { encontrada = false });
        }

        try
        {
            var empresaId = SessionHelper.EmpresaId;
            var ano = SessionHelper.Ano;
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.ValidateAccount), new { empresaId, ano, codigo });
            var datos = await client.GetFromApiAsync<JsonElement>(url!);

            if (datos.TryGetProperty("valid", out var valid) && valid.GetBoolean())
            {
                return Json(new
                {
                    encontrada = true,
                    idCuenta = datos.GetProperty("idCuenta").GetInt32(),
                    nombre = datos.GetProperty("nombre").GetString(),
                    codigo = datos.GetProperty("codigo").GetString()
                });
            }

            return Json(new { encontrada = false });
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error buscando cuenta: {Codigo}", codigo);
            return Json(new { encontrada = false, error = "Error al buscar cuenta" });
        }
    }

    /// <summary>
    /// Validacion remota de cuenta para atributo [Remote] en MovimientoItemViewModel
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ValidarCuentaRemote(int IdCuenta, string CodigoCuenta)
    {
        // Si no hay IdCuenta pero hay codigo, es una validacion pendiente
        if (IdCuenta == 0 && !string.IsNullOrWhiteSpace(CodigoCuenta))
        {
            return Json("Busque la cuenta para validar");
        }

        // Si hay IdCuenta, la cuenta ya fue validada
        if (IdCuenta > 0)
        {
            return Json(true);
        }

        return Json("Cuenta no encontrada en el sistema");
    }

    /// <summary>
    /// Convierte moneda usando tipo de cambio del dia
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ConvertirMoneda(decimal monto, string desde, string hasta)
    {
        try
        {
            var empresaId = SessionHelper.EmpresaId;
            var client = httpClientFactory.CreateClient();
            // TODO: Llamar a API de conversion de moneda
            // Por ahora retornar el mismo monto si son iguales
            if (desde == hasta)
            {
                return Json(new { resultado = monto });
            }

            // Simular conversion (reemplazar con llamada real a API)
            decimal resultado = monto;
            if (desde == "CLP" && hasta == "USD")
            {
                resultado = monto / 900m; // Tipo cambio aproximado
            }
            else if (desde == "USD" && hasta == "CLP")
            {
                resultado = monto * 900m;
            }

            return Json(new { resultado = Math.Round(resultado, 2) });
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error convirtiendo moneda");
            return Json(new { error = "Error al convertir moneda" });
        }
    }

    /// <summary>
    /// Editar comprobante o plantilla existente
    /// </summary>
    /// <param name="id">ID del comprobante o plantilla</param>
    /// <param name="esTipo">Si es true, edita una plantilla (CT_Comprobante). VB6: FrmComprobante.FEdit(IdComp, True)</param>
    [HttpGet]
    public async Task<IActionResult> Edit(int id, bool esTipo = false)
    {
        // Validar que haya empresa seleccionada
        if (!SessionHelper.TieneEmpresaSeleccionada)
        {
            logger.LogWarning("Intento de acceso a Comprobante/Edit sin empresa seleccionada. UsuarioId: {UsuarioId}", SessionHelper.UsuarioId);
            TempData["SwalError"] = esTipo
                ? "Debe seleccionar una empresa antes de editar una plantilla"
                : "Debe seleccionar una empresa antes de editar un comprobante";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        logger.LogInformation("Loading Comprobante edit for id: {Id}, usuarioId: {UsuarioId}, esTipo: {EsTipo}",
            id, SessionHelper.UsuarioId, esTipo);

        var viewModel = await CrearViewModelBaseAsync(idComp: id, isTemplate: esTipo);

        // Verificar que se haya cargado el comprobante/plantilla
        var notFound = esTipo
            ? string.IsNullOrEmpty(viewModel.Nombre)
            : (!viewModel.Movimientos.Any() && viewModel.Correlativo == null);

        if (notFound)
        {
            logger.LogWarning("{Tipo} {Id} not found for edit", esTipo ? "Template" : "Comprobante", id);
            TempData["SwalError"] = esTipo
                ? $"No se encontró la plantilla #{id}"
                : $"No se encontró el comprobante #{id}";
            TempData["SwalType"] = "error";
            return RedirectToAction(esTipo ? "Index" : "Index", esTipo ? "ListarPorTipo" : "Home");
        }

        return View("Create", viewModel);
    }

    /// <summary>
    /// Ver comprobante o plantilla (solo lectura)
    /// </summary>
    /// <param name="id">ID del comprobante o plantilla</param>
    /// <param name="esTipo">Si es true, visualiza una plantilla (CT_Comprobante)</param>
    [HttpGet]
    public async Task<IActionResult> Detail(int id, bool esTipo = false)
    {
        // Validar que haya empresa seleccionada
        if (!SessionHelper.TieneEmpresaSeleccionada)
        {
            logger.LogWarning("Intento de acceso a Comprobante/Detail sin empresa seleccionada. UsuarioId: {UsuarioId}", SessionHelper.UsuarioId);
            TempData["SwalError"] = esTipo
                ? "Debe seleccionar una empresa antes de ver una plantilla"
                : "Debe seleccionar una empresa antes de ver un comprobante";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        logger.LogInformation("Loading Comprobante Detail for id: {Id}, usuarioId: {UsuarioId}, esTipo: {EsTipo}",
            id, SessionHelper.UsuarioId, esTipo);

        var viewModel = await CrearViewModelBaseAsync(idComp: id, isReadOnly: true, isTemplate: esTipo);

        // Verificar que se haya cargado el comprobante/plantilla
        var notFound = esTipo
            ? string.IsNullOrEmpty(viewModel.Nombre)
            : (!viewModel.Movimientos.Any() && viewModel.Correlativo == null);

        if (notFound)
        {
            logger.LogWarning("{Tipo} {Id} not found for detail", esTipo ? "Template" : "Comprobante", id);
            TempData["SwalError"] = esTipo
                ? $"No se encontró la plantilla #{id}"
                : $"No se encontró el comprobante #{id}";
            TempData["SwalType"] = "error";
            return RedirectToAction(esTipo ? "Index" : "Index", esTipo ? "ListarPorTipo" : "Home");
        }

        return View("Create", viewModel);
    }

    // ==================== MÉTODOS PROXY PARA API ====================

    // 1. Obtener siguiente correlativo
    [HttpGet]
    public async Task<IActionResult> GetNextCorrelative(int tipo)
    {
        {
            var empresaId = SessionHelper.EmpresaId;
            var ano = SessionHelper.Ano;
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.GetNextCorrelative), new { empresaId, ano, tipo });
            logger.LogInformation("GetNextCorrelative API URL: {Url}", url);

            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 2. Obtener fecha sugerida para nuevo comprobante
    [HttpGet]
    public async Task<IActionResult> GetFechaSugerida(int empresaId, short ano)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.GetFechaSugerida), new { empresaId, ano });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 3. Obtener comprobante por ID
    [HttpGet]
    public async Task<IActionResult> GetComprobante(int id)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.GetById), new { id });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 4. Validar cuenta
    [HttpGet]
    public async Task<IActionResult> ValidateAccount(string codigo)
    {
        {
            var empresaId = SessionHelper.EmpresaId;
            var ano = SessionHelper.Ano;
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.ValidateAccount), new { empresaId, ano, codigo });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 5. Buscar cuentas por código (filtrado en tiempo real)
    [HttpGet]
    public async Task<IActionResult> SearchAccounts(string query)
    {
        {
            var empresaId = SessionHelper.EmpresaId;
            var ano = SessionHelper.Ano;
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.SearchAccounts), new { empresaId, ano, query });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 6. Generar cheque
    [HttpPost]
    public async Task<IActionResult> GenerateCheque(int id, [FromBody] JsonElement data)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.GenerateCheque), new { id });
            var (statusCode, content) = await client.ProxyRequestAsync(url!, data, HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    // 5. Guardar comprobante (crear nuevo)
    [HttpPost]
    public async Task<IActionResult> SaveComprobante([FromBody] JsonElement data)
    {
        {
            var empresaId = SessionHelper.EmpresaId;
            var usuarioId = SessionHelper.UsuarioId;

            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.Create), new { empresaId, usuarioId });

            var (statusCode, content) = await client.ProxyRequestAsync(url!, data, HttpMethod.Post);

            return new ContentResult
            {
                Content = content,
                ContentType = "application/json",
                StatusCode = statusCode
            };
        }
    }

    // 5a. Crear comprobante desde form POST (patrón PRG)
    /// <summary>
    /// Crea un nuevo comprobante desde formulario HTML (patrón PRG con TempData)
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(ComprobanteFormDto model)
    {
        var empresaId = SessionHelper.EmpresaId;
        var usuarioId = SessionHelper.UsuarioId;
        var ano = SessionHelper.Ano;

        // Debug: Log de datos recibidos del form
        logger.LogInformation("Create Comprobante - Datos recibidos: Fecha={Fecha}, Tipo={Tipo}, Estado={Estado}, Glosa={Glosa}, Movimientos={MovCount}",
            model.Fecha, model.Tipo, model.Estado, model.Glosa, model.Movimientos?.Count ?? 0);

        // Log de todos los form keys para debugging
        var formKeys = Request.Form.Keys.Where(k => k.Contains("Movimientos")).ToList();
        logger.LogInformation("Create Comprobante - Form keys con Movimientos: {Keys}", string.Join(", ", formKeys));

        if (model.Movimientos != null && model.Movimientos.Count > 0)
        {
            foreach (var mov in model.Movimientos)
            {
                logger.LogInformation("  Movimiento: IdCuenta={IdCuenta}, Debe={Debe}, Haber={Haber}, Glosa={Glosa}",
                    mov.IdCuenta, mov.Debe, mov.Haber, mov.Glosa);
            }
        }
        else
        {
            logger.LogWarning("Create Comprobante - NO HAY MOVIMIENTOS en el modelo!");
        }

        if (!ModelState.IsValid)
        {
            var viewModel = model.ToComprobanteViewModel(empresaId, ano, usuarioId);
            return View("Create", viewModel);
        }

        try
        {
            // Construir el payload para la API
            var apiPayload = new
            {
                idEmpresa = empresaId,
                ano = ano,
                fecha = model.Fecha.ToString("yyyy-MM-dd"),
                tipo = model.Tipo,
                estado = model.Estado,
                glosa = model.Glosa,
                impResumido = model.ImpResumido,
                otrosIngEg14TER = model.OtrosIngEg14TER,
                movimientos = (model.Movimientos ?? new List<MovimientoFormDto>()).Select(m => new
                {
                    idCuenta = m.IdCuenta,
                    debe = m.Debe,
                    haber = m.Haber,
                    glosa = m.Glosa,
                    idDoc = m.IdDoc,
                    idCCosto = m.IdCCosto,
                    idAreaNegocio = m.IdAreaNegocio,
                    idDocCuota = m.IdDocCuota
                }).ToList()
            };

            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.Create), new { empresaId, usuarioId });

            var jsonContent = JsonSerializer.Serialize(apiPayload);
            logger.LogInformation("Create Comprobante - URL: {Url}, Payload: {Payload}", url, jsonContent);

            var (statusCode, content) = await client.ProxyRequestAsync(url!, JsonDocument.Parse(jsonContent).RootElement, HttpMethod.Post);

            logger.LogInformation("Create Comprobante - StatusCode: {StatusCode}, Response: {Response}", statusCode, content);

            if (statusCode >= 200 && statusCode < 300)
            {
                TempData["Success"] = "Comprobante creado exitosamente";
                // VB6: Después de guardar, el usuario ve la lista de comprobantes (FrmLstComp)
                return RedirectToAction("Index");
            }
            else
            {
                // Parsear respuesta de la API
                var viewModel = model.ToComprobanteViewModel(empresaId, ano, usuarioId);

                try
                {
                    var errorResponse = JsonSerializer.Deserialize<JsonElement>(content);

                    // Verificar si es una validación de negocio (422)
                    if (statusCode == 422 && errorResponse.TryGetProperty("type", out var typeEl) && typeEl.GetString() == "business_validation")
                    {
                        // Extraer errores de validación de negocio para mostrar con SweetAlert
                        if (errorResponse.TryGetProperty("errors", out var errorsEl) && errorsEl.ValueKind == JsonValueKind.Array)
                        {
                            var validationErrors = new List<string>();
                            foreach (var error in errorsEl.EnumerateArray())
                            {
                                var errorMsg = error.GetString();
                                if (!string.IsNullOrEmpty(errorMsg))
                                {
                                    validationErrors.Add(errorMsg);
                                }
                            }
                            // Guardar en TempData para mostrar con SweetAlert (formato JSON array)
                            TempData["BusinessValidationErrors"] = JsonSerializer.Serialize(validationErrors);
                            logger.LogInformation("Create Comprobante - Validaciones de negocio: {Errors}", string.Join("; ", validationErrors));
                        }
                    }
                    else
                    {
                        // Error genérico de la API
                        var errorMessage = errorResponse.TryGetProperty("message", out var msg) ? msg.GetString() : "Error al crear el comprobante";
                        logger.LogWarning("Create Comprobante - API Error: {ErrorMessage}", errorMessage);
                        TempData["Error"] = errorMessage;
                    }
                }
                catch
                {
                    logger.LogWarning("Create Comprobante - Could not parse error response: {Content}", content);
                    TempData["Error"] = "Error al crear el comprobante";
                }

                return View("Create", viewModel);
            }
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error al crear comprobante");
            TempData["Error"] = "Error inesperado al crear el comprobante";
            var viewModel = model.ToComprobanteViewModel(empresaId, ano, usuarioId);
            return View("Create", viewModel);
        }
    }

    // 5a-edit. Actualizar comprobante desde form POST (patrón PRG)
    /// <summary>
    /// Actualiza un comprobante existente desde formulario HTML (patrón PRG con TempData)
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, ComprobanteFormDto model)
    {
        var empresaId = SessionHelper.EmpresaId;
        var usuarioId = SessionHelper.UsuarioId;
        var ano = SessionHelper.Ano;

        if (!ModelState.IsValid)
        {
            var viewModel = model.ToComprobanteViewModel(empresaId, ano, usuarioId);
            viewModel.IdComp = id;
            return View("Create", viewModel);
        }

        try
        {
            // Construir el payload para la API
            var apiPayload = new
            {
                fecha = model.Fecha.ToString("yyyy-MM-dd"),
                tipo = model.Tipo,
                estado = model.Estado,
                glosa = model.Glosa,
                impResumido = model.ImpResumido,
                otrosIngEg14TER = model.OtrosIngEg14TER,
                movimientos = (model.Movimientos ?? new List<MovimientoFormDto>()).Select(m => new
                {
                    idMov = m.IdMov,
                    idCuenta = m.IdCuenta,
                    debe = m.Debe,
                    haber = m.Haber,
                    glosa = m.Glosa,
                    idDoc = m.IdDoc,
                    idCCosto = m.IdCCosto,
                    idAreaNegocio = m.IdAreaNegocio,
                    idDocCuota = m.IdDocCuota
                }).ToList()
            };

            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.Update), new { id, usuarioId });

            var jsonContent = JsonSerializer.Serialize(apiPayload);
            var (statusCode, content) = await client.ProxyRequestAsync(url!, JsonDocument.Parse(jsonContent).RootElement, HttpMethod.Put);

            if (statusCode >= 200 && statusCode < 300)
            {
                TempData["Success"] = "Comprobante actualizado exitosamente";
                // VB6: Después de actualizar, el usuario ve la lista de comprobantes (FrmLstComp)
                return RedirectToAction("Index");
            }
            else
            {
                try
                {
                    var errorResponse = JsonSerializer.Deserialize<JsonElement>(content);
                    var errorMessage = errorResponse.TryGetProperty("message", out var msg) ? msg.GetString() : "Error al actualizar el comprobante";
                    TempData["Error"] = errorMessage;
                }
                catch
                {
                    TempData["Error"] = "Error al actualizar el comprobante";
                }

                var viewModel = model.ToComprobanteViewModel(empresaId, ano, usuarioId);
                viewModel.IdComp = id;
                return View("Create", viewModel);
            }
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error al actualizar comprobante {Id}", id);
            TempData["Error"] = "Error inesperado al actualizar el comprobante";
            var viewModel = model.ToComprobanteViewModel(empresaId, ano, usuarioId);
            viewModel.IdComp = id;
            return View("Create", viewModel);
        }
    }

    // 5b. Actualizar comprobante existente
    /// <summary>
    /// Actualiza un comprobante existente (Bug #971307)
    /// </summary>
    [HttpPut]
    public async Task<IActionResult> UpdateComprobante([FromQuery] int id, [FromBody] JsonElement data)
    {
        {
            var usuarioId = SessionHelper.UsuarioId;
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.Update), new { id, usuarioId });
            var (statusCode, content) = await client.ProxyRequestAsync(url!, data, HttpMethod.Put);

            return new ContentResult
            {
                Content = content,
                ContentType = "application/json",
                StatusCode = statusCode
            };
        }
    }

    // 6. Buscar documentos
    /// <summary>
    /// Busca documentos con filtros (VB6: FrmSelDocComp)
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> SearchDocuments(
        int? tipoLib = null,
        int? estado = null,
        string? numDoc = null,
        string? entidad = null,
        string? fechaDesde = null,
        string? fechaHasta = null)
    {
        {
            var empresaId = SessionHelper.EmpresaId;
            var ano = SessionHelper.Ano;

            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.SearchDocuments), new { empresaId, tipoLib, estado, numDoc, entidad, fechaDesde, fechaHasta });

            logger.LogInformation("SearchDocuments: Calling API URL: {Url}", url);

            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 7. Generar pago automático
    [HttpPost]
    public async Task<IActionResult> GeneratePayment([FromBody] JsonElement data)
    {
        {
            var empresaId = SessionHelper.EmpresaId;
            var usuarioId = SessionHelper.UsuarioId;
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.GeneratePayment), new { empresaId, usuarioId });
            var (statusCode, content) = await client.ProxyRequestAsync(url!, data, HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    // 8. Convertir moneda
    [HttpPost]
    public async Task<IActionResult> ConvertCurrency([FromBody] JsonElement data)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.ConvertCurrency), null);

            // Retornar el objeto completo de conversión (no solo convertedAmount)
            var result = await client.PostToApiAsync<JsonElement, object>(url!, data);
            return Ok(result);
        }
    }

    // 9. Exportar a Excel
    [HttpGet]
    public async Task<IActionResult> ExportToExcel(int id)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.ExportToExcel), new { id });
            var (fileBytes, contentType) = await client.DownloadFileAsync(url, HttpMethod.Get);

            return File(fileBytes,
                contentType ?? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                $"Comprobante_{id}.xlsx");
        }
    }

    // 10. Generar reporte
    [HttpGet]
    public async Task<IActionResult> GenerateReport(int id, bool resumido = false)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.GenerateReport), new { id, resumido });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 11. Obtener glosas
    [HttpGet]
    public async Task<IActionResult> GetGlossaries()
    {
        {
            var empresaId = SessionHelper.EmpresaId;
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.GetGlossaries), new { empresaId });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 12. Obtener plantillas de comprobante
    [HttpGet]
    public async Task<IActionResult> GetVoucherTypes()
    {
        {
            var empresaId = SessionHelper.EmpresaId;
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.GetVoucherTypes), new { empresaId });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 13. Cargar plantilla específica
    [HttpGet]
    public async Task<IActionResult> LoadVoucherType(int idCompTipo)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.LoadFromVoucherType), new { id = idCompTipo });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 14. Guardar plantilla de comprobante (directamente con movimientos)
    [HttpPost]
    public async Task<IActionResult> SaveVoucherType([FromBody] JsonElement data)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.SaveVoucherTypeDirect), null);
            var (statusCode, content) = await client.ProxyRequestAsync(url!, data, HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    // 14b. Crear plantilla desde comprobante actual (VB6: Bt_NewCompTipo)
    [HttpPost]
    public async Task<IActionResult> CreateVoucherTypeFromCurrent([FromBody] JsonElement data)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.CreateVoucherTypeFromCurrent), null);
            var (statusCode, content) = await client.ProxyRequestAsync(url!, data, HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    // 14c. Obtener glosas predefinidas (VB6: FrmGlosas.FLoad)
    [HttpGet]
    public async Task<IActionResult> GetGlosas()
    {
        {
            var empresaId = SessionHelper.EmpresaId;
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<GlosasApiController>(HttpContext, nameof(GlosasApiController.GetAll), new { empresaId });
            var glosas = await client.GetFromApiAsync<object>(url!);
            return Ok(glosas);
        }
    }

    // 15. Obtener catálogos (áreas negocio, centros costo)
    [HttpGet]
    public async Task<IActionResult> GetCatalogs()
    {
        {
            var empresaId = SessionHelper.EmpresaId;
            var ano = SessionHelper.Ano;

            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.GetCatalogs), new { empresaId, ano });
            var catalogs = await client.GetFromApiAsync<CatalogsDto>(url!);

            return Ok(catalogs);
        }
    }

    // 16. Validar cuenta (versión alternativa del .js)
    [HttpGet]
    public async Task<IActionResult> ValidateAccountByCode(string code)
    {
        {
            var empresaId = SessionHelper.EmpresaId;
            var ano = SessionHelper.Ano;
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.ValidateAccount), new { empresaId, ano, codigo = code });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 17. Validar formulario completo
    [HttpPost]
    public async Task<IActionResult> ValidateForm([FromBody] JsonElement data)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.ValidateComprobante), null);
            var (statusCode, content) = await client.ProxyRequestAsync(url!, data, HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    // ========== NUEVAS FUNCIONALIDADES - MÉTODOS PROXY ==========

    // 18. Verificar si cuenta es Activo Fijo
    [HttpGet]
    public async Task<IActionResult> IsCuentaActivoFijo(int idCuenta)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.IsCuentaActivoFijo), new { idCuenta });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 19. Obtener activos fijos de comprobante
    [HttpGet]
    public async Task<IActionResult> GetActivosFijos(int idComp)
    {
        {
            var empresaId = SessionHelper.EmpresaId;
            var ano = SessionHelper.Ano;
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.GetActivosFijos), new { idComp, empresaId, ano });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 20. Asignar activo fijo a movimiento
    [HttpPost]
    public async Task<IActionResult> AsignarActivoFijo(int idMov, [FromBody] JsonElement data)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.AsignarActivoFijo), new { idMov });
            var (statusCode, content) = await client.ProxyRequestAsync(url!, data, HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    // 21. Remover activo fijo
    [HttpDelete]
    public async Task<IActionResult> RemoverActivoFijo(int idCompFicha)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.RemoverActivoFijo), new { idCompFicha });
            var (statusCode, content) = await client.ProxyRequestAsync(url!, null, HttpMethod.Delete);
            return StatusCode(statusCode, content);
        }
    }

    // 22. Crear documento desde movimiento
    [HttpPost]
    public async Task<IActionResult> CreateDocumentFromMovimiento(int idMov, [FromBody] JsonElement data)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.CreateDocumentFromMovimiento), new { idMov });
            var (statusCode, content) = await client.ProxyRequestAsync(url!, data, HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    // 23. Obtener detalle de documento desde movimiento
    [HttpGet]
    public async Task<IActionResult> GetDocumentoDetalle(int idMov)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.GetDocumentoDetalleFromMovimiento), new { idMov });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 24. Obtener nota de movimiento
    [HttpGet]
    public async Task<IActionResult> GetMovimientoNota(int idMov)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.GetMovimientoNota), new { idMov });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 25. Guardar nota de movimiento
    [HttpPut]
    public async Task<IActionResult> SaveMovimientoNota(int idMov, [FromBody] JsonElement data)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.SaveMovimientoNota), new { idMov });
            var (statusCode, content) = await client.ProxyRequestAsync(url!, data, HttpMethod.Put);
            return StatusCode(statusCode, content);
        }
    }

    // 26. Eliminar nota de movimiento
    [HttpDelete]
    public async Task<IActionResult> DeleteMovimientoNota(int idMov)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.DeleteMovimientoNota), new { idMov });
            var (statusCode, content) = await client.ProxyRequestAsync(url!, null, HttpMethod.Delete);
            return StatusCode(statusCode, content);
        }
    }

    // 27. Validar si cuenta es banco
    [HttpGet]
    public async Task<IActionResult> IsCuentaBanco(int idCuenta)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.IsCuentaBanco), new { idCuenta });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 28. Validar si movimiento es editable
    [HttpGet]
    public async Task<IActionResult> ValidateMovimientoEditable(int idMov)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.ValidateMovimientoEditable), new { idMov });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 29. Validar comprobante cuadrado
    [HttpGet]
    public async Task<IActionResult> ValidateComprobanteCuadrado(int idComp)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.ValidateComprobanteCuadrado), new { idComp });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 30. Validar período abierto
    [HttpGet]
    public async Task<IActionResult> ValidatePeriodoAbierto(string fecha)
    {
        {
            var empresaId = SessionHelper.EmpresaId;
            var ano = SessionHelper.Ano;
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.ValidatePeriodoAbierto), new { fecha, empresaId, ano });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 31. Navegar entre comprobantes (VB6: Bt_First, Bt_Prev, Bt_Next, Bt_Last)
    [HttpGet]
    public async Task<IActionResult> NavigateVoucher(string direction, int? currentId, int empresaId, short ano)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.NavigateVoucher), new { direction, currentId, empresaId, ano });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 32. Buscar comprobantes (VB6: Bt_Find)
    [HttpGet]
    public async Task<IActionResult> SearchVouchers(
        int empresaId,
        short ano,
        int? correlativo = null,
        int? tipo = null,
        string? fechaDesde = null,
        string? fechaHasta = null,
        string? glosa = null,
        int? estado = null)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.SearchVouchers), new { empresaId, ano, correlativo, tipo, fechaDesde, fechaHasta, glosa, estado });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // ========== MÉTODOS PROXY PARA INTEGRACIÓN CON DOCUMENTOS/ACTIVOS FIJOS ==========

    // 33. Preparar crear documento desde movimiento
    [HttpGet]
    public async Task<IActionResult> PrepararCrearDocumento(int idMov)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.PrepararCrearDocumento), new { idMov });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 34. Preparar ver documento desde movimiento
    [HttpGet]
    public async Task<IActionResult> PrepararVerDocumento(int idMov)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.PrepararVerDocumento), new { idMov });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 35. Preparar activo fijo desde movimiento
    [HttpGet]
    public async Task<IActionResult> PrepararActivoFijo(int idMov)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.PrepararActivoFijo), new { idMov });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 36. Verificar si tiene activo fijo asociado
    [HttpGet]
    public async Task<IActionResult> TieneActivoFijo(int idMov)
    {
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.MovimientoTieneActivoFijo), new { idMov });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 37. Obtener contexto de documento
    [HttpGet]
    public async Task<IActionResult> GetDocumentoContexto(int idDoc, int? empresaId = null, int? ano = null)
    {
        {
            var empId = empresaId ?? SessionHelper.EmpresaId;
            var year = ano ?? SessionHelper.Ano;

            var client = httpClientFactory.CreateClient();

            // Este endpoint es un proxy directo a GestionDocumentos
            // No existe en ComprobanteeApi, se debe usar GestionDocumentosApi directamente
            var url = linkGenerator.GetApiUrl<App.Features.GestionDocumentos.GestionDocumentosApiController>(HttpContext, "GetById", new { id = idDoc, empresaId = empId, ano = year });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 38. Verificar si es centralización full
    [HttpGet]
    public async Task<IActionResult> EsCentralizacionFull(int idComp, int? empresaId = null, int? ano = null)
    {
        {
            var empId = empresaId ?? SessionHelper.EmpresaId;
            var year = ano ?? SessionHelper.Ano;

            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.EsCentralizacionFull), new { idComp, empresaId = empId, ano = year });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 39. Obtener totales full
    [HttpGet]
    public async Task<IActionResult> GetTotalesFull(int idComp, int? empresaId = null, int? ano = null)
    {
        {
            var empId = empresaId ?? SessionHelper.EmpresaId;
            var year = ano ?? SessionHelper.Ano;

            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.CalcularTotalesFull), new { idComp, empresaId = empId, ano = year });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 40. Marcar centralización full
    [HttpPost]
    public async Task<IActionResult> MarcarCentralizacionFull(int idComp, int? empresaId = null, int? ano = null)
    {
        {
            var empId = empresaId ?? SessionHelper.EmpresaId;
            var year = ano ?? SessionHelper.Ano;

            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.MarcarComoCentralizacionFull), new { idComp, empresaId = empId, ano = year });
            var (statusCode, content) = await client.ProxyRequestAsync(url!, null, HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    // 41. Dejar en cero movimientos
    [HttpPost]
    public async Task<IActionResult> DejarEnCeroMovimientos(int idComp, int? empresaId = null)
    {
        {
            var empId = empresaId ?? SessionHelper.EmpresaId;

            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.DejarEnCeroMovimientos), new { idComp, empresaId = empId });
            var (statusCode, content) = await client.ProxyRequestAsync(url!, null, HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    // ========== ENDPOINTS PROXY PARA INTEGRACIÓN CON OTROS FEATURES ==========

    // 42. Obtener plan de cuentas (proxy a PlanCuentasApi)
    /// <summary>
    /// Proxy para obtener el plan de cuentas completo
    /// Usado para validación y búsqueda de cuentas en tiempo real
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetPlanCuentas()
    {
        {
            var empresaId = SessionHelper.EmpresaId;
            var ano = SessionHelper.Ano;
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<App.Features.PlanCuentas.PlanCuentasApiController>(HttpContext, "Index", new { empresaId, ano });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 43. Obtener documento completo (proxy a GestionDocumentosApi)
    /// <summary>
    /// Proxy para obtener los datos completos de un documento
    /// Usado cuando se asocian documentos a movimientos
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetDocumento(int idDoc)
    {
        {
            var empresaId = SessionHelper.EmpresaId;
            var ano = SessionHelper.Ano;
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<App.Features.GestionDocumentos.GestionDocumentosApiController>(HttpContext, "GetById", new { id = idDoc, empresaId, ano });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // 44. Obtener tipos de documento por tipo de libro
    [HttpGet]
    public async Task<IActionResult> GetTiposDocumento(int tipoLib)
    {
        var empresaId = SessionHelper.EmpresaId;
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.GetTiposDocumento), new { tipoLib, empresaId });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    // 45. Buscar entidad por RUT
    [HttpGet]
    public async Task<IActionResult> BuscarEntidadPorRut(string rut)
    {
        var empresaId = SessionHelper.EmpresaId;
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.BuscarEntidadPorRut), new { rut, empresaId });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    // 46. Crear documento nuevo (desde modal de Comprobantee)
    [HttpPost]
    public async Task<IActionResult> CrearDocumento([FromBody] JsonElement data)
    {
        var empresaId = SessionHelper.EmpresaId;
        var ano = SessionHelper.Ano;
        var usuarioId = SessionHelper.UsuarioId;
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ComprobanteApiController>(HttpContext, nameof(ComprobanteApiController.CrearDocumento), new { empresaId, ano, usuarioId });
        var (statusCode, content) = await client.ProxyRequestAsync(url!, data, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }
}
