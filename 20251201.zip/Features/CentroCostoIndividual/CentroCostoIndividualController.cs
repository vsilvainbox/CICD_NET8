using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Text.Json;
using App.Extensions;
using App.Helpers;

namespace App.Features.CentroCostoIndividual;

/// <summary>
/// MVC Controller para gestión individual de centros de costo
/// Basado en FrmCCosto.frm del sistema VB6
/// </summary>
[Authorize]

public class CentroCostoIndividualController(
    ILogger<CentroCostoIndividualController> logger,
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator) : Controller
{
    /// <summary>
    /// Vista principal/por defecto para centro de costo individual
    /// Redirige a la creación de nuevo centro de costo
    /// </summary>
    public IActionResult Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Centro de Costo Individual";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        logger.LogInformation("Accediendo a vista principal de centro de costo individual");
        // Redirigir a la vista de nuevo centro de costo como comportamiento por defecto
        return RedirectToAction(nameof(Nuevo));
    }

    /// <summary>
    /// Vista para crear nuevo centro de costo
    /// Mapea: FrmCCosto.FNew()
    /// </summary>
    public IActionResult Nuevo()
    {
        logger.LogInformation("Cargando vista para nuevo centro de costo");

        ViewBag.Modo = "Nuevo";
        ViewBag.Titulo = "Nuevo Centro de Gestión";
        ViewBag.SoloLectura = false;

        var dto = new CentroCostoDto
        {
            Vigente = true // Default en VB6: Ch_Vigente = 1
        };

        return View("Index", dto);
    }

    /// <summary>
    /// Vista para editar centro de costo existente
    /// Mapea: FrmCCosto.FEdit()
    /// </summary>
    public async Task<IActionResult> Editar(int id)
    {
        {
            logger.LogInformation("Cargando vista para editar centro de costo Id={Id}", id);

            int empresaId = SessionHelper.EmpresaId;
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<CentroCostoIndividualApiController>(HttpContext, nameof(CentroCostoIndividualApiController.GetById), new { id, empresaId });

            var centroCosto = await client.GetFromApiAsync<CentroCostoDto>(url!);

            if (centroCosto == null)
            {
                logger.LogWarning("Centro de costo no encontrado: Id={Id}", id);
                return NotFound("Centro de costo no encontrado");
            }

            ViewBag.Modo = "Editar";
            ViewBag.Titulo = "Modificar Centro de Gestión";
            ViewBag.SoloLectura = false;

            return View("Index", centroCosto);
        }
    }

    /// <summary>
    /// Vista para ver centro de costo (solo lectura)
    /// Mapea: FrmCCosto.FView()
    /// </summary>
    public async Task<IActionResult> Ver(int id)
    {
        {
            logger.LogInformation("Cargando vista para ver centro de costo Id={Id}", id);

            int empresaId = SessionHelper.EmpresaId;
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<CentroCostoIndividualApiController>(HttpContext, nameof(CentroCostoIndividualApiController.GetById), new { id, empresaId });

            var centroCosto = await client.GetFromApiAsync<CentroCostoDto>(url!);

            if (centroCosto == null)
            {
                logger.LogWarning("Centro de costo no encontrado: Id={Id}", id);
                return NotFound("Centro de costo no encontrado");
            }

            ViewBag.Modo = "Ver";
            ViewBag.Titulo = "Ver Centro de Gestión";
            ViewBag.SoloLectura = true;

            return View("Index", centroCosto);
        }
    }

    #region Métodos PRG para Form Submit

    /// <summary>
    /// POST: Crear centro de costo (PRG Pattern)
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Crear(CentroCostoFormDto dto)
    {
        logger.LogInformation("Creando nuevo centro de costo: Código={Codigo}", dto.Codigo);

        if (!ModelState.IsValid)
        {
            ViewBag.Modo = "Nuevo";
            ViewBag.Titulo = "Nuevo Centro de Gestión";
            ViewBag.SoloLectura = false;
            return View("Index", new CentroCostoDto
            {
                Codigo = dto.Codigo,
                Descripcion = dto.Descripcion,
                Vigente = dto.Vigente
            });
        }

        try
        {
            int empresaId = SessionHelper.EmpresaId;
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<CentroCostoIndividualApiController>(
                HttpContext, 
                nameof(CentroCostoIndividualApiController.Create), 
                new { empresaId });

            var createDto = new CrearCentroCostoDto
            {
                Codigo = dto.Codigo,
                Descripcion = dto.Descripcion,
                Vigente = dto.Vigente
            };

            var (statusCode, content) = await client.ProxyRequestAsync(url!, createDto, HttpMethod.Post);

            if (statusCode >= 200 && statusCode < 300)
            {
                TempData["Success"] = "Centro de costo creado correctamente";
                return RedirectToAction("Index", "CentrosCosto");
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Error al crear el centro de costo");
                ViewBag.Modo = "Nuevo";
                ViewBag.Titulo = "Nuevo Centro de Gestión";
                ViewBag.SoloLectura = false;
                return View("Index", new CentroCostoDto
                {
                    Codigo = dto.Codigo,
                    Descripcion = dto.Descripcion,
                    Vigente = dto.Vigente
                });
            }
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error al crear centro de costo");
            ModelState.AddModelError(string.Empty, "Error al crear el centro de costo");
            ViewBag.Modo = "Nuevo";
            ViewBag.Titulo = "Nuevo Centro de Gestión";
            ViewBag.SoloLectura = false;
            return View("Index", new CentroCostoDto
            {
                Codigo = dto.Codigo,
                Descripcion = dto.Descripcion,
                Vigente = dto.Vigente
            });
        }
    }

    /// <summary>
    /// POST: Actualizar centro de costo (PRG Pattern)
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Actualizar(CentroCostoFormDto dto)
    {
        logger.LogInformation("Actualizando centro de costo Id={Id}", dto.IdCCosto);

        if (!ModelState.IsValid)
        {
            ViewBag.Modo = "Editar";
            ViewBag.Titulo = "Modificar Centro de Gestión";
            ViewBag.SoloLectura = false;
            return View("Index", new CentroCostoDto
            {
                IdCCosto = dto.IdCCosto,
                Codigo = dto.Codigo,
                Descripcion = dto.Descripcion,
                Vigente = dto.Vigente
            });
        }

        try
        {
            int empresaId = SessionHelper.EmpresaId;
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<CentroCostoIndividualApiController>(
                HttpContext, 
                nameof(CentroCostoIndividualApiController.Update), 
                new { id = dto.IdCCosto, empresaId });

            var updateDto = new ActualizarCentroCostoDto
            {
                Codigo = dto.Codigo,
                Descripcion = dto.Descripcion,
                Vigente = dto.Vigente
            };

            var (statusCode, content) = await client.ProxyRequestAsync(url!, updateDto, HttpMethod.Put);

            if (statusCode >= 200 && statusCode < 300)
            {
                TempData["Success"] = "Centro de costo actualizado correctamente";
                return RedirectToAction("Index", "CentrosCosto");
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Error al actualizar el centro de costo");
                ViewBag.Modo = "Editar";
                ViewBag.Titulo = "Modificar Centro de Gestión";
                ViewBag.SoloLectura = false;
                return View("Index", new CentroCostoDto
                {
                    IdCCosto = dto.IdCCosto,
                    Codigo = dto.Codigo,
                    Descripcion = dto.Descripcion,
                    Vigente = dto.Vigente
                });
            }
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error al actualizar centro de costo Id={Id}", dto.IdCCosto);
            ModelState.AddModelError(string.Empty, "Error al actualizar el centro de costo");
            ViewBag.Modo = "Editar";
            ViewBag.Titulo = "Modificar Centro de Gestión";
            ViewBag.SoloLectura = false;
            return View("Index", new CentroCostoDto
            {
                IdCCosto = dto.IdCCosto,
                Codigo = dto.Codigo,
                Descripcion = dto.Descripcion,
                Vigente = dto.Vigente
            });
        }
    }

    #endregion

    #region Métodos Proxy para API (AJAX)

    /// <summary>
    /// Proxy: Validar código único (para validación remota)
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ValidarCodigo(string codigo, int? excludeId)
    {
        logger.LogInformation("Proxy: Validar código {Codigo}, excludeId={ExcludeId}", codigo, excludeId);

        int empresaId = SessionHelper.EmpresaId;
        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<CentroCostoIndividualApiController>(
            HttpContext, 
            nameof(CentroCostoIndividualApiController.ValidarCodigo), 
            new { codigo, empresaId, excludeId });

        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    #endregion
}
