using Microsoft.AspNetCore.Mvc;

namespace App.Features.CentroCostoIndividual;

/// <summary>
/// API Controller para gestiÃ³n individual de centros de costo
/// Basado en FrmCCosto.frm del sistema VB6
/// </summary>
[ApiController]
[Route("[controller]/[action]")]
public class CentroCostoIndividualApiController(
    ICentroCostoIndividualService service,
    ILogger<CentroCostoIndividualApiController> logger) : ControllerBase
{
    /// <summary>
    /// Obtiene un centro de costo por su ID
    /// GET api/CentroCostoIndividual/GetById?id=1&amp;empresaId=1
    /// Mapea: FrmCCosto.LoadAll()
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<CentroCostoDto>> GetById(
        [FromQuery] int id,
        [FromQuery] int empresaId)
    {
        {
            if (empresaId <= 0)
            {
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "EmpresaId es requerido y debe ser mayor a 0" } });
            }

            logger.LogInformation("API: Obteniendo centro de costo Id={Id} para empresa {EmpresaId}", id, empresaId);

            var centroCosto = await service.GetByIdAsync(id, empresaId);

            if (centroCosto == null)
            {
                return NotFound(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "Centro de costo no encontrado" } });
            }

            return Ok(centroCosto);
        }
    }

    /// <summary>
    /// Crea un nuevo centro de costo
    /// POST api/CentroCostoIndividual/Create?empresaId=1
    /// Body: { "codigo": "CC001", "descripcion": "Centro 1", ... }
    /// Mapea: FrmCCosto.FNew() â†' bt_OK_Click()
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<CentroCostoDto>> Create(
        [FromQuery] int empresaId,
        [FromBody] CrearCentroCostoDto dto)
    {
        {
            if (empresaId <= 0)
            {
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "EmpresaId es requerido y debe ser mayor a 0" } });
            }

            logger.LogInformation("API: Creando centro de costo: Codigo={Codigo} para empresa {EmpresaId}", 
                dto.Codigo, empresaId);

            // Validar modelo
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Validar cÃ³digo obligatorio
            if (string.IsNullOrWhiteSpace(dto.Codigo))
            {
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "Debe ingresar el código" } });
            }

            // Crear centro de costo
            var nuevoCentroCosto = await service.CreateAsync(dto, empresaId);

            return CreatedAtAction(
                nameof(GetById),
                new { id = nuevoCentroCosto.IdCCosto, empresaId = empresaId },
                nuevoCentroCosto);
        }
    }

    /// <summary>
    /// Actualiza un centro de costo existente
    /// PUT api/CentroCostoIndividual/Update?id=1&amp;empresaId=1
    /// Body: { "codigo": "CC001", "descripcion": "Centro Actualizado", ... }
    /// Mapea: FrmCCosto.FEdit() â†' bt_OK_Click()
    /// </summary>
    [HttpPut]
    public async Task<ActionResult<CentroCostoDto>> Update(
        [FromQuery] int id,
        [FromQuery] int empresaId,
        [FromBody] ActualizarCentroCostoDto dto)
    {
        {
            if (empresaId <= 0)
            {
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "EmpresaId es requerido y debe ser mayor a 0" } });
            }

            logger.LogInformation("API: Actualizando centro de costo Id={Id}: Codigo={Codigo} para empresa {EmpresaId}",
                id, dto.Codigo, empresaId);

            // Validar modelo
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Validar cÃ³digo obligatorio
            if (string.IsNullOrWhiteSpace(dto.Codigo))
            {
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "Debe ingresar el código" } });
            }

            // Actualizar centro de costo
            var centroCostoActualizado = await service.UpdateAsync(id, dto, empresaId);

            return Ok(centroCostoActualizado);
        }
    }

    /// <summary>
    /// Valida si un cÃ³digo ya existe
    /// GET api/CentroCostoIndividual/ValidarCodigo?codigo=CC001&amp;empresaId=1&amp;excludeId=5
    /// Mapea: FrmCCosto.Valida()
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<bool>> ValidarCodigo(
        [FromQuery] string codigo,
        [FromQuery] int empresaId,
        [FromQuery] int? excludeId = null)
    {
        {
            if (empresaId <= 0)
            {
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "EmpresaId es requerido y debe ser mayor a 0" } });
            }

            if (string.IsNullOrWhiteSpace(codigo))
            {
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "Código requerido" } });
            }

            var existe = await service.ExisteCodigoAsync(codigo, empresaId, excludeId);

            return Ok(new { existe });
        }
    }
}
