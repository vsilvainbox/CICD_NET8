using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Text.Json;
using App.Extensions;
using App.Helpers;

namespace App.Features.BalanceEjecutivoIfrs;

/// <summary>
/// Controller MVC para Balance Ejecutivo IFRS.
/// Gestiona la interfaz de usuario para generar balances ejecutivos IFRS.
/// </summary>
[Authorize]

public class BalanceEjecutivoIfrsController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<BalanceEjecutivoIfrsController> logger) : Controller
{
    /// <summary>
    /// Vista principal del Balance Ejecutivo IFRS.
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder al Balance Ejecutivo IFRS";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        var client = httpClientFactory.CreateClient();

        // Cargar áreas de negocio desde API
        var urlAreas = linkGenerator.GetApiUrl<BalanceEjecutivoIfrsApiController>(
            HttpContext,
            nameof(BalanceEjecutivoIfrsApiController.GetAreasNegocio));
        var areas = urlAreas != null
            ? await client.GetFromApiAsync<List<Shared.ComboItemDto>>(urlAreas)
            : new List<Shared.ComboItemDto>();
        ViewBag.AreasNegocio = areas ?? new List<Shared.ComboItemDto>();

        // Cargar centros de costo desde API
        var urlCentros = linkGenerator.GetApiUrl<BalanceEjecutivoIfrsApiController>(
            HttpContext,
            nameof(BalanceEjecutivoIfrsApiController.GetCentrosCosto));
        var centros = urlCentros != null
            ? await client.GetFromApiAsync<List<Shared.ComboItemDto>>(urlCentros)
            : new List<Shared.ComboItemDto>();
        ViewBag.CentrosCosto = centros ?? new List<Shared.ComboItemDto>();

        // Establecer fechas por defecto
        var hoy = DateTime.Today;
        ViewBag.FechaDesde = new DateTime(hoy.Year, hoy.Month, 1);
        ViewBag.FechaHasta = hoy;

        return View();
    }

    /// <summary>
    /// Método proxy para generar el Balance Ejecutivo IFRS.
    /// Actúa como intermediario entre la vista y la API.
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Generar([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC: Generar balance ejecutivo IFRS");

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<BalanceEjecutivoIfrsApiController>(
            HttpContext,
            nameof(BalanceEjecutivoIfrsApiController.Generar));

        var (statusCode, content) = await client.ProxyRequestAsync(
            url!,
            request!,
            HttpMethod.Post);

        return StatusCode(statusCode, content);
    }

    /// <summary>
    /// Método proxy para validar plan de cuentas IFRS.
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ValidarPlan()
    {
        logger.LogInformation("MVC: Validar plan de cuentas IFRS");

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<BalanceEjecutivoIfrsApiController>(
            HttpContext,
            nameof(BalanceEjecutivoIfrsApiController.ValidarPlanCuentas));

        var datos = await client.GetFromApiAsync<object>(url!);

        return Ok(datos);
    }

    /// <summary>
    /// Método proxy para validar clasificación IFRS.
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ValidarClasificacion([FromQuery] DateTime fechaHasta)
    {
        logger.LogInformation("MVC: Validar clasificación IFRS para fecha {FechaHasta}", fechaHasta);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<BalanceEjecutivoIfrsApiController>(
            HttpContext,
            nameof(BalanceEjecutivoIfrsApiController.ValidarClasificacion),
            new { fechaHasta });

        var datos = await client.GetFromApiAsync<object>(url!);

        return Ok(datos);
    }
}
