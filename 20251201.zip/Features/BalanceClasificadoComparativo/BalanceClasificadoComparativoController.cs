using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Extensions;
using App.Helpers;

namespace App.Features.BalanceClasificadoComparativo;

public class BalanceClasificadoComparativoController(
    ILogger<BalanceClasificadoComparativoController> logger,
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator) : Controller
{
    /// <summary>
    /// Vista principal del Balance Clasificado Comparativo
    /// GET /BalanceClasificadoComparativo
    /// </summary>
    [HttpGet]
    public IActionResult Index(
        [FromQuery] BalanceClasificadoComparativoMode modo = BalanceClasificadoComparativoMode.BalanceClasificado)
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder al Balance Clasificado Comparativo";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        int empresaId = SessionHelper.EmpresaId;
        short ano = (short)SessionHelper.Ano;

        logger.LogInformation(
            "Balance Clasificado Comparativo: Index called with empresaId: {EmpresaId}, año: {Ano}, modo: {Modo}",
            empresaId,
            ano,
            modo);

        var viewModel = new BalanceClasificadoComparativoViewModel
        {
            EmpresaId = empresaId,
            Ano = ano,
            Modo = modo,
            WindowTitle = GetWindowTitle(modo, empresaId, ano)
        };

        return View(viewModel);
    }

    /// <summary>
    /// Vista del Balance Clasificado (Activo/Pasivo/Patrimonio)
    /// GET /BalanceClasificadoComparativo/balance
    /// </summary>
    [HttpGet]
    public IActionResult BalanceClasificado()
    {
        int empresaId = SessionHelper.EmpresaId;
        short ano = (short)SessionHelper.Ano;

        logger.LogInformation("Opening Balance Clasificado view");

        var viewModel = new BalanceClasificadoComparativoViewModel
        {
            EmpresaId = empresaId,
            Ano = ano,
            Modo = BalanceClasificadoComparativoMode.BalanceClasificado,
            WindowTitle = GetWindowTitle(BalanceClasificadoComparativoMode.BalanceClasificado, empresaId, ano)
        };

        return View("Index", viewModel);
    }

    /// <summary>
    /// Vista del Estado de Resultado Comparativo
    /// GET /BalanceClasificadoComparativo/estado-resultado
    /// </summary>
    [HttpGet]
    public IActionResult EstadoResultado()
    {
        int empresaId = SessionHelper.EmpresaId;
        short ano = (short)SessionHelper.Ano;

        logger.LogInformation("Opening Estado de Resultado view");

        var viewModel = new BalanceClasificadoComparativoViewModel
        {
            EmpresaId = empresaId,
            Ano = ano,
            Modo = BalanceClasificadoComparativoMode.EstadoResultado,
            WindowTitle = GetWindowTitle(BalanceClasificadoComparativoMode.EstadoResultado, empresaId, ano)
        };

        return View("Index", viewModel);
    }

    private string GetWindowTitle(BalanceClasificadoComparativoMode modo, int empresaId, short ano)
    {
        var tipoBalance = modo == BalanceClasificadoComparativoMode.BalanceClasificado
            ? "Balance Clasificado Comparativo"
            : "Estado de Resultado Comparativo";

        return $"{tipoBalance} - Empresa {empresaId} - año {ano}";
    }

    /// <summary>
    /// PROXY: Obtiene opciones de filtros (�reas de Negocio, Centros de Costo)
    /// GET /BalanceClasificadoComparativo/Opciones
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Opciones([FromQuery] int empresaId)
    {
        logger.LogInformation(
            "BalanceClasificadoComparativo: Proxy Opciones called with empresaId: {EmpresaId}",
            empresaId);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<BalanceClasificadoComparativoApiController>(
            HttpContext,
            nameof(BalanceClasificadoComparativoApiController.GetOpciones),
            new { empresaId }
        );
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// PROXY: Genera el balance clasificado comparativo
    /// POST /BalanceClasificadoComparativo/Generar
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Generar([FromBody] JsonElement request)
    {
        logger.LogInformation("BalanceClasificadoComparativo: Proxy Generar called");

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<BalanceClasificadoComparativoApiController>(
            HttpContext,
            nameof(BalanceClasificadoComparativoApiController.Generar)
        );
        var (statusCode, content) = await client.ProxyRequestAsync(
            url!,
            request!,
            HttpMethod.Post);
        return StatusCode(statusCode, content);
    }

    /// <summary>
    /// PROXY: Exporta el balance a Excel
    /// POST /BalanceClasificadoComparativo/ExportarExcel
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> ExportarExcel([FromBody] JsonElement request)
    {
        logger.LogInformation("BalanceClasificadoComparativo: Proxy ExportarExcel called");

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<BalanceClasificadoComparativoApiController>(
            HttpContext,
            nameof(BalanceClasificadoComparativoApiController.ExportarExcel)
        );
        var (fileBytes, contentType) = await client.DownloadFileAsync(
            url,
            HttpMethod.Post,
            request);

        int empresaId = SessionHelper.EmpresaId;
        var fileName = $"BalanceClasificadoComparativo_{empresaId}_{DateTime.Now:yyyyMMddHHmmss}.xlsx";
        return File(fileBytes, contentType, fileName);
    }
}

/// <summary>
/// ViewModel para la vista del Balance Clasificado Comparativo
/// </summary>
public class BalanceClasificadoComparativoViewModel
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public BalanceClasificadoComparativoMode Modo { get; set; }
    public string WindowTitle { get; set; } = string.Empty;
}