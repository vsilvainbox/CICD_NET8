namespace App.Features.AjustesRliCaja;

public class AjustesRliCajaDto
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public List<TipoAjusteRliDto> Tipos { get; set; } = new();
}

public class TipoAjusteRliDto
{
    public int IdTipo { get; set; }
    public string? Nombre { get; set; }
    public List<GrupoAjusteRliDto> Grupos { get; set; } = new();
}

public class GrupoAjusteRliDto
{
    public int IdGrupo { get; set; }
    public string? Nombre { get; set; }
    public List<ItemAjusteRliDto> Items { get; set; } = new();
}

public class ItemAjusteRliDto
{
    public int TipoAjuste { get; set; }
    public int IdGrupo { get; set; }
    public int IdItem { get; set; }
    public string? TipoItem { get; set; }
    public string? Concepto { get; set; }
    public decimal Valor { get; set; }
    public int Orden { get; set; }
}

public class ExportRliDto
{
    public string? TipoItem { get; set; }
    public DateTime Fecha { get; set; }
    public string? Descripcion { get; set; }
    public decimal Monto { get; set; }
}
