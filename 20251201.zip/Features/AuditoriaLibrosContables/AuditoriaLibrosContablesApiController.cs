using Microsoft.AspNetCore.Mvc;

namespace App.Features.AuditoriaLibrosContables;

[ApiController]
[Route("[controller]/[action]")]
public class AuditoriaLibrosContablesApiController(
    IAuditoriaLibrosContablesService service,
    ILogger<AuditoriaLibrosContablesApiController> logger) : ControllerBase
{
    /// <summary>
    /// Obtiene todos los movimientos de auditoría para un período específico
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetAuditoria([FromQuery] int empresaId, [FromQuery] short ano, [FromQuery] int mes)
    {
        logger.LogInformation("API: GetAll called with empresaId: {EmpresaId}, ano: {Ano}, mes: {Mes}", empresaId, ano, mes);

        if (empresaId <= 0 || ano <= 0 || mes <= 0 || mes > 12)
        {
            return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "EmpresaId, Ano y Mes son requeridos y deben ser válidos" } });
        }

        var resultado = await service.GetAllAsync(empresaId, ano, mes);
        logger.LogInformation("API: Returning auditoría libros contables data");
        return Ok(resultado);
    }

    /// <summary>
    /// Obtiene el mes contable actual
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetCurrentMonth([FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: GetCurrentMonth called with empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        if (empresaId <= 0 || ano <= 0)
        {
            return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "EmpresaId y Ano son requeridos" } });
        }

        var mes = await service.GetCurrentMonthAsync(empresaId, ano);
        logger.LogInformation("API: Returning current month: {Month}", mes);
        return Ok(new { mes });
    }

    /// <summary>
    /// Exporta los datos de auditoría a Excel
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ExportarExcel([FromQuery] int empresaId, [FromQuery] short ano, [FromQuery] int mes)
    {
        logger.LogInformation("API: ExportToExcel called with empresaId: {EmpresaId}, ano: {Ano}, mes: {Mes}", empresaId, ano, mes);

        if (empresaId <= 0 || ano <= 0 || mes <= 0 || mes > 12)
        {
            return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "EmpresaId, Ano y Mes son requeridos y deben ser válidos" } });
        }

        var excelData = await service.ExportToExcelAsync(empresaId, ano, mes);
        logger.LogInformation("API: Returning Excel file");

        return File(
            excelData,
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            $"AuditoriaLibros_{ano}_{mes:00}.xlsx"
        );
    }



}