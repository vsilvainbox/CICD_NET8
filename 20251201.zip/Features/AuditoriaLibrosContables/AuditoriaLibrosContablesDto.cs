namespace App.Features.AuditoriaLibrosContables;

/// <summary>
/// DTO para auditor�a de libros contables
/// </summary>
public class AuditoriaLibrosContablesDto
{
    public int IdComp { get; set; }
    public DateTime? FechaComprobante { get; set; }
    public int? Correlativo { get; set; }
    public string? TipoComprobante { get; set; }
    public bool? OtrosIngEg14TER { get; set; }
    public string? CodigoCuenta { get; set; }
    public string? NombreCuenta { get; set; }
    public string? GlosaComprobante { get; set; }
    public string? RutEntidad { get; set; }
    public string? NombreEntidad { get; set; }
    public string? TipoDocumento { get; set; }
    public string? NumeroDocumento { get; set; }
    public DateTime? FechaEmision { get; set; }
    public DateTime? FechaVencimiento { get; set; }
    public string? GlosaMovimiento { get; set; }
    public string? AreaNegocio { get; set; }
    public string? CentroCosto { get; set; }
    public decimal? Debe { get; set; }
    public decimal? Haber { get; set; }
}

/// <summary>
/// DTO para filtros de b�squeda
/// </summary>
public class AuditoriaLibrosContablesFilterDto
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public int Mes { get; set; }
}