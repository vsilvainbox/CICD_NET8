using System.ComponentModel.DataAnnotations;
using App.Models.Validation;

namespace App.Features.AnalisisVencimientos;

/// <summary>
/// ViewModel para la página de Análisis de Vencimientos
/// Centraliza estado, cálculos y formateo (siguiendo patrón ASP.NET Core MVC)
/// </summary>
public class AnalisisVencimientosViewModel : IValidatableObject
{
    // === Propiedades de Contexto ===
    public int EmpresaId { get; set; }
    public short Ano { get; set; }

    // === Filtros de Búsqueda ===
    [Display(Name = "Vencim. al")]
    [DataType(DataType.Date)]
    public DateTime? FechaVencimiento { get; set; }

    [Display(Name = "Libro")]
    public int? TipoLib { get; set; }

    [Display(Name = "Cuenta")]
    public int? IdCuenta { get; set; }

    [Display(Name = "Nombre")]
    public int? IdEntidad { get; set; }

    [Display(Name = "RUT")]
    [StringLength(12)]
    [RutChileno(ValidateCheckDigit = false, ErrorMessage = "Formato de RUT inválido")]
    public string? Rut { get; set; }

    [Display(Name = "Usar RUT")]
    public bool UsarRut { get; set; } = true;

    [Display(Name = "Clasificación")]
    public int? Clasificacion { get; set; }

    // === Datos para Dropdowns ===
    public List<TipoLibroDto> TiposLibro { get; set; } = new();
    public List<ClasificacionEntidadDto> Clasificaciones { get; set; } = new();
    public List<CuentaComboDto> Cuentas { get; set; } = new();
    public List<EntidadComboDto> Entidades { get; set; } = new();

    // === Datos de Resultados ===
    public List<DocumentoVencimientoDto> Documentos { get; set; } = new();
    public int? DocumentoSeleccionadoId { get; set; }
    public List<int> IdsSeleccionados { get; set; } = new();

    // === Propiedades Calculadas (Anti-patrón 4: Evitar cálculos en JavaScript) ===

    /// <summary>
    /// Total general de todos los documentos (suma de Total)
    /// </summary>
    public decimal TotalGeneral => Documentos?.Sum(d => d.Total ?? 0) ?? 0;

    /// <summary>
    /// Total de saldos pendientes (suma de SaldoDoc)
    /// </summary>
    public decimal TotalSaldo => Documentos?.Sum(d => d.SaldoDoc ?? 0) ?? 0;

    /// <summary>
    /// Suma total de documentos seleccionados
    /// </summary>
    public decimal SumaSeleccionadosTotal
    {
        get
        {
            if (IdsSeleccionados == null || IdsSeleccionados.Count == 0)
                return 0;

            return Documentos?
                .Where(d => IdsSeleccionados.Contains(d.IdDoc))
                .Sum(d => d.Total ?? 0) ?? 0;
        }
    }

    /// <summary>
    /// Suma de saldos de documentos seleccionados
    /// </summary>
    public decimal SumaSeleccionadosSaldo
    {
        get
        {
            if (IdsSeleccionados == null || IdsSeleccionados.Count == 0)
                return 0;

            return Documentos?
                .Where(d => IdsSeleccionados.Contains(d.IdDoc))
                .Sum(d => d.SaldoDoc ?? 0) ?? 0;
        }
    }

    /// <summary>
    /// Cantidad de documentos encontrados
    /// </summary>
    public int CantidadDocumentos => Documentos?.Count ?? 0;

    /// <summary>
    /// Indica si hay documentos para mostrar
    /// </summary>
    public bool TieneDocumentos => CantidadDocumentos > 0;

    // === Propiedades Formateadas (Anti-patrón 5: Evitar formateo en JavaScript) ===

    /// <summary>
    /// Total general formateado como moneda chilena (sin decimales)
    /// </summary>
    public string TotalGeneralFormateado => TotalGeneral.ToString("N0");

    /// <summary>
    /// Total de saldos formateado como moneda chilena (sin decimales)
    /// </summary>
    public string TotalSaldoFormateado => TotalSaldo.ToString("N0");

    /// <summary>
    /// Suma de seleccionados (total) formateada
    /// </summary>
    public string SumaSeleccionadosTotalFormateado => SumaSeleccionadosTotal.ToString("N0");

    /// <summary>
    /// Suma de seleccionados (saldo) formateada
    /// </summary>
    public string SumaSeleccionadosSaldoFormateado => SumaSeleccionadosSaldo.ToString("N0");

    /// <summary>
    /// Fecha de vencimiento formateada para display
    /// </summary>
    public string FechaVencimientoFormateada => FechaVencimiento?.ToString("dd/MM/yyyy") ?? string.Empty;

    // === Validaciones de Negocio (Anti-patrón 6: Evitar duplicación de validaciones) ===

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        // Validación: Si UsarRut está activo, el RUT es obligatorio
        if (UsarRut && string.IsNullOrWhiteSpace(Rut))
        {
            yield return new ValidationResult(
                "Debe ingresar un RUT o desactivar la búsqueda por RUT",
                new[] { nameof(Rut) });
        }

        // Validación: Si hay RUT y UsarRut, debe haber IdEntidad o se buscará
        // (Esta validación se puede omitir si el comportamiento es buscar automáticamente)

        // Validación: Fecha de vencimiento no puede ser muy antigua (opcional)
        if (FechaVencimiento.HasValue && FechaVencimiento.Value < DateTime.Now.AddYears(-10))
        {
            yield return new ValidationResult(
                "La fecha de vencimiento no puede ser anterior a 10 años",
                new[] { nameof(FechaVencimiento) });
        }
    }

    // === Métodos Helper para la Vista ===

    /// <summary>
    /// Obtiene la clase CSS para una fila según si está seleccionada
    /// </summary>
    public string GetFilaClasses(int idDoc)
    {
        var baseClass = "hover:bg-gray-50 cursor-pointer";
        return DocumentoSeleccionadoId == idDoc
            ? $"{baseClass} bg-primary-100"
            : baseClass;
    }

    /// <summary>
    /// Indica si un documento está seleccionado
    /// </summary>
    public bool IsDocumentoSeleccionado(int idDoc)
    {
        return IdsSeleccionados.Contains(idDoc);
    }

    /// <summary>
    /// Convierte a FiltrosVencimientoDto para llamadas al servicio
    /// </summary>
    public FiltrosVencimientoDto ToFiltrosDto()
    {
        return new FiltrosVencimientoDto
        {
            FechaVencimiento = FechaVencimiento,
            TipoLib = TipoLib,
            IdCuenta = IdCuenta,
            IdEntidad = IdEntidad,
            Rut = Rut,
            UsarRut = UsarRut,
            Clasificacion = Clasificacion,
            UseCidFormat = true
        };
    }
}
