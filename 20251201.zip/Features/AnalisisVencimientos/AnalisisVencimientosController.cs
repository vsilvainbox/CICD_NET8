using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using App.Helpers;
using App.Extensions;

namespace App.Features.AnalisisVencimientos;

[Authorize]

public class AnalisisVencimientosController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    IAnalisisVencimientosService service,
    ILogger<AnalisisVencimientosController> logger) : Controller
{
    /// <summary>
    /// Vista principal del informe de vencimientos
    /// GET /AnalisisVencimientos
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Index(int? dias = 30)
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder al Análisis de Vencimientos";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        var empresaId = SessionHelper.EmpresaId;
        var ano = SessionHelper.Ano;

        logger.LogInformation("Loading AnalisisVencimientos index for empresaId: {EmpresaId}, ano: {Ano}, dias: {Dias}", empresaId, ano, dias);

        // Crear ViewModel con datos iniciales
        var viewModel = new AnalisisVencimientosViewModel
        {
            EmpresaId = empresaId,
            Ano = ano,
            FechaVencimiento = DateTime.Now.AddDays(dias ?? 30),
            TiposLibro = (await service.GetTiposLibroAsync()).ToList(),
            Clasificaciones = (await service.GetClasificacionesEntidadAsync()).ToList(),
            Cuentas = (await service.GetCuentasActivasAsync(empresaId, ano)).ToList()
        };

        // Cargar documentos iniciales automáticamente
        var filtros = viewModel.ToFiltrosDto();
        var documentos = await service.GetDocumentosVencidosAsync(empresaId, ano, filtros);
        viewModel.Documentos = documentos.ToList();

        return View(viewModel);
    }

    /// <summary>
    /// Filtra documentos y retorna HTML parcial
    /// POST /AnalisisVencimientos/Filtrar
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Filtrar(AnalisisVencimientosViewModel model)
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            return BadRequest("Sesión inválida");
        }

        var empresaId = SessionHelper.EmpresaId;
        var ano = SessionHelper.Ano;

        logger.LogInformation("Filtering documents with filters for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        // Si hay RUT y UsarRut, buscar la entidad
        if (model.UsarRut && !string.IsNullOrWhiteSpace(model.Rut) && !model.IdEntidad.HasValue)
        {
            var rutLimpio = model.Rut.Replace(".", "").Replace("-", "");
            var entidad = await service.SearchEntityByRutAsync(empresaId, rutLimpio);
            if (entidad != null)
            {
                model.IdEntidad = entidad.IdEntidad;
            }
        }

        // Obtener documentos
        var filtros = model.ToFiltrosDto();
        var documentos = await service.GetDocumentosVencidosAsync(empresaId, ano, filtros);

        model.EmpresaId = empresaId;
        model.Ano = ano;
        model.Documentos = documentos.ToList();

        // Retornar solo el grid (PartialView)
        return PartialView("Sections/_DocumentosGrid", model);
    }

    /// <summary>
    /// Calcula suma de documentos seleccionados y retorna JSON formateado
    /// POST /AnalisisVencimientos/CalcularSuma
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> CalcularSuma([FromBody] List<int> idsSeleccionados)
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            return BadRequest("Sesión inválida");
        }

        if (idsSeleccionados == null || idsSeleccionados.Count == 0)
        {
            return Json(new
            {
                sumaTotal = 0m,
                sumaSaldo = 0m,
                sumaTotalFormateado = "$0",
                sumaSaldoFormateado = "$0",
                cantidad = 0
            });
        }

        var empresaId = SessionHelper.EmpresaId;
        var ano = SessionHelper.Ano;

        logger.LogInformation("Calculating sum for {Count} selected documents", idsSeleccionados.Count);

        // Obtener documentos desde el servicio filtrando por IDs
        var documentos = await service.GetDocumentosByIdsAsync(empresaId, ano, idsSeleccionados);

        // Calcular sumas con precision decimal (server-side)
        decimal sumaTotal = documentos.Sum(d => d.Total ?? 0);
        decimal sumaSaldo = documentos.Sum(d => d.SaldoDoc ?? 0);

        return Json(new
        {
            sumaTotal,
            sumaSaldo,
            sumaTotalFormateado = "$" + sumaTotal.ToString("N0"),
            sumaSaldoFormateado = "$" + sumaSaldo.ToString("N0"),
            cantidad = documentos.Count()
        });
    }

    [HttpGet]
    public async Task<IActionResult> GetTiposLibro()
    {
        logger.LogInformation("Proxying GetTiposLibro");

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AnalisisVencimientosApiController>(
            HttpContext,
            nameof(AnalisisVencimientosApiController.GetTiposLibro));
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    [HttpGet]
    public async Task<IActionResult> GetClasificaciones()
    {
        logger.LogInformation("Proxying GetClasificaciones");

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AnalisisVencimientosApiController>(
            HttpContext,
            nameof(AnalisisVencimientosApiController.GetClasificaciones));
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    [HttpGet]
    public async Task<IActionResult> GetCuentas(int empresaId, short ano)
    {
        logger.LogInformation("Proxying GetCuentas: empresaId={EmpresaId}, ano={Ano}", empresaId, ano);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AnalisisVencimientosApiController>(
            HttpContext,
            nameof(AnalisisVencimientosApiController.GetCuentas),
            new { empresaId, ano });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    [HttpGet]
    public async Task<IActionResult> SearchEntity(string rut, int empresaId)
    {
        logger.LogInformation("Proxying SearchEntity: rut={Rut}, empresaId={EmpresaId}", rut, empresaId);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AnalisisVencimientosApiController>(
            HttpContext,
            nameof(AnalisisVencimientosApiController.SearchEntity),
            new { rut, empresaId });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    [HttpGet]
    public async Task<IActionResult> GetEntitiesByClassification(int clasificacion, int empresaId)
    {
        logger.LogInformation("Proxying GetEntitiesByClassification: clasificacion={Clasificacion}, empresaId={EmpresaId}", clasificacion, empresaId);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AnalisisVencimientosApiController>(
            HttpContext,
            nameof(AnalisisVencimientosApiController.GetEntitiesByClassification),
            new { clasificacion, empresaId });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Carga entidades por clasificación y retorna HTML de options para el select
    /// GET /AnalisisVencimientos/CargarEntidades
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> CargarEntidades(int clasificacion)
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            return BadRequest("Sesión inválida");
        }

        var empresaId = SessionHelper.EmpresaId;

        logger.LogInformation("Loading entities for clasificacion: {Clasificacion}, empresaId: {EmpresaId}", clasificacion, empresaId);

        var entidades = await service.GetEntitiesByClassificationAsync(empresaId, clasificacion);

        // Retornar HTML de options
        var options = new System.Text.StringBuilder();
        options.AppendLine("<option value=\"\">Todas</option>");

        foreach (var ent in entidades)
        {
            options.AppendLine($"<option value=\"{ent.IdEntidad}\" data-rut=\"{ent.Rut ?? ""}\" data-not-valid-rut=\"{(ent.NotValidRut ? "1" : "0")}\">{ent.Nombre}</option>");
        }

        return Content(options.ToString(), "text/html");
    }

    /// <summary>
    /// Proxy para obtener documentos vencidos con filtros
    /// GET /AnalisisVencimientos/GetDocumentos
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetDocumentos(int empresaId, short ano, string? fechaVencimiento = null,
        string? tipoLib = null, int? idCuenta = null, int? idEntidad = null)
    {
        logger.LogInformation("AnalisisVencimientos: GetDocumentos proxy called for empresaId={EmpresaId}, ano={Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient();

            var values = new Dictionary<string, object?>
            {
                ["empresaId"] = empresaId,
                ["ano"] = ano
            };

            if (!string.IsNullOrEmpty(fechaVencimiento))
                values["fechaVencimiento"] = fechaVencimiento;
            if (!string.IsNullOrEmpty(tipoLib))
                values["tipoLib"] = tipoLib;
            if (idCuenta.HasValue)
                values["idCuenta"] = idCuenta;
            if (idEntidad.HasValue)
                values["idEntidad"] = idEntidad;

            var url = linkGenerator.GetApiUrl<AnalisisVencimientosApiController>(
                HttpContext,
                nameof(AnalisisVencimientosApiController.GetDocumentos),
                values);
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Proxy para exportar documentos vencidos a Excel
    /// GET /AnalisisVencimientos/ExportExcel
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ExportExcel(int empresaId, short ano, string? fechaVencimiento = null,
        string? tipoLib = null, int? idCuenta = null)
    {
        logger.LogInformation("AnalisisVencimientos: ExportExcel proxy called for empresaId={EmpresaId}, ano={Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient();

            var values = new Dictionary<string, object?>
            {
                ["empresaId"] = empresaId,
                ["ano"] = ano
            };

            if (!string.IsNullOrEmpty(fechaVencimiento))
                values["fechaVencimiento"] = fechaVencimiento;
            if (!string.IsNullOrEmpty(tipoLib))
                values["tipoLib"] = tipoLib;
            if (idCuenta.HasValue)
                values["idCuenta"] = idCuenta;

            var url = linkGenerator.GetApiUrl<AnalisisVencimientosApiController>(
                HttpContext,
                nameof(AnalisisVencimientosApiController.ExportExcel),
                values);
            var (fileBytes, contentType) = await client.DownloadFileAsync(url, HttpMethod.Get);
            var fileName = $"AnalisisVencimientos_{empresaId}_{ano}.xlsx";
            return File(fileBytes, contentType, fileName);
        }
    }
}
