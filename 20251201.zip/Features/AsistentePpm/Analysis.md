# Análisis Exhaustivo: FrmAsisPPM.frm → AsistentePpm

## 📋 INFORMACIÓN GENERAL

**Formulario VB6:** `FrmAsisPPM.frm`
**Feature .NET:** `AsistentePpm`
**Ruta destino:** `\app\Features\AsistentePpm\`
**Propósito:** Asistente para reajuste de Pagos Provisionales Mensuales (PPM) Obligatorios y Voluntarios con actualización por IPC

---

## 🎯 FUNCIONALIDAD PRINCIPAL

Este formulario genera un reporte de reajuste de PPM (Pagos Provisionales Mensuales), tanto obligatorios como voluntarios, actualizando los montos pagados con factores de actualización anual (IPC) hasta diciembre del año fiscal.

**Características principales:**
1. **Dos grillas principales**: PPM Obligatorio y PPM Voluntario
2. **Actualización automática**: Aplica factor de actualización anual a cada pago
3. **Totales y reajustes**: Calcula totales originales, totales actualizados y reajustes
4. **Total traspaso**: Suma de ambos reajustes para traspaso contable
5. **Exportación**: Excel, Vista previa e Impresión
6. **Herramientas auxiliares**: Calculadora, convertidor moneda, calendario
7. **Configuración dinámica**: Puede excluir PPM pagados hasta 20/Enero según configuración

---

## 🗂️ CONTROLES DEL FORMULARIO

### Grillas (MSFlexGrid)

| Control | Propósito | Columnas |
|---------|-----------|----------|
| `GridPpmObligatorio` | Pagos PPM obligatorios con actualización | FECHA_PAGO, MONTO, MONTO_ACTUALIZADO |
| `GridPpmVoluntario` | Pagos PPM voluntarios con actualización | FECHA_PAGO, MONTO, MONTO_ACTUALIZADO |
| `GridTotOblig` | Totales y reajuste de PPM obligatorio | NOMBRE, MONTO, MONTO_ACTUALIZADO (3 filas: Totales, vacía, Reajuste) |
| `GridTotVolunt` | Totales y reajuste de PPM voluntario | NOMBRE, MONTO, MONTO_ACTUALIZADO (3 filas: Totales, vacía, Reajuste) |
| `GridTotTraspaso` | Total reajuste a traspasar | NOMBRE, VALOR (1 fila: suma reajustes obligatorio + voluntario) |

### Botones de Acción

| Botón | Ícono | ToolTip | Función |
|-------|-------|---------|---------|
| `Bt_Preview` | 👁️ | Vista previa de la impresión | Abre FrmPrintPreview con reporte completo |
| `Bt_Print` | 🖨️ | Imprimir | Imprime reporte directo a impresora |
| `Bt_CopyExcel` | 📊 | Copiar Excel | Copia datos al portapapeles formato Excel |
| `Bt_Calendar` | 📅 | Calendario | Abre FrmCalendar para selección de fecha |
| `Bt_ConvMoneda` | 💱 | Convertir moneda | Abre FrmConverMoneda para conversión |
| `Bt_Calc` | 🧮 | Calculadora | Abre calculadora Windows |
| `bt_Help` | ❓ | Ver formato archivo para importar cartola | Configura si incluir PPM hasta 20/Enero |
| `Bt_Sum[0]` | ➕ | Sumar movimientos seleccionados | Suma selección en GridPpmObligatorio |
| `Bt_Sum[1]` | ➕ | Sumar movimientos seleccionados | Suma selección en GridPpmVoluntario |
| `Bt_Cerrar` | ❌ | Cerrar | Cierra formulario |

### Frames (Agrupaciones)

| Frame | Caption | Contenido |
|-------|---------|-----------|
| `Frame1` | (sin caption) | Barra de herramientas superior con todos los botones |
| `Frame2` | "PPM Obligatorio" | GridPpmObligatorio + GridTotOblig |
| `FrmAsisPPM` (Frame) | "PPM Voluntario" | GridPpmVoluntario + GridTotVolunt |
| `Frame3` | (sin caption) | GridTotTraspaso |

---

## 📊 CONSTANTES Y VARIABLES GLOBALES

### Constantes de Columnas (Grids PPM)
```vb
Const C_FECHA_PAGO = 0            ' Columna: Fecha de pago PPM
Const C_MONTO = 1                  ' Columna: Monto original pagado
Const C_MONTO_ACTUALIZADO = 2      ' Columna: Monto actualizado con factor IPC
Const NCOLS = C_MONTO_ACTUALIZADO  ' Número total de columnas
```

### Constantes de Columnas (Grids Totales/Traspaso)
```vb
Const C_NOMBRE = 0                 ' Columna: Nombre del concepto (TOTALES, REAJUSTE, etc.)
Const C_NUMLIN = 1                 ' (No usado en este formulario)
```

### Variables de Módulo
```vb
Dim lOrientacion As Integer        ' Orientación de impresión (ORIENT_VER = vertical)
Dim lPapelFoliado As Boolean       ' Si usa papel foliado
Dim lInfoPreliminar As Boolean     ' Si muestra marca "INFO PRELIMINAR"
```

---

## 🔄 EVENTOS Y FLUJO DE EJECUCIÓN

### 1. `Form_Load()`

**Propósito:** Inicialización del formulario

**Flujo:**
```
1. Establece orientación vertical: lOrientacion = ORIENT_VER
2. Llama SetUpGridAll() → Configura estructura de todas las grillas
3. Llama LoadAllPpmObli() → Carga datos PPM Obligatorio
4. Llama LoadAllPpmVolun() → Carga datos PPM Voluntario
5. Llama CalcTotTraspasar() → Calcula total a traspasar
```

### 2. `SetUpGridAll()`

**Propósito:** Configura estructura y formato de todas las grillas

**Acciones PPM Obligatorio:**
```vb
' Anchos de columna
GridPpmObligatorio.ColWidth(C_FECHA_PAGO) = 1200
GridPpmObligatorio.ColWidth(C_MONTO) = 1300
GridPpmObligatorio.ColWidth(C_MONTO_ACTUALIZADO) = 2100

' Alineaciones
GridPpmObligatorio.ColAlignment(C_FECHA_PAGO) = flexAlignLeftCenter
GridPpmObligatorio.ColAlignment(otros) = flexAlignRightCenter

' Headers
GridPpmObligatorio.TextMatrix(0, C_FECHA_PAGO) = "FECHA PAGO"
GridPpmObligatorio.TextMatrix(0, C_MONTO) = "MONTO"
GridPpmObligatorio.TextMatrix(0, C_MONTO_ACTUALIZADO) = "MONTO ACTUALIZADO"

' Llamadas auxiliares
Call FGrSetup(GridPpmObligatorio)      ' Setup general del grid
Call FGrVRows(GridPpmObligatorio)      ' Configuración de filas
```

**Acciones PPM Voluntario:** Idénticas a PPM Obligatorio

### 3. `LoadAllPpmObli()`

**Propósito:** Carga datos de PPM Obligatorio desde base de datos

**Lógica de configuración PPM:**
```sql
-- Verifica configuración PPM en ParamEmpresa
SELECT Codigo, Valor FROM ParamEmpresa 
WHERE Tipo='PPM' 
AND IdEmpresa = gEmpresa.id 
AND Ano = gEmpresa.Ano

-- Si Valor != 0 → TipoPPM = True (excluir PPM hasta 20/Enero)
-- FechaPPM = 20/Enero/AñoFiscal
```

**Query principal (SQL Server):**
```sql
SELECT Comprobante.FECHA, MovComprobante.DEBE 
FROM (MovComprobante INNER JOIN Comprobante ON MovComprobante.IdComp = Comprobante.IdComp)
  INNER JOIN ParamEmpresa ON MovComprobante.IdEmpresa = ParamEmpresa.IdEmpresa 
WHERE MovComprobante.IdEmpresa = {gEmpresa.id}
  AND ParamEmpresa.tipo = 'CTAPPMOBLI'                               -- Tipo: Cuenta PPM Obligatorio
  AND MovComprobante.idCuenta = Convert(int, ParamEmpresa.valor)      -- La cuenta configurada
  AND COMPROBANTE.TIPO = {TC_EGRESO}                                  -- Tipo: Egreso
  AND COMPROBANTE.ESTADO = {EC_APROBADO}                              -- Estado: Aprobado
ORDER BY Comprobante.FECHA ASC
```

**Lógica de actualización por cada registro:**
```vb
' Si TipoPPM = True Y Fecha < 20/Enero → NO mostrar, marcar bt_Help visible
' Si TipoPPM = False O Fecha >= 20/Enero → Agregar fila

Para cada registro visible:
  ' Buscar factor de actualización
  Query: SELECT Factor FROM FactorActAnual
         WHERE Ano = Year(Fecha)
         AND MesCol = 12                    -- Siempre diciembre (mes destino)
         AND MesRow = Month(Fecha)          -- Mes del pago
  
  Si existe Factor:
    MontoActualizado = Monto * Factor
  Sino:
    MontoActualizado = Monto * 1
  
  ' Agregar fila al grid
  GridPpmObligatorio.TextMatrix(i, C_FECHA_PAGO) = Fecha formato dd/mm/yyyy
  GridPpmObligatorio.TextMatrix(i, C_MONTO) = Monto formato numérico
  GridPpmObligatorio.TextMatrix(i, C_MONTO_ACTUALIZADO) = MontoActualizado formato numérico
```

**Llamadas finales:**
```vb
Call CalcTotOblig()              ' Calcula totales y reajuste
GridPpmObligatorio.Redraw = True ' Redibuja grid
```

### 4. `LoadAllPpmVolun()`

**Propósito:** Carga datos de PPM Voluntario desde base de datos

**Query principal (SQL Server):**
```sql
SELECT Comprobante.FECHA, MovComprobante.DEBE 
FROM (MovComprobante INNER JOIN Comprobante ON MovComprobante.IdComp = Comprobante.IdComp)
  INNER JOIN ParamEmpresa ON MovComprobante.IdEmpresa = ParamEmpresa.IdEmpresa 
WHERE MovComprobante.IdEmpresa = {gEmpresa.id}
  AND ParamEmpresa.tipo = 'CTAPPMVOLU'                               -- Tipo: Cuenta PPM Voluntario
  AND MovComprobante.idCuenta = Convert(int, ParamEmpresa.valor)      -- La cuenta configurada
  AND COMPROBANTE.TIPO = {TC_EGRESO}                                  -- Tipo: Egreso
  AND COMPROBANTE.ESTADO = {EC_APROBADO}                              -- Estado: Aprobado
```

**Lógica:** Idéntica a LoadAllPpmObli() pero sin filtro de fecha 20/Enero

**Llamadas finales:**
```vb
Call CalcTotVolunt()              ' Calcula totales y reajuste
GridPpmVoluntario.Redraw = True   ' Redibuja grid
```

### 5. `CalcTotOblig()`

**Propósito:** Calcula totales y reajuste para PPM Obligatorio

**Lógica:**
```vb
' Recorre todas las filas de datos
For i = GridPpmObligatorio.FixedRows To GridPpmObligatorio.rows - 1
  If GridPpmObligatorio.TextMatrix(i, C_FECHA_PAGO) = "" Then Exit For
  
  ' Suma columnas MONTO y MONTO_ACTUALIZADO
  Tot(C_MONTO) += vFmt(TextMatrix(i, C_MONTO))
  Tot(C_MONTO_ACTUALIZADO) += vFmt(TextMatrix(i, C_MONTO_ACTUALIZADO))
Next i

' Fila 0: TOTALES
GridTotOblig.TextMatrix(0, C_NOMBRE) = "TOTALES"
GridTotOblig.TextMatrix(0, C_MONTO) = Tot(C_MONTO) formato numérico
GridTotOblig.TextMatrix(0, C_MONTO_ACTUALIZADO) = Tot(C_MONTO_ACTUALIZADO) formato numérico

' Fila 1: Vacía (separador visual)

' Fila 2: REAJUSTE (diferencia)
GridTotOblig.TextMatrix(2, C_NOMBRE) = "REAJUSTE"
GridTotOblig.TextMatrix(2, C_MONTO) = ""
GridTotOblig.TextMatrix(2, C_MONTO_ACTUALIZADO) = (Tot(C_MONTO_ACTUALIZADO) - Tot(C_MONTO)) formato numérico
```

### 6. `CalcTotVolunt()`

**Propósito:** Calcula totales y reajuste para PPM Voluntario

**Lógica:** Idéntica a `CalcTotOblig()` pero con `GridPpmVoluntario` y `GridTotVolunt`

### 7. `CalcTotTraspasar()`

**Propósito:** Calcula el total de reajuste a traspasar (suma de ambos reajustes)

**Lógica:**
```vb
' Configuración de grid
GridTotTraspaso.ColWidth(C_NOMBRE) = 1200
GridTotTraspaso.ColAlignment(0) = flexAlignRightCenter

' Cálculo
ReajusteOblig = GridTotOblig.TextMatrix(2, C_MONTO_ACTUALIZADO)   ' Reajuste obligatorio
ReajusteVolunt = GridTotVolunt.TextMatrix(2, C_MONTO_ACTUALIZADO) ' Reajuste voluntario

' Suma (convierte quitando comas de miles)
TotalTraspaso = Int(Replace(ReajusteVolunt, ",", "")) + Int(Replace(ReajusteOblig, ",", ""))

' Mostrar
GridTotTraspaso.TextMatrix(0, C_NOMBRE) = "TOTAL"
GridTotTraspaso.TextMatrix(1, 0) = TotalTraspaso formato numérico
```

### 8. `bt_Help_Click()`

**Propósito:** Configura si considerar PPM pagados hasta 20/Enero

**Flujo:**
```vb
Pregunta: "¿Desea considerar los PPM pagados hasta el 20/Enero para los cálculos posteriores?"

Si usuario responde SÍ:
  UPDATE ParamEmpresa SET Valor = '0' WHERE Tipo='PPM' AND IdEmpresa = {id} AND Ano = {año}
  ' Valor = 0 → TipoPPM = False → INCLUIR todos los PPM

Si usuario responde NO:
  UPDATE ParamEmpresa SET Valor = '1' WHERE Tipo='PPM' AND IdEmpresa = {id} AND Ano = {año}
  ' Valor = 1 → TipoPPM = True → EXCLUIR PPM hasta 20/Enero

' Recarga formulario con nueva configuración
Call Form_Load()
```

**Visibilidad de bt_Help:**
- Se hace visible cuando hay PPM pagados antes del 20/Enero y TipoPPM = True
- Indica que hay registros excluidos que el usuario puede optar por incluir

### 9. `Bt_CopyExcel_Click()`

**Propósito:** Copia datos al portapapeles en formato Excel

**Formato de salida:**
```
[HEADER] Reajuste PPM Obligatorio    Año {AñoFiscal}
[DATA]   {contenido GridPpmObligatorio}
[TOTALS] {contenido GridTotOblig - 3 filas}

[HEADER] Reajuste PPM Voluntario    Año {AñoFiscal}
[DATA]   {contenido GridPpmVoluntario}
[TOTALS] {contenido GridTotVolunt - 3 filas}

Total a Traspasar    {valor de GridTotTraspaso}
```

**Implementación:**
```vb
Clip = FGr2String(GridPpmObligatorio, Caption + " Obligatorio" & vbTab & "Año " & Año, False, C_NUMLIN)
Clip += FGr2String(GridTotOblig)
Clip += "" & vbCrLf

Clip += FGr2String(GridPpmVoluntario, Caption + " Voluntario" & vbTab & "Año " & Año)
Clip += FGr2String(GridTotVolunt)
Clip += "" & vbCrLf

Clip += "Total a Traspasar" & vbTab & GridTotTraspaso.TextMatrix(1, 0)

Clipboard.Clear
Clipboard.SetText Clip
```

### 10. `Bt_Preview_Click()` y `Bt_Print_Click()`

**Propósito:** Vista previa e impresión del reporte completo

**Estructura del reporte (3 secciones):**

1. **Sección PPM Obligatorio:**
   - Título: "REAJUSTE PPM OBLIGATORIO"
   - Grid: GridPpmObligatorio
   - Totales: GridTotOblig (3 filas)

2. **Sección PPM Voluntario:**
   - Título: "REAJUSTE PPM VOLUNTARIO"
   - Grid: GridPpmVoluntario
   - Totales: GridTotVolunt (3 filas)

3. **Sección Total Traspaso:**
   - Título: "TOTAL REAJUSTE TRASPASO"
   - Grid: GridTotTraspaso (1 fila)

**Configuración de impresión:**
```vb
' Títulos generales
Titulos(0) = "Reajuste PPM Obligatorio y Voluntario"
If lInfoPreliminar Then Titulos(2) = INFO_PRELIMINAR

' Encabezados por sección
Encabezados(2) = "REAJUSTE PPM OBLIGATORIO"
EncabezadosCont(2) = "REAJUSTE PPM VOLUNTARIO"
EncabezadosCont2(2) = "TOTAL REAJUSTE TRASPASO"

' Configuración ClsPrtFlxGrid
gPrtLibros.Orientacion = ORIENT_VER
gPrtLibros.CallEndDoc = False        ' Primera y segunda sección
gPrtLibros.EsContinuacion = True     ' Segunda y tercera sección
gPrtLibros.CallEndDoc = True         ' Tercera sección (final)

' Impresión
SetUpPrtGrid(GridPpmObligatorio, GridTotOblig)
Pag = gPrtLibros.PrtFlexGrid(destino)

SetUpPrtGrid2(GridPpmVoluntario, GridTotVolunt)
Pag = gPrtLibros.PrtFlexGrid(destino)

SetUpPrtGrid3(GridTotTraspaso)
Pag = gPrtLibros.PrtFlexGrid1(destino)

Printer.EndDoc (solo en Bt_Print)
```

### 11. Botones Auxiliares

| Evento | Acción |
|--------|--------|
| `Bt_Calc_Click()` | `Call Calculadora` (abre calculadora Windows) |
| `Bt_Calendar_Click()` | Abre `FrmCalendar` para selección de fecha |
| `Bt_ConvMoneda_Click()` | Abre `FrmConverMoneda` para conversión de moneda |
| `Bt_Sum_Click(0)` | Abre `FrmSumSimple` con selección de `GridPpmObligatorio` |
| `Bt_Sum_Click(1)` | Abre `FrmSumSimple` con selección de `GridPpmVoluntario` |
| `bt_Cerrar_Click()` | `Unload Me` (cierra formulario) |

---

## 🗄️ ENTIDADES Y TABLAS

### Entidades principales

| Entidad .NET | Tabla BD | Propiedades Relevantes | Uso |
|--------------|----------|------------------------|-----|
| `ParamEmpresa` | ParamEmpresa | IdEmpresa, Ano, Tipo, Codigo, Valor, ValorOld | Configuración de cuentas PPM y flag de fecha 20/Enero |
| `Comprobante` | Comprobante | IdComp, IdEmpresa, Ano, Fecha, Tipo, Estado, Glosa, TotalDebe, TotalHaber | Comprobantes de egreso con pagos PPM |
| `MovComprobante` | MovComprobante | IdMov, IdEmpresa, Ano, IdComp, IdCuenta, Debe, Haber, Glosa | Movimientos contables (egresos PPM) |
| `FactorActAnual` | FactorActAnual | IdFactorActAnual, Ano, MesRow, MesCol, Factor | Factores de actualización IPC por año/mes |

### Constantes VB6 a verificar

```vb
' Constantes de tipo de comprobante
TC_EGRESO = ?          ' Tipo: Egreso (valor a verificar en código)

' Constantes de estado de comprobante
EC_APROBADO = ?        ' Estado: Aprobado (valor a verificar en código)
```

### Tipos de ParamEmpresa relevantes

| Tipo | Descripción | Valor |
|------|-------------|-------|
| `'PPM'` | Configuración inclusión/exclusión PPM hasta 20/Enero | '0' = incluir todos, '1' = excluir hasta 20/Enero |
| `'CTAPPMOBLI'` | Código de cuenta contable PPM Obligatorio | IdCuenta (int convertido) |
| `'CTAPPMVOLU'` | Código de cuenta contable PPM Voluntario | IdCuenta (int convertido) |

---

## 📐 CÁLCULOS Y FÓRMULAS

### 1. Monto Actualizado

```csharp
// Para cada pago PPM
DateTime fechaPago = ...;           // Fecha del pago
decimal montoPagado = ...;          // Monto original del pago

// Buscar factor de actualización
var factor = await _context.FactorActAnual
    .Where(f => f.Ano == fechaPago.Year &&
                f.MesCol == 12 &&               // Siempre actualizar a diciembre
                f.MesRow == fechaPago.Month)    // Desde el mes del pago
    .Select(f => f.Factor)
    .FirstOrDefaultAsync();

decimal factorAplicar = factor ?? 1.0m;         // Si no hay factor, usar 1.0
decimal montoActualizado = montoPagado * factorAplicar;
```

### 2. Reajuste

```csharp
decimal reajuste = totalMontoActualizado - totalMontoPagado;
```

### 3. Total Traspaso

```csharp
decimal totalTraspaso = reajusteObligatorio + reajusteVoluntario;
```

---

## 🔍 VALIDACIONES Y REGLAS DE NEGOCIO

### 1. Filtrado por Fecha 20/Enero

**Condición:**
```csharp
// Obtener configuración PPM
var paramPpm = await _context.ParamEmpresa
    .Where(p => p.IdEmpresa == empresaId &&
                p.Ano == ano &&
                p.Tipo == "PPM")
    .FirstOrDefaultAsync();

bool excluirHasta20Enero = paramPpm?.Valor == "1";

// Aplicar filtro si corresponde
if (excluirHasta20Enero)
{
    DateTime fecha20Enero = new DateTime(ano, 1, 20);
    query = query.Where(x => x.Fecha > DateToSerial(fecha20Enero));
}
```

**Mostrar botón de ayuda:**
- Si `excluirHasta20Enero == true` Y existen registros con fecha < 20/Enero → Mostrar icono/botón de ayuda
- El botón permite al usuario cambiar la configuración

### 2. Solo Comprobantes de Egreso Aprobados

```csharp
query = query.Where(c => c.Tipo == TC_EGRESO && c.Estado == EC_APROBADO);
```

### 3. Cuentas Configuradas

```csharp
// Para PPM Obligatorio
var paramCtaOblig = await _context.ParamEmpresa
    .Where(p => p.IdEmpresa == empresaId &&
                p.Ano == ano &&
                p.Tipo == "CTAPPMOBLI")
    .FirstOrDefaultAsync();

int? idCuentaOblig = int.TryParse(paramCtaOblig?.Valor, out int ctaOblig) ? ctaOblig : null;

// Para PPM Voluntario
var paramCtaVolu = await _context.ParamEmpresa
    .Where(p => p.IdEmpresa == empresaId &&
                p.Ano == ano &&
                p.Tipo == "CTAPPMVOLU")
    .FirstOrDefaultAsync();

int? idCuentaVolu = int.TryParse(paramCtaVolu?.Valor, out int ctaVolu) ? ctaVolu : null;
```

**Validación:**
- Si no existe configuración de cuenta → No hay datos que mostrar
- Mostrar mensaje indicando que debe configurar las cuentas PPM

---

## 📤 EXPORTACIÓN Y FORMATO

### Excel (Portapapeles)

**Formato esperado:**
```
Reajuste PPM Obligatorio	Año 2024
FECHA PAGO	MONTO	MONTO ACTUALIZADO
15/03/2024	500,000	520,000
20/06/2024	600,000	610,000
...
TOTALES	1,100,000	1,130,000

REAJUSTE		30,000

Reajuste PPM Voluntario	Año 2024
FECHA PAGO	MONTO	MONTO ACTUALIZADO
10/04/2024	300,000	305,000
...
TOTALES	300,000	305,000

REAJUSTE		5,000

Total a Traspasar	35,000
```

### Impresión

**Características:**
- Orientación: Vertical (ORIENT_VER)
- Papel foliado: Opcional (lPapelFoliado)
- Marca preliminar: Opcional (lInfoPreliminar)
- Encabezado general: "Reajuste PPM Obligatorio y Voluntario"
- 3 secciones consecutivas en el mismo documento
- Totales de 3 líneas por sección (TOTALES, vacía, REAJUSTE)

---

## 🎨 INTERFAZ DE USUARIO (.NET)

### Layout Propuesto

```
┌────────────────────────────────────────────────────────────────────┐
│ [🖨️] [📊] [📅] [🧮] [💱] [❓]                     [Cerrar]         │
├────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────────────── PPM Obligatorio ───────────────────┐    │
│  │  ┌──────────────────────────────────────────────────────┐  │    │
│  │  │ FECHA PAGO │    MONTO    │ MONTO ACTUALIZADO        │  │    │
│  │  ├────────────┼─────────────┼──────────────────────────┤  │    │
│  │  │ 15/03/2024 │   500,000   │       520,000            │  │    │
│  │  │ 20/06/2024 │   600,000   │       610,000            │  │    │
│  │  └──────────────────────────────────────────────────────┘  │    │
│  │  ┌──────────────────────────────────────────────────────┐  │    │
│  │  │ TOTALES         1,100,000        1,130,000           │  │    │
│  │  │                                                       │  │    │
│  │  │ REAJUSTE                            30,000           │  │    │
│  │  └──────────────────────────────────────────────────────┘  │    │
│  │  [➕ Sumar]                                                │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                     │
│  ┌─────────────────────── PPM Voluntario ─────────────────────┐    │
│  │  ┌──────────────────────────────────────────────────────┐  │    │
│  │  │ FECHA PAGO │    MONTO    │ MONTO ACTUALIZADO        │  │    │
│  │  ├────────────┼─────────────┼──────────────────────────┤  │    │
│  │  │ 10/04/2024 │   300,000   │       305,000            │  │    │
│  │  └──────────────────────────────────────────────────────┘  │    │
│  │  ┌──────────────────────────────────────────────────────┐  │    │
│  │  │ TOTALES           300,000          305,000           │  │    │
│  │  │                                                       │  │    │
│  │  │ REAJUSTE                             5,000           │  │    │
│  │  └──────────────────────────────────────────────────────┘  │    │
│  │  [➕ Sumar]                                                │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  TOTAL TRASPASO:                        35,000             │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                     │
└────────────────────────────────────────────────────────────────────┘
```

### Componentes Tailwind CSS

```html
<!-- Botones de acción con iconos -->
<button class="btn-icon" title="Vista previa">🖨️</button>
<button class="btn-icon" title="Imprimir">🖨️</button>
<button class="btn-icon" title="Copiar Excel">📊</button>
<button class="btn-icon" title="Calendario">📅</button>
<button class="btn-icon" title="Calculadora">🧮</button>
<button class="btn-icon" title="Convertir moneda">💱</button>
<button class="btn-icon" id="btnHelp" title="Configurar filtro fecha">❓</button>

<!-- Tablas con Tailwind -->
<table class="table-auto w-full">
  <thead class="bg-primary-600 text-white">
    <tr>
      <th class="text-left">FECHA PAGO</th>
      <th class="text-right">MONTO</th>
      <th class="text-right">MONTO ACTUALIZADO</th>
    </tr>
  </thead>
  <tbody>
    <!-- Filas de datos -->
  </tbody>
  <tfoot class="bg-gray-100 font-bold">
    <tr>
      <td>TOTALES</td>
      <td class="text-right">1,100,000</td>
      <td class="text-right">1,130,000</td>
    </tr>
    <tr>
      <td>REAJUSTE</td>
      <td></td>
      <td class="text-right text-primary-600">30,000</td>
    </tr>
  </tfoot>
</table>
```

---

## 🚀 ENDPOINTS API REQUERIDOS

### 1. GET `/api/asistenteppm/obligatorio`

**Parámetros Query:**
- `empresaId` (int, requerido)
- `ano` (int, requerido)

**Response:**
```json
{
  "registros": [
    {
      "fechaPago": "2024-03-15T00:00:00",
      "monto": 500000.00,
      "montoActualizado": 520000.00
    }
  ],
  "totalMonto": 1100000.00,
  "totalMontoActualizado": 1130000.00,
  "reajuste": 30000.00,
  "mostrarBotonConfiguracion": false
}
```

### 2. GET `/api/asistenteppm/voluntario`

**Parámetros Query:**
- `empresaId` (int, requerido)
- `ano` (int, requerido)

**Response:**
```json
{
  "registros": [
    {
      "fechaPago": "2024-04-10T00:00:00",
      "monto": 300000.00,
      "montoActualizado": 305000.00
    }
  ],
  "totalMonto": 300000.00,
  "totalMontoActualizado": 305000.00,
  "reajuste": 5000.00
}
```

### 3. GET `/api/asistenteppm/totaltraspaso`

**Parámetros Query:**
- `empresaId` (int, requerido)
- `ano` (int, requerido)

**Response:**
```json
{
  "reajusteObligatorio": 30000.00,
  "reajusteVoluntario": 5000.00,
  "totalTraspaso": 35000.00
}
```

### 4. GET `/api/asistenteppm/configuracion`

**Parámetros Query:**
- `empresaId` (int, requerido)
- `ano` (int, requerido)

**Response:**
```json
{
  "excluirHasta20Enero": true,
  "idCuentaObligatoria": 12345,
  "idCuentaVoluntaria": 12346,
  "existenRegistrosExcluidos": false
}
```

### 5. POST `/api/asistenteppm/configuracion`

**Body:**
```json
{
  "empresaId": 1,
  "ano": 2024,
  "excluirHasta20Enero": false
}
```

**Response:**
```json
{
  "success": true,
  "message": "Configuración actualizada correctamente"
}
```

### 6. GET `/api/asistenteppm/exportexcel`

**Parámetros Query:**
- `empresaId` (int, requerido)
- `ano` (int, requerido)

**Response:** Archivo Excel (.xlsx)

**Content-Type:** `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`

---

## ⚙️ SERVICIOS REQUERIDOS

### IAsistentePpmService

```csharp
public interface IAsistentePpmService
{
    // Obtener datos PPM Obligatorio
    Task<AsistentePpmObligatorioDto> GetPpmObligatorioAsync(int empresaId, int ano);
    
    // Obtener datos PPM Voluntario
    Task<AsistentePpmVoluntarioDto> GetPpmVoluntarioAsync(int empresaId, int ano);
    
    // Obtener total traspaso
    Task<AsistentePpmTotalTraspasoDto> GetTotalTraspasoAsync(int empresaId, int ano);
    
    // Obtener configuración
    Task<AsistentePpmConfiguracionDto> GetConfiguracionAsync(int empresaId, int ano);
    
    // Actualizar configuración fecha 20/Enero
    Task<bool> ActualizarConfiguracionAsync(int empresaId, int ano, bool excluirHasta20Enero);
    
    // Exportar a Excel
    Task<byte[]> ExportarExcelAsync(int empresaId, int ano);
}
```

---

## 📊 DTOs REQUERIDOS

### AsistentePpmRegistroDto

```csharp
public class AsistentePpmRegistroDto
{
    public DateTime FechaPago { get; set; }
    public decimal Monto { get; set; }
    public decimal MontoActualizado { get; set; }
}
```

### AsistentePpmObligatorioDto

```csharp
public class AsistentePpmObligatorioDto
{
    public List<AsistentePpmRegistroDto> Registros { get; set; }
    public decimal TotalMonto { get; set; }
    public decimal TotalMontoActualizado { get; set; }
    public decimal Reajuste { get; set; }
    public bool MostrarBotonConfiguracion { get; set; }
}
```

### AsistentePpmVoluntarioDto

```csharp
public class AsistentePpmVoluntarioDto
{
    public List<AsistentePpmRegistroDto> Registros { get; set; }
    public decimal TotalMonto { get; set; }
    public decimal TotalMontoActualizado { get; set; }
    public decimal Reajuste { get; set; }
}
```

### AsistentePpmTotalTraspasoDto

```csharp
public class AsistentePpmTotalTraspasoDto
{
    public decimal ReajusteObligatorio { get; set; }
    public decimal ReajusteVoluntario { get; set; }
    public decimal TotalTraspaso { get; set; }
}
```

### AsistentePpmConfiguracionDto

```csharp
public class AsistentePpmConfiguracionDto
{
    public bool ExcluirHasta20Enero { get; set; }
    public int? IdCuentaObligatoria { get; set; }
    public int? IdCuentaVoluntaria { get; set; }
    public bool ExistenRegistrosExcluidos { get; set; }
}
```

---

## 🔄 CONVERSIONES Y HELPERS

### Conversión Fecha Serial

```csharp
// VB6 almacena fechas como integer serial (días desde 30/12/1899)
public static DateTime SerialToDate(int serial)
{
    DateTime baseDate = new DateTime(1899, 12, 30);
    return baseDate.AddDays(serial);
}

public static int DateToSerial(DateTime date)
{
    DateTime baseDate = new DateTime(1899, 12, 30);
    return (int)(date - baseDate).TotalDays;
}
```

### Constantes de Comprobante

```csharp
// Verificar valores exactos en código VB6 existente
public const int TC_EGRESO = 2;        // Tipo: Egreso (VERIFICAR)
public const int EC_APROBADO = 2;      // Estado: Aprobado (VERIFICAR)
```

---

## 📝 NOTAS DE IMPLEMENTACIÓN

### 1. Dependencias Externas
- `FGrSetup()`, `FGrVRows()`: Funciones de configuración de grid (no migrar, usar Tailwind CSS)
- `Calculadora`, `FrmCalendar`, `FrmConverMoneda`, `FrmSumSimple`: Herramientas auxiliares (implementar según disponibilidad)
- `ClsPrtFlxGrid`: Clase de impresión VB6 (no migrar, usar funciones browser print())

### 2. Ordenamiento
- Los registros PPM se muestran ordenados por FECHA ascendente (más antiguos primero)

### 3. Formato Numérico
- En VB6 usa formato `NUMFMT` (verificar: formato chileno con separador de miles punto `.` y decimal coma `,`)
- En .NET usar formato: `#,##0` (separador miles: punto, sin decimales)

### 4. Rendimiento
- Cargar FactorActAnual en memoria al inicio (solo ~144 registros: 12 meses × 12 meses × año)
- Usar un solo diccionario: `Dictionary<(int Ano, int MesRow, int MesCol), double> factoresCache`

### 5. Validaciones de Datos
- Si no existe configuración de cuentas PPM → Mostrar mensaje "Configure las cuentas PPM en Parámetros de Empresa"
- Si no existen factores de actualización para un año → Usar factor 1.0 (sin actualización)
- Si no hay registros → Mostrar mensaje "No hay pagos PPM registrados para el año {año}"

### 6. Botón de Configuración (bt_Help)
- Solo visible si:
  - La configuración actual excluye PPM hasta 20/Enero (`ParamEmpresa.Tipo='PPM' AND Valor='1'`)
  - Y existen registros con fecha anterior a 20/Enero
- Al hacer clic: Modal de confirmación SweetAlert2 con pregunta del VB6

---

## ✅ CHECKLIST DE IMPLEMENTACIÓN

- [ ] Crear DTOs con propiedades exactas
- [ ] Verificar constantes TC_EGRESO y EC_APROBADO en código VB6
- [ ] Implementar IAsistentePpmService
- [ ] Implementar AsistentePpmService con:
  - [ ] GetPpmObligatorioAsync
  - [ ] GetPpmVoluntarioAsync
  - [ ] GetTotalTraspasoAsync
  - [ ] GetConfiguracionAsync
  - [ ] ActualizarConfiguracionAsync
  - [ ] ExportarExcelAsync
- [ ] Implementar AsistentePpmApiController con todos los endpoints
- [ ] Implementar AsistentePpmController (MVC)
- [ ] Crear View Index.cshtml con:
  - [ ] Barra de herramientas (botones con iconos)
  - [ ] Tabla PPM Obligatorio con totales
  - [ ] Tabla PPM Voluntario con totales
  - [ ] Sección Total Traspaso
  - [ ] Botón configuración (condicional)
  - [ ] Funcionalidad Copiar Excel
  - [ ] Funcionalidad Vista previa/Impresión
- [ ] Agregar navegación en _Layout.cshtml
- [ ] Actualizar features.md (❌ PENDIENTE → ✅ COMPLETADO)
- [ ] Probar conversiones de fecha serial
- [ ] Probar cálculos de actualización con factores IPC
- [ ] Probar configuración inclusión/exclusión 20/Enero

---

## 🎓 CONCLUSIÓN

Este es un **reporte de reajuste contable-fiscal** que actualiza los Pagos Provisionales Mensuales (PPM) con factores de actualización anual (IPC) hasta diciembre. Es crítico para:

1. **Determinar el reajuste total** que debe traspasarse como gasto en la declaración anual
2. **Diferenciar PPM obligatorio vs voluntario** (tienen tratamiento fiscal distinto)
3. **Permitir configuración flexible** para incluir/excluir PPM pagados hasta 20/Enero según normativa vigente

**Complejidad:** Media-Alta
- Múltiples queries con joins
- Cálculos de actualización con factores externos (IPC)
- Lógica condicional basada en configuración
- Exportación multi-formato (Excel, impresión)
- Interfaz de usuario con múltiples secciones y totales anidados
