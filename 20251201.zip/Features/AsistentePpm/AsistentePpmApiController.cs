using Microsoft.AspNetCore.Mvc;

namespace App.Features.AsistentePpm;

/// <summary>
/// API Controller para Asistente de Reajuste PPM
/// </summary>
[ApiController]
[Route("[controller]/[action]")]
public class AsistentePpmApiController(IAsistentePpmService service, ILogger<AsistentePpmApiController> logger) : ControllerBase
{
    private readonly IAsistentePpmService _service = service ?? throw new ArgumentNullException(nameof(service));
    private readonly ILogger<AsistentePpmApiController> _logger = logger ?? throw new ArgumentNullException(nameof(logger));

    /// <summary>
    /// Obtiene los datos de PPM Obligatorio con actualización por factores IPC
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año fiscal</param>
    /// <returns>DTO con registros PPM obligatorios, totales y reajuste</returns>
    [HttpGet]
    [ProducesResponseType(typeof(AsistentePpmObligatorioDto), 200)]
    [ProducesResponseType(400)]
    [ProducesResponseType(500)]
    public async Task<ActionResult<AsistentePpmObligatorioDto>> GetObligatorio(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        if (empresaId <= 0)
        {
            _logger.LogWarning("Solicitud con empresaId inválido: {EmpresaId}", empresaId);
            return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "El ID de empresa debe ser mayor a 0" } });
        }

        if (ano < 2000 || ano > 2100)
        {
            _logger.LogWarning("Solicitud con año inválido: {Ano}", ano);
            return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "El año debe estar entre 2000 y 2100" } });
        }

        {
            var resultado = await _service.GetPpmObligatorioAsync(empresaId, ano);
            return Ok(resultado);
        }
    }

    /// <summary>
    /// Obtiene los datos de PPM Voluntario con actualización por factores IPC
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año fiscal</param>
    /// <returns>DTO con registros PPM voluntarios, totales y reajuste</returns>
    [HttpGet]
    [ProducesResponseType(typeof(AsistentePpmVoluntarioDto), 200)]
    [ProducesResponseType(400)]
    [ProducesResponseType(500)]
    public async Task<ActionResult<AsistentePpmVoluntarioDto>> GetVoluntario(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        if (empresaId <= 0)
        {
            _logger.LogWarning("Solicitud con empresaId inválido: {EmpresaId}", empresaId);
            return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "El ID de empresa debe ser mayor a 0" } });
        }

        if (ano < 2000 || ano > 2100)
        {
            _logger.LogWarning("Solicitud con año inválido: {Ano}", ano);
            return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "El año debe estar entre 2000 y 2100" } });
        }

        {
            var resultado = await _service.GetPpmVoluntarioAsync(empresaId, ano);
            return Ok(resultado);
        }
    }

    /// <summary>
    /// Calcula el total de reajuste a traspasar sumando el reajuste de PPM obligatorio y voluntario
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año fiscal</param>
    /// <returns>DTO con reajustes individuales y total a traspasar</returns>
    [HttpGet]
    [ProducesResponseType(typeof(AsistentePpmTotalTraspasoDto), 200)]
    [ProducesResponseType(400)]
    [ProducesResponseType(500)]
    public async Task<ActionResult<AsistentePpmTotalTraspasoDto>> GetTotalTraspaso(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        if (empresaId <= 0)
        {
            _logger.LogWarning("Solicitud con empresaId inválido: {EmpresaId}", empresaId);
            return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "El ID de empresa debe ser mayor a 0" } });
        }

        if (ano < 2000 || ano > 2100)
        {
            _logger.LogWarning("Solicitud con año inválido: {Ano}", ano);
            return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "El año debe estar entre 2000 y 2100" } });
        }

        {
            var resultado = await _service.GetTotalTraspasoAsync(empresaId, ano);
            return Ok(resultado);
        }
    }

    /// <summary>
    /// Obtiene la configuración actual de AsistentePpm
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año fiscal</param>
    /// <returns>DTO con configuración actual</returns>
    [HttpGet]
    [ProducesResponseType(typeof(AsistentePpmConfiguracionDto), 200)]
    [ProducesResponseType(400)]
    [ProducesResponseType(500)]
    public async Task<ActionResult<AsistentePpmConfiguracionDto>> GetConfiguracion(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        if (empresaId <= 0)
        {
            _logger.LogWarning("Solicitud con empresaId inválido: {EmpresaId}", empresaId);
            return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "El ID de empresa debe ser mayor a 0" } });
        }

        if (ano < 2000 || ano > 2100)
        {
            _logger.LogWarning("Solicitud con año inválido: {Ano}", ano);
            return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "El año debe estar entre 2000 y 2100" } });
        }

        {
            var resultado = await _service.GetConfiguracionAsync(empresaId, ano);
            return Ok(resultado);
        }
    }

    /// <summary>
    /// Actualiza la configuración de inclusión/exclusión de PPM pagados hasta 20/Enero
    /// </summary>
    /// <param name="dto">DTO con la nueva configuración</param>
    /// <returns>Resultado de la operación</returns>
    [HttpPost]
    [ProducesResponseType(200)]
    [ProducesResponseType(400)]
    [ProducesResponseType(500)]
    public async Task<ActionResult> PostConfiguracion([FromBody] ActualizarConfiguracionPpmDto dto)
    {
        if (!ModelState.IsValid)
        {
            _logger.LogWarning("Solicitud con modelo inválido");
            return BadRequest(ModelState);
        }

        {
            bool resultado = await _service.ActualizarConfiguracionAsync(
                dto.EmpresaId,
                dto.Ano,
                dto.ExcluirHasta20Enero);

            if (resultado)
            {
                return Ok(new { success = true, message = "Configuración actualizada correctamente" });
            }
            else
            {
                return StatusCode(500, new { success = false, message = "No se pudo actualizar la configuración" });
            }
        }
    }

    /// <summary>
    /// Exporta a Excel el reporte completo de reajuste PPM
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año fiscal</param>
    /// <returns>Archivo Excel</returns>
    [HttpGet]
    [ProducesResponseType(typeof(FileContentResult), 200)]
    [ProducesResponseType(400)]
    [ProducesResponseType(500)]
    public async Task<ActionResult> ExportExcel(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        if (empresaId <= 0)
        {
            _logger.LogWarning("Solicitud con empresaId inválido: {EmpresaId}", empresaId);
            return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "El ID de empresa debe ser mayor a 0" } });
        }

        if (ano < 2000 || ano > 2100)
        {
            _logger.LogWarning("Solicitud con año inválido: {Ano}", ano);
            return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "El año debe estar entre 2000 y 2100" } });
        }

        {
            byte[] excelBytes = await _service.ExportarExcelAsync(empresaId, ano);
            string fileName = $"ReajustePPM_{ano}.xlsx";

            return File(
                excelBytes,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                fileName);
        }
    }
}
