using Microsoft.AspNetCore.Mvc;

namespace App.Features.AjustesExtraContablesCaja;

[ApiController]
[Route("[controller]/[action]")]
public class AjustesExtraContablesCajaApiController(
    IAjustesExtraContablesCajaService service,
    ILogger<AjustesExtraContablesCajaApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<AjustesExtraContablesCajaDto>> Calcular(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        logger.LogInformation("API: Calcular ajustes called");

        {
            var data = await service.CalcularAjustesAsync(empresaId, ano);
            return Ok(data);
        }
    }

    [HttpPost]
    public async Task<ActionResult> Guardar([FromBody] SaveAjustesDto dto)
    {
        logger.LogInformation("API: Guardar ajustes called");

        {
            var success = await service.GuardarAjustesAsync(dto);
            
            if (success)
            {
                return Ok(new { message = "Ajustes guardados correctamente" });
            }

            return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "Error al guardar ajustes" } });
        }
    }
}

