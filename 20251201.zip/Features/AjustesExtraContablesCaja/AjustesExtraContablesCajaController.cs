using Microsoft.AspNetCore.Mvc;
using App.Helpers;
using System.Text.Json;
using App.Extensions;

namespace App.Features.AjustesExtraContablesCaja;


public class AjustesExtraContablesCajaController(
    ILogger<AjustesExtraContablesCajaController> logger,
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator) : Controller
{
    public IActionResult Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Ajustes Extra Contables Caja";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        logger.LogInformation("AjustesExtraContablesCaja accessed for EmpresaId: {EmpresaId}, Ano: {Ano}",
            SessionHelper.EmpresaId, SessionHelper.Ano);

        // Establecer datos comunes en ViewBag desde la sesión
        return View();
    }

    [HttpGet]
    public async Task<IActionResult> Calcular(int empresaId, short ano)
    {
        logger.LogInformation("Calcular called for EmpresaId: {EmpresaId}, Ano: {Ano}", empresaId, ano);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AjustesExtraContablesCajaApiController>(
            HttpContext,
            nameof(AjustesExtraContablesCajaApiController.Calcular),
            new { empresaId, ano });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    [HttpPost]
    public async Task<IActionResult> Guardar([FromBody] JsonElement request)
    {
        logger.LogInformation("Guardar called for EmpresaId: {EmpresaId}, Ano: {Ano}", SessionHelper.EmpresaId, SessionHelper.Ano);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AjustesExtraContablesCajaApiController>(
            HttpContext,
            nameof(AjustesExtraContablesCajaApiController.Guardar));
        var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }
}
