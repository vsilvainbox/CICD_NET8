using Microsoft.EntityFrameworkCore;
using App.Data;
using LibroCajaEntity = App.Data.LibroCaja;

namespace App.Features.AjustesExtraContablesCaja;

public class AjustesExtraContablesCajaService(
    LpContabContext context,
    ILogger<AjustesExtraContablesCajaService> logger) : IAjustesExtraContablesCajaService
{
    public async Task<AjustesExtraContablesCajaDto> CalcularAjustesAsync(int empresaId, short ano)
    {
        return await GetAjustesAsync(empresaId, ano);
    }

    public Task<bool> GuardarAjustesAsync(SaveAjustesDto dto)
    {
        logger.LogInformation("Saving ajustes for empresa {EmpresaId}, año {Ano}", dto.EmpresaId, dto.Ano);

        {
            // TODO: [LEGACY] [MEDIUM] Implementar guardado de ajustes
            // Requiere análisis de estructura de tabla AjustesExtLibCaja
            
            logger.LogInformation("Ajustes saved successfully");
            return Task.FromResult(true);
        }
    }

    private async Task<AjustesExtraContablesCajaDto> GetAjustesAsync(int empresaId, short ano)
    {
        logger.LogInformation("Getting ajustes extra contables caja for empresa {EmpresaId}, año {Ano}", empresaId, ano);

        {
            var dto = new AjustesExtraContablesCajaDto
            {
                EmpresaId = empresaId,
                Ano = ano,
                Documentos = new List<DocumentoAjusteDto>()
            };

            // Obtener documentos del libro caja
            var libroCaja = await context.LibroCaja
                .Where(lc => lc.IdEmpresa == empresaId && lc.Ano == ano)
                .OrderBy(lc => lc.FechaOperacion)
                .ToListAsync();

            // Obtener fecha de cierre y apertura
            var empresaAno = await context.EmpresasAno
                .FirstOrDefaultAsync(ea => ea.idEmpresa == empresaId && ea.Ano == ano);

            if (empresaAno == null)
            {
                logger.LogWarning("No se encontró EmpresasAno para empresa {EmpresaId}, año {Ano}", empresaId, ano);
                return dto;
            }

            int? fechaCierre = empresaAno.FCierre;
            int? fechaApertura = empresaAno.FApertura;

            // Procesar cada entrada del libro caja
            foreach (var entry in libroCaja)
            {
                var docDto = new DocumentoAjusteDto
                {
                    IdDoc = entry.IdDoc ?? 0,
                    TipoLib = entry.TipoLib ?? 0,
                    TipoDoc = entry.TipoDoc ?? 0,
                    NumDoc = entry.NumDoc ?? string.Empty,
                    FechaOperacion = entry.FechaOperacion ?? 0,
                    RutEntidad = entry.RutEntidad ?? string.Empty,
                    NombreEntidad = entry.NombreEntidad ?? string.Empty,
                    Total = entry.Total ?? 0,
                    Ajustes = new List<AjusteItemDto>()
                };

                // Calcular ajustes para este documento
                await CalcularAjustesDocumentoAsync(docDto, entry, fechaCierre, fechaApertura);

                dto.Documentos.Add(docDto);
            }

            // Calcular totales
            dto.TotalAgregados = (decimal)dto.Documentos.Sum(d => d.Ajustes.Where(a => a.TipoAjuste == 1).Sum(a => a.Monto));
            dto.TotalDeducciones = (decimal)dto.Documentos.Sum(d => d.Ajustes.Where(a => a.TipoAjuste == 2).Sum(a => a.Monto));

            logger.LogInformation("Ajustes retrieved successfully. Total agregados: {TotalAgregados}, Total deducciones: {TotalDeducciones}",
                dto.TotalAgregados, dto.TotalDeducciones);

            return dto;
        }
    }

    private async Task CalcularAjustesDocumentoAsync(
        DocumentoAjusteDto docDto,
        LibroCajaEntity libroCajaEntry,
        int? fechaCierre,
        int? fechaApertura)
    {
        // TODO: [LEGACY] [HIGH] Implementar cálculo de ajustes extracontables
        // Lógica compleja que requiere análisis detallado del código VB6 original
        
        // 1. Verificar si documento tiene cuotas pendientes
        if (libroCajaEntry.IdDoc.HasValue)
        {
            var cuotas = await context.DocCuotas
                .Where(dc => dc.IdEmpresa == libroCajaEntry.IdEmpresa
                          && dc.Ano == libroCajaEntry.Ano
                          && dc.IdDoc == libroCajaEntry.IdDoc.Value)
                .ToListAsync();

            // Análisis de cuotas para determinar ajustes
            foreach (var cuota in cuotas)
            {
                // TODO: Implementar lógica de ajuste por cuotas
                // Requiere análisis de fechas de vencimiento vs fechas de pago
            }
        }

        // 2. Calcular ajuste por IPC si corresponde
        if (libroCajaEntry.FechaOperacion.HasValue && fechaCierre.HasValue)
        {
            // Convertir fechas a AnoMes para buscar en IPC
            int anoMesOperacion = ConvertirFechaAAnoMes(libroCajaEntry.FechaOperacion.Value);
            int anoMesCierre = ConvertirFechaAAnoMes(fechaCierre.Value);

            // Buscar valores IPC
            var ipcOperacion = await context.IPC
                .FirstOrDefaultAsync(i => i.AnoMes == anoMesOperacion);

            var ipcCierre = await context.IPC
                .FirstOrDefaultAsync(i => i.AnoMes == anoMesCierre);

            if (ipcOperacion != null && ipcCierre != null && 
                ipcOperacion.vIPC.HasValue && ipcCierre.vIPC.HasValue &&
                ipcOperacion.vIPC.Value != 0)
            {
                // Calcular factor de ajuste IPC
                double factorIPC = ipcCierre.vIPC.Value / ipcOperacion.vIPC.Value;
                
                // TODO: Aplicar ajuste según tipo de operación
                // Requiere análisis de reglas tributarias específicas
            }
        }

        // 3. Verificar si documento está relacionado con entidad relacionada
        if (libroCajaEntry.ConEntRel == true)
        {
            // TODO: Implementar ajustes para entidades relacionadas
            // Requiere análisis de reglas tributarias específicas
        }
    }

    private int ConvertirFechaAAnoMes(int fecha)
    {
        // Fecha en formato OLE - convertir a DateTime y extraer año/mes
        var date = DateTime.FromOADate(fecha);
        return date.Year * 100 + date.Month;
    }

    public async Task<RentaLiquidaImponibleDto> CalcularRentaLiquidaAsync(int empresaId, short ano)
    {
        logger.LogInformation("Calculating renta liquida imponible for empresa {EmpresaId}, año {Ano}", empresaId, ano);

        {
            var ajustes = await GetAjustesAsync(empresaId, ano);

            var rli = new RentaLiquidaImponibleDto
            {
                EmpresaId = empresaId,
                Ano = ano,
                RentaBruta = 0, // TODO: Obtener de balance
                TotalAgregados = (double)ajustes.TotalAgregados,
                TotalDeducciones = (double)ajustes.TotalDeducciones
            };

            rli.RentaLiquida = rli.RentaBruta + rli.TotalAgregados - rli.TotalDeducciones;

            logger.LogInformation("Renta liquida calculated: {RentaLiquida}", rli.RentaLiquida);
            return rli;
        }
    }

    public async Task<List<AjusteItemDto>> GetAjustesPorTipoAsync(int empresaId, short ano, int tipoAjuste)
    {
        logger.LogInformation("Getting ajustes by type {TipoAjuste} for empresa {EmpresaId}, año {Ano}",
            tipoAjuste, empresaId, ano);

        {
            var ajustes = await GetAjustesAsync(empresaId, ano);

            var ajustesPorTipo = ajustes.Documentos
                .SelectMany(d => d.Ajustes)
                .Where(a => a.TipoAjuste == tipoAjuste)
                .ToList();

            logger.LogInformation("Found {Count} ajustes of type {TipoAjuste}", ajustesPorTipo.Count, tipoAjuste);
            return ajustesPorTipo;
        }
    }
}
