# Legacy Analysis: Capital Aportado

## 📄 VB6: FrmCapitalAportado.frm
**Propósito:** Grid editable para gestionar capital aportado por socios y calcularlo para Capital Propio Simplificado

### Campos Socios
1. **RUT** - RUT del socio (read-only)
2. **Nombre** - Nombre del socio (read-only)
3. **MontoPagado** - Monto ya pagado (read-only)
4. **MontoIngresadoUsuario** - Monto manual ingresado por usuario (editable)
5. **MontoATraspasar** - Monto a traspasar = MontoIngresadoUsuario OR MontoPagado (calculado)

### Lógica Cálculo
- Si usuario ingresa `MontoIngresadoUsuario`, ese es el `MontoATraspasar`
- Si no, usa `MontoPagado` como default
- Total se suma y guarda en `EmpresasAno.CPS_CapitalAportado`

### Operaciones
- **LoadAll()**: Carga socios desde tabla `Socios`
- **SaveAll()**: UPDATE `Socios` (MontoIngresadoUsuario, MontoATraspasar) + UPDATE `EmpresasAno.CPS_CapitalAportado`
- Grid editable con cálculo automático de totales

**Entidades:** `Socios`, `EmpresasAno` (CPS_CapitalAportado existe en schema)


## 📄 VB6: FrmCapitalAportado.frm
**Propósito:** Grid editable para gestionar capital aportado por socios y calcularlo para Capital Propio Simplificado

### Campos Socios
1. **RUT** - RUT del socio (read-only)
2. **Nombre** - Nombre del socio (read-only)
3. **MontoPagado** - Monto ya pagado (read-only)
4. **MontoIngresadoUsuario** - Monto manual ingresado por usuario (editable)
5. **MontoATraspasar** - Monto a traspasar = MontoIngresadoUsuario OR MontoPagado (calculado)

### Lógica Cálculo
- Si usuario ingresa `MontoIngresadoUsuario`, ese es el `MontoATraspasar`
- Si no, usa `MontoPagado` como default
- Total se suma y guarda en `EmpresasAno.CPS_CapitalAportado`

### Operaciones
- **LoadAll()**: Carga socios desde tabla `Socios`
- **SaveAll()**: UPDATE `Socios` (MontoIngresadoUsuario, MontoATraspasar) + UPDATE `EmpresasAno.CPS_CapitalAportado`
- Grid editable con cálculo automático de totales

**Entidades:** `Socios`, `EmpresasAno` (CPS_CapitalAportado existe en schema)

