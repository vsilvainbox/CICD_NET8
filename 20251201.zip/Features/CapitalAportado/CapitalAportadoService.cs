using Microsoft.EntityFrameworkCore;
using App.Data;
using App.Exceptions;

namespace App.Features.CapitalAportado;

public class CapitalAportadoService(
    LpContabContext context,
    ILogger<CapitalAportadoService> logger) : ICapitalAportadoService
{
    public async Task<CapitalAportadoDto> GetCapitalAportadoAsync(int empresaId, short ano)
    {
        logger.LogInformation("Getting capital aportado for empresa {EmpresaId}, año {Ano}", empresaId, ano);

        var socios = await context.Socios
            .Where(s => s.IdEmpresa == empresaId && s.Ano == ano)
            .OrderBy(s => s.Nombre)
            .ToListAsync();

        var sociosDto = socios.Select(s => new SocioCapitalDto
        {
            IdSocio = s.IdSocio,
            Rut = s.RUT,
            Nombre = s.Nombre,
            MontoPagado = (decimal)(s.MontoPagado ?? 0),
            MontoIngresadoUsuario = (decimal)(s.MontoIngresadoUsuario ?? 0),
            MontoATraspasar = s.MontoATraspasar.HasValue && s.MontoATraspasar.Value != 0
                ? (decimal)s.MontoATraspasar.Value
                : (decimal)(s.MontoPagado ?? 0)
        }).ToList();

        var total = sociosDto.Sum(s => s.MontoATraspasar);

        return new CapitalAportadoDto
        {
            EmpresaId = empresaId,
            Ano = ano,
            Socios = sociosDto,
            TotalMontoATraspasar = total
        };
    }

    public async Task<bool> SaveCapitalAportadoAsync(SaveCapitalAportadoRequestDto request)
    {
        logger.LogInformation("Saving capital aportado for empresa {EmpresaId}, año {Ano}", 
            request.EmpresaId, request.Ano);

        {
            // Actualizar socios
            foreach (var socioDto in request.Socios)
            {
                var socio = await context.Socios
                    .Where(s => s.IdSocio == socioDto.IdSocio 
                        && s.IdEmpresa == request.EmpresaId 
                        && s.Ano == request.Ano)
                    .FirstOrDefaultAsync();

                if (socio != null)
                {
                    socio.MontoIngresadoUsuario = (double)socioDto.MontoIngresadoUsuario;
                    socio.MontoATraspasar = (double)socioDto.MontoATraspasar;
                }
            }

            // Calcular total
            var total = request.Socios.Sum(s => s.MontoATraspasar);

            // Actualizar EmpresasAno
            var empresaAno = await context.EmpresasAno
                .Where(e => e.idEmpresa == request.EmpresaId && e.Ano == request.Ano)
                .FirstOrDefaultAsync();

            if (empresaAno != null)
            {
                empresaAno.CPS_CapitalAportado = (double)total;
            }

            await context.SaveChangesAsync();

            logger.LogInformation("Successfully saved capital aportado. Total: {Total}", total);
            return true;
        }
    }
}
