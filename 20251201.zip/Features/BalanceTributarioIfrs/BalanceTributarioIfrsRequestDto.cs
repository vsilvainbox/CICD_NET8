using System.ComponentModel.DataAnnotations;

namespace App.Features.BalanceTributarioIfrs;

/// <summary>
/// Request DTO para generar el Balance Tributario IFRS (8 columnas).
/// </summary>
public class BalanceTributarioIfrsRequestDto
{
    /// <summary>
    /// Fecha inicial del período a analizar.
    /// </summary>
    [Required(ErrorMessage = "La fecha inicial es requerida")]
    [Display(Name = "Desde")]
    [DataType(DataType.Date)]
    public DateTime FechaDesde { get; set; }

    /// <summary>
    /// Fecha final del período a analizar.
    /// </summary>
    [Required(ErrorMessage = "La fecha final es requerida")]
    [Display(Name = "Hasta")]
    [DataType(DataType.Date)]
    public DateTime FechaHasta { get; set; }

    /// <summary>
    /// Nivel de profundidad de las cuentas a mostrar (1-5).
    /// </summary>
    [Required(ErrorMessage = "El nivel es requerido")]
    [Range(1, 5, ErrorMessage = "El nivel debe estar entre 1 y 5")]
    [Display(Name = "Nivel de cuentas")]
    public int Nivel { get; set; } = 2;

    /// <summary>
    /// ID del área de negocio para filtrar (opcional).
    /// </summary>
    [Display(Name = "Área de Negocio")]
    public int? IdAreaNegocio { get; set; }

    /// <summary>
    /// ID del centro de costo para filtrar (opcional).
    /// </summary>
    [Display(Name = "Centro de Gestión")]
    public int? IdCentroCosto { get; set; }

    /// <summary>
    /// Indica si se debe mostrar el código de cuenta IFRS.
    /// </summary>
    [Display(Name = "Ver Código Cuenta")]
    public bool VerCodigoCuenta { get; set; } = true;

    /// <summary>
    /// Indica si se debe incluir el membrete de la empresa en exportaciones.
    /// </summary>
    [Display(Name = "Incluir membrete empresa")]
    public bool IncluirMembreteEmpresa { get; set; } = false;
}
