using App.Data;
using Microsoft.EntityFrameworkCore;

namespace App.Features.BalanceTributarioIfrs;

/// <summary>
/// Implementación del servicio de Balance Tributario IFRS.
/// </summary>
public class BalanceTributarioIfrsService(
    LpContabContext context,
    ILogger<BalanceTributarioIfrsService> logger) : IBalanceTributarioIfrsService
{
    private const int ClasCtaActivo = 1;
    private const int ClasCtaPasivo = 2;
    private const int ClasCtaOrden = 3;
    private const int ClasCtaResultado = 4;
    private const int TipoAjusteFinanciero = 1;
    private const int TipoAjusteAmbos = 3;
    private const int EstadoAprobado = 1;

    public async Task<BalanceTributarioIfrsResponseDto> GenerarAsync(BalanceTributarioIfrsRequestDto request)
    {
        logger.LogInformation(
            "Generando Balance Tributario IFRS desde {FechaDesde} hasta {FechaHasta}, Nivel {Nivel}",
            request.FechaDesde, request.FechaHasta, request.Nivel);

        // Validar fechas
        if (request.FechaDesde > request.FechaHasta)
        {
            throw new ArgumentException("La fecha inicial no puede ser mayor que la fecha final");
        }

        // Convertir fechas a formato int (YYYYMMDD)
        int fechaDesdeInt = ConvertirFechaAEntero(request.FechaDesde);
        int fechaHastaInt = ConvertirFechaAEntero(request.FechaHasta);

        // Obtener nombres de filtros opcionales
        string? areaNegocio = null;
        string? centroCosto = null;

        if (request.IdAreaNegocio.HasValue)
        {
            areaNegocio = await context.AreaNegocio
                .Where(a => a.IdAreaNegocio == request.IdAreaNegocio.Value)
                .Select(a => a.Descripcion)
                .FirstOrDefaultAsync();
        }

        if (request.IdCentroCosto.HasValue)
        {
            centroCosto = await context.CentroCosto
                .Where(c => c.IdCCosto == request.IdCentroCosto.Value)
                .Select(c => c.Descripcion)
                .FirstOrDefaultAsync();
        }

        // Consulta principal: obtener movimientos agrupados por cuenta IFRS
        var movimientos = await ObtenerMovimientosIfrsAsync(request, fechaDesdeInt, fechaHastaInt);

        // Procesar datos jerárquicamente
        var cuentas = ProcesarJerarquiaIfrs(movimientos, request.Nivel);

        // Calcular totales
        var (subtotales, ajuste, totales, esUtilidad) = CalcularTotales(cuentas);

        var response = new BalanceTributarioIfrsResponseDto
        {
            Cuentas = cuentas,
            Subtotales = subtotales,
            Ajuste = ajuste,
            Totales = totales,
            EsUtilidad = esUtilidad,
            FechaDesde = request.FechaDesde,
            FechaHasta = request.FechaHasta,
            Nivel = request.Nivel,
            AreaNegocio = areaNegocio,
            CentroCosto = centroCosto
        };

        logger.LogInformation(
            "Balance Tributario IFRS generado con {CantidadCuentas} líneas",
            cuentas.Count);

        return response;
    }

    public async Task<(bool EsValido, string? PlanActual)> ValidarPlanCuentasAsync()
    {
        var planActual = await context.ParamEmpresa
            .Where(p => p.Tipo == "PLANCTAS")
            .Select(p => p.Valor)
            .FirstOrDefaultAsync();

        if (string.IsNullOrEmpty(planActual))
        {
            return (false, null);
        }

        var planesValidos = new[] { "BÁSICO", "INTERMEDIO", "AVANZADO", "IFRS" };
        var esValido = planesValidos.Contains(planActual.ToUpperInvariant());

        return (esValido, planActual);
    }

    public async Task<bool> ExistenCuentasSinClasificacionIfrsAsync(DateTime fechaHasta)
    {
        int fechaHastaInt = ConvertirFechaAEntero(fechaHasta);

        // Verificar si hay cuentas con saldo pero sin CodIFRS
        var cuentasSinClasificar = await context.Cuentas
            .Where(c => string.IsNullOrEmpty(c.CodIFRS))
            .Select(c => c.idCuenta)
            .Take(100)
            .ToListAsync();

        if (!cuentasSinClasificar.Any())
        {
            return false;
        }

        // Verificar si alguna tiene movimientos con saldo
        var tieneSaldo = await (
            from m in context.MovComprobante
            join c in context.Comprobante on m.IdComp equals c.IdComp
            where cuentasSinClasificar.Contains(m.IdCuenta ?? 0)
                && c.Fecha <= fechaHastaInt
                && c.Estado == EstadoAprobado
            group m by m.IdCuenta into g
            select new
            {
                IdCuenta = g.Key,
                Saldo = g.Sum(x => x.Debe ?? 0) - g.Sum(x => x.Haber ?? 0)
            }
        ).AnyAsync(x => x.Saldo != 0);

        return tieneSaldo;
    }

    private async Task<List<MovimientoIfrsDto>> ObtenerMovimientosIfrsAsync(
        BalanceTributarioIfrsRequestDto request,
        int fechaDesdeInt,
        int fechaHastaInt)
    {
        var query = from m in context.MovComprobante
                    join c in context.Comprobante on m.IdComp equals c.IdComp
                    join cta in context.Cuentas on m.IdCuenta equals cta.idCuenta
                    where c.Fecha >= fechaDesdeInt
                        && c.Fecha <= fechaHastaInt
                        && c.Estado == EstadoAprobado
                        && (c.TipoAjuste == null
                            || c.TipoAjuste == TipoAjusteFinanciero
                            || c.TipoAjuste == TipoAjusteAmbos)
                        && !string.IsNullOrEmpty(cta.CodIFRS)
                    select new { m, cta };

        // Filtros opcionales
        if (request.IdAreaNegocio.HasValue)
        {
            query = query.Where(x => x.m.idAreaNeg == request.IdAreaNegocio.Value);
        }

        if (request.IdCentroCosto.HasValue)
        {
            query = query.Where(x => x.m.idCCosto == request.IdCentroCosto.Value);
        }

        // Agrupar por código IFRS
        var movimientos = await query
            .GroupBy(x => new
            {
                CodIFRS = x.cta.CodIFRS,
                Descripcion = x.cta.Descripcion,
                IdCuenta = x.cta.idCuenta,
                Nivel = ObtenerNivelIfrs(x.cta.CodIFRS),
                Clasificacion = ObtenerClasificacionIfrs(x.cta.CodIFRS)
            })
            .Select(g => new MovimientoIfrsDto
            {
                IdCuenta = g.Key.IdCuenta,
                Codigo = g.Key.CodIFRS!,
                Descripcion = g.Key.Descripcion ?? "",
                Nivel = g.Key.Nivel,
                Clasificacion = g.Key.Clasificacion,
                Debe = (decimal)g.Sum(x => x.m.Debe ?? 0),
                Haber = (decimal)g.Sum(x => x.m.Haber ?? 0)
            })
            .OrderBy(m => m.Codigo)
            .ToListAsync();

        return movimientos;
    }

    private List<BalanceTributarioIfrsLineaDto> ProcesarJerarquiaIfrs(
        List<MovimientoIfrsDto> movimientos,
        int nivelSeleccionado)
    {
        var resultado = new List<BalanceTributarioIfrsLineaDto>();
        var totalesPorNivel = new Dictionary<int, TotalesNivel>();

        int nivelActual = 0;
        string? codigoActual = null;

        foreach (var mov in movimientos)
        {
            // Si el nivel disminuye, escribir totales de niveles superiores
            if (mov.Nivel < nivelActual)
            {
                for (int nivel = nivelActual - 1; nivel >= mov.Nivel; nivel--)
                {
                    if (totalesPorNivel.ContainsKey(nivel) && totalesPorNivel[nivel].LineaIndex >= 0)
                    {
                        var lineaTotal = resultado[totalesPorNivel[nivel].LineaIndex];
                        lineaTotal.Debitos = totalesPorNivel[nivel].Debitos;
                        lineaTotal.Creditos = totalesPorNivel[nivel].Creditos;

                        totalesPorNivel[nivel] = new TotalesNivel();
                    }
                }
            }

            // Agregar nueva cuenta
            if (codigoActual != mov.Codigo)
            {
                // Si había una cuenta anterior del mismo nivel, guardar sus totales
                if (!string.IsNullOrEmpty(codigoActual) && nivelActual == mov.Nivel)
                {
                    if (totalesPorNivel.ContainsKey(nivelActual) && totalesPorNivel[nivelActual].LineaIndex >= 0)
                    {
                        var lineaAnterior = resultado[totalesPorNivel[nivelActual].LineaIndex];
                        lineaAnterior.Debitos = totalesPorNivel[nivelActual].Debitos;
                        lineaAnterior.Creditos = totalesPorNivel[nivelActual].Creditos;
                    }
                }

                nivelActual = mov.Nivel;
                codigoActual = mov.Codigo;

                var linea = new BalanceTributarioIfrsLineaDto
                {
                    IdCuenta = mov.IdCuenta,
                    Codigo = mov.Codigo,
                    Cuenta = mov.Descripcion,
                    Nivel = mov.Nivel,
                    Clasificacion = mov.Clasificacion.ToString(),
                    MostrarNegrita = false
                };

                resultado.Add(linea);

                if (!totalesPorNivel.ContainsKey(nivelActual))
                {
                    totalesPorNivel[nivelActual] = new TotalesNivel();
                }

                totalesPorNivel[nivelActual].Debitos = 0;
                totalesPorNivel[nivelActual].Creditos = 0;
                totalesPorNivel[nivelActual].LineaIndex = resultado.Count - 1;
            }

            // Sumar a los totales de este nivel y niveles superiores
            for (int nivel = nivelActual; nivel >= 1; nivel--)
            {
                if (!totalesPorNivel.ContainsKey(nivel))
                {
                    totalesPorNivel[nivel] = new TotalesNivel();
                }

                totalesPorNivel[nivel].Debitos += mov.Debe;
                totalesPorNivel[nivel].Creditos += mov.Haber;
            }
        }

        // Escribir totales de la última cuenta
        if (codigoActual != null && totalesPorNivel.ContainsKey(nivelActual))
        {
            var lineaFinal = resultado[totalesPorNivel[nivelActual].LineaIndex];
            lineaFinal.Debitos = totalesPorNivel[nivelActual].Debitos;
            lineaFinal.Creditos = totalesPorNivel[nivelActual].Creditos;

            // Escribir totales hacia arriba
            for (int nivel = nivelActual - 1; nivel >= 1; nivel--)
            {
                if (totalesPorNivel.ContainsKey(nivel) && totalesPorNivel[nivel].LineaIndex >= 0)
                {
                    var lineaTotalNivel = resultado[totalesPorNivel[nivel].LineaIndex];
                    lineaTotalNivel.Debitos = totalesPorNivel[nivel].Debitos;
                    lineaTotalNivel.Creditos = totalesPorNivel[nivel].Creditos;
                }
            }
        }

        // Calcular saldos y clasificar en columnas
        var cuentasVisibles = new List<BalanceTributarioIfrsLineaDto>();

        foreach (var linea in resultado)
        {
            var diferencia = linea.Debitos - linea.Creditos;

            if (diferencia > 0)
            {
                linea.SaldoDeudor = diferencia;
            }
            else
            {
                linea.SaldoAcreedor = Math.Abs(diferencia);
            }

            // Clasificar en columnas de Inventario o Resultado
            var clasif = int.TryParse(linea.Clasificacion, out int clasifInt) ? clasifInt : 0;

            switch (clasif)
            {
                case ClasCtaActivo:
                case ClasCtaPasivo:
                case ClasCtaOrden:
                    if (linea.SaldoDeudor > 0)
                    {
                        linea.InventarioActivo = linea.SaldoDeudor;
                    }
                    else
                    {
                        linea.InventarioPasivo = linea.SaldoAcreedor;
                    }
                    break;

                case ClasCtaResultado:
                    if (linea.SaldoDeudor > 0)
                    {
                        linea.ResultadoPerdida = linea.SaldoDeudor;
                    }
                    else
                    {
                        linea.ResultadoGanancia = linea.SaldoAcreedor;
                    }
                    break;
            }

            // Solo mostrar cuentas del nivel seleccionado y con movimiento
            if (linea.Nivel == nivelSeleccionado && (linea.Debitos != 0 || linea.Creditos != 0))
            {
                cuentasVisibles.Add(linea);
            }
        }

        return cuentasVisibles;
    }

    private (BalanceTributarioIfrsLineaDto Subtotales,
             BalanceTributarioIfrsLineaDto Ajuste,
             BalanceTributarioIfrsLineaDto Totales,
             bool EsUtilidad) CalcularTotales(List<BalanceTributarioIfrsLineaDto> cuentas)
    {
        // Calcular subtotales
        var subtotales = new BalanceTributarioIfrsLineaDto
        {
            Cuenta = "Sub Total",
            EsTotal = true,
            MostrarNegrita = true,
            Debitos = cuentas.Sum(c => c.Debitos),
            Creditos = cuentas.Sum(c => c.Creditos),
            SaldoDeudor = cuentas.Sum(c => c.SaldoDeudor),
            SaldoAcreedor = cuentas.Sum(c => c.SaldoAcreedor),
            InventarioActivo = cuentas.Sum(c => c.InventarioActivo),
            InventarioPasivo = cuentas.Sum(c => c.InventarioPasivo),
            ResultadoPerdida = cuentas.Sum(c => c.ResultadoPerdida),
            ResultadoGanancia = cuentas.Sum(c => c.ResultadoGanancia)
        };

        // Calcular ajuste (diferencias para cuadrar)
        var ajuste = new BalanceTributarioIfrsLineaDto
        {
            EsTotal = true,
            MostrarNegrita = true
        };

        // Diferencia Débitos - Créditos
        var diffDebitoCredito = subtotales.Debitos - subtotales.Creditos;
        if (diffDebitoCredito < 0)
        {
            ajuste.Debitos = Math.Abs(diffDebitoCredito);
        }
        else
        {
            ajuste.Creditos = Math.Abs(diffDebitoCredito);
        }

        // Diferencia Deudor - Acreedor
        var diffDeudorAcreedor = subtotales.SaldoDeudor - subtotales.SaldoAcreedor;
        if (diffDeudorAcreedor < 0)
        {
            ajuste.SaldoDeudor = Math.Abs(diffDeudorAcreedor);
        }
        else
        {
            ajuste.SaldoAcreedor = Math.Abs(diffDeudorAcreedor);
        }

        // Diferencia Inventario Activo - Pasivo
        var diffInventario = subtotales.InventarioActivo - subtotales.InventarioPasivo;
        if (diffInventario < 0)
        {
            ajuste.InventarioActivo = Math.Abs(diffInventario);
        }
        else
        {
            ajuste.InventarioPasivo = Math.Abs(diffInventario);
        }

        // Diferencia Pérdida - Ganancia (determina Utilidad o Pérdida)
        var diffResultado = subtotales.ResultadoPerdida - subtotales.ResultadoGanancia;
        bool esUtilidad;

        if (diffResultado < 0)
        {
            ajuste.ResultadoPerdida = Math.Abs(diffResultado);
            ajuste.Cuenta = "Utilidad";
            esUtilidad = true;
        }
        else
        {
            ajuste.ResultadoGanancia = Math.Abs(diffResultado);
            ajuste.Cuenta = diffResultado == 0 ? "Utilidad" : "Pérdida";
            esUtilidad = diffResultado == 0;
        }

        // Calcular totales finales (Subtotal + Ajuste)
        var totales = new BalanceTributarioIfrsLineaDto
        {
            Cuenta = "TOTALES",
            EsTotal = true,
            MostrarNegrita = true,
            Debitos = subtotales.Debitos + ajuste.Debitos,
            Creditos = subtotales.Creditos + ajuste.Creditos,
            SaldoDeudor = subtotales.SaldoDeudor + ajuste.SaldoDeudor,
            SaldoAcreedor = subtotales.SaldoAcreedor + ajuste.SaldoAcreedor,
            InventarioActivo = subtotales.InventarioActivo + ajuste.InventarioActivo,
            InventarioPasivo = subtotales.InventarioPasivo + ajuste.InventarioPasivo,
            ResultadoPerdida = subtotales.ResultadoPerdida + ajuste.ResultadoPerdida,
            ResultadoGanancia = subtotales.ResultadoGanancia + ajuste.ResultadoGanancia
        };

        return (subtotales, ajuste, totales, esUtilidad);
    }

    private static int ObtenerNivelIfrs(string? codigoIfrs)
    {
        if (string.IsNullOrEmpty(codigoIfrs))
        {
            return 0;
        }

        // Eliminar puntos y contar dígitos para determinar nivel
        var sinPuntos = codigoIfrs.Replace(".", "").Replace("-", "");

        return sinPuntos.Length switch
        {
            1 => 1,
            2 => 2,
            4 => 3,
            6 => 4,
            _ => 5
        };
    }

    private static int ObtenerClasificacionIfrs(string? codigoIfrs)
    {
        if (string.IsNullOrEmpty(codigoIfrs))
        {
            return 0;
        }

        // La clasificación se determina por el primer dígito
        var primerDigito = codigoIfrs[0];

        return primerDigito switch
        {
            '1' => ClasCtaActivo,
            '2' => ClasCtaPasivo,
            '3' => ClasCtaOrden,
            '4' or '5' => ClasCtaResultado,
            _ => 0
        };
    }

    public async Task<List<Shared.ComboItemDto>> ObtenerAreasNegocioAsync()
    {
        var items = await context.AreaNegocio
            .OrderBy(a => a.Descripcion)
            .Select(a => new Shared.ComboItemDto
            {
                Value = a.IdAreaNegocio,
                Text = a.Descripcion ?? ""
            })
            .ToListAsync();

        items.Insert(0, new Shared.ComboItemDto { Value = 0, Text = "-- Todas --" });
        return items;
    }

    public async Task<List<Shared.ComboItemDto>> ObtenerCentrosCostoAsync()
    {
        var items = await context.CentroCosto
            .OrderBy(c => c.Descripcion)
            .Select(c => new Shared.ComboItemDto
            {
                Value = c.IdCCosto,
                Text = c.Descripcion ?? ""
            })
            .ToListAsync();

        items.Insert(0, new Shared.ComboItemDto { Value = 0, Text = "-- Todos --" });
        return items;
    }

    /// <summary>
    /// Genera un archivo PDF con el Balance Tributario IFRS.
    /// </summary>
    /// <param name="request">Los filtros y parámetros para generar el balance</param>
    /// <param name="incluirMembrete">Si debe incluir el membrete de la empresa</param>
    /// <returns>Byte array con el contenido del PDF</returns>
    public async Task<byte[]> ExportarPdfAsync(BalanceTributarioIfrsRequestDto request, bool incluirMembrete = true)
    {
        logger.LogInformation("[BalanceTributarioIfrs] Generando PDF - FechaDesde: {FechaDesde}, FechaHasta: {FechaHasta}, Nivel: {Nivel}, Membrete: {Membrete}",
            request.FechaDesde, request.FechaHasta, request.Nivel, incluirMembrete);

        // TODO: [FEATURE] [BAJA] Implementar generación de PDF server-side
        // Librerías recomendadas:
        // - QuestPDF (moderna, fluent API, MIT license)
        // - iTextSharp 7+ (robusta, comercial/AGPL)
        // - DinkToPdf (convierte HTML a PDF usando wkhtmltopdf)
        //
        // Implementación sugerida:
        // 1. Generar el balance con GenerarAsync()
        // 2. Crear PDF con tabla de 8 columnas + totales
        // 3. Incluir membrete si incluirMembrete == true (Logo, RUT, Razón Social, Dirección)
        // 4. Incluir fecha de generación, filtros aplicados
        // 5. Formato: Landscape para mejor visualización de 8 columnas
        // 6. Headers con merge (colspan) como en la vista HTML
        //
        // Por ahora: window.print() en el cliente cubre el 90% de casos de uso

        await Task.CompletedTask; // Evitar warning de async sin await

        return Array.Empty<byte>();
    }

    /// <summary>
    /// Convierte DateTime a int en formato OLE/Excel.
    /// </summary>
    private static int ConvertirFechaAEntero(DateTime fecha)
    {
        return (int)fecha.ToOADate();
    }

    private class MovimientoIfrsDto
    {
        public long IdCuenta { get; set; }
        public string Codigo { get; set; } = string.Empty;
        public string Descripcion { get; set; } = string.Empty;
        public int Nivel { get; set; }
        public int Clasificacion { get; set; }
        public decimal Debe { get; set; }
        public decimal Haber { get; set; }
    }

    private class TotalesNivel
    {
        public decimal Debitos { get; set; }
        public decimal Creditos { get; set; }
        public int LineaIndex { get; set; } = -1;
    }
}
