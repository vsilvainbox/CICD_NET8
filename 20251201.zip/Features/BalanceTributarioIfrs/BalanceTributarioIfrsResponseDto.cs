namespace App.Features.BalanceTributarioIfrs;

/// <summary>
/// Response DTO para el Balance Tributario IFRS (8 columnas).
/// </summary>
public class BalanceTributarioIfrsResponseDto
{
    /// <summary>
    /// Líneas del balance (cuentas y subtotales).
    /// </summary>
    public List<BalanceTributarioIfrsLineaDto> Cuentas { get; set; } = new();

    /// <summary>
    /// Línea de subtotales.
    /// </summary>
    public BalanceTributarioIfrsLineaDto? Subtotales { get; set; }

    /// <summary>
    /// Línea de ajuste (utilidad o pérdida).
    /// </summary>
    public BalanceTributarioIfrsLineaDto? Ajuste { get; set; }

    /// <summary>
    /// Línea de totales finales.
    /// </summary>
    public BalanceTributarioIfrsLineaDto? Totales { get; set; }

    /// <summary>
    /// Indica si el ajuste es utilidad (true) o pérdida (false).
    /// </summary>
    public bool EsUtilidad { get; set; }

    /// <summary>
    /// Fecha inicial del período consultado.
    /// </summary>
    public DateTime FechaDesde { get; set; }

    /// <summary>
    /// Fecha final del período consultado.
    /// </summary>
    public DateTime FechaHasta { get; set; }

    /// <summary>
    /// Nivel de cuentas utilizado.
    /// </summary>
    public int Nivel { get; set; }

    /// <summary>
    /// Nombre del área de negocio (si se filtró).
    /// </summary>
    public string? AreaNegocio { get; set; }

    /// <summary>
    /// Nombre del centro de costo (si se filtró).
    /// </summary>
    public string? CentroCosto { get; set; }
}
