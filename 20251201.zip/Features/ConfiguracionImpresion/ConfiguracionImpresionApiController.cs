using Microsoft.AspNetCore.Mvc;

namespace App.Features.ConfiguracionImpresion;

/// <summary>
/// API Controller para la configuraciÃ³n de impresiÃ³n
/// </summary>
[ApiController]
[Route("[controller]/[action]")]
public class ConfiguracionImpresionApiController(
    IConfiguracionImpresionService service,
    ILogger<ConfiguracionImpresionApiController> logger) : ControllerBase
{
    /// <summary>
    /// Obtiene la configuraciÃ³n de impresiÃ³n por defecto o guardada
    /// GET: api/ConfiguracionImpresion/configuracion
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<ConfiguracionImpresionDto>> GetConfiguracion()
    {
        {
            logger.LogInformation("GET api/ConfiguracionImpresion/configuracion - Obteniendo configuraciÃ³n");
            
            var configuracion = await service.GetConfiguracionDefaultAsync();
            
            return Ok(configuracion);
        }
    }

    /// <summary>
    /// Valida los privilegios del usuario para opciones de impresiÃ³n
    /// GET: api/ConfiguracionImpresion/privilegios
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<PrivilegiosImpresionDto>> GetPrivilegios()
    {
        {
            logger.LogInformation("GET api/ConfiguracionImpresion/privilegios - Obteniendo privilegios");
            
            var privilegios = await service.ValidarPrivilegiosUsuarioAsync();
            
            return Ok(privilegios);
        }
    }

    /// <summary>
    /// Guarda la configuraciÃ³n de impresiÃ³n seleccionada
    /// POST: api/ConfiguracionImpresion/configuracion
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<ResultadoConfiguracionDto>> SaveConfiguracion(
        [FromBody] ConfiguracionImpresionDto configuracion)
    {
        {
            logger.LogInformation("POST api/ConfiguracionImpresion/configuracion - Guardando configuraciÃ³n");
            
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var resultado = await service.GuardarConfiguracionAsync(configuracion);
            
            if (!resultado.Exitoso)
            {
                return BadRequest(resultado);
            }

            return Ok(resultado);
        }
    }
}
