namespace App.Features.ConfiguracionImpresion;

/// <summary>
/// Interfaz del servicio para gestionar la configuración de impresión
/// </summary>
public interface IConfiguracionImpresionService
{
    /// <summary>
    /// Obtiene la configuración de impresión por defecto o la última usada por el usuario
    /// </summary>
    /// <returns>Configuración de impresión</returns>
    Task<ConfiguracionImpresionDto> GetConfiguracionDefaultAsync();

    /// <summary>
    /// Valida los privilegios del usuario actual para opciones de impresión
    /// </summary>
    /// <returns>DTO con información de privilegios</returns>
    Task<PrivilegiosImpresionDto> ValidarPrivilegiosUsuarioAsync();

    /// <summary>
    /// Guarda la configuración de impresión seleccionada por el usuario
    /// para uso futuro (preferencias)
    /// </summary>
    /// <param name="configuracion">Configuración a guardar</param>
    /// <returns>Resultado de la operación</returns>
    Task<ResultadoConfiguracionDto> GuardarConfiguracionAsync(ConfiguracionImpresionDto configuracion);

    /// <summary>
    /// Obtiene la configuración de impresión guardada para el usuario actual
    /// </summary>
    /// <returns>Configuración guardada o null si no existe</returns>
    Task<ConfiguracionImpresionDto?> GetConfiguracionGuardadaAsync();
}
