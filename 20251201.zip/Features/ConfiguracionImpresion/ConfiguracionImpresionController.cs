using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using App.Extensions;

namespace App.Features.ConfiguracionImpresion;

/// <summary>
/// Controlador MVC para la configuración de impresión
/// </summary>
[Authorize]

public class ConfiguracionImpresionController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<ConfiguracionImpresionController> logger) : Controller
{
    /// <summary>
    /// Muestra la vista de configuración de impresión
    /// GET: /ConfiguracionImpresion
    /// </summary>
    public async Task<IActionResult> Index()
    {
        logger.LogInformation("Mostrando vista de configuración de impresión");

        ViewData["Title"] = "Configuración de Impresión";

        // Cargar configuración actual
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionImpresionApiController>(
            HttpContext,
            nameof(ConfiguracionImpresionApiController.GetConfiguracion));
        var config = await client.GetFromApiAsync<ConfiguracionImpresionDto>(url!) ?? new ConfiguracionImpresionDto();

        // Cargar privilegios
        var urlPriv = linkGenerator.GetApiUrl<ConfiguracionImpresionApiController>(
            HttpContext,
            nameof(ConfiguracionImpresionApiController.GetPrivilegios));
        var privilegios = await client.GetFromApiAsync<PrivilegiosImpresionDto>(urlPriv!);
        ViewBag.Privilegios = privilegios;

        return View(config);
    }

    /// <summary>
    /// Proxy: Obtiene la configuración de impresión actual
    /// GET: /ConfiguracionImpresion/GetConfiguracion
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetConfiguracion()
    {
        logger.LogInformation("Proxy MVC: Obteniendo configuración de impresión");

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionImpresionApiController>(
            HttpContext,
            nameof(ConfiguracionImpresionApiController.GetConfiguracion));
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Proxy: Valida privilegios del usuario para impresión
    /// GET: /ConfiguracionImpresion/GetPrivilegios
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetPrivilegios()
    {
        logger.LogInformation("Proxy MVC: Obteniendo privilegios de impresión");

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionImpresionApiController>(
            HttpContext,
            nameof(ConfiguracionImpresionApiController.GetPrivilegios));
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Guarda la configuración de impresión usando PRG pattern
    /// POST: /ConfiguracionImpresion/SaveConfiguracion
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> SaveConfiguracion(ConfiguracionImpresionDto config)
    {
        if (!ModelState.IsValid)
        {
            return View("Index", config);
        }

        logger.LogInformation("Guardando configuración de impresión");

        try
        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ConfiguracionImpresionApiController>(
                HttpContext,
                nameof(ConfiguracionImpresionApiController.SaveConfiguracion));
            await client.PostToApiAsync<ConfiguracionImpresionDto, object>(url!, config);

            TempData["Success"] = "Configuración de impresión guardada correctamente";
            return RedirectToAction(nameof(Index));
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error al guardar configuración de impresión");
            ModelState.AddModelError("", ex.Message);
            return View("Index", config);
        }
    }
}
