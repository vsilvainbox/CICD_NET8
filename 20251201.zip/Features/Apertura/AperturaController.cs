﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.Apertura;

public class AperturaController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<AperturaController> logger) : Controller
{
    /// <summary>
    /// Main view for apertura (opening entry generation)
    /// Loads initial data server-side instead of AJAX call
    /// </summary>
    /// <returns>Apertura view with populated ViewModel</returns>
    public async Task<IActionResult> Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Apertura";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        logger.LogInformation("Loading Apertura index for empresaId: {EmpresaId}, ano: {Ano}",
            SessionHelper.EmpresaId, SessionHelper.Ano);

        ViewData["Title"] = $"Apertura - año {SessionHelper.Ano}";

        // Load initial data server-side
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<AperturaApiController>(
            HttpContext,
            nameof(AperturaApiController.Init),
            new { empresaId = SessionHelper.EmpresaId, ano = SessionHelper.Ano }
        );

        var initData = await client.GetFromApiAsync<AperturaInitDataDto>(url!);

        // Map to ViewModel (server-side state management)
        var model = new AperturaViewModel
        {
            EmpresaId = initData.EmpresaId,
            Ano = initData.Ano,
            NombreEmpresa = initData.NombreEmpresa,
            NumCompAper = initData.NumCompAper,
            IdCompAper = initData.IdCompAper,
            OpeningEntryExists = initData.OpeningEntryExists,
            WarningMessage = initData.WarningMessage,
            IdCuentaResul = initData.IdCuentaResul ?? 0,
            DescCuentaResul = initData.DescCuentaResul,
            IdCuentaCredIVA = initData.IdCuentaCredIVA ?? 0,
            DescCuentaCredIVA = initData.DescCuentaCredIVA,
            RemIVAUTM = initData.RemIVAUTM,
            RemIVAReadOnly = initData.RemIVAReadOnly,
            RemIVASource = initData.RemIVASource,
            HasPreviousYear = initData.HasPreviousYear
        };

        return View(model);
    }

    /// <summary>
    /// Proxy method: Get initial data for apertura form
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Init(int empresaId, short ano)
    {
        logger.LogInformation("MVC Proxy: Init - empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AperturaApiController>(
            HttpContext,
            nameof(AperturaApiController.Init),
            new { empresaId, ano }
        );
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Get accounts by type and return as Partial View (HTML)
    /// Eliminates JSON.stringify and innerHTML patterns
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetAccounts(int empresaId, short ano, string type, string? searchTerm = null)
    {
        logger.LogInformation("MVC: GetAccounts - empresaId: {EmpresaId}, ano: {Ano}, type: {Type}, search: {Search}",
            empresaId, ano, type, searchTerm);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AperturaApiController>(
            HttpContext,
            nameof(AperturaApiController.GetAccounts),
            new { empresaId, ano, type }
        );
        var accounts = await client.GetFromApiAsync<List<AccountDto>>(url!);

        // Create ViewModel for partial view
        var searchMode = type == "patrimonio" ? "result" : "iva";
        var modalTitle = type == "patrimonio"
            ? "Seleccionar Cuenta de Resultado"
            : "Seleccionar Cuenta de Crédito IVA";

        var viewModel = new AccountSearchViewModel
        {
            SearchMode = searchMode,
            ModalTitle = modalTitle,
            Accounts = accounts,
            SearchTerm = searchTerm ?? string.Empty
        };

        // Return server-rendered HTML instead of JSON
        return PartialView("_BusquedaCuentas", viewModel);
    }

    /// <summary>
    /// Legacy endpoint for backward compatibility (returns JSON)
    /// New code should use GetAccounts which returns HTML
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetAccountsJson(int empresaId, short ano, string type)
    {
        logger.LogInformation("MVC Proxy (Legacy): GetAccountsJson - empresaId: {EmpresaId}, ano: {Ano}, type: {Type}",
            empresaId, ano, type);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AperturaApiController>(
            HttpContext,
            nameof(AperturaApiController.GetAccounts),
            new { empresaId, ano, type }
        );
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Execute apertura (opening entry) with automatic model validation
    /// Eliminates JSON.stringify - uses Model Binding instead
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Execute(AperturaViewModel model)
    {
        logger.LogInformation("MVC: Execute apertura - empresaId: {EmpresaId}, ano: {Ano}",
            model.EmpresaId, model.Ano);

        // Model validation is automatic via DataAnnotations
        if (!ModelState.IsValid)
        {
            var errors = ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage)
                .ToList();

            return BadRequest(new
            {
                success = false,
                message = "Error de validación",
                errors = errors
            });
        }

        var client = httpClientFactory.CreateClient();

        // Map ViewModel to DTO for API
        var request = new AperturaRequestDto
        {
            EmpresaId = model.EmpresaId,
            Ano = model.Ano,
            NumCompAper = model.NumCompAper,
            IdCuentaResul = model.IdCuentaResul,
            IdCuentaCredIVA = model.IdCuentaCredIVA,
            RemIVAUTM = model.RemIVAUTM
        };

        var url = linkGenerator.GetApiUrl<AperturaApiController>(
            HttpContext,
            nameof(AperturaApiController.Execute)
        );

        var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }

    /// <summary>
    /// Legacy execute method using JSON body (for backward compatibility)
    /// New code should use Execute(AperturaViewModel) with model binding
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> ExecuteJson([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy (Legacy): Execute apertura via JSON");

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AperturaApiController>(
            HttpContext,
            nameof(AperturaApiController.Execute)
        );
        var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }
}