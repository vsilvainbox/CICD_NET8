using App.Data;
using App.Exceptions;
using Microsoft.EntityFrameworkCore;

namespace App.Features.ConfiguracionCorreccionComprobantes;

/// <summary>
/// Servicio para gestionar la configuración de comprobantes contables
/// </summary>
public class ConfiguracionCorreccionComprobantesService(
    LpContabContext context,
    ILogger<ConfiguracionCorreccionComprobantesService> logger) : IConfiguracionCorreccionComprobantesService
{
    // Constantes - Tipo Correlativo
    private const int TCC_UNICO = 1;
    private const int TCC_TIPOCOMP = 2;
    
    // Constantes - Período Correlativo
    private const int TCC_MENSUAL = 1;
    private const int TCC_ANUAL = 2;
    private const int TCC_CONTINUO = 3;
    
    // Constantes - Estado Comprobante
    private const int EC_PENDIENTE = 1;
    private const int EC_APROBADO = 2;
    
    // Constantes - Tipo Comprobante (VB6: HyperComun.bas:300)
    private const int TC_APERTURA = 4;
    
    // Constantes - Opción Impresión Detalle
    private const int PRTMOV_DESC = 1;
    private const int PRTMOV_ENTIDAD = 2;
    private const int PRTMOV_CCOSTO = 3;
    private const int PRTMOV_AREANEG = 4;
    
    // Constantes - Fecha Comprobante Centralización
    private const int DTCOMPCENT_CURRDEF = 1;
    private const int DTCOMPCENT_LASTDAY = 2;
    private const int DTCOMPCENT_DEFDAY = 3;
    
    // Tipos de parámetros en ParamEmpresa
    private const string PARAM_TCORRCOMP = "TCORRCOMP";
    private const string PARAM_PCORRCOMP = "PCORRCOMP";
    private const string PARAM_ESTADOCOMP = "ESTADOCOMP";
    private const string PARAM_MESPARALEL = "MESPARALEL";
    private const string PARAM_VERCOMPANU = "VERCOMPANU";
    private const string PARAM_PRTMOVDET = "PRTMOVDET";
    private const string PARAM_IMPRESCENT = "IMPRESCENT";
    private const string PARAM_DTCOMPCENT = "DTCOMPCENT";
    private const string PARAM_DYCOMPCENT = "DYCOMPCENT";
    private const string PARAM_TITTIPCOMP = "TITTIPCOMP";

    /// <summary>
    /// Obtiene la configuración actual de comprobantes
    /// </summary>
    public async Task<ConfiguracionCorreccionComprobantesDto> GetConfiguracionAsync(int empresaId, short ano)
    {
        logger.LogInformation("Obteniendo configuración de comprobantes para EmpresaId={EmpresaId}, Ano={Ano}", empresaId, ano);
        
        {
            // Cargar todos los parámetros de la empresa
            var parametros = await context.ParamEmpresa
                .Where(p => p.IdEmpresa == empresaId && p.Ano == ano)
                .ToListAsync();
            
            // Verificar si se permite modificar correlativo (no hay comprobantes excepto apertura)
            var existenComprobantes = await context.Comprobante
                .AnyAsync(c => c.IdEmpresa == empresaId && 
                              c.Ano == ano && 
                              c.Tipo != TC_APERTURA);
            
            // TODO: Verificar funcionalidad comprobantes resumidos (gFunciones.ComprobanteResumido)
            // Por ahora asumimos que siempre está disponible
            var funcionalidadResumidosDisponible = true;
            
            var config = new ConfiguracionCorreccionComprobantesDto
            {
                EmpresaId = empresaId,
                Ano = ano,
                
                // Valores predeterminados
                TipoCorrelativo = TCC_UNICO,
                PeriodoCorrelativo = TCC_ANUAL,
                ComprobanteAprobadoAutomaticamente = false,
                PermitirAbrirMesesParalelo = false,
                MostrarComprobantesAnuladosEnLibroDiario = false,
                OpcionImpresionDetalleMovimiento = PRTMOV_DESC,
                ImprimirResumidoCentralizacion = false,
                IncluirTipoComprobanteEnTitulo = false,
                OpcionFechaCentralizacion = DTCOMPCENT_CURRDEF,
                DiaEspecificoCentralizacion = null,
                
                // Estado
                PermiteModificarCorrelativo = !existenComprobantes,
                FuncionalidadComprobantesResumidosDisponible = funcionalidadResumidosDisponible
            };
            
            // Cargar valores desde ParamEmpresa
            foreach (var param in parametros)
            {
                if (string.IsNullOrEmpty(param.Tipo) || string.IsNullOrEmpty(param.Valor))
                    continue;
                
                switch (param.Tipo)
                {
                    case PARAM_TCORRCOMP:
                        if (int.TryParse(param.Valor, out int tipoCorr))
                            config.TipoCorrelativo = tipoCorr;
                        break;
                    
                    case PARAM_PCORRCOMP:
                        if (int.TryParse(param.Valor, out int perCorr))
                            config.PeriodoCorrelativo = perCorr;
                        break;
                    
                    case PARAM_ESTADOCOMP:
                        if (int.TryParse(param.Valor, out int estado))
                            config.ComprobanteAprobadoAutomaticamente = (estado == EC_APROBADO);
                        break;
                    
                    case PARAM_MESPARALEL:
                        if (int.TryParse(param.Valor, out int mesParalel))
                            config.PermitirAbrirMesesParalelo = (mesParalel != 0);
                        break;
                    
                    case PARAM_VERCOMPANU:
                        if (int.TryParse(param.Valor, out int verCompAnu))
                            config.MostrarComprobantesAnuladosEnLibroDiario = (verCompAnu != 0);
                        break;
                    
                    case PARAM_PRTMOVDET:
                        if (int.TryParse(param.Valor, out int prtMovDet))
                            config.OpcionImpresionDetalleMovimiento = prtMovDet;
                        break;
                    
                    case PARAM_IMPRESCENT:
                        if (int.TryParse(param.Valor, out int impResCent))
                            config.ImprimirResumidoCentralizacion = (impResCent != 0);
                        break;
                    
                    case PARAM_DTCOMPCENT:
                        if (int.TryParse(param.Valor, out int dtCompCent))
                            config.OpcionFechaCentralizacion = dtCompCent;
                        break;
                    
                    case PARAM_DYCOMPCENT:
                        if (int.TryParse(param.Valor, out int dyCompCent))
                            config.DiaEspecificoCentralizacion = dyCompCent;
                        break;
                    
                    case PARAM_TITTIPCOMP:
                        if (int.TryParse(param.Valor, out int titTipComp))
                            config.IncluirTipoComprobanteEnTitulo = (titTipComp != 0);
                        break;
                }
            }
            
            logger.LogInformation("Configuración obtenida exitosamente");
            return config;
        }
    }
    
    /// <summary>
    /// Actualiza la configuración de comprobantes
    /// </summary>
    public async Task<bool> ActualizarConfiguracionAsync(ActualizarConfiguracionCorreccionComprobantesDto dto)
    {
        logger.LogInformation("Actualizando configuración de comprobantes para EmpresaId={EmpresaId}, Ano={Ano}", 
            dto.EmpresaId, dto.Ano);
        
        {
            // Validar si se puede cambiar el correlativo
            var configActual = await GetConfiguracionAsync(dto.EmpresaId, dto.Ano);
            
            if (!configActual.PermiteModificarCorrelativo &&
                (configActual.TipoCorrelativo != dto.TipoCorrelativo ||
                 configActual.PeriodoCorrelativo != dto.PeriodoCorrelativo))
            {
                logger.LogWarning("Intento de cambiar correlativo con comprobantes existentes");
                throw new BusinessException(
                    "No es posible cambiar el tipo de correlativo de los comprobantes, hay comprobantes ya ingresados.");
            }
            
            // Validar día específico si aplica
            if (dto.OpcionFechaCentralizacion == DTCOMPCENT_DEFDAY)
            {
                if (!dto.DiaEspecificoCentralizacion.HasValue ||
                    dto.DiaEspecificoCentralizacion.Value < 1 ||
                    dto.DiaEspecificoCentralizacion.Value > 30)
                {
                    throw new BusinessException(
                        "Día del mes asignado para fecha de comprobante de centralización inválido. Debe estar entre 1 y 30.");
                }
            }
            
            using var transaction = await context.Database.BeginTransactionAsync();
            
            {
                // Actualizar cada parámetro
                await UpsertParametroAsync(dto.EmpresaId, dto.Ano, PARAM_TCORRCOMP, dto.TipoCorrelativo.ToString());
                await UpsertParametroAsync(dto.EmpresaId, dto.Ano, PARAM_PCORRCOMP, dto.PeriodoCorrelativo.ToString());
                
                var estadoComprobante = dto.ComprobanteAprobadoAutomaticamente ? EC_APROBADO : EC_PENDIENTE;
                await UpsertParametroAsync(dto.EmpresaId, dto.Ano, PARAM_ESTADOCOMP, estadoComprobante.ToString());
                
                await UpsertParametroAsync(dto.EmpresaId, dto.Ano, PARAM_MESPARALEL, 
                    dto.PermitirAbrirMesesParalelo ? "1" : "0");
                
                await UpsertParametroAsync(dto.EmpresaId, dto.Ano, PARAM_VERCOMPANU, 
                    dto.MostrarComprobantesAnuladosEnLibroDiario ? "1" : "0");
                
                await UpsertParametroAsync(dto.EmpresaId, dto.Ano, PARAM_PRTMOVDET, 
                    dto.OpcionImpresionDetalleMovimiento.ToString());
                
                await UpsertParametroAsync(dto.EmpresaId, dto.Ano, PARAM_IMPRESCENT, 
                    dto.ImprimirResumidoCentralizacion ? "1" : "0");
                
                await UpsertParametroAsync(dto.EmpresaId, dto.Ano, PARAM_DTCOMPCENT, 
                    dto.OpcionFechaCentralizacion.ToString());
                
                var diaEspecifico = dto.DiaEspecificoCentralizacion?.ToString() ?? "0";
                await UpsertParametroAsync(dto.EmpresaId, dto.Ano, PARAM_DYCOMPCENT, diaEspecifico);
                
                await UpsertParametroAsync(dto.EmpresaId, dto.Ano, PARAM_TITTIPCOMP, 
                    dto.IncluirTipoComprobanteEnTitulo ? "1" : "0");
                
                await context.SaveChangesAsync();
                await transaction.CommitAsync();
                
                logger.LogInformation("Configuración actualizada exitosamente");
                return true;
            }
        }
    }
    
    /// <summary>
    /// Aplica la opción "Imprimir Resumido" a todos los comprobantes de centralización existentes
    /// </summary>
    public async Task<ActualizarResumidoCentralizacionResultDto> AplicarResumidoCentralizacionAsync(
        int empresaId, short ano)
    {
        logger.LogInformation(
            "Aplicando impresión resumida a comprobantes de centralización para EmpresaId={EmpresaId}, Ano={Ano}", 
            empresaId, ano);
        
        {
            // Obtener IDs de comprobantes de centralización
            var comprobantesIds = await context.MovComprobante
                .Where(mc => mc.IdEmpresa == empresaId && 
                            mc.Ano == ano && 
                            mc.DeCentraliz == true &&
                            mc.IdComp != null)
                .Select(mc => mc.IdComp!.Value)
                .Distinct()
                .ToListAsync();
            
            if (!comprobantesIds.Any())
            {
                logger.LogInformation("No se encontraron comprobantes de centralización");
                return new ActualizarResumidoCentralizacionResultDto
                {
                    ComprobantesActualizados = 0,
                    Exito = true,
                    Mensaje = "No hay comprobantes de centralización para actualizar."
                };
            }
            
            // Actualizar comprobantes
            var comprobantesActualizados = await context.Comprobante
                .Where(c => c.IdEmpresa == empresaId && 
                           c.Ano == ano && 
                           comprobantesIds.Contains(c.IdComp))
                .ExecuteUpdateAsync(setters => setters
                    .SetProperty(c => c.ImpResumido, true));
            
            logger.LogInformation(
                "Se actualizaron {Count} comprobantes de centralización con impresión resumida", 
                comprobantesActualizados);
            
            return new ActualizarResumidoCentralizacionResultDto
            {
                ComprobantesActualizados = comprobantesActualizados,
                Exito = true,
                Mensaje = $"Todos los comprobantes de centralización han quedado con la opción 'Imprimir Resumido' seleccionada. ({comprobantesActualizados} comprobantes actualizados)"
            };
        }
    }
    
    /// <summary>
    /// Inserta o actualiza un parámetro en ParamEmpresa
    /// </summary>
    private async Task UpsertParametroAsync(int empresaId, short ano, string tipo, string valor)
    {
        var parametro = await context.ParamEmpresa
            .FirstOrDefaultAsync(p => p.IdEmpresa == empresaId && 
                                     p.Ano == ano && 
                                     p.Tipo == tipo);
        
        if (parametro != null)
        {
            // UPDATE
            parametro.Codigo = 0;
            parametro.Valor = valor;
            context.ParamEmpresa.Update(parametro);
        }
        else
        {
            // INSERT
            parametro = new ParamEmpresa
            {
                IdEmpresa = empresaId,
                Ano = ano,
                Tipo = tipo,
                Codigo = 0,
                Valor = valor
            };
            context.ParamEmpresa.Add(parametro);
        }
    }
}
