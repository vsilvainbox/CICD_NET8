using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Text.Json;
using App.Extensions;
using App.Helpers;

namespace App.Features.ConfiguracionCorreccionComprobantes;

[Authorize]

public class ConfiguracionCorreccionComprobantesController(
    IHttpClientFactory httpClientFactory,
    ILogger<ConfiguracionCorreccionComprobantesController> logger,
    LinkGenerator linkGenerator) : Controller
{
    [HttpGet]
    public IActionResult Index()
    {
        // Extraer datos de HttpContext usando extensiones
        int empresaId = SessionHelper.EmpresaId;
        int ano = SessionHelper.Ano;

        logger.LogInformation("Loading ConfiguracionCorreccionComprobantes for empresaId: {EmpresaId}, ano: {Ano}",
            empresaId, ano);

        // Validar que haya una empresa seleccionada en la sesión
        if (empresaId <= 0)
        {
            logger.LogWarning("No hay empresa seleccionada en la sesión. Redirigiendo a SeleccionarEmpresa");
            TempData["SwalError"] = "Debe seleccionar una empresa antes de acceder a esta página";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        return View();
    }

    [HttpGet]
    public async Task<IActionResult> GetConfiguracion(int empresaId, short ano)
    {
        logger.LogInformation("Proxy: GetConfiguracion - empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ConfiguracionCorreccionComprobantesApiController>(
                HttpContext,
                nameof(ConfiguracionCorreccionComprobantesApiController.GetConfiguracion),
                new { empresaId, ano });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    [HttpPost]
    public async Task<IActionResult> SaveConfiguracion([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: SaveConfiguracion");

        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ConfiguracionCorreccionComprobantesApiController>(
                HttpContext,
                nameof(ConfiguracionCorreccionComprobantesApiController.ActualizarConfiguracion));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    [HttpPost]
    public async Task<IActionResult> AplicarResumidoCentralizacion(int empresaId, short ano)
    {
        logger.LogInformation("Proxy: AplicarResumidoCentralizacion - empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<ConfiguracionCorreccionComprobantesApiController>(
                HttpContext,
                nameof(ConfiguracionCorreccionComprobantesApiController.AplicarResumidoCentralizacion),
                new { empresaId, ano });
            var (statusCode, content) = await client.ProxyRequestAsync(url!, null, HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }
}
