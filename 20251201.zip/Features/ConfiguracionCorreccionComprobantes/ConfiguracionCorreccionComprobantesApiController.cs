using Microsoft.AspNetCore.Mvc;

namespace App.Features.ConfiguracionCorreccionComprobantes;

[ApiController]
[Route("[controller]/[action]")]
public class ConfiguracionCorreccionComprobantesApiController(
    IConfiguracionCorreccionComprobantesService service,
    ILogger<ConfiguracionCorreccionComprobantesApiController> logger) : ControllerBase
{
    /// <summary>
    /// Obtiene la configuraciÃ³n actual de comprobantes
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<ConfiguracionCorreccionComprobantesDto>> GetConfiguracion(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        {
            if (empresaId <= 0)
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "EmpresaId debe ser mayor a 0" } });

            if (ano < 2000 || ano > 2100)
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "Año debe estar entre 2000 y 2100" } });

            var config = await service.GetConfiguracionAsync(empresaId, ano);
            return Ok(config);
        }
    }
    
    /// <summary>
    /// Actualiza la configuraciÃ³n de comprobantes
    /// </summary>
    [HttpPost]
    public async Task<ActionResult> ActualizarConfiguracion(
        [FromBody] ActualizarConfiguracionCorreccionComprobantesDto dto)
    {
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            
            var resultado = await service.ActualizarConfiguracionAsync(dto);
            
            if (resultado)
            {
                return Ok(new { success = true, mensaje = "ConfiguraciÃ³n actualizada exitosamente" });
            }
            
            return StatusCode(500, new { success = false, mensaje = "Error al actualizar configuraciÃ³n" });
        }
    }
    
    /// <summary>
    /// Aplica la opciÃ³n "Imprimir Resumido" a todos los comprobantes de centralizaciÃ³n existentes
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<ActualizarResumidoCentralizacionResultDto>> AplicarResumidoCentralizacion(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        {
            if (empresaId <= 0)
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "EmpresaId debe ser mayor a 0" } });

            if (ano < 2000 || ano > 2100)
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = new[] { "Año debe estar entre 2000 y 2100" } });

            var resultado = await service.AplicarResumidoCentralizacionAsync(empresaId, ano);
            return Ok(resultado);
        }
    }
}
