# Mapa de Navegacion de Formularios VB6 - TR Contabilidad

## Resumen Ejecutivo

Este documento describe el flujo completo de navegacion entre todos los formularios del sistema TR Contabilidad (Thomson Reuters Contabilidad). El sistema esta compuesto por **3 modulos principales**:

1. **HyperContabilidad** - Modulo principal de contabilidad (170+ formularios)
2. **Administrador** - Modulo de administracion de empresas y usuarios (29 formularios)
3. **Comun** - Formularios compartidos entre modulos (9 formularios)
4. **VB50** - Componentes reutilizables (8 formularios)

---

## 1. SECUENCIA DE INICIO DE LA APLICACION

### 1.1 HyperContabilidad (Modulo Principal)

```
Sub Main() [LpContMain.bas]
    |
    +---> FrmStart.Show vbModeless  [Splash Screen - NO MODAL]
    |         |
    |         +-- Muestra logo TR Contabilidad
    |         +-- Muestra version del sistema
    |         +-- Expone Drive1 para seleccion de ruta BD
    |
    +---> FrmIdUser.Show vbModal  [Login - MODAL]
    |         |
    |         +-- Tx_Nombre: Usuario
    |         +-- Tx_Clave: Contrasena
    |         +-- Valida contra tabla Usuarios
    |         +-- Retorna: gUsuario.Rc (vbOK/vbCancel)
    |         +-- Datos: gUsuario.IdUsuario, gUsuario.Nombre, gUsuario.NombreLargo
    |
    +---> FrmSelEmpresas.FSelect() vbModal  [Seleccion Empresa - MODAL]
    |         |
    |         +-- Lista empresas segun permisos usuario
    |         +-- Lista anos disponibles por empresa
    |         +-- Retorna: gEmpresa.Id, gEmpresa.Ano
    |
    +---> FrmMain.Show vbModeless  [Formulario Principal MDI - NO MODAL]
    |
    +---> Unload FrmStart
```

### 1.2 Administrador

```
Sub Main() [Administrador.bas]
    |
    +---> FrmStart.Show vbModeless  [Splash Screen]
    |
    +---> FrmidUsuario.FShow() vbModal  [Login Administrador]
    |         |
    |         +-- Valida usuario administrador
    |
    +---> FrmMain.Show vbModeless  [Menu Principal Administrador]
    |
    +---> Unload FrmStart
```

---

## 2. ARBOL DE NAVEGACION PRINCIPAL (FrmMain - HyperContabilidad)

### 2.1 Menu ARCHIVO

| Menu Item | Formulario Llamado | Modalidad | Metodo | Datos Pasados |
|-----------|-------------------|-----------|--------|---------------|
| Seleccionar Empresa | FrmSelEmpresas | Modal | .FSelect() | - |
| Configuracion | FrmConfig | Modal | .Show | - |
| Config. Activo Fijo IFRS | FrmConfigActFijoIFRS | Modal | .Show | - |
| Config. Ctas Ajustes | FrmConfigCtasAjustes | Modal | .Show | - |
| Config. Ctas Ajustes RLI | FrmConfigCtasAjustesRLI | Modal | .Show | - |
| Config. Codigo IFRS | FrmConfigCodIFRS | Modal | .Show | - |
| Config. Remuneraciones | FrmConfigRemu | Modal | .Show | - |
| Config. Cheque | FrmConfigCheque | Modal | .Show | - |
| Config. Monedas | FrmMonedas | Modal | .Show | - |
| Config. Hojas Timbraje | FrmFoliacion | Modal | .Show | - |

### 2.2 Menu MAESTROS

| Menu Item | Formulario Llamado | Modalidad | Metodo | Datos Pasados |
|-----------|-------------------|-----------|--------|---------------|
| Plan de Cuentas | FrmPlanCuentas | - | .FEdit | - |
| Listado Cuentas | FrmLstPlanCuentas | Modal | .Show | - |
| Editar Empresa | FrmEmpresa | - | .FEdit(gEmpresa.Id) | IdEmpresa |
| Contadores Empresa | FrmContEmpresa | Modal | .Show | - |
| Entidades Relacionadas | FrmEntidades | - | .FEdit | - |
| Areas de Negocio | FrmAreaNeg | - | .FEdit | - |
| Centros de Costo | FrmCentrosCosto | - | .FEdit | - |
| Equivalencias | FrmEquivalencias | Modal/- | .Show/.FEdit(0) | IdMoneda=0 |
| Mant. Percepciones | FrmMantPercepciones | Modal | .Show | - |

### 2.3 Menu COMPROBANTES

| Menu Item | Formulario Llamado | Modalidad | Metodo | Datos Pasados |
|-----------|-------------------|-----------|--------|---------------|
| Nuevo Comprobante | FrmComprobante | - | .FNew(False) | CompTipo=False |
| Editar Comprobante | FrmLstComp | - | .FView | - |
| Listar Comprobantes | FrmLstComp | - | .FView | - |
| Imprimir Comprobante | FrmLstComp | - | .FPrint | - |
| Comp. Apertura Fin | FrmComprobante | - | .FEdit(IdComp, False) | IdComp, CompTipo |
| Comp. Apertura Trib | FrmComprobante | - | .FEdit(IdComp, False) | IdComp, CompTipo |
| Tipos de Comprobante | FrmLstCompTipo | Modal | .Show | - |

### 2.4 Menu DOCUMENTOS (Libros Compra/Venta)

| Menu Item | Formulario Llamado | Modalidad | Metodo | Datos Pasados |
|-----------|-------------------|-----------|--------|---------------|
| Listar Documentos | FrmSelLibDocs | - | .FSelect(TipoLib, True) | TipoLib, SelMode |
| Nuevo Documento | FrmSelLibDocs | - | .FSelectMes(...) | TipoLib, Mes, Ano |
| Cheques a Fecha | FrmLstDoc | - | .FView(LIB_OTROS, TipoDoc, Estado, Mes, Ano) | Multiples params |
| Cheques Anulados | FrmLstDoc | - | .FView(...) | - |
| Cheques Emitidos | FrmLstDoc | - | .FView(...) | - |
| Cuotas por Pagar | FrmLstDocCuotas | - | .FView | - |

### 2.5 Menu BALANCES

| Menu Item | Formulario Llamado | Modalidad | Metodo | Datos Pasados |
|-----------|-------------------|-----------|--------|---------------|
| Balance Clasificado | FrmBalClasif | Modeless | .FViewBalClasif | Mes (opcional) |
| Balance Comprobacion | FrmBalComprobacion | Modeless | .FView(0) | Mes=0 |
| Balance Tributario | FrmBalTributario | Modal/Modeless | .FView(0) | Mes=0 |
| Balance por Area Neg | FrmBalClasifDesglo | Modeless | .FViewBalClasifDesglo("AREANEG") | TipoDesglose |
| Balance por CC | FrmBalClasifDesglo | Modeless | .FViewBalClasifDesglo("CCOSTO") | TipoDesglose |
| Balance Comparativo | FrmBalClasifCompar | Modeless | .FViewBalClasif | - |
| Balance Ejecutivo | FrmBalClasifEjec | Modeless | .FViewBalClasif | - |
| Balance Ejec IFRS | FrmBalEjecIFRS | Modal | .FView | Mes (opcional) |
| Balance Trib IFRS | FrmBalTributarioIFRS | Modal/Modeless | .FView(0) | Mes=0 |

### 2.6 Menu ESTADOS DE RESULTADOS

| Menu Item | Formulario Llamado | Modalidad | Metodo | Datos Pasados |
|-----------|-------------------|-----------|--------|---------------|
| Estado Resultado Clasif | FrmBalClasif | Modeless | .FViewEstResultClasif | Mes (opcional) |
| Estado Resultado Compar | FrmBalClasif | Modeless | .FViewEstResultComparativo | Mes (opcional) |
| E.R. por Area Neg | FrmBalClasifDesglo | Modeless | .FViewEstResultClasifDesglo("AREANEG") | TipoDesglose |
| E.R. por CC | FrmBalClasifDesglo | Modeless | .FViewEstResultClasifDesglo("CCOSTO") | TipoDesglose |
| E.R. Comp Periodo | FrmBalClasifCompar | Modeless | .FViewEstResultClasif | - |

### 2.7 Menu LIBROS CONTABLES

| Menu Item | Formulario Llamado | Modalidad | Metodo | Datos Pasados |
|-----------|-------------------|-----------|--------|---------------|
| Libro Diario | FrmLibDiario | Modeless/Modal | - | - |
| Libro Mayor | FrmLibMayor | Modeless/Modal | - | - |
| Libro Inventario y Bal | FrmLibInvBal | Modeless | - | - |
| Libro Retenciones | FrmLibRetenciones | Modal/Modeless | - | - |
| Libro Caja | FrmLibroCaja | Modal/Modeless | - | - |
| Libro Ingreso Egreso | FrmLibIngEg | Modal | .Show | - |
| Seleccion Libros | FrmSelLibros | - | .FSelectMes | - |
| Editar Libro Caja | FrmSelLibCaja | - | .FSelectOper | - |
| Libros Impresos | FrmLstLibImpresos | Modal | .Show | - |
| Auditoria Libros | FrmAuditLibContables | - | .FView | - |

### 2.8 Menu INFORMES ANALITICOS

| Menu Item | Formulario Llamado | Modalidad | Metodo | Datos Pasados |
|-----------|-------------------|-----------|--------|---------------|
| Inf. Analitico por Entidad | FrmInfAnalitico | Modeless | .FViewPorEntidad(0) | Param=0 |
| Inf. Analitico por Cuenta | FrmInfAnalitico | Modeless | .FViewPorCuenta(0) | Param=0 |
| Inf. Analitico Cta ODF | FrmInfAnaliticoFulle | Modeless | .FViewPorCuenta(0) | Param=0 |
| Inf. Analitico Ent ODF | FrmInfAnaliticoFulle | Modeless | .FViewPorEntidad(0) | Param=0 |
| Resumen Lib Auxiliares | FrmResLibAux | - | .FView | - |
| Info Cartola Bancaria | FrmResCartolas | Modal | .Show | - |
| Info Conciliacion | FrmInfConciliacion | Modeless | .Show | - |
| Resumen Conciliacion | FrmResInfConcil | Modeless | .Show | - |
| Info Vencimiento 30d | FrmInfoVencim | - | .FView(30) | Dias=30 |
| Info Vencimiento 60d | FrmInfoVencim | - | .FView(60) | Dias=60 |
| Info Vencimiento 90d | FrmInfoVencim | - | .FView(90) | Dias=90 |

### 2.9 Menu ACTIVO FIJO

| Menu Item | Formulario Llamado | Modalidad | Metodo | Datos Pasados |
|-----------|-------------------|-----------|--------|---------------|
| Mantencion Activo Fijo | FrmLstActFijo | - | .FEdit | - |
| Importar Activo Fijo | FrmImpActFijoFile | Modal | .Show | - |
| Reimportar Activo Fijo | FrmImpActFijos | Modal | .Show | - |
| Reporte Activo Fijo | FrmRepActivoFijo | - | .FView | - |
| Reporte AF IFRS | FrmRepActFijoIFRS | - | .FView | - |
| Seleccion Rep AF | FrmSelRepActFijo | Modal | .Show | - |

### 2.10 Menu EXPORTACION/IMPORTACION

| Menu Item | Formulario Llamado | Modalidad | Metodo | Datos Pasados |
|-----------|-------------------|-----------|--------|---------------|
| Exportar Entidades | FrmExpEntidades | Modal | .Show | - |
| Exportar F22 | FrmExpF22 | Modal | .Show | - |
| Exportar F29 | FrmExpF29 | Modal | .Show | - |
| Exportar HR RAB | FrmExpDJAnual | - | .ExpHRRAB | - |
| Exportar HR RAD | FrmExpDJAnual | - | .ExpHRRAD | - |
| Exportar Retiros Div | FrmExpDJAnual | - | .ExpRetirosDividendos | - |
| Exportar DJ 1847 | FrmExpDJAnual | - | .Exp1847 | - |
| Exportar DJ 1923 | FrmExpDJAnual | - | .Exp1923 | - |
| Exportar DJ 1924B | FrmExpDJAnual | - | .Exp1924B | - |
| Exportar DJ 1924C | FrmExpDJAnual | - | .Exp1924C | - |
| Exportar Certif HR | FrmExpHRCertif | Modal | .Show | - |
| Exportar Percepciones | FrmExpPercepciones | Modal | .Show | - |
| Ajustes Extra RLI | FrmAjustesExtraLibCajaRLI | Modal | .Show | - |
| Importar Comprobantes | FrmImpComp | Modal | .Show | - |
| Importar Facturacion | FrmImpFacturacion | Modal | .Show | - |
| Exp/Imp Lib Auxiliares | FrmImpExpLib | - | .FExport/.FImport | - |
| Importar Otros Docs | FrmSelImpoOD | Modal | .Show | - |
| Importar Remuneraciones | FrmImportRemu | Modal | .Show | - |
| Importar F29 | FrmImportF29 | Modal | .Show | - |

### 2.11 Menu SII (Servicio Impuestos Internos)

| Menu Item | Formulario Llamado | Modalidad | Metodo | Datos Pasados |
|-----------|-------------------|-----------|--------|---------------|
| Lib Elect Compras | FrmLibElectCompras | - | .FGenLibComprasSII | - |
| Imp Lib Compras SII | FrmImpLibComprasSII | Modal | .Show | - |
| Imp Lib Ventas SII | FrmImpLibVentasSII | Modal | .Show | - |
| Imp Lib Retenciones SII | FrmImpLibRetencionesSII | Modal | .Show | - |

### 2.12 Menu TRIBUTARIO

| Menu Item | Formulario Llamado | Modalidad | Metodo | Datos Pasados |
|-----------|-------------------|-----------|--------|---------------|
| Capital Propio Simplif (General) | FrmCapPropioSimpl | Modeless | .FView(CPS_TIPOINFO_GENERAL) | TipoInforme |
| Capital Propio Simplif (VarAnual) | FrmCapPropioSimpl | Modeless | .FView(CPS_TIPOINFO_VARANUAL) | TipoInforme |
| Capital Propio Tributario | FrmCapitalPropio | Modeless | .FView | - |
| Prop IVA | FrmPropIVA | Modal | .Show | - |
| 14 Ter / ProPyme (>=2020) | FrmSel14DProPyme | Modal | .Show | - |
| 14 Ter (<2020) | FrmSelLib14ter | - | .FView | - |

### 2.13 Menu IFRS

| Menu Item | Formulario Llamado | Modalidad | Metodo | Datos Pasados |
|-----------|-------------------|-----------|--------|---------------|
| Estado Financiero | FrmLstIInformeIFRS | - | .FView(IFRS_ESTFIN) | TipoInforme |
| Estado Resultado | FrmLstIInformeIFRS | - | .FView(IFRS_ESTRES) | TipoInforme |
| Balance Ejecutivo IFRS | FrmBalEjecIFRS | - | .FView | - |

### 2.14 Menu UTILIDADES

| Menu Item | Formulario Llamado | Modalidad | Metodo | Datos Pasados |
|-----------|-------------------|-----------|--------|---------------|
| Calendario | FrmCalendar | - | .SelDate(Fecha) | Fecha (ByRef) |
| Convertir Moneda | FrmConverMoneda | Modal | .Show | - |
| Indices IPC | FrmIPC | Modal | .Show | - |
| Cambiar Clave | FrmCambioClave | Modal | .Show | - |
| Estado Meses | FrmEstadoMeses | Modal | .Show | - |
| Cierre Anual | FrmCierreAnual | Modal | .Show | - |
| Importar Cartola | FrmImpCartola | Modal | .Show | - |
| Conciliacion | FrmConciliacion | - | .FEdit | - |
| Imprimir Hojas Timb | FrmPrtFoliacion | Modal | .Show | - |
| Calc Razones Financ | FrmCalcRazones | Modal | .Show | - |
| Def Razones Financ | FrmRazones | - | .FConfigParam | - |
| Renumerar | FrmRenum | Modal | .Show | - |
| Herramientas Int | FrmIntTools | Modal | .Show | - |
| Auditoria Seguimiento | FrmSelSeguimiento | Modal | .Show | - |
| Traspaso OD a ODF | FrmTrapasoODToODF | Modal | .Show | - |

---

## 3. ARBOL DE NAVEGACION ADMINISTRADOR (FrmMain - Administrador)

### 3.1 Menu EMPRESAS

| Menu Item | Formulario Llamado | Modalidad | Metodo | Datos Pasados |
|-----------|-------------------|-----------|--------|---------------|
| Mant. Empresas | FrmEmpresas | Modal | .Show | - |
| Listar Empresas | FrmPrtEmpresas | Modal | .Show | - |
| Importar Empresa | FrmEmpArchivo | - | .FSelect | - |
| Imp. Empresa HR | FrmEmpHR | - | .FSelect | gEmprHR |
| Imp. Emp LP Remu | FrmEmpLpRemu | - | .Show | - |
| Reset Empresa Ano | FrmResetEmprAno | Modal | .Show | - |
| Rep Aud Cuentas Def | FrmRepAudCuentasDefinidas | Modal | .Show | - |
| Rep Control Empresas | FrmReporteControlEmpresas | Modal | .Show | - |

### 3.2 Menu CONFIGURACION

| Menu Item | Formulario Llamado | Modalidad | Metodo | Datos Pasados |
|-----------|-------------------|-----------|--------|---------------|
| Crear Usr Fiscalizador | FrmCrearUsrFiscalizador | Modal | .Show | - |
| Desbloquear | FrmDesbloquear | Modal | .Show | - |
| Imp Datos SII | FrmIntegracionDatosSII | Modal | .Show | - |
| Oficina | FrmOficina | Modal | .Show | - |
| Razones Financieras | FrmRazones | - | .FDefinir | - |

### 3.3 Menu USUARIOS

| Menu Item | Formulario Llamado | Modalidad | Metodo | Datos Pasados |
|-----------|-------------------|-----------|--------|---------------|
| Equipos Autorizados (Admin) | FrmEquiposAut | - | .Admin | - |
| Equipos Autorizados (Solic) | FrmEquiposAut | - | .Solicitud | - |
| Perfiles | FrmPerfiles | - | .ShowPerfiles(True) | NoIncPrivMaestros |
| Privilegios Usuario | FrmUsuarioPriv | Modal | .Show | - |
| Usuarios | FrmUsuarios | Modal | .Show | - |
| Cambiar Clave | FrmCambioClave | Modal | .Show | - |

### 3.4 Menu AYUDA

| Menu Item | Formulario Llamado | Modalidad | Metodo | Datos Pasados |
|-----------|-------------------|-----------|--------|---------------|
| Acerca De | FrmAbout | Modal | .Show | - |
| Backup | FrmGenBackup | Modal | .Show | - |
| Ayuda Backup | FrmBackup | Modal | .Show | - |
| Reporte Error | FrmRepError | Modal | .Show | - |
| Exportar Empresa | FrmExportEmp | Modal | .Show | - |

---

## 4. FORMULARIOS COMUNES (Compartidos entre modulos)

| Formulario | Funcion | Metodos Publicos | Llamado Desde |
|------------|---------|------------------|---------------|
| FrmCambioClave | Cambiar contrasena usuario | .Show | FrmMain (ambos) |
| FrmDesbloquear | Desbloquear empresas | .Show | FrmMain Admin |
| FrmEquivalencias | Equivalencias de moneda | .FEdit(IdMoneda), .FSelect(...) | FrmMain, FrmConfig |
| FrmFactoresAct | Factores actualizacion | .FEdit(Ano) | FrmConfig |
| FrmMantMoneda | Mantencion monedas | .Show | FrmMonedas |
| FrmMonedas | Listado monedas | .Show | FrmMain (ambos) |
| FrmOficina | Datos oficina | .Show | FrmMain Admin |
| FrmPrintPreview | Vista previa impresion | .FView(Cap), .NewPage(), .LastPage() | Multiples |
| FrmRazones | Razones financieras | .FDefinir, .FConfigParam | FrmMain (ambos) |

---

## 5. FORMULARIOS VB50 (Componentes Reutilizables)

| Formulario | Funcion | Metodos Publicos | Usado En |
|------------|---------|------------------|----------|
| Calendar (FrmCalendar) | Selector de fecha | .SelDate(Fecha ByRef) | Multiples formularios |
| FrmBackup | Ayuda sobre backup | .Show | FrmMain Admin |
| FrmConfigCheque | Configurar impresion cheque | .Show | FrmMain Contab |
| FrmDemo | Pantalla demo | .Show | Modo demo |
| FrmHlpBackup | Ayuda backup detallada | .Show | FrmBackup |
| FrmMsgConBreak | Mensaje con opcion cancelar | .Show | Procesos largos |
| FrmPrtCheque | Imprimir cheque | - | FrmDoc |
| FrmRepError | Reportar error | .Show | FrmMain Admin |

---

## 6. RELACIONES DETALLADAS ENTRE FORMULARIOS

### 6.1 Cadena de Comprobantes

```
FrmMain
    |
    +---> FrmLstComp.FView  [Lista comprobantes]
              |
              +---> FrmComprobante.FEdit(IdComp)  [Editar comprobante]
                        |
                        +---> FrmPlanCuentas.FSelect  [Seleccionar cuenta]
                        +---> FrmEntidades.FSelect  [Seleccionar entidad]
                        +---> FrmCalendar.SelDate  [Seleccionar fecha]
                        +---> FrmConverMoneda.FSelect  [Convertir moneda]
                        +---> FrmActivoFijo.FNewFromComp  [Crear activo fijo]
```

### 6.2 Cadena de Documentos (Compra/Venta)

```
FrmMain
    |
    +---> FrmSelLibDocs.FSelect(TipoLib)  [Seleccionar libro/mes]
              |
              +---> FrmCompraVenta.FEdit(TipoLib, Mes, Ano, IdDoc)  [Editar documento]
                        |
                        +---> FrmEntidad.FNew/FEdit  [Mantener entidad]
                        +---> FrmDocCuotas.FEdit  [Cuotas documento]
                        +---> FrmDocLib.FNew/FEdit  [Documento libro]
                        +---> FrmLstActFijo.FSelect  [Vincular activo fijo]
                        +---> FrmActivoFijo.FNewFromDoc  [Crear activo fijo]
                        +---> FrmPlanCuentas.FSelect  [Seleccionar cuenta]
                        +---> FrmCalendar.SelDate  [Fecha]
```

### 6.3 Cadena de Activo Fijo

```
FrmMain
    |
    +---> FrmLstActFijo.FEdit  [Lista activos fijos]
              |
              +---> FrmActivoFijo.FEdit(IdActFijo)  [Editar activo]
                        |
                        +---> FrmAFCompsFicha.FEdit  [Componentes ficha]
                        |         |
                        |         +---> FrmConfigActFijoIFRS  [Config IFRS]
                        |
                        +---> FrmAFFicha.FEdit  [Ficha activo]
                        +---> FrmActFijoInfoAdic.FEdit  [Info adicional]
                        +---> FrmCalendar.SelDate  [Fechas]
                        +---> FrmRequisitos  [Requisitos legales]
```

### 6.4 Cadena de Balances

```
FrmMain
    |
    +---> Bt_Balances_Click
              |
              +---> FrmSelBalances.Show  [Seleccion tipo balance]
                        |
                        +---> FrmBalClasif  [Balance clasificado]
                        +---> FrmBalComprobacion  [Balance comprobacion]
                        +---> FrmBalTributario  [Balance tributario]
                        +---> FrmBalClasifDesglo  [Balance desglosado]
                        +---> FrmBalClasifEjec  [Balance ejecutivo]
                                  |
                                  +---> FrmLibMayor.FView  [Drill-down a Mayor]
                                  +---> FrmPrintPreview.FView  [Vista previa]
                                  +---> FrmConverMoneda.FSelect  [Conversion]
                                  +---> FrmCalendar.SelDate  [Fechas]
                                  +---> FrmEmailAccount  [Enviar por email]
```

### 6.5 Cadena de Configuracion

```
FrmMain.M_Config_Click
    |
    +---> FrmConfig.Show vbModal  [Configuracion general]
              |
              +---> FrmConfigCtasLibCompras  [Cuentas lib compras]
              +---> FrmConfigCtasLibVentas  [Cuentas lib ventas]
              +---> FrmConfigCtasDef  [Cuentas definidas]
              |         |
              |         +---> FrmConfigDefinidasPlanCuenta  [Plan pre-2019]
              |         +---> FrmConfigDefinidasPlanCuenta2019  [Plan 2019+]
              |
              +---> FrmConfigFUT  [Configurar FUT]
              +---> FrmCopyPlan  [Copiar plan de cuentas]
              +---> FrmConfigInformes  [Configurar informes]
              +---> FrmConfigInformeFirma  [Firmas en informes]
              +---> FrmConfigImpAdic  [Impuestos adicionales]
              +---> FrmPlanCuentas.FSelect  [Seleccionar cuentas]
```

### 6.6 Cadena de Usuarios (Administrador)

```
FrmMain Admin
    |
    +---> FrmUsuarios.Show vbModal  [Lista usuarios]
              |
              +---> FrmMantUsuario.FNew/FEdit  [Mantener usuario]
              |         |
              |         +-- Nombre, Clave, Activo, Perfil, etc.
              |
              +---> FrmUsuarioPriv.Show  [Privilegios]
              |
              +---> FrmPerfiles.ShowPerfiles  [Perfiles seguridad]
```

---

## 7. TIPOS DE FORMULARIOS

### 7.1 Formularios Modales (Bloquean interaccion)

Los siguientes formularios siempre se muestran con `.Show vbModal`:

- Todos los formularios de configuracion (FrmConfig*)
- Formularios de dialogo (FrmIdUser, FrmSelEmpresas)
- Formularios de mantencion (FrmMant*, FrmUsuarios)
- Formularios de edicion simple (FrmCuenta, FrmEntidad, FrmDoc)
- Formularios de seleccion (FrmSel*)

### 7.2 Formularios No Modales (Permiten navegacion)

Los siguientes formularios se muestran con `.Show vbModeless`:

- FrmMain (ambos modulos)
- FrmStart (splash screen)
- Balances (FrmBalClasif, FrmBalComprobacion, etc.)
- Informes analiticos (FrmInfAnalitico*)
- Libro Mayor (FrmLibMayor)
- Capital Propio (FrmCapitalPropio, FrmCapPropioSimpl)

### 7.3 Formularios con Metodos Especiales

Formularios que no usan `.Show` sino metodos publicos:

| Formulario | Metodo | Descripcion |
|------------|--------|-------------|
| FrmCalendar | .SelDate(Fecha) | Retorna fecha por referencia |
| FrmPlanCuentas | .FSelect/FEdit | Seleccion o edicion plan |
| FrmEntidades | .FEdit/FSelect | Seleccion o edicion entidad |
| FrmComprobante | .FNew/.FEdit/.FView | CRUD comprobantes |
| FrmDoc | .FNew/.FEdit/.FView | CRUD documentos |
| FrmExpDJAnual | .ExpHRRAB/.ExpHRRAD/etc | Exportaciones especificas |
| FrmEquiposAut | .Admin/.Solicitud | Modos de operacion |
| FrmPerfiles | .ShowPerfiles(bool) | Con parametro |

---

## 8. VARIABLES GLOBALES DE NAVEGACION

### 8.1 Usuario Actual
```vb
gUsuario.IdUsuario      ' ID del usuario
gUsuario.Nombre         ' Nombre de login
gUsuario.NombreLargo    ' Nombre completo
gUsuario.Priv           ' Nivel de privilegio
gUsuario.Rc             ' Resultado ultimo dialogo (vbOK/vbCancel)
```

### 8.2 Empresa Actual
```vb
gEmpresa.Id             ' ID de la empresa
gEmpresa.Rut            ' RUT de la empresa
gEmpresa.Ano            ' Ano contable seleccionado
gEmpresa.NombreCorto    ' Nombre corto
```

### 8.3 Configuracion Sistema
```vb
gDbPath                 ' Ruta base de datos
gDbType                 ' Tipo: SQL_ACCESS o SQL_SERVER
gAppCode.Demo           ' Modo demo activo
gMaxEmpLicencia         ' Maximo empresas licenciadas
gOficina.Rut            ' RUT de la oficina
```

---

## 9. LISTADO COMPLETO DE FORMULARIOS

### 9.1 HyperContabilidad (170 formularios)

| # | Formulario | Tipo | Descripcion |
|---|------------|------|-------------|
| 1 | FrmAbout | Modal | Acerca de |
| 2 | FrmActFijoInfoAdic | Modal | Info adicional activo fijo |
| 3 | FrmActivoFijo | Modal | Mantencion activo fijo |
| 4 | FrmAFCompsFicha | Modal | Componentes ficha AF |
| 5 | FrmAFFicha | Modal | Ficha activo fijo |
| 6 | FrmAjustesExtraLibCaja | Modal | Ajustes extra libro caja |
| 7 | FrmAjustesExtraLibCajaRLI | Modal | Ajustes RLI |
| 8 | FrmANeg | Modal | Area de negocio individual |
| 9 | FrmApertura | Modal | Apertura de periodo |
| 10 | FrmAreaNeg | Modal | Lista areas de negocio |
| 11 | FrmAsisPPM | Modal | Asistente PPM |
| 12 | FrmAsistImpPrimCat | Modal | Asist. imp primera categoria |
| 13 | FrmAuditLibContables | Modal | Auditoria libros contables |
| 14 | FrmAuditoria | Modal | Auditoria general |
| 15 | FrmAyuda | Modal | Ayuda contextual |
| 16 | FrmBalClasif | Modeless | Balance clasificado |
| 17 | FrmBalClasifCompar | Modeless | Balance clasif comparativo |
| 18 | FrmBalClasifDesglo | Modeless | Balance clasif desglosado |
| 19 | FrmBalClasifEjec | Modeless | Balance clasif ejecutivo |
| 20 | FrmBalComprobacion | Modeless | Balance comprobacion |
| 21 | FrmBalEjecIFRS | Modal | Balance ejecutivo IFRS |
| 22 | FrmBalTributario | Modal/Modeless | Balance tributario |
| 23 | FrmBalTributarioIFRS | Modal/Modeless | Balance tributario IFRS |
| 24 | FrmBaseImponible | Modal | Base imponible |
| 25 | FrmBaseImponible14D | Modal | Base imponible 14D |
| 26 | FrmBaseImponible14DFull | Modal | Base imponible 14D completa |
| 27 | FrmCalcRazones | Modal | Calcular razones financieras |
| 28 | FrmCambioClave | Modal | Cambiar clave usuario |
| 29 | FrmCambioEstadoComp | Modal | Cambiar estado comprobante |
| 30 | FrmCapitalAportado | Modal | Capital aportado |
| 31 | FrmCapitalPropio | Modeless | Capital propio |
| 32 | FrmCapPropioSimpl | Modeless | Capital propio simplificado |
| 33 | FrmCCosto | Modal | Centro de costo individual |
| 34 | FrmCentrosCosto | Modal | Lista centros de costo |
| 35 | FrmCierreAnual | Modal | Cierre anual |
| 36 | FrmComponente | Modal | Componente |
| 37 | FrmCompraVenta | Modal/Modeless | Libro compra/venta |
| 38 | FrmComprobante | Modal | Comprobante contable |
| 39 | FrmConciliacion | Modal | Conciliacion bancaria |
| 40 | FrmConfig | Modal | Configuracion general |
| 41 | FrmConfigActFijo | Modal | Config activo fijo |
| 42 | FrmConfigActFijoIFRS | Modal | Config activo fijo IFRS |
| 43 | FrmConfigCodIFRS | Modal | Config codigos IFRS |
| 44 | FrmConfigCompActFijo | Modal | Config comp activo fijo |
| 45 | FrmConfigCorrComp | Modal | Config corr comprobante |
| 46 | FrmConfigCtasAjustes | Modal | Config cuentas ajustes |
| 47 | FrmConfigCtasAjustesRLI | Modal | Config cuentas RLI |
| 48 | FrmConfigCtasDef | Modal | Config cuentas definidas |
| 49 | FrmConfigCtasLibCompras | Modal | Config ctas lib compras |
| 50 | FrmConfigCtasLibVentas | Modal | Config ctas lib ventas |
| 51 | frmConfigDefinidasPlanCuenta | Modal | Config plan cuentas |
| 52 | frmConfigDefinidasPlanCuenta2019 | Modal | Config plan cuentas 2019 |
| 53 | FrmConfigFUT | Modal | Config FUT |
| 54 | FrmConfigImpAdic | Modal | Config impuestos adicionales |
| 55 | FrmConfigInformeFirma | Modal | Config firmas informes |
| 56 | FrmConfigInformes | Modal | Config informes |
| 57 | FrmConfigRemu | Modal | Config remuneraciones |
| 58 | FrmContEmpresa | Modal | Contadores empresa |
| 59 | FrmConverMoneda | Modal | Convertir moneda |
| 60 | FrmCopiarSincronizacion | Modal | Copiar sincronizacion |
| 61 | FrmCopyPlan | Modal | Copiar plan cuentas |
| 62 | FrmCuenta | Modal | Cuenta contable |
| 63 | FrmDatosDJ1847 | Modal | Datos DJ 1847 |
| 64 | FrmDetBaseImponible14DFull | Modal | Detalle base imp 14D |
| 65 | FrmDetCapPropioSimpl | Modal | Detalle cap propio simpl |
| 66 | FrmDetCapPropioSimplAcum | Modal | Det cap propio acumulado |
| 67 | FrmDetCapPropioSimplMini | Modal | Det cap propio mini |
| 68 | FrmDetSaldoAp | Modal | Detalle saldo apertura |
| 69 | FrmDoc | Modal | Documento |
| 70 | FrmDocCuotas | Modal | Cuotas documento |
| 71 | FrmDocLib | Modal | Documento libro |
| 72 | FrmEditarSincronizacion | Modal | Editar sincronizacion |
| 73 | FrmEjemploImport | Modal | Ejemplo importacion |
| 74 | FrmEmailAccount | - | Cuenta email |
| 75 | FrmEmpHR | Modal | Empresa HyperRenta |
| 76 | FrmEmpresa | Modal | Empresa |
| 77 | FrmEntidad | Modal | Entidad relacionada |
| 78 | FrmEntidades | Modal | Lista entidades |
| 79 | FrmEquivalencias | Modal | Equivalencias moneda |
| 80 | FrmEstadoMeses | Modal | Estado de meses |
| 81 | FrmExpDJAnual | Modal | Exportar DJ anual |
| 82 | FrmExpEntidades | Modal | Exportar entidades |
| 83 | FrmExpF22 | Modal | Exportar F22 |
| 84 | FrmExpF29 | Modal | Exportar F29 |
| 85 | FrmExpHRCertif | Modal | Exportar certificados HR |
| 86 | FrmExpPercepciones | Modal | Exportar percepciones |
| 87 | FrmFmtImpEnt | Modal | Formato import entidades |
| 88 | FrmFoliacion | Modal | Foliacion |
| 89 | FrmGlosas | Modal | Glosas |
| 90 | FrmGlosasUpdate | Modal | Actualizar glosas |
| 91 | FrmGrupo | Modal | Grupo |
| 92 | FrmHelpCred33bis | Modal | Ayuda credito 33bis |
| 93 | FrmHelpImpCartola | Modal | Ayuda importar cartola |
| 94 | FrmIdUser | Modal | Identificacion usuario |
| 95 | FrmImpActFijoFile | Modal | Importar AF archivo |
| 96 | FrmImpActFijos | Modal | Importar activos fijos |
| 97 | FrmImpAreaNegocio | Modal | Importar areas negocio |
| 98 | FrmImpCartola | Modal | Importar cartola |
| 99 | FrmImpCentroCosto | Modal | Importar centros costo |
| 100 | FrmImpComp | Modal | Importar comprobantes |
| 101 | FrmImpExpLib | Modal | Import/Export libros |
| 102 | FrmImpFacturacion | Modal | Importar facturacion |
| 103 | FrmImpLibComprasSII | Modal | Imp lib compras SII |
| 104 | FrmImpLibRetencionesSII | Modal | Imp lib retenciones SII |
| 105 | FrmImpLibVentasSII | Modal | Imp lib ventas SII |
| 106 | FrmImportF29 | Modal | Importar F29 |
| 107 | FrmImportRemu | Modal | Importar remuneraciones |
| 108 | FrmImpOtrosDocFull | Modal | Imp otros docs full |
| 109 | FrmImpOtrosDocs | Modal | Imp otros docs |
| 110 | FrmImpSucursales | Modal | Importar sucursales |
| 111 | FrmInfAnalitico | Modeless | Informe analitico |
| 112 | FrmInfAnaliticoAdv | Modeless | Inf analitico avanzado |
| 113 | FrmInfAnaliticoFull | Modeless | Inf analitico completo |
| 114 | FrmInfAnaliticoFulle | Modeless | Inf analitico full ext |
| 115 | FrmInfConciliacion | Modal | Informe conciliacion |
| 116 | FrmInfoAyuda | Modal | Info ayuda |
| 117 | FrmInfoVencim | Modal | Info vencimientos |
| 118 | FrmIntTools | Modal | Herramientas internas |
| 119 | FrmIPC | Modal | IPC |
| 120 | FrmIVA | Modal | IVA |
| 121 | FrmLibDiario | Modeless/Modal | Libro diario |
| 122 | FrmLibElectCompras | Modal | Lib electronico compras |
| 123 | FrmLibIngEg | Modal | Libro ingreso egreso |
| 124 | FrmLibInvBal | Modeless | Libro inventario balance |
| 125 | FrmLibMayor | Modeless/Modal | Libro mayor |
| 126 | FrmLibRetenciones | Modal/Modeless | Libro retenciones |
| 127 | FrmLibroCaja | Modal/Modeless | Libro caja |
| 128 | FrmListadoPlanCuentas | Modal | Listado plan cuentas |
| 129 | FrmLstActFijo | Modal | Lista activos fijos |
| 130 | FrmLstAtrib | Modal | Lista atributos |
| 131 | FrmLstComp | Modal | Lista comprobantes |
| 132 | FrmLstCompTipo | Modal | Lista tipos comprobante |
| 133 | FrmLstDoc | Modal | Lista documentos |
| 134 | FrmLstDocCuotas | Modal | Lista cuotas documentos |
| 135 | FrmLstIInformeIFRS | Modal | Lista informes IFRS |
| 136 | FrmLstLibImpresos | Modal | Lista libros impresos |
| 137 | FrmLstPlanCuentasPreview | Modal | Preview plan cuentas |
| 138 | FrmMain | Modeless | Menu principal |
| 139 | FrmMainSQLServer | Modeless | Main SQL Server |
| 140 | FrmMantPercepciones | Modal | Mant percepciones |
| 141 | FrmMarkActFijo | Modal | Marcar activo fijo |
| 142 | FrmMsgSincronizacion | Modal | Mensaje sincronizacion |
| 143 | FrmNiveles | Modal | Niveles |
| 144 | FrmNote | Modal | Nota |
| 145 | FrmParamRaz | Modal | Parametros razones |
| 146 | FrmPercepciones | Modal | Percepciones |
| 147 | FrmPlanCuentas | Modal | Plan de cuentas |
| 148 | FrmPropIVA | Modal | Proporcion IVA |
| 149 | FrmPrtFoliacion | Modal | Imprimir foliacion |
| 150 | FrmPrtSetup | Modal | Config impresion |
| 151 | FrmRenum | Modal | Renumerar |
| 152 | FrmRepActFijoIFRS | Modal | Reporte AF IFRS |
| 153 | FrmRepActivoFijo | Modal | Reporte activo fijo |
| 154 | FrmRepPorNivel | Modal | Reporte por nivel |
| 155 | FrmRequisitos | Modal | Requisitos |
| 156 | FrmResCartolas | Modal | Resumen cartolas |
| 157 | FrmResDocs | Modal | Resumen documentos |
| 158 | FrmResInfConcil | Modeless | Resumen conciliacion |
| 159 | FrmResIVA | Modal | Resumen IVA |
| 160 | FrmResLibAux | Modal | Resumen lib auxiliares |
| 161 | FrmResOtrosImp | Modal | Resumen otros impuestos |
| 162 | FrmResRet3Porc | Modal | Resumen ret 3% |
| 163 | FrmRevDetDocs | Modal | Revisar det documentos |
| 164 | FrmSaldoApertura | Modal | Saldo apertura |
| 165 | FrmSalyTotLibCajas | Modal | Saldos lib caja |
| 166 | FrmSeguimientoCierreApertura | Modal | Seguim cierre apertura |
| 167 | FrmSeguimientoComp | Modal | Seguimiento comprobantes |
| 168 | FrmSeguimientoDoc | Modal | Seguimiento documentos |
| 169 | FrmSeguimientoMovComp | Modal | Seguim mov comprobantes |
| 170 | FrmSeguimientoMovDoc | Modal | Seguim mov documentos |
| 171 | FrmSel14DProPyme | Modal | Seleccion 14D ProPyme |
| 172 | FrmSelBalances | Modeless | Seleccion balances |
| 173 | FrmSelCompTipo | Modal | Sel tipo comprobante |
| 174 | FrmSelEmpresas | Modal | Seleccion empresas |
| 175 | FrmSelEstRes | Modeless | Sel estado resultado |
| 176 | FrmSelImpoOD | Modal | Sel importar OD |
| 177 | FrmSelInfAnalit | Modeless | Sel inf analitico |
| 178 | FrmSelInfIFRS | Modeless | Sel informe IFRS |
| 179 | FrmSelLib14ter | Modal | Sel libro 14 ter |
| 180 | FrmSelLibCaja | Modal | Sel libro caja |
| 181 | FrmSelLibDocs | Modal | Sel libro documentos |
| 182 | FrmSelLibros | Modal | Sel libros |
| 183 | FrmSelRepActFijo | Modal | Sel reporte AF |
| 184 | FrmSelRuta | Modal | Sel ruta |
| 185 | FrmSelSeguimiento | Modal | Sel seguimiento |
| 186 | FrmSincronizacionSII | Modal | Sincronizacion SII |
| 187 | FrmSolicitudSincronizacionesSII | Modal | Solicitud sinc SII |
| 188 | FrmStart | Modeless | Splash screen |
| 189 | FrmSucursal | Modal | Sucursal |
| 190 | FrmSucursales | Modal | Lista sucursales |
| 191 | FrmSumMov | Modal | Sumatoria movimientos |
| 192 | FrmSumSimple | Modal | Sumatoria simple |
| 193 | FrmTipoDocs | Modal | Tipos documentos |
| 194 | FrmTrapasoODToODF | Modal | Traspaso OD a ODF |
| 195 | FrmUnlock | Modal | Desbloquear |

### 9.2 Administrador (29 formularios)

| # | Formulario | Tipo | Descripcion |
|---|------------|------|-------------|
| 1 | FrmBackup1 | Modal | Backup |
| 2 | FrmCrearUsrFiscalizador | Modal | Crear usr fiscalizador |
| 3 | FrmEmpArchivo | Modal | Empresa desde archivo |
| 4 | FrmEmpHR | Modal | Empresa HyperRenta |
| 5 | FrmEmpLpRemu | Modal | Empresa LP Remu |
| 6 | FrmEmpresas | Modal | Lista empresas |
| 7 | FrmEquiposAut | Modal | Equipos autorizados |
| 8 | FrmExportEmp | Modal | Exportar empresa |
| 9 | FrmGenBackup | Modal | Generar backup |
| 10 | FrmidUsuario | Modal | ID usuario |
| 11 | FrmImpEmpresa | Modal | Importar empresa |
| 12 | FrmImportEmpresas | Modal | Importar empresas |
| 13 | FrmInforAyudaEmpresas | Modal | Info ayuda empresas |
| 14 | FrmIntegracionDatosSII | Modal | Integracion datos SII |
| 15 | FrmMain | Modeless | Menu principal admin |
| 16 | FrmMantEmpresa | Modal | Mantener empresa |
| 17 | FrmMantUsuario | Modal | Mantener usuario |
| 18 | FrmPerfiles | Modal | Perfiles seguridad |
| 19 | FrmPrintPreview | Modal | Vista previa |
| 20 | FrmPrtEmpresas | Modal | Imprimir empresas |
| 21 | FrmRepAudCuentasDefinidas | Modal | Rep aud ctas definidas |
| 22 | FrmRepContEmpresas | Modal | Rep cont empresas |
| 23 | FrmReporteControlEmpresas | Modal | Rep control empresas |
| 24 | FrmResetEmprAno | Modal | Reset empresa ano |
| 25 | FrmSelEmpresasNivelEmpresa | Modal | Sel empresas nivel |
| 26 | FrmSelEmpresasTras | Modal | Sel empresas traspaso |
| 27 | FrmUsuarioPriv | Modal | Privilegios usuario |
| 28 | FrmUsuarios | Modal | Lista usuarios |

### 9.3 Comun (9 formularios)

| # | Formulario | Tipo | Descripcion |
|---|------------|------|-------------|
| 1 | FrmCambioClave | Modal | Cambiar clave |
| 2 | FrmDesbloquear | Modal | Desbloquear |
| 3 | FrmEquivalencias | Modal | Equivalencias |
| 4 | FrmFactoresAct | Modal | Factores actualizacion |
| 5 | FrmMantMoneda | Modal | Mantener moneda |
| 6 | FrmMonedas | Modal | Monedas |
| 7 | FrmOficina | Modal | Oficina |
| 8 | FrmPrintPreview | Modal | Vista previa |
| 9 | FrmRazones | Modal | Razones financieras |

### 9.4 VB50 (8 formularios)

| # | Formulario | Tipo | Descripcion |
|---|------------|------|-------------|
| 1 | Calendar | Modal | Calendario |
| 2 | FrmBackup | Modal | Backup |
| 3 | FrmConfigCheque | Modal | Config cheque |
| 4 | FrmDemo | Modal | Demo |
| 5 | FrmHlpBackup | Modal | Ayuda backup |
| 6 | FrmMsgConBreak | Modal | Mensaje con break |
| 7 | FrmPrtCheque | Modal | Imprimir cheque |
| 8 | FrmRepError | Modal | Reportar error |

---

## 10. TOTALES

| Modulo | Cantidad |
|--------|----------|
| HyperContabilidad | 195 |
| Administrador | 28 |
| Comun | 9 |
| VB50 | 8 |
| **TOTAL** | **240** |

---

## 11. MAPA DE DEPENDENCIAS ENTRE FORMULARIOS

Esta sección documenta las relaciones de llamadas entre formularios, indicando desde dónde se llama cada uno, qué método se usa, qué parámetros se envían y si es modal o no.

### 11.1 Leyenda de Métodos

| Método | Descripción | Retorno |
|--------|-------------|---------|
| `.Show vbModal` | Muestra formulario bloqueando la ventana padre | - |
| `.Show vbModeless` | Muestra formulario sin bloquear | - |
| `.FNew(params)` | Crear nuevo registro | vbOK/vbCancel + ID ByRef |
| `.FEdit(params)` | Editar registro existente | vbOK/vbCancel |
| `.FView(params)` | Ver registro (solo lectura) | - |
| `.FSelect(params)` | Seleccionar de lista | vbOK/vbCancel + selección ByRef |
| `.FSelEdit(params)` | Seleccionar o editar | vbOK/vbCancel + datos ByRef |
| `.SelDate(fecha)` | Seleccionar fecha | Fecha ByRef |
| `.TxSelDate(textbox)` | Asignar fecha a TextBox | Modifica TextBox |

---

### 11.2 FrmMain (HyperContabilidad) - Llamadas Salientes

El formulario principal realiza **115 llamadas** a **71 formularios diferentes**.

#### Menú ARCHIVO
| Formulario | Método | Parámetros | Menú Item | Modal |
|------------|--------|------------|-----------|-------|
| FrmSelEmpresas | FSelect | - | Seleccionar Empresa | Modal |
| FrmConfig | Show | - | Configuración | Modal |
| FrmConfigActFijoIFRS | Show | - | Config. Activo Fijo IFRS | Modal |
| FrmConfigCtasAjustes | Show | - | Config. Ctas Ajustes | Modal |
| FrmConfigCtasAjustesRLI | Show | - | Config. Ctas Ajustes RLI | Modal |
| FrmConfigCodIFRS | Show | - | Config. Código IFRS | Modal |
| FrmConfigRemu | Show | - | Config. Remuneraciones | Modal |
| FrmConfigCheque | Show | - | Config. Cheque | Modal |
| FrmMonedas | Show | - | Config. Monedas | Modal |
| FrmFoliacion | Show | - | Config. Hojas Timbraje | Modal |

#### Menú MAESTROS
| Formulario | Método | Parámetros | Menú Item | Modal |
|------------|--------|------------|-----------|-------|
| FrmPlanCuentas | FEdit | - | Plan de Cuentas | Modal |
| FrmLstPlanCuentas | Show | - | Listado Cuentas | Modal |
| FrmEmpresa | FEdit | gEmpresa.Id | Editar Empresa | Modal |
| FrmContEmpresa | Show | - | Contadores Empresa | Modal |
| FrmEntidades | FEdit | - | Entidades Relacionadas | Modal |
| FrmAreaNeg | FEdit | - | Áreas de Negocio | Modal |
| FrmCentrosCosto | FEdit | - | Centros de Costo | Modal |
| FrmEquivalencias | FEdit | 0 | Equivalencias | Modal |
| FrmMantPercepciones | Show | - | Mant. Percepciones | Modal |

#### Menú COMPROBANTES
| Formulario | Método | Parámetros | Menú Item | Modal |
|------------|--------|------------|-----------|-------|
| FrmComprobante | FNew | False | Nuevo Comprobante | Modal |
| FrmLstComp | FView | - | Editar Comprobante | Modal |
| FrmLstComp | FView | - | Listar Comprobantes | Modal |
| FrmLstComp | FPrint | - | Imprimir Comprobante | Modal |
| FrmComprobante | FEdit | IdComp, False | Comp. Apertura Fin/Trib | Modal |
| FrmLstCompTipo | Show | - | Tipos de Comprobante | Modal |

#### Menú DOCUMENTOS
| Formulario | Método | Parámetros | Menú Item | Modal |
|------------|--------|------------|-----------|-------|
| FrmSelLibDocs | FSelect | TipoLib (ByRef), True | Listar Documentos | Modal |
| FrmSelLibDocs | FSelectMes | TipoLib, Mes, Año, False | Nuevo Documento | Modal |
| FrmLstDoc | FView | LIB_OTROS, TipoDoc, Estado, Mes, Año | Cheques a Fecha | Modal |
| FrmLstDoc | FView | LIB_OTROS, TipoDoc, ED_ANULADO, Mes, Año | Cheques Anulados | Modal |
| FrmLstDoc | FView | LIB_OTROS, TipoDoc, ED_PENDIENTE, Mes, Año | Cheques Emitidos | Modal |
| FrmLstDocCuotas | FView | - | Cuotas por Pagar | Modal |

#### Menú BALANCES
| Formulario | Método | Parámetros | Menú Item | Modal |
|------------|--------|------------|-----------|-------|
| FrmBalClasif | FViewBalClasif | - | Balance Clasificado | Modeless |
| FrmBalComprobacion | FView | 0 | Balance Comprobación | Modeless |
| FrmBalTributario | FView | 0 | Balance Tributario | Modal/Modeless |
| FrmBalClasifDesglo | FViewBalClasifDesglo | "AREANEG" | Balance por Área Neg | Modeless |
| FrmBalClasifDesglo | FViewBalClasifDesglo | "CCOSTO" | Balance por CC | Modeless |
| FrmBalClasifCompar | FViewBalClasif | - | Balance Comparativo | Modeless |
| FrmBalClasifEjec | FViewBalClasif | - | Balance Ejecutivo | Modeless |
| FrmBalEjecIFRS | FView | - | Balance Ejec IFRS | Modal |
| FrmBalTributarioIFRS | FView | 0 | Balance Trib IFRS | Modal/Modeless |

#### Menú ESTADOS DE RESULTADOS
| Formulario | Método | Parámetros | Menú Item | Modal |
|------------|--------|------------|-----------|-------|
| FrmBalClasif | FViewEstResultClasif | - | E.R. Clasificado | Modeless |
| FrmBalClasif | FViewEstResultComparativo | - | E.R. Comparativo | Modeless |
| FrmBalClasif | FViewEstResultMensual | - | E.R. Mensual | Modeless |
| FrmBalClasifDesglo | FViewEstResultClasifDesglo | "AREANEG" | E.R. por Área Neg | Modeless |
| FrmBalClasifDesglo | FViewEstResultClasifDesglo | "CCOSTO" | E.R. por CC | Modeless |
| FrmBalClasifCompar | FViewEstResultClasif | - | E.R. Comp Período | Modeless |

#### Menú LIBROS CONTABLES
| Formulario | Método | Parámetros | Menú Item | Modal |
|------------|--------|------------|-----------|-------|
| FrmSelLibros | FSelectMes | - | Selección Libros | Modal |
| FrmSelLibCaja | FSelectOper | - | Editar Libro Caja | Modal |
| FrmLstLibImpresos | Show | - | Libros Impresos | Modal |
| FrmAuditLibContables | FView | - | Auditoría Libros | Modal |
| FrmLibIngEg | Show | - | Libro Ingreso Egreso | Modal |

#### Menú INFORMES ANALÍTICOS
| Formulario | Método | Parámetros | Menú Item | Modal |
|------------|--------|------------|-----------|-------|
| FrmInfAnalitico | FViewPorEntidad | 0 | Inf. por Entidad | Modeless |
| FrmInfAnalitico | FViewPorCuenta | 0 | Inf. por Cuenta | Modeless |
| FrmInfAnaliticoFulle | FViewPorCuenta | 0 | Inf. Cta ODF | Modeless |
| FrmInfAnaliticoFulle | FViewPorEntidad | 0 | Inf. Ent ODF | Modeless |
| FrmResLibAux | FView | - | Resumen Lib Aux | Modal |
| FrmResCartolas | Show | - | Info Cartola Bancaria | Modal |
| FrmInfConciliacion | Show | - | Info Conciliación | Modeless |
| FrmResInfConcil | Show | - | Resumen Conciliación | Modeless |
| FrmInfoVencim | FView | 30/60/90 | Info Vencimiento | Modal |

#### Menú ACTIVO FIJO
| Formulario | Método | Parámetros | Menú Item | Modal |
|------------|--------|------------|-----------|-------|
| FrmLstActFijo | FEdit | - | Mantención Activo Fijo | Modal |
| FrmImpActFijoFile | Show | - | Importar Activo Fijo | Modal |
| FrmImpActFijos | Show | - | Reimportar Activo Fijo | Modal |
| FrmRepActivoFijo | FView | - | Reporte Activo Fijo | Modal |
| FrmRepActFijoIFRS | FView | - | Reporte AF IFRS | Modal |
| FrmSelRepActFijo | Show | - | Selección Rep AF | Modal |

#### Menú TRIBUTARIO
| Formulario | Método | Parámetros | Menú Item | Modal |
|------------|--------|------------|-----------|-------|
| FrmCapPropioSimpl | FView | CPS_TIPOINFO_GENERAL | Cap. Propio Simplif (General) | Modeless |
| FrmCapPropioSimpl | FView | CPS_TIPOINFO_VARANUAL | Cap. Propio Simplif (VarAnual) | Modeless |
| FrmCapitalPropio | FView | - | Capital Propio Tributario | Modeless |
| FrmPropIVA | Show | - | Prop IVA | Modal |
| FrmSel14DProPyme | Show | - | 14 Ter / ProPyme (>=2020) | Modal |
| FrmSelLib14ter | FView | - | 14 Ter (<2020) | Modal |

#### Menú UTILIDADES
| Formulario | Método | Parámetros | Menú Item | Modal |
|------------|--------|------------|-----------|-------|
| FrmCalendar | SelDate | Fecha (ByRef) | Calendario | Modal |
| FrmConverMoneda | Show | - | Convertir Moneda | Modal |
| FrmIPC | Show | - | Índices IPC | Modal |
| FrmCambioClave | Show | - | Cambiar Clave | Modal |
| FrmEstadoMeses | Show | - | Estado Meses | Modal |
| FrmCierreAnual | Show | - | Cierre Anual | Modal |
| FrmImpCartola | Show | - | Importar Cartola | Modal |
| FrmConciliacion | FEdit | - | Conciliación | Modal |
| FrmPrtFoliacion | Show | - | Imprimir Hojas Timb | Modal |
| FrmCalcRazones | Show | - | Calc Razones Financ | Modal |
| FrmRazones | FConfigParam | - | Def Razones Financ | Modal |
| FrmRenum | Show | - | Renumerar | Modal |
| FrmIntTools | Show | - | Herramientas Int | Modal |
| FrmSelSeguimiento | Show | - | Auditoría Seguimiento | Modal |
| FrmTrapasoODToODF | Show | - | Traspaso OD a ODF | Modal |

---

### 11.3 FrmComprobante - Llamadas Salientes

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmLstActFijo | FViewFromComp | IdComp, IdMov | Bt_ActivoFijo_Click | Modal |
| FrmLstDoc | FSelect | LstIdDoc, TipoLib, Estado, True, False | Bt_GenPago_Click | Modal |
| FrmLstDoc | FSelect | LstIdDoc, TipoLib, ED_CENTRALIZADO, True, True | Bt_BuscarDoc_Click | Modal |
| FrmCalendar | SelDate | Fecha (ByRef) | Bt_Calendar_Click | Modal |
| FrmCalendar | TxSelDate | Tx_Fecha | Bt_SelFecha_Click | Modal |
| FrmSelCompTipo | FSelect | IdCompTipo (ByRef) | bt_CompTipo_Click | Modal |
| FrmConverMoneda | FSelect | valor (ByRef) | Bt_ConvMoneda_Click | Modal |
| FrmDoc | FEdit | IdDoc, TipoDoc | Bt_DetMov_Click | Modal |
| FrmDoc | FNew | 0, IdDoc, False, Mes, Año, Valor, IdEnt, TipoLibEnt | Bt_NewDoc_Click | Modal |
| FrmDoc | FView | IdDoc, TipoDoc | Grid_DblClick | Modal |
| FrmGlosas | FSelect | Tx_Glosa / Tx_GlosaCompTipo | Bt_Glosas_Click | Modal |
| FrmPrintPreview | FView | Caption | Bt_Preview_Click | Modal |
| FrmPrtCheque | FPrint | NumCheque, Fecha, Nombre, Ref, Cuenta, Valor, NumEgreso | Bt_PrtCheque_Click | Modal |
| FrmPlanCuentas | FEdit | False | Bt_Cuentas_Click | Modal |
| FrmPlanCuentas | FSelEdit | IdCuenta, Codigo, Desc, Nombre, False | AsignaCuenta | Modal |
| FrmSumMov | FViewSum | Grid, C_DEBE, C_HABER, Row, RowSel | Bt_Sum_Click | Modal |
| FrmPercepciones | Show | (propiedades del form) | Grid_AcceptValue | Modal |
| FrmMsgConBreak | FView | Msg, "NoDispMsgNewComp" | SaveAll | Modal |
| FrmNote | FEdit / FView | Txt | M_AddNote_Click / M_ViewNote_Click | Modal |
| FrmActivoFijo | FNewFromComp | IdComp, IdMov, Fecha, ValNeto, Glosa, IdCuenta | ActivoFijo (función) | Modal |
| FrmLstActFijo | FEditFromComp | IdComp, IdMov, Fecha | ActivoFijo (función) | Modal |

---

### 11.4 FrmLstComp - Llamadas Salientes

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmAuditoria | Show | - | Bt_Auditoria_Click | Modal |
| FrmCalendar | SelDate | Fecha (ByRef) | Bt_Calendar_Click | Modal |
| FrmCalendar | TxSelDate | Tx_Fecha(Index) | Bt_Calendario_Click | Modal |
| FrmCambioEstadoComp | FEdit | NewEstado (ByRef) | Bt_CambiarEstadoComps_Click | Modal |
| FrmConverMoneda | FSelect | valor | Bt_ConvMoneda_Click | Modal |
| FrmPrintPreview | FView | Caption | Bt_Preview_Click | Modal |
| FrmGlosas | FSelect | Tx_Glosa | Bt_Glosas_Click | Modal |
| FrmComprobante | FPrtComp | IdComp | Bt_PrtSelComps_Click (loop) | Modal |
| FrmSumSimple | FViewSum | Grid | Bt_Sum_Click | Modal |
| FrmComprobante | FViewResumido | IdComp | Bt_ViewCompRes_Click | Modal |
| FrmComprobante | FEdit | IdComp, False | ViewDetComp / Grid_DblClick | Modal |

---

### 11.5 FrmDoc - Llamadas Salientes

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmEntidad | FNew | Entidad, AuxRut | Bt_NewEnt_Click | Modal |
| FrmCalendar | TxSelDate | Tx_FEmision | Bt_Fecha_Click (Index=0) | Modal |
| FrmCalendar | TxSelDate | Tx_FVenc | Bt_Fecha_Click (Index=1) | Modal |
| FrmPrtCheque | FPrint | NumCheque, Fecha, Nombre, Ref, Cuenta, Valor, NumEgreso | Bt_PrtCheque_Click | Modal |

---

### 11.6 FrmLstDoc - Llamadas Salientes

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmConverMoneda | FSelect | valor | Bt_ConvMoneda_Click | Modal |
| FrmDocCuotas | FView | IdDoc | Bt_DocCuotas_Click | Modal |
| FrmDoc | FEdit | IdDoc, TipoLib | Bt_ModDoc_Click | Modal |
| FrmDoc | FView | IdDoc, TipoLib | Bt_DetDoc_Click | Modal |
| FrmDoc | FNew | TipoLib, IdDoc, False, Mes, Año | Bt_NewDoc_Click | Modal |
| FrmSelLibDocs | FSelectMes | TipoLib, Mes, Año, True | Bt_NewDoc_Click | Modal |
| FrmCompraVenta | FEdit | TipoLib, Mes, Año, IdDoc | Bt_NewDoc_Click (Compras/Ventas) | Modal |
| FrmLibRetenciones | FEdit | Mes, Año, IdDoc | Bt_NewDoc_Click (Retenciones) | Modal |
| FrmSumSimple | FViewSum | Grid | Bt_Sum_Click | Modal |
| FrmPrintPreview | FView | Caption | Bt_Preview_Click | Modal |
| FrmCalendar | TxSelDate | Tx_FEmision(Index) | Bt_FechaE_Click | Modal |
| FrmCalendar | TxSelDate | Tx_FVenc(Index) | Bt_FechaV_Click | Modal |
| FrmCalendar | SelDate | Fecha (ByRef) | Bt_Calendar_Click | Modal |

---

### 11.7 Formularios de Balances - Llamadas Salientes

#### FrmBalClasif, FrmBalComprobacion, FrmBalTributario, FrmBalClasifEjec

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmEmailAccount | Show | - | Bt_Email_Click | Modeless |
| FrmPrintPreview | FView | Caption | Bt_Preview_Click | Modal |
| FrmPrtSetup | FEdit | Orientación, PapelFoliado, InfoPreliminar | Bt_Print_Click | Modal |
| FrmLibMayor | FViewChain | FDesde, FHasta, IdCuenta, TipoAjuste | Bt_VerLibMayor / Grid_DblClick | Modal |
| FrmSumSimple | FViewSum | Grid | Bt_Sum_Click | Modal |
| FrmConverMoneda | FView | valor | Bt_ConvMoneda_Click | Modal |
| FrmCalendar | SelDate | Fecha (ByRef) | Bt_Calendar_Click | Modal |
| FrmCalendar | TxSelDate | Tx_Desde / Tx_Hasta | Bt_Fecha_Click | Modal |

---

### 11.8 Formularios de Libros Contables - Llamadas Salientes

#### FrmLibDiario

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmCalendar | TxSelDate | Tx_Desde / Tx_Hasta | Bt_Fecha_Click | Modal |
| FrmPrtSetup | FEdit | Orientación, PapelFoliado, InfoPreliminar | Bt_Print_Click | Modal |
| FrmPrintPreview | FView | Caption | Bt_Preview_Click | Modal |
| FrmSumMov | FViewSum | Grid, C_DEBE, C_HABER | Bt_Sum_Click | Modal |
| FrmConverMoneda | FView | valor (ByRef) | Bt_ConvMoneda_Click | Modal |
| FrmCalendar | SelDate | Fecha (ByRef) | Bt_Calendar_Click | Modal |
| FrmComprobante | FView | IdComp, False | Bt_VerComp_Click / Grid_DblClick | Modal |
| FrmDoc | FView | IdDoc | Bt_VerDoc_Click / Grid_DblClick | Modal |

#### FrmLibMayor

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmCalendar | TxSelDate | Tx_Desde / Tx_Hasta | Bt_Fecha_Click | Modal |
| FrmPrintPreview | FView | Caption | Bt_Preview_Click | Modal |
| FrmPrtSetup | FEdit | Orientación, PapelFoliado, InfoPreliminar | Bt_Print_Click | Modal |
| FrmPlanCuentas | FSelect | IdCuenta, Codigo, Nombre, Descrip, False | Bt_SelCuenta_Click | Modal |
| FrmSumMov | FViewSum | Grid, C_DEBITOS, C_CREDITOS | Bt_Sum_Click | Modal |
| FrmConverMoneda | FView | valor (ByRef) | Bt_ConvMoneda_Click | Modal |
| FrmCalendar | SelDate | Fecha (ByRef) | Bt_Calendar_Click | Modal |
| FrmComprobante | FView | IdComp, False | Bt_VerComp_Click | Modal |
| FrmDoc | FView | IdDoc | Bt_VerDoc_Click / Grid_DblClick | Modal |
| FrmLibDiario | FViewChain | IdComp, TipoAjuste | Grid_DblClick (col C_NUMERO) | Modal |

#### FrmLibroCaja

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmDoc | FView | IdDoc | Bt_DetDoc_Click | Modal |
| FrmComprobante | FView | IdComp, False | Bt_DetDoc_Click (si no hay IdDoc) | Modal |
| FrmDocCuotas | FView | IdDoc | Bt_DocCuotas_Click | Modal |
| FrmSalyTotLibCajas | FView | - | Bt_SaldoTotal_Click | Modal |
| FrmEntidades | FSelEdit | Entidad, TipoEnt | Bt_SelEnt_Click | Modal |
| FrmEntidad | FNew | Entidad, Rut | NewEntidad | Modal |
| FrmSumSimple | FViewSum | Grid, Row, RowSel, Col, ColSel | Bt_Sum_Click | Modal |
| FrmPrtSetup | FEdit | Orientación, PapelFoliado, InfoPreliminar | Bt_Print_Click | Modal |
| FrmPrintPreview | FView | Caption | Bt_Preview_Click | Modal |
| FrmConverMoneda | FView | valor (ByRef) | Bt_ConvMoneda_Click | Modal |
| FrmCalendar | SelDate | Fecha (ByRef) | Bt_Calendar_Click | Modal |

#### FrmLibRetenciones

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmFmtImpEnt | FViewLibReten | - | Bt_HlpImport_Click | Modal |
| FrmPrtSetup | FEdit | Orientación, PapelFoliado, InfoPreliminar | Bt_Print_Click / Bt_Preview_Click | Modal |
| FrmPrintPreview | FView | Caption | Bt_Preview_Click | Modal |
| FrmResRet3Porc | FPrtRes / FView | Mes, Año | Bt_Resumen_Click / Bt_Print_Click | Modal |
| FrmComprobante | FEditCentraliz | IdComp, Mes, Año | Bt_Centralizar_Click | Modal |
| FrmPlanCuentas | FEdit / FSelEdit | False / IdCuenta, CodCta, DescCta, NombCta, False | Bt_Cuentas_Click / M_ItCuenta_Click | Modal |
| FrmSumSimple | FViewSum | Grid, Row, RowSel, Col, ColSel | Bt_Sum_Click | Modal |
| FrmConverMoneda | FView | valor (ByRef) | Bt_ConvMoneda_Click | Modal |
| FrmCalendar | SelDate | Fecha (ByRef) | Bt_Calendar_Click | Modal |
| FrmEntidad | FNew | Entidad, Rut | NewEntidad | Modal |
| FrmEntidades | FSelEdit | Entidad, TipoEnt | Bt_SelEnt_Click | Modal |
| FrmDocLib | FView / FEdit | IdDoc | Bt_DetDoc_Click | Modal |

---

### 11.9 FrmConfig - Llamadas Salientes

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmConfigActFijo | Show | - | Bt_ConfigActFijo_Click | Modal |
| FrmConfigCorrComp | Show | - | Bt_ConfigCorrComp_Click | Modal |
| FrmIVA | Show | - | Bt_ConfigIVA_Click | Modal |
| FrmCopyPlan | FCopy | - | Bt_CopyPlan_Click | Modal |
| FrmConfigCtasDef | Show | - | Bt_CtasBasicas_Click | Modal |
| FrmPlanCuentas | FEdit | - | Bt_EditPlan_Click | Modal |
| FrmConfigInformeFirma | Show | - | Bt_Firmas_Click | Modal |
| FrmFmtImpEnt | FViewCuentas / FViewEntidad | - | Bt_FormatCta_Click / Bt_FormatEnt_Click | Modal |
| FrmNiveles | Show | - | Bt_Niveles_Click | Modal |
| FrmConfigInformes | Show | - | Bt_Opciones_Click | Modal |
| frmConfigDefinidasPlanCuenta | Show | - | Bt_PlanCtas_Click (año <> 2019) | Modal |
| frmConfigDefinidasPlanCuenta2019 | Show | - | Bt_PlanCtas_Click (año = 2019) | Modal |
| FrmSaldoApertura | Show | - | Bt_SaldoApert_Click | Modal |
| FrmConfigCodIFRS | Show | - | Cb_PlanCuentas_Click | Modal |
| FrmLstPlanCuentasPreview | Show | - | GenPlanBas / Bt_PlanBasico_Click | Modal |
| FrmPlanCuentas | FViewPlan | PlanCuentas, NombrePlan | VerPlanCuentas | Modal |

---

### 11.10 FrmConfigCtasDef - Llamadas Salientes

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmPlanCuentas | FSelCuentasBasicas | TipoLib, TipoValor | Bt_AsignarCuentas_Click | Modal |
| FrmPlanCuentas | FSelect | IdCuenta, Codigo, Descrip, Nombre | Múltiples botones Bt_* | Modal |
| FrmConfigCtasLibCompras | Show | - | Bt_ConfigDetCtas_Click (Compras) | Modal |
| FrmConfigCtasLibVentas | Show | - | Bt_ConfigDetCtas_Click (Ventas) | Modal |
| FrmConfigImpAdic | FConfig | LIB_COMPRAS / LIB_VENTAS | Bt_ConfigOtrosImp_Click | Modal |

---

### 11.11 Formularios de Activo Fijo - Llamadas Salientes

#### FrmActivoFijo

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmAFCompsFicha | FEdit | IdActFijo | Bt_Componentes_Click | Modal |
| FrmAFFicha | FEdit | IdActFijo | Bt_DetCosto_Click | Modal |
| FrmActFijoInfoAdic | FView / FEdit | IdActFijo, Descrip, DepLey21210, etc. | Bt_InfoAdic_Click | Modal |
| FrmCalendar | TxSelDate | Tx_Fecha / Tx_FechaUtilizacion / Tx_FechaVenta | Bt_Fecha*_Click | Modal |
| FrmRequisitos | FViewCredArt33bis / FViewDecimaParte / FViewDepInstant / FViewLey21210 / FViewLey21256 | - | Tx_requisitos*_Click | Modal |

#### FrmLstActFijo

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmDocLib | FView | IdDoc | Bt_DetDocComp_Click (IdDoc > 0) | Modal |
| FrmComprobante | FView | IdComp, False | Bt_DetDocComp_Click (IdComp > 0) | Modal |
| FrmActivoFijo | FEdit | IdActFijo | Bt_Edit_Click | Modal |
| FrmActivoFijo | FView | IdActFijo | Bt_ViewDet_Click | Modal |
| FrmActivoFijo | FNewFromDocActFijo | IdDoc, Fecha, TipoLib, IdCuenta, IdArea, IdCentro | Bt_New_Click (Compras) | Modal |
| FrmActivoFijo | FNewFromComp | IdComp, IdMov, Fecha, IdCuenta | Bt_New_Click (Comprobante) | Modal |
| FrmMarkActFijo | FEdit | IdActivo | Bt_MarcarExport_Click | Modal |
| FrmCalendar | TxSelDate | Tx_Fecha(Index) | Bt_Fecha_Click | Modal |

#### FrmRepActivoFijo

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmIPC | Show | - | Bt_Indices_Click | Modal |
| FrmSumSimple | FViewSum | Grid | Bt_Sum_Click | Modal |
| FrmConverMoneda | FView | valor | Bt_ConvMoneda_Click | Modal |
| FrmCalendar | SelDate / TxSelDate | Fecha / Tx_Fecha | Bt_Calendar_Click / Bt_Fecha_Click | Modal |
| FrmPrintPreview | FView | Caption | Bt_Preview_Click | Modal |
| FrmDoc | FView | IdDoc | Grid_DblClick / Bt_VerDoc_Click | Modal |
| FrmComprobante | FView | IdComp, False | Grid_DblClick / Bt_VerComp_Click | Modal |
| FrmActivoFijo | FEdit | IdActFijo | Bt_VerActivoFijo_Click | Modal |

#### FrmAFCompsFicha

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmConfigActFijoIFRS | Show | - | Bt_ConfigComp_Click | Modal |

---

### 11.12 FrmCompraVenta - Llamadas Salientes

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmLstActFijo | FViewFromDoc / FEditFromDoc | IdDoc, TipoLib, Fecha | Bt_ActivoFijo_Click / ActivoFijo | Modal |
| FrmPlanCuentas | FEdit / FSelEdit | False / IdCuenta, CodCta, DescCta, NombCta | Bt_Cuentas_Click / M_ItCuenta_Click | Modal |
| FrmDocCuotas | FView / FEdit | IdDoc, FVenc, NumCuotas | Bt_DocCuotas_Click | Modal |
| FrmDocLib | FView / FEdit | IdDoc | Bt_DetDoc_Click | Modal |
| FrmFmtImpEnt | FViewLibCompras / FViewLibVentas | - | Bt_HlpImport_Click | Modal |
| FrmPrintPreview | FView | Caption | Bt_Preview_Click | Modal |
| FrmPrtSetup | FEdit | Orientación, PapelFoliado, InfoPreliminar | Bt_Print_Click | Modal |
| FrmResIVA | FView | Mes, Año, TipoLib | Bt_Resumen_Click | Modal |
| FrmEntidades | FSelEdit | Entidad, TipoEnt | Bt_SelEnt_Click | Modal |
| FrmEntidad | FNew | Entidad, Rut | NewEntidad | Modal |
| FrmConverMoneda | FView | valor | Bt_ConvMoneda_Click | Modal |
| FrmCalendar | SelDate | Fecha (ByRef) | Bt_Calendar_Click | Modal |
| FrmActivoFijo | FNewFromDoc | IdDoc, Fecha, TipoLib, etc. | ActivoFijo | Modal |
| FrmSumSimple | FViewSum | Grid, Row, RowSel, Col, ColSel | Bt_Sum_Click | Modal |

---

### 11.13 FrmInfAnalitico - Llamadas Salientes

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmPrintPreview | FView | Caption | Bt_Preview_Click | Modal |
| FrmPrtSetup | FEdit | Orientación, PapelFoliado, InfoPreliminar | Bt_Print_Click | Modal |
| FrmPlanCuentas | FSelect | IdCuenta, Codigo, Nombre, Descrip, False | Bt_DetCuenta_Click | Modal |
| FrmSumMov | FViewSum | Grid, C_DEBE, C_HABER | Bt_Sum_Click | Modal |
| FrmConverMoneda | FView | valor | Bt_ConvMoneda_Click | Modal |
| FrmCalendar | SelDate / TxSelDate | Fecha / Tx_Hasta / Tx_HastaComp | Bt_Calendar_Click / Bt_Fecha*_Click | Modal |
| FrmComprobante | FView | IdComp, False | Bt_VerComp_Click | Modal |
| FrmDoc | FView | IdDoc | Bt_VerDoc_Click | Modal |

---

### 11.14 FrmConciliacion - Llamadas Salientes

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmImpCartola | Show | - | Bt_ImpCart_Click | Modal |
| FrmPrintPreview | FView | Caption | Bt_Preview_Click | Modal |
| FrmComprobante | FView | IdComp, False | Bt_VerComp_Click | Modal |
| FrmConverMoneda | FSelect | valor | Bt_ConvMoneda_Click | Modal |
| FrmCalendar | SelDate / TxSelDate | Fecha / Tx_Desde / Tx_Hasta | Bt_Calendar_Click / Bt_Fecha_Click | Modal |

---

### 11.15 FrmMain (Administrador) - Llamadas Salientes

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmEmpresas | Show | - | M_MantEmpresas / Bt_Emp | Modal |
| FrmPrtEmpresas | Show | - | M_ListEmpresas | Modal |
| FrmEmpArchivo | FSelect | - | M_ImpEmpArchivo | Modal |
| FrmEmpHR | FSelect | - | M_ImpEmpHR | Modal |
| FrmMantEmpresa | FNew | 0, Rut, NombreCorto | Después de FrmEmpHR | Modal |
| FrmEmpLpRemu | Show | - | M_ImpEmpLpRemuFromAccess | Modeless |
| FrmResetEmprAno | Show | - | M_RemoveEmpAno | Modal |
| FrmRepAudCuentasDefinidas | Show | - | M_RepAudCuentasDefinidas | Modal |
| FrmReporteControlEmpresas | Show | - | M_RepControlEmpresas | Modal |
| FrmCrearUsrFiscalizador | Show | - | MC_CrearUsrFisc | Modal |
| FrmDesbloquear | Show | - | MC_Desbloquear | Modal |
| FrmIntegracionDatosSII | Show | - | MC_ImpDatosSII | Modal |
| FrmOficina | Show | - | MC_Oficina | Modal |
| FrmRazones | FDefinir | - | MC_RazonesFin / Bt_DefRazonesFin | Modal |
| FrmEquiposAut | Admin / Solicitud | - | MC_AutEquipos / MC_SolicCod | Modal |
| FrmPerfiles | ShowPerfiles | True | MC_Perfiles / bt_Perfiles | Modal |
| FrmUsuarioPriv | Show | - | MC_Privilegios / bt_UsuarioPrv | Modal |
| FrmUsuarios | Show | - | MC_Usuarios / bt_Usuarios | Modal |
| FrmMonedas | Show | - | M_ConfigMonedas | Modal |
| FrmEquivalencias | FEdit | 0 | M_Equivalencias | Modal |
| FrmIPC | Show | - | M_Indices / Bt_Indices | Modal |
| FrmCambioClave | Show | - | MC_CambiarClave | Modal |
| FrmAbout | Show | - | MH_AcercaDe | Modal |
| FrmGenBackup | Show | - | M_Backup | Modal |
| FrmBackup | Show | - | MH_HlpBackup | Modal |
| FrmRepError | Show | - | MH_RepError | Modal |
| FrmExportEmp | Show | - | MH_Export | Modal |
| FrmRepContEmpresas | Show | - | M_ContEmpresas | Modal |

---

### 11.16 Formularios del Administrador - Llamadas Salientes

#### FrmEmpresas

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmMantEmpresa | FNew | id, Rut, NCorto (ByRef) | Bt_New_Click | Modal |
| FrmMantEmpresa | FEdit | id, Rut, NCorto, Estado (ByRef) | Bt_Ren_Click | Modal |

#### FrmUsuarios

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmMantUsuario | FNew | Nombre, IdUsuario (ByRef) | Bt_New_Click | Modal |
| FrmMantUsuario | FEdit | Nombre, IdUsuario (ByRef) | Bt_Mod_Click | Modal |

#### FrmPerfiles

*No llama a otros formularios - es autocontenido*

#### FrmMantEmpresa

*No llama a otros formularios - es autocontenido*

#### FrmMantUsuario

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmCalendar | TxSelDate | Tx_Hasta | Bt_Fecha_Click | Modal |

#### FrmCrearUsrFiscalizador

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmCalendar | TxSelDate | Tx_Hasta | Bt_Fecha_Click | Modal |

#### FrmEmpArchivo

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmInforAyudaEmpresas | Show | vbModal | Bt_VerFormato_Click | Modal |

#### FrmEquiposAut

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmEquiposAut (self) | Solicitud | - | Método público - modo solicitud licencia | Modal |
| FrmEquiposAut (self) | Admin | - | Método público - modo administración | Modal |

#### FrmGenBackup, FrmResetEmprAno, FrmUsuarioPriv, FrmExportEmp

*Estos formularios no llaman a otros formularios - son autocontenidos*

---

### 11.17 Formularios Comunes - Llamadas Salientes

#### FrmEquivalencias

*No llama a otros formularios*

#### FrmMonedas

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmMantMoneda | FEdit | Moneda (struct) | Bt_Edit_Click | Modal |
| FrmMantMoneda | FNew | Moneda (ByRef) | Bt_New_Click | Modal |
| FrmEquivalencias | FEdit | IdMoneda | bt_Equivalencia_Click | Modal |

#### FrmRazones

| Formulario | Método | Parámetros | Contexto | Modal |
|------------|--------|------------|----------|-------|
| FrmParamRaz | FEdit | IdRazon | Bt_DefCuentas_Click | Modal |

#### FrmPrintPreview

*No llama a otros formularios*

---

### 11.18 Formularios de Utilidad Común

Los siguientes formularios son llamados desde múltiples lugares del sistema:

| Formulario | Función | Llamadores Principales |
|------------|---------|------------------------|
| FrmCalendar | Selección de fecha | Todos los formularios con fechas |
| FrmConverMoneda | Conversión de moneda | Balances, Informes, Comprobantes |
| FrmPrintPreview | Vista previa de impresión | Balances, Libros, Informes, Reportes |
| FrmPrtSetup | Configuración de impresión | Todos los formularios de impresión |
| FrmPlanCuentas | Selección/Edición de cuentas | Comprobantes, Config, Libros |
| FrmEntidades | Selección/Edición de entidades | Comprobantes, Documentos, Libros |
| FrmSumSimple / FrmSumMov | Sumatoria de grillas | Todos los formularios con grillas |
| FrmGlosas | Selección de glosas | Comprobantes |

---

### 11.19 Índice Inverso: ¿Desde Dónde se Llama Cada Formulario?

#### FrmDoc
| Llamado Desde | Método | Contexto |
|---------------|--------|----------|
| FrmComprobante | FNew, FEdit, FView | Bt_NewDoc, Bt_DetMov, Grid_DblClick |
| FrmLstDoc | FNew, FEdit, FView | Bt_NewDoc, Bt_ModDoc, Bt_DetDoc |
| FrmLibDiario | FView | Bt_VerDoc, Grid_DblClick |
| FrmLibMayor | FView | Bt_VerDoc, Grid_DblClick |
| FrmInfAnalitico | FView | Bt_VerDoc |
| FrmInfAnaliticoFull/Adv/Fulle | FView | Bt_VerDoc |
| FrmInfConciliacion | FView | Bt_VerDoc |
| FrmInfoVencim | FView | Grid_DblClick |
| FrmLibroCaja | FView | Bt_DetDoc |
| FrmRepActivoFijo | FView | Grid_DblClick, Bt_VerDoc |
| FrmLstDocCuotas | FView | Grid_DblClick |

#### FrmComprobante
| Llamado Desde | Método | Contexto |
|---------------|--------|----------|
| FrmMain | FNew, FEdit | M_NewComprob, M_EditCompAp* |
| FrmLstComp | FEdit, FPrtComp, FViewResumido | ViewDetComp, Bt_PrtSelComps, Bt_ViewCompRes |
| FrmLibDiario | FView | Bt_VerComp, Grid_DblClick |
| FrmLibMayor | FView | Bt_VerComp |
| FrmLibroCaja | FView | Bt_DetDoc |
| FrmDocCuotas | FView | Bt_VerComp |
| FrmInfAnalitico | FView | Bt_VerComp |
| FrmConciliacion | FView | Bt_VerComp |
| FrmRepActivoFijo | FView | Grid_DblClick, Bt_VerComp |
| FrmLstActFijo | FView | Bt_DetDocComp |
| FrmLibRetenciones | FEditCentraliz | Bt_Centralizar |

#### FrmPlanCuentas
| Llamado Desde | Método | Contexto |
|---------------|--------|----------|
| FrmMain | FEdit | M_Plan |
| FrmConfig | FEdit, FViewPlan | Bt_EditPlan, VerPlanCuentas |
| FrmConfigCtasDef | FSelect, FSelCuentasBasicas | Múltiples botones |
| FrmComprobante | FEdit, FSelEdit | Bt_Cuentas, AsignaCuenta |
| FrmLibMayor | FSelect | Bt_SelCuenta |
| FrmLibRetenciones | FEdit, FSelEdit | Bt_Cuentas, M_ItCuenta |
| FrmCompraVenta | FEdit, FSelEdit | Bt_Cuentas, M_ItCuenta |
| FrmDocLib | FSelect, FEdit | Grid_DblClick, Bt_Cuentas |
| FrmInfAnalitico | FSelect | Bt_DetCuenta |

#### FrmEntidades
| Llamado Desde | Método | Contexto |
|---------------|--------|----------|
| FrmMain | FEdit | M_EntRel |
| FrmLibroCaja | FSelEdit | Bt_SelEnt |
| FrmLibRetenciones | FSelEdit | Bt_SelEnt |
| FrmCompraVenta | FSelEdit | Bt_SelEnt |
| FrmDocLib | FEdit | Bt_Entidades |

#### FrmLstActFijo
| Llamado Desde | Método | Contexto |
|---------------|--------|----------|
| FrmMain | FEdit | M_ActFijo |
| FrmComprobante | FViewFromComp, FEditFromComp | Bt_ActivoFijo, ActivoFijo |
| FrmCompraVenta | FViewFromDoc, FEditFromDoc | Bt_ActivoFijo, ActivoFijo |
| FrmDocLib | FViewFromDoc, FEditFromDoc | Bt_ActivoFijo |

#### FrmActivoFijo
| Llamado Desde | Método | Contexto |
|---------------|--------|----------|
| FrmLstActFijo | FEdit, FView, FNewFromComp, FNewFromDocActFijo | Bt_Edit, Bt_ViewDet, Bt_New |
| FrmComprobante | FNewFromComp | ActivoFijo |
| FrmCompraVenta | FNewFromDoc | ActivoFijo |
| FrmRepActivoFijo | FEdit | Bt_VerActivoFijo |

#### FrmCalendar
| Llamado Desde | Método | Contexto |
|---------------|--------|----------|
| FrmMain | SelDate | M_Calendario |
| FrmComprobante | SelDate, TxSelDate | Bt_Calendar, Bt_SelFecha |
| FrmLstComp | SelDate, TxSelDate | Bt_Calendar, Bt_Calendario |
| FrmDoc | TxSelDate | Bt_Fecha (Index 0,1) |
| FrmLstDoc | SelDate, TxSelDate | Bt_Calendar, Bt_FechaE, Bt_FechaV |
| FrmBalClasif/Comprobacion/Tributario | SelDate, TxSelDate | Bt_Calendar, Bt_Fecha |
| FrmLibDiario/Mayor/Caja | SelDate, TxSelDate | Bt_Calendar, Bt_Fecha |
| FrmLibRetenciones | SelDate | Bt_Calendar |
| FrmInfAnalitico | SelDate, TxSelDate | Bt_Calendar, Bt_Fecha |
| FrmConciliacion | SelDate, TxSelDate | Bt_Calendar, Bt_Fecha |
| FrmActivoFijo | TxSelDate | Bt_Fecha* |
| FrmLstActFijo | TxSelDate | Bt_Fecha |
| FrmRepActivoFijo | SelDate, TxSelDate | Bt_Calendar, Bt_Fecha |
| FrmMantUsuario | TxSelDate | Bt_Fecha |
| FrmCrearUsrFiscalizador | TxSelDate | Bt_Fecha |

#### FrmPrintPreview
| Llamado Desde | Método | Contexto |
|---------------|--------|----------|
| FrmComprobante | FView | Bt_Preview |
| FrmLstComp | FView | Bt_Preview |
| FrmLstDoc | FView | Bt_Preview |
| FrmBalClasif/Comprobacion/Tributario/Ejec | FView | Bt_Preview |
| FrmLibDiario/Mayor/Caja/Retenciones | FView | Bt_Preview |
| FrmInfAnalitico/Full/Adv/Fulle | FView | Bt_Preview |
| FrmCompraVenta | FView | Bt_Preview |
| FrmConciliacion | FView | Bt_Preview |
| FrmRepActivoFijo/IFRS | FView | Bt_Preview |
| FrmResIVA/LibAux/Cartolas | FView | Bt_Preview |

#### FrmConverMoneda
| Llamado Desde | Método | Contexto |
|---------------|--------|----------|
| FrmMain | Show | M_ConvMoneda |
| FrmComprobante | FSelect | Bt_ConvMoneda |
| FrmLstComp | FSelect | Bt_ConvMoneda |
| FrmLstDoc | FSelect | Bt_ConvMoneda |
| FrmBalClasif/Comprobacion/Tributario | FView | Bt_ConvMoneda |
| FrmLibDiario/Mayor/Caja/Retenciones | FView | Bt_ConvMoneda |
| FrmInfAnalitico | FView | Bt_ConvMoneda |
| FrmConciliacion | FSelect | Bt_ConvMoneda |
| FrmCompraVenta | FView | Bt_ConvMoneda |
| FrmRepActivoFijo | FView | Bt_ConvMoneda |

#### FrmSumSimple / FrmSumMov
| Llamado Desde | Método | Contexto |
|---------------|--------|----------|
| FrmLstComp | FViewSum | Bt_Sum |
| FrmLstDoc | FViewSum | Bt_Sum |
| FrmBalClasif/Comprobacion/Tributario | FViewSum | Bt_Sum |
| FrmLibDiario | FViewSum (FrmSumMov) | Bt_Sum |
| FrmLibMayor | FViewSum (FrmSumMov) | Bt_Sum |
| FrmLibroCaja | FViewSum | Bt_Sum |
| FrmLibRetenciones | FViewSum | Bt_Sum |
| FrmInfAnalitico | FViewSum (FrmSumMov) | Bt_Sum |
| FrmCompraVenta | FViewSum | Bt_Sum |
| FrmComprobante | FViewSum (FrmSumMov) | Bt_Sum |
| FrmRepActivoFijo | FViewSum | Bt_Sum |

#### FrmMantEmpresa
| Llamado Desde | Método | Contexto |
|---------------|--------|----------|
| FrmEmpresas | FNew, FEdit | Bt_New, Bt_Ren |
| FrmMain (Admin) | FNew | Después de FrmEmpHR |

#### FrmMantUsuario
| Llamado Desde | Método | Contexto |
|---------------|--------|----------|
| FrmUsuarios | FNew, FEdit | Bt_New, Bt_Mod |

---

## 12. TOTALES ACTUALIZADOS

| Módulo | Cantidad Formularios | Llamadas Salientes (aprox) |
|--------|---------------------|---------------------------|
| HyperContabilidad | 195 | 450+ |
| Administrador | 28 | 40 |
| Común | 9 | 5 |
| VB50 | 8 | 0 |
| **TOTAL** | **240** | **495+** |

### Formularios más referenciados (llamados desde múltiples lugares)

| Formulario | Veces Referenciado | Función Principal |
|------------|-------------------|-------------------|
| FrmCalendar | 15+ | Selección de fechas |
| FrmPrintPreview | 12+ | Vista previa de impresión |
| FrmConverMoneda | 10+ | Conversión de moneda |
| FrmSumSimple/SumMov | 11+ | Sumatoria de grillas |
| FrmPlanCuentas | 9+ | Selección/Edición de cuentas |
| FrmDoc | 11+ | Gestión de documentos |
| FrmComprobante | 10+ | Gestión de comprobantes |
| FrmEntidades | 5+ | Selección/Edición de entidades |
| FrmPrtSetup | 8+ | Configuración de impresión |

### Formularios autocontenidos (sin llamadas salientes)

Los siguientes formularios no llaman a otros formularios y son terminales en la navegación:

- **Administrador**: FrmPerfiles, FrmMantEmpresa, FrmGenBackup, FrmResetEmprAno, FrmUsuarioPriv, FrmExportEmp
- **Común**: FrmEquivalencias, FrmPrintPreview
- **VB50**: Todos los formularios de este módulo

---

## 13. MAPA COMPLETO DE FORMULARIOS RESTANTES

Esta sección documenta TODOS los formularios que faltaban en el mapa de dependencias.

### 13.1 Formularios de Exportación (FrmExp*)

| Formulario | Llamadas Salientes | Llamado Desde |
|------------|-------------------|---------------|
| FrmExpDJAnual | FrmDatosDJ1847.FEdit | FrmMain (M_ExpHRRAB, M_ExpHRRAD, M_Exp1847, etc.) |
| FrmExpEntidades | *Autocontenido* | FrmMain (M_ExpEntidades) |
| FrmExpF22 | FrmPrintPreview.FView, FrmCapitalPropio, FrmBalTributario | FrmMain (M_ExpF22) |
| FrmExpF29 | *Autocontenido* | FrmMain (M_ExpF29) |
| FrmExpHRCertif | *Autocontenido* | FrmMain (M_ExpHRCertif) |
| FrmExpPercepciones | *Autocontenido* | FrmMain (M_ExpPercepciones) |

### 13.2 Formularios de Importación (FrmImp*)

| Formulario | Llamadas Salientes | Llamado Desde |
|------------|-------------------|---------------|
| FrmImpAreaNegocio | FrmAreaNeg.FEdit, FrmFmtImpEnt.FViewAreaNegocio | FrmMain |
| FrmImpCentroCosto | FrmCentrosCosto.FEdit, FrmFmtImpEnt.FViewCentroCosto | FrmMain |
| FrmImpComp | FrmFmtImpEnt.FViewComprobantes | FrmMain (M_ImpComp) |
| FrmImpExpLib | *Autocontenido (Me.Show)* | FrmMain (M_ImpExpLib, M_ExpLib) |
| FrmImpFacturacion | *Autocontenido* | FrmMain (M_ImpFact) |
| FrmImpSucursales | FrmSucursales.FEdit, FrmFmtImpEnt.FViewSucursales | FrmMain |
| FrmImpLibComprasSII | *Autocontenido* | FrmMain (M_ImpLibComprasSII) |
| FrmImpLibVentasSII | FrmInfoAyuda.FView | FrmMain (M_ImpLibVentasSII) |
| FrmImpLibRetencionesSII | *Autocontenido* | FrmMain (M_ImpLibRetenSII) |
| FrmImportF29 | *Autocontenido* | FrmMain (M_ImpF29) |
| FrmImportRemu | FrmComprobante.FEditCentraliz | FrmMain (M_ImpRemu) |
| FrmImpOtrosDocs | FrmFmtImpEnt.FViewOtrosDocs | FrmSelImpoOD |
| FrmImpOtrosDocFull | FrmFmtImpEnt.FViewOtrosDocFull | FrmSelImpoOD |

### 13.3 Formularios de Selección (FrmSel*)

| Formulario | Llamadas Salientes | Llamado Desde |
|------------|-------------------|---------------|
| FrmSelBalances | FrmBalComprobacion.FView, FrmBalTributario.FView, FrmBalClasif.FViewBalClasif, FrmBalClasifCompar.FViewBalClasif, FrmBalClasifEjec.FViewBalClasif, FrmLstInformeIFRS.FView | FrmMainSQLServer (Bt_Balances) |
| FrmSelEstRes | FrmBalClasif.FViewEstResultClasif/Mensual/Comparativo, FrmBalClasifCompar.FViewEstResultClasif, FrmLstInformeIFRS.FView | FrmMainSQLServer |
| FrmSelImpoOD | FrmImpOtrosDocs.Show, FrmImpOtrosDocFull.Show | FrmMain (M_SelImpoOD) |
| FrmSelInfAnalit | FrmInfAnalitico.FViewPorEntidad/FViewPorCuenta | FrmMainSQLServer |
| FrmSelInfIFRS | FrmLstInformeIFRS.FView, FrmBalEjecIFRS.FView, FrmBalTributarioIFRS.FView | FrmMainSQLServer |
| FrmSelLib14ter | FrmSelLibCaja.FSelectOper, FrmLibCaja.FView, FrmLibIngEg.Show, FrmAjustesExtraLibCaja.Show, FrmBaseImponible14DFull.Show, FrmBaseImponible.Show, FrmAsistImpPrimCat.Show | FrmMain (M_14ter) |
| FrmSelRuta | *Autocontenido (Me.Show)* | FrmMain (Admin), FrmEmpLpRemu |

### 13.4 Formularios de Detalle (FrmDet*)

| Formulario | Llamadas Salientes | Llamado Desde |
|------------|-------------------|---------------|
| FrmDetBaseImponible14DFull | FrmPrintPreview.FView, FrmSumSimple.FViewSum, FrmConverMoneda.FView, FrmCalendar | FrmBaseImponible14DFull |
| FrmDetCapPropioSimpl | FrmDetCapPropioSimplAcum.FEdit, FrmPrintPreview.FView, FrmSumSimple.FViewSum, FrmConverMoneda.FView, FrmCalendar, FrmComprobante.FView | FrmCapPropioSimpl |
| FrmDetCapPropioSimplAcum | FrmPrintPreview.FView, FrmSumSimple.FViewSum, FrmConverMoneda.FView, FrmCalendar | FrmDetCapPropioSimpl, FrmDetCapPropioSimplMini, FrmBaseImponible14D |
| FrmDetCapPropioSimplMini | FrmDetCapPropioSimplAcum.FEdit, FrmAyuda.FViewOtrosAjustes*, FrmPrintPreview.FView, FrmSumSimple.FViewSum, FrmConverMoneda.FView, FrmCalendar | FrmCapPropioSimpl |
| FrmDetSaldoAp | FrmPrintPreview.FView, FrmSumMov.FViewSum, FrmConverMoneda.FView, FrmCalendar, FrmEntidades, FrmEntidad.FNew | FrmSaldoApertura |

### 13.5 Formularios de Seguimiento (FrmSeguimiento*)

| Formulario | Llamadas Salientes | Llamado Desde |
|------------|-------------------|---------------|
| FrmSeguimientoCierreApertura | FrmCalendar (x2), FrmPrintPreview.FView | FrmSelSeguimiento |
| FrmSeguimientoComp | FrmCalendar (x3), FrmSeguimientoMovComp.Show, FrmComprobante.FView, FrmPrintPreview.FView | FrmSelSeguimiento |
| FrmSeguimientoDoc | FrmCalendar (x3), FrmSeguimientoMovDoc.Show, FrmComprobante.FView, FrmPrintPreview.FView | FrmSelSeguimiento |
| FrmSeguimientoMovComp | FrmPrintPreview.FView | FrmSeguimientoComp |
| FrmSeguimientoMovDoc | FrmPrintPreview.FView | FrmSeguimientoDoc |

### 13.6 Formularios de Resumen/Reporte (FrmRes*, FrmRep*)

| Formulario | Llamadas Salientes | Llamado Desde |
|------------|-------------------|---------------|
| FrmResDocs | FrmSumSimple.FViewSum, FrmPrintPreview.FView, FrmConverMoneda.FView, FrmCalendar (x2), FrmDocLib.FView | FrmMain (M_ResSuper, M_ResVPE) |
| FrmResOtrosImp | FrmResLibAux.Show | FrmCompraVenta |
| FrmRevDetDocs | *Autocontenido* | FrmLstDoc |
| FrmRepPorNivel | FrmCalendar | FrmBalClasif |

### 13.7 Formularios de Configuración Restantes (FrmConfig*)

| Formulario | Llamadas Salientes | Llamado Desde |
|------------|-------------------|---------------|
| FrmConfigFUT | FrmPlanCuentas.FSelect, FrmLstConfigFUT.Show | FrmMain (comentado) |
| FrmConfigCompActFijo | FrmComprobante.FNewCompActivo, FrmPlanCuentas.FSelect | FrmAFCompsFicha |
| FrmConfigActFijo | *Autocontenido* | FrmConfig |
| FrmConfigCorrComp | *Autocontenido (Me.Show)* | FrmConfig |

### 13.8 Formularios Auxiliares HyperContabilidad

| Formulario | Llamadas Salientes | Llamado Desde |
|------------|-------------------|---------------|
| FrmAjustesExtraLibCaja | FrmLibCaja.FView, FrmRepActivoFijo.FView, FrmPrtSetup.FEdit, FrmPrintPreview.FView, FrmSumSimple.FViewSum, FrmConverMoneda.FView, FrmCalendar | FrmSelLib14ter, FrmAsistImpPrimCat |
| FrmAjustesExtraLibCajaRLI | FrmPrintPreview.FView, FrmSumSimple.FViewSum, FrmConverMoneda.FView, FrmCalendar | FrmMain (M_AjustesRLI) |
| FrmANeg | *Autocontenido (Me.Show)* | FrmAreaNeg |
| FrmApertura | FrmPlanCuentas.FEdit (x3) | FrmCierreAnual |
| FrmAsisPPM | FrmCalendar, FrmConverMoneda.FView, FrmPrintPreview.FView (x2), FrmPrtSetup.FEdit, FrmSumSimple.FViewSum (x2) | FrmBaseImponible14DFull |
| FrmAsistImpPrimCat | FrmBaseImponible.Show, FrmAjustesExtraLibCaja.Show, FrmPrintPreview.FView, FrmSumSimple.FViewSum, FrmConverMoneda.FView, FrmCalendar | FrmSelLib14ter |
| FrmAyuda | *Autocontenido (Me.Show)* | FrmDetCapPropioSimplMini |
| FrmBaseImponible | FrmPrtSetup.FEdit, FrmPrintPreview.FView, FrmSumSimple.FViewSum, FrmConverMoneda.FView, FrmCalendar | FrmSelLib14ter, FrmAsistImpPrimCat |
| FrmBaseImponible14D | FrmDetCapPropioSimplAcum.FEdit, FrmPrintPreview.FView, FrmSumSimple.FViewSum, FrmConverMoneda.FView, FrmCalendar, FrmBaseImponible14DFull.FEdit | FrmCapPropioSimpl |
| FrmBaseImponible14DFull | FrmPrintPreview.FView, FrmSumSimple.FViewSum, FrmConverMoneda.FView, FrmCalendar, FrmDetBaseImponible14DFull.FEdit, FrmAsisPPM.Show | FrmSelLib14ter, FrmBaseImponible14D |
| FrmCCosto | *Autocontenido (Me.Show)* | FrmCentrosCosto |
| FrmComponente | *Autocontenido (Me.Show)* | FrmAFCompsFicha |
| FrmCopiarSincronizacion | *Autocontenido* | FrmSincronizacionSII |
| FrmCuenta | FrmConfigCodIFRS.Show | FrmPlanCuentas, FrmListadoPlanCuentas |
| FrmDatosDJ1847 | *Autocontenido (Me.Show)* | FrmExpDJAnual |
| FrmEditarSincronizacion | FrmSolicitudSincronizacionesSII | FrmSolicitudSincronizacionesSII |
| FrmEjemploImport | *Autocontenido (Me.Show)* | FrmImpComp |
| FrmGlosasUpdate | *Autocontenido (Me.Show)* | FrmGlosas |
| FrmGrupo | *Autocontenido (Me.Show)* | FrmPlanCuentas |
| FrmHelpCred33bis | *Autocontenido* | FrmRequisitos |
| FrmHelpImpCartola | *Autocontenido* | FrmImpCartola |
| FrmIdUser | *Autocontenido* | Sub Main (LpContMain.bas) |
| FrmInfoAyuda | FrmFmtImpEnt.FViewLibVentas | FrmImpLibVentasSII |
| FrmLibElectCompras | *Autocontenido (Me.Show)* | FrmMain (M_LibElectCompras) |
| FrmLibInvBal | FrmPrintPreview.FView, FrmPrtSetup.FEdit, FrmSumMov.FViewSum, FrmConverMoneda.FView, FrmCalendar (x2) | FrmMain (M_LibInvBal) |
| FrmListadoPlanCuentas | FrmCuenta.FEdit, FrmPrintPreview.FView, FrmLstAtrib.Show | FrmPlanCuentas |
| FrmLstAtrib | *Autocontenido* | FrmListadoPlanCuentas |
| FrmLstInformeIFRS | FrmEmailAccount.FEdit, FrmPrintPreview.FView, FrmMsgConBreak.FView, FrmCalendar (x2), FrmSumSimple.FViewSum, FrmConverMoneda.FView | FrmMain, FrmSelBalances, FrmSelEstRes, FrmSelInfIFRS |
| FrmMainSQLServer | *Ver FrmMain - versión SQL Server con mismas llamadas* | Sub Main (SQL Server) |
| FrmParamRaz | FrmPlanCuentas.FSelect | FrmRazones |
| FrmSincronizacionSII | FrmCopiarSincronizacion.Show, FrmSolicitudSincronizacionesSII.Show | FrmMain |
| FrmSolicitudSincronizacionesSII | FrmEditarSincronizacion.FEdit, FrmPrintPreview.FView | FrmSincronizacionSII, FrmEditarSincronizacion |
| FrmStart | *Autocontenido* | Sub Main |
| FrmSucursal | *Autocontenido (Me.Show)* | FrmSucursales |
| FrmTipoDocs | *Autocontenido* | FrmMain (M_TipoDocs) |
| FrmUnlock | *Autocontenido* | FrmMain (M_Unlock) |
| FrmInfAnaliticoAdv | FrmPrintPreview.FView, FrmSumMov.FViewSum, FrmConverMoneda.FView, FrmCalendar (x3), FrmComprobante.FView, FrmDoc.FView | FrmMain |
| FrmInfAnaliticoFull | FrmPrintPreview.FView, FrmPrtSetup.FEdit, FrmPlanCuentas.FSelect, FrmSumMov.FViewSum, FrmConverMoneda.FView, FrmCalendar (x3), FrmComprobante.FView, FrmDoc.FView | FrmMain |
| FrmCapitalAportado | FrmPrintPreview.FView, FrmSumSimple.FViewSum, FrmConverMoneda.FView, FrmCalendar | FrmCapitalPropio |

### 13.9 Formularios VB50 (Componentes Reutilizables)

| Formulario | Llamadas Salientes | Llamado Desde |
|------------|-------------------|---------------|
| Calendar (FrmCalendar) | *Autocontenido (Me.Show)* | 50+ formularios (selector de fechas universal) |
| FrmBackup | *Autocontenido* | FrmMain (MH_HlpBackup) |
| FrmConfigCheque | *Autocontenido* | FrmMain (M_ConfigCheque) |
| FrmDemo | *Autocontenido* | Modo demo |
| FrmHlpBackup | *Autocontenido* | FrmBackup |
| FrmMsgConBreak | *Autocontenido (Me.Show)* | FrmComprobante, FrmLstInformeIFRS |
| FrmPrtCheque | *Autocontenido (Me.Show)* | FrmComprobante, FrmDoc |
| FrmRepError | *Autocontenido* | FrmMain (MH_RepError) |

### 13.10 Formularios Administrador Restantes

| Formulario | Llamadas Salientes | Llamado Desde |
|------------|-------------------|---------------|
| FrmBackup1 | *Autocontenido* | FrmMain Admin |
| FrmEmpLpRemu | FrmSelRuta (x5) | FrmMain Admin (M_ImpEmpLpRemu) |
| FrmidUsuario | *Autocontenido (Me.Show)* | Sub Main (Administrador.bas) |
| FrmImpEmpresa | FrmFmtImpEnt.FView | FrmMain Admin |
| FrmImportEmpresas | *Autocontenido* | FrmMain Admin |
| FrmInforAyudaEmpresas | *Autocontenido (Me.Show)* | FrmEmpArchivo |
| FrmIntegracionDatosSII | *Autocontenido* | FrmMain Admin (MC_ImpDatosSII) |
| FrmSelEmpresasNivelEmpresa | FrmSelEmpresasTras.FSelect | FrmMain Admin (M_ImpEmpFromAccess) |
| FrmSelEmpresasTras | *Autocontenido (Me.Show)* | FrmSelEmpresasNivelEmpresa |

### 13.11 Formularios Comunes Restantes

| Formulario | Llamadas Salientes | Llamado Desde |
|------------|-------------------|---------------|
| FrmDesbloquear | *Autocontenido* | FrmMain Admin (MC_Desbloquear) |
| FrmFactoresAct | *Autocontenido (Me.Show)* | FrmConfig |
| FrmOficina | *Autocontenido* | FrmMain Admin (MC_Oficina) |

---

## 14. GUÍA DE USO DEL MAPA

### ¿Cómo encontrar la ruta de navegación a un formulario?

1. **Buscar en el Índice Inverso** (Sección 11.19): Localiza el formulario destino y verás todos los formularios que lo llaman.

2. **Trazar la ruta hacia atrás**: Desde cada formulario llamador, busca en las secciones 11.2-11.18 para ver quién lo llama a él.

3. **Continuar hasta FrmMain**: Eventualmente llegarás a FrmMain (HyperContabilidad o Administrador) que es el punto de entrada.

### Ejemplo: ¿Cómo llegar a FrmActivoFijo?

```
FrmMain (HyperContabilidad)
    └── M_ActFijo → FrmLstActFijo.FEdit
                        └── Bt_Edit → FrmActivoFijo.FEdit(IdActFijo)
```

O alternativamente:
```
FrmMain → M_NewComprob → FrmComprobante.FNew
                              └── ActivoFijo() → FrmActivoFijo.FNewFromComp(...)
```

### Ejemplo: ¿Cómo llegar a FrmMantUsuario?

```
FrmMain (Administrador)
    └── MC_Usuarios → FrmUsuarios.Show vbModal
                          └── Bt_New → FrmMantUsuario.FNew(Nombre, IdUsuario)
```

---

*Documento generado automáticamente - TR Contabilidad VB6*
*Fecha: Noviembre 2025*
*Actualizado con Mapa de Dependencias 100% Completo*
*Total de formularios mapeados: 240/240 (100%)*
*Total de relaciones documentadas: 600+*
