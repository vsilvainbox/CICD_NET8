﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Regiones
{
    public int Id { get; set; }

    public string? CODIGO { get; set; }

    public string? COMUNA { get; set; }
}
