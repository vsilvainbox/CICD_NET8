﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Notas
{
    public string? Tipo { get; set; }

    public int? IdEmpresa { get; set; }

    public string? Nota { get; set; }

    public short? Incluir { get; set; }

    public bool? IncluirInfo { get; set; }
}
