﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Auditoria_Cuentas_Definidas
{
    public int id { get; set; }

    public int? idEmpresa { get; set; }

    public int? ano { get; set; }

    public string? configuracion { get; set; }

    public string? tipoPlan { get; set; }

    public string? evento { get; set; }

    public string? cta_asociado { get; set; }

    public string? codigo { get; set; }

    public string? descripcion { get; set; }

    public DateTime fecha { get; set; }

    public int? idUsuario { get; set; }
}
