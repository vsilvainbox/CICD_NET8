﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class AjusteIVAMensual
{
    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public byte? Mes { get; set; }

    public double? Valor { get; set; }
}
