﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Entidades
{
    public int IdEntidad { get; set; }

    public int? IdEmpresa { get; set; }

    public string? Rut { get; set; }

    public string? Codigo { get; set; }

    public string? Nombre { get; set; }

    public string? Direccion { get; set; }

    public short? Region { get; set; }

    public short? Comuna { get; set; }

    public string? Ciudad { get; set; }

    public string? Telefonos { get; set; }

    public string? Fax { get; set; }

    public int? ActEcon { get; set; }

    public string? CodActEcon { get; set; }

    public string? DomPostal { get; set; }

    public short? ComPostal { get; set; }

    public string? Email { get; set; }

    public string? Web { get; set; }

    public byte? Estado { get; set; }

    public string? Obs { get; set; }

    public byte? Clasif0 { get; set; }

    public byte? Clasif1 { get; set; }

    public byte? Clasif2 { get; set; }

    public byte? Clasif3 { get; set; }

    public byte? Clasif4 { get; set; }

    public byte? Clasif5 { get; set; }

    public string? Giro { get; set; }

    public bool? NotValidRut { get; set; }

    public bool? EsSupermercado { get; set; }

    public bool? EntRelacionada { get; set; }

    public string? CodCtaAfecto { get; set; }

    public string? CodCtaExento { get; set; }

    public string? CodCtaTotal { get; set; }

    public short? PropIVA { get; set; }

    public string? CodCCostoAfecto { get; set; }

    public string? CodAreaNegAfecto { get; set; }

    public string? CodCCostoExento { get; set; }

    public string? CodAreaNegExento { get; set; }

    public string? CodCCostoTotal { get; set; }

    public string? CodAreaNegTotal { get; set; }

    public string? CodCtaAfectoVta { get; set; }

    public string? CodCtaExentoVta { get; set; }

    public string? CodCtaTotalVta { get; set; }

    public string? CodCCostoAfectoVta { get; set; }

    public string? CodAreaNegAfectoVta { get; set; }

    public string? CodCCostoExentoVta { get; set; }

    public string? CodAreaNegExentoVta { get; set; }

    public string? CodCCostoTotalVta { get; set; }

    public string? CodAreaNegTotalVta { get; set; }

    public bool? EsDelGiro { get; set; }

    public byte? FranqTribEnt { get; set; }

    public bool? Ret3Porc { get; set; }

    public int? FDesde3Porc { get; set; }

    public int? FHasta3Porc { get; set; }
}
