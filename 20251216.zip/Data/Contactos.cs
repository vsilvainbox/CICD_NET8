﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Contactos
{
    public int idContacto { get; set; }

    public int? IdEmpresa { get; set; }

    public int? idEntidad { get; set; }

    public string? Nombre { get; set; }

    public string? Telefono { get; set; }

    public string? Cargo { get; set; }
}
