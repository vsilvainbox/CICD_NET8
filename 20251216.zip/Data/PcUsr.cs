﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class PcUsr
{
    public string? PC { get; set; }

    public string? Usr { get; set; }

    public int? Pid { get; set; }
}
