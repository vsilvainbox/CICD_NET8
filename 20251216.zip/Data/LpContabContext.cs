﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using App.Data;

namespace App.Data;

public partial class LpContabContext : DbContext
{
    public LpContabContext(DbContextOptions<LpContabContext> options)
        : base(options)
    {
    }

    public virtual DbSet<AFComponentes> AFComponentes { get; set; }

    public virtual DbSet<AFGrupos> AFGrupos { get; set; }

    public virtual DbSet<ActFijoCompsFicha> ActFijoCompsFicha { get; set; }

    public virtual DbSet<ActFijoFicha> ActFijoFicha { get; set; }

    public virtual DbSet<AjusteIVAMensual> AjusteIVAMensual { get; set; }

    public virtual DbSet<AjustesExtLibCaja> AjustesExtLibCaja { get; set; }

    public virtual DbSet<AreaNegocio> AreaNegocio { get; set; }

    public virtual DbSet<AsistImpPrimCat> AsistImpPrimCat { get; set; }

    public virtual DbSet<Auditoria_Cuentas_Definidas> Auditoria_Cuentas_Definidas { get; set; }

    public virtual DbSet<Auditoria_Empresas> Auditoria_Empresas { get; set; }

    public virtual DbSet<BaseImponible14D> BaseImponible14D { get; set; }

    public virtual DbSet<BaseImponible14Ter> BaseImponible14Ter { get; set; }

    public virtual DbSet<CT_Comprobante> CT_Comprobante { get; set; }

    public virtual DbSet<CT_ComprobanteBase> CT_ComprobanteBase { get; set; }

    public virtual DbSet<CT_MovComprobante> CT_MovComprobante { get; set; }

    public virtual DbSet<CT_MovComprobanteBase> CT_MovComprobanteBase { get; set; }

    public virtual DbSet<CapPropioSimplAnual> CapPropioSimplAnual { get; set; }

    public virtual DbSet<Cartola> Cartola { get; set; }

    public virtual DbSet<CentroCosto> CentroCosto { get; set; }

    public virtual DbSet<CodActiv> CodActiv { get; set; }

    public virtual DbSet<Colores> Colores { get; set; }

    public virtual DbSet<Comprobante> Comprobante { get; set; }

    public virtual DbSet<ConfiguraSincronizacionSII> ConfiguraSincronizacionSII { get; set; }

    public virtual DbSet<Contactos> Contactos { get; set; }

    public virtual DbSet<ControlEmpresa> ControlEmpresa { get; set; }

    public virtual DbSet<CtasAjustesExCont> CtasAjustesExCont { get; set; }

    public virtual DbSet<CtasAjustesExContRLI> CtasAjustesExContRLI { get; set; }

    public virtual DbSet<Cuentas> Cuentas { get; set; }

    public virtual DbSet<CuentasBasicas> CuentasBasicas { get; set; }

    public virtual DbSet<CuentasRazon> CuentasRazon { get; set; }

    public virtual DbSet<DetCapPropioSimpl> DetCapPropioSimpl { get; set; }

    public virtual DbSet<DetCartola> DetCartola { get; set; }

    public virtual DbSet<DetPercepciones> DetPercepciones { get; set; }

    public virtual DbSet<DetSaldosAp> DetSaldosAp { get; set; }

    public virtual DbSet<DocCuotas> DocCuotas { get; set; }

    public virtual DbSet<Documento> Documento { get; set; }

    public virtual DbSet<Empresa> Empresa { get; set; }

    public virtual DbSet<Empresas> Empresas { get; set; }

    public virtual DbSet<EmpresasAno> EmpresasAno { get; set; }

    public virtual DbSet<Entidades> Entidades { get; set; }

    public virtual DbSet<Equipos> Equipos { get; set; }

    public virtual DbSet<Equivalencia> Equivalencia { get; set; }

    public virtual DbSet<ErrorLog> ErrorLog { get; set; }

    public virtual DbSet<ActivityLog> ActivityLog { get; set; }

    public virtual DbSet<EstadoMes> EstadoMes { get; set; }

    public virtual DbSet<FactorActAnual> FactorActAnual { get; set; }

    public virtual DbSet<Firmas> Firmas { get; set; }

    public virtual DbSet<Glosas> Glosas { get; set; }

    public virtual DbSet<IFRS_PlanIFRS> IFRS_PlanIFRS { get; set; }

    public virtual DbSet<IPC> IPC { get; set; }

    public virtual DbSet<ImpAdic> ImpAdic { get; set; }

    public virtual DbSet<Impuestos> Impuestos { get; set; }

    public virtual DbSet<InfoAnualDJ1847> InfoAnualDJ1847 { get; set; }

    public virtual DbSet<LParam> LParam { get; set; }

    public virtual DbSet<LibroCaja> LibroCaja { get; set; }

    public virtual DbSet<LockAction> LockAction { get; set; }

    public virtual DbSet<LogComprobantes> LogComprobantes { get; set; }

    public virtual DbSet<LogImpreso> LogImpreso { get; set; }

    public virtual DbSet<Membrete> Membrete { get; set; }

    public virtual DbSet<Monedas> Monedas { get; set; }

    public virtual DbSet<MovActivoFijo> MovActivoFijo { get; set; }

    public virtual DbSet<MovComprobante> MovComprobante { get; set; }

    public virtual DbSet<MovDocumento> MovDocumento { get; set; }

    public virtual DbSet<Notas> Notas { get; set; }

    public virtual DbSet<Param> Param { get; set; }

    public virtual DbSet<ParamEmpresa> ParamEmpresa { get; set; }

    public virtual DbSet<ParamRazon> ParamRazon { get; set; }

    public virtual DbSet<PcUsr> PcUsr { get; set; }

    public virtual DbSet<Percepciones> Percepciones { get; set; }

    public virtual DbSet<Perfiles> Perfiles { get; set; }

    public virtual DbSet<PlanAvanzado> PlanAvanzado { get; set; }

    public virtual DbSet<PlanBasico> PlanBasico { get; set; }

    public virtual DbSet<PlanCuentasSII> PlanCuentasSII { get; set; }

    public virtual DbSet<PlanIntermedio> PlanIntermedio { get; set; }

    public virtual DbSet<PropIVA_TotMensual> PropIVA_TotMensual { get; set; }

    public virtual DbSet<RazonesFin> RazonesFin { get; set; }

    public virtual DbSet<Regiones> Regiones { get; set; }

    public virtual DbSet<Socios> Socios { get; set; }

    public virtual DbSet<Sucursales> Sucursales { get; set; }

    public virtual DbSet<Timbraje> Timbraje { get; set; }

    public virtual DbSet<TipoDocs> TipoDocs { get; set; }

    public virtual DbSet<TipoValor> TipoValor { get; set; }

    public virtual DbSet<Tracking_AperturaCierre> Tracking_AperturaCierre { get; set; }

    public virtual DbSet<Tracking_Comprobante> Tracking_Comprobante { get; set; }

    public virtual DbSet<Tracking_Documento> Tracking_Documento { get; set; }

    public virtual DbSet<Tracking_MovComprobante> Tracking_MovComprobante { get; set; }

    public virtual DbSet<Tracking_MovDocumento> Tracking_MovDocumento { get; set; }

    public virtual DbSet<UsuarioEmpresa> UsuarioEmpresa { get; set; }

    public virtual DbSet<Usuarios> Usuarios { get; set; }

    public virtual DbSet<tbl_Comp_Centra_Full> tbl_Comp_Centra_Full { get; set; }

    public virtual DbSet<tmp_CRISTINACASTILL_qc__4304> tmp_CRISTINACASTILL_qc__4304 { get; set; }

    public virtual DbSet<vMovCompIdDoc> vMovCompIdDoc { get; set; }

    public virtual DbSet<vPrimeraDocCuota> vPrimeraDocCuota { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.UseCollation("Modern_Spanish_CI_AS");

        modelBuilder.Entity<AFComponentes>(entity =>
        {
            entity.HasKey(e => e.IdComp).HasName("AFComponentes_IdxComp_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.IdGrupo }, "IdGrupo");

            entity.HasIndex(e => new { e.IdEmpresa, e.NombComp }, "IdxNombre").IsUnique();

            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
            entity.Property(e => e.NombComp)
                .HasMaxLength(30)
                .IsUnicode(false);
        });

        modelBuilder.Entity<AFGrupos>(entity =>
        {
            entity.HasKey(e => e.IdGrupo).HasName("AFGrupos_IdxGrupo_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.NombGrupo }, "IdxNombre").IsUnique();

            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
            entity.Property(e => e.NombGrupo)
                .HasMaxLength(15)
                .IsUnicode(false);
        });

        modelBuilder.Entity<ActFijoCompsFicha>(entity =>
        {
            entity.HasKey(e => e.IdCompFicha).HasName("ActFijoCompsFicha_Idx_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.IdActFijo, e.IdComp }, "IdxActFijo").IsUnique();

            entity.Property(e => e.Ano).HasDefaultValue((short)0);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
        });

        modelBuilder.Entity<ActFijoFicha>(entity =>
        {
            entity.HasKey(e => e.IdFicha).HasName("ActFijoFicha_Idx_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.IdActFijo }, "IdxActFijo").IsUnique();

            entity.Property(e => e.Ano).HasDefaultValue((short)0);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
        });

        modelBuilder.Entity<AjusteIVAMensual>(entity =>
        {
            entity.HasNoKey();
        });

        modelBuilder.Entity<AjustesExtLibCaja>(entity =>
        {
            entity.HasKey(e => e.IdAjustesExtLibCaja).HasName("AjustesExtLibCaja_Idx_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.TipoAjuste, e.IdItemAjuste }, "IdxItem").IsUnique();

            entity.Property(e => e.IdAjustesExtLibCaja).ValueGeneratedNever();
            entity.Property(e => e.Ano).HasDefaultValue((short)0);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
        });

        modelBuilder.Entity<AreaNegocio>(entity =>
        {
            entity.HasKey(e => e.IdAreaNegocio).HasName("AreaNegocio_Id_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.Codigo }, "Nombre").IsUnique();

            entity.Property(e => e.Codigo)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.Descripcion)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.IdEmpresa).HasDefaultValue((short)0);
        });

        modelBuilder.Entity<AsistImpPrimCat>(entity =>
        {
            entity.HasKey(e => e.IdAsistImpPrimCat).HasName("AsistImpPrimCat_Idx_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdItem }, "IdxItem").IsUnique();

            entity.Property(e => e.IdAsistImpPrimCat).ValueGeneratedNever();
            entity.Property(e => e.Ano).HasDefaultValue((short)0);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
        });

        modelBuilder.Entity<Auditoria_Cuentas_Definidas>(entity =>
        {
            entity.HasKey(e => e.id).HasName("PK__Auditori__3213E83F2DF46384");

            entity.HasIndex(e => new { e.idEmpresa, e.ano, e.fecha, e.idUsuario }, "Idx_Auditoria_Cuentas_Definidas").IsUnique();

            entity.Property(e => e.codigo)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.configuracion)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.cta_asociado).IsUnicode(false);
            entity.Property(e => e.descripcion)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.evento)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.fecha).HasColumnType("datetime");
            entity.Property(e => e.tipoPlan)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Auditoria_Empresas>(entity =>
        {
            entity.HasKey(e => e.id).HasName("PK__Auditori__3213E83F5718A24D");

            entity.HasIndex(e => new { e.idEmpresa, e.Annio, e.Fecha_Evento, e.Usuario }, "Idx_Auditoria_Empresas").IsUnique();

            entity.Property(e => e.Descripcion).IsUnicode(false);
            entity.Property(e => e.Fecha_Evento).HasColumnType("datetime");
            entity.Property(e => e.Modulo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Nombre_Empresa)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Rut)
                .HasMaxLength(12)
                .IsUnicode(false);
            entity.Property(e => e.Tipo_Evento)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.Usuario)
                .HasMaxLength(10)
                .IsUnicode(false);
        });

        modelBuilder.Entity<BaseImponible14D>(entity =>
        {
            entity.HasKey(e => e.IdBaseImponible14D).HasName("IdxBaseImponible14D");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.Codigo, e.Fecha }, "IdxEmpAno");
        });

        modelBuilder.Entity<BaseImponible14Ter>(entity =>
        {
            entity.HasKey(e => e.IdBaseImponible14Ter).HasName("BaseImponible14Ter_Idx_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.TipoBaseImp, e.IdItemBaseImp }, "IdxItem").IsUnique();

            entity.Property(e => e.IdBaseImponible14Ter).ValueGeneratedNever();
            entity.Property(e => e.Ano).HasDefaultValue((short)0);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
        });

        modelBuilder.Entity<CT_Comprobante>(entity =>
        {
            entity.HasKey(e => e.IdComp).HasName("CT_Comprobante_IdComp_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.Glosa }, "Glosa");

            entity.HasIndex(e => new { e.IdEmpresa, e.Tipo }, "Tipo");

            entity.Property(e => e.Correlativo).HasDefaultValue(0);
            entity.Property(e => e.Descrip)
                .HasMaxLength(40)
                .IsUnicode(false);
            entity.Property(e => e.Estado).HasDefaultValue((byte)0);
            entity.Property(e => e.Fecha).HasDefaultValue(0);
            entity.Property(e => e.Glosa)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.IdCompOld).HasDefaultValue(0);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
            entity.Property(e => e.IdUsuario).HasDefaultValue(0);
            entity.Property(e => e.Nombre)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.Tipo).HasDefaultValue((byte)0);
            entity.Property(e => e.TotalDebe).HasDefaultValue(0.0);
            entity.Property(e => e.TotalHaber).HasDefaultValue(0.0);
        });

        modelBuilder.Entity<CT_ComprobanteBase>(entity =>
        {
            entity.HasKey(e => e.IdComp).HasName("CT_ComprobanteBase_IdComp_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.Glosa }, "Glosa");

            entity.HasIndex(e => new { e.IdEmpresa, e.Tipo }, "Tipo");

            entity.Property(e => e.Correlativo).HasDefaultValue(0);
            entity.Property(e => e.Descrip)
                .HasMaxLength(40)
                .IsUnicode(false);
            entity.Property(e => e.Estado).HasDefaultValue((byte)0);
            entity.Property(e => e.Fecha).HasDefaultValue(0);
            entity.Property(e => e.Glosa)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
            entity.Property(e => e.IdUsuario).HasDefaultValue(0);
            entity.Property(e => e.Nombre)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.Tipo).HasDefaultValue((byte)0);
            entity.Property(e => e.TotalDebe).HasDefaultValue(0.0);
            entity.Property(e => e.TotalHaber).HasDefaultValue(0.0);
        });

        modelBuilder.Entity<CT_MovComprobante>(entity =>
        {
            entity.HasKey(e => e.IdMov).HasName("CT_MovComprobante_IdMov_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.IdComp }, "IdxIdComp");

            entity.Property(e => e.CodCuenta)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.Debe).HasDefaultValue(0.0);
            entity.Property(e => e.Glosa)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Haber).HasDefaultValue(0.0);
            entity.Property(e => e.IdAreaNeg).HasDefaultValue(0);
            entity.Property(e => e.IdCCosto).HasDefaultValue(0);
            entity.Property(e => e.IdComp).HasDefaultValue(0);
            entity.Property(e => e.IdCuenta).HasDefaultValue(0);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
        });

        modelBuilder.Entity<CT_MovComprobanteBase>(entity =>
        {
            entity.HasKey(e => e.IdMov).HasName("CT_MovComprobanteBase_IdMov_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.IdComp }, "IdxIdComp");

            entity.Property(e => e.CodCuenta)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.Debe).HasDefaultValue(0.0);
            entity.Property(e => e.Glosa)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Haber).HasDefaultValue(0.0);
            entity.Property(e => e.IdAreaNeg).HasDefaultValue(0);
            entity.Property(e => e.IdCCosto).HasDefaultValue(0);
            entity.Property(e => e.IdComp).HasDefaultValue(0);
            entity.Property(e => e.IdCuenta).HasDefaultValue(0);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
            entity.Property(e => e.Orden).HasDefaultValue((byte)0);
        });

        modelBuilder.Entity<CapPropioSimplAnual>(entity =>
        {
            entity.HasKey(e => e.IdCapPropioSimplAnual).HasName("IdxCapPropioSimplAnual");

            entity.HasIndex(e => new { e.IdEmpresa, e.TipoDetCPS, e.AnoValor }, "IdxEmpCapAnual").IsUnique();
        });

        modelBuilder.Entity<Cartola>(entity =>
        {
            entity.HasKey(e => e.IdCartola).HasName("Cartola_IdCartola_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdCuentaBco }, "IdCuentaBco");

            entity.Property(e => e.Ano).HasDefaultValue((short)0);
            entity.Property(e => e.Cartola1)
                .HasDefaultValue((short)0)
                .HasColumnName("Cartola");
            entity.Property(e => e.FDesde).HasDefaultValue(0);
            entity.Property(e => e.FHasta).HasDefaultValue(0);
            entity.Property(e => e.IdCuentaBco).HasDefaultValue(0);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
            entity.Property(e => e.TotAbono).HasDefaultValue(0.0);
            entity.Property(e => e.TotCargo).HasDefaultValue(0.0);
        });

        modelBuilder.Entity<CentroCosto>(entity =>
        {
            entity.HasKey(e => e.IdCCosto).HasName("CentroCosto_Id_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.Codigo }, "Nombre").IsUnique();

            entity.Property(e => e.Codigo)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.Descripcion)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
        });

        modelBuilder.Entity<CodActiv>(entity =>
        {
            entity.HasKey(e => e.Codigo).HasName("CodActiv_Codigo_PK");

            entity.Property(e => e.Codigo)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.Descrip)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.OldCodigo)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsFixedLength();
        });

        modelBuilder.Entity<Colores>(entity =>
        {
            entity.HasKey(e => new { e.IdEmpresa, e.Nivel }).HasName("Colores_IdxEmpresa_PK");

            entity.Property(e => e.Color).HasDefaultValue(0);
        });

        modelBuilder.Entity<Comprobante>(entity =>
        {
            entity.HasKey(e => e.IdComp).HasName("Comprobante_IdComp_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.Correlativo }, "Correlativo");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.Estado }, "Estado");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.Fecha }, "Fecha");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.Glosa }, "Glosa");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdUsuario }, "IdUsuario");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.Tipo }, "Tipo");

            entity.HasIndex(e => new { e.IdComp, e.IdEmpresa, e.Ano }, "idx_Comp_ComTipo");

            entity.Property(e => e.Ano).HasDefaultValue((short)0);
            entity.Property(e => e.Correlativo).HasDefaultValue(0);
            entity.Property(e => e.Estado).HasDefaultValue((byte)0);
            entity.Property(e => e.Fecha).HasDefaultValue(0);
            entity.Property(e => e.FechaCreacion).HasDefaultValue(0);
            entity.Property(e => e.Glosa)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
            entity.Property(e => e.IdUsuario).HasDefaultValue(0);
            entity.Property(e => e.Tipo).HasDefaultValue((byte)0);
            entity.Property(e => e.TotalDebe).HasDefaultValue(0.0);
            entity.Property(e => e.TotalHaber).HasDefaultValue(0.0);
        });

        modelBuilder.Entity<ConfiguraSincronizacionSII>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Configur__3214EC076CEFCC6F");

            entity.Property(e => e.Contador).HasDefaultValue(0);
            entity.Property(e => e.Fecha_Creacion).HasColumnType("datetime");
            entity.Property(e => e.Fecha_Ejecucion).HasColumnType("datetime");
            entity.Property(e => e.Fecha_Sincroniza).HasColumnType("datetime");
            entity.Property(e => e.Tipo_Libro)
                .HasMaxLength(20)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Contactos>(entity =>
        {
            entity.HasKey(e => e.idContacto).HasName("Contactos_Id_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.idEntidad }, "IdEnt");

            entity.Property(e => e.Cargo)
                .HasMaxLength(25)
                .IsUnicode(false);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
            entity.Property(e => e.Nombre)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Telefono)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.idEntidad).HasDefaultValue(0);
        });

        modelBuilder.Entity<ControlEmpresa>(entity =>
        {
            entity.HasKey(e => new { e.IdEmpresa, e.Ano });

            entity.Property(e => e.RUT)
                .HasMaxLength(12)
                .IsUnicode(false);
            entity.Property(e => e.RazonSocial)
                .HasMaxLength(200)
                .IsUnicode(false);
        });

        modelBuilder.Entity<CtasAjustesExCont>(entity =>
        {
            entity.HasKey(e => e.IdCtaAjustes).HasName("CtasAjustesExCont_IdCtaAjustes_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.TipoAjuste, e.IdItem }, "IdItem");

            entity.Property(e => e.Ano).HasDefaultValue((short)0);
            entity.Property(e => e.CodCuenta)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
        });

        modelBuilder.Entity<CtasAjustesExContRLI>(entity =>
        {
            entity.HasKey(e => e.IdCtaAjustesRLI).HasName("Idx");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.TipoAjuste, e.IdGrupo, e.IdItem }, "IdxItem");

            entity.Property(e => e.CodCuenta)
                .HasMaxLength(15)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Cuentas>(entity =>
        {
            entity.HasKey(e => new { e.IdEmpresa, e.Ano, e.idCuenta });

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.Clasificacion }, "Clasificacion");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.Codigo }, "Codigo").IsUnique();

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.Nivel }, "Nivel");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.Nombre }, "Nombre");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.idPadre }, "idPadre");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.idCuenta, e.Codigo }, "idx_Cuentas_ComTipo");

            entity.Property(e => e.idCuenta).ValueGeneratedOnAdd();
            entity.Property(e => e.Atrib1).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib10).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib2).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib3).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib4).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib5).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib6).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib7).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib8).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib9).HasDefaultValue((byte)0);
            entity.Property(e => e.Clasificacion).HasDefaultValue((byte)0);
            entity.Property(e => e.CodCtaPlanSII)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.CodF22).HasDefaultValue((short)0);
            entity.Property(e => e.CodFECU)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodIFRS)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodIFRS_EstFin)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodIFRS_EstRes)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.Codigo)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.Debe).HasDefaultValue(0.0);
            entity.Property(e => e.Descripcion)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Estado).HasDefaultValue((byte)0);
            entity.Property(e => e.Haber).HasDefaultValue(0.0);
            entity.Property(e => e.IdCuentaOld).HasDefaultValue(0);
            entity.Property(e => e.IdPadreOld).HasDefaultValue(0);
            entity.Property(e => e.MarcaApertura).HasDefaultValue((short)0);
            entity.Property(e => e.Nivel).HasDefaultValue((byte)0);
            entity.Property(e => e.Nombre)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.TipoCapPropio).HasDefaultValue(0);
            entity.Property(e => e.TipoPlan)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.idPadre).HasDefaultValue(0);
        });

        modelBuilder.Entity<CuentasBasicas>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("CuentasBasicas_Id_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdCuenta }, "IdCuenta");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.Tipo, e.TipoLib, e.TipoValor }, "Tipo");

            entity.Property(e => e.Ano).HasDefaultValue((short)0);
            entity.Property(e => e.IdCuenta).HasDefaultValue(0);
            entity.Property(e => e.IdCuentaOld).HasDefaultValue(0);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
            entity.Property(e => e.Tipo).HasDefaultValue((short)0);
            entity.Property(e => e.TipoLib).HasDefaultValue((short)0);
            entity.Property(e => e.TipoValor).HasDefaultValue((short)0);
        });

        modelBuilder.Entity<CuentasRazon>(entity =>
        {
            entity.HasNoKey();

            entity.HasIndex(e => new { e.IdEmpresa, e.IdRazon }, "IdRazon");

            entity.Property(e => e.CodCuenta)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
            entity.Property(e => e.Operador)
                .HasMaxLength(1)
                .IsUnicode(false)
                .IsFixedLength();
        });

        modelBuilder.Entity<DetCapPropioSimpl>(entity =>
        {
            entity.HasKey(e => e.IdDetCapPropioSimpl).HasName("IdxDetCapPropioSimpl");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.TipoDetCPS, e.IngresoManual, e.Fecha, e.CodCuenta }, "IdxEmpAno");

            entity.Property(e => e.CodCuenta)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.Descrip)
                .HasMaxLength(80)
                .IsUnicode(false);
        });

        modelBuilder.Entity<DetCartola>(entity =>
        {
            entity.HasKey(e => e.IdDetCartola).HasName("DetCartola_IdDetCartola_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdCartola }, "IdCartola");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdMov }, "IdMov");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.NumDoc }, "NumDoc");

            entity.Property(e => e.Abono).HasDefaultValue(0.0);
            entity.Property(e => e.Ano).HasDefaultValue((short)0);
            entity.Property(e => e.Cargo).HasDefaultValue(0.0);
            entity.Property(e => e.Detalle)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Fecha).HasDefaultValue(0);
            entity.Property(e => e.IdCartola).HasDefaultValue(0);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
            entity.Property(e => e.IdMov).HasDefaultValue(0);
            entity.Property(e => e.NumDoc)
                .HasDefaultValue(0m)
                .HasColumnType("numeric(18, 0)");
        });

        modelBuilder.Entity<DetPercepciones>(entity =>
        {
            entity.HasKey(e => new { e.IDPerc, e.CodDet }).HasName("PK__DetPerce__80C60325A152BBC2");

            entity.Property(e => e.IDPerc).HasColumnType("numeric(18, 0)");
            entity.Property(e => e.CodDet).HasColumnType("numeric(18, 0)");
            entity.Property(e => e.Valor).HasColumnType("numeric(18, 0)");
        });

        modelBuilder.Entity<DetSaldosAp>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("DetSaldosAp_Id_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdCuenta, e.IdEntidad }, "IdEntidad").IsUnique();

            entity.Property(e => e.Ano).HasDefaultValue((short)0);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
        });

        modelBuilder.Entity<DocCuotas>(entity =>
        {
            entity.HasKey(e => e.IdDocCuota).HasName("DocCuotas_Idx_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdCompPago }, "IdCompPago");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdLibCaja }, "IdLibCaja");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.Estado }, "IdxEstado");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdDoc }, "IdxIdDoc");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.NumCuota }, "NumCuota");

            entity.Property(e => e.Ano).HasDefaultValue((short)0);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
        });

        modelBuilder.Entity<Documento>(entity =>
        {
            entity.HasKey(e => e.IdDoc).HasName("Documento_IdDoc_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdCompCent }, "IdComp");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdCompPago }, "IdCompPago");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdDocAsoc }, "IdDocAsoc");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdSucursal }, "IdSucursal");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.TipoLib, e.TipoDoc, e.NumDoc, e.IdEntidad, e.DTE }, "IdxDoc");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.TipoLib, e.FEmision }, "IdxFechaEmi");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.TipoLib, e.FEmisionOri }, "IdxFechaEmiOri");

            entity.HasIndex(e => e.Ano, "idx_AnoDOC");

            entity.HasIndex(e => e.Exento, "idx_Exento");

            entity.HasIndex(e => e.FEmision, "idx_FEmision");

            entity.HasIndex(e => e.IdEmpresa, "idx_IdEmpresa");

            entity.HasIndex(e => e.PorcentRetencion, "idx_PorcentRetencion");

            entity.HasIndex(e => e.TipoLib, "idx_TipoLibDoc");

            entity.HasIndex(e => e.TipoRetencion, "idx_TipoRetencion");

            entity.Property(e => e.Afecto).HasDefaultValue(0.0);
            entity.Property(e => e.Ano).HasDefaultValue((short)0);
            entity.Property(e => e.CodCtaAfectoOld)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodCtaExentoOld)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodCtaTotalOld)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.Descrip)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Estado).HasDefaultValue((short)0);
            entity.Property(e => e.Exento).HasDefaultValue(0.0);
            entity.Property(e => e.FEmision).HasDefaultValue(0);
            entity.Property(e => e.FVenc).HasDefaultValue(0);
            entity.Property(e => e.FechaCreacion).HasDefaultValue(0);
            entity.Property(e => e.IVA).HasDefaultValue(0.0);
            entity.Property(e => e.IdANegCCosto)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.IdCompCent).HasDefaultValue(0);
            entity.Property(e => e.IdCompPago).HasDefaultValue(0);
            entity.Property(e => e.IdCuentaAfecto).HasDefaultValue(0);
            entity.Property(e => e.IdCuentaExento).HasDefaultValue(0);
            entity.Property(e => e.IdCuentaIVA).HasDefaultValue(0);
            entity.Property(e => e.IdCuentaOtroImp).HasDefaultValue(0);
            entity.Property(e => e.IdCuentaTotal).HasDefaultValue(0);
            entity.Property(e => e.IdEntidad).HasDefaultValue(0);
            entity.Property(e => e.IdUsuario).HasDefaultValue(0);
            entity.Property(e => e.NombreEntidad)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.NumDoc)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasDefaultValueSql("((0))");
            entity.Property(e => e.NumDocAsoc)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.NumDocHasta)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasDefaultValueSql("((0))");
            entity.Property(e => e.NumDocRef)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.NumFiscImpr)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.NumInformeZ)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.OtroImp).HasDefaultValue(0.0);
            entity.Property(e => e.RutEntidad)
                .HasMaxLength(12)
                .IsUnicode(false);
            entity.Property(e => e.TipoDoc).HasDefaultValue((byte)0);
            entity.Property(e => e.TipoEntidad).HasDefaultValue((short)0);
            entity.Property(e => e.TipoLib).HasDefaultValue((byte)0);
            entity.Property(e => e.Total).HasDefaultValue(0.0);
            entity.Property(e => e.UrlDTE)
                .HasMaxLength(250)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Empresa>(entity =>
        {
            entity.HasKey(e => new { e.Id, e.Ano }).HasName("Empresa_IdxEmpresa_PK");

            entity.Property(e => e.ActEconom).HasDefaultValue((short)0);
            entity.Property(e => e.ApMaterno)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.ApPaterno)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Calle)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Celular).HasColumnType("numeric(18, 0)");
            entity.Property(e => e.Ciudad)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.CodActEconom)
                .HasMaxLength(8)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.CodArea).HasColumnType("numeric(18, 0)");
            entity.Property(e => e.Comuna).HasDefaultValue(0);
            entity.Property(e => e.ComunaPostal).HasDefaultValue((short)0);
            entity.Property(e => e.Contador)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.DomPostal)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Dpto)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Fax)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.FechaConstitucion).HasDefaultValue(0);
            entity.Property(e => e.FechaInicioAct).HasDefaultValue(0);
            entity.Property(e => e.Giro)
                .HasMaxLength(80)
                .IsUnicode(false);
            entity.Property(e => e.Nombre)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.NombreCorto)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Numero)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.RazonSocial)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.Region).HasDefaultValue((short)0);
            entity.Property(e => e.RepLegal1)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.RepLegal2)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Rut)
                .HasMaxLength(12)
                .IsUnicode(false);
            entity.Property(e => e.RutContador)
                .HasMaxLength(12)
                .IsUnicode(false);
            entity.Property(e => e.RutRepLegal1)
                .HasMaxLength(12)
                .IsUnicode(false)
                .HasDefaultValueSql("((0))");
            entity.Property(e => e.RutRepLegal2)
                .HasMaxLength(12)
                .IsUnicode(false)
                .HasDefaultValueSql("((0))");
            entity.Property(e => e.Telefonos)
                .HasMaxLength(35)
                .IsUnicode(false);
            entity.Property(e => e.Villa)
                .HasMaxLength(80)
                .IsUnicode(false);
            entity.Property(e => e.Web)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Empresas>(entity =>
        {
            entity.HasKey(e => e.IdEmpresa).HasName("Empresas_IdEmpresa_PK");

            entity.HasIndex(e => e.NombreCorto, "NombreCorto").IsUnique();

            entity.HasIndex(e => e.Rut, "Rut").IsUnique();

            entity.Property(e => e.ClaveSII)
                .HasMaxLength(30)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.Estado).HasDefaultValue((byte)0);
            entity.Property(e => e.NombreCorto)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Rut)
                .HasMaxLength(12)
                .IsUnicode(false);
            entity.Property(e => e.RutDisp)
                .HasMaxLength(20)
                .IsUnicode(false);
        });

        modelBuilder.Entity<EmpresasAno>(entity =>
        {
            entity.HasKey(e => new { e.idEmpresa, e.Ano }).HasName("EmpresasAno_Id_PK");

            entity.Property(e => e.FApertura).HasDefaultValue(0);
            entity.Property(e => e.FCierre).HasDefaultValue(0);
            entity.Property(e => e.NCompAper).HasDefaultValue(0);
            entity.Property(e => e.NCompAperProx).HasDefaultValue(0);
        });

        modelBuilder.Entity<Entidades>(entity =>
        {
            entity.HasKey(e => e.IdEntidad).HasName("Entidades_IdEntidad_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.Codigo }, "Codigo").IsUnique();

            entity.HasIndex(e => new { e.IdEmpresa, e.Rut }, "Rut").IsUnique();

            entity.Property(e => e.ActEcon).HasDefaultValue(0);
            entity.Property(e => e.Ciudad)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Clasif0).HasDefaultValue((byte)0);
            entity.Property(e => e.Clasif1).HasDefaultValue((byte)0);
            entity.Property(e => e.Clasif2).HasDefaultValue((byte)0);
            entity.Property(e => e.Clasif3).HasDefaultValue((byte)0);
            entity.Property(e => e.Clasif4).HasDefaultValue((byte)0);
            entity.Property(e => e.Clasif5).HasDefaultValue((byte)0);
            entity.Property(e => e.CodActEcon)
                .HasMaxLength(8)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.CodAreaNegAfecto)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodAreaNegAfectoVta)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodAreaNegExento)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodAreaNegExentoVta)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodAreaNegTotal)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodAreaNegTotalVta)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodCCostoAfecto)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodCCostoAfectoVta)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodCCostoExento)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodCCostoExentoVta)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodCCostoTotal)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodCCostoTotalVta)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodCtaAfecto)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodCtaAfectoVta)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodCtaExento)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodCtaExentoVta)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodCtaTotal)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodCtaTotalVta)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.Codigo)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.ComPostal).HasDefaultValue((short)0);
            entity.Property(e => e.Comuna).HasDefaultValue((short)0);
            entity.Property(e => e.Direccion)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.DomPostal)
                .HasMaxLength(35)
                .IsUnicode(false);
            entity.Property(e => e.Email)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Estado).HasDefaultValue((byte)0);
            entity.Property(e => e.Fax)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.Giro)
                .HasMaxLength(80)
                .IsUnicode(false);
            entity.Property(e => e.Nombre)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Obs)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.Region).HasDefaultValue((short)0);
            entity.Property(e => e.Rut)
                .HasMaxLength(12)
                .IsUnicode(false);
            entity.Property(e => e.Telefonos)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Web)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Equipos>(entity =>
        {
            entity.HasKey(e => new { e.PC, e.MAC, e.CodPC }).HasName("Equipos_PC_MAC_COD_PK");

            entity.Property(e => e.PC)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MAC)
                .HasMaxLength(18)
                .IsUnicode(false);
            entity.Property(e => e.CodPC)
                .HasMaxLength(15)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Equivalencia>(entity =>
        {
            entity.HasNoKey();

            entity.HasIndex(e => new { e.idMoneda, e.Fecha }, "Id").IsUnique();

            entity.Property(e => e.Fecha).HasDefaultValue(0);
            entity.Property(e => e.Valor).HasDefaultValue(0.0);
            entity.Property(e => e.idMoneda).HasDefaultValue(0);
        });

        modelBuilder.Entity<ErrorLog>(entity =>
        {
            entity.HasKey(e => e.IdError).HasName("PK__ErrorLog__C8A4CFD9F1B8E44B");

            entity.HasIndex(e => e.EmpresaId, "IX_ErrorLog_EmpresaId");

            entity.HasIndex(e => e.Resolved, "IX_ErrorLog_Resolved");

            entity.HasIndex(e => new { e.Resolved, e.Timestamp }, "IX_ErrorLog_Resolved_Timestamp").IsDescending(false, true);

            entity.HasIndex(e => e.Severity, "IX_ErrorLog_Severity");

            entity.HasIndex(e => e.Source, "IX_ErrorLog_Source");

            entity.HasIndex(e => e.Timestamp, "IX_ErrorLog_Timestamp").IsDescending();

            entity.HasIndex(e => e.UsuarioId, "IX_ErrorLog_UsuarioId");

            entity.Property(e => e.ExceptionType).HasMaxLength(200);
            entity.Property(e => e.IPAddress).HasMaxLength(50);
            entity.Property(e => e.Message).HasMaxLength(2000);
            entity.Property(e => e.Notes).HasMaxLength(1000);
            entity.Property(e => e.Severity).HasMaxLength(20);
            entity.Property(e => e.Source).HasMaxLength(50);
            entity.Property(e => e.Timestamp).HasDefaultValueSql("(getdate())");
            entity.Property(e => e.Url).HasMaxLength(500);
            entity.Property(e => e.UserAgent).HasMaxLength(500);
        });

        modelBuilder.Entity<ActivityLog>(entity =>
        {
            entity.HasKey(e => e.IdActivity).HasName("PK__ActivityLog__IdActivity");

            entity.HasIndex(e => e.UsuarioId, "IX_ActivityLog_UsuarioId");

            entity.HasIndex(e => e.EmpresaId, "IX_ActivityLog_EmpresaId");

            entity.HasIndex(e => e.Timestamp, "IX_ActivityLog_Timestamp").IsDescending();

            entity.Property(e => e.IdActivity).ValueGeneratedOnAdd();
            entity.Property(e => e.Timestamp).HasDefaultValueSql("(getdate())");
            entity.Property(e => e.UserName).HasMaxLength(100);
            entity.Property(e => e.IpAddress).HasMaxLength(50);
            entity.Property(e => e.Host).HasMaxLength(200);
            entity.Property(e => e.Url).HasMaxLength(500);
            entity.Property(e => e.Method).HasMaxLength(10);
            entity.Property(e => e.UserAgent).HasMaxLength(500);
        });

        modelBuilder.Entity<EstadoMes>(entity =>
        {
            entity.HasNoKey();

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.Mes }, "IdxEmpresa");

            entity.Property(e => e.Ano).HasDefaultValue((short)0);
            entity.Property(e => e.Estado).HasDefaultValue((short)0);
            entity.Property(e => e.FechaApertura).HasDefaultValue(0);
            entity.Property(e => e.FechaCierre).HasDefaultValue(0);
            entity.Property(e => e.FechaImpresion).HasDefaultValue(0);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
            entity.Property(e => e.Impreso).HasDefaultValue((short)0);
            entity.Property(e => e.Mes).HasDefaultValue((short)0);
        });

        modelBuilder.Entity<FactorActAnual>(entity =>
        {
            entity.HasKey(e => e.IdFactorActAnual).HasName("Idx_FactorActAnual");

            entity.HasIndex(e => new { e.Ano, e.MesRow, e.MesCol }, "IdxAno_FactorActAnual").IsUnique();
        });

        modelBuilder.Entity<Firmas>(entity =>
        {
            entity.HasNoKey();

            entity.Property(e => e.IdEmpresa).HasColumnType("numeric(18, 0)");
            entity.Property(e => e.Patch)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.Tipo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ano)
                .HasMaxLength(4)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Glosas>(entity =>
        {
            entity.HasKey(e => e.idGlosa).HasName("Glosas_Id_PK");

            entity.HasIndex(e => e.IdEmpresa, "IdxEmpresa");

            entity.Property(e => e.Glosa)
                .HasMaxLength(250)
                .IsUnicode(false);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
        });

        modelBuilder.Entity<IFRS_PlanIFRS>(entity =>
        {
            entity.HasKey(e => e.idCuenta).HasName("IFRS_PlanIFRS_IdCuenta_PK");

            entity.HasIndex(e => e.Codigo, "Codigo").IsUnique();

            entity.HasIndex(e => e.Nombre, "Nombre");

            entity.Property(e => e.CodCtaPlanSII)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.CodPlanAvanzado)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.Codigo)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.Descripcion)
                .HasMaxLength(130)
                .IsUnicode(false);
            entity.Property(e => e.Nombre)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsFixedLength();
        });

        modelBuilder.Entity<IPC>(entity =>
        {
            entity.HasKey(e => e.AnoMes).HasName("IPC_AnoMes_PK");

            entity.Property(e => e.AnoMes).ValueGeneratedNever();
        });

        modelBuilder.Entity<ImpAdic>(entity =>
        {
            entity.HasKey(e => e.IdImpAdic).HasName("ImpAdic_Idx_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.TipoLib, e.TipoValor }, "IdxEmpresa");

            entity.Property(e => e.CodCuenta)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
        });

        modelBuilder.Entity<Impuestos>(entity =>
        {
            entity.HasKey(e => e.idImpuesto).HasName("Impuestos_PrimaryKey_PK");

            entity.HasIndex(e => e.Impuesto, "Imp");

            entity.Property(e => e.Impuesto)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Porcentaje).HasDefaultValue(0.0);
        });

        modelBuilder.Entity<InfoAnualDJ1847>(entity =>
        {
            entity.HasNoKey();

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdAjustesRLI }, "IdAjustesRLI");
        });

        modelBuilder.Entity<LParam>(entity =>
        {
            entity.HasKey(e => e.Codigo).HasName("LParam_Codigo_PK");

            entity.Property(e => e.Codigo).ValueGeneratedNever();
            entity.Property(e => e.Valor)
                .HasMaxLength(255)
                .IsUnicode(false);
        });

        modelBuilder.Entity<LibroCaja>(entity =>
        {
            entity.HasKey(e => e.IdLibroCaja).HasName("LibroCaja_Idx_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdComp }, "IdComp");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdDoc }, "IdxDoc");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.TipoOper, e.FechaIngresoLibro }, "IdxFecha");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.TipoLib, e.TipoDoc, e.NumDoc, e.IdEntidad }, "IdxNumDoc");

            entity.Property(e => e.Ano).HasDefaultValue((short)0);
            entity.Property(e => e.Descrip)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
            entity.Property(e => e.NombreEntidad)
                .HasMaxLength(40)
                .IsUnicode(false);
            entity.Property(e => e.NumDoc)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.NumDocHasta)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.RutEntidad)
                .HasMaxLength(12)
                .IsUnicode(false);
        });

        modelBuilder.Entity<LockAction>(entity =>
        {
            entity.HasKey(e => new { e.idAction, e.idItem }).HasName("LockAction_ActionItem_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano }, "IdxEmpresa");

            entity.HasIndex(e => e.idLock, "idLock").IsUnique();

            entity.Property(e => e.Ano).HasDefaultValue((short)0);
            entity.Property(e => e.Fecha).HasColumnType("datetime");
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
            entity.Property(e => e.PcName)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.idLock).ValueGeneratedOnAdd();
        });

        modelBuilder.Entity<LogComprobantes>(entity =>
        {
            entity.HasKey(e => e.IdLog).HasName("LogComprobantes_IdLog_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.Fecha }, "Fecha");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdComp }, "IdComp");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdOper }, "IdOper");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdUsuario }, "IdUsuario");

            entity.Property(e => e.Ano).HasDefaultValue((short)0);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
        });

        modelBuilder.Entity<LogImpreso>(entity =>
        {
            entity.HasKey(e => e.IdLog).HasName("LogImpreso_IdLog_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.Fecha }, "Fecha");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.idInforme }, "IdInforme");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdUsuario }, "IdUsuario");

            entity.Property(e => e.Ano).HasDefaultValue((short)0);
            entity.Property(e => e.Comentario)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.CorrFin).HasDefaultValue(0);
            entity.Property(e => e.CorrInicio).HasDefaultValue(0);
            entity.Property(e => e.Estado).HasDefaultValue((byte)0);
            entity.Property(e => e.Fecha).HasDefaultValue(0);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
            entity.Property(e => e.idInforme).HasDefaultValue(0);
        });

        modelBuilder.Entity<Membrete>(entity =>
        {
            entity.HasNoKey();

            entity.Property(e => e.IdEmpresa).HasColumnType("numeric(18, 0)");
            entity.Property(e => e.Texto1)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Texto2)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.TituloMembrete1)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.TituloMembrete2)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Monedas>(entity =>
        {
            entity.HasKey(e => e.idMoneda).HasName("Monedas_Id_PK");

            entity.HasIndex(e => e.CodAduana, "IdxCod");

            entity.Property(e => e.Caracteristica).HasDefaultValue((byte)0);
            entity.Property(e => e.CodAduana)
                .HasMaxLength(3)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.DecInf).HasDefaultValue(0f);
            entity.Property(e => e.DecVenta).HasDefaultValue(0f);
            entity.Property(e => e.Descrip)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Simbolo)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsFixedLength();
        });

        modelBuilder.Entity<MovActivoFijo>(entity =>
        {
            entity.HasKey(e => e.IdActFijo).HasName("MovActivoFijo_Id_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdComp }, "IdComp");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdCuenta }, "IdCuenta");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdDoc }, "IdDoc");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdMovComp }, "IdMovComp");

            entity.HasIndex(e => e.IdAreaNeg, "idx_IdAreaNeg");

            entity.HasIndex(e => e.idCCosto, "idx_IdCCosto");

            entity.Property(e => e.Ano).HasDefaultValue((short)0);
            entity.Property(e => e.Cantidad).HasDefaultValue(0);
            entity.Property(e => e.DepAcelerada).HasDefaultValue((short)0);
            entity.Property(e => e.DepNormal).HasDefaultValue((short)0);
            entity.Property(e => e.Descrip)
                .HasMaxLength(80)
                .IsUnicode(false);
            entity.Property(e => e.Fecha).HasDefaultValue(0);
            entity.Property(e => e.IVA).HasDefaultValue(0.0);
            entity.Property(e => e.IdComp).HasDefaultValue(0);
            entity.Property(e => e.IdCuenta).HasDefaultValue(0);
            entity.Property(e => e.IdDoc).HasDefaultValue(0);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
            entity.Property(e => e.IdMovComp).HasDefaultValue(0);
            entity.Property(e => e.Neto).HasDefaultValue(0.0);
            entity.Property(e => e.NombreProy)
                .HasMaxLength(60)
                .IsUnicode(false);
            entity.Property(e => e.PatenteRol)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.TipoMovAF).HasDefaultValue((short)0);
        });

        modelBuilder.Entity<MovComprobante>(entity =>
        {
            entity.HasKey(e => e.IdMov).HasName("MovComprobante_IdMov_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdCartola }, "IdCartola");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdCuenta }, "IdCuenta");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdDoc, e.IdDocCuota }, "IdDocCuota");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.idAreaNeg }, "IdxAreaNeg");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.idCCosto }, "IdxCCosto");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdComp, e.IdMov }, "IdxMovComp").IsUnique();

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdComp, e.IdCuenta }, "idx_MovComprobante_ComTipo");

            entity.Property(e => e.Ano).HasDefaultValue((short)0);
            entity.Property(e => e.Debe).HasDefaultValue(0.0);
            entity.Property(e => e.Glosa)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Haber).HasDefaultValue(0.0);
            entity.Property(e => e.IdCartola).HasDefaultValue(0);
            entity.Property(e => e.IdComp).HasDefaultValue(0);
            entity.Property(e => e.IdCuenta).HasDefaultValue(0);
            entity.Property(e => e.IdDoc).HasDefaultValue(0);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
            entity.Property(e => e.Nota)
                .HasMaxLength(120)
                .IsUnicode(false);
            entity.Property(e => e.Orden).HasDefaultValue(0);
            entity.Property(e => e.idAreaNeg).HasDefaultValue(0);
            entity.Property(e => e.idCCosto).HasDefaultValue(0);
        });

        modelBuilder.Entity<MovDocumento>(entity =>
        {
            entity.HasKey(e => e.IdMovDoc).HasName("MovDocumento_IdMovDoc_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdAreaNeg }, "IdAreaNeg");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdCCosto }, "IdCCosto");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdCompCent }, "IdComp");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdCompPago }, "IdCompPago");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdCuenta }, "IdCuenta");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdDoc }, "IdDoc");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.IdTipoValLib }, "IdTipoValLib");

            entity.Property(e => e.Ano).HasDefaultValue((short)0);
            entity.Property(e => e.CodCuentaOld)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodSIIDTE)
                .HasMaxLength(5)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.Debe).HasDefaultValue(0.0);
            entity.Property(e => e.Glosa)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Haber).HasDefaultValue(0.0);
            entity.Property(e => e.IdAreaNeg).HasDefaultValue(0);
            entity.Property(e => e.IdCCosto).HasDefaultValue(0);
            entity.Property(e => e.IdCompCent).HasDefaultValue(0);
            entity.Property(e => e.IdCompPago).HasDefaultValue(0);
            entity.Property(e => e.IdCuenta).HasDefaultValue(0);
            entity.Property(e => e.IdDoc).HasDefaultValue(0);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
            entity.Property(e => e.IdTipoValLib).HasDefaultValue((short)0);
            entity.Property(e => e.Orden).HasDefaultValue((byte)0);
        });

        modelBuilder.Entity<Notas>(entity =>
        {
            entity.HasNoKey();

            entity.HasIndex(e => new { e.IdEmpresa, e.Tipo }, "IdxEmpresa");

            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
            entity.Property(e => e.Nota)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.Tipo)
                .HasMaxLength(15)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Param>(entity =>
        {
            entity.HasKey(e => new { e.Tipo, e.Codigo }).HasName("Param_Tipo_PK");

            entity.Property(e => e.Tipo)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.Atributo)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.Diminutivo)
                .HasMaxLength(4)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.Valor)
                .HasMaxLength(30)
                .IsUnicode(false);
        });

        modelBuilder.Entity<ParamEmpresa>(entity =>
        {
            entity.HasNoKey();

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano }, "IdxEmpresa");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.Tipo, e.Codigo }, "TipoCod").IsUnique();

            entity.Property(e => e.Ano).HasDefaultValue((short)0);
            entity.Property(e => e.Codigo).HasDefaultValue((short)0);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
            entity.Property(e => e.Tipo)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.Valor)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.ValorOld)
                .HasMaxLength(30)
                .IsUnicode(false);
        });

        modelBuilder.Entity<ParamRazon>(entity =>
        {
            entity.HasKey(e => new { e.IdEmpresa, e.IdRazon }).HasName("ParamRazon_IdxParamRazon_PK");
        });

        modelBuilder.Entity<PcUsr>(entity =>
        {
            entity.HasNoKey();

            entity.HasIndex(e => new { e.PC, e.Usr }, "Pc").IsUnique();

            entity.Property(e => e.PC)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Usr)
                .HasMaxLength(30)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Percepciones>(entity =>
        {
            entity.HasKey(e => e.IDPerc).HasName("PK__Percepci__895414F2DE066D6F");

            entity.Property(e => e.IDPerc).HasColumnType("numeric(18, 0)");
            entity.Property(e => e.Contabilizacion).HasColumnType("numeric(18, 0)");
            entity.Property(e => e.IdComp).HasColumnType("numeric(18, 0)");
            entity.Property(e => e.IdCuenta).HasColumnType("numeric(18, 0)");
            entity.Property(e => e.IdEmpresa).HasColumnType("numeric(18, 0)");
            entity.Property(e => e.NumCertificado).HasColumnType("numeric(18, 0)");
            entity.Property(e => e.Orden).HasColumnType("numeric(18, 0)");
            entity.Property(e => e.Percepciones1)
                .HasColumnType("numeric(18, 0)")
                .HasColumnName("Percepciones");
            entity.Property(e => e.Regimen).HasColumnType("numeric(18, 0)");
            entity.Property(e => e.RutEmpresa).HasColumnType("numeric(18, 0)");
            entity.Property(e => e.TasaTef).HasColumnType("decimal(18, 6)");
            entity.Property(e => e.TasaTex).HasColumnType("decimal(18, 6)");
        });

        modelBuilder.Entity<Perfiles>(entity =>
        {
            entity.HasNoKey();

            entity.HasIndex(e => e.IdPerfil, "IdPerfil").IsUnique();

            entity.HasIndex(e => e.Nombre, "Perfil").IsUnique();

            entity.Property(e => e.IdPerfil).HasDefaultValue((short)0);
            entity.Property(e => e.Nombre)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Privilegios).HasDefaultValue(0);
        });

        modelBuilder.Entity<PlanAvanzado>(entity =>
        {
            entity.HasNoKey();

            entity.HasIndex(e => e.Clasificacion, "Clasificacion");

            entity.HasIndex(e => e.Codigo, "Codigo").IsUnique();

            entity.HasIndex(e => e.Nivel, "Nivel");

            entity.HasIndex(e => e.Nombre, "Nombre");

            entity.HasIndex(e => e.idCuenta, "idCuenta").IsUnique();

            entity.HasIndex(e => e.idPadre, "idPadre");

            entity.Property(e => e.Atrib1).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib10).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib2).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib3).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib4).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib5).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib6).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib7).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib8).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib9).HasDefaultValue((byte)0);
            entity.Property(e => e.Clasificacion).HasDefaultValue((byte)0);
            entity.Property(e => e.CodCtaPlanSII)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.CodF22).HasDefaultValue((short)0);
            entity.Property(e => e.CodFECU)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodIFRS)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodIFRS_EstFin)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodIFRS_EstRes)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.Codigo)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.Debe).HasDefaultValue(0.0);
            entity.Property(e => e.Descripcion)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Estado).HasDefaultValue((byte)0);
            entity.Property(e => e.Haber).HasDefaultValue(0.0);
            entity.Property(e => e.MarcaApertura).HasDefaultValue((short)0);
            entity.Property(e => e.Nivel).HasDefaultValue((byte)0);
            entity.Property(e => e.Nombre)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.TipoCapPropio).HasDefaultValue(0);
            entity.Property(e => e.TipoPlan)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.idCuenta).ValueGeneratedOnAdd();
            entity.Property(e => e.idPadre).HasDefaultValue(0);
        });

        modelBuilder.Entity<PlanBasico>(entity =>
        {
            entity.HasNoKey();

            entity.HasIndex(e => e.Clasificacion, "Clasificacion");

            entity.HasIndex(e => e.Codigo, "Codigo").IsUnique();

            entity.HasIndex(e => e.Nivel, "Nivel");

            entity.HasIndex(e => e.Nombre, "Nombre");

            entity.HasIndex(e => e.idCuenta, "idCuenta").IsUnique();

            entity.HasIndex(e => e.idPadre, "idPadre");

            entity.Property(e => e.Atrib1).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib10).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib2).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib3).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib4).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib5).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib6).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib7).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib8).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib9).HasDefaultValue((byte)0);
            entity.Property(e => e.Clasificacion).HasDefaultValue((byte)0);
            entity.Property(e => e.CodCtaPlanSII)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.CodF22).HasDefaultValue((short)0);
            entity.Property(e => e.CodFECU)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodIFRS)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodIFRS_EstFin)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodIFRS_EstRes)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.Codigo)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.Debe).HasDefaultValue(0.0);
            entity.Property(e => e.Descripcion)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Estado).HasDefaultValue((byte)0);
            entity.Property(e => e.Haber).HasDefaultValue(0.0);
            entity.Property(e => e.MarcaApertura).HasDefaultValue((short)0);
            entity.Property(e => e.Nivel).HasDefaultValue((byte)0);
            entity.Property(e => e.Nombre)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.TipoCapPropio).HasDefaultValue(0);
            entity.Property(e => e.idCuenta).ValueGeneratedOnAdd();
            entity.Property(e => e.idPadre).HasDefaultValue(0);
        });

        modelBuilder.Entity<PlanCuentasSII>(entity =>
        {
            entity.HasKey(e => e.IdPlanCuentasSII).HasName("PlanCuentasSII_IdxId_PK");

            entity.HasIndex(e => e.Clasificacion, "IdClasif");

            entity.HasIndex(e => e.CodigoSII, "IdxCod").IsUnique();

            entity.Property(e => e.CodigoSII)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.DescripSII)
                .HasMaxLength(130)
                .IsUnicode(false);
            entity.Property(e => e.FmtCodigoSII)
                .HasMaxLength(15)
                .IsUnicode(false);
        });

        modelBuilder.Entity<PlanIntermedio>(entity =>
        {
            entity.HasNoKey();

            entity.HasIndex(e => e.Clasificacion, "Clasificacion");

            entity.HasIndex(e => e.Codigo, "Codigo").IsUnique();

            entity.HasIndex(e => e.Nivel, "Nivel");

            entity.HasIndex(e => e.Nombre, "Nombre");

            entity.HasIndex(e => e.idCuenta, "idCuenta").IsUnique();

            entity.HasIndex(e => e.idPadre, "idPadre");

            entity.Property(e => e.Atrib1).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib10).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib2).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib3).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib4).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib5).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib6).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib7).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib8).HasDefaultValue((byte)0);
            entity.Property(e => e.Atrib9).HasDefaultValue((byte)0);
            entity.Property(e => e.Clasificacion).HasDefaultValue((byte)0);
            entity.Property(e => e.CodCtaPlanSII)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.CodF22).HasDefaultValue((short)0);
            entity.Property(e => e.CodFECU)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodIFRS)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodIFRS_EstFin)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodIFRS_EstRes)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.Codigo)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.Debe).HasDefaultValue(0.0);
            entity.Property(e => e.Descripcion)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Estado).HasDefaultValue((byte)0);
            entity.Property(e => e.Haber).HasDefaultValue(0.0);
            entity.Property(e => e.MarcaApertura).HasDefaultValue((short)0);
            entity.Property(e => e.Nivel).HasDefaultValue((byte)0);
            entity.Property(e => e.Nombre)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.TipoCapPropio).HasDefaultValue(0);
            entity.Property(e => e.idCuenta).ValueGeneratedOnAdd();
            entity.Property(e => e.idPadre).HasDefaultValue(0);
        });

        modelBuilder.Entity<PropIVA_TotMensual>(entity =>
        {
            entity.HasNoKey();

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.Mes }, "IdxEmpresa");

            entity.Property(e => e.Ano).HasDefaultValue((short)0);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
        });

        modelBuilder.Entity<RazonesFin>(entity =>
        {
            entity.HasKey(e => e.IdRazon).HasName("RazonesFin_IdRazon_PK");

            entity.HasIndex(e => e.Tipo, "IdxTipo");

            entity.HasIndex(e => e.Nombre, "Nombre").IsUnique();

            entity.Property(e => e.Glosa)
                .HasMaxLength(120)
                .IsUnicode(false);
            entity.Property(e => e.Nombre)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Operador)
                .HasMaxLength(1)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.TxtDenominador)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.TxtNumerador)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UnidadRes)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsFixedLength();
        });

        modelBuilder.Entity<Regiones>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("Regiones_Id_PK");

            entity.HasIndex(e => e.CODIGO, "Cod");

            entity.Property(e => e.CODIGO)
                .HasMaxLength(2)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.COMUNA)
                .HasMaxLength(40)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Socios>(entity =>
        {
            entity.HasKey(e => e.IdSocio).HasName("Socios_Idx_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.Ano, e.RUT }, "IdxRut").IsUnique();

            entity.Property(e => e.Ano).HasDefaultValue((short)0);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
            entity.Property(e => e.Nombre)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RUT)
                .HasMaxLength(12)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Sucursales>(entity =>
        {
            entity.HasKey(e => e.IdSucursal).HasName("Sucursales_IdSucursal_PK");

            entity.HasIndex(e => new { e.IdEmpresa, e.Codigo }, "IdEmpresa");

            entity.Property(e => e.Codigo)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.Descripcion)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.IdEmpresa).HasDefaultValue(0);
        });

        modelBuilder.Entity<Timbraje>(entity =>
        {
            entity.HasNoKey();

            entity.HasIndex(e => e.idEmpresa, "IdEmp");

            entity.Property(e => e.FUltImpreso).HasDefaultValue(0);
            entity.Property(e => e.FUltTimbrado).HasDefaultValue(0);
            entity.Property(e => e.FUltUsado).HasDefaultValue(0);
            entity.Property(e => e.UltImpreso).HasDefaultValue(0);
            entity.Property(e => e.UltTimbrado).HasDefaultValue(0);
            entity.Property(e => e.UltUsado).HasDefaultValue(0);
            entity.Property(e => e.idEmpresa).HasDefaultValue(0);
        });

        modelBuilder.Entity<TipoDocs>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("TipoDocs_Id_PK");

            entity.HasIndex(e => e.Diminutivo, "NonClusteredIndex-20191015-122819");

            entity.HasIndex(e => e.CodDocDTESII, "NonClusteredIndex-20191015-122835");

            entity.HasIndex(e => new { e.TipoLib, e.TipoDoc }, "Tipo").IsUnique();

            entity.Property(e => e.Atributo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CodDocDTESII)
                .HasMaxLength(3)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.CodDocSII)
                .HasMaxLength(3)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.CodF29AFCount).HasDefaultValue((short)0);
            entity.Property(e => e.CodF29AFIVA).HasDefaultValue((short)0);
            entity.Property(e => e.CodF29Count).HasDefaultValue((short)0);
            entity.Property(e => e.CodF29IVA).HasDefaultValue((short)0);
            entity.Property(e => e.CodF29IVADTE).HasDefaultValue((short)0);
            entity.Property(e => e.CodF29Neto).HasDefaultValue((short)0);
            entity.Property(e => e.Diminutivo)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.Nombre)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.TipoDoc).HasDefaultValue((short)0);
            entity.Property(e => e.TipoLib).HasDefaultValue((short)0);
        });

        modelBuilder.Entity<TipoValor>(entity =>
        {
            entity.HasKey(e => e.idTValor).HasName("TipoValor_Id_PK");

            entity.HasIndex(e => e.Atributo, "Atributo");

            entity.HasIndex(e => e.CodImpSII, "CodImpSII");

            entity.HasIndex(e => e.CodSIIDTE, "CodSIIDTE");

            entity.HasIndex(e => new { e.TipoLib, e.Codigo }, "Tipo").IsUnique();

            entity.Property(e => e.Atributo)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.CodImpSII)
                .HasMaxLength(3)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.CodSIIDTE)
                .HasMaxLength(3)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.Codigo).HasDefaultValue((byte)0);
            entity.Property(e => e.Diminutivo)
                .HasMaxLength(4)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.TipoDoc)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.TipoLib).HasDefaultValue((byte)0);
            entity.Property(e => e.Tit1)
                .HasMaxLength(25)
                .IsUnicode(false);
            entity.Property(e => e.Tit2)
                .HasMaxLength(25)
                .IsUnicode(false);
            entity.Property(e => e.TitCompleto)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Valor)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Tracking_AperturaCierre>(entity =>
        {
            entity.HasNoKey();

            entity.Property(e => e.FechaHora).HasColumnType("datetime");
            entity.Property(e => e.Origen)
                .HasMaxLength(250)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Tracking_Comprobante>(entity =>
        {
            entity.HasKey(e => new { e.IdComp, e.FechaHora }).HasName("Tracking_Comprobante_IdComp_PK");

            entity.Property(e => e.FechaHora).HasColumnType("datetime");
            entity.Property(e => e.Glosa)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Origen)
                .HasMaxLength(250)
                .IsUnicode(false);
            entity.Property(e => e.Query).IsUnicode(false);
        });

        modelBuilder.Entity<Tracking_Documento>(entity =>
        {
            entity.HasKey(e => new { e.IdDoc, e.FechaHora }).HasName("Tracking_Documento_IdDoc_PK");

            entity.Property(e => e.FechaHora).HasColumnType("datetime");
            entity.Property(e => e.CodCtaAfectoOld)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodCtaExentoOld)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodCtaTotalOld)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.Descrip)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.IdANegCCosto)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.NombreEntidad)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.NumDoc)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.NumDocAsoc)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.NumDocHasta)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.NumDocRef)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.NumFiscImpr)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.NumInformeZ)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Origen)
                .HasMaxLength(250)
                .IsUnicode(false);
            entity.Property(e => e.Query).IsUnicode(false);
            entity.Property(e => e.RutEntidad)
                .HasMaxLength(12)
                .IsUnicode(false);
            entity.Property(e => e.UrlDTE)
                .HasMaxLength(250)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Tracking_MovComprobante>(entity =>
        {
            entity.HasKey(e => new { e.IdMov, e.FechaHora }).HasName("Tracking_MovComprobante_IdMov_PK");

            entity.Property(e => e.FechaHora).HasColumnType("datetime");
            entity.Property(e => e.Glosa)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Nota)
                .HasMaxLength(120)
                .IsUnicode(false);
            entity.Property(e => e.Origen)
                .HasMaxLength(250)
                .IsUnicode(false);
            entity.Property(e => e.Query).IsUnicode(false);
        });

        modelBuilder.Entity<Tracking_MovDocumento>(entity =>
        {
            entity.HasKey(e => new { e.IdMovDoc, e.FechaHora }).HasName("Tracking_MovDocumento_IdMovDoc_PK");

            entity.Property(e => e.FechaHora).HasColumnType("datetime");
            entity.Property(e => e.CodCuentaOld)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.CodSIIDTE)
                .HasMaxLength(2)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.Glosa)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Origen)
                .HasMaxLength(250)
                .IsUnicode(false);
            entity.Property(e => e.Query).IsUnicode(false);
        });

        modelBuilder.Entity<UsuarioEmpresa>(entity =>
        {
            entity.HasKey(e => new { e.idUsuario, e.idEmpresa }).HasName("UsuarioEmpresa_UsrEmp_PK");

            entity.Property(e => e.idPerfil).HasDefaultValue((short)0);
        });

        modelBuilder.Entity<Usuarios>(entity =>
        {
            entity.HasKey(e => e.IdUsuario).HasName("Usuarios_IdUsuario_PK");

            entity.HasIndex(e => e.Usuario, "Nombre").IsUnique();

            entity.HasIndex(e => e.PasswordHash, "idx_usuarios_passwordhash").HasFilter("([PasswordHash] IS NOT NULL)");

            entity.Property(e => e.Clave).HasDefaultValue(0);
            entity.Property(e => e.NombreLargo)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasDefaultValue(" ");
            entity.Property(e => e.PasswordHash).HasMaxLength(255);
            entity.Property(e => e.PrivAdm).HasDefaultValue((byte)0);
            entity.Property(e => e.Usuario)
                .HasMaxLength(15)
                .IsUnicode(false)
                .HasDefaultValue(" ");
        });

        modelBuilder.Entity<tbl_Comp_Centra_Full>(entity =>
        {
            entity.HasNoKey();

            entity.Property(e => e.Tipo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ano)
                .HasMaxLength(4)
                .IsUnicode(false);
        });

        modelBuilder.Entity<tmp_CRISTINACASTILL_qc__4304>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("tmp_CRISTINACASTILL_qc__4304");
        });

        modelBuilder.Entity<vMovCompIdDoc>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vMovCompIdDoc");
        });

        modelBuilder.Entity<vPrimeraDocCuota>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vPrimeraDocCuota");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
