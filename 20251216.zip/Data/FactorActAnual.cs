﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class FactorActAnual
{
    public int IdFactorActAnual { get; set; }

    public short? Ano { get; set; }

    public byte? MesRow { get; set; }

    public byte? MesCol { get; set; }

    public double? Factor { get; set; }
}
