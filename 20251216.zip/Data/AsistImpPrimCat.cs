﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class AsistImpPrimCat
{
    public int IdAsistImpPrimCat { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public byte? IdItem { get; set; }

    public double? RemEjAntNominal { get; set; }

    public double? RemEjAntAct { get; set; }

    public double? GeneradoAno { get; set; }

    public double? CredUtilizado { get; set; }

    public double? RemEjSgte { get; set; }
}
