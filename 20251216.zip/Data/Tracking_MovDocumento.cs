﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Tracking_MovDocumento
{
    public int IdMovDoc { get; set; }

    public DateTime FechaHora { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public int? IdDoc { get; set; }

    public int? IdCompCent { get; set; }

    public int? IdCompPago { get; set; }

    public byte? Orden { get; set; }

    public int? IdCuenta { get; set; }

    public double? Debe { get; set; }

    public double? Haber { get; set; }

    public string? Glosa { get; set; }

    public short? IdTipoValLib { get; set; }

    public bool? EsTotalDoc { get; set; }

    public int? IdCCosto { get; set; }

    public int? IdAreaNeg { get; set; }

    public float? Tasa { get; set; }

    public bool? EsRecuperable { get; set; }

    public string? CodSIIDTE { get; set; }

    public string? CodCuentaOld { get; set; }

    public string? Origen { get; set; }

    public string? Query { get; set; }

    public int? Vigente { get; set; }

    public int? FormaIngreso { get; set; }

    public int? Ajuste { get; set; }
}
