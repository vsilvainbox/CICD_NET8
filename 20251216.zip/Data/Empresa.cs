﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Empresa
{
    public int Id { get; set; }

    public short Ano { get; set; }

    public string? Rut { get; set; }

    public string? NombreCorto { get; set; }

    public string? RazonSocial { get; set; }

    public string? ApPaterno { get; set; }

    public string? ApMaterno { get; set; }

    public string? Nombre { get; set; }

    public string? Calle { get; set; }

    public string? Numero { get; set; }

    public string? Dpto { get; set; }

    public string? Telefonos { get; set; }

    public string? Fax { get; set; }

    public short? Region { get; set; }

    public int? Comuna { get; set; }

    public string? Ciudad { get; set; }

    public string? Giro { get; set; }

    public short? ActEconom { get; set; }

    public string? CodActEconom { get; set; }

    public string? DomPostal { get; set; }

    public short? ComunaPostal { get; set; }

    public string? Email { get; set; }

    public string? Web { get; set; }

    public int? FechaConstitucion { get; set; }

    public int? FechaInicioAct { get; set; }

    public bool? RepConjunta { get; set; }

    public string? RutRepLegal1 { get; set; }

    public string? RepLegal1 { get; set; }

    public string? RutRepLegal2 { get; set; }

    public string? RepLegal2 { get; set; }

    public string? Contador { get; set; }

    public string? RutContador { get; set; }

    public short? TipoContrib { get; set; }

    public bool? TransaBolsa { get; set; }

    public bool? Franq14bis { get; set; }

    public bool? FranqLey18392 { get; set; }

    public bool? FranqDL600 { get; set; }

    public bool? FranqDL701 { get; set; }

    public bool? FranqDS341 { get; set; }

    public int? Opciones { get; set; }

    public int? TContribFUT { get; set; }

    public bool? Franq14ter { get; set; }

    public bool? Franq14quater { get; set; }

    public bool? ObligaLibComprasVentas { get; set; }

    public bool? FranqRentaAtribuida { get; set; }

    public bool? FranqSemiIntegrado { get; set; }

    public bool? FranqSocProfPrimCat { get; set; }

    public bool? FranqSocProfSegCat { get; set; }

    public bool? Franq14ASemiIntegrado { get; set; }

    public bool? FranqProPymeGeneral { get; set; }

    public bool? FranqProPymeTransp { get; set; }

    public bool? FranqRentasPresuntas { get; set; }

    public bool? FranqRentaEfectiva { get; set; }

    public bool? FranqOtro { get; set; }

    public bool? FranqNoSujetoArt14 { get; set; }

    public decimal? CodArea { get; set; }

    public decimal? Celular { get; set; }

    public string? Villa { get; set; }
}
