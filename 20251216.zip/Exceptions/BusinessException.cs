namespace App.Exceptions;

/// <summary>
/// Excepcion para errores de validacion de negocio.
/// Estos errores se muestran al usuario como mensajes de correccion,
/// NO como errores de sistema.
///
/// Uso:
///   throw new BusinessException("El RUT es invalido");
///   throw new BusinessException("Campo requerido", "Fecha fuera de rango");
/// </summary>
public class BusinessException : Exception
{
    /// <summary>
    /// Lista de errores/mensajes de validacion
    /// </summary>
    public List<string> Errors { get; }

    public BusinessException(string message) : base(message)
    {
        Errors = [message];
    }

    public BusinessException(params string[] errors) : base(errors.FirstOrDefault() ?? "Error de validacion")
    {
        Errors = errors.ToList();
    }

    public BusinessException(IEnumerable<string> errors) : base(errors.FirstOrDefault() ?? "Error de validacion")
    {
        Errors = errors.ToList();
    }
}
