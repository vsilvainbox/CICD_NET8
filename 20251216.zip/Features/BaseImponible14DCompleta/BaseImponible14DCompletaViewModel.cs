using System.ComponentModel.DataAnnotations;
using System.Globalization;
using ValidationResult = System.ComponentModel.DataAnnotations.ValidationResult;

namespace App.Features.BaseImponible14DCompleta;

/// <summary>
/// ViewModel para la vista principal de Base Imponible 14D Completa
/// Siguiendo el patrón ASP.NET Core MVC Way - servidor renderiza, cliente coordina
/// </summary>
public class BaseImponible14DCompletaViewModel
{
    // Identificadores (del estado de sesión)
    public int EmpresaId { get; set; }
    public short Ano { get; set; }

    // Información de empresa
    public string NombreEmpresa { get; set; } = string.Empty;
    public string Regimen { get; set; } = string.Empty;
    public bool? ProPymeGeneral { get; set; }
    public bool? ProPymeTransp { get; set; }
    public bool PeriodoCerrado { get; set; }

    // Datos jerárquicos
    public List<BaseImponible14DSeccionViewModel> Secciones { get; set; } = new();

    // Totales calculados (server-side)
    public decimal TotalIngresos { get; set; }
    public decimal TotalEgresos { get; set; }
    public decimal BaseImponible { get; set; }

    // Propiedades formateadas para la vista
    public string TotalIngresosFormateado => FormatearMoneda(TotalIngresos);
    public string TotalEgresosFormateado => FormatearMoneda(TotalEgresos);
    public string BaseImponibleFormateado => FormatearMoneda(BaseImponible);

    // Estado de expansión (para mantener estado entre requests)
    public HashSet<int> NodosExpandidos { get; set; } = new();
    public bool ModoSaldosVigentes { get; set; }

    // Formateo consistente de moneda
    private static string FormatearMoneda(decimal valor)
    {
        return valor.ToString("N2", new CultureInfo("es-CL"));
    }
}

/// <summary>
/// ViewModel para una sección de la estructura jerárquica
/// </summary>
public class BaseImponible14DSeccionViewModel
{
    public byte Nivel { get; set; }
    public string Titulo { get; set; } = string.Empty;
    public decimal Subtotal { get; set; }
    public string SubtotalFormateado => Subtotal.ToString("N2", new CultureInfo("es-CL"));
    public bool Expandida { get; set; } = true;
    public List<BaseImponible14DItemViewModel> Items { get; set; } = new();
}

/// <summary>
/// ViewModel para un item individual de Base Imponible 14D
/// </summary>
public class BaseImponible14DItemViewModel
{
    public int IdBaseImponible14D { get; set; }
    public int IdEmpresa { get; set; }
    public short Ano { get; set; }
    public byte Tipo { get; set; }
    public byte Nivel { get; set; }
    public short Codigo { get; set; }
    public string Descripcion { get; set; } = string.Empty;

    [Range(0, double.MaxValue, ErrorMessage = "El valor debe ser mayor o igual a cero")]
    public decimal Valor { get; set; }

    public byte FormaIngreso { get; set; }
    public bool EsEditable { get; set; }
    public bool EsSubtotal { get; set; }
    public bool EsNegrita { get; set; }
    public bool EsVisible { get; set; } = true;
    public string ColorTexto { get; set; } = string.Empty;
    public bool TieneHijos { get; set; }
    public bool Expandido { get; set; } = true;
    public int? CodigoEspejo { get; set; }
    public List<BaseImponible14DItemViewModel> Hijos { get; set; } = new();

    // Propiedades formateadas para la vista
    public string ValorFormateado => Valor.ToString("N2", new CultureInfo("es-CL"));

    // Propiedades calculadas para la vista
    public string ClasesCSS
    {
        get
        {
            var clases = new List<string>();
            if (EsNegrita) clases.Add("font-bold");
            if (ColorTexto == "blue") clases.Add("text-blue-600");
            else clases.Add("text-gray-900");
            return string.Join(" ", clases);
        }
    }

    public int IndentacionPx => (Nivel - 1) * 20;

    public string IconoExpansion => Expandido ? "fa-minus-square" : "fa-plus-square";
}

/// <summary>
/// Request para editar un valor manual
/// Siguiendo el patrón ASP.NET Core MVC Way - validación server-side
/// </summary>
public class EditarValorRequest : IValidatableObject
{
    [Required(ErrorMessage = "El código es requerido")]
    public short Codigo { get; set; }

    /// <summary>
    /// Valor como string para permitir el Model Binding procesar la cultura correcta
    /// El servidor parseará con cultura chilena (punto = miles, coma = decimal)
    /// </summary>
    public string? ValorString { get; set; }

    /// <summary>
    /// Valor parseado (será asignado después de validar ValorString)
    /// </summary>
    [Range(0, double.MaxValue, ErrorMessage = "El valor debe ser mayor o igual a cero")]
    public decimal Valor { get; set; }

    public int EmpresaId { get; set; }
    public short Ano { get; set; }

    /// <summary>
    /// Validación personalizada para parsing de cultura chilena
    /// </summary>
    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        // Si ValorString está vacío, usar 0
        if (string.IsNullOrWhiteSpace(ValorString))
        {
            Valor = 0;
            yield break;
        }

        // Intentar parsear con cultura chilena (es-CL)
        // Formato chileno: punto (.) = separador de miles, coma (,) = separador decimal
        var culturaChilena = new CultureInfo("es-CL");

        // Limpiar el valor: remover espacios y símbolos de moneda
        var valorLimpio = ValorString.Trim()
            .Replace("$", "")
            .Replace(" ", "");

        // Intentar parsear
        if (!decimal.TryParse(valorLimpio, NumberStyles.Number | NumberStyles.AllowThousands, culturaChilena, out var valorParseado))
        {
            yield return new ValidationResult(
                "El valor ingresado no es un número válido. Use formato chileno: 1.234,56",
                new[] { nameof(ValorString) });
            yield break;
        }

        // Validar rango
        if (valorParseado < 0)
        {
            yield return new ValidationResult(
                "El valor debe ser mayor o igual a cero",
                new[] { nameof(ValorString) });
            yield break;
        }

        // Base imponible tributaria: validación de límites razonables
        if (valorParseado > 999_999_999_999.99m) // 999 billones chilenos
        {
            yield return new ValidationResult(
                "El valor ingresado excede el límite permitido",
                new[] { nameof(ValorString) });
            yield break;
        }

        // Asignar el valor parseado
        Valor = valorParseado;
    }
}

/// <summary>
/// Request para guardar cambios
/// </summary>
public class GuardarCambiosRequest : IValidatableObject
{
    [Required(ErrorMessage = "La empresa es requerida")]
    public int EmpresaId { get; set; }

    [Required(ErrorMessage = "El año es requerido")]
    public short Ano { get; set; }

    public List<ItemActualizadoViewModel> ItemsActualizados { get; set; } = new();

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (ItemsActualizados == null || ItemsActualizados.Count == 0)
        {
            yield return new ValidationResult(
                "No hay cambios para guardar",
                new[] { nameof(ItemsActualizados) });
        }

        // Validar que no haya códigos duplicados
        var codigosDuplicados = ItemsActualizados
            .GroupBy(x => x.Codigo)
            .Where(g => g.Count() > 1)
            .Select(g => g.Key)
            .ToList();

        if (codigosDuplicados.Any())
        {
            yield return new ValidationResult(
                $"Códigos duplicados en cambios: {string.Join(", ", codigosDuplicados)}",
                new[] { nameof(ItemsActualizados) });
        }
    }
}

/// <summary>
/// Item actualizado en el formulario
/// </summary>
public class ItemActualizadoViewModel
{
    [Required(ErrorMessage = "El código es requerido")]
    public short Codigo { get; set; }

    [Required(ErrorMessage = "El valor es requerido")]
    [Range(0, double.MaxValue, ErrorMessage = "El valor debe ser mayor o igual a cero")]
    public decimal Valor { get; set; }
}

/// <summary>
/// Response del servidor después de guardar
/// </summary>
public class GuardarCambiosResponse
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public int RegistrosActualizados { get; set; }
    public int RegistrosInsertados { get; set; }
    public decimal BaseImponibleCalculada { get; set; }
    public string BaseImponibleFormateada => BaseImponibleCalculada.ToString("N2", new CultureInfo("es-CL"));
}
