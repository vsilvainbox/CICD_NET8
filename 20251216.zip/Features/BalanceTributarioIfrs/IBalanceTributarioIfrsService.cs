namespace App.Features.BalanceTributarioIfrs;

/// <summary>
/// Servicio para generar el Balance Tributario IFRS (8 columnas).
/// </summary>
public interface IBalanceTributarioIfrsService
{
    /// <summary>
    /// Genera el Balance Tributario IFRS para el período especificado.
    /// </summary>
    /// <param name="request">Parámetros de filtrado y configuración.</param>
    /// <returns>Balance con estructura de 8 columnas y totales.</returns>
    Task<BalanceTributarioIfrsResponseDto> GenerarAsync(BalanceTributarioIfrsRequestDto request);

    /// <summary>
    /// Valida que el plan de cuentas sea compatible con IFRS.
    /// </summary>
    /// <returns>Tupla con información de validez, plan actual y mensaje.</returns>
    Task<(bool EsValido, string? PlanActual, string Mensaje)> ValidarPlanCuentasAsync();

    /// <summary>
    /// Verifica si existen cuentas con saldo sin clasificación IFRS.
    /// </summary>
    /// <param name="fechaHasta">Fecha hasta para verificar saldos.</param>
    /// <returns>Tupla con información de existencia y mensaje.</returns>
    Task<(bool Existen, string Mensaje)> ValidarClasificacionIfrsAsync(DateTime fechaHasta);

    /// <summary>
    /// Obtiene las áreas de negocio disponibles para dropdowns.
    /// </summary>
    /// <returns>Lista de items para combos.</returns>
    Task<List<Shared.ComboItemDto>> ObtenerAreasNegocioAsync();

    /// <summary>
    /// Obtiene los centros de costo disponibles para dropdowns.
    /// </summary>
    /// <returns>Lista de items para combos.</returns>
    Task<List<Shared.ComboItemDto>> ObtenerCentrosCostoAsync();

    /// <summary>
    /// Genera un archivo PDF con el Balance Tributario IFRS.
    /// </summary>
    /// <param name="request">Los filtros y parámetros para generar el balance</param>
    /// <param name="incluirMembrete">Si debe incluir el membrete de la empresa</param>
    /// <returns>Tupla con el byte array del PDF y el nombre del archivo generado</returns>
    Task<(byte[] PdfBytes, string FileName)> ExportarPdfAsync(BalanceTributarioIfrsRequestDto request, bool incluirMembrete = true);
}
