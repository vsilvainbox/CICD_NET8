# COMPARACIÓN VISUAL: VB6 vs .NET 9

## Feature: AjustesRliCaja (Ajustes Extra-Contables RLI HR RAB/RAD)

---

## INTERFAZ DE USUARIO

### VB6: FrmAjustesExtraLibCajaRLI

```
┌─────────────────────────────────────────────────────────────────────┐
│ Ajustes Extra - Contables RLI HR RAB                                │
├─────────────────────────────────────────────────────────────────────┤
│ [🖨] [🖨] [📋] [Σ] [💱] [🧮] [📅]    [Filtrar] [Exportar] [Cerrar]   │
├─────────────────────────────────────────────────────────────────────┤
│                                                                       │
│  AGREGADOS                                                            │
│     A) Agregados art 33                                               │
│          Ajuste por depreciación acelerada              150,000       │
│          Ajuste por provisiones                          75,000       │
│          Otros ajustes art 33                            25,000       │
│     B) Otros agregados                                                │
│          Gastos rechazados                               50,000       │
│          Multas e intereses                              10,000       │
│                                                                       │
│  ─────────────────────────────────────────────────────────────────   │
│                                                                       │
│  DEDUCCIONES                                                          │
│     C) Deducciones                                                    │
│          Depreciación normal                            100,000       │
│          Incentivo ahorro                                30,000       │
│                                                                       │
└─────────────────────────────────────────────────────────────────────┘
```

**Botones:**
- Vista previa (🖨)
- Imprimir (🖨)
- Copiar Excel (📋)
- Sumar (Σ)
- Convertir Moneda (💱)
- Calculadora (🧮)
- Calendario (📅)
- Mostrar Partidas con Valores
- Exportar a HR RAB/RAD
- Cerrar

---

### .NET 9: Index.cshtml + _AjustesGrid.cshtml

```
┌─────────────────────────────────────────────────────────────────────┐
│ Ajustes Extra-Contables RLI HR RAD                                   │
│ Ajustes extra-contables para Régimen de Libre Imputación             │
├─────────────────────────────────────────────────────────────────────┤
│ [📥 Exportar a HR RAD] [🔍 Mostrar Partidas con Valores]  [🖨] [📊] │
├─────────────────────────────────────────────────────────────────────┤
│                                                                       │
│  AGREGADOS                                                            │
│     A) Agregados art 33                                               │
│          Ajuste por depreciación acelerada                     0      │
│          Ajuste por provisiones                                0      │
│          Otros ajustes art 33                                  0      │
│     B) Otros agregados                                                │
│          Gastos rechazados                                     0      │
│          Multas e intereses                                    0      │
│                                                                       │
│  ─────────────────────────────────────────────────────────────────   │
│                                                                       │
│  DEDUCCIONES                                                          │
│     C) Deducciones                                                    │
│          Depreciación normal                                   0      │
│          Incentivo ahorro                                      0      │
│                                                                       │
└─────────────────────────────────────────────────────────────────────┘
```

**Botones:**
- Exportar a HR RAD (primario, azul)
- Mostrar Partidas con Valores (secundario)
- Imprimir (icono)
- Excel (icono)

---

## COMPARACIÓN DE CARACTERÍSTICAS

| Característica | VB6 | .NET 9 | Estado |
|----------------|-----|--------|:------:|
| **Título dinámico (RAB/RAD)** | ✅ Sí | ✅ Sí | ✅ |
| **Estructura jerárquica** | ✅ Tipo→Grupo→Item | ✅ Tipo→Grupo→Item | ✅ |
| **Indentación visual** | ✅ Espacios | ✅ `&nbsp;` | ✅ |
| **Valores calculados** | ✅ Desde BD | ❌ Todos en 0 | 🔴 |
| **Formato números** | ✅ Formato chileno | ✅ Formato chileno | ✅ |
| **Botón filtrar** | ✅ Sí | ✅ Sí | ✅ |
| **Botón exportar** | ✅ Sí | ✅ Sí | ⚠️ |
| **Botón imprimir** | ✅ Sí | ✅ Sí | ✅ |
| **Botón Excel** | ✅ Sí | ✅ Sí | ✅ |
| **Calculadora** | ✅ Sí | ❌ No | ⚠️ |
| **Conversor moneda** | ✅ Sí | ❌ No | ⚠️ |
| **Calendario** | ✅ Sí | ❌ No | ⚠️ |
| **Suma seleccionados** | ✅ Sí | ❌ No | ⚠️ |
| **Responsive** | ❌ No | ✅ Sí | ✅ |
| **Tema moderno** | ❌ No | ✅ Sí | ✅ |

---

## FLUJO DE CARGA DE DATOS

### VB6

```
Form_Load()
    │
    ├─ SetUpGrid()
    │   └─ Configura columnas y anchos
    │
    └─ LoadAll()
        │
        ├─ FOR k = 1 TO MAX_TIPOAJUSTESECRLI
        │   │
        │   ├─ Agregar fila TIPO (Bold, Gris)
        │   │
        │   └─ FOR j = 1 TO MAX_GRUPOAJUSTESECRLI
        │       │
        │       ├─ Agregar fila GRUPO (Bold, Gris)
        │       │
        │       └─ FOR i = 1 TO MAX_ITEMAJUSTESECRLI
        │           │
        │           ├─ LoadValCuentas()
        │           │   └─ SELECT Sum(Debe-Haber)
        │           │       FROM MovComprobante
        │           │       INNER JOIN Comprobante
        │           │       WHERE IdCuenta IN (...)
        │           │         AND TipoAjuste IN (1,3)
        │           │         AND Tipo <> APERTURA
        │           │
        │           └─ Grid.TextMatrix(Row, C_VALOR) = Valor
        │
        └─ Grid.FlxGrid.Redraw = True
```

---

### .NET 9

```
Index.cshtml (onload)
    │
    └─ cargarDatos()
        │
        └─ fetch('/AjustesRliCaja/GetAjustesGrid')
            │
            ├─ AjustesRliCajaController.GetAjustesGrid()
            │   │
            │   ├─ HTTP GET /AjustesRliCajaApi/GetAjustes
            │   │   │
            │   │   └─ AjustesRliCajaService.GetAjustesAsync()
            │   │       │
            │   │       ├─ Tipos hardcoded (Agregados, Deducciones)
            │   │       │
            │   │       ├─ GetGruposAgregadosAsync()
            │   │       │   └─ GetItemsAgregadosArt33Async()
            │   │       │       └─ TODO: Implementar cálculos ❌
            │   │       │
            │   │       └─ GetGruposDeduccionesAsync()
            │   │           └─ GetItemsDeduccionesAsync()
            │   │               ├─ context.MovComprobante
            │   │               │   .Where(IdEmpresa, Ano)
            │   │               │   .ToListAsync()
            │   │               │
            │   │               └─ TODO: Implementar cálculos ❌
            │   │
            │   ├─ MapearAViewModel()
            │   │
            │   └─ PartialView("_AjustesGrid", viewModel)
            │       │
            │       └─ _AjustesGrid.cshtml
            │           └─ @foreach (renderizar HTML)
            │
            └─ document.getElementById('grid-container').innerHTML = html
```

---

## LÓGICA DE CÁLCULO

### VB6: LoadValCuentas()

```vb
' INPUT:
' - LstCuentas = "(123,456,789)"
' - TipoItem = "AG01"
' - NombreItem = "Ajuste por depreciación"

' PROCESO:
1. Limpiar formato: "(123,456,789)" → "123,456,789"

2. Query:
   SELECT Sum(Debe - Haber) AS Valor
   FROM MovComprobante
   INNER JOIN Comprobante ON IdComp
   WHERE IdCuenta IN (123,456,789)
     AND TipoAjuste IN (1, 3)        -- FINANCIERO o AMBOS
     AND Tipo <> 1                    -- NO Apertura
     AND IdEmpresa = @empresaId
     AND Ano = @ano

3. Obtener resultado: Tot = vFld(Rs("Valor"))

4. Formatear: Format(Abs(Tot), NEGNUMFMT)

' OUTPUT:
' - Valor: 150000 (formateado)
```

---

### .NET 9: Estado Actual

```csharp
private Task<List<ItemAjusteRliDto>> GetItemsAgregadosArt33Async(
    int empresaId, short ano)
{
    var items = new List<ItemAjusteRliDto>();

    // TODO: [LEGACY] [MEDIUM] Implementar cálculos complejos de ajustes art 33
    // Requiere análisis detallado de fórmulas tributarias específicas

    return Task.FromResult(items);
}

// RESULTADO: Lista vacía → Grid sin datos → Valores en 0
```

---

### .NET 9: Implementación Requerida

```csharp
private async Task<List<ItemAjusteRliDto>> GetItemsAgregadosArt33Async(
    int empresaId, short ano)
{
    // 1. Obtener configuración desde BD
    var configuracion = await context.AjustesExtraContRLI
        .Where(a => a.TipoAjuste == 1 && a.IdGrupo == 1 && a.Activo)
        .OrderBy(a => a.Orden)
        .ToListAsync();

    var items = new List<ItemAjusteRliDto>();

    // 2. Para cada item, calcular valor
    foreach (var config in configuracion)
    {
        var lstCuentas = config.GetListaCuentas(); // [123, 456, 789]

        // 3. Query con JOIN
        var valor = await context.MovComprobante
            .Where(m => m.IdEmpresa == empresaId && m.Ano == ano)
            .Where(m => lstCuentas.Contains(m.IdCuenta))
            .Join(
                context.Comprobante,
                m => new { m.IdComp, m.IdEmpresa, m.Ano },
                c => new { c.IdComp, c.IdEmpresa, c.Ano },
                (m, c) => new { m, c }
            )
            .Where(x => x.c.TipoAjuste == 1 || x.c.TipoAjuste == 3)
            .Where(x => x.c.Tipo != 1)
            .SumAsync(x => (decimal?)(x.m.Debe - x.m.Haber));

        // 4. Agregar item con valor calculado
        items.Add(new ItemAjusteRliDto
        {
            TipoAjuste = config.TipoAjuste,
            IdGrupo = config.IdGrupo,
            IdItem = config.IdItem,
            TipoItem = config.TipoItem ?? "",
            Concepto = config.Nombre,
            Valor = Math.Abs(valor ?? 0),
            Orden = config.Orden
        });
    }

    return items;
}
```

---

## EXPORTACIÓN CSV

### VB6: Export_RLI_HR_RAB()

```vb
' ARCHIVO:
' - Ruta: C:\HR\RUTS\12345678\ImpConta\RLI_HR_RAB_23.csv
' - Encoding: ANSI

' HEADER:
Print #Fd, "Tipo Item;Fecha;Descripción;Monto"

' DATOS:
FOR r = Grid.FixedRows TO Grid.Rows - 1
    IF Grid.TextMatrix(r, C_TIPOITEM) <> "" AND Valor <> 0 THEN

        ' Query detallado por movimiento
        SELECT Tipo, Correlativo, Fecha, (Debe - Haber) AS Valor
        FROM MovComprobante
        INNER JOIN Comprobante ON IdComp
        WHERE IdCuenta IN (LstCuentas)
          AND TipoAjuste IN (1, 3)
          AND Tipo <> 1

        ' Generar líneas
        DO WHILE NOT Rs.EOF
            Descrip = gTipoComp(Tipo) & " " & Correlativo & " " & Concepto
            Linea = TipoItem & ";" & Format(Fecha, "dd/mm/yyyy") & ";" & Descrip & ";" & Abs(Valor)
            Print #Fd, Linea
        LOOP
    END IF
NEXT r

' EJEMPLO OUTPUT:
' AG01;31/12/2023;EGRESO 123 Ajuste por depreciación;150000
' AG01;31/12/2023;EGRESO 124 Ajuste por depreciación;75000
' DD02;15/12/2023;INGRESO 45 Deducción por incentivo;50000
```

---

### .NET 9: Estado Actual

```csharp
public async Task<ExportarHrRabRadResultDto> ExportarHrRabRadAsync(...)
{
    var sb = new StringBuilder();

    // Header INCORRECTO
    sb.AppendLine("Tipo,Grupo,Item,Concepto,Valor");

    // Datos INCORRECTOS (itera por items agrupados, no por movimientos)
    foreach (var tipo in ajustes.Tipos)
    {
        foreach (var grupo in tipo.Grupos)
        {
            foreach (var item in grupo.Items)
            {
                sb.AppendLine($"{tipo.Nombre},{grupo.Nombre},{item.IdItem},{item.Concepto},{item.Valor}");
            }
        }
    }

    // EJEMPLO OUTPUT ACTUAL (INCORRECTO):
    // Tipo,Grupo,Item,Concepto,Valor
    // Agregados,A) Agregados art 33,1,Ajuste por depreciación,0
    // Agregados,A) Agregados art 33,2,Ajuste por provisiones,0
}
```

**Problema:** HR espera 1 línea por movimiento, no 1 línea por item.

---

### .NET 9: Implementación Requerida

```csharp
public async Task<ExportarHrRabRadResultDto> ExportarHrRabRadAsync(
    int empresaId, short ano)
{
    var sb = new StringBuilder();

    // Header CORRECTO
    sb.AppendLine("Tipo Item;Fecha;Descripción;Monto");

    // Obtener configuración
    var configuracion = await GetConfiguracionTodosAjustesAsync();

    // Iterar por cada item configurado
    foreach (var config in configuracion)
    {
        var lstCuentas = config.GetListaCuentas();

        // Query DETALLADO por movimiento
        var movimientos = await context.MovComprobante
            .Where(m => m.IdEmpresa == empresaId && m.Ano == ano)
            .Where(m => lstCuentas.Contains(m.IdCuenta))
            .Join(
                context.Comprobante,
                m => new { m.IdComp, m.IdEmpresa, m.Ano },
                c => new { c.IdComp, c.IdEmpresa, c.Ano },
                (m, c) => new { m, c }
            )
            .Where(x => x.c.TipoAjuste == 1 || x.c.TipoAjuste == 3)
            .Where(x => x.c.Tipo != 1)
            .Where(x => (x.m.Debe - x.m.Haber) != 0)
            .Select(x => new
            {
                Tipo = x.c.Tipo,
                Correlativo = x.c.Correlativo,
                Fecha = x.c.Fecha,
                Valor = x.m.Debe - x.m.Haber
            })
            .ToListAsync();

        // Generar líneas CSV
        foreach (var mov in movimientos)
        {
            var tipoCompNombre = GetTipoComprobanteNombre(mov.Tipo);
            var descripcion = $"{tipoCompNombre} {mov.Correlativo} {config.Nombre}";

            var linea = string.Join(";",
                config.TipoItem,
                mov.Fecha.ToString("dd/MM/yyyy"),
                descripcion,
                Math.Abs(mov.Valor).ToString("0")
            );

            sb.AppendLine(linea);
        }
    }

    // EJEMPLO OUTPUT CORRECTO:
    // Tipo Item;Fecha;Descripción;Monto
    // AG01;31/12/2023;EGRESO 123 Ajuste por depreciación;150000
    // AG01;31/12/2023;EGRESO 124 Ajuste por depreciación;75000
    // DD02;15/12/2023;INGRESO 45 Deducción por incentivo;50000

    var csvData = Encoding.UTF8.GetBytes(sb.ToString());
    var fileName = ano >= 2020
        ? $"RLI_HR_RAD_{ano:yy}.csv"
        : $"RLI_HR_RAB_{ano:yy}.csv";

    return new ExportarHrRabRadResultDto
    {
        CsvData = csvData,
        FileName = fileName
    };
}
```

---

## FILTRO "MOSTRAR SOLO CON VALORES"

### VB6

```vb
Private Sub Bt_VerSaldosPositivos_Click()
    Dim i As Integer

    ' Ocultar filas con valor = 0
    For i = Grid.FixedRows To Grid.rows - 1
        If Grid.TextMatrix(i, C_TIPOITEM) <> "" And Val(Grid.TextMatrix(i, C_VALOR)) = 0 Then
            Grid.RowHeight(i) = 0  ' Ocultar en cliente
        End If
    Next i

    Call FGrVRows(Grid, 1)
End Sub
```

**Método:** Oculta filas en el cliente (performance degradada con muchas filas).

---

### .NET 9

```csharp
// Controller
public async Task<IActionResult> GetAjustesGrid(
    int empresaId, short ano, bool mostrarSoloConValor = false)
{
    var datos = await client.GetFromApiAsync<AjustesRliCajaDto>(url!);
    var viewModel = MapearAViewModel(datos, empresaId, ano, mostrarSoloConValor);

    return PartialView("_AjustesGrid", viewModel);
}
```

```cshtml
<!-- _AjustesGrid.cshtml -->
@foreach (var item in grupo.Items.OrderBy(i => i.Orden))
{
    @* Filtro SERVER-SIDE *@
    @if (!Model.MostrarSoloConValor || item.TieneValor)
    {
        <tr>
            <td>@item.Concepto</td>
            <td>@item.ValorFormateado</td>
        </tr>
    }
}
```

**Método:** Filtro server-side (mejor performance, envía menos datos).

**Mejora:** ✅ .NET es superior en este aspecto.

---

## IMPRESIÓN

### VB6

```vb
Private Sub Bt_Print_Click()
    Call SetUpPrtGrid()
    Call gPrtLibros.PrtFlexGrid(Printer)
    Printer.Orientation = OldOrientacion
End Sub

Private Sub SetUpPrtGrid()
    Set gPrtLibros.Grid = Grid
    lOrientacion = ORIENT_VER
    Titulos(0) = Me.Caption
    gPrtLibros.Titulos = Titulos

    For i = 0 To Grid.Cols - 1
        ColWi(i) = Grid.ColWidth(i) * 0.9
    Next i

    gPrtLibros.ColWi = ColWi
    gPrtLibros.FmtCol = C_FMT
End Sub
```

**Método:** Objeto personalizado `gPrtLibros` que renderiza grid a printer.

---

### .NET 9

```javascript
function imprimir() {
    window.print();
}
```

```css
@media print {
    .no-print, button { display: none; }
    table { page-break-inside: auto; }
    tr { page-break-inside: avoid; }
}
```

**Método:** Impresión nativa del navegador con CSS print.

**Diferencia:** Más simple, pero menos control sobre formato.

---

## ARQUITECTURA DE CÓDIGO

### VB6

```
FrmAjustesExtraLibCajaRLI.frm (678 líneas)
    ├─ UI (controles)
    ├─ Event handlers (botones)
    ├─ Lógica de negocio (LoadAll, LoadValCuentas)
    ├─ Queries SQL
    ├─ Exportación (Export_RLI_HR_RAB)
    └─ Impresión (SetUpPrtGrid)

TODO EN UN SOLO ARCHIVO
```

---

### .NET 9

```
Features/AjustesRliCaja/
    ├─ Controllers/
    │   ├─ AjustesRliCajaController.cs       (UI MVC)
    │   └─ AjustesRliCajaApiController.cs    (API)
    │
    ├─ Services/
    │   ├─ IAjustesRliCajaService.cs         (Interface)
    │   └─ AjustesRliCajaService.cs          (Lógica de negocio)
    │
    ├─ DTOs/
    │   ├─ AjustesRliCajaDto.cs              (Transferencia datos)
    │   └─ AjustesRliCajaViewModel.cs        (Presentación)
    │
    └─ Views/
        ├─ Index.cshtml                       (Vista principal)
        └─ _AjustesGrid.cshtml                (Partial View)

SEPARACIÓN DE RESPONSABILIDADES
```

**Ventaja .NET:** Código más mantenible, testeable, escalable.

---

## RESUMEN DE DIFERENCIAS CLAVE

| Aspecto | VB6 | .NET 9 | Ganador |
|---------|-----|--------|:-------:|
| **Cálculo de valores** | ✅ Funcional | ❌ No implementado | VB6 |
| **Formato exportación** | ✅ Correcto | ❌ Incorrecto | VB6 |
| **Arquitectura código** | ❌ Todo junto | ✅ Separado | .NET |
| **UI/UX** | ❌ Antigua | ✅ Moderna | .NET |
| **Performance** | ❌ Cliente pesado | ✅ Server-side | .NET |
| **Mantenibilidad** | ❌ Baja | ✅ Alta | .NET |
| **Testing** | ❌ Difícil | ✅ Fácil | .NET |
| **Escalabilidad** | ❌ Bloqueante | ✅ Async | .NET |
| **Observabilidad** | ❌ Sin logs | ✅ Logging | .NET |
| **Funcionalidad core** | ✅ 100% | ❌ 0% | VB6 |

**Veredicto:**
- VB6 tiene la funcionalidad completa pero código legacy
- .NET tiene excelente arquitectura pero falta implementar la lógica
- Con 1 semana de trabajo, .NET superará a VB6 en todos los aspectos

---

**Fecha:** 2025-12-06
**Objetivo:** Guía visual para entender diferencias y guiar implementación
