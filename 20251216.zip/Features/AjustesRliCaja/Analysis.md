# Legacy Analysis: Ajustes RLI Caja

## 📄 VB6: FrmAjustesExtraLibCajaRLI.frm
**Propósito:** Visualización y exportación de Ajustes Extra-Contables RLI HR RAB/RAD

### Descripción
Grid de solo lectura que muestra ajustes extra-contables para Régimen de Libre Imputación (RLI), estructurado jerárquicamente en:
- **Tipos de Ajuste** (gTipoAjustesECRLI)
- **Grupos** (gGrupoAjustesECRLI)
- **Items** (gAjustesExtraContRLI)

### Estructura Jerárquica
```
TIPO AJUSTE 1 (k)
   GRUPO 1 (j)
      Item 1 (i) - Valor calculado
      Item 2 (i) - Valor calculado
   GRUPO 2 (j)
      Item 3 (i) - Valor calculado
TIPO AJUSTE 2 (k)
   ...
```

### Constantes
```vb
C_ID = 0                ' Hidden
C_TIPOAJUSTE = 1        ' Hidden (k)
C_IDGRUPO = 2           ' Hidden (j)
C_IDITEM = 3            ' Hidden (i)
C_TIPOITEM = 4          ' Hidden - código item para exportación
C_CONCEPTO = 5          ' Nombre del item (indentado)
C_VALOR = 6             ' Valor calculado
C_FMT = 7               ' Hidden - formato
C_COLOBLIGATORIA = 8    ' Hidden
C_UPD = 9               ' Hidden
```

### Configuración Global (VB6)
- `gTipoAjustesECRLI(k)`: Nombres de tipos de ajuste
- `gGrupoAjustesECRLI(k, j)`: Nombres de grupos
- `gAjustesExtraContRLI(k, j, i)`: Estructura con:
  - `.Nombre`: Nombre del item
  - `.orden`: Orden de presentación
  - `.TipoItem`: Código para exportación
  - `.LstCuentas`: Lista de IdCuentas asociadas (formato: "|123|456|")

### Cálculo de Valores
```vb
LoadValCuentas(LstCuentas) Returns Double
```
**Query:**
```sql
SELECT Sum(Debe - Haber) 
FROM MovComprobante 
INNER JOIN Comprobante 
WHERE IdCuenta IN (LstCuentas)
  AND TipoAjuste IN (TAJUSTE_FINANCIERO, TAJUSTE_AMBOS)
  AND Comprobante.Tipo <> TC_APERTURA
  AND Comprobante.IdEmpresa = ? 
  AND Comprobante.Ano = ?
```

### Funcionalidades

#### 1. Mostrar Partidas con Valores
**Botón**: `Bt_VerSaldosPositivos`
- Oculta filas con valor = 0
- Solo items (no títulos)
- `Grid.RowHeight(i) = 0`

#### 2. Exportar a HR RAB/RAD
**Botón**: `Bt_ExportHRRAB`
**Archivo**: `RLI_HR_RAB_YY.csv` o `RLI_HR_RAD_YY.csv` (desde 2020)
**Ruta**: `C:\HR\RUTS\[RUT]\ImpConta\`

**Formato CSV:**
```
Tipo Item;Fecha;Descripción;Monto
A;01/03/2025;INGRESO 123 Concepto Item;15000
B;15/03/2025;EGRESO 456 Concepto Item;8500
```

**Lógica Exportación:**
- Por cada fila con TipoItem <> "" y Valor <> 0:
  - Extrae movimientos individuales del comprobante
  - Línea por movimiento (no agregado)
  - Descripción: TipoComp + Correlativo + NombreItem
  - Valor: Abs(Debe - Haber)

**Query Detalle:**
```sql
SELECT Comprobante.Tipo, Correlativo, Fecha, 
       (Debe - Haber) as Valor
FROM MovComprobante 
INNER JOIN Comprobante
WHERE IdCuenta IN (LstCuentas)
  AND TipoAjuste IN (FINANCIERO, AMBOS)
  AND Comprobante.Tipo <> APERTURA
```

### Cambio 2020
Si `gEmpresa.Ano >= 2020`:
- Caption: "RLI HR RAD" (antes "RLI HR RAB")
- Archivo: `RLI_HR_RAD_YY.csv`

### Herramientas Toolbar
- **Imprimir/Vista Previa**: Imprime grid
- **Copiar Excel**: Exporta a clipboard
- **Suma**: Suma seleccionados
- **Calculadora/Calendario/Conversor**: Utilidades

**Entidades:** `CtasAjustesExContRLI`, `MovComprobante`, `Comprobante`
**Config Global**: `gTipoAjustesECRLI`, `gGrupoAjustesECRLI`, `gAjustesExtraContRLI` (arrays VB6)


## 📄 VB6: FrmAjustesExtraLibCajaRLI.frm
**Propósito:** Visualización y exportación de Ajustes Extra-Contables RLI HR RAB/RAD

### Descripción
Grid de solo lectura que muestra ajustes extra-contables para Régimen de Libre Imputación (RLI), estructurado jerárquicamente en:
- **Tipos de Ajuste** (gTipoAjustesECRLI)
- **Grupos** (gGrupoAjustesECRLI)
- **Items** (gAjustesExtraContRLI)

### Estructura Jerárquica
```
TIPO AJUSTE 1 (k)
   GRUPO 1 (j)
      Item 1 (i) - Valor calculado
      Item 2 (i) - Valor calculado
   GRUPO 2 (j)
      Item 3 (i) - Valor calculado
TIPO AJUSTE 2 (k)
   ...
```

### Constantes
```vb
C_ID = 0                ' Hidden
C_TIPOAJUSTE = 1        ' Hidden (k)
C_IDGRUPO = 2           ' Hidden (j)
C_IDITEM = 3            ' Hidden (i)
C_TIPOITEM = 4          ' Hidden - código item para exportación
C_CONCEPTO = 5          ' Nombre del item (indentado)
C_VALOR = 6             ' Valor calculado
C_FMT = 7               ' Hidden - formato
C_COLOBLIGATORIA = 8    ' Hidden
C_UPD = 9               ' Hidden
```

### Configuración Global (VB6)
- `gTipoAjustesECRLI(k)`: Nombres de tipos de ajuste
- `gGrupoAjustesECRLI(k, j)`: Nombres de grupos
- `gAjustesExtraContRLI(k, j, i)`: Estructura con:
  - `.Nombre`: Nombre del item
  - `.orden`: Orden de presentación
  - `.TipoItem`: Código para exportación
  - `.LstCuentas`: Lista de IdCuentas asociadas (formato: "|123|456|")

### Cálculo de Valores
```vb
LoadValCuentas(LstCuentas) Returns Double
```
**Query:**
```sql
SELECT Sum(Debe - Haber) 
FROM MovComprobante 
INNER JOIN Comprobante 
WHERE IdCuenta IN (LstCuentas)
  AND TipoAjuste IN (TAJUSTE_FINANCIERO, TAJUSTE_AMBOS)
  AND Comprobante.Tipo <> TC_APERTURA
  AND Comprobante.IdEmpresa = ? 
  AND Comprobante.Ano = ?
```

### Funcionalidades

#### 1. Mostrar Partidas con Valores
**Botón**: `Bt_VerSaldosPositivos`
- Oculta filas con valor = 0
- Solo items (no títulos)
- `Grid.RowHeight(i) = 0`

#### 2. Exportar a HR RAB/RAD
**Botón**: `Bt_ExportHRRAB`
**Archivo**: `RLI_HR_RAB_YY.csv` o `RLI_HR_RAD_YY.csv` (desde 2020)
**Ruta**: `C:\HR\RUTS\[RUT]\ImpConta\`

**Formato CSV:**
```
Tipo Item;Fecha;Descripción;Monto
A;01/03/2025;INGRESO 123 Concepto Item;15000
B;15/03/2025;EGRESO 456 Concepto Item;8500
```

**Lógica Exportación:**
- Por cada fila con TipoItem <> "" y Valor <> 0:
  - Extrae movimientos individuales del comprobante
  - Línea por movimiento (no agregado)
  - Descripción: TipoComp + Correlativo + NombreItem
  - Valor: Abs(Debe - Haber)

**Query Detalle:**
```sql
SELECT Comprobante.Tipo, Correlativo, Fecha, 
       (Debe - Haber) as Valor
FROM MovComprobante 
INNER JOIN Comprobante
WHERE IdCuenta IN (LstCuentas)
  AND TipoAjuste IN (FINANCIERO, AMBOS)
  AND Comprobante.Tipo <> APERTURA
```

### Cambio 2020
Si `gEmpresa.Ano >= 2020`:
- Caption: "RLI HR RAD" (antes "RLI HR RAB")
- Archivo: `RLI_HR_RAD_YY.csv`

### Herramientas Toolbar
- **Imprimir/Vista Previa**: Imprime grid
- **Copiar Excel**: Exporta a clipboard
- **Suma**: Suma seleccionados
- **Calculadora/Calendario/Conversor**: Utilidades

**Entidades:** `CtasAjustesExContRLI`, `MovComprobante`, `Comprobante`
**Config Global**: `gTipoAjustesECRLI`, `gGrupoAjustesECRLI`, `gAjustesExtraContRLI` (arrays VB6)

