# 📊 Reporte de Gaps: AjustesRliCaja
## Comparación VB6 → .NET 9

**Fecha de análisis:** 2025-12-06  
**Feature:** AjustesRliCaja (Ajustes Extra-Contables RLI HR RAB/RAD)  
**Formulario VB6:** `FrmAjustesExtraLibCajaRLI.frm`  
**Feature .NET:** `Features\AjustesRliCaja\`  
**Importancia:** 🟠 ALTA  
**Estado general:** **73.3% PARIDAD**

---

## 📋 Resumen Ejecutivo

| Métrica | Valor |
|---------|-------|
| **Paridad General** | **73.3%** (63/86 aspectos) |
| **Aspectos OK** | 56 |
| **Aspectos N/A** | 7 |
| **Gaps Críticos** | 6 |
| **Gaps Altos** | 2 |
| **Gaps Medios** | 3 |
| **Mejoras en .NET** | 4 |

### Estado por Categoría

| Categoría | Total | OK | N/A | Gaps | % Paridad |
|-----------|:-----:|:--:|:---:|:----:|:---------:|
| 1. Inputs/Dependencias | 6 | 5 | 0 | 1 | 83.3% |
| 2. Datos y Persistencia | 10 | 4 | 4 | 2 | 80.0% |
| 3. Acciones y Operaciones | 6 | 5 | 1 | 0 | 100.0% |
| 4. Validaciones | 6 | 4 | 0 | 2 | 66.7% |
| 5. Cálculos y Lógica | 5 | 1 | 1 | 3 | 50.0% |
| 6. Interfaz y UX | 5 | 5 | 0 | 0 | 100.0% |
| 7. Seguridad | 2 | 2 | 0 | 0 | 100.0% |
| 8. Manejo de Errores | 2 | 2 | 0 | 0 | 100.0% |
| 9. Outputs/Salidas | 6 | 5 | 0 | 1 | 83.3% |
| 10. Controles UI | 6 | 4 | 2 | 0 | 100.0% |
| 11. Grids y Columnas | 2 | 2 | 0 | 0 | 100.0% |
| 12. Eventos e Interacción | 5 | 3 | 2 | 0 | 100.0% |
| 13. Estados y Modos | 3 | 3 | 0 | 0 | 100.0% |
| 14. Inicialización | 3 | 3 | 0 | 0 | 100.0% |
| 15. Filtros y Búsqueda | 2 | 2 | 0 | 0 | 100.0% |
| 16. Reportes | 2 | 1 | 1 | 0 | 100.0% |
| 17. Reglas de Negocio | 4 | 2 | 0 | 2 | 50.0% |
| 18. Flujos de Trabajo | 3 | 3 | 0 | 0 | 100.0% |
| 19. Integraciones | 3 | 2 | 1 | 0 | 100.0% |
| 20. Mensajes al Usuario | 2 | 2 | 0 | 0 | 100.0% |
| 21. Casos Borde | 3 | 3 | 0 | 0 | 100.0% |

### Veredicto

🟠 **ACEPTABLE CON GAPS DOCUMENTADOS** - La migración alcanza 73.3% de paridad funcional. Los gaps críticos están concentrados en:
1. **Lógica de cálculo de ajustes tributarios** - Query principal NO implementada
2. **Exportación HR RAB/RAD** - Formato CSV incorrecto para integración externa
3. **Configuración de ajustes** - Estructura de datos incompleta

La UI, navegación y estructura general están completas.

---

## 1️⃣ INPUTS / DEPENDENCIAS DE ENTRADA (6 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 1 | Variables globales | `gEmpresa.id`, `gEmpresa.Ano`, `gUsuario` | `SessionHelper.EmpresaId`, `SessionHelper.Ano` | ✅ |
| 2 | Parámetros de entrada | Ninguno (modal usa `FEdit()`) | Route implícitos desde sesión | ✅ |
| 3 | Configuraciones | `gTipoAjustesECRLI()`, `gGrupoAjustesECRLI()`, `gAjustesExtraContRLI()` | Hardcoded en Service | ⚠️ |
| 4 | Estado previo requerido | Empresa y año seleccionados | Empresa y año desde sesión | ✅ |
| 5 | Datos maestros necesarios | Plan de cuentas, comprobantes, movimientos | Mismos datos | ✅ |
| 6 | Conexión/Sesión | `DbMain`, `gDbType` | `LpContabContext` (EF Core) | ✅ |

**Gap identificado:**

⚠️ **MEDIO - GAP-001: Configuración de ajustes hardcoded**
```
VB6: Usa arrays globales con estructura completa:
  gAjustesExtraContRLI(k, j, i).Nombre
  gAjustesExtraContRLI(k, j, i).TipoItem
  gAjustesExtraContRLI(k, j, i).LstCuentas  ← CRÍTICO: lista de cuentas a sumar
  gAjustesExtraContRLI(k, j, i).orden

.NET: Estructura hardcoded SIN LstCuentas (líneas 23-75 AjustesRliCajaService.cs)
```

---

## 2️⃣ DATOS Y PERSISTENCIA (10 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 7 | Queries SELECT | `OpenRs()` con `SELECT Sum(Debe-Haber)` + JOIN | `context.MovComprobante.Where()` | 🔴 |
| 8 | Queries INSERT | N/A (solo lectura) | N/A | ✅ |
| 9 | Queries UPDATE | N/A (solo lectura) | N/A | ✅ |
| 10 | Queries DELETE | N/A (solo lectura) | N/A | ✅ |
| 11 | Stored Procedures | No usa | No usa | ✅ |
| 12 | Tablas accedidas | `MovComprobante`, `Comprobante` (JOIN) | Solo `MovComprobante` | 🔴 |
| 13 | Campos leídos | `Debe`, `Haber`, `IdCuenta`, `TipoAjuste`, `Tipo`, `Fecha`, `Correlativo` | Solo `IdEmpresa`, `Ano` | 🔴 |
| 14 | Campos escritos | N/A (solo lectura) | N/A | ✅ |
| 15 | Transacciones | N/A (solo lectura) | N/A | ✅ |
| 16 | Concurrencia | N/A (solo lectura) | N/A | ✅ |

**Gaps identificados:**

🔴 **CRÍTICO - GAP-002: Query de cálculo NO implementada**
```sql
-- VB6 (LoadValCuentas, líneas 397-428):
SELECT Sum(Debe - Haber) as Valor
FROM MovComprobante 
INNER JOIN Comprobante ON (MovComprobante.IdComp = Comprobante.IdComp 
  AND Comprobante.IdEmpresa = MovComprobante.IdEmpresa 
  AND Comprobante.Ano = MovComprobante.Ano)
WHERE IdCuenta IN ({LstCuentas})
  AND TipoAjuste IN (TAJUSTE_FINANCIERO, TAJUSTE_AMBOS)
  AND Comprobante.Tipo <> TC_APERTURA
  AND Comprobante.IdEmpresa = {empresaId} 
  AND Comprobante.Ano = {ano}

-- .NET (líneas 88-120): TODO marcados, retorna lista vacía
```

🔴 **CRÍTICO - GAP-003: JOIN con Comprobante faltante**
```
VB6: Filtra por:
  - Comprobante.TipoAjuste IN (FINANCIERO, AMBOS)
  - Comprobante.Tipo <> TC_APERTURA (excluir apertura)

.NET: No accede a tabla Comprobante, solo filtra por IdEmpresa y Ano
```

🔴 **CRÍTICO - GAP-004: Campos de filtrado faltantes**
```
VB6 usa: IdCuenta, TipoAjuste (de Comprobante), Tipo (de Comprobante)
.NET usa: Solo IdEmpresa, Ano (filtro insuficiente)
```

---

## 3️⃣ ACCIONES Y OPERACIONES (6 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 17 | Botones/Acciones | 10 botones totales | 4 acciones principales | ⚠️ |
| 18 | Operaciones CRUD | Solo lectura (R) | Solo lectura (R) | ✅ |
| 19 | Operaciones especiales | Exportar, Filtrar, Imprimir | Exportar, Filtrar, Imprimir | ✅ |
| 20 | Búsquedas | N/A | N/A | ✅ |
| 21 | Ordenamiento | Por `gAjustesExtraContRLI().orden` | `.OrderBy(i => i.Orden)` | ✅ |
| 22 | Paginación | N/A (todo en pantalla) | N/A | ✅ |

**Botones utilitarios faltantes (NO críticos):**
| Botón VB6 | Función | Estado .NET |
|-----------|---------|:-----------:|
| `Bt_Preview` | Vista previa impresión | ✅ `window.print()` |
| `Bt_Print` | Imprimir | ✅ `window.print()` |
| `Bt_CopyExcel` | Copiar a Excel | ✅ `exportarExcel()` |
| `Bt_VerSaldosPositivos` | Filtrar con valores | ✅ `mostrarConValor()` |
| `Bt_ExportHRRAB` | Exportar HR | ✅ `exportarHrRabRad()` |
| `Bt_Cancelar` | Cerrar | ✅ Navegación |
| `Bt_Sum` | Sumar selección | ❌ N/A |
| `Bt_ConvMoneda` | Conversor moneda | ❌ N/A |
| `Bt_Calc` | Calculadora | ❌ N/A |
| `Bt_Calendar` | Calendario | ❌ N/A |

---

## 4️⃣ VALIDACIONES (6 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 23 | Campos requeridos | Empresa y Año validados | Desde sesión | ✅ |
| 24 | Validación de rangos | `gEmpresa.Ano >= 2020` → RAD/RAB | `ano >= 2020` | ✅ |
| 25 | Validación de formato | N/A | N/A | ✅ |
| 26 | Validación de longitud | N/A | N/A | ✅ |
| 27 | Validaciones custom | `If LstCuentas = "" Then Exit` | No implementado | ⚠️ |
| 28 | Manejo de nulos | `vFld()` en queries | Sin implementar | ⚠️ |

**Gaps identificados:**

⚠️ **MEDIO - GAP-005: Validación de lista de cuentas vacía**
```vb
' VB6 (líneas 403-406):
If LstCuentas = "" Then
   LoadValCuentas = 0
   Exit Function
End If

' .NET: No valida porque query no está implementada
```

---

## 5️⃣ CÁLCULOS Y LÓGICA (5 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 29 | Funciones de cálculo | `LoadValCuentas()` - `Sum(Debe-Haber)` | TODOs pendientes | 🔴 |
| 30 | Redondeos | `Format(Abs(valor), NEGNUMFMT)` | `Math.Abs()` + formato 0 decimales | ✅ |
| 31 | Campos calculados | Valor calculado desde DB en tiempo real | Valores en 0 | 🔴 |
| 32 | Dependencias campos | N/A (recarga al filtrar) | Recarga desde servidor | ✅ |
| 33 | Valores por defecto | Todos en 0 hasta cargar | Todos en 0 | ✅ |

**Gaps identificados:**

🔴 **CRÍTICO - GAP-006: Función LoadValCuentas NO implementada**
```vb
' VB6 (líneas 397-428):
Private Function LoadValCuentas(Row, TipoItem, NombreItem, LstCuentas) As Double
   Q1 = "SELECT Sum(Debe - Haber) as Valor "
   Q1 = Q1 & " FROM MovComprobante INNER JOIN Comprobante..."
   Q1 = Q1 & " WHERE IdCuenta IN (" & LstCuentas & ")"
   Q1 = Q1 & " AND TipoAjuste IN (" & TAJUSTE_FINANCIERO & "," & TAJUSTE_AMBOS & ")"
   ...
End Function

' .NET (líneas 84-120 AjustesRliCajaService.cs):
// TODO: [LEGACY] [MEDIUM] Implementar cálculos complejos de ajustes art 33
// Requiere análisis detallado de fórmulas tributarias específicas
return Task.FromResult(items);  // Retorna lista vacía
```

🔴 **CRÍTICO - GAP-007: Estructura de configuración incompleta**
```
VB6: gAjustesExtraContRLI(k, j, i) contiene:
  .Nombre        → Descripción del ajuste
  .TipoItem      → Código para exportación HR
  .LstCuentas    → Lista cuentas: "(101,102,103)" ← FALTA EN .NET
  .orden         → Orden de visualización

.NET: ItemAjusteRliDto NO tiene propiedad LstCuentas
```

---

## 6️⃣ INTERFAZ Y UX (5 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 34 | Combos/Listas | N/A | N/A | ✅ |
| 35 | Mensajes usuario | `MsgBox1` con mensajes específicos | `Swal.fire()` equivalentes | ✅ |
| 36 | Confirmaciones | N/A | N/A | ✅ |
| 37 | Habilitaciones UI | Botones siempre habilitados | Botones siempre habilitados | ✅ |
| 38 | Formatos display | `Format(Abs(valor), NEGNUMFMT)` | Formato chileno 0 decimales | ✅ |

---

## 7️⃣ SEGURIDAD (2 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 39 | Permisos requeridos | Validado en menú | Middleware autenticación | ✅ |
| 40 | Validación acceso | Implícito | Implícito | ✅ |

---

## 8️⃣ MANEJO DE ERRORES (2 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 41 | Captura errores | `On Error Resume Next` en export | `try/catch` en Service y JS | ✅ |
| 42 | Mensajes de error | `MsgErr FPath` | `BusinessException` + `Swal.fire()` | ✅ |

---

## 9️⃣ OUTPUTS / SALIDAS (6 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 43 | Datos de retorno | N/A (modal sin retorno) | N/A | ✅ |
| 44 | Exportar Excel | `LP_FGr2String()` + Clipboard | `exportarExcel()` tabla→.xls | ✅ |
| 45 | Exportar PDF | No tiene | No tiene | ✅ |
| 46 | Exportar CSV/Texto | `Export_RLI_HR_RAB()` formato específico | `ExportarHrRabRadAsync()` | 🔴 |
| 47 | Impresión | `gPrtLibros.PrtFlexGrid()` | `window.print()` | ✅ |
| 48 | Llamadas a otros módulos | No llama otros forms | No llama otros módulos | ✅ |

**Gap identificado:**

🔴 **CRÍTICO - GAP-008: Formato exportación CSV incompatible**
```
VB6 (líneas 612, 646-648):
  Header: "Tipo Item;Fecha;Descripción;Monto"
  Separador: ;
  Fecha: dd/mm/yyyy
  Descripción: [TipoComp] [Correlativo] [Concepto]
  
.NET (línea 136 AjustesRliCajaService.cs):
  Header: "Tipo,Grupo,Item,Concepto,Valor"
  Separador: ,
  Sin Fecha
  Sin detalle de comprobante

❌ FORMATO INCOMPATIBLE - El archivo HR externo NO podrá procesarlo
```

**Query de exportación VB6 (detalle por comprobante):**
```sql
SELECT Comprobante.Tipo, Comprobante.Correlativo, Comprobante.Fecha,
       MovComprobante.Debe - MovComprobante.Haber as Valor
FROM MovComprobante 
INNER JOIN Comprobante ON ...
WHERE IdCuenta IN ({LstCuentas})
  AND TipoAjuste IN (FINANCIERO, AMBOS)
  AND Comprobante.Tipo <> TC_APERTURA
```

---

## 🔟 PARIDAD DE CONTROLES UI (6 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 49 | TextBoxes | N/A (solo visualización) | N/A | ✅ |
| 50 | Labels/Etiquetas | Título en Caption | `<h1>` dinámico | ✅ |
| 51 | ComboBoxes/Selects | N/A | N/A | ✅ |
| 52 | Grids/Tablas | FlexEdGrid 10 cols (2 visibles) | `<table>` 2 cols | ✅ |
| 53 | CheckBoxes | N/A | N/A | ✅ |
| 54 | Campos ocultos | Columnas ocultas en grid | `data-tipo-item` attr | ✅ |

---

## 1️⃣1️⃣ GRIDS Y COLUMNAS (2 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 55 | Columnas del grid | 2 visibles: Concepto (9400px), Valor (1600px) | 2 cols: Concepto, Valor | ✅ |
| 56 | Datos del grid | `LoadAll()` con loop Tipo→Grupo→Item | `@foreach` con ViewModel | ✅ |

**Verificación de columnas:**
```
VB6:                                    .NET:
✅ Concepto (indentado con espacios)    ✅ Concepto (indentado con &nbsp;)
✅ Valor (alineación derecha)           ✅ Valor (text-right)
✅ Filas de título en BOLD+gris         ✅ Filas tipo en bg-gray-100 font-bold
✅ Filas de grupo en BOLD+gris          ✅ Filas grupo en bg-gray-50 font-semibold
```

---

## 1️⃣2️⃣ EVENTOS E INTERACCIÓN (5 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 57 | Doble clic | No implementado | N/A | ✅ |
| 58 | Teclas especiales | No implementado | N/A | ✅ |
| 59 | Eventos Change | N/A (solo lectura) | N/A | ✅ |
| 60 | Menú contextual | No implementado | N/A | ✅ |
| 61 | Modales Lookup | N/A | N/A | ✅ |

---

## 1️⃣3️⃣ ESTADOS Y MODOS DEL FORMULARIO (3 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 62 | Modos del form | Modo View único (`FEdit()`) | Vista Index única | ✅ |
| 63 | Controles por modo | Todos solo lectura | Solo lectura | ✅ |
| 64 | Orden de tabulación | N/A (sin inputs) | N/A | ✅ |

---

## 1️⃣4️⃣ INICIALIZACIÓN Y CARGA (3 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 65 | Carga inicial | `Form_Load()` → `SetUpGrid()` → `LoadAll()` | `cargarDatos()` al montar | ✅ |
| 66 | Valores por defecto | Ninguno (solo muestra) | Ninguno | ✅ |
| 67 | Llenado de combos | N/A | N/A | ✅ |

---

## 1️⃣5️⃣ FILTROS Y BÚSQUEDA (2 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 68 | Campos de filtro | Botón "Mostrar solo con valores" | Botón "Mostrar Partidas con Valores" | ✅ |
| 69 | Criterios de búsqueda | Oculta filas con valor = 0 | Filtro server-side | ✅ |

---

## 1️⃣6️⃣ REPORTES E IMPRESIÓN (2 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 70 | Reportes disponibles | `gPrtLibros.PrtFlexGrid()` | `window.print()` CSS | ✅ |
| 71 | Parámetros de reporte | Título dinámico RAB/RAD | Título dinámico | ✅ |

---

## 1️⃣7️⃣ REGLAS DE NEGOCIO (4 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 72 | Umbrales y límites | `Ano >= 2020` → RAD, sino RAB | Misma lógica | ✅ |
| 73 | Fórmulas de cálculo | `Sum(Debe - Haber)` con filtros | No implementado | 🔴 |
| 74 | Condiciones de negocio | `TipoAjuste IN (FINANCIERO, AMBOS) AND Tipo <> APERTURA` | No implementado | 🔴 |
| 75 | Restricciones | Solo lectura | Solo lectura | ✅ |

---

## 1️⃣8️⃣ FLUJOS DE TRABAJO (3 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 76 | Secuencia de estados | N/A (vista estática) | N/A | ✅ |
| 77 | Acciones por estado | Solo visualización/export | Solo visualización/export | ✅ |
| 78 | Transiciones válidas | N/A | N/A | ✅ |

---

## 1️⃣9️⃣ INTEGRACIONES ENTRE MÓDULOS (3 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 79 | Llamadas a otros módulos | `FrmSumSimple`, `FrmConverMoneda`, `FrmCalendar` (utilitarios) | N/A | ✅ |
| 80 | Parámetros de integración | Grid a `FViewSum()` | N/A | ✅ |
| 81 | Datos compartidos/retorno | Ninguno | N/A | ✅ |

---

## 2️⃣0️⃣ MENSAJES AL USUARIO (2 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 82 | Mensajes de error | `MsgErr`, "No existen datos para generar archivo" | `Swal.fire()` equivalente | ✅ |
| 83 | Mensajes de confirmación | "Proceso de exportación finalizado" + ruta | `Swal.fire()` con nombre archivo | ✅ |

**Catálogo de mensajes:**
| Contexto | VB6 | .NET | Estado |
|----------|-----|------|:------:|
| Sin datos para exportar | "No existen datos para generar archivo Ajustes Extra - Contables RLI HR {RAB/RAD}..." | `BusinessException("No existen datos para generar archivo")` | ✅ |
| Exportación exitosa | "Proceso de exportación finalizado. Se ha generado el archivo: {ruta}" | `Swal.fire()` "Proceso de exportación finalizado. Se ha generado el archivo: {nombre}" | ✅ |
| Error de archivo | `MsgErr FPath` | `try/catch` + `Swal.fire()` error | ✅ |

---

## 2️⃣1️⃣ CASOS BORDE Y VALORES ESPECIALES (3 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 84 | Valores cero | Permite (filtra con botón) | Permite (filtra con botón) | ✅ |
| 85 | Valores negativos | Muestra `Abs(valor)` | Muestra `Math.Abs(Valor)` | ✅ |
| 86 | Valores nulos/vacíos | `vFld()` previene nulos | `??` operators | ✅ |

---

## 📊 RESUMEN DE GAPS

### 🔴 Gaps Críticos (6)

| ID | Descripción | Impacto | Acción Requerida |
|----|-------------|---------|------------------|
| GAP-002 | Query de cálculo NO implementada | Sin datos reales | Implementar query con JOIN |
| GAP-003 | JOIN con Comprobante faltante | Filtros incorrectos | Agregar JOIN a Comprobante |
| GAP-004 | Campos de filtrado faltantes | Datos incorrectos | Agregar filtros TipoAjuste, Tipo |
| GAP-006 | Función LoadValCuentas NO implementada | Sin cálculos | Implementar lógica completa |
| GAP-007 | Estructura de configuración incompleta | Sin lista de cuentas | Agregar LstCuentas a config |
| GAP-008 | Formato exportación CSV incompatible | Integración HR rota | Corregir formato CSV |

### 🟠 Gaps Altos (2)

| ID | Descripción | Impacto | Acción Requerida |
|----|-------------|---------|------------------|
| GAP-001 | Configuración hardcoded | Mantenibilidad | Mover a BD o archivo config |
| - | Botones utilitarios faltantes | UX menor | Opcional (Sum, Calc, Calendar) |

### 🟡 Gaps Menores (3)

| ID | Descripción | Impacto | Acción Requerida |
|----|-------------|---------|------------------|
| GAP-005 | Validación lista cuentas vacía | Edge case | Agregar validación |
| - | Separador CSV distinto (`,` vs `;`) | Compatibilidad | Cambiar a `;` |
| - | Ruta de exportación diferente | N/A en web | Aceptable |

### ✅ Mejoras sobre VB6 (4)

| Mejora | Descripción |
|--------|-------------|
| Renderizado server-side | Partial Views en vez de JavaScript puro |
| Diseño responsive | TailwindCSS moderno |
| SweetAlert2 | Mejores notificaciones que MsgBox |
| Exportación directa | Download sin crear archivo en servidor |

---

## 🔧 PLAN DE REMEDIACIÓN

### Prioridad 1: Críticos (Bloquean uso)

1. **Implementar configuración de ajustes con LstCuentas**
   ```csharp
   // En tabla CtasAjustesExContRLI o similar
   public class ConfigAjusteRli {
       public int TipoAjuste { get; set; }
       public int IdGrupo { get; set; }
       public int IdItem { get; set; }
       public string Nombre { get; set; }
       public string TipoItem { get; set; }
       public string LstCuentas { get; set; }  // "(101,102,103)"
       public int Orden { get; set; }
   }
   ```

2. **Implementar query de cálculo**
   ```csharp
   // En AjustesRliCajaService.cs
   private async Task<decimal> LoadValCuentasAsync(string lstCuentas, int empresaId, short ano)
   {
       var cuentas = lstCuentas.Trim('(', ')').Split(',').Select(int.Parse).ToList();
       
       var valor = await (from mov in context.MovComprobante
                          join comp in context.Comprobante 
                            on new { mov.IdComp, mov.IdEmpresa, mov.Ano } 
                            equals new { comp.IdComp, comp.IdEmpresa, comp.Ano }
                          where cuentas.Contains(mov.IdCuenta)
                            && (comp.TipoAjuste == TAJUSTE_FINANCIERO || comp.TipoAjuste == TAJUSTE_AMBOS)
                            && comp.Tipo != TC_APERTURA
                            && comp.IdEmpresa == empresaId
                            && comp.Ano == ano
                          select mov.Debe - mov.Haber).SumAsync();
       
       return valor;
   }
   ```

3. **Corregir formato exportación CSV**
   ```csharp
   // Header correcto
   sb.AppendLine("Tipo Item;Fecha;Descripción;Monto");
   
   // Datos con detalle de comprobante
   foreach (var mov in movimientos)
   {
       var descripcion = $"{tipoComp} {mov.Correlativo} {concepto}";
       sb.AppendLine($"{tipoItem};{mov.Fecha:dd/MM/yyyy};{descripcion};{Math.Abs(mov.Valor)}");
   }
   ```

### Prioridad 2: Medios (Funcionalidad degradada)

4. Agregar validación de lista de cuentas vacía
5. Mover configuración a base de datos

### Prioridad 3: Menores (Opcional)

6. Implementar botones utilitarios (Sum, Calc, Calendar)
7. Agregar separador configurable para CSV

---

## ✅ CONCLUSIÓN

| Aspecto | Estado |
|---------|--------|
| **Paridad UI/UX** | ✅ 100% - Diseño moderno equivalente |
| **Paridad Funcional** | 🔴 20% - Cálculos NO implementados |
| **Paridad Datos** | 🔴 40% - Queries pendientes |
| **Paridad Exportación** | 🔴 50% - Formato incorrecto |

**Recomendación:** 🔴 **NO APTO PARA PRODUCCIÓN** hasta implementar GAP-002 a GAP-008. La UI está lista pero la lógica de negocio (cálculo de ajustes tributarios) no está migrada.

**Esfuerzo estimado de remediación:** 8-12 horas desarrollo
