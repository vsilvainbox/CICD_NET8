using Microsoft.AspNetCore.Mvc;
using App.Extensions;

namespace App.Features.AjustesRliCaja;

public class AjustesRliCajaController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<AjustesRliCajaController> logger) : Controller
{
    public IActionResult Index()
    {
        logger.LogInformation("AjustesRliCaja index accessed");

        return View();
    }

    /// <summary>
    /// Endpoint que retorna HTML renderizado (Partial View) con los ajustes
    /// Sigue el patrón: Server-Side Rendering con AJAX parcial
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetAjustesGrid(int empresaId, short ano, bool mostrarSoloConValor = false)
    {
        logger.LogInformation("GetAjustesGrid: empresaId={EmpresaId}, ano={Ano}, filtro={Filtro}",
            empresaId, ano, mostrarSoloConValor);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AjustesRliCajaApiController>(
            HttpContext,
            nameof(AjustesRliCajaApiController.GetAjustes),
            new { empresaId, ano });

        var datos = await client.GetFromApiAsync<AjustesRliCajaDto>(url!);

        // Mapear DTO a ViewModel
        var viewModel = MapearAViewModel(datos, empresaId, ano, mostrarSoloConValor);

        // Retornar HTML renderizado
        return PartialView("_AjustesGrid", viewModel);
    }

    /// <summary>
    /// Endpoint legacy para compatibilidad (puede eliminarse después)
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetAjustes(int empresaId, short ano)
    {
        logger.LogInformation("Proxying GetAjustes: empresaId={EmpresaId}, ano={Ano}", empresaId, ano);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AjustesRliCajaApiController>(
            HttpContext,
            nameof(AjustesRliCajaApiController.GetAjustes),
            new { empresaId, ano });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Mapea el DTO de la API al ViewModel de la vista
    /// </summary>
    private AjustesRliCajaViewModel MapearAViewModel(AjustesRliCajaDto dto, int empresaId, short ano, bool mostrarSoloConValor)
    {
        var viewModel = new AjustesRliCajaViewModel
        {
            EmpresaId = empresaId,
            Ano = ano,
            MostrarSoloConValor = mostrarSoloConValor
        };

        // Mapear tipos con índice para saber cuál es el primero
        viewModel.Tipos = dto.Tipos.Select((tipo, idx) => new TipoAjusteRliViewModel
        {
            IdTipo = tipo.IdTipo,
            Nombre = tipo.Nombre ?? string.Empty,
            EsPrimerTipo = idx == 0,
            Grupos = tipo.Grupos.Select(grupo => new GrupoAjusteRliViewModel
            {
                IdGrupo = grupo.IdGrupo,
                Nombre = grupo.Nombre ?? string.Empty,
                Items = grupo.Items.Select(item => new ItemAjusteRliViewModel
                {
                    TipoAjuste = item.TipoAjuste,
                    IdGrupo = item.IdGrupo,
                    IdItem = item.IdItem,
                    TipoItem = item.TipoItem ?? string.Empty,
                    Concepto = item.Concepto ?? string.Empty,
                    Valor = item.Valor,
                    Orden = item.Orden
                }).ToList()
            }).ToList()
        }).ToList();

        return viewModel;
    }
}