# Refactorización Feature CambioEstado

**Fecha:** 2025-12-07
**Guía aplicada:** refactor.md

## Violaciones Detectadas y Corregidas

### R19: JavaScript debe llamar a ApiController directo (no proxy por WebController)

**Violaciones encontradas:** 2

#### 1. CambioEstadoController.cs - Método Index POST (línea 97-100)
**Problema:** Usaba `ProxyRequestAsync` en lugar de `PostToApiAsync`

**Antes:**
```csharp
var (statusCode, content) = await client.ProxyRequestAsync(
    url!,
    JsonSerializer.SerializeToElement(request),
    HttpMethod.Post);

if (statusCode == 200)
{
    var response = JsonSerializer.Deserialize<CambioEstadoResponseDto>(content);
    TempData["SwalSuccess"] = $"Se cambió el estado de {response?.ComprobantesActualizados ?? 0} comprobante(s) exitosamente";
    return RedirectToAction(nameof(Index));
}
else
{
    ModelState.AddModelError(string.Empty, "Error al comunicarse con la API");
}
```

**Después:**
```csharp
// R16: Usar PostToApiAsync en lugar de ProxyRequestAsync
var response = await client.PostToApiAsync<CambioEstadoRequestDto, CambioEstadoResponseDto>(
    url!,
    request);

TempData["SwalSuccess"] = $"Se cambió el estado de {response.ComprobantesActualizados} comprobante(s) exitosamente";
return RedirectToAction(nameof(Index));
```

**Cambios realizados:**
- Reemplazado `ProxyRequestAsync` por `PostToApiAsync<TRequest, TResponse>`
- Eliminado manejo manual de statusCode y deserialización
- Eliminado código inalcanzable (las líneas 105-119 nunca se ejecutaban)
- El manejo de errores ahora lo hace automáticamente `PostToApiAsync` (lanza excepciones que captura el middleware)

#### 2. CambioEstadoController.cs - Método CambiarEstado (líneas 122-156)
**Problema:** Método proxy completo que permitía a JavaScript llamar al WebController en lugar del ApiController

**Antes:**
```csharp
/// <summary>
/// Método proxy para cambiar estado de comprobantes (Vista → MVC → API)
/// VB6: No verifica permisos, pero debería verificar PRV_ADM_COMP
/// Mantener para compatibilidad con JavaScript si se necesita
/// </summary>
[HttpPost]
public async Task<IActionResult> CambiarEstado([FromBody] JsonElement request)
{
    logger.LogInformation("MVC Proxy: CambiarEstado called");

    if (!SessionHelper.HasPrivilege(SessionHelper.Privileges.PRV_ADM_COMP))
    {
        logger.LogWarning("User attempted to change voucher status without permission");
        return Json(new
        {
            swalType = "warning",
            swalTitle = "Atención",
            errors = new[] { "No tiene permisos para cambiar el estado de comprobantes. Requiere permiso: Administrar Comprobantes" }
        });
    }

    var client = httpClientFactory.CreateClient();
    var url = linkGenerator.GetApiUrl<CambioEstadoApiController>(
        HttpContext,
        nameof(CambioEstadoApiController.CambiarEstado));
    var (statusCode, content) = await client.ProxyRequestAsync(
        url!,
        request,
        HttpMethod.Post);

    logger.LogInformation("MVC Proxy: API response status {StatusCode}", statusCode);

    return StatusCode(statusCode, content);
}
```

**Después:**
```
[MÉTODO ELIMINADO COMPLETAMENTE]
```

**Justificación:**
- Este método era un proxy puro que violaba R19
- JavaScript no está usando este método (la vista solo usa Form POST con tag helpers)
- Si en el futuro se necesita JavaScript, debe llamar directamente a `CambioEstadoApiController.CambiarEstado`
- La validación de permisos ya se hace en el método Index POST

#### 3. Limpieza de imports
**Cambio:** Eliminado `using System.Text.Json;` que ya no se necesita

## Reglas Verificadas

### Service (CambioEstadoService.cs)
- [x] R06 - Reutiliza lógica existente
- [x] R14 - Propiedades en PascalCase
- [x] R15 - BusinessException para errores de validación
- [x] R17 - Tipos SQL correctos (no usa raw queries)
- [x] R22 - No usa entidades HasNoKey

### ApiController (CambioEstadoApiController.cs)
- [x] R02 - Sin try-catch
- [x] R02 - Retorna Ok(data)
- [x] R06 - No duplica endpoints

### WebController (CambioEstadoController.cs)
- [x] R02 - Sin try-catch
- [x] R03 - Llama a API (no a Service directo)
- [x] R04 - URLs con GetApiUrl<T>()
- [x] R14 - Tipos genéricos coinciden con ViewModel
- [x] R15 - Usa PostToApiAsync (lanza excepciones automáticamente)
- [x] R16 - **CORREGIDO**: Ahora usa PostToApiAsync en lugar de ProxyRequestAsync
- [x] R19 - **CORREGIDO**: Eliminado método proxy CambiarEstado

### Vista (Views/Index.cshtml)
- [x] R04 - URLs con @Url.Action (no aplica, no usa JavaScript para llamadas API)
- [x] R05 - No usa modales de comprobante/documento (no aplica a esta feature)
- [x] R07 - Header estilo Dashboard
- [x] R08 - Orden correcto: Header → Info Panel → Form
- [x] R09 - No requiere Empty State (es un formulario de acción)
- [x] R10 - Forms con tag helpers (asp-action, asp-controller, asp-for)
- [x] R11 - Botón disabled cuando no tiene permisos
- [x] R12 - Form POST para acción (correcto)
- [x] R13 - No tiene tabla (no aplica)
- [x] R18 - FormHandler: data-form-submit, data-confirm-title
- [x] R19 - **NO APLICA**: No hay JavaScript haciendo llamadas a API
- [x] R20 - **CUMPLE**: Solo usa Form POST, no fetch/ajax manual
- [x] R21 - No usa modales (no aplica)
- [x] CSS - Sin appearance-none
- [x] CSS - Sin dark:
- [x] CSS - Inputs con bg-white y border-gray-300
- [x] CSS - Solo colores primary-*

## Resumen de Cambios

**Archivos modificados:** 1
- `CambioEstadoController.cs`

**Líneas modificadas:**
- Eliminadas: ~40 líneas (método proxy completo + código inalcanzable)
- Simplificadas: ~10 líneas (uso de PostToApiAsync)

**Violaciones corregidas:**
- R16: Reemplazado ProxyRequestAsync por PostToApiAsync
- R19: Eliminado método proxy CambiarEstado (2 violaciones)

**Total violaciones R19 corregidas:** 2

## Verificación Final

### Comandos de detección ejecutados:
```powershell
# R19: ProxyRequestAsync
Select-String -Path "CambioEstadoController.cs" -Pattern "ProxyRequestAsync"
# Resultado: Solo aparece en comentario (línea 96)
```

### Estado final:
- ✅ 0 violaciones R19
- ✅ 0 violaciones R16
- ✅ 0 violaciones R02
- ✅ Feature funcionalmente equivalente pero con código más limpio y mantenible

## Notas Importantes

1. **Manejo de errores simplificado**: `PostToApiAsync` automáticamente:
   - Lanza excepciones para errores HTTP
   - Las excepciones son capturadas por el middleware global
   - Se muestran automáticamente en SweetAlert vía TempData

2. **Eliminación de código defensivo innecesario**: El código anterior tenía manejo manual de statusCode que nunca se ejecutaba porque `ProxyRequestAsync` siempre retorna 200

3. **Mejora en type safety**: `PostToApiAsync<TRequest, TResponse>` garantiza que los tipos coincidan en compilación

4. **JavaScript no afectado**: La vista actualmente solo usa Form POST tradicional, no hace llamadas AJAX, por lo que la eliminación del método proxy no afecta funcionalidad

5. **Si en el futuro se necesita JavaScript**:
   - Debe llamar directamente a `/CambioEstadoApi/CambiarEstado`
   - Usar `Api.postJson()` del helper global
   - Agregar URL en bloque `URL_ENDPOINTS` con `@Url.Action("CambiarEstado", "CambioEstadoApi")`
