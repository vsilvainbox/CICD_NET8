using App.Data;
using App.Exceptions;
using Microsoft.EntityFrameworkCore;

namespace App.Features.CambioEstado;

public class CambioEstadoService(LpContabContext context, ILogger<CambioEstadoService> logger) : ICambioEstadoService
{
    public async Task<CambioEstadoResponseDto> CambiarEstadoAsync(CambioEstadoRequestDto request, CancellationToken cancellationToken = default)
    {
        // VB6: No verifica permisos explícitamente, pero debería
        // .NET 9: Agregar validación de permiso PRV_ADM_COMP
        // NOTA: La validación de permiso se hace en el Controller antes de llamar al Service

        if (request.IdComprobantes == null || request.IdComprobantes.Count == 0)
        {
            throw new BusinessException("No se seleccionaron comprobantes para cambiar el estado");
        }

        // Validate estado value
        if (request.NuevoEstado < 1 || request.NuevoEstado > 3)
        {
            throw new BusinessException("Estado inválido. Debe ser 1 (Aprobado), 2 (Pendiente) o 3 (Anulado)");
        }

        var comprobantes = await context.Comprobante
            .Where(c => c.IdEmpresa == request.EmpresaId
                        && c.Ano == request.Ano
                        && request.IdComprobantes.Contains(c.IdComp))
            .ToListAsync(cancellationToken);

        if (comprobantes.Count == 0)
        {
            throw new BusinessException("No se encontraron los comprobantes especificados");
        }

        foreach (var comp in comprobantes)
        {
            comp.Estado = request.NuevoEstado;
        }

        await context.SaveChangesAsync(cancellationToken);

        var estadoTexto = ObtenerEstadoTexto(request.NuevoEstado);

        logger.LogInformation("Cambiado estado de {Count} comprobantes a {Estado}", comprobantes.Count, estadoTexto);

        return new CambioEstadoResponseDto
        {
            ComprobantesActualizados = comprobantes.Count
        };
    }

    private string ObtenerEstadoTexto(int estado)
    {
        return estado switch
        {
            1 => "Aprobado",
            2 => "Pendiente",
            3 => "Anulado",
            _ => "Desconocido"
        };
    }
}