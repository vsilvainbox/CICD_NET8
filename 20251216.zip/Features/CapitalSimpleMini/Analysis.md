# Legacy Analysis: Capital Simple Mini

## 📄 Información del Formulario VB6

**Archivo VB6:** `old/Contabilidad70/HyperContabilidad/FrmDetCapPropioSimplMini.frm`
**Fecha Análisis:** 2025-10-01
**Analista:** IA
**Complejidad:** Media

### Propósito del Formulario

Este formulario permite gestionar el detalle de ajustes al Capital Propio Simplificado (CPS) de tipo aumentos o disminuciones. Muestra una grilla editable con registros de ajustes manuales, calcula totales acumulados de años anteriores y del año actual, y permite exportar, imprimir y acceder a la base imponible acumulada.

---

## 🎨 CONTROLES UI IDENTIFICADOS

### Grilla Principal (FEd3Grid - Grid)
| Control VB6 | Columnas | Editable | Propósito |
|-------------|----------|----------|-----------|
| Grid | 4 visibles: Año, Fecha, Descripción, Monto | Sí (Fecha, Descrip, Monto para registros manuales) | Muestra ajustes de años anteriores (no editables) y del año actual (editables si son de ingreso manual) |

**Columnas:**
- C_ANO (1): Año del registro
- C_FECHA (2): Fecha del ajuste
- C_DESCRIP (4): Descripción del ajuste
- C_MONTO (5): Monto del ajuste

**Columnas ocultas:**
- C_IDDETCAPPROPIOSIMPL (0): ID del registro
- C_LNGFECHA (3): Fecha en formato long
- C_INGRESOMANUAL (6): Indica si es ingreso manual
- C_LINEAENBLANCO (7): Marca líneas no editables
- C_COLOBLIGATORIA (8): Control interno
- C_FMT (9): Formato de celda
- C_UPDATE (10): Estado de modificación (FGR_I, FGR_U, FGR_D)

### Grilla de Totales (MSFlexGrid - GridTot)
| Control VB6 | Propósito |
|-------------|-----------|
| GridTot | Muestra el total acumulado de todos los ajustes (incluidos años anteriores) |

### Botones de Acción

| Botón VB6 | Caption | ToolTip | Acción | Mapeo .NET |
|-----------|---------|---------|--------|------------|
| Bt_VerComp | (icono) | "Detalle comprobante seleccionado" | Abre detalle de comprobante (no implementado en código visible) | N/A (legacy, no parece funcional) |
| Bt_Del | (icono) | "Eliminar registro seleccionado" | Elimina registro de ingreso manual | DeleteAsync() |
| Bt_Preview | (icono) | "Vista previa de la impresión" | Muestra vista previa para imprimir | PreviewPrintAsync() |
| Bt_Print | (icono) | "Imprimir" | Imprime la grilla | PrintAsync() |
| Bt_CopyExcel | (icono) | "Copiar Excel" | Copia datos al portapapeles para Excel | ExportToExcelAsync() |
| Bt_Sum | (icono) | "Sumar movimientos seleccionados" | Abre calculadora de suma | SumSelectedAsync() |
| Bt_ConvMoneda | (icono) | "Convertir moneda" | Abre conversor de monedas | ConvertCurrencyAsync() |
| Bt_Calc | (icono) | "Calculadora" | Abre calculadora | OpenCalculatorAsync() |
| Bt_Calendar | (icono) | "Calendario" | Abre calendario | OpenCalendarAsync() |
| Bt_OK | "Aceptar" | | Valida, guarda y cierra el formulario | SaveAndCloseAsync() |
| Bt_Cancel | "Cancelar" | | Cierra sin guardar | CancelAsync() |
| Bt_DetCapAcum | "Base Imponible Acumulada..." | | Abre formulario de acumulados anuales (FrmDetCapPropioSimplAcum) | OpenAccumulatedAsync() |

---

## 🔘 EVENTOS IDENTIFICADOS

### Eventos de Formulario

| Evento VB6 | Cuándo Ocurre | Acciones | Mapeo .NET |
|------------|---------------|----------|------------|
| Form_Load | Al abrir form | SetUpGrid(), LoadAll(), configurar visibilidad de Bt_DetCapAcum según TipoInforme | GetConfiguracionAsync(), GetAllAsync() |

### Eventos de Botones

| Botón.Evento | Trigger | Acción VB6 | Mapeo .NET |
|--------------|---------|------------|------------|
| Bt_OK_Click | Click en Aceptar | Valida(), SaveAll(), cierra con lRc = vbOK | SaveAndCloseAsync() |
| Bt_Cancel_Click | Click en Cancelar | Cierra con lRc = vbCancel sin guardar | CancelAsync() |
| Bt_Del_Click | Click en Eliminar | Valida que es ingreso manual, confirma, marca fila como FGR_D, recalcula totales | DeleteAsync() |
| Bt_DetCapAcum_Click | Click en Base Imp. Acum. | Valida(), SaveAll(), abre FrmDetCapPropioSimplAcum, recarga LoadAll() | OpenAccumulatedAsync() |
| Bt_Preview_Click | Click en Vista Previa | SetUpPrtGrid(), llama PrtFlexGrid con FrmPrintPreview | PreviewPrintAsync() |
| Bt_Print_Click | Click en Imprimir | SetUpPrtGrid(), llama PrtFlexGrid con Printer | PrintAsync() |
| Bt_CopyExcel_Click | Click en Copiar Excel | Genera string con datos de Grid y GridTot, lo pone en Clipboard | ExportToExcelAsync() |
| Bt_Sum_Click | Click en Sumar | Abre FrmSumSimple con Grid | SumSelectedAsync() |
| Bt_ConvMoneda_Click | Click en Convertir Moneda | Abre FrmConverMoneda | ConvertCurrencyAsync() |
| Bt_Calc_Click | Click en Calculadora | Llama función Calculadora() | OpenCalculatorAsync() |
| Bt_Calendar_Click | Click en Calendario | Abre FrmCalendar | OpenCalendarAsync() |

### Eventos de Controles

| Control.Evento | Trigger | Acción VB6 | Mapeo .NET |
|----------------|---------|------------|------------|
| Grid.BeforeEdit | Antes de editar celda | Valida que no sea línea de año ni en blanco, valida que fila anterior esté completa, habilita edición según columna | JavaScript: validar antes de habilitar input |
| Grid.AcceptValue | Al aceptar valor editado | Valida fecha (año actual), formatea fecha y monto, marca como ingreso manual, actualiza lngFecha, recalcula totales | UpdateCellAsync() + CalcTotAsync() |
| Grid.EditKeyPress | Tecla presionada en edición | Filtra teclas según columna (fecha: KeyDate, monto: KeyNumPos, descrip: KeyName) | JavaScript: input validation |
| Grid.Scroll | Al hacer scroll | Sincroniza GridTot.LeftCol con Grid.LeftCol | JavaScript: scroll sync |

---

## 🔧 FUNCIONES Y PROCEDIMIENTOS VB6

### Función Pública: FEdit

```vb
Public Function FEdit(ByVal TipoDetCapPropioSimpl As Integer, ByVal TipoInforme As Integer, valor As Double) As Integer
' Propósito: Abre el formulario modal, carga datos, permite edición y retorna el valor total
' Parámetros: TipoDetCapPropioSimpl (CPS_OTROSAJUSTAUMENTOS o CPS_OTROSAJUSTDISMIN), TipoInforme (CPS_TIPOINFO_GENERAL o CPS_TIPOINFO_VARANUAL)
' Retorno: vbOK o vbCancel
' Mapeo .NET: EditAsync(int tipoDetCps, int tipoInforme) → CapitalSimpleMiniDto
```

### Funciones Privadas

```vb
Private Sub LoadAll()
' Propósito: Cargar totales de años anteriores + detalle del año actual
' Acciones:
'   1. Si TipoInforme = GENERAL: Carga acumulados años anteriores desde CapPropioSimplAnual
'   2. Carga fila de "Año [actual]" como total del año
'   3. Carga detalle del año actual desde DetCapPropioSimpl (IngresoManual=1)
'   4. Calcula totales
' Mapeo .NET: GetAllAsync()
```

```vb
Private Sub SaveAll()
' Propósito: Guardar registros de ingreso manual en DetCapPropioSimpl
' Acciones:
'   1. Procesa filas marcadas como FGR_I, FGR_U, FGR_D
'   2. INSERT/UPDATE/DELETE en DetCapPropioSimpl
'   3. UPDATE EmpresasAno (CPS_OtrosAjustesAumentos o CPS_OtrosAjustesDisminuciones) con total acumulado
'   4. INSERT/UPDATE CapPropioSimplAnual con total del año actual
' Mapeo .NET: SaveAsync()
```

```vb
Private Function valida() As Boolean
' Propósito: Validar que registros manuales tengan fecha y monto
' Mapeo .NET: ValidateAsync()
```

```vb
Private Sub SetUpGrid()
' Propósito: Configurar columnas y apariencia de la grilla
' Mapeo .NET: JavaScript + GetFormatoGridAsync()
```

```vb
Private Sub CalcTot()
' Propósito: Recalcular totales del año y total acumulado
' Mapeo .NET: JavaScript (recalcular en cambio) + CalculateTotalsAsync() en servidor
```

```vb
Private Sub SetUpPrtGrid()
' Propósito: Preparar configuración de impresión
' Mapeo .NET: GenerarPdfAsync() con configuración similar
```

---

## 💾 ACCESO A DATOS VB6

### Query 1: Cargar Acumulados Años Anteriores

```vb
Q1 = "SELECT AnoValor, Valor FROM CapPropioSimplAnual"
Q1 = Q1 & " WHERE TipoDetCPS = " & lTipoDetCapPropioSimpl & " AND AnoValor < " & gEmpresa.Ano
Q1 = Q1 & " And Valor <> 0 AND IdEmpresa = " & gEmpresa.id
Q1 = Q1 & " ORDER BY AnoValor "
```

**Mapeo Entity Framework:**
```csharp
await _context.CapPropioSimplAnual
    .Where(c => c.TipoDetCPS == tipoDetCps 
             && c.AnoValor < ano 
             && c.Valor != 0 
             && c.IdEmpresa == empresaId)
    .OrderBy(c => c.AnoValor)
    .Select(c => new AnualDto {
        AnoValor = c.AnoValor,
        Valor = c.Valor
    })
    .ToListAsync();
```

### Query 2: Cargar Detalle Año Actual

```vb
Q1 = " SELECT 1 as IngresoManual, IdDetCapPropioSimpl, Fecha, Descrip, Valor"
Q1 = Q1 & " FROM DetCapPropioSimpl "
Q1 = Q1 & " WHERE IngresoManual = 1 AND TipoDetCPS = " & lTipoDetCapPropioSimpl
Q1 = Q1 & " AND DetCapPropioSimpl.IdEmpresa = " & gEmpresa.id & " AND DetCapPropioSimpl.Ano = " & gEmpresa.Ano
Q1 = Q1 & " ORDER BY Fecha, IdDetCapPropioSimpl"
```

**Mapeo Entity Framework:**
```csharp
await _context.DetCapPropioSimpl
    .Where(d => d.IngresoManual == 1 
             && d.TipoDetCPS == tipoDetCps 
             && d.IdEmpresa == empresaId 
             && d.Ano == ano)
    .OrderBy(d => d.Fecha)
    .ThenBy(d => d.IdDetCapPropioSimpl)
    .Select(d => new DetalleDto {
        IdDetCapPropioSimpl = d.IdDetCapPropioSimpl,
        Fecha = d.Fecha,
        Descrip = d.Descrip,
        Valor = d.Valor
    })
    .ToListAsync();
```

### Query 3: INSERT DetCapPropioSimpl

```vb
Q1 = "INSERT INTO DetCapPropioSimpl "
Q1 = Q1 & " (IdEmpresa, Ano, TipoDetCPS, IngresoManual, IdCuenta, CodCuenta, Fecha, Descrip, IdMovComp, Valor) VALUES "
Q1 = Q1 & " (" & gEmpresa.id & ", " & gEmpresa.Ano & ", " & lTipoDetCapPropioSimpl & ", 1, 0, ' ', " 
Q1 = Q1 & Grid.TextMatrix(i, C_LNGFECHA) & ", '" & ParaSQL(Grid.TextMatrix(i, C_DESCRIP)) & "', 0, " 
Q1 = Q1 & vFmt(Grid.TextMatrix(i, C_MONTO)) & ")"
```

**Mapeo Entity Framework:**
```csharp
var detalle = new App.Data.DetCapPropioSimpl
{
    IdEmpresa = empresaId,
    Ano = ano,
    TipoDetCPS = tipoDetCps,
    IngresoManual = 1,
    IdCuenta = 0,
    CodCuenta = " ",
    Fecha = fechaInt,
    Descrip = descripcion,
    IdMovComp = 0,
    Valor = monto
};
_context.DetCapPropioSimpl.Add(detalle);
await _context.SaveChangesAsync();
```

### Query 4: UPDATE EmpresasAno

```vb
Q1 = "UPDATE EmpresasAno SET "
Select Case lTipoDetCapPropioSimpl
  Case CPS_OTROSAJUSTAUMENTOS
     Q1 = Q1 & " CPS_OtrosAjustesAumentos = "
  Case CPS_OTROSAJUSTDISMIN
     Q1 = Q1 & " CPS_OtrosAjustesDisminuciones = "
End Select
Q1 = Q1 & vFmt(GridTot.TextMatrix(0, C_MONTO))
Q1 = Q1 & " WHERE IdEmpresa = " & gEmpresa.id & " AND Ano = " & gEmpresa.Ano
```

**Mapeo Entity Framework:**
```csharp
var empresaAno = await _context.EmpresasAno
    .FirstOrDefaultAsync(e => e.IdEmpresa == empresaId && e.Ano == ano);

if (empresaAno != null)
{
    if (tipoDetCps == CPS_OTROSAJUSTAUMENTOS)
        empresaAno.CPS_OtrosAjustesAumentos = totalAcumulado;
    else if (tipoDetCps == CPS_OTROSAJUSTDISMIN)
        empresaAno.CPS_OtrosAjustesDisminuciones = totalAcumulado;
    
    await _context.SaveChangesAsync();
}
```

### Query 5: INSERT/UPDATE CapPropioSimplAnual

```vb
' Si existe
Q1 = "UPDATE CapPropioSimplAnual SET Valor = " & lValorAnual & ", IngresoManual = 0 "
Q1 = Q1 & " WHERE TipoDetCPS = " & lTipoDetCapPropioSimpl & " AND AnoValor = " & gEmpresa.Ano
Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.id

' Si no existe
Q1 = "INSERT INTO CapPropioSimplAnual (TipoDetCPS, IngresoManual, AnoValor, Valor, IdEmpresa )"
Q1 = Q1 & " VALUES( " & lTipoDetCapPropioSimpl & ", 0, " & gEmpresa.Ano & ", " & lValorAnual & ", " & gEmpresa.id & ") "
```

**Mapeo Entity Framework:**
```csharp
var anual = await _context.CapPropioSimplAnual
    .FirstOrDefaultAsync(c => c.TipoDetCPS == tipoDetCps 
                           && c.AnoValor == ano 
                           && c.IdEmpresa == empresaId);

if (anual != null)
{
    anual.Valor = valorAnual;
    anual.IngresoManual = 0;
}
else
{
    _context.CapPropioSimplAnual.Add(new App.Data.CapPropioSimplAnual
    {
        TipoDetCPS = tipoDetCps,
        IngresoManual = 0,
        AnoValor = ano,
        Valor = valorAnual,
        IdEmpresa = empresaId
    });
}

await _context.SaveChangesAsync();
```

---

## ✅ VALIDACIONES Y REGLAS DE NEGOCIO

### Validaciones de Campos

| Campo | Regla | Mensaje Error VB6 | Implementar en .NET |
|-------|-------|-------------------|---------------------|
| Fecha | Obligatorio para ingreso manual | "Falta ingresar la fecha." | [Required] + ValidateAsync() |
| Fecha | Debe pertenecer al año actual | "Advertencia: esta fecha no pertenece al año actual. Desea continuar?" | ValidateFechaAsync() (warning) |
| Monto | Obligatorio para ingreso manual | "Falta ingresar la valor." | [Required] + ValidateAsync() |
| Monto | Debe ser numérico | (validación KeyNumPos) | [Range] attribute |

### Reglas de Negocio

1. **Solo eliminar registros de ingreso manual**: No se pueden eliminar registros autogenera dos (IngresoManual=0)
   ```vb
   If Val(Grid.TextMatrix(Row, C_INGRESOMANUAL)) = 0 Then
       MsgBox1 "Sólo se pueden eliminar los registros de ingreso manual.", vbExclamation + vbOKOnly
       Exit Sub
   End If
   ```
   **→ Implementar:** `CanDeleteAsync(id)` verifica IngresoManual antes de eliminar

2. **Completar fila anterior antes de continuar**: No permitir editar nueva fila sin completar la anterior
   **→ Implementar:** Validación JavaScript en UI

3. **Fecha debe ser ingresada antes que descripción y monto**: Secuencia de ingreso
   **→ Implementar:** Validación JavaScript en UI

4. **Totales calculados**: Total del año + Total acumulado (con años anteriores)
   **→ Implementar:** `CalculateTotalsAsync()` retorna ambos valores

5. **Actualizar EmpresasAno según tipo**: CPS_OtrosAjustesAumentos o CPS_OtrosAjustesDisminuciones
   **→ Implementar:** Lógica en `SaveAsync()` con switch/case

---

## 🧮 CÁLCULOS Y FÓRMULAS

### Cálculo 1: Total del Año

```vb
For i = Grid.FixedRows To Grid.rows - 1
  If Grid.TextMatrix(i, C_FECHA) <> "" Then
    TotAno = TotAno + vFmt(Grid.TextMatrix(i, C_MONTO))
  End If
Next i
```

**→ Implementar:** `CalculateTotalAnoAsync()` suma montos con fecha del año actual

### Cálculo 2: Total Acumulado

```vb
For i = Grid.FixedRows To Grid.rows - 1
  If i <> lRowTotAno Then
    Total = Total + vFmt(Grid.TextMatrix(i, C_MONTO))
  End If
Next i
```

**→ Implementar:** `CalculateTotalAccumulatedAsync()` suma todos los montos incluyendo años anteriores (excepto fila de total de año)

---

## 🚀 NAVEGACIÓN Y FLUJO

### Formularios Llamados

| Desde VB6 | Formulario Destino | Parámetros | Retorno | Mapeo .NET |
|-----------|-------------------|------------|---------|------------|
| Bt_DetCapAcum_Click | FrmDetCapPropioSimplAcum | tipoDetCps, valorAnual | valor actualizado | Redirect a /CapitalSimpleAcumulado/{tipo}/{valor} |

### Flujo de Estados del Form

```
[Inicio] → FEdit(tipo, tipoInforme) → Form_Load() → LoadAll() → [Estado: Edición]
  ↓
[Usuario edita grilla] → Grid.AcceptValue() → CalcTot() → [Estado: Modificado]
  ↓
[Bt_OK] → valida() → SaveAll() → lRc=vbOK → Unload → [Estado: Guardado]
  ó
[Bt_Cancel] → lRc=vbCancel → Unload → [Estado: Cancelado]
  ó
[Bt_DetCapAcum] → valida() → SaveAll() → Abre FrmDetCapPropioSimplAcum → LoadAll() → [Estado: Edición]
```

---

## 📊 EXPORTACIONES E IMPORTACIONES

### Exportación a Excel

```vb
Clip = LP_FGr2String(Grid, Me.Caption & vbTab & "Año " & gEmpresa.Ano, False, C_FECHA)
Clip = Clip & FGr2String(GridTot)
Clipboard.SetText Clip
```

**→ Implementar:** `ExportToExcelAsync()` genera string delimitado por tabs con encabezados y totales, descarga como archivo .xlsx usando EPPlus

---

## 🎯 MAPEO FINAL: MÉTODOS .NET DETERMINADOS

### Interface del Service

```csharp
public interface ICapitalSimpleMiniService
{
    // Operaciones principales
    Task<CapitalSimpleMiniDto> GetAllAsync(int empresaId, int ano, int tipoDetCps, int tipoInforme);
    Task<CapitalSimpleMiniDto> SaveAsync(int empresaId, int ano, int tipoDetCps, CapitalSimpleMiniSaveDto dto);
    Task<bool> DeleteAsync(int empresaId, int ano, int idDetalle);
    
    // Validaciones
    Task<ValidationResult> ValidateAsync(CapitalSimpleMiniSaveDto dto);
    Task<bool> CanDeleteAsync(int idDetalle);
    
    // Cálculos
    Task<CalculoTotalesDto> CalculateTotalsAsync(int empresaId, int ano, int tipoDetCps, List<DetalleCapitalDto> detalles);
    
    // Utilidades
    Task<string> GetTituloAsync(int tipoDetCps);
    Task<byte[]> ExportToExcelAsync(int empresaId, int ano, int tipoDetCps);
}
```

### Resumen de Mapeo

| Funcionalidad VB6 | Método .NET | Complejidad | Prioridad |
|-------------------|-------------|-------------|-----------|
| Form_Load + LoadAll | GetAllAsync() | Alta | Alta |
| SaveAll | SaveAsync() | Alta | Alta |
| Bt_Del_Click | DeleteAsync() | Media | Alta |
| valida | ValidateAsync() | Baja | Alta |
| CalcTot | CalculateTotalsAsync() | Media | Alta |
| Bt_CopyExcel | ExportToExcelAsync() | Media | Media |
| Bt_Preview/Bt_Print | PreviewPrintAsync()/PrintAsync() | Alta | Baja (Legacy) |
| Bt_Sum/Bt_Calc/Bt_Calendar/Bt_ConvMoneda | Helpers (modal/popup) | Baja | Baja (Utilities) |

---

## ⚠️ NOTAS IMPORTANTES Y OBSERVACIONES

### Peculiaridades del Form VB6

- **Modo de uso**: Se abre como modal desde otro formulario (FrmCapPropioSimpl probablemente) pasando parámetros
- **TipoInforme controla visibilidad**: Si es CPS_TIPOINFO_VARANUAL, oculta botón Bt_DetCapAcum
- **Acumulados años anteriores**: Solo se cargan si TipoInforme = CPS_TIPOINFO_GENERAL
- **Grilla multi-sección**: Mezcla datos de años anteriores (solo lectura) con datos del año actual (editables)
- **Fila especial "Año [actual]"**: Muestra total del año, no es editable
- **Fechas en formato int**: DateSerial convertido a CLng, requiere conversión DateTime ↔ int

### Decisiones de Diseño

- **Modo de edición inline**: Mantener edición inline en grilla con JavaScript para UX similar a VB6
- **Totales en tiempo real**: Recalcular totales en cliente (JavaScript) al modificar montos
- **Validación de fecha**: Warning (no bloqueante) si fecha no pertenece al año actual
- **Exportación Excel**: Implementar descarga directa de archivo .xlsx en lugar de portapapeles
- **Impresión**: Generar PDF descargable en lugar de imprimir directo
- **Botones legacy**: Ver Comprobante, Sumar, Calculadora, Calendario, Convertir Moneda → Agregar con TODO [LEGACY]

### Pendientes/Incompletos en VB6

- **Bt_VerComp**: Existe pero no tiene código funcional visible → **MIGRAR con TODO [LEGACY]**: "Funcionalidad no implementada en VB6 original"
- **Comentario código comentado**: Queries comentadas de carga desde MovComprobante → **NO migrar** (código muerto)

---

## ✅ CHECKLIST DE COMPLETITUD DEL ANÁLISIS

- [x] Todos los controles UI documentados
- [x] Todos los botones y eventos mapeados
- [x] **TODOS los botones tienen "Mapeo .NET" definido** (con TODOs para legacy/utilities)
- [x] Todas las funciones VB6 identificadas
- [x] Todos los queries SQL traducidos a EF Core
- [x] Todas las validaciones documentadas
- [x] Todas las reglas de negocio identificadas
- [x] Todos los cálculos documentados
- [x] Navegación y flujos mapeados
- [x] Métodos .NET determinados
- [x] Interface del Service definida

---

**✅ ANÁLISIS COMPLETO - LISTO PARA IMPLEMENTACIÓN**

