namespace App.Features.AuditoriaCuentasDefinidas;

/// <summary>
/// ViewModel para la vista Index de auditoría de cuentas definidas
/// </summary>
public class AuditoriaCuentasDefinidasIndexViewModel
{
    /// <summary>
    /// Año actual del sistema
    /// </summary>
    public int CurrentYear { get; set; }
}
