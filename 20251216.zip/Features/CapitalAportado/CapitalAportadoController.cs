using Microsoft.AspNetCore.Mvc;
using App.Helpers;

namespace App.Features.CapitalAportado;

public class CapitalAportadoController(
    ILogger<CapitalAportadoController> logger) : Controller
{
    public IActionResult Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Capital Aportado";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        logger.LogInformation("CapitalAportado index accessed");

        var viewModel = new CapitalAportadoIndexViewModel
        {
            EmpresaId = SessionHelper.EmpresaId,
            Ano = SessionHelper.Ano
        };

        return View(viewModel);
    }
}