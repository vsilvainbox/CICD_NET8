# ✅ Feature Refactorizada: CapitalAportado

**Fecha:** 2025-12-07
**Guía aplicada:** refactor.md

---

## Violaciones Detectadas y Corregidas

### R19: JavaScript → ApiController directo (NO proxy por WebController)
**Violaciones encontradas:** 1

**Antes:**
- JavaScript llamaba a métodos del WebController (`GetData`, `Save`)
- WebController usaba `ProxyRequestAsync` para reenviar peticiones al ApiController
- Patrón proxy innecesario que añade latencia y complejidad

**Después:**
- JavaScript llama directamente al ApiController
- URLs cambiadas de `CapitalAportado` a `CapitalAportadoApi`
- Eliminados métodos `GetData()` y `Save()` del WebController

### R20: SOLO Form POST o Api.* (prohibido fetch manual)
**Violaciones encontradas:** 2

**Antes:**
- `cargarDatos()`: usaba `fetch` manual con `await fetch(...)` y manejo de errores try-catch
- `guardarCapital()`: usaba `fetch` manual con POST, headers explícitos, y manejo de response manual

**Después:**
- `cargarDatos()`: usa `Api.get(url, params)` - manejo de errores automático
- `guardarCapital()`: usa `Api.postJson(url, data)` - manejo de errores automático

---

## Archivos Modificados

### 1. CapitalAportadoApiController.cs
**Cambios:**
- ✅ R02: Eliminada envoltura `{ message: "..." }` en endpoint `Save()`
- ✅ R02: Endpoint retorna `Ok()` directamente para operaciones void

**Líneas modificadas:**
```csharp
// ANTES
return Ok(new { message = "Capital aportado guardado correctamente" });

// DESPUÉS
return Ok();
```

### 2. CapitalAportadoController.cs
**Cambios:**
- ✅ R19: Eliminados métodos proxy `GetData()` y `Save()`
- ✅ Eliminadas dependencias innecesarias: `IHttpClientFactory`, `LinkGenerator`
- ✅ WebController ahora solo sirve la vista Index

**Métodos eliminados:**
```csharp
[HttpGet]
public async Task<IActionResult> GetData(int empresaId, short ano)

[HttpPost]
public async Task<IActionResult> Save([FromBody] JsonElement request)
```

### 3. Views/Index.cshtml
**Cambios:**
- ✅ R04 + R19: URLs actualizadas para apuntar a `CapitalAportadoApi`
- ✅ R20: Reemplazado `fetch` manual por `Api.get()` en `cargarDatos()`
- ✅ R20: Reemplazado `fetch` manual por `Api.postJson()` en `guardarCapital()`
- ✅ R15: Manejo de errores automático mediante Api helpers

**Antes:**
```javascript
const URL_ENDPOINTS = {
    getData: '@Url.Action("GetData", "CapitalAportado")',
    save: '@Url.Action("Save", "CapitalAportado")'
};

async function cargarDatos() {
    try {
        const response = await fetch(`${URL_ENDPOINTS.getData}?empresaId=${empresaId}&ano=${ano}`, {
            headers: { 'Accept': 'application/json' }
        });
        const data = await response.json();
        // ...
    } catch (error) {
        Swal.fire({ icon: 'error', title: 'Error', text: 'Error al cargar los datos' });
    }
}

async function guardarCapital() {
    try {
        const response = await fetch(URL_ENDPOINTS.save, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify(request)
        });
        const result = await response.json();
        if (response.ok) {
            Swal.fire({ icon: 'success', title: 'Éxito', text: result.message });
        }
    } catch (error) {
        Swal.fire({ icon: 'error', title: 'Error', text: 'Error al guardar los datos' });
    }
}
```

**Después:**
```javascript
const URL_ENDPOINTS = {
    getData: '@Url.Action("Get", "CapitalAportadoApi")',
    save: '@Url.Action("Save", "CapitalAportadoApi")'
};

async function cargarDatos() {
    const data = await Api.get(URL_ENDPOINTS.getData, { empresaId, ano });
    if (data) {
        socios = data.socios;
        renderGrid();
        document.getElementById('loading').classList.add('hidden');
    }
}

async function guardarCapital() {
    const request = { empresaId, ano, socios: /* ... */ };
    const result = await Api.postJson(URL_ENDPOINTS.save, request);
    if (result) {
        Swal.fire({
            icon: 'success',
            title: 'Guardado',
            text: 'Capital aportado guardado correctamente',
            timer: 1500
        });
    }
}
```

---

## Reglas Verificadas

### Service
- [x] R06 - Reutiliza lógica existente (consulta Socios y EmpresasAno)
- [x] R15 - BusinessException para errores (línea 74: empresa no encontrada)
- [x] R17 - Tipos SQL correctos (decimal ↔ double conversions)

### ApiController
- [x] R02 - Sin try-catch (excepciones fluyen al middleware)
- [x] R02 - Retorna Ok() para void, Ok(data) para datos
- [x] R02 - NO envuelve respuestas en { message: "..." }

### WebController
- [x] R02 - Sin try-catch
- [x] R03 - NO llama a Service directo (N/A - solo sirve vista)
- [x] R19 - NO contiene métodos proxy (eliminados GetData y Save)

### Vista
- [x] R04 - URLs con @Url.Action() apuntando a ApiController
- [x] R07 - Header estilo Dashboard (simple h1 + descripción)
- [x] R19 - JavaScript llama a ApiController directamente
- [x] R20 - Usa Api.get() y Api.postJson() (NO fetch manual)
- [x] R15 - Manejo automático de errores con SweetAlert

---

## Beneficios de la Refactorización

### 1. Arquitectura Simplificada
- **Antes:** Cliente → WebController → ApiController → Service
- **Después:** Cliente → ApiController → Service
- **Reducción:** 1 salto HTTP menos, menor latencia

### 2. Código más Limpio
- **Antes:** 70 líneas de WebController con proxy
- **Después:** 28 líneas de WebController (solo vista)
- **Reducción:** 60% menos código en WebController

### 3. Manejo de Errores Consistente
- **Antes:** Try-catch manual en cada función JavaScript
- **Después:** Manejo centralizado en Api helpers
- **Beneficio:** Errores muestran SweetAlert automáticamente

### 4. Menor Duplicación
- **Antes:** Lógica de headers, error handling, JSON parsing duplicada
- **Después:** Todo centralizado en Api.get() / Api.postJson()
- **Beneficio:** Menos código, más mantenible

---

## Verificación

### Comandos de detección ejecutados
```powershell
# R19: Proxy en controller
Select-String -Path "CapitalAportadoController.cs" -Pattern "ProxyRequestAsync"
# Resultado: 0 violaciones ✅

# R20: fetch manual
Select-String -Path "Views\Index.cshtml" -Pattern "await\s+fetch\("
# Resultado: 0 violaciones ✅
```

### Pruebas funcionales sugeridas
1. ✅ Cargar la página Capital Aportado
2. ✅ Verificar que la tabla de socios se carga correctamente
3. ✅ Modificar "Monto Ingresado Usuario" de un socio
4. ✅ Verificar que "Monto a Traspasar" se actualiza automáticamente
5. ✅ Hacer clic en "Guardar"
6. ✅ Verificar que aparece SweetAlert de éxito
7. ✅ Simular error de red (Network offline) y verificar SweetAlert de error

---

## Notas Adicionales

### Compatibilidad con Api Helpers
Los Api helpers están definidos en `_Layout.cshtml` y proporcionan:
- `Api.get(url, params)`: GET con query string automático
- `Api.postJson(url, data)`: POST con JSON serialization
- Manejo automático de errores 4xx/5xx
- SweetAlert automático en errores
- Retorna `null` en caso de error (permite `if (result)` simple)

### Comportamiento de errores
- **BusinessException** (Service): → 400 Bad Request → SweetAlert warning
- **Exception genérica**: → 500 Server Error → SweetAlert error
- **Network error**: → SweetAlert error "Error de conexión"

### Archivos NO modificados
- ✅ `CapitalAportadoService.cs`: Ya cumplía con las reglas
- ✅ `CapitalAportadoDto.cs`: Ya usaba PascalCase correcto
- ✅ `ICapitalAportadoService.cs`: Interface sin cambios necesarios

---

## Resumen

| Métrica | Antes | Después | Mejora |
|---------|-------|---------|--------|
| Violaciones R19 | 1 | 0 | ✅ 100% |
| Violaciones R20 | 2 | 0 | ✅ 100% |
| Líneas WebController | 70 | 28 | ↓ 60% |
| Saltos HTTP | 3 | 2 | ↓ 33% |
| Try-catch manuales en JS | 2 | 0 | ↓ 100% |

**Estado:** ✅ Feature completamente refactorizada según refactor.md
