using System.ComponentModel.DataAnnotations;

namespace App.Features.AsistenteImportacionPrimeraCategoria;

/// <summary>
/// ViewModel principal para la vista de Asistente de Primera Categoría
/// Sigue el patrón ASP.NET Core MVC: todo el estado en el servidor
/// </summary>
public class AsistenteImportacionPrimeraCategoriaViewModel
{
    // Contexto de la empresa y año
    public int EmpresaId { get; set; }
    public short Ano { get; set; }

    // Lista de items
    public List<AsistenteItemViewModel> Items { get; set; } = new();

    // Estado de selección (en lugar de variables globales JS)
    public int? SelectedRowIndex { get; set; }
    public int? SelectedColIndex { get; set; }

    // Propiedades calculadas server-side
    public decimal TotalRemEjAntNominal => Items
        .Where(i => i.IdItem.HasValue)
        .Sum(i => (decimal)(i.RemEjAntNominal ?? 0));

    public decimal TotalRemEjAntAct => Items
        .Where(i => i.IdItem.HasValue)
        .Sum(i => (decimal)(i.RemEjAntAct ?? 0));

    public decimal TotalGeneradoAno => Items
        .Where(i => i.IdItem.HasValue)
        .Sum(i => (decimal)(i.GeneradoAno ?? 0));

    public decimal TotalCredUtilizado => Items
        .Where(i => i.IdItem.HasValue)
        .Sum(i => (decimal)(i.CredUtilizado ?? 0));

    public decimal TotalRemEjSgte => Items
        .Where(i => i.IdItem.HasValue)
        .Sum(i => (decimal)(i.RemEjSgte ?? 0));
}

/// <summary>
/// ViewModel para cada item de la tabla
/// Incluye propiedades formateadas para la vista
/// </summary>
public class AsistenteItemViewModel
{
    public int? IdAsistImpPrimCat { get; set; }
    public int? IdEmpresa { get; set; }
    public short? Ano { get; set; }
    public byte? IdItem { get; set; }

    [Display(Name = "Concepto")]
    public string Concepto { get; set; } = string.Empty;

    [Display(Name = "Rem. Ej. Ant. Nominal")]
    public double? RemEjAntNominal { get; set; }

    [Display(Name = "Rem. Ej. Ant. Actualizado")]
    public double? RemEjAntAct { get; set; }

    [Display(Name = "Generado en el Año")]
    public double? GeneradoAno { get; set; }

    [Display(Name = "Crédito Utilizado")]
    public double? CredUtilizado { get; set; }

    [Display(Name = "Rem. Ej. Siguiente")]
    public double? RemEjSgte { get; set; }

    // Propiedades auxiliares para UI
    public bool IsBold { get; set; }
    public bool IsLine { get; set; }
    public bool IsEditable { get; set; }
    public bool HasGrayBackground { get; set; }
    public int RowIndex { get; set; }

    // Propiedades formateadas (en lugar de formateo JS)
    public string RemEjAntNominalFormateado => FormatCurrency(RemEjAntNominal);
    public string RemEjAntActFormateado => FormatCurrency(RemEjAntAct);
    public string GeneradoAnoFormateado => FormatCurrency(GeneradoAno);
    public string CredUtilizadoFormateado => FormatCurrency(CredUtilizado);
    public string RemEjSgteFormateado => FormatCurrency(RemEjSgte);

    // Helper para formateo consistente
    private static string FormatCurrency(double? value)
    {
        if (!value.HasValue || value.Value == 0)
            return string.Empty;

        return ((decimal)value.Value).ToString("N0", System.Globalization.CultureInfo.GetCultureInfo("es-CL"));
    }

    // Determina si la celda debe ser editable
    public bool IsCellEditable(int columnIndex)
    {
        if (!IsEditable || !IdItem.HasValue)
            return false;

        // Solo columnas 1 (RemEjAntNominal) y 3 (GeneradoAno) son editables
        return columnIndex == 1 || columnIndex == 3;
    }

    // Determina si hay detalle disponible para la celda
    public string? GetDetailUrl(int columnIndex, int empresaId, short ano)
    {
        // Lógica según VB6: abrir detalle según IdItem y columna
        if ((IdItem == 1 || IdItem == 7) && columnIndex == 4)
        {
            return $"/BaseImponible/Index?empresaId={empresaId}&ano={ano}";
        }
        else if (IdItem == 3 && columnIndex == 3)
        {
            return $"/AjustesExtraContablesCaja/Index?empresaId={empresaId}&ano={ano}";
        }

        return null;
    }
}

/// <summary>
/// Request para actualizar un item
/// Usa Model Binding en lugar de JSON.stringify
/// </summary>
public class UpdateAsistenteItemRequest
{
    [Required(ErrorMessage = "La empresa es requerida")]
    public int EmpresaId { get; set; }

    [Required(ErrorMessage = "El año es requerido")]
    public short Ano { get; set; }

    [Required(ErrorMessage = "El índice de fila es requerido")]
    public int RowIndex { get; set; }

    public double? RemEjAntNominal { get; set; }
    public double? GeneradoAno { get; set; }
}

/// <summary>
/// Request para guardar todos los cambios
/// Usa Model Binding con colecciones
/// </summary>
public class SaveAllRequest
{
    [Required(ErrorMessage = "La empresa es requerida")]
    public int EmpresaId { get; set; }

    [Required(ErrorMessage = "El año es requerido")]
    public short Ano { get; set; }

    public List<AsistenteItemUpdate> Items { get; set; } = new();
}

public class AsistenteItemUpdate
{
    public byte? IdItem { get; set; }
    public double? RemEjAntNominal { get; set; }
    public double? GeneradoAno { get; set; }
}
