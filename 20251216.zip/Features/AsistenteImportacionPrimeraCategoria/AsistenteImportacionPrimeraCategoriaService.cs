using App.Data;
using App.Exceptions;
using App.Services;
using Microsoft.EntityFrameworkCore;

namespace App.Features.AsistenteImportacionPrimeraCategoria;

public class AsistenteImportacionPrimeraCategoriaService(
    LpContabContext context,
    ILogger<AsistenteImportacionPrimeraCategoriaService> logger,
    IIndicadoresEconomicosService indicadoresService) : IAsistenteImportacionPrimeraCategoriaService
{
    // Constantes de configuración (en VB6 son variables globales)
    private const double IMP_PRIM_CATEGORIA = 0.27; // 27% - actualizar según año fiscal
    private const byte BASEIMP_TOTALES = 1; // Constante para tipo base imponible
    private const int MAX_ITEMS = 8; // Cantidad de ítems del asistente

    // Conceptos de cada ítem (equivalente a gStrAsistImpPrimCat en VB6)
    private readonly Dictionary<int, string> _conceptos = new()
    {
        { 1, "IDPC sobre Base Imponible" },
        { 2, "Créditos contra Impuesto de Primera Categoría" },
        { 3, "Crédito 33 bis" },
        { 4, "Crédito asociado a ingreso diferido" },
        { 5, "Crédito asociado a retiros, dividendos y participaciones percibidas" },
        { 6, "IDPC neto a pagar" },
        { 7, "Mayor valor en enajenación de acciones" },
        { 8, "IDPC a pagar" }
    };

    public async Task<IEnumerable<AsistenteImportacionPrimeraCategoriaDto>> GetAllItemsAsync(int empresaId, short ano)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");
        if (ano <= 0)
            throw new BusinessException("Debe seleccionar un año válido");

        logger.LogInformation("Getting all items for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);
            var items = new List<AsistenteImportacionPrimeraCategoriaDto>();
                
            // Obtener valores base para cálculos
            var idpcBaseImp = await GetBaseImponibleIDPCAsync(empresaId, ano);
            var mayorValorEnajenacion = await GetMayorValorEnajenacionAsync(empresaId, ano);
            var credito33bis = await GetCredito33bisAsync(empresaId, ano);
            var factorActualizacion = await GetFactorActualizacionAsync(ano - 1);

            var rowIndex = 0;

            for (byte i = 1; i <= MAX_ITEMS; i++)
            {
                if (!_conceptos.ContainsKey(i))
                    continue;

                var item = new AsistenteImportacionPrimeraCategoriaDto
                {
                    IdItem = i,
                    Concepto = _conceptos[i],
                    IdEmpresa = empresaId,
                    Ano = ano,
                    RowIndex = rowIndex
                };

                // Obtener datos guardados de BD si existen
                var saved = await context.AsistImpPrimCat
                    .Where(a => a.IdItem == i && a.IdEmpresa == empresaId && a.Ano == ano)
                    .FirstOrDefaultAsync();

                if (saved != null)
                {
                    item.IdAsistImpPrimCat = saved.IdAsistImpPrimCat;
                    item.RemEjAntNominal = saved.RemEjAntNominal;
                    item.RemEjAntAct = saved.RemEjAntAct;
                    item.GeneradoAno = saved.GeneradoAno;
                    item.CredUtilizado = saved.CredUtilizado;
                    item.RemEjSgte = saved.RemEjSgte;
                }

                // Aplicar lógica específica según IdItem
                switch (i)
                {
                    case 1: // IDPC Sobre Base Imponible
                        item.CredUtilizado = idpcBaseImp;
                        item.IsBold = true;
                        item.HasGrayBackground = true;
                        rowIndex++;
                            
                        // Agregar línea en blanco
                        items.Add(item);
                        items.Add(new AsistenteImportacionPrimeraCategoriaDto 
                        { 
                            RowIndex = rowIndex++, 
                            IsLine = true 
                        });
                        continue;

                    case 2: // Encabezados de columnas
                        item.RemEjAntNominal = 0; // Placeholder para títulos
                        item.IsBold = true;
                        break;

                    case 3: // Crédito 33 bis
                        item.GeneradoAno = credito33bis;
                        item.CredUtilizado = Math.Min(idpcBaseImp, credito33bis);
                        item.HasGrayBackground = true;
                        break;

                    case 4: // Crédito ingreso diferido
                        item.IsEditable = true;
                        break;

                    case 5: // Crédito retiros
                        item.IsEditable = true;
                        rowIndex++;
                        items.Add(item);
                        continue;

                    case 6: // IDPC neto a pagar
                        item.IsBold = true;
                        item.HasGrayBackground = true;
                        rowIndex++;
                        items.Add(item);
                        items.Add(new AsistenteImportacionPrimeraCategoriaDto 
                        { 
                            RowIndex = rowIndex++, 
                            IsLine = true 
                        });
                        continue;

                    case 7: // Mayor valor enajenación
                        item.CredUtilizado = mayorValorEnajenacion * IMP_PRIM_CATEGORIA;
                        item.IsBold = true;
                        rowIndex++;
                        items.Add(item);
                        items.Add(new AsistenteImportacionPrimeraCategoriaDto 
                        { 
                            RowIndex = rowIndex++, 
                            IsLine = true 
                        });
                        continue;

                    case 8: // IDPC a pagar
                        item.IsBold = true;
                        item.HasGrayBackground = true;
                        break;
                }

                items.Add(item);
                rowIndex++;
            }

            // Calcular totales
            var result = await CalculateTotalsAsync(empresaId, ano, items);
            items = result.Items;

            logger.LogInformation("Found {Count} items", items.Count);
            return items;
    }

    public async Task<AsistenteImportacionPrimeraCategoriaDto?> GetByIdAsync(int id)
    {
        logger.LogInformation("Getting item by id: {Id}", id);

        {
            var entity = await context.AsistImpPrimCat.FindAsync(id);
            if (entity == null)
                throw new BusinessException($"No se encontró el item con id {id}");

            return new AsistenteImportacionPrimeraCategoriaDto
            {
                IdAsistImpPrimCat = entity.IdAsistImpPrimCat,
                IdEmpresa = entity.IdEmpresa,
                Ano = entity.Ano,
                IdItem = entity.IdItem,
                Concepto = entity.IdItem.HasValue && _conceptos.ContainsKey(entity.IdItem.Value)
                    ? _conceptos[entity.IdItem.Value]
                    : string.Empty,
                RemEjAntNominal = entity.RemEjAntNominal,
                RemEjAntAct = entity.RemEjAntAct,
                GeneradoAno = entity.GeneradoAno,
                CredUtilizado = entity.CredUtilizado,
                RemEjSgte = entity.RemEjSgte
            };
        }
    }

    public async Task SaveAllAsync(int empresaId, short ano, List<AsistenteImportacionPrimeraCategoriaDto> items)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");
        if (ano <= 0)
            throw new BusinessException("Debe seleccionar un año válido");
        if (items == null || !items.Any())
            throw new BusinessException("No hay ítems para guardar");

        logger.LogInformation("Saving all items for empresaId: {EmpresaId}, ano: {Ano}, count: {Count}",
            empresaId, ano, items.Count);
            // Validar
            var validationResult = await ValidateAsync(items);
            if (!validationResult.IsValid)
                throw new BusinessException(validationResult.ErrorMessage);

            // Recalcular antes de guardar
            var calcResult = await CalculateTotalsAsync(empresaId, ano, items);
            items = calcResult.Items;

            foreach (var item in items.Where(i => i.IdItem.HasValue && i.IdItem.Value > 0))
            {
                if (item.IdAsistImpPrimCat > 0)
                {
                    // UPDATE
                    var entity = await context.AsistImpPrimCat
                        .FirstOrDefaultAsync(a => a.IdAsistImpPrimCat == item.IdAsistImpPrimCat
                                                  && a.IdEmpresa == empresaId
                                                  && a.Ano == ano);

                    if (entity != null)
                    {
                        entity.RemEjAntNominal = item.RemEjAntNominal;
                        entity.RemEjAntAct = item.RemEjAntAct;
                        entity.GeneradoAno = item.GeneradoAno;
                        entity.CredUtilizado = item.CredUtilizado;
                        entity.RemEjSgte = item.RemEjSgte;

                        logger.LogInformation("Updated item {Id}", entity.IdAsistImpPrimCat);
                    }
                }
                else
                {
                    // INSERT
                    var entity = new App.Data.AsistImpPrimCat
                    {
                        IdEmpresa = empresaId,
                        Ano = item.Ano,
                        IdItem = item.IdItem,
                        RemEjAntNominal = item.RemEjAntNominal,
                        RemEjAntAct = item.RemEjAntAct,
                        GeneradoAno = item.GeneradoAno,
                        CredUtilizado = item.CredUtilizado,
                        RemEjSgte = item.RemEjSgte
                    };

                    context.AsistImpPrimCat.Add(entity);
                    logger.LogInformation("Created new item with IdItem: {IdItem}", item.IdItem);
                }
            }

            await context.SaveChangesAsync();
            logger.LogInformation("Successfully saved all items");
    }

    public async Task<CalculationResult> CalculateTotalsAsync(int empresaId, short ano, List<AsistenteImportacionPrimeraCategoriaDto> items)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");
        if (ano <= 0)
            throw new BusinessException("Debe seleccionar un año válido");

        logger.LogInformation("Calculating totals for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);
            var result = new CalculationResult { Items = items, IsValid = true };

            // Obtener valores base
            var idpcBaseImp = await GetBaseImponibleIDPCAsync(empresaId, ano);
            var credito33bis = await GetCredito33bisAsync(empresaId, ano);
            var factorActualizacion = await GetFactorActualizacionAsync(ano - 1);

            result.IDPCBaseImponible = idpcBaseImp;
            result.Credito33bisUtilizado = Math.Min(idpcBaseImp, credito33bis);
            result.FactorActualizacion = factorActualizacion;

            // Encontrar índices de filas importantes
            var itemCredIng = items.FirstOrDefault(i => i.IdItem == 4);
            var itemCredRetiros = items.FirstOrDefault(i => i.IdItem == 5);
            var itemIDPCNeto = items.FirstOrDefault(i => i.IdItem == 6);
            var itemMayorValor = items.FirstOrDefault(i => i.IdItem == 7);
            var itemIDPCPagar = items.FirstOrDefault(i => i.IdItem == 8);

            if (itemCredIng != null)
            {
                // Remanente Anterior Actualizado - Crédito Ingreso
                itemCredIng.RemEjAntAct = (itemCredIng.RemEjAntNominal ?? 0) * factorActualizacion;

                // Crédito Utilizado - Crédito Ingreso
                var val1 = idpcBaseImp - result.Credito33bisUtilizado;
                var val2 = (itemCredIng.RemEjAntAct ?? 0) + (itemCredIng.GeneradoAno ?? 0);
                itemCredIng.CredUtilizado = Math.Min(val1, val2);
            }

            if (itemCredRetiros != null)
            {
                // Remanente Anterior Actualizado - Crédito Retiros
                itemCredRetiros.RemEjAntAct = (itemCredRetiros.RemEjAntNominal ?? 0) * factorActualizacion;

                // Crédito Utilizado - Crédito Retiros
                var val1 = idpcBaseImp - result.Credito33bisUtilizado - (itemCredIng?.CredUtilizado ?? 0);
                var val2 = (itemCredRetiros.RemEjAntAct ?? 0) + (itemCredRetiros.GeneradoAno ?? 0);
                itemCredRetiros.CredUtilizado = Math.Min(val1, val2);

                // Remanente Ejercicio Siguiente
                itemCredRetiros.RemEjSgte = val2 - (itemCredRetiros.CredUtilizado ?? 0);
            }

            if (itemIDPCNeto != null)
            {
                // IDPC Neto a Pagar
                itemIDPCNeto.CredUtilizado = idpcBaseImp 
                                             - result.Credito33bisUtilizado 
                                             - (itemCredIng?.CredUtilizado ?? 0) 
                                             - (itemCredRetiros?.CredUtilizado ?? 0);
            }

            if (itemMayorValor != null)
            {
                // Mayor Valor Enajenación
                var mayorValorBase = await GetMayorValorEnajenacionAsync(empresaId, ano);
                itemMayorValor.CredUtilizado = mayorValorBase * IMP_PRIM_CATEGORIA;
                result.MayorValorEnajenacion = mayorValorBase;
            }

            if (itemIDPCPagar != null)
            {
                // IDPC Total a Pagar
                itemIDPCPagar.CredUtilizado = (itemMayorValor?.CredUtilizado ?? 0) * IMP_PRIM_CATEGORIA;
            }

            logger.LogInformation("Totals calculated successfully");
            return result;
    }

    public async Task<double> GetFactorActualizacionAsync(int anoAnterior)
    {
        logger.LogInformation("Getting factor actualizacion for ano: {Ano}", anoAnterior);

        {
            // Migrado desde VB6: GetFactorCM(DateSerial(anoAnterior, 12, 1))
            // Obtiene el Factor de Corrección Monetaria de diciembre del año anterior
            var factorCM = await indicadoresService.GetFactorCMFinAnoAsync(anoAnterior);
            
            if (factorCM == 0)
            {
                logger.LogWarning(
                    "No se encontró Factor CM para diciembre de {Ano}, usando 1.0 (sin actualización)",
                    anoAnterior);
                return 1.0;
            }

            logger.LogInformation(
                "Factor CM obtenido para 12/{Ano}: {Factor}",
                anoAnterior, factorCM);

            return factorCM;
        }
    }

    public async Task<double> GetBaseImponibleIDPCAsync(int empresaId, short ano)
    {
        logger.LogInformation("Getting base imponible IDPC for empresaId: {EmpresaId}, ano: {Ano}", 
            empresaId, ano);

        {
            var baseImponible = await context.BaseImponible14Ter
                .Where(b => b.TipoBaseImp == BASEIMP_TOTALES
                            && b.IdItemBaseImp == 0
                            && b.IdEmpresa == empresaId
                            && b.Ano == ano)
                .Select(b => b.Valor)
                .FirstOrDefaultAsync();

            var idpcBaseImp = (baseImponible ?? 0) * IMP_PRIM_CATEGORIA;
                
            logger.LogInformation("Base imponible IDPC: {Value}", idpcBaseImp);
            return idpcBaseImp;
        }
    }

    public async Task<double> GetMayorValorEnajenacionAsync(int empresaId, short ano)
    {
        logger.LogInformation("Getting mayor valor enajenacion for empresaId: {EmpresaId}, ano: {Ano}", 
            empresaId, ano);

        {
            var mayorValor = await context.BaseImponible14Ter
                .Where(b => b.TipoBaseImp == BASEIMP_TOTALES
                            && b.IdItemBaseImp == 1
                            && b.IdEmpresa == empresaId
                            && b.Ano == ano)
                .Select(b => b.Valor)
                .FirstOrDefaultAsync();

            logger.LogInformation("Mayor valor enajenacion: {Value}", mayorValor ?? 0);
            return mayorValor ?? 0;
        }
    }

    public async Task<double> GetCredito33bisAsync(int empresaId, short ano)
    {
        logger.LogInformation("Getting credito 33bis for empresaId: {EmpresaId}, ano: {Ano}", 
            empresaId, ano);

        {
            // TODO: [INTEGRATION] [HIGH] Implementar GetValAjustesELC(TAEC_AGREGADOS, 6)
            // Requiere integración con feature AjustesExtraContablesCaja
            // En VB6: valor = GetValAjustesELC(TAEC_AGREGADOS, 6)
                
            double credito = 0; // Placeholder
                
            // Aplicar tope de 500 UTM
            var valorUTM = await GetValorUTMAsync(ano);
            var topeUTM = 500 * valorUTM;
                
            if (credito > topeUTM)
                credito = topeUTM;

            logger.LogInformation("Credito 33bis: {Value} (tope UTM: {Tope})", credito, topeUTM);
            return credito;
        }
    }

    public async Task<double> GetValorUTMAsync(short ano)
    {
        logger.LogInformation("Getting valor UTM for ano: {Ano}", ano);

        {
            // Migrado desde VB6: GetValMoneda("UTM", ValUTM, DateSerial(ano, 12, 31), False)
            // Consulta valor UTM al 31 de diciembre del año
            var valorUTM = await indicadoresService.GetValorUTMFinAnoAsync(ano);
            
            if (valorUTM == 0)
            {
                logger.LogWarning(
                    "No se encontró valor UTM para 31/12/{Ano}, usando valor por defecto",
                    ano);
                // Valor por defecto aproximado (debe configurarse en BD)
                return 60000;
            }

            logger.LogInformation(
                "Valor UTM obtenido para 31/12/{Ano}: ${Valor:N0}",
                ano, valorUTM);

            return valorUTM;
        }
    }

    public Task<ValidationResult> ValidateAsync(List<AsistenteImportacionPrimeraCategoriaDto> items)
    {
        logger.LogInformation("Validating {Count} items", items.Count);

        var result = new ValidationResult { IsValid = true };

        {
            // Validaciones básicas
            foreach (var item in items.Where(i => i.IdItem.HasValue))
            {
                // Validar valores numéricos no negativos
                if (item.RemEjAntNominal < 0 || item.GeneradoAno < 0)
                {
                    result.IsValid = false;
                    result.Errors.Add($"Ítem {item.IdItem}: Los valores no pueden ser negativos");
                }
            }

            if (!result.IsValid)
                result.ErrorMessage = string.Join(", ", result.Errors);

            return Task.FromResult(result);
        }
    }

    public async Task<byte[]> ExportToPdfAsync(int empresaId, short ano)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");
        if (ano <= 0)
            throw new BusinessException("Debe seleccionar un año válido");

        logger.LogInformation("Exporting to PDF for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        // TODO: [FEATURE] [MEDIUM] Implementar exportación PDF
        // Usar librería como QuestPDF, iTextSharp o similar
        // Replicar layout de impresión VB6
            
        await Task.CompletedTask;
        throw new BusinessException("La exportación a PDF aún no está implementada");
    }

    public async Task<string> ExportToClipboardAsync(int empresaId, short ano)
    {
        logger.LogInformation("Exporting to clipboard for empresaId: {EmpresaId}, ano: {Ano}", 
            empresaId, ano);

        {
            var items = await GetAllItemsAsync(empresaId, ano);
                
            var lines = new List<string>
            {
                "Asistente de cálculo Impuesto de Primera Categoría",
                $"Empresa ID: {empresaId}, Año: {ano}",
                "",
                "Concepto\tRem. Ej. Ant. Nominal\tRem. Ej. Ant. Actualizado\tGenerado Año\tCrédito Utilizado\tRem. Ej. Siguiente"
            };

            foreach (var item in items.Where(i => i.IdItem.HasValue))
            {
                lines.Add($"{item.Concepto}\t" +
                          $"{item.RemEjAntNominal:N0}\t" +
                          $"{item.RemEjAntAct:N0}\t" +
                          $"{item.GeneradoAno:N0}\t" +
                          $"{item.CredUtilizado:N0}\t" +
                          $"{item.RemEjSgte:N0}");
            }

            return string.Join(Environment.NewLine, lines);
        }
    }
}