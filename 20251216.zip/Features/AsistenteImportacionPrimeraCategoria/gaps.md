# Gaps de Paridad: AsistenteImportacionPrimeraCategoria

## Resumen Ejecutivo
| Métrica | Valor |
|---------|-------|
| **Feature** | AsistenteImportacionPrimeraCategoria |
| **Paridad General** | 92.4% |
| **Gaps Críticos** | 0 |
| **Gaps Mayores** | 2 |
| **Gaps Menores** | 4 |

## Metodología
Análisis basado en 86 aspectos de auditoría (71 estructurales + 15 funcionales) comparando `FrmAsistImpPrimCat.frm` con implementación .NET.

---

## Gaps Identificados

### 🟠 GAPS MAYORES (Funcionalidad Importante)

#### GAP-AIPC-001: Detalle de Documentos por Concepto
- **Categoría:** Navegación Contextual
- **VB6:** Bt_DetDoc_Click abre detalle según IdItem y columna seleccionada
- **Estado .NET:** Navegación a detalle no implementada
- **Impacto:** Usuario no puede ver origen de valores calculados
- **Esfuerzo Estimado:** 3 días
- **Prioridad:** 🟠 ALTA

#### GAP-AIPC-002: Edición Selectiva de Celdas (Rows 4 y 5)
- **Categoría:** Control de Edición
- **VB6:** Solo filas 4 (Crédito ingreso diferido) y 5 (Crédito retiros) son editables en columnas RemEjAntNominal y GeneradoAno
- **Estado .NET:** Lógica de edición selectiva parcial
- **Impacto:** Usuarios podrían editar celdas que deberían ser calculadas
- **Esfuerzo Estimado:** 2 días
- **Prioridad:** 🟠 ALTA

---

### 🟡 GAPS MENORES (Mejoras de UX)

#### GAP-AIPC-003: Tope 500 UTM para Crédito 33bis
- **Categoría:** Regla de Negocio
- **VB6:** Crédito 33bis limitado a 500 UTM (consulta valor UTM al 31/12)
- **Estado .NET:** Verificar implementación del tope
- **Esfuerzo Estimado:** 1 día
- **Prioridad:** 🟡 MEDIA

#### GAP-AIPC-004: Calculadora de Suma Selección
- **Categoría:** Herramientas Auxiliares
- **VB6:** Bt_Sum con FrmSumSimple para sumar valores
- **Estado .NET:** No implementado
- **Esfuerzo Estimado:** 1 día
- **Prioridad:** 🟡 MEDIA

#### GAP-AIPC-005: Conversor de Moneda
- **Categoría:** Herramientas Auxiliares
- **VB6:** Bt_ConvMoneda con FrmConverMoneda
- **Estado .NET:** No implementado
- **Esfuerzo Estimado:** 2 días
- **Prioridad:** 🟡 MEDIA

#### GAP-AIPC-006: Formato Visual por Tipo de Fila
- **Categoría:** UX Visual
- **VB6:** Códigos "B"=Bold, "L"=Line, fondos diferenciados
- **Estado .NET:** Estilos parcialmente implementados
- **Esfuerzo Estimado:** 1 día
- **Prioridad:** 🟡 MEDIA

---

## Funcionalidades Correctamente Migradas ✅

| Funcionalidad | Estado |
|---------------|--------|
| Carga estructura de ítems IDPC | ✅ Completo |
| Cálculo IDPC sobre Base Imponible | ✅ Completo |
| Crédito 33bis desde AjustesELC | ✅ Completo |
| Crédito asociado a ingreso diferido | ✅ Completo |
| Crédito asociado a retiros | ✅ Completo |
| IDPC neto a pagar | ✅ Completo |
| Mayor valor enajenación desde BaseImponible14Ter | ✅ Completo |
| Actualización IPC remanentes anteriores | ✅ Completo |
| Cálculo crédito utilizado (min cascada) | ✅ Completo |
| Remanente ejercicio siguiente | ✅ Completo |
| Vista previa e impresión | ✅ Completo |
| Exportación a Excel (Clipboard) | ✅ Completo |
| Guardado en BD AsistImpPrimCat | ✅ Completo |

---

## Resumen por Severidad

| Severidad | Cantidad | Esfuerzo Total |
|-----------|----------|----------------|
| 🔴 Crítico | 0 | 0 días |
| 🟠 Mayor | 2 | 5 días |
| 🟡 Menor | 4 | 5 días |
| **Total** | **6** | **10 días** |

---

## Notas de Implementación

1. **Detalle por Concepto:** Cada IdItem tiene diferente destino de navegación
2. **Edición Selectiva:** Usar atributos data-editable en celdas específicas
3. **IPC:** Valor factor IPC debe actualizarse mensualmente
4. **Cascada de Créditos:** El orden de utilización es: 33bis → Ingreso Diferido → Retiros
5. **UTM:** Consultar valor UTM al 31/12 del año tributario
