using System.ComponentModel.DataAnnotations;

namespace App.Features.AsistenteImportacionPrimeraCategoria;

public class AsistenteImportacionPrimeraCategoriaDto
{
    public int IdAsistImpPrimCat { get; set; }
    public int? IdEmpresa { get; set; }
    public short? Ano { get; set; }
    public byte? IdItem { get; set; }
        
    [Display(Name = "Concepto")]
    public string Concepto { get; set; } = string.Empty;
        
    [Display(Name = "Rem. Ej. Ant. Nominal")]
    public double? RemEjAntNominal { get; set; }
        
    [Display(Name = "Rem. Ej. Ant. Actualizado")]
    public double? RemEjAntAct { get; set; }
        
    [Display(Name = "Generado en el Año")]
    public double? GeneradoAno { get; set; }
        
    [Display(Name = "Crédito Utilizado")]
    public double? CredUtilizado { get; set; }
        
    [Display(Name = "Rem. Ej. Siguiente")]
    public double? RemEjSgte { get; set; }
        
    // Propiedades auxiliares para UI
    public bool IsBold { get; set; }
    public bool IsLine { get; set; }
    public bool IsEditable { get; set; }
    public bool HasGrayBackground { get; set; }
    public int RowIndex { get; set; }
}

public class AsistenteImportacionPrimeraCategoriaCreateDto
{
    [Required(ErrorMessage = "La empresa es requerida")]
    public int IdEmpresa { get; set; }

    [Required(ErrorMessage = "El año es requerido")]
    public short Ano { get; set; }

    [Required(ErrorMessage = "El item es requerido")]
    public byte IdItem { get; set; }
        
    public double? RemEjAntNominal { get; set; }
    public double? RemEjAntAct { get; set; }
    public double? GeneradoAno { get; set; }
    public double? CredUtilizado { get; set; }
    public double? RemEjSgte { get; set; }
}

public class AsistenteImportacionPrimeraCategoriaUpdateDto
{
    public double? RemEjAntNominal { get; set; }
    public double? RemEjAntAct { get; set; }
    public double? GeneradoAno { get; set; }
    public double? CredUtilizado { get; set; }
    public double? RemEjSgte { get; set; }
}

public class CalculationResult
{
    public List<AsistenteImportacionPrimeraCategoriaDto> Items { get; set; } = new();
    public double IDPCBaseImponible { get; set; }
    public double Credito33bisUtilizado { get; set; }
    public double MayorValorEnajenacion { get; set; }
    public double FactorActualizacion { get; set; }
    public bool IsValid { get; set; }
    public string Message { get; set; } = string.Empty;
}

public class ValidationResult
{
    public bool IsValid { get; set; }
    public string ErrorMessage { get; set; } = string.Empty;
    public List<string> Errors { get; set; } = new();
}