using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.AsistenteImportacionPrimeraCategoria;

public class AsistenteImportacionPrimeraCategoriaController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<AsistenteImportacionPrimeraCategoriaController> logger) : Controller
{
    /// <summary>
    /// Vista principal - Carga datos y renderiza ViewModel
    /// REFACTORIZADO: Sigue patrón ASP.NET Core MVC
    /// </summary>
    public async Task<IActionResult> Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder al Asistente de Importación Primera Categoría";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        logger.LogInformation("Loading AsistenteImportacionPrimeraCategoria Index for empresaId: {EmpresaId}, ano: {Ano}",
            SessionHelper.EmpresaId, SessionHelper.Ano);

        ViewData["Title"] = "Asistente de cálculo Impuesto de Primera Categoría";

        // Cargar datos desde la API
        var viewModel = await LoadViewModelAsync(SessionHelper.EmpresaId, SessionHelper.Ano);

        return View(viewModel);
    }

    /// <summary>
    /// Helper: Cargar datos desde API y convertir a ViewModel
    /// </summary>
    private async Task<AsistenteImportacionPrimeraCategoriaViewModel> LoadViewModelAsync(int empresaId, short ano)
    {
        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AsistenteImportacionPrimeraCategoriaApiController>(
            HttpContext,
            nameof(AsistenteImportacionPrimeraCategoriaApiController.GetDatos),
            new { empresaId, ano });

        var dtos = await client.GetFromApiAsync<List<AsistenteImportacionPrimeraCategoriaDto>>(url!);

        // Convertir DTOs a ViewModels
        var viewModel = new AsistenteImportacionPrimeraCategoriaViewModel
        {
            EmpresaId = empresaId,
            Ano = ano,
            Items = dtos.Select((dto, index) => new AsistenteItemViewModel
            {
                IdAsistImpPrimCat = dto.IdAsistImpPrimCat,
                IdEmpresa = dto.IdEmpresa,
                Ano = dto.Ano,
                IdItem = dto.IdItem,
                Concepto = dto.Concepto,
                RemEjAntNominal = dto.RemEjAntNominal,
                RemEjAntAct = dto.RemEjAntAct,
                GeneradoAno = dto.GeneradoAno,
                CredUtilizado = dto.CredUtilizado,
                RemEjSgte = dto.RemEjSgte,
                IsBold = dto.IsBold,
                IsLine = dto.IsLine,
                IsEditable = dto.IsEditable,
                HasGrayBackground = dto.HasGrayBackground,
                RowIndex = index
            }).ToList()
        };

        return viewModel;
    }

    /// <summary>
    /// REFACTORIZADO: Recalcular y retornar Partial View con tabla actualizada
    /// Reemplaza JSON.stringify + renderTable() en JavaScript
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Recalculate([FromForm] AsistenteImportacionPrimeraCategoriaViewModel model)
    {
        logger.LogInformation("Recalculate called for empresaId: {EmpresaId}, ano: {Ano}", model.EmpresaId, model.Ano);

        try
        {
            // Convertir ViewModel a DTOs para enviar a la API
            var dtos = model.Items.Select(item => new AsistenteImportacionPrimeraCategoriaDto
            {
                IdAsistImpPrimCat = item.IdAsistImpPrimCat ?? 0,
                IdEmpresa = item.IdEmpresa,
                Ano = item.Ano,
                IdItem = item.IdItem,
                Concepto = item.Concepto,
                RemEjAntNominal = item.RemEjAntNominal,
                RemEjAntAct = item.RemEjAntAct,
                GeneradoAno = item.GeneradoAno,
                CredUtilizado = item.CredUtilizado,
                RemEjSgte = item.RemEjSgte,
                IsBold = item.IsBold,
                IsLine = item.IsLine,
                IsEditable = item.IsEditable,
                HasGrayBackground = item.HasGrayBackground,
                RowIndex = item.RowIndex
            }).ToList();

            // Llamar a la API para recalcular
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<AsistenteImportacionPrimeraCategoriaApiController>(
                HttpContext,
                nameof(AsistenteImportacionPrimeraCategoriaApiController.Calculate),
                new { empresaId = model.EmpresaId, ano = model.Ano });

            var calculationResult = await client.PostToApiAsync<List<AsistenteImportacionPrimeraCategoriaDto>, CalculationResult>(url!, dtos);

            // Actualizar ViewModel con resultados
            var updatedViewModel = new AsistenteImportacionPrimeraCategoriaViewModel
            {
                EmpresaId = model.EmpresaId,
                Ano = model.Ano,
                SelectedRowIndex = model.SelectedRowIndex,
                SelectedColIndex = model.SelectedColIndex,
                Items = calculationResult!.Items.Select((dto, index) => new AsistenteItemViewModel
                {
                    IdAsistImpPrimCat = dto.IdAsistImpPrimCat,
                    IdEmpresa = dto.IdEmpresa,
                    Ano = dto.Ano,
                    IdItem = dto.IdItem,
                    Concepto = dto.Concepto,
                    RemEjAntNominal = dto.RemEjAntNominal,
                    RemEjAntAct = dto.RemEjAntAct,
                    GeneradoAno = dto.GeneradoAno,
                    CredUtilizado = dto.CredUtilizado,
                    RemEjSgte = dto.RemEjSgte,
                    IsBold = dto.IsBold,
                    IsLine = dto.IsLine,
                    IsEditable = dto.IsEditable,
                    HasGrayBackground = dto.HasGrayBackground,
                    RowIndex = index
                }).ToList()
            };

            // Retornar Partial View con HTML actualizado
            return PartialView("_AsistentePCTable", updatedViewModel);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error recalculating data");
            return StatusCode(500, new { error = "Error al recalcular" });
        }
    }

    /// <summary>
    /// REFACTORIZADO: Guardar todos los cambios usando Model Binding
    /// Reemplaza JSON.stringify manual
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> SaveAll([FromForm] AsistenteImportacionPrimeraCategoriaViewModel model)
    {
        logger.LogInformation("SaveAll called for empresaId: {EmpresaId}, ano: {Ano}", model.EmpresaId, model.Ano);

        try
        {
            // Convertir ViewModel a DTOs
            var dtos = model.Items.Select(item => new AsistenteImportacionPrimeraCategoriaDto
            {
                IdAsistImpPrimCat = item.IdAsistImpPrimCat ?? 0,
                IdEmpresa = item.IdEmpresa,
                Ano = item.Ano,
                IdItem = item.IdItem,
                Concepto = item.Concepto,
                RemEjAntNominal = item.RemEjAntNominal,
                RemEjAntAct = item.RemEjAntAct,
                GeneradoAno = item.GeneradoAno,
                CredUtilizado = item.CredUtilizado,
                RemEjSgte = item.RemEjSgte
            }).ToList();

            // Llamar a la API para guardar
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<AsistenteImportacionPrimeraCategoriaApiController>(
                HttpContext,
                nameof(AsistenteImportacionPrimeraCategoriaApiController.Save),
                new { empresaId = model.EmpresaId, ano = model.Ano });

            await client.PostToApiAsync<List<AsistenteImportacionPrimeraCategoriaDto>>(url!, dtos);

            return Ok();
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error saving data");
            return StatusCode(500, new { isValid = false, errorMessage = "Error al guardar los datos" });
        }
    }

    /// <summary>
    /// MVC Proxy: Exportar PDF
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ExportPdf(int empresaId, short ano)
    {
        logger.LogInformation("AsistenteImportacionPrimeraCategoria: ExportPdf proxy called for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AsistenteImportacionPrimeraCategoriaApiController>(
            HttpContext,
            nameof(AsistenteImportacionPrimeraCategoriaApiController.ExportPdf),
            new { empresaId, ano });
        var (fileBytes, contentType) = await client.DownloadFileAsync(url, HttpMethod.Get);
        return File(fileBytes, contentType);
    }

    /// <summary>
    /// MVC Proxy: Exportar para portapapeles (Excel)
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ExportClipboard(int empresaId, short ano)
    {
        logger.LogInformation("AsistenteImportacionPrimeraCategoria: ExportClipboard proxy called for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AsistenteImportacionPrimeraCategoriaApiController>(
            HttpContext,
            nameof(AsistenteImportacionPrimeraCategoriaApiController.ExportClipboard),
            new { empresaId, ano });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }
}