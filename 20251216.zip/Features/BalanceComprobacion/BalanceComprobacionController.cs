using Microsoft.AspNetCore.Mvc;
using App.Helpers;

namespace App.Features.BalanceComprobacion;

public class BalanceComprobacionController(
    ILogger<BalanceComprobacionController> logger) : Controller
{
    /// <summary>
    /// Vista principal del Balance de Comprobación
    /// </summary>
    [HttpGet]
    public IActionResult Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder al Balance de Comprobación";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        var empresaId = SessionHelper.EmpresaId;
        var ano = (short)SessionHelper.Ano;

        logger.LogInformation("Cargando Balance de Comprobación para Empresa {EmpresaId}, Año {Ano}",
            empresaId, ano);

        // Crear modelo con valores iniciales
        var model = new BalanceComprobacionRequestDto
        {
            EmpresaId = empresaId,
            Ano = ano,
            FechaDesde = new DateTime(ano, 1, 1),
            FechaHasta = new DateTime(ano, 12, 31),
            Nivel = 2,
            TipoAjuste = 1,
            MostrarCodigoCuenta = true,
            SoloLibroOficial = false
        };

        return View(model);
    }
}
