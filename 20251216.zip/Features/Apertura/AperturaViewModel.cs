using System.ComponentModel.DataAnnotations;
using ValidationResult = System.ComponentModel.DataAnnotations.ValidationResult;

namespace App.Features.Apertura;

/// <summary>
/// ViewModel for Apertura view with server-side rendering support
/// Follows ASP.NET Core MVC pattern - eliminates client-side state and calculations
/// </summary>
public class AperturaViewModel : IValidatableObject
{
    // ===== Session Data =====
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public string NombreEmpresa { get; set; } = string.Empty;

    // ===== Opening Entry Configuration =====

    [Required(ErrorMessage = "El número de comprobante es requerido")]
    [Range(1, int.MaxValue, ErrorMessage = "El número de comprobante debe ser mayor a 0")]
    [Display(Name = "Nº de comprobante de apertura")]
    public int NumCompAper { get; set; } = 1;

    public int? IdCompAper { get; set; }
    public bool OpeningEntryExists { get; set; }
    public string WarningMessage { get; set; } = string.Empty;

    // ===== Result Account (Cuenta de Resultado) =====

    [Required(ErrorMessage = "Debe seleccionar una cuenta de resultado")]
    [Range(1, int.MaxValue, ErrorMessage = "Debe seleccionar una cuenta de patrimonio")]
    [Display(Name = "Cuenta de resultado")]
    public int IdCuentaResul { get; set; }

    // Display-only property (populated from modal selection)
    [Display(Name = "Cuenta de resultado")]
    public string? DescCuentaResul { get; set; }

    // ===== IVA Credit Account (Cuenta de Crédito IVA) =====

    [Required(ErrorMessage = "Debe seleccionar una cuenta de crédito IVA")]
    [Range(1, int.MaxValue, ErrorMessage = "Debe seleccionar una cuenta de crédito IVA")]
    [Display(Name = "Cuenta de Crédito IVA")]
    public int IdCuentaCredIVA { get; set; }

    // Display-only property (populated from modal selection)
    [Display(Name = "Cuenta de Crédito IVA")]
    public string? DescCuentaCredIVA { get; set; }

    // ===== IVA Remainder =====

    [Range(0, double.MaxValue, ErrorMessage = "El remanente IVA debe ser mayor o igual a 0")]
    [Display(Name = "Remanente IVA año anterior (UTM)")]
    public double RemIVAUTM { get; set; }

    public bool RemIVAReadOnly { get; set; }
    public string RemIVASource { get; set; } = string.Empty; // "PreviousYearClose" or "ManualInput"

    // ===== Computed Properties (server-side only) =====

    /// <summary>
    /// Formatted source info for IVA remainder display
    /// </summary>
    public string RemIVASourceInfo => RemIVAReadOnly
        ? "(Valor desde cierre año anterior)"
        : "(Ingreso manual)";

    /// <summary>
    /// Formatted IVA remainder with 2 decimal places
    /// </summary>
    public string RemIVAFormateado => RemIVAUTM.ToString("N2");

    // ===== Account Lists for Search Modal =====

    /// <summary>
    /// List of patrimonio accounts for result account selection
    /// Populated by controller, rendered by partial view
    /// </summary>
    public List<AccountDto> CuentasPatrimonio { get; set; } = new();

    /// <summary>
    /// List of activo accounts for IVA credit account selection
    /// Populated by controller, rendered by partial view
    /// </summary>
    public List<AccountDto> CuentasActivo { get; set; } = new();

    // ===== Additional Metadata =====

    public bool HasPreviousYear { get; set; }

    /// <summary>
    /// Business validation rules (in addition to DataAnnotations)
    /// </summary>
    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        // Ensure result account and IVA account are different
        if (IdCuentaResul > 0 && IdCuentaCredIVA > 0 && IdCuentaResul == IdCuentaCredIVA)
        {
            yield return new ValidationResult(
                "La cuenta de resultado y la cuenta de crédito IVA deben ser diferentes",
                new[] { nameof(IdCuentaCredIVA) });
        }

        // Validate RemIVA is read-only when it should be
        if (RemIVAReadOnly && RemIVASource == "PreviousYearClose")
        {
            // This is informational - the readonly attribute on the input prevents changes
            // but we document the business rule here
        }
    }
}

/// <summary>
/// ViewModel for account search results in partial view
/// Eliminates need for innerHTML + JSON rendering
/// </summary>
public class AccountSearchViewModel
{
    public string SearchMode { get; set; } = string.Empty; // "result" or "iva"
    public string ModalTitle { get; set; } = string.Empty;
    public List<AccountDto> Accounts { get; set; } = new();
    public string SearchTerm { get; set; } = string.Empty;

    /// <summary>
    /// Filtered accounts based on search term
    /// Server-side filtering instead of JavaScript
    /// </summary>
    public List<AccountDto> FilteredAccounts
    {
        get
        {
            if (string.IsNullOrWhiteSpace(SearchTerm))
                return Accounts;

            var term = SearchTerm.ToLower();
            return Accounts
                .Where(a =>
                    a.Codigo.ToLower().Contains(term) ||
                    a.Descripcion.ToLower().Contains(term))
                .ToList();
        }
    }

    /// <summary>
    /// Count of results for display
    /// </summary>
    public int ResultCount => FilteredAccounts.Count;

    /// <summary>
    /// Message when no results found
    /// </summary>
    public string NoResultsMessage =>
        $"No se encontraron cuentas{(string.IsNullOrWhiteSpace(SearchTerm) ? "" : $" para '{SearchTerm}'")}";
}
