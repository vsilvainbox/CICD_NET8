namespace App.Features.AyudaImportacionCartola;

public interface IAyudaImportacionCartolaService
{
    /// <summary>
    /// Obtiene la información de ayuda para importación de cartolas bancarias
    /// </summary>
    /// <returns>Datos estáticos de ayuda con campos y formatos</returns>
    Task<AyudaImportacionCartolaDto> GetAyudaImportacionAsync();

    /// <summary>
    /// Genera el texto formateado para copiar al portapapeles (formato Excel)
    /// </summary>
    /// <returns>Texto tabulado listo para pegar en Excel</returns>
    Task<string> GenerateClipboardTextAsync();

    /// <summary>
    /// Genera la respuesta completa de clipboard con texto, estado y mensaje
    /// </summary>
    /// <returns>Respuesta completa para el endpoint de clipboard</returns>
    Task<ClipboardResponseDto> GenerateClipboardResponseAsync();

    /// <summary>
    /// Obtiene la lista de campos y formatos para la grilla
    /// </summary>
    /// <returns>Lista de campos y sus formatos correspondientes</returns>
    Task<IEnumerable<CampoFormatoDto>> GetCamposFormatoAsync();
}