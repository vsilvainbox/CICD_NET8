using System.ComponentModel.DataAnnotations;

namespace App.Features.AyudaImportacionCartola;

public class CampoFormatoDto
{
    [Required(ErrorMessage = "El campo es requerido")]
    public string Campo { get; set; } = string.Empty;

    [Required(ErrorMessage = "El formato es requerido")]
    public string Formato { get; set; } = string.Empty;
}

public class AyudaImportacionCartolaDto
{
    public string Titulo { get; set; } = "Formato Importación Cartolas Bancarias";
    public string Instrucciones { get; set; } = "Columnas o campos del archivo:";
    public string Nota { get; set; } = "NOTA:";
    public string DetalleNota { get; set; } = "Los archivos de importación deben seguir el formato especificado para garantizar una importación correcta de los datos bancarios.";
    public IEnumerable<CampoFormatoDto> Campos { get; set; } = new List<CampoFormatoDto>();
}

public class ClipboardResponseDto
{
    public bool Success { get; set; } = true;
    public string ClipboardText { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;
}