using System.ComponentModel.DataAnnotations;

namespace App.Features.AreasNegocio;

public class AreasNegocioDto
{
    public int IdAreaNegocio { get; set; }
    public string? Codigo { get; set; }
    public string? Descripcion { get; set; }
    public bool? Vigente { get; set; }
    
    /// <summary>
    /// Propiedad computada para indicar si el área está vigente
    /// En SQL Server: true = activo, false = inactivo, null = no definido
    /// </summary>
    public bool IsVigente 
    {
        get => Vigente == true;
        set { /* Setter dummy para permitir deserialización */ }
    }
}

public class AreasNegocioCreateDto
{
    [Required(ErrorMessage = "El código es obligatorio")]
    [StringLength(15, ErrorMessage = "El código no puede exceder 15 caracteres")]
    [Display(Name = "Código")]
    public string Codigo { get; set; } = string.Empty;

    [Required(ErrorMessage = "La descripción es obligatoria")]
    [StringLength(50, ErrorMessage = "La descripción no puede exceder 50 caracteres")]
    [Display(Name = "Descripción")]
    public string Descripcion { get; set; } = string.Empty;

    [Display(Name = "Área activa")]
    public bool Vigente { get; set; } = true;
}

public class AreasNegocioUpdateDto
{
    [Required(ErrorMessage = "El código es obligatorio")]
    [StringLength(15, ErrorMessage = "El código no puede exceder 15 caracteres")]
    [Display(Name = "Código")]
    public string Codigo { get; set; } = string.Empty;

    [Required(ErrorMessage = "La descripción es obligatoria")]
    [StringLength(50, ErrorMessage = "La descripción no puede exceder 50 caracteres")]
    [Display(Name = "Descripción")]
    public string Descripcion { get; set; } = string.Empty;

    [Display(Name = "Área activa")]
    public bool Vigente { get; set; } = true;
}

/// <summary>
/// DTO para formulario modal de Áreas de Negocio (Tag Helpers)
/// Maneja tanto creación (IdAreaNegocio = 0) como edición (IdAreaNegocio &gt; 0)
/// </summary>
public class AreasNegocioFormDto
{
    public int IdAreaNegocio { get; set; }

    [Required(ErrorMessage = "El código es obligatorio")]
    [StringLength(15, ErrorMessage = "El código no puede exceder 15 caracteres")]
    [Display(Name = "Código")]
    public string Codigo { get; set; } = string.Empty;

    [Required(ErrorMessage = "La descripción es obligatoria")]
    [StringLength(50, ErrorMessage = "La descripción no puede exceder 50 caracteres")]
    [Display(Name = "Descripción")]
    public string Descripcion { get; set; } = string.Empty;

    [Display(Name = "Área activa")]
    public bool Vigente { get; set; } = true;
}