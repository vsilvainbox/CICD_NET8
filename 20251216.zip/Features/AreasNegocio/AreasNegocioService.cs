using App.Data;
using App.Exceptions;
using Microsoft.EntityFrameworkCore;

namespace App.Features.AreasNegocio;

public class AreasNegocioService(LpContabContext context, ILogger<AreasNegocioService> logger) : IAreasNegocioService
{
    public async Task<IEnumerable<AreasNegocioDto>> GetAllAsync(int empresaId)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");

        logger.LogInformation("GetAllAsync: Obteniendo todas las áreas de negocio para empresaId={EmpresaId}", empresaId);

        var areas = await context.AreaNegocio
            .Where(a => a.IdEmpresa == empresaId)
            .OrderBy(a => a.Codigo)
            .Select(a => new AreasNegocioDto
            {
                IdAreaNegocio = a.IdAreaNegocio,
                Codigo = a.Codigo,
                Descripcion = a.Descripcion,
                Vigente = a.Vigente
            })
            .ToListAsync();

        logger.LogInformation("GetAllAsync: Se encontraron {Count} áreas de negocio", areas.Count);
        return areas;
    }

    public async Task<AreasNegocioDto> GetByIdAsync(int id, int empresaId)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");

        logger.LogInformation("GetByIdAsync: Obteniendo área de negocio id={Id}, empresaId={EmpresaId}", id, empresaId);

        var area = await context.AreaNegocio
            .Where(a => a.IdAreaNegocio == id && a.IdEmpresa == empresaId)
            .Select(a => new AreasNegocioDto
            {
                IdAreaNegocio = a.IdAreaNegocio,
                Codigo = a.Codigo,
                Descripcion = a.Descripcion,
                Vigente = a.Vigente
            })
            .FirstOrDefaultAsync();

        if (area == null)
        {
            logger.LogWarning("GetByIdAsync: Área de negocio no encontrada id={Id}, empresaId={EmpresaId}", id, empresaId);
            throw new BusinessException("Área de negocio no encontrada");
        }

        return area;
    }

    public async Task<AreasNegocioDto> CreateAsync(int empresaId, AreasNegocioCreateDto dto)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");

        logger.LogInformation("CreateAsync: Creando nueva área de negocio codigo={Codigo}, empresaId={EmpresaId}",
            dto.Codigo, empresaId);

        // Validar código único
        var codigoUpper = dto.Codigo?.ToUpper() ?? string.Empty;
        if (await CheckUniqueCodeAsync(codigoUpper, empresaId))
        {
            logger.LogWarning("CreateAsync: El código ya existe codigo={Codigo}, empresaId={EmpresaId}",
                codigoUpper, empresaId);
            throw new BusinessException("El código ya existe");
        }

        var area = new App.Data.AreaNegocio
        {
            IdEmpresa = (short)empresaId,
            Codigo = codigoUpper,
            Descripcion = dto.Descripcion,
            Vigente = dto.Vigente
        };

        context.AreaNegocio.Add(area);
        await context.SaveChangesAsync();

        logger.LogInformation("CreateAsync: Área de negocio creada exitosamente id={Id}, codigo={Codigo}",
            area.IdAreaNegocio, area.Codigo);

        return new AreasNegocioDto
        {
            IdAreaNegocio = area.IdAreaNegocio,
            Codigo = area.Codigo,
            Descripcion = area.Descripcion,
            Vigente = area.Vigente
        };
    }

    public async Task<AreasNegocioDto> UpdateAsync(int id, int empresaId, AreasNegocioUpdateDto dto)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");

        logger.LogInformation("UpdateAsync: Actualizando área de negocio id={Id}, codigo={Codigo}, empresaId={EmpresaId}",
            id, dto.Codigo, empresaId);

        var area = await context.AreaNegocio
            .FirstOrDefaultAsync(a => a.IdAreaNegocio == id && a.IdEmpresa == empresaId);

        if (area == null)
        {
            logger.LogWarning("UpdateAsync: Área de negocio no encontrada id={Id}, empresaId={EmpresaId}",
                id, empresaId);
            throw new BusinessException("Área de negocio no encontrada");
        }

        // Validar código único (excluir el actual)
        var codigoUpper = dto.Codigo?.ToUpper() ?? string.Empty;
        if (await CheckUniqueCodeAsync(codigoUpper, empresaId, id))
        {
            logger.LogWarning("UpdateAsync: El código ya existe codigo={Codigo}, empresaId={EmpresaId}",
                codigoUpper, empresaId);
            throw new BusinessException("El código ya existe");
        }

        area.Codigo = codigoUpper;
        area.Descripcion = dto.Descripcion;
        area.Vigente = dto.Vigente;

        await context.SaveChangesAsync();

        logger.LogInformation("UpdateAsync: Área de negocio actualizada exitosamente id={Id}, codigo={Codigo}",
            area.IdAreaNegocio, area.Codigo);

        return new AreasNegocioDto
        {
            IdAreaNegocio = area.IdAreaNegocio,
            Codigo = area.Codigo,
            Descripcion = area.Descripcion,
            Vigente = area.Vigente
        };
    }

    public async Task DeleteAsync(int id, int empresaId)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");

        logger.LogInformation("DeleteAsync: Eliminando área de negocio id={Id}, empresaId={EmpresaId}",
            id, empresaId);

        var area = await context.AreaNegocio
            .FirstOrDefaultAsync(a => a.IdAreaNegocio == id && a.IdEmpresa == empresaId);

        if (area == null)
        {
            logger.LogWarning("DeleteAsync: Área de negocio no encontrada id={Id}, empresaId={EmpresaId}",
                id, empresaId);
            throw new BusinessException("Área de negocio no encontrada");
        }

        // Validar referencias en MovComprobante
        if (await HasReferencesAsync(id, empresaId))
        {
            logger.LogWarning("DeleteAsync: No se puede eliminar área de negocio, tiene movimientos asociados id={Id}, codigo={Codigo}",
                id, area.Codigo);
            throw new BusinessException($"No puede borrar el área de negocios {area.Descripcion}, existe un movimiento asociado.");
        }

        context.AreaNegocio.Remove(area);
        await context.SaveChangesAsync();

        logger.LogInformation("DeleteAsync: Área de negocio eliminada exitosamente id={Id}, codigo={Codigo}",
            id, area.Codigo);
    }

    public async Task<bool> CheckUniqueCodeAsync(string codigo, int empresaId, int? excludeId = null)
    {
        var query = context.AreaNegocio
            .Where(a => a.Codigo == codigo && a.IdEmpresa == empresaId);

        if (excludeId.HasValue)
        {
            query = query.Where(a => a.IdAreaNegocio != excludeId.Value);
        }

        return await query.AnyAsync();
    }

    public async Task<bool> HasReferencesAsync(int id, int empresaId)
    {
        logger.LogDebug("HasReferencesAsync: Verificando referencias para área de negocio id={Id}, empresaId={EmpresaId}",
            id, empresaId);

        var hasReferences = await context.MovComprobante
            .AnyAsync(m => m.idAreaNeg == id && m.IdEmpresa == empresaId);

        logger.LogDebug("HasReferencesAsync: Área de negocio tiene referencias={HasReferences}",
            hasReferences);

        return hasReferences;
    }
}