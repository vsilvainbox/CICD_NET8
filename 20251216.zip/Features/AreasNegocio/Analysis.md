# Legacy Analysis: Áreas de Negocio

## 📄 Información del Formulario VB6

**Archivo VB6:** `old/Contabilidad70/HyperContabilidad/FrmAreaNeg.frm` + `FrmANeg.frm`
**Fecha Análisis:** 2025-09-29
**Analista:** IA
**Complejidad:** Baja

### Propósito del Formulario
Administración de áreas de negocio de la empresa. Permite listar, crear, editar y eliminar áreas de negocio para segmentación empresarial. Incluye funcionalidad de importación y selección de área para uso en otros módulos.

---

## 🎨 CONTROLES UI IDENTIFICADOS

### Grilla Principal (MSFlexGrid)
| Control VB6 | Columnas | Datos | Eventos | Propósito |
|-------------|----------|-------|---------|-----------|
| Grid | 3 cols: Codigo (C_CODIGO=0), Descripcion (C_DESCRIP=1), IdAreaNegocio (C_ID=2) | SELECT Codigo, idAreaNegocio, Descripcion FROM AreaNegocio WHERE IdEmpresa=X ORDER BY Codigo | Click, DblClick | Mostrar listado de áreas de negocio, doble click edita |

### Botones de Acción (Formulario Principal)
| Botón VB6 | Caption | TabIndex | Acción | Mapeo .NET |
|-----------|---------|----------|--------|------------|
| Bt_New | "&Agregar" | 2 | Abre FrmANeg en modo nuevo | CreateAsync() |
| Bt_Edit | "Edi&tar" | 3 | Abre FrmANeg en modo edición | UpdateAsync() |
| Bt_Del | "&Eliminar" | 4 | Elimina área con validación de referencias | DeleteAsync() con validación |
| Bt_Print | "&Imprimir" | 5 | Imprime listado completo | window.print() TODO [LEGACY] |
| Bt_Sel | "&Seleccionar" | 1 | Selecciona área y cierra (modo selección) | TODO [LEGACY] - No aplicable web |
| Bt_Cancel | "Cerrar" | 6 | Cierra formulario | Navegación back/home |
| Bt_Importador | "&Importador" | 9 | Abre FrmImpAreaNegocio | TODO [FUTURE] - Requiere migración FrmImpAreaNegocio |

### Campos de Edición (Formulario Modal FrmANeg)
| Control VB6 | Propiedad Bound | Tipo | Validación | Propósito |
|-------------|----------------|------|------------|-----------|
| Tx_Codigo | AreaNegocio.Codigo | String | Required, MaxLength=15, Unique | Código único de área |
| Tx_Descripcion | AreaNegocio.Descripcion | String | MaxLength=50 | Nombre descriptivo |
| Ch_Vigente | AreaNegocio.Vigente | Boolean | -1=True, 0=False | Estado activo/inactivo |

### Botones Modal (FrmANeg)
| Botón VB6 | Caption | Acción | Mapeo .NET |
|-----------|---------|--------|------------|
| Bt_OK | "Aceptar" | Valida y guarda (INSERT o UPDATE según modo) | CreateAsync()/UpdateAsync() |
| Bt_Cancel | "Cancelar" | Cierra sin guardar | Cancelar modal |

---

## 🔘 EVENTOS IDENTIFICADOS

### Eventos de Formulario Principal
| Evento VB6 | Cuándo Ocurre | Acciones | Mapeo .NET |
|------------|---------------|----------|------------|
| Form_Load | Al abrir formulario | Llama CargaInicial → SetUpGrid, LoadAll, EnableForm, SetupPriv | GetAllAsync() en carga inicial |
| Grid_DblClick | Doble click en grilla | Si fila vacía llama Bt_New_Click, sino Bt_Edit_Click | Editar registro |

### Eventos de Formulario Modal
| Evento VB6 | Cuándo Ocurre | Acciones | Mapeo .NET |
|------------|---------------|----------|------------|
| Form_Load (FrmANeg) | Al abrir modal | Establece Caption según modo (Nueva/Modificar/Ver), LoadAll en modo edit | GetByIdAsync() |
| Tx_Codigo_KeyPress | Usuario escribe | Convierte a mayúsculas (KeyUpper) | toUpperCase() en JavaScript |

---

## 🔧 FUNCIONES Y PROCEDIMIENTOS VB6

### Funciones Públicas (FrmAreaNeg)
```vb
' Función: CargaInicial
' Propósito: Inicializar formulario, configurar grilla, cargar datos
' Parámetros: Ninguno
' Llamado por: Form_Load, Bt_Importador_Click
Public Sub CargaInicial()
   Fr_Edit.visible = (lOper = O_EDIT)
   Fr_Sel.visible = (lOper = O_VIEW)
   Call SetUpGrid
   Call LoadAll
   Call EnableForm(Me, gEmpresa.FCierre = 0)
   Call SetupPriv
End Sub
```
**Mapeo .NET:** Index() carga inicial del controller

```vb
' Función: FSelect
' Propósito: Abrir en modo selección para elegir área
' Parámetros: AreaNeg (ByRef)
' Retorno: Integer (vbOK/vbCancel)
Friend Function FSelect(AreaNeg As AreaNeg_t) As Integer
   lAreaNeg = AreaNeg
   lOper = O_VIEW
   Me.Show vbModal
   AreaNeg = lAreaNeg
   FSelect = lRc
End Function
```
**Mapeo .NET:** TODO [LEGACY] - No aplicable en web (usar dropdowns)

### Funciones Privadas (FrmAreaNeg)
```vb
' Función: LoadAll
' Propósito: Cargar todas las áreas de negocio en la grilla
Private Sub LoadAll()
   Q1 = "SELECT Codigo, idAreaNegocio, Descripcion FROM AreaNegocio WHERE IdEmpresa = " & gEmpresa.id
   Q1 = Q1 & " ORDER BY Codigo"
   Set Rs = OpenRs(DbMain, Q1)
   ' ... llenar grilla
End Sub
```
**Mapeo .NET:** `GetAllAsync(empresaId)`

```vb
' Función: SetUpGrid
' Propósito: Configurar columnas de la grilla
Private Sub SetUpGrid()
   Grid.ColWidth(C_CODIGO) = 1500
   Grid.ColWidth(C_DESCRIP) = 2830
   Grid.ColWidth(C_ID) = 0  ' oculta
   Grid.TextMatrix(0, C_CODIGO) = "Código"
   Grid.TextMatrix(0, C_DESCRIP) = "Descripción"
End Sub
```
**Mapeo .NET:** Estructura de tabla HTML/Tailwind

```vb
' Función: UpDateGrid
' Propósito: Actualizar fila de grilla tras edición
Private Sub UpDateGrid(Row As Integer)
    Grid.TextMatrix(Row, C_CODIGO) = lAreaNeg.Codigo
    Grid.TextMatrix(Row, C_DESCRIP) = lAreaNeg.Descrip
    Grid.TextMatrix(Row, C_ID) = lAreaNeg.id
End Sub
```
**Mapeo .NET:** Refrescar tabla vía JavaScript tras guardar

### Funciones Privadas (FrmANeg - Modal)
```vb
' Función: LoadAll (modal)
' Propósito: Cargar datos de área para edición
Private Sub LoadAll()
   Q1 = "SELECT Codigo, Descripcion, Vigente FROM AreaNegocio"
   Q1 = Q1 & " WHERE idAreaNegocio=" & lAreaNeg.Id
   Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.Id
   Set Rs = OpenRs(DbMain, Q1)
   If Rs.EOF = False Then
      Tx_Codigo = vFld(Rs("Codigo"), True)
      Tx_Descripcion = vFld(Rs("Descripcion"), True)
      Ch_Vigente = IIf(vFld(Rs("Vigente")) <> 0, 1, 0)
   End If
End Sub
```
**Mapeo .NET:** `GetByIdAsync(id)`

```vb
' Función: Valida
' Propósito: Validar campos antes de guardar
' Retorno: Boolean
Private Function Valida() As Boolean
   Valida = False

   If Tx_Codigo = "" Then
      MsgBox1 "Debe ingresar el código", vbExclamation
      Exit Function
   End If

   Q1 = "SELECT idAreaNegocio FROM AreaNegocio WHERE Codigo='" & Tx_Codigo & "'"
   Q1 = Q1 & " AND idAreaNegocio<>" & lAreaNeg.Id
   Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.Id
   Set Rs = OpenRs(DbMain, Q1)
   If Rs.EOF = False Then
      MsgBox1 "Código ya existe", vbExclamation
      Exit Function
   End If

   Valida = True
End Function
```
**Mapeo .NET:** `ValidateAsync()` + `CheckUniqueCodeAsync()`

### Lista Completa de Funciones
| Función VB6 | Tipo | Propósito | Mapeo .NET Method |
|-------------|------|-----------|-------------------|
| CargaInicial() | Public Sub | Inicializar formulario principal | Index() action |
| FSelect() | Friend Function→Integer | Modo selección | TODO [LEGACY] |
| FEdit() | Public Sub | Abrir en modo edición | N/A (navegación) |
| LoadAll() | Private Sub | Cargar grilla | GetAllAsync() |
| SetUpGrid() | Private Sub | Configurar columnas | HTML table |
| UpDateGrid() | Private Sub | Actualizar fila | JavaScript refresh |
| LoadAll() modal | Private Sub | Cargar datos edición | GetByIdAsync() |
| Valida() | Private Function→Boolean | Validar campos | ValidateAsync() |
| SetupPriv() | Private Function | Permisos | N/A (auth middleware) |
| CountANeg() | Private Function→Integer | Contar áreas | Count() LINQ |

---

## 💾 ACCESO A DATOS VB6

### Query 1: Cargar Listado de Áreas
```vb
' Ubicación: LoadAll()
' Tablas: AreaNegocio
' Filtros: IdEmpresa
' Orden: Codigo
Q1 = "SELECT Codigo, idAreaNegocio, Descripcion FROM AreaNegocio WHERE IdEmpresa = " & gEmpresa.Id
Q1 = Q1 & " ORDER BY Codigo"
Set Rs = OpenRs(DbMain, Q1)
```

**Mapeo Entity Framework:**
```csharp
await _context.AreaNegocio
    .Where(a => a.IdEmpresa == empresaId)
    .OrderBy(a => a.Codigo)
    .Select(a => new AreasNegocioDto {
        IdAreaNegocio = a.IdAreaNegocio,
        Codigo = a.Codigo,
        Descripcion = a.Descripcion,
        Vigente = a.Vigente
    })
    .ToListAsync();
```

### Query 2: Obtener Área por ID (Edición)
```vb
' Ubicación: LoadAll() en FrmANeg
Q1 = "SELECT Codigo, Descripcion, Vigente FROM AreaNegocio"
Q1 = Q1 & " WHERE idAreaNegocio=" & lAreaNeg.Id
Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.Id
Set Rs = OpenRs(DbMain, Q1)
```

**Mapeo Entity Framework:**
```csharp
await _context.AreaNegocio
    .Where(a => a.IdAreaNegocio == id && a.IdEmpresa == empresaId)
    .Select(a => new AreasNegocioDto {
        IdAreaNegocio = a.IdAreaNegocio,
        Codigo = a.Codigo,
        Descripcion = a.Descripcion,
        Vigente = a.Vigente
    })
    .FirstOrDefaultAsync();
```

### Query 3: Guardar Nueva Área
```vb
' Ubicación: bt_OK_Click en FrmANeg (modo O_NEW)
lAreaNeg.Id = AdvTbAddNew(DbMain, "AreaNegocio", "idAreaNegocio", "IdEmpresa", gEmpresa.Id)

Q1 = "UPDATE AreaNegocio SET Codigo='" & ParaSQL(Tx_Codigo) & "'"
Q1 = Q1 & ", Descripcion='" & ParaSQL(Tx_Descripcion) & "'"
Q1 = Q1 & ", Vigente = " & IIf(Ch_Vigente <> 0, -1, 0)
Q1 = Q1 & " WHERE idAreaNegocio=" & lAreaNeg.Id
Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.Id
Call ExecSQL(DbMain, Q1)
```

**Mapeo Entity Framework:**
```csharp
var area = new App.Data.AreaNegocio
{
    IdEmpresa = empresaId,
    Codigo = dto.Codigo,
    Descripcion = dto.Descripcion,
    Vigente = dto.Vigente ? -1 : 0
};
_context.AreaNegocio.Add(area);
await _context.SaveChangesAsync();
return area.IdAreaNegocio;
```

### Query 4: Actualizar Área Existente
```vb
' Ubicación: bt_OK_Click en FrmANeg (modo O_EDIT)
Q1 = "UPDATE AreaNegocio SET Codigo='" & ParaSQL(Tx_Codigo) & "'"
Q1 = Q1 & ", Descripcion='" & ParaSQL(Tx_Descripcion) & "'"
Q1 = Q1 & ", Vigente = " & IIf(Ch_Vigente <> 0, -1, 0)
Q1 = Q1 & " WHERE idAreaNegocio=" & lAreaNeg.Id
Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.Id
Call ExecSQL(DbMain, Q1)
```

**Mapeo Entity Framework:**
```csharp
var area = await _context.AreaNegocio
    .FirstOrDefaultAsync(a => a.IdAreaNegocio == id && a.IdEmpresa == empresaId);
if (area != null)
{
    area.Codigo = dto.Codigo;
    area.Descripcion = dto.Descripcion;
    area.Vigente = dto.Vigente ? -1 : 0;
    await _context.SaveChangesAsync();
}
```

### Query 5: Eliminar Área (con validación)
```vb
' Ubicación: Bt_Del_Click
' Primero valida que no existan movimientos asociados
Q1 = "SELECT Count(*) as n FROM MovComprobante WHERE idAreaNeg=" & vFmt(Grid.TextMatrix(Row, C_ID))
Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.id & " AND Ano = " & gEmpresa.Ano
Set Rs = OpenRs(DbMain, Q1)

If vFld(Rs("n")) <> 0 Then
   MsgBox1 "No puede borrar el área de negocios, existe un movimiento asociado.", vbExclamation
   Exit Sub
End If

' Si no hay referencias, eliminar
Q1 = " WHERE idAreaNegocio = " & vFmt(Grid.TextMatrix(Row, C_ID))
Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.id
Call DeleteSQL(DbMain, "AreaNegocio", Q1)
```

**Mapeo Entity Framework:**
```csharp
// Validar referencias
var hasReferences = await _context.MovComprobante
    .AnyAsync(m => m.IdAreaNeg == id && m.IdEmpresa == empresaId);

if (hasReferences)
{
    throw new InvalidOperationException("No puede borrar el área de negocios, existe un movimiento asociado.");
}

// Eliminar si no hay referencias
var area = await _context.AreaNegocio
    .FirstOrDefaultAsync(a => a.IdAreaNegocio == id && a.IdEmpresa == empresaId);
if (area != null)
{
    _context.AreaNegocio.Remove(area);
    await _context.SaveChangesAsync();
}
```

### Query 6: Validar Código Único
```vb
' Ubicación: Valida() en FrmANeg
Q1 = "SELECT idAreaNegocio FROM AreaNegocio WHERE Codigo='" & Tx_Codigo & "'"
Q1 = Q1 & " AND idAreaNegocio<>" & lAreaNeg.Id
Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.Id
Set Rs = OpenRs(DbMain, Q1)
If Rs.EOF = False Then
    MsgBox1 "Código ya existe", vbExclamation
End If
```

**Mapeo Entity Framework:**
```csharp
var exists = await _context.AreaNegocio
    .AnyAsync(a => a.Codigo == codigo
               && a.IdEmpresa == empresaId
               && a.IdAreaNegocio != excludeId);
```

---

## ✅ VALIDACIONES Y REGLAS DE NEGOCIO

### Validaciones de Campos
| Campo | Regla | Mensaje Error VB6 | Implementar en .NET |
|-------|-------|-------------------|---------------------|
| Tx_Codigo | Obligatorio | "Debe ingresar el código" | [Required] + ValidateAsync() |
| Tx_Codigo | MaxLength 15 | N/A (control VB6) | [MaxLength(15)] |
| Tx_Codigo | Único por empresa | "Código ya existe" | CheckUniqueCodeAsync() |
| Tx_Descripcion | MaxLength 50 | N/A (control VB6) | [MaxLength(50)] |
| Ch_Vigente | Boolean | N/A | true/false en DTO |

### Reglas de Negocio
1. **Código debe ser único por empresa**: No duplicados dentro de la misma empresa
   **→ Implementar:** `CheckUniqueCodeAsync(codigo, empresaId, excludeId)`

2. **Código siempre en mayúsculas**: VB6 usa KeyUpper en KeyPress
   **→ Implementar:** `codigo = codigo?.ToUpper()` en DTO

3. **Eliminación con validación de referencias**: Verificar MovComprobante antes de eliminar
   **→ Implementar:** `CheckReferencesAsync(id, empresaId)` antes de DeleteAsync()

4. **Mensaje específico si hay referencias**: "No puede borrar el área de negocios [nombre], existe un movimiento asociado."
   **→ Implementar:** Exception con mensaje detallado

5. **Vigente default True**: Al crear, Ch_Vigente inicia en 1 (True)
   **→ Implementar:** Default value true en CreateDto

---

## 🚀 NAVEGACIÓN Y FLUJO

### Formularios Llamados
| Desde VB6 | Formulario Destino | Parámetros | Retorno | Mapeo .NET |
|-----------|-------------------|------------|---------|------------|
| Bt_New_Click | FrmANeg.FNew() | Ninguno | lAreaNeg | Modal JavaScript |
| Bt_Edit_Click | FrmANeg.FEdit() | lAreaNeg.Id | lAreaNeg actualizado | Modal JavaScript |
| Grid_DblClick | FrmANeg (según fila) | Id o ninguno | lAreaNeg | Modal JavaScript |
| Bt_Importador_Click | FrmImpAreaNegocio | Ninguno | Ninguno | TODO [FUTURE] |

### Flujo de Estados del Form
```
[Inicio] → Form_Load() → CargaInicial() → LoadAll() → [Estado: Listado cargado]
  ↓
[Bt_New] → FrmANeg.FNew() → [Modal: Nuevo]
  ↓
[Bt_OK] → Valida() → INSERT (AdvTbAddNew) → UPDATE datos → lRc=vbOK → Unload → UpDateGrid() → [Listado actualizado]

[Grid_DblClick fila con datos] → FrmANeg.FEdit() → LoadAll() → [Modal: Edición]
  ↓
[Bt_OK] → Valida() → UPDATE → lRc=vbOK → Unload → UpDateGrid() → [Listado actualizado]

[Bt_Del] → Validar referencias → Confirmación → DeleteSQL → Grid.RowHeight(Row)=0 → [Listado actualizado]
```

---

## 📊 EXPORTACIONES E IMPORTACIONES

### Impresión (Bt_Print_Click)
```vb
' Botón: Bt_Print_Click
' Formato: Reporte con PrtFlexGrid
' Columnas: Código, Descripción
' Título: "LISTADO DE AREAS DE NEGOCIOS"
Call PrtFlexGrid(Grid, "", "LISTADO DE AREAS DE NEGOCIOS", "", "", ColWi, Total, False, , , , , , , , , , , True)
```
**→ Implementar:** window.print() con TODO [LEGACY] [MEDIUM]

### Importador (Bt_Importador_Click)
```vb
' Abre FrmImpAreaNegocio
Dim Frm As FrmImpAreaNegocio
Set Frm = New FrmImpAreaNegocio
Frm.Show vbModal
```
**→ Implementar:** TODO [FUTURE] [MEDIUM] [BLOCKED_BY: FrmImpAreaNegocio]

---

## 🎯 MAPEO FINAL: MÉTODOS .NET DETERMINADOS

### Interface del Service
```csharp
public interface IAreasNegocioService
{
    // CRUD Principal
    Task<IEnumerable<AreasNegocioDto>> GetAllAsync(int empresaId);
    Task<AreasNegocioDto?> GetByIdAsync(int id, int empresaId);
    Task<AreasNegocioDto> CreateAsync(int empresaId, AreasNegocioCreateDto dto);
    Task<AreasNegocioDto> UpdateAsync(int id, int empresaId, AreasNegocioUpdateDto dto);
    Task<bool> DeleteAsync(int id, int empresaId);

    // Validaciones
    Task<bool> CheckUniqueCodeAsync(string codigo, int empresaId, int? excludeId = null);

    // Validación de referencias
    Task<bool> HasReferencesAsync(int id, int empresaId);
}
```

### Resumen de Mapeo
| Funcionalidad VB6 | Método .NET | Complejidad | Prioridad |
|-------------------|-------------|-------------|-----------|
| Form_Load + LoadAll | GetAllAsync() | Baja | Alta |
| Bt_New + FrmANeg.FNew | CreateAsync() | Baja | Alta |
| Bt_Edit + FrmANeg.FEdit | GetByIdAsync() + UpdateAsync() | Baja | Alta |
| Bt_Del + Validación | HasReferencesAsync() + DeleteAsync() | Media | Alta |
| Valida() | CheckUniqueCodeAsync() | Baja | Alta |
| Bt_Print | window.print() TODO [LEGACY] | Baja | Media |
| Bt_Importador | TODO [FUTURE] | Alta | Baja (futura) |
| Bt_Sel | TODO [LEGACY] | Baja | Baja (no aplicable) |

---

## ⚠️ NOTAS IMPORTANTES Y OBSERVACIONES

### Peculiaridades del Form VB6
- Usa variable global `gEmpresa.Id` para filtrar datos
- Vigente usa valores -1 (True) y 0 (False) en lugar de boolean estándar
- Código se convierte a mayúsculas automáticamente (KeyUpper)
- Tiene modo "Selección" (O_VIEW) para elegir área desde otros módulos
- Grid oculta columna IdAreaNegocio (ColWidth=0)
- **Validación crítica**: Verifica referencias en MovComprobante antes de eliminar

### Decisiones de Diseño
- **Vigente como Boolean**: En .NET usar bool en DTO, mapear a -1/0 en BD
- **Código mayúsculas**: Aplicar ToUpper() en DTO o Service
- **Modo selección**: No implementar (web usa eventos JavaScript directos)
- **Importador**: TODO [FUTURE] - requiere migración de FrmImpAreaNegocio
- **Validación eliminación**: Implementar con mensaje específico si hay referencias

### Pendientes/Incompletos en VB6
- Bt_Print existe → **MIGRAR con TODO [LEGACY] [MEDIUM]**
- Bt_Importador abre otro form → **TODO [FUTURE] [BLOCKED_BY: FrmImpAreaNegocio]**
- Bt_Sel modo selección → **TODO [LEGACY] [LOW] - No aplicable en web**
- CountANeg() tiene código comentado sobre límite MAX_DESGLOESTRESULT → **No implementar** (validación deshabilitada)

---

## ✅ CHECKLIST DE COMPLETITUD DEL ANÁLISIS

- [x] Todos los controles UI documentados
- [x] Todos los botones y eventos mapeados
- [x] **TODOS los botones tienen "Mapeo .NET" definido** (sin excepciones "N/A (omitir)")
- [x] **Botones con excepciones documentan razón válida** (INTEGRATION, BLOCKED, LEGACY, FUTURE)
- [x] Todas las funciones VB6 identificadas
- [x] Todos los queries SQL traducidos a EF Core
- [x] Todas las validaciones documentadas
- [x] Todas las reglas de negocio identificadas
- [x] Navegación y flujos mapeados
- [x] Métodos .NET determinados
- [x] Interface del Service definida
- [x] **Decisiones de excepción justificadas y estructuradas**
- [x] **Validación de referencias en eliminación documentada**

---

**✅ ANÁLISIS COMPLETO - LISTO PARA IMPLEMENTACIÓN**