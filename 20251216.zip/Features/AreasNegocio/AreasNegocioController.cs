using Microsoft.AspNetCore.Mvc;
using App.Extensions;
using App.Helpers;

namespace App.Features.AreasNegocio;

/// <summary>
/// MVC Controller para gestión de Áreas de Negocio
/// </summary>
public class AreasNegocioController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<AreasNegocioController> logger) : Controller
{
    /// <summary>
    /// Vista principal de Áreas de Negocio
    /// Carga el listado completo de áreas para la empresa en sesión
    /// </summary>
    public async Task<IActionResult> Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Áreas de Negocio";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        var empresaId = SessionHelper.EmpresaId;

        logger.LogInformation("Index: Cargando vista de áreas de negocio para empresaId={EmpresaId}", empresaId);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AreasNegocioApiController>(
            HttpContext,
            nameof(AreasNegocioApiController.GetAll),
            new { empresaId }
        );
        var areas = await client.GetFromApiAsync<List<AreasNegocioDto>>(url!);

        logger.LogInformation("Index: Áreas de negocio cargadas exitosamente. Total: {Count}", areas?.Count ?? 0);
        return View(areas ?? new List<AreasNegocioDto>());
    }

    /// <summary>
    /// Guardar área de negocio desde formulario tradicional (POST)
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Save([Bind(Prefix = "formModel")] AreasNegocioFormDto model)
    {
        logger.LogInformation("Save: Recibido - Codigo={Codigo}, Descripcion={Descripcion}, Vigente={Vigente}, IdAreaNegocio={Id}",
            model?.Codigo, model?.Descripcion, model?.Vigente, model?.IdAreaNegocio);

        if (!ModelState.IsValid)
        {
            var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).ToList();
            logger.LogWarning("Save: ModelState inválido - Errores: {Errors}", string.Join(", ", errors));
            return Json(new { success = false, errors });
        }

        var empresaId = SessionHelper.EmpresaId;
        var client = httpClientFactory.CreateClient();

        if (model.IdAreaNegocio > 0)
        {
            // Actualizar
            var updateDto = new AreasNegocioUpdateDto
            {
                Codigo = model.Codigo,
                Descripcion = model.Descripcion,
                Vigente = model.Vigente
            };

            var url = linkGenerator.GetApiUrl<AreasNegocioApiController>(
                HttpContext,
                nameof(AreasNegocioApiController.Update),
                new { id = model.IdAreaNegocio, empresaId }
            );
            await client.PutToApiAsync(url!, updateDto);
        }
        else
        {
            // Crear
            var createDto = new AreasNegocioCreateDto
            {
                Codigo = model.Codigo,
                Descripcion = model.Descripcion,
                Vigente = model.Vigente
            };

            var url = linkGenerator.GetApiUrl<AreasNegocioApiController>(
                HttpContext,
                nameof(AreasNegocioApiController.Create),
                new { empresaId }
            );
            await client.PostToApiAsync(url!, createDto);
        }

        var message = model.IdAreaNegocio > 0 ? "Área actualizada correctamente" : "Área creada correctamente";
        return Json(new { success = true, message });
    }

    /// <summary>
    /// Eliminar área de negocio desde formulario tradicional (POST)
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirm(int id)
    {
        var empresaId = SessionHelper.EmpresaId;
        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AreasNegocioApiController>(
            HttpContext,
            nameof(AreasNegocioApiController.Delete),
            new { id, empresaId }
        );
        await client.DeleteFromApiAsync(url!);

        TempData["Success"] = "Área de negocio eliminada correctamente";
        return RedirectToAction("Index");
    }
}
