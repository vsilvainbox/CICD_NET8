using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using App.Extensions;

namespace App.Features.AcercaDelSistema;

[Authorize]

public class AcercaDelSistemaController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<AcercaDelSistemaController> logger) : Controller
{
    public async Task<IActionResult> Index()
    {
        logger.LogInformation("Loading Acerca del Sistema");

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AcercaDelSistemaApiController>(
            HttpContext,
            nameof(AcercaDelSistemaApiController.Get));
        var data = await client.GetFromApiAsync<AcercaDelSistemaDto>(url!);

        logger.LogInformation("Successfully loaded system information");
        return View(data);
    }
}