namespace App.Features.BaseImponible14D;

public class BaseImponible14DDto
{
    public int IdEmpresa { get; set; }
    public short Ano { get; set; }
    public decimal BaseImp14DN3 { get; set; }
    public decimal BaseImp14DN8 { get; set; }
    public string TipoRegimen { get; set; } = string.Empty; // "ProPymeGeneral" o "ProPymeTransp"
    public string NombreEmpresa { get; set; } = string.Empty;
}
    
public class BaseImponible14DSaveDto
{
    public decimal Valor { get; set; }
}