# ✅ Feature Refactorizada

**Fecha:** 2025-12-07
**Guía aplicada:** refactor.md
**Feature:** BaseImponible14D

## Violaciones Detectadas Inicialmente

- **R16:http-directo** - 1 violación (ya estaba corregida)
- **R20:fetch-manual** - 3 violaciones detectadas

## Reglas Aplicadas

### WebController (BaseImponible14DController.cs)

- [x] **R02** - Sin try-catch
- [x] **R03** - Llama a API Controller (no a Service directo)
- [x] **R04** - URLs con GetApiUrl<T>()
- [x] **R16** - Usa GetFromApiAsync (ya estaba implementado correctamente)
- [x] **R19** - Eliminado método proxy TraspasarPerdidaAnterior (JavaScript llama directo a ApiController)

### ApiController (BaseImponible14DApiController.cs)

- [x] **R02** - Sin try-catch
- [x] **R02** - Retorna Ok()/Ok(data)
- [x] **R15** - No captura excepciones (fluyen al middleware)

### Service (BaseImponible14DService.cs)

- [x] **R15** - Usa BusinessException para errores de validación
- [x] **R17** - Tipos SQL correctos (byte, short, decimal, double)

### Vista (Views/Index.cshtml)

- [x] **R04** - URLs con @Url.Action
- [x] **R19** - JavaScript llama directamente a ApiController (TraspasarPerdidaAnterior)
- [x] **R20** - Reemplazado fetch manual por Api.postJson
- [x] **R20** - Exportaciones Excel/PDF usan window.location (descarga directa)

## Cambios Realizados

### 1. BaseImponible14DController.cs

**Líneas 79-91 - ELIMINADO método proxy TraspasarPerdidaAnterior**

Razón: Viola R19 (JavaScript debe llamar directamente a ApiController, no usar proxy por WebController)

**Antes:**
```csharp
[HttpPost]
public async Task<IActionResult> TraspasarPerdidaAnterior(int empresaId, short ano)
{
    var client = httpClientFactory.CreateClient();
    var url = linkGenerator.GetApiUrl<BaseImponible14DApiController>(HttpContext, nameof(BaseImponible14DApiController.TraspasarPerdidaAnterior), new { empresaId, ano });
    await client.PostToApiAsync(url!, (object?)null);
    return Ok(new { message = "Pérdida traspasada exitosamente" });
}
```

**Después:**
```csharp
// Eliminado - JavaScript ahora llama directo a BaseImponible14DApiController
```

**Nota:** Los métodos ExportExcel y ExportPdf se mantienen como proxy porque manejan descargas de archivos, lo cual es un caso válido según las reglas.

---

### 2. Views/Index.cshtml

**Líneas 206-211 - ACTUALIZADO: URL endpoints apuntan a ApiController**

**Antes:**
```javascript
const URL_ENDPOINTS = {
    exportExcel: '@Url.Action("ExportExcel", "BaseImponible14D")',
    exportPdf: '@Url.Action("ExportPdf", "BaseImponible14D")',
    traspasarPerdida: '@Url.Action("TraspasarPerdidaAnterior", "BaseImponible14D")' // ❌ Apuntaba a WebController
};
```

**Después:**
```javascript
// R04 + R19: URLs apuntan a ApiController (no WebController)
const URL_ENDPOINTS = {
    exportExcel: '@Url.Action("ExportExcel", "BaseImponible14D")', // Proxy necesario para descargas
    exportPdf: '@Url.Action("ExportPdf", "BaseImponible14D")', // Proxy necesario para descargas
    traspasarPerdida: '@Url.Action("TraspasarPerdidaAnterior", "BaseImponible14DApi")' // ✅ Apunta a ApiController
};
```

---

**Líneas 224-227 - REFACTORIZADO: exportExcel() sin fetch manual**

**Antes:**
```javascript
async function exportExcel() {
    try {
        const response = await fetch(`${URL_ENDPOINTS.exportExcel}?empresaId=${empresaId}&ano=${ano}`);
        if (response.ok) {
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `BaseImponible14D_${ano}.xlsx`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
            Swal.fire('Éxito', 'Archivo Excel exportado correctamente', 'success');
        }
    } catch (error) {
        Swal.fire('Error', 'No se pudo exportar el archivo', 'error');
    }
}
```

**Después:**
```javascript
function exportExcel() {
    // R20: Descarga directa usando window.location (sin fetch manual)
    window.location.href = `${URL_ENDPOINTS.exportExcel}?empresaId=${empresaId}&ano=${ano}`;
}
```

---

**Líneas 229-233 - REFACTORIZADO: exportPdf() sin fetch manual**

**Antes:**
```javascript
async function exportPdf() {
    try {
        const response = await fetch(`${URL_ENDPOINTS.exportPdf}?empresaId=${empresaId}&ano=${ano}`);
        if (response.ok) {
            const blob = await response.blob();
            // ... manejo manual de blob ...
            Swal.fire('Éxito', 'Archivo PDF exportado correctamente', 'success');
        }
    } catch (error) {
        Swal.fire('Error', 'No se pudo exportar el archivo PDF', 'error');
    }
}
```

**Después:**
```javascript
function exportPdf() {
    // R20: Descarga directa usando window.location (sin fetch manual)
    window.location.href = `${URL_ENDPOINTS.exportPdf}?empresaId=${empresaId}&ano=${ano}`;
}
```

---

**Líneas 235-264 - REFACTORIZADO: traspasarPerdidaAnterior() usa Api.postJson**

**Antes:**
```javascript
async function traspasarPerdidaAnterior() {
    try {
        const confirm = await Swal.fire({...});
        if (!confirm.isConfirmed) return;

        const response = await fetch(`${URL_ENDPOINTS.traspasarPerdida}?empresaId=${empresaId}&ano=${ano}`, {
            method: 'POST',
            headers: { 'Accept': 'application/json' }
        });

        if (response.ok) {
            Swal.fire({...}).then(() => location.reload());
        } else {
            const error = await response.json();
            Swal.fire('Error', error.message || 'No se pudo traspasar la pérdida', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        Swal.fire('Error', 'No se pudo traspasar la pérdida del año anterior', 'error');
    }
}
```

**Después:**
```javascript
async function traspasarPerdidaAnterior() {
    const confirm = await Swal.fire({
        title: '¿Traspasar Pérdida del Año Anterior?',
        html: `<p>Esta acción traspasará la pérdida tributaria del año ${ano - 1} al año actual con código 9600.</p>
               <p class="mt-2 text-gray-600">¿Desea continuar?</p>`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Sí, traspasar',
        cancelButtonText: 'Cancelar'
    });

    if (!confirm.isConfirmed) return;

    // R20: Usar Api.postJson en lugar de fetch manual
    const result = await Api.postJson(`${URL_ENDPOINTS.traspasarPerdida}?empresaId=${empresaId}&ano=${ano}`, null);

    if (result) {
        Swal.fire({
            title: 'Éxito',
            text: 'Pérdida del año anterior traspasada correctamente',
            icon: 'success',
            confirmButtonColor: '#d64000'
        }).then(() => {
            location.reload();
        });
    }
}
```

## Verificación Final

### Comandos ejecutados

```bash
# R16: PostAsJsonAsync/GetAsync en Controller
grep -n "PostAsJsonAsync\|GetAsync\s*(" BaseImponible14DController.cs
# Resultado: Sin violaciones ✅

# R20: fetch manual en Vista
grep -n "await\s\+fetch(\|\.ajax(\|axios\." Views/Index.cshtml
# Resultado: Sin violaciones ✅
```

## Beneficios de la Refactorización

1. **R16 cumplido**: El WebController ya usaba `GetFromApiAsync` correctamente (no requirió cambios).

2. **R19 cumplido**: JavaScript llama directamente a `BaseImponible14DApiController.TraspasarPerdidaAnterior` sin pasar por proxy del WebController.

3. **R20 cumplido**:
   - Exportaciones Excel/PDF usan descarga directa con `window.location` (más simple, sin manejo manual de blobs)
   - Función `traspasarPerdidaAnterior` usa `Api.postJson` con manejo automático de errores

4. **Código más limpio**: Eliminado código repetitivo de manejo de fetch, blobs y errores.

5. **Manejo de errores consistente**: `Api.postJson` muestra SweetAlert automáticamente en caso de error (R15).

## Notas Adicionales

- **Proxy para descargas**: Los métodos `ExportExcel` y `ExportPdf` del WebController se mantienen como proxy porque manejan descarga de archivos, lo cual es un caso de uso válido según las reglas (necesitan usar `DownloadFileAsync` para el manejo correcto de archivos).

- **Tipos SQL**: El Service ya usa tipos correctos (byte, short, decimal, double) según R17.

- **BusinessException**: El Service ya lanza BusinessException correctamente para errores de validación según R15.

## Estado Final

✅ **0 violaciones de R16**
✅ **0 violaciones de R20**
✅ **Todas las reglas aplicables verificadas y cumplidas**
