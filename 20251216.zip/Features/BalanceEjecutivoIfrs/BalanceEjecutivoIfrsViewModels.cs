namespace App.Features.BalanceEjecutivoIfrs;

/// <summary>
/// ViewModel para la vista Index de Balance Ejecutivo IFRS
/// Patrón: JavaScript + API Directo
/// - Los combos se cargan por JavaScript (Api.get)
/// - El balance se genera por JavaScript (Api.postJson)
/// - Los resultados se renderizan dinámicamente (innerHTML)
/// - El ViewModel solo contiene valores iniciales de filtros
/// </summary>
public class BalanceEjecutivoIfrsIndexViewModel
{
    public DateTime FechaDesde { get; set; }
    public DateTime FechaHasta { get; set; }
}
