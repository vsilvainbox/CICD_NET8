namespace App.Features.BalanceEjecutivoIfrs;

/// <summary>
/// Servicio para generar el Balance Ejecutivo IFRS.
/// Genera un balance en formato T (Activos | Pasivos + Patrimonio).
/// </summary>
public interface IBalanceEjecutivoIfrsService
{
    /// <summary>
    /// Genera el Balance Ejecutivo IFRS para un período específico.
    /// </summary>
    /// <param name="request">Parámetros de generación del balance</param>
    /// <returns>Balance ejecutivo con secciones de Activos, Pasivos y Patrimonio</returns>
    Task<BalanceEjecutivoIfrsResponseDto> GenerarAsync(BalanceEjecutivoIfrsRequestDto request);

    /// <summary>
    /// Valida que exista un plan de cuentas configurado con códigos IFRS.
    /// </summary>
    /// <returns>Tupla indicando si es válido y el nombre del plan actual</returns>
    Task<(bool EsValido, string? PlanActual)> ValidarPlanCuentasAsync();

    /// <summary>
    /// Verifica si existen cuentas sin clasificación IFRS hasta una fecha específica.
    /// </summary>
    /// <param name="fechaHasta">Fecha hasta la cual verificar</param>
    /// <returns>True si existen cuentas sin clasificación IFRS</returns>
    Task<bool> ExistenCuentasSinClasificacionIfrsAsync(DateTime fechaHasta);

    /// <summary>
    /// Obtiene lista de áreas de negocio para dropdowns.
    /// </summary>
    Task<List<Shared.ComboItemDto>> GetAreasNegocioAsync();

    /// <summary>
    /// Obtiene lista de centros de costo para dropdowns.
    /// </summary>
    Task<List<Shared.ComboItemDto>> GetCentrosCostoAsync();
}
