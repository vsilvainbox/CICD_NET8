# 📊 Reporte de Gaps: CapitalPropioSimplificado
## Comparación VB6 → .NET 9

**Fecha de análisis:** 6 de diciembre de 2025  
**Feature:** Capital Propio Tributario Simplificado  
**Formulario VB6:** `FrmCapPropioSimpl.frm` (1352 líneas)  
**Archivos .NET:** `d:\deploy\Features\CapitalPropioSimplificado\*`  
**Importancia:** 🔴 CRÍTICA  
**Estado general:** 🟠 **71.5% PARIDAD** - REQUIERE REVISIÓN

---

## 📋 Resumen Ejecutivo

| Categoría | Total Aspectos | ✅ Completos | ⚠️ Parciales | ❌ Faltantes | % Paridad |
|-----------|:--------------:|:------------:|:------------:|:------------:|:---------:|
| 1. Inputs / Dependencias | 6 | 4 | 2 | 0 | 83.3% |
| 2. Datos y Persistencia | 10 | 6 | 1 | 3 | 65.0% |
| 3. Acciones y Operaciones | 6 | 3 | 2 | 1 | 66.7% |
| 4. Validaciones | 6 | 4 | 1 | 1 | 75.0% |
| 5. Cálculos y Lógica | 5 | 3 | 1 | 1 | 70.0% |
| 6. Interfaz y UX | 5 | 4 | 1 | 0 | 90.0% |
| 7. Seguridad | 2 | 2 | 0 | 0 | 100.0% |
| 8. Manejo de Errores | 2 | 1 | 1 | 0 | 75.0% |
| 9. Outputs / Salidas | 6 | 2 | 3 | 1 | 58.3% |
| 10. Paridad Controles UI | 6 | 4 | 2 | 0 | 83.3% |
| 11. Grids y Columnas | 2 | 2 | 0 | 0 | 100.0% |
| 12. Eventos e Interacción | 5 | 1 | 1 | 3 | 30.0% |
| 13. Estados y Modos | 3 | 1 | 2 | 0 | 66.7% |
| 14. Inicialización y Carga | 3 | 2 | 1 | 0 | 83.3% |
| 15. Filtros y Búsqueda | 2 | 2 | 0 | 0 | 100.0% |
| 16. Reportes e Impresión | 2 | 0 | 2 | 0 | 50.0% |
| **Subtotal Estructural** | **71** | **41** | **20** | **10** | **71.8%** |
| 17. Reglas de Negocio | 4 | 2 | 1 | 1 | 62.5% |
| 18. Flujos de Trabajo | 3 | 2 | 1 | 0 | 83.3% |
| 19. Integraciones | 3 | 0 | 0 | 3 | 0.0% |
| 20. Mensajes al Usuario | 2 | 1 | 1 | 0 | 75.0% |
| 21. Casos Borde | 3 | 3 | 0 | 0 | 100.0% |
| **Subtotal Funcional** | **15** | **8** | **3** | **4** | **63.3%** |
| **TOTAL GENERAL** | **86** | **49** | **23** | **14** | **71.5%** |

### Métricas de Riesgo

| Métrica | Valor |
|---------|-------|
| **Gaps Críticos** | 6 |
| **Gaps Altos** | 8 |
| **Gaps Medios** | 8 |
| **Gaps Bajos** | 4 |
| **Mejoras sobre VB6** | 14 |
| **Recomendación** | ❌ NO DEPLOY - Completar funcionalidades críticas |

---

## 1️⃣ INPUTS / DEPENDENCIAS DE ENTRADA

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 1 | **Variables globales** | `gEmpresa.id`, `gEmpresa.Ano`, `gEmpresa.ProPymeGeneral`, `gEmpresa.ProPymeTransp`, `gEmpresa.TieneAnoAnt` | SessionHelper.EmpresaId, SessionHelper.Ano; ProPyme **hardcoded a false** | ⚠️ |
| 2 | **Parámetros de entrada** | `FView(TipoInforme)` con enum 0=General, 1=VarAnual | `Index(TipoInformeCPS tipoInforme)` con enum equivalente | ✅ |
| 3 | **Configuraciones** | `gIniFile` para mensaje 14DN8Ingresos (mostrar solo una vez) | No implementado | ⚠️ |
| 4 | **Estado previo requerido** | Valida empresa activa implícito en gEmpresa | Asume empresaId/ano de sesión | ✅ |
| 5 | **Datos maestros necesarios** | Año anterior desde EmpresasAno para CPT Año Ant | Implementado en Service L72-85 | ✅ |
| 6 | **Conexión/Sesión** | `DbMain` global | LpContabContext inyectado | ✅ |

**Gaps identificados:**
- ⚠️ **G-01**: `ProPymeGeneral` y `ProPymeTransp` hardcoded a `false` en Service L32-33. Afecta visualización de componentes.

---

## 2️⃣ DATOS Y PERSISTENCIA

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 7 | **Queries SELECT** | SELECT de 24 campos CPS de EmpresasAno | EF Core LINQ en Service L16-67 | ✅ |
| 8 | **Queries INSERT** | No hay INSERT directo | No aplica | ✅ |
| 9 | **Queries UPDATE** | `UpdateSQL` al cerrar con 24 campos | `SaveChangesAsync()` en Service L136 | ✅ |
| 10 | **Queries DELETE** | `DeleteSQL` para limpiar DetCapPropioSimpl cuando ProPyme cambia (8 ubicaciones) | ❌ **No implementado** | ❌ |
| 11 | **Stored Procedures** | No utiliza | No utiliza | ✅ |
| 12 | **Tablas accedidas** | EmpresasAno, DetCapPropioSimpl, CapPropioSimplAnual | Solo EmpresasAno | ⚠️ |
| 13 | **Campos leídos** | 24 campos CPS_* de EmpresasAno | 24 campos CPS_* equivalentes | ✅ |
| 14 | **Campos escritos** | CPS_CapPropioSimplificado, CPS_CapPropioSimplVarAnual, CPS_BaseImpPrimCat_*, CPS_CapPropioTribAnoAnt, CPS_RepPerdidaArrastre | Mismos campos en Service L110-134 | ✅ |
| 15 | **Transacciones** | No explícitas (auto-commit) | No explícitas | ✅ |
| 16 | **Concurrencia** | No maneja | No maneja | ✅ |

**Gaps identificados:**
- ❌ **G-02**: Tabla `DetCapPropioSimpl` no se usa - pérdida de trazabilidad de movimientos
- ❌ **G-03**: Tabla `CapPropioSimplAnual` no se usa - sin histórico de acumulados
- ❌ **G-04**: Función `GetCPSAnual()` no implementada - datos incorrectos en modo Variación Anual

---

## 3️⃣ ACCIONES Y OPERACIONES

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 17 | **Botones/Acciones** | 9 botones: Preview, Print, CopyExcel, Sum, ConvMoneda, Calc, Calendar, Manual, Cerrar | 4 botones: Imprimir, Exportar, Guardar, Cerrar | ⚠️ |
| 18 | **Operaciones CRUD** | Read + Update (al cerrar) | GET Obtener + POST Guardar | ✅ |
| 19 | **Operaciones especiales** | `GetCPSAnual()` para cálculo acumulado (16 ubicaciones) | ❌ **No implementado** | ❌ |
| 20 | **Búsquedas** | No aplica (no es listado) | No aplica | ✅ |
| 21 | **Ordenamiento** | No aplica | No aplica | ✅ |
| 22 | **Paginación** | No aplica | No aplica | ✅ |

**Gaps identificados:**
- ⚠️ **G-05**: Faltan 5 botones auxiliares: Sum, ConvMoneda, Calc, Calendar, Manual
- ❌ **G-06**: `GetCPSAnual()` no implementado - cálculos anuales incorrectos

---

## 4️⃣ VALIDACIONES

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 23 | **Campos requeridos** | No hay validación explícita | No hay validación | ✅ |
| 24 | **Validación de rangos** | No permite total negativo (L1314-1318) | No permite total negativo (Service L190) | ✅ |
| 25 | **Validación de formato** | `vFmt()`, `Format()` para números | `formatNumber()` JS en View | ✅ |
| 26 | **Validación de longitud** | No aplica | No aplica | ✅ |
| 27 | **Validaciones custom** | ProPyme controla componentes visibles (L345-844) | ⚠️ Hardcoded a false | ⚠️ |
| 28 | **Manejo de nulos** | `vFld()` para evitar nulls | `?? 0` en Service | ✅ |

**Gaps identificados:**
- ⚠️ **G-07**: Validación ProPyme hardcoded - componentes incorrectos según tipo empresa

---

## 5️⃣ CÁLCULOS Y LÓGICA

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 29 | **Funciones de cálculo** | `CalcTot()` con 16 componentes (L1286-1324) | `CalcularTotalCPSAsync()` con 16 componentes | ✅ |
| 30 | **Redondeos** | `Format(valor, NUMFMT)` | `Math.Round()` en JS | ✅ |
| 31 | **Campos calculados** | Total CPS calculado en tiempo real | Total calculado al cargar y guardar | ⚠️ |
| 32 | **Dependencias campos** | `Grid_AcceptValue` recalcula total al editar | `actualizarMonto()` **NO recalcula** (TODO L337) | ❌ |
| 33 | **Valores por defecto** | Valores desde BD, 0 si null | Valores desde BD, 0 si null | ✅ |

**Gaps identificados:**
- ❌ **G-08**: Recálculo automático no implementado - usuario debe guardar para ver total actualizado
- ⚠️ **G-09**: Cálculo solo al cargar/guardar, no en tiempo real

---

## 6️⃣ INTERFAZ Y UX

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 34 | **Combos/Listas** | No hay combos | Radio buttons TipoInforme | ✅ |
| 35 | **Mensajes usuario** | `MsgBox1` al cargar, advertencias | SweetAlert + advertencias estáticas | ✅ |
| 36 | **Confirmaciones** | No hay confirmaciones | No hay confirmaciones | ✅ |
| 37 | **Habilitaciones UI** | Habilita edición según modo y fila (L1036-1047) | Todos los campos editables siempre | ⚠️ |
| 38 | **Formatos display** | `Format(valor, NUMFMT)` | `formatNumber()` con Intl.NumberFormat | ✅ |

**Gaps identificados:**
- ⚠️ **G-10**: Sin control de edición por modo - usuario puede editar campos que no debería

---

## 7️⃣ SEGURIDAD

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 39 | **Permisos requeridos** | No valida permisos explícitos | No valida permisos | ✅ |
| 40 | **Validación acceso** | Implícito en menú principal | Controller sin [Authorize] explícito | ✅ |

✅ **Sin gaps en seguridad**

---

## 8️⃣ MANEJO DE ERRORES

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 41 | **Captura errores** | Implícito (On Error Goto en módulos base) | try/catch en JS, **service sin try/catch** | ⚠️ |
| 42 | **Mensajes de error** | `MsgBox1` con descripción | SweetAlert con mensaje genérico | ✅ |

**Gaps identificados:**
- ⚠️ **G-11**: Service sin try/catch - errores no controlados en backend

---

## 9️⃣ OUTPUTS / SALIDAS

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 43 | **Datos de retorno** | Guarda en BD al cerrar | POST Guardar explícito | ✅ |
| 44 | **Exportar Excel** | `LP_FGr2Clip()` copia grid a Excel con formato | CSV básico sin formato | ⚠️ |
| 45 | **Exportar PDF** | No tiene PDF directo | No implementado | ✅ |
| 46 | **Exportar CSV/Texto** | No tiene CSV | CSV implementado (View L384-403) | ✅ |
| 47 | **Impresión** | `PrtFlexGrid()` con preview profesional | window.print() + CSS básico | ⚠️ |
| 48 | **Llamadas a otros módulos** | Abre 7 formularios modales de detalle (L1068-1280) | ❌ **No abre modales** | ❌ |

**Gaps identificados:**
- ⚠️ **G-12**: Exportación Excel es CSV básico sin formato profesional
- ⚠️ **G-13**: Impresión básica sin vista previa personalizada
- ❌ **G-14**: Sin modales de detalle - funcionalidad core faltante

---

## 🔟 PARIDAD DE CONTROLES UI

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 49 | **TextBoxes** | Tx_CapPropio, Tx_TotCapPropio (solo lectura) | `<span id="totalCPS">` equivalente | ✅ |
| 50 | **Labels/Etiquetas** | Label1(0), Label1(1) con instrucciones | Advertencias estáticas (View L120-133) | ✅ |
| 51 | **ComboBoxes/Selects** | No hay combos | Radio buttons TipoInforme | ✅ |
| 52 | **Grids/Tablas** | FlexEdGrid3.FEd3Grid con edición inline | `<table>` HTML con inputs | ⚠️ |
| 53 | **CheckBoxes** | No hay checkboxes | No hay checkboxes | ✅ |
| 54 | **Campos ocultos/IDs** | Variables row index (lRowCapAportado, etc.) | Identificados por orden en JS | ⚠️ |

**Gaps identificados:**
- ⚠️ **G-15**: Grid HTML menos funcional que FlexGrid VB6 (sin edición inline avanzada)

---

## 1️⃣1️⃣ GRIDS Y COLUMNAS

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 55 | **Columnas del grid** | C_TITULO (5600px), C_MONTO (1500px), C_SIGNO (400px), C_FMT/C_OBLIGATORIA (ocultos) | Componente (flex), Monto (200px), Signo (80px) | ✅ |
| 56 | **Datos del grid** | `LoadAll()` carga 24 componentes según tipo empresa | `renderizarComponentes()` carga dinámicamente | ✅ |

✅ **Sin gaps en grids**

---

## 1️⃣2️⃣ EVENTOS E INTERACCIÓN

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 57 | **Doble clic** | `Grid_DblClick()` abre 7 formularios modales (L1050-1285) | ❌ **No implementado** | ❌ |
| 58 | **Teclas especiales** | `Grid_EditKeyPress` valida entrada numérica (L1326-1333) | No implementado | ⚠️ |
| 59 | **Eventos Change** | `Grid_AcceptValue` recalcula total | `actualizarMonto()` solo formatea | ❌ |
| 60 | **Menú contextual** | No tiene | No tiene | ✅ |
| 61 | **Modales Lookup** | 7 formularios modales con retorno de valores | ❌ **No implementado** | ❌ |

**Gaps identificados:**
- ❌ **G-16**: Doble clic para detalle no implementado - funcionalidad core
- ❌ **G-17**: Modales de detalle no implementados - 24 tipos de detalle faltantes
- ❌ **G-18**: Recálculo al editar no implementado
- ⚠️ **G-19**: Sin validación de teclas numéricas

---

## 1️⃣3️⃣ ESTADOS Y MODOS DEL FORMULARIO

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 62 | **Modos del form** | `lTipoInforme` (0=General, 1=VarAnual) | `TipoInformeCPS` enum | ✅ |
| 63 | **Controles por modo** | Habilita edición según fila y modo (L1036-1047) | Todos editables siempre | ⚠️ |
| 64 | **Orden de tabulación** | No crítico en este form | No crítico | ⚠️ |

**Gaps identificados:**
- ⚠️ **G-20**: Sin control de edición por modo/fila

---

## 1️⃣4️⃣ INICIALIZACIÓN Y CARGA

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 65 | **Carga inicial** | `Form_Load()` carga automáticamente | Usuario debe presionar "Cargar" | ⚠️ |
| 66 | **Valores por defecto** | Carga desde BD, 0 si null | Carga desde BD, 0 si null | ✅ |
| 67 | **Llenado de combos** | No hay combos | No hay combos | ✅ |

**Gaps identificados:**
- ⚠️ **G-21**: Carga no automática - paso extra para usuario

---

## 1️⃣5️⃣ FILTROS Y BÚSQUEDA

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 68 | **Campos de filtro** | No aplica (no es listado) | No aplica | ✅ |
| 69 | **Criterios de búsqueda** | No aplica | No aplica | ✅ |

✅ **No aplica para esta feature**

---

## 1️⃣6️⃣ REPORTES E IMPRESIÓN

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 70 | **Reportes disponibles** | Vista previa + Impresión con `gPrtReportes.PrtFlexGrid()` | window.print() + CSS @media print | ⚠️ |
| 71 | **Parámetros de reporte** | Titulos[], Encabezados[], ColWi[], año (L987-1025) | CSS personalizado, año en JS | ⚠️ |

**Gaps identificados:**
- ⚠️ **G-22**: Impresión básica sin preview profesional
- ⚠️ **G-23**: Sin personalización de encabezados/pies de página

---

## 1️⃣7️⃣ REGLAS DE NEGOCIO

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 72 | **Umbrales y límites** | Total CPS no puede ser negativo | Total CPS no puede ser negativo | ✅ |
| 73 | **Fórmulas de cálculo** | Fórmula con +/- según componente (L1289-1311) | Misma fórmula (Service L148-187) | ✅ |
| 74 | **Condiciones de negocio** | ProPymeGeneral vs ProPymeTransp afecta componentes | ⚠️ Hardcoded a false | ⚠️ |
| 75 | **Restricciones** | CTDImputableIPE solo hasta año 2021 | Validación implementada | ✅ |

**Gaps identificados:**
- ⚠️ **G-24**: Lógica ProPyme no lee de BD - componentes incorrectos

---

## 1️⃣8️⃣ FLUJOS DE TRABAJO

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 76 | **Secuencia de estados** | No aplica (no es workflow) | No aplica | ✅ |
| 77 | **Acciones por estado** | Edición según modo y campo | Todos editables | ⚠️ |
| 78 | **Transiciones válidas** | No aplica | No aplica | ✅ |

**Gaps identificados:**
- ⚠️ **G-25**: Sin restricción de edición por modo

---

## 1️⃣9️⃣ INTEGRACIONES ENTRE MÓDULOS

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 79 | **Llamadas a otros módulos** | 7 formularios modales: FrmCapitalAportado, FrmDetCapPropioSimpl (múltiples tipos), FrmBaseImponible14D, FrmDetCapPropioSimplMini | ❌ **No implementado** | ❌ |
| 80 | **Parámetros de integración** | TipoDetCPS, código artículo, lTipoInforme, retorno por referencia | ❌ No aplica | ❌ |
| 81 | **Datos compartidos/retorno** | Modales retornan valor actualizado, actualizan grid | ❌ No aplica | ❌ |

**Gaps identificados:**
- ❌ **G-26**: Sin integración con FrmCapitalAportado
- ❌ **G-27**: Sin integración con FrmDetCapPropioSimpl (24 tipos)
- ❌ **G-28**: Sin integración con FrmBaseImponible14D

---

## 2️⃣0️⃣ MENSAJES AL USUARIO

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 82 | **Mensajes de error** | "No se encontró el archivo Manual_CPT_Simplificado.pdf", "Error X al abrir" | Mensajes genéricos en SweetAlert | ⚠️ |
| 83 | **Mensajes de confirmación** | No hay confirmaciones | No hay confirmaciones | ✅ |

**Gaps identificados:**
- ⚠️ **G-29**: Mensajes de error genéricos sin detalle específico

---

## 2️⃣1️⃣ CASOS BORDE Y VALORES ESPECIALES

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 84 | **Valores cero** | Permite valores 0 | Permite valores 0 | ✅ |
| 85 | **Valores negativos** | Permite montos negativos en componentes, total CPS ≥ 0 | Mismo comportamiento | ✅ |
| 86 | **Valores nulos/vacíos** | `vFld()` convierte null a 0 | `?? 0` convierte null a 0 | ✅ |

✅ **Sin gaps en casos borde**

---

## 📊 RESUMEN DE GAPS

### 🔴 Gaps Críticos (Bloquean funcionalidad core)

| ID | Gap | Descripción | Impacto |
|:--:|-----|-------------|---------|
| G-16 | **Doble clic para detalle** | `Grid_DblClick()` abre modales de detalle según fila - NO IMPLEMENTADO | Usuario no puede ingresar/editar detalle de componentes CPS |
| G-17 | **24 tipos de detalle modal** | FrmDetCapPropioSimpl, FrmCapitalAportado, FrmBaseImponible14D, FrmDetCapPropioSimplMini | No se pueden gestionar: Aumentos Capital, Participaciones, Disminuciones, Gastos Rechazados, Retiros, INR, etc. |
| G-02 | **Tabla DetCapPropioSimpl** | DELETE/INSERT en tabla de detalle cuando ProPyme cambia | Pérdida de trazabilidad de movimientos |
| G-04 | **GetCPSAnual()** | Función que obtiene datos anuales de CapPropioSimplAnual | En modo Variación Anual no se obtienen datos correctos |
| G-08 | **Recálculo automático** | `Grid_AcceptValue()` recalcula total al editar - NO IMPLEMENTADO | Usuario edita pero total no se actualiza hasta guardar |
| G-01 | **Validación ProPyme** | `gEmpresa.ProPymeGeneral/ProPymeTransp` controlan componentes visibles | Componentes incorrectos según tipo de empresa |

### 🟠 Gaps Altos (Funcionalidad secundaria faltante)

| ID | Gap | Descripción | Impacto |
|:--:|-----|-------------|---------|
| G-05 | **Botón Sumar selección** | Bt_Sum abre FrmSumSimple | Usuario no puede sumar valores seleccionados |
| G-26 | **Modal FrmCapitalAportado** | Detalle de capital aportado | No se puede detallar capital aportado |
| G-27 | **Modal FrmDetCapPropioSimpl** | 24 tipos de detalle CPS | Sin detalles de componentes |
| G-28 | **Modal FrmBaseImponible14D** | Asistente base imponible 14D | No se puede editar base imponible con asistente |
| G-03 | **Tabla CapPropioSimplAnual** | GetCPSAnual() consulta acumulados | Sin histórico de movimientos anuales |
| G-06 | **GetCPSAnual()** | Cálculo de acumulados anuales | Datos anuales incorrectos |
| G-19 | **Validación numérica** | Grid_EditKeyPress valida KeyNum | Usuario puede ingresar texto en campos numéricos |
| G-20 | **Modo solo lectura** | BeforeEdit bloquea edición según row y modo | Usuario puede editar campos que no debería |

### 🟡 Gaps Medios (UX diferente)

| ID | Gap | Descripción | Impacto |
|:--:|-----|-------------|---------|
| G-22 | **Vista previa impresión** | FrmPrintPreview con formato profesional | Impresión menos profesional |
| G-12 | **Copiar a Excel** | LP_FGr2Clip() con formato FlexGrid | Exportación menos amigable (solo CSV) |
| G-23 | **SetUpPrtGrid** | Configura títulos, encabezados, anchos | Impresión sin customización |
| G-21 | **Carga automática** | Form_Load() carga datos automáticamente | Paso extra para usuario |
| G-11 | **Manejo errores Service** | Service sin try/catch | Errores no controlados en backend |
| G-29 | **Mensajes específicos** | MsgBox con descripción detallada | Mensajes genéricos |
| G-09 | **Cálculo tiempo real** | Total calculado al editar | Solo al cargar/guardar |
| G-15 | **Grid avanzado** | FlexGrid con edición inline | Tabla HTML básica |

### 🟢 Gaps Bajos (Funcionalidad auxiliar)

| ID | Gap | Descripción | Impacto |
|:--:|-----|-------------|---------|
| G-30 | **Botón Manual PDF** | Bt_Manual abre Manual_CPT_Simplificado.pdf | Sin ayuda contextual |
| G-31 | **Botón Convertir Moneda** | Bt_ConvMoneda abre FrmConverMoneda | Sin conversor integrado |
| G-32 | **Botón Calculadora** | Bt_Calc llama función Calculadora() | Sin calculadora integrada |
| G-33 | **Botón Calendario** | Bt_Calendar abre FrmCalendar | Sin calendario integrado |

---

## ✅ MEJORAS SOBRE VB6

| # | Mejora | Descripción | Beneficio |
|---|--------|-------------|-----------|
| M-01 | **Arquitectura MVC + API** | Separación Controller → ApiController → Service | Mantenibilidad, escalabilidad, testabilidad |
| M-02 | **Inyección de dependencias** | ICapitalPropioSimplificadoService inyectado | Código más limpio, testeable |
| M-03 | **async/await** | Operaciones asíncronas en Service | Mejor performance, no bloquea UI |
| M-04 | **Entity Framework Core** | LINQ vs queries SQL concatenados | Seguridad (SQL injection), tipado fuerte |
| M-05 | **DTOs tipados** | CapitalPropioSimplificadoDto con propiedades tipadas | Type safety, validación automática |
| M-06 | **TailwindCSS moderno** | UI moderna responsive | Mejor UX, accesible desde cualquier dispositivo |
| M-07 | **SweetAlert profesional** | Modales elegantes vs MsgBox básico | Mejor experiencia de usuario |
| M-08 | **Exportación CSV nativa** | Función JS sin dependencias | No requiere componentes externos |
| M-09 | **CSS @media print** | Impresión personalizada | Funciona en cualquier navegador |
| M-10 | **Estado inicial guiado** | Pantalla de bienvenida explicativa | Mejor onboarding de usuario |
| M-11 | **Loading spinner** | Indicador de carga visual | Usuario sabe que está procesando |
| M-12 | **Iconografía Font Awesome** | Iconos modernos escalables | Profesional, consistente |
| M-13 | **Logging estructurado** | ILogger con contexto | Trazabilidad en producción |
| M-14 | **Enum TipoInformeCPS** | Enum fuertemente tipado | Menos errores, IntelliSense |

---

## 🎯 PLAN DE REMEDIACIÓN

### Fase 1: Funcionalidad Core (Prioridad Crítica - 2-3 semanas)

| # | Tarea | Gaps Resueltos | Esfuerzo |
|---|-------|----------------|:--------:|
| 1 | Implementar modales de detalle (genérico reutilizable) | G-16, G-17, G-26, G-27, G-28 | 8 días |
| 2 | Crear CRUD para DetCapPropioSimpl | G-02 | 2 días |
| 3 | Implementar GetCPSAnual() con CapPropioSimplAnual | G-03, G-04, G-06 | 2 días |
| 4 | Implementar recálculo automático en frontend | G-08, G-09 | 1 día |
| 5 | Leer ProPymeGeneral/ProPymeTransp de BD | G-01, G-24 | 1 día |

### Fase 2: Paridad Completa (Prioridad Alta - 1-2 semanas)

| # | Tarea | Gaps Resueltos | Esfuerzo |
|---|-------|----------------|:--------:|
| 6 | Botón Sumar selección | G-05 | 1 día |
| 7 | Validación numérica en inputs | G-19 | 0.5 días |
| 8 | Control de edición por modo/fila | G-20, G-25 | 1 día |
| 9 | Try/catch en Service | G-11 | 0.5 días |

### Fase 3: Mejoras UX (Prioridad Media - 1 semana)

| # | Tarea | Gaps Resueltos | Esfuerzo |
|---|-------|----------------|:--------:|
| 10 | Vista previa impresión profesional | G-22, G-23 | 2 días |
| 11 | Exportación Excel con formato (EPPlus) | G-12 | 1 día |
| 12 | Carga automática opcional | G-21 | 0.5 días |
| 13 | Mensajes de error específicos | G-29 | 0.5 días |

### Fase 4: Opcionales (Prioridad Baja)

| # | Tarea | Gaps Resueltos | Esfuerzo |
|---|-------|----------------|:--------:|
| 14 | Enlace a manual PDF | G-30 | 0.5 días |
| 15 | Conversor de moneda | G-31 | 1 día |
| 16 | Calculadora integrada | G-32 | 0.5 días |
| 17 | Calendario integrado | G-33 | 0.5 días |

---

## ✅ CONCLUSIÓN

### Veredicto Final

| Aspecto | Evaluación |
|---------|------------|
| **Paridad Funcional** | **71.5%** - Requiere mejoras significativas |
| **Funcionalidad Core** | ❌ **INCOMPLETA** - Falta sistema de detalle modal |
| **Listo para Producción** | ❌ **NO** - Implementar gaps críticos primero |
| **Calidad de Código .NET** | ✅ **BUENA** - Arquitectura sólida, mejorable |
| **Experiencia de Usuario** | ⚠️ **ACEPTABLE** - Falta interactividad de VB6 |

### Riesgo de Migración

🔴 **RIESGO ALTO**

La ausencia de modales de detalle y tablas `DetCapPropioSimpl`/`CapPropioSimplAnual` representa una **pérdida crítica de funcionalidad** respecto a VB6. Los usuarios **no podrán gestionar el detalle de componentes CPS**, lo que afecta directamente la precisión del cálculo tributario.

### Recomendación Final

**❌ NO DEPLOY A PRODUCCIÓN** sin implementar:

1. ✅ Sistema de modales de detalle (G-16, G-17)
2. ✅ Uso de tablas de detalle (G-02, G-03, G-04)
3. ✅ Recálculo automático (G-08)
4. ✅ Lectura de ProPyme desde BD (G-01)

### Esfuerzo Estimado

| Fase | Duración | Paridad Resultante |
|------|:--------:|:------------------:|
| Fase 1 (Core) | 2-3 semanas | ~88% |
| Fase 2 (Paridad) | 1-2 semanas | ~95% |
| Fase 3 (UX) | 1 semana | ~98% |
| **Total mínimo aceptable** | **3-5 semanas** | **≥90%** |

---

**Auditado por:** GitHub Copilot (Claude Opus 4.5)  
**Fecha:** 6 de diciembre de 2025  
**Metodología:** 86 aspectos según `auditoria-gaps.md`  
**Versión del reporte:** 1.0
