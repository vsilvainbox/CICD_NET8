using Microsoft.AspNetCore.Mvc;

namespace App.Features.CapitalPropioSimplificado;

public class CapitalPropioSimplificadoController(
    ILogger<CapitalPropioSimplificadoController> logger) : Controller
{
    public IActionResult Index(TipoInformeCPS tipoInforme = TipoInformeCPS.General)
    {
        logger.LogInformation("Cargando vista Capital Propio Simplificado");

        var viewModel = new CapitalPropioSimplificadoIndexViewModel
        {
            TipoInforme = (int)tipoInforme
        };

        return View(viewModel);
    }
}