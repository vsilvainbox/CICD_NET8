# Feature Refactorizada: CapitalPropioSimplificado

**Fecha:** 2025-12-07
**Guia aplicada:** refactor.md

## Violaciones Detectadas y Corregidas

### R19: JavaScript fetch a API Controller directo (1 violacion)
- **Ubicacion:** CapitalPropioSimplificadoController.cs
- **Problema:** WebController tenia metodos proxy (`Obtener`, `Guardar`) que usaban `ProxyRequestAsync` para hacer proxy al ApiController
- **Solucion:**
  - Eliminados metodos proxy del WebController
  - JavaScript ahora llama directamente al ApiController
  - URLs actualizadas para apuntar a `CapitalPropioSimplificadoApi` en lugar de `CapitalPropioSimplificado`

### R20: Reemplazar fetch/ajax manual por Api.* helpers (2 violaciones)
- **Ubicacion:** Views/Index.cshtml
- **Problemas:**
  1. Linea 201-206: `fetch` manual en funcion `cargarDatos()`
  2. Linea 342-349: `fetch` manual en funcion `guardarDatos()`
- **Solucion:**
  - `cargarDatos()`: Reemplazado `fetch` por `Api.get(URL_ENDPOINTS.obtener, { empresaId, ano, tipoInforme })`
  - `guardarDatos()`: Reemplazado `fetch` por `Api.postJson(URL_ENDPOINTS.guardar, datosActuales)`
  - Eliminado manejo manual de errores (Api.* ya maneja errores con SweetAlert)

## Cambios Adicionales (Mejoras R15)

### Service
- **Archivo:** CapitalPropioSimplificadoService.cs
- **Cambios:**
  - `GuardarCPSAsync` ahora retorna `Task` en lugar de `Task<GuardarCPSResultado>`
  - Lanza `BusinessException` cuando no se encuentra el registro (cumple R15)
  - Eliminada clase `GuardarCPSResultado` (patron Result prohibido)
  - Agregado `using App.Exceptions;`

### ApiController
- **Archivo:** CapitalPropioSimplificadoApiController.cs
- **Cambios:**
  - Endpoint `Guardar` ahora retorna `Ok()` en lugar de `Ok(resultado)`
  - Cumple con R02: No envolver respuestas void en objetos mensaje

### WebController
- **Archivo:** CapitalPropioSimplificadoController.cs
- **Cambios:**
  - Eliminadas dependencias `IHttpClientFactory` y `LinkGenerator` (ya no necesarias)
  - Eliminado `using System.Text.Json;` y `using App.Extensions;`
  - Solo mantiene metodo `Index()` para retornar la vista

## Reglas Verificadas

### Service
- [x] R06 - Reutiliza logica existente
- [x] R14 - Propiedades en PascalCase
- [x] R15 - BusinessException para errores (corregido)
- [x] R17 - Tipos SQL correctos

### ApiController
- [x] R02 - Sin try-catch
- [x] R02 - Retorna Ok()/Ok(data) correctamente
- [x] R15 - No captura excepciones

### WebController
- [x] R02 - Sin try-catch
- [x] R19 - NO tiene metodos proxy (corregido)

### Vista
- [x] R04 - URLs con @Url.Action
- [x] R19 - JS llama a ApiController directo (corregido)
- [x] R20 - Solo Api.* helpers, no fetch manual (corregido)

## Archivos Modificados

1. `CapitalPropioSimplificadoController.cs` - Eliminados metodos proxy
2. `CapitalPropioSimplificadoService.cs` - Cambiado a usar BusinessException
3. `ICapitalPropioSimplificadoService.cs` - Actualizada firma de GuardarCPSAsync
4. `CapitalPropioSimplificadoApiController.cs` - Endpoint Guardar retorna Ok()
5. `Views/Index.cshtml` - Reemplazado fetch por Api.get/Api.postJson, URLs actualizadas

## Verificacion Final

```powershell
# R19: Sin metodos proxy
Select-String -Path "*Controller.cs" -Pattern "ProxyRequestAsync"
# Resultado: 0 coincidencias

# R20: Sin fetch manual
Select-String -Path "Views\*.cshtml" -Pattern "await\s+fetch\(|\.ajax\(|axios\."
# Resultado: 0 coincidencias
```

## Notas

- Todas las URLs JavaScript ahora apuntan correctamente al ApiController (`CapitalPropioSimplificadoApi`)
- El manejo de errores esta centralizado en los Api.* helpers y el middleware global
- La arquitectura ahora sigue el patron correcto: Vista → ApiController → Service
- Se elimino el patron prohibido de proxy MVC (Vista → WebController → ApiController)
