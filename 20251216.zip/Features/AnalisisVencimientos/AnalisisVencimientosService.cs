using App.Data;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;
using OfficeOpenXml.Style;

namespace App.Features.AnalisisVencimientos;

public class AnalisisVencimientosService(LpContabContext context, ILogger<AnalisisVencimientosService> logger) : IAnalisisVencimientosService
{
    public async Task<int?> ResolveEntityIdFromRutAsync(int empresaId, FiltrosVencimientoDto filtros)
    {
        // Si ya tiene IdEntidad, no hacer nada
        if (filtros.IdEntidad.HasValue)
            return filtros.IdEntidad.Value;

        // Si no usa RUT o el RUT está vacío, retornar null
        if (!filtros.UsarRut || string.IsNullOrWhiteSpace(filtros.Rut))
            return null;

        // Buscar entidad por RUT
        var rutLimpio = filtros.Rut.Replace(".", "").Replace("-", "").Trim();
        var entidad = await SearchEntityByRutAsync(empresaId, rutLimpio);

        return entidad?.IdEntidad;
    }

    public async Task<IEnumerable<DocumentoVencimientoDto>> GetDocumentosVencidosAsync(int empresaId, short ano, FiltrosVencimientoDto filtros)
    {
        logger.LogInformation("Getting documentos vencidos for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            // Query base replicando la lógica VB6 con LEFT JOINs
            var query = from d in context.Documento
                where d.IdEmpresa == empresaId 
                      && d.Ano == ano
                      && d.SaldoDoc != null 
                      && d.SaldoDoc != 0
                select d;

            // Filtro por entidad
            if (filtros.IdEntidad.HasValue && filtros.IdEntidad.Value > 0)
            {
                query = query.Where(d => d.IdEntidad == filtros.IdEntidad.Value);
            }

            // Filtro por tipo de libro
            if (filtros.TipoLib.HasValue && filtros.TipoLib.Value > 0)
            {
                query = query.Where(d => d.TipoLib == filtros.TipoLib.Value);
            }

            // Filtro por fecha de vencimiento
            if (filtros.FechaVencimiento.HasValue)
            {
                var fechaInt = ConvertirFechaAInt(filtros.FechaVencimiento.Value);
                query = query.Where(d => d.FVenc.HasValue && d.FVenc.Value > 0 && d.FVenc.Value <= fechaInt);
            }

            // Filtro por cuenta - JOIN con MovDocumento
            if (filtros.IdCuenta.HasValue && filtros.IdCuenta.Value > 0)
            {
                var idCuenta = filtros.IdCuenta.Value;
                query = query.Where(d => context.MovDocumento
                    .Any(m => m.IdDoc == d.IdDoc
                              && m.IdEmpresa == empresaId
                              && m.Ano == ano
                              && m.IdCuenta == idCuenta
                              && (m.EsTotalDoc == true || m.EsTotalDoc == null)));
            }
            else
            {
                // Si no hay filtro por cuenta, aplicar filtro EsTotalDoc globalmente
                query = query.Where(d => context.MovDocumento
                    .Any(m => m.IdDoc == d.IdDoc
                              && m.IdEmpresa == empresaId
                              && m.Ano == ano
                              && (m.EsTotalDoc == true || m.EsTotalDoc == null)));
            }

            // Ejecutar query y hacer LEFT JOIN con Entidades en memoria
            var documentosData = await query
                .OrderBy(d => d.FVenc)
                .ThenBy(d => d.NombreEntidad)
                .ThenBy(d => d.NumDoc)
                .ToListAsync();

            // LEFT JOIN con Entidades
            var entidadesIds = documentosData
                .Where(d => d.IdEntidad.HasValue && d.IdEntidad.Value > 0)
                .Select(d => d.IdEntidad!.Value)
                .Distinct()
                .ToList();

            var entidades = await context.Entidades
                .Where(e => e.IdEmpresa == empresaId && entidadesIds.Contains(e.IdEntidad))
                .ToDictionaryAsync(e => e.IdEntidad, e => e);

            // Convertir a DTOs
            var documentos = documentosData
                .Select(d =>
                {
                    var entidad = d.IdEntidad.HasValue && entidades.ContainsKey(d.IdEntidad.Value)
                        ? entidades[d.IdEntidad.Value]
                        : null;

                    return new DocumentoVencimientoDto
                    {
                        IdDoc = d.IdDoc,
                        TipoLib = d.TipoLib,
                        TipoDoc = d.TipoDoc,
                        NumDoc = d.NumDoc,
                        FEmision = ConvertirIntAFecha(d.FEmision),
                        FVenc = ConvertirIntAFecha(d.FVenc),
                        RutEntidad = entidad?.Rut ?? d.RutEntidad ?? string.Empty,
                        NombreEntidad = entidad?.Nombre ?? d.NombreEntidad ?? string.Empty,
                        NotValidRut = entidad?.NotValidRut ?? false,
                        Total = (decimal?)(d.Total ?? 0),
                        SaldoDoc = (decimal?)(d.SaldoDoc ?? 0),
                        TipoDocDescripcion = ObtenerDiminutivoTipoDoc(d.TipoLib, d.TipoDoc),
                        RutFormateado = FormatearRut(
                            entidad?.Rut ?? d.RutEntidad,
                            filtros.UseCidFormat && (entidad?.NotValidRut != true))
                    };
                })
                .ToList();

            logger.LogInformation("Found {Count} documentos vencidos", documentos.Count);
            return documentos;
        }
    }

    public async Task<IEnumerable<DocumentoVencimientoDto>> GetDocumentosByIdsAsync(int empresaId, short ano, List<int> ids)
    {
        if (ids == null || ids.Count == 0)
        {
            return Enumerable.Empty<DocumentoVencimientoDto>();
        }

        logger.LogInformation("Getting {Count} documentos by IDs for empresaId: {EmpresaId}, ano: {Ano}", ids.Count, empresaId, ano);

        var documentosData = await context.Documento
            .Where(d => d.IdEmpresa == empresaId && d.Ano == ano && ids.Contains(d.IdDoc))
            .ToListAsync();

        // Convertir a DTOs con los campos necesarios para suma
        var documentos = documentosData.Select(d => new DocumentoVencimientoDto
        {
            IdDoc = d.IdDoc,
            Total = (decimal?)(d.Total ?? 0),
            SaldoDoc = (decimal?)(d.SaldoDoc ?? 0)
        }).ToList();

        logger.LogInformation("Found {Count} documentos by IDs", documentos.Count);
        return documentos;
    }

    public async Task<EntidadBusquedaDto?> SearchEntityByRutAsync(int empresaId, string rut)
    {
        logger.LogInformation("Searching entity by RUT: {Rut} for empresaId: {EmpresaId}", rut, empresaId);

        {
            // Formatear RUT para búsqueda (sin puntos ni guión)
            var rutFormateado = rut.Replace(".", "").Replace("-", "").Trim();
                
            var entidad = await context.Entidades
                .Where(e => e.Rut == rutFormateado && e.IdEmpresa == empresaId)
                .Select(e => new EntidadBusquedaDto
                {
                    IdEntidad = e.IdEntidad,
                    Nombre = e.Nombre ?? string.Empty,
                    Rut = e.Rut,
                    NotValidRut = e.NotValidRut,
                    Clasif0 = e.Clasif0,
                    Clasif1 = e.Clasif1,
                    Clasif2 = e.Clasif2,
                    Clasif3 = e.Clasif3,
                    Clasif4 = e.Clasif4,
                    Clasif5 = e.Clasif5
                })
                .FirstOrDefaultAsync();

            if (entidad != null)
            {
                logger.LogInformation("Entity found: IdEntidad {IdEntidad}", entidad.IdEntidad);
            }
            else
            {
                logger.LogWarning("Entity not found for RUT: {Rut}", rut);
            }

            return entidad;
        }
    }

    public async Task<IEnumerable<EntidadComboDto>> GetEntitiesByClassificationAsync(int empresaId, int clasificacion)
    {
        logger.LogInformation("Getting entities by classification: {Clasificacion} for empresaId: {EmpresaId}", clasificacion, empresaId);

        {
            var query = context.Entidades.Where(e => e.IdEmpresa == empresaId);

            // Filtro dinámico por clasificación (Clasif0 a Clasif5)
            // Nota: VB6 usaba -1 como TRUE, pero en SQL Server tinyint almacena 1
            switch (clasificacion)
            {
                case 0: query = query.Where(e => e.Clasif0 == 1); break;
                case 1: query = query.Where(e => e.Clasif1 == 1); break;
                case 2: query = query.Where(e => e.Clasif2 == 1); break;
                case 3: query = query.Where(e => e.Clasif3 == 1); break;
                case 4: query = query.Where(e => e.Clasif4 == 1); break;
                case 5: query = query.Where(e => e.Clasif5 == 1); break;
                default:
                    logger.LogWarning("Invalid clasificacion: {Clasificacion}", clasificacion);
                    return Enumerable.Empty<EntidadComboDto>();
            }

            var entidades = await query
                .OrderBy(e => e.Nombre)
                .Select(e => new EntidadComboDto
                {
                    IdEntidad = e.IdEntidad,
                    Nombre = e.Nombre ?? string.Empty,
                    Rut = e.Rut,
                    NotValidRut = e.NotValidRut ?? false,
                    RutFormateado = FormatearRut(e.Rut, e.NotValidRut != true)
                })
                .ToListAsync();

            logger.LogInformation("Found {Count} entities for clasificacion: {Clasificacion}", entidades.Count, clasificacion);
            return entidades;
        }
    }

    public async Task<IEnumerable<CuentaComboDto>> GetCuentasActivasAsync(int empresaId, short ano)
    {
        logger.LogInformation("Getting cuentas activas for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            // CRÍTICO: Cuentas usa idCuenta en camelCase (no IdCuenta)
            var cuentas = await context.Cuentas
                .Where(c => c.IdEmpresa == empresaId && c.Ano == ano && c.Estado == 1)
                .OrderBy(c => c.Codigo)
                .Select(c => new CuentaComboDto
                {
                    IdCuenta = c.idCuenta,  // ⚠️ IMPORTANTE: camelCase
                    Codigo = c.Codigo ?? string.Empty,
                    Nombre = c.Nombre ?? string.Empty
                })
                .ToListAsync();

            logger.LogInformation("Found {Count} cuentas activas", cuentas.Count);
            return cuentas;
        }
    }

    public async Task<IEnumerable<TipoLibroDto>> GetTiposLibroAsync()
    {
        logger.LogInformation("Getting tipos de libro");

        // Tipos de libro hardcodeados según constantes VB6
        var tipos = new List<TipoLibroDto>
        {
            new TipoLibroDto { Codigo = 1, Descripcion = "Compras" },      // LIB_COMPRAS
            new TipoLibroDto { Codigo = 2, Descripcion = "Ventas" },       // LIB_VENTAS
            new TipoLibroDto { Codigo = 3, Descripcion = "Retenciones" },  // LIB_RETEN
            new TipoLibroDto { Codigo = 4, Descripcion = "Otros" }         // LIB_OTROS
        };

        return await Task.FromResult(tipos);
    }

    public async Task<IEnumerable<ClasificacionEntidadDto>> GetClasificacionesEntidadAsync()
    {
        logger.LogInformation("Getting clasificaciones de entidad");

        // Clasificaciones hardcodeadas según constantes VB6
        var clasificaciones = new List<ClasificacionEntidadDto>
        {
            new ClasificacionEntidadDto { Codigo = -1, Descripcion = "(Todas)" },
            new ClasificacionEntidadDto { Codigo = 0, Descripcion = "Cliente" },    // ENT_CLIENTE
            new ClasificacionEntidadDto { Codigo = 1, Descripcion = "Proveedor" },  // ENT_PROVEEDOR
            new ClasificacionEntidadDto { Codigo = 2, Descripcion = "Empleado" },   // ENT_EMPLEADO
            new ClasificacionEntidadDto { Codigo = 3, Descripcion = "Socio" },      // ENT_SOCIO
            new ClasificacionEntidadDto { Codigo = 4, Descripcion = "Otro" }        // ENT_OTRO
        };

        return await Task.FromResult(clasificaciones);
    }

    public async Task<bool> ValidateRutFormatAsync(string rut, bool useCidFormat)
    {
        logger.LogInformation("Validating RUT format: {Rut}, useCidFormat: {UseCidFormat}", rut, useCidFormat);

        if (string.IsNullOrWhiteSpace(rut))
            return false;

        if (!useCidFormat)
            return true; // Texto libre, no validar formato

        // Validación básica de formato RUT chileno (XX.XXX.XXX-X o XXXXXXXX-X)
        var rutLimpio = rut.Replace(".", "").Replace("-", "").Trim();
        if (rutLimpio.Length < 2)
            return false;

        // Extraer dígito verificador
        var dv = rutLimpio[rutLimpio.Length - 1];
        var rutNumero = rutLimpio.Substring(0, rutLimpio.Length - 1);

        if (!int.TryParse(rutNumero, out _))
            return false;

        // Calcular dígito verificador esperado
        var dvCalculado = CalcularDigitoVerificador(rutNumero);

        return await Task.FromResult(dv.ToString().ToUpper() == dvCalculado.ToUpper());
    }

    public async Task<bool> CheckEntityExistsAsync(int empresaId, string rut)
    {
        logger.LogInformation("Checking if entity exists: RUT {Rut} for empresaId: {EmpresaId}", rut, empresaId);

        {
            // Formatear RUT para búsqueda (sin puntos ni guión)
            var rutFormateado = rut.Replace(".", "").Replace("-", "").Trim();
                
            var existe = await context.Entidades
                .AnyAsync(e => e.Rut == rutFormateado && e.IdEmpresa == empresaId);

            logger.LogInformation("Entity {Status} for RUT: {Rut}", existe ? "exists" : "does not exist", rut);
            return existe;
        }
    }

    public async Task<TotalesVencimientoDto> CalculateTotalsAsync(IEnumerable<DocumentoVencimientoDto> documentos)
    {
        logger.LogInformation("Calculating totals for {Count} documentos", documentos.Count());

        var totales = new TotalesVencimientoDto
        {
            TotalGeneral = documentos.Sum(d => d.Total ?? 0),
            SaldoTotal = documentos.Sum(d => d.SaldoDoc ?? 0),
            CantidadDocumentos = documentos.Count()
        };

        logger.LogInformation("Totals calculated: TotalGeneral {Total}, SaldoTotal {Saldo}", totales.TotalGeneral, totales.SaldoTotal);

        return await Task.FromResult(totales);
    }

    public async Task<Dictionary<string, decimal>> SumSelectedColumnsAsync(IEnumerable<DocumentoVencimientoDto> documentos, string[] columnas)
    {
        logger.LogInformation("Summing selected columns: {Columnas} for {Count} documentos", string.Join(", ", columnas), documentos.Count());

        var sumas = new Dictionary<string, decimal>();

        foreach (var columna in columnas)
        {
            switch (columna.ToLower())
            {
                case "total":
                    sumas[columna] = documentos.Sum(d => d.Total ?? 0);
                    break;
                case "saldo":
                case "saldodoc":
                    sumas[columna] = documentos.Sum(d => d.SaldoDoc ?? 0);
                    break;
                default:
                    logger.LogWarning("Unknown column: {Columna}", columna);
                    break;
            }
        }

        return await Task.FromResult(sumas);
    }

    public async Task<(byte[] excelBytes, string fileName)> ExportToExcelAsync(int empresaId, short ano, FiltrosVencimientoDto filtros)
    {
        logger.LogInformation("Exporting to Excel for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        var documentos = await GetDocumentosVencidosAsync(empresaId, ano, filtros);
        var totales = await CalculateTotalsAsync(documentos);

        ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
        using var package = new ExcelPackage();
        var worksheet = package.Workbook.Worksheets.Add("Análisis de Vencimientos");

        // Encabezados
        worksheet.Cells[1, 1].Value = "Fecha Vencimiento";
        worksheet.Cells[1, 2].Value = "Fecha Emisión";
        worksheet.Cells[1, 3].Value = "Documento";
        worksheet.Cells[1, 4].Value = "RUT";
        worksheet.Cells[1, 5].Value = "Nombre Entidad";
        worksheet.Cells[1, 6].Value = "Total";
        worksheet.Cells[1, 7].Value = "Saldo";

        // Estilo encabezados
        using (var range = worksheet.Cells[1, 1, 1, 7])
        {
            range.Style.Font.Bold = true;
            range.Style.Fill.PatternType = ExcelFillStyle.Solid;
            range.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightGray);
        }

        // Datos
        var row = 2;
        foreach (var doc in documentos)
        {
            worksheet.Cells[row, 1].Value = doc.FVencFormateada;
            worksheet.Cells[row, 2].Value = doc.FEmisionFormateada;
            worksheet.Cells[row, 3].Value = $"{doc.TipoDocDescripcion} {doc.NumDoc}";
            worksheet.Cells[row, 4].Value = doc.RutFormateado;
            worksheet.Cells[row, 5].Value = doc.NombreEntidad;
            worksheet.Cells[row, 6].Value = doc.Total;
            worksheet.Cells[row, 7].Value = doc.SaldoDoc;
            row++;
        }

        // Totales
        worksheet.Cells[row, 5].Value = "TOTAL";
        worksheet.Cells[row, 6].Value = totales.TotalGeneral;
        worksheet.Cells[row, 7].Value = totales.SaldoTotal;
        worksheet.Cells[row, 5, row, 7].Style.Font.Bold = true;

        // Formato de números
        worksheet.Cells[2, 6, row, 7].Style.Numberformat.Format = "#,##0";

        // Ajustar anchos
        worksheet.Column(1).Width = 15;
        worksheet.Column(2).Width = 15;
        worksheet.Column(3).Width = 20;
        worksheet.Column(4).Width = 15;
        worksheet.Column(5).Width = 40;
        worksheet.Column(6).Width = 15;
        worksheet.Column(7).Width = 15;

        var fileName = $"AnalisisVencimientos_{DateTime.Now:yyyyMMdd}.xlsx";
        logger.LogInformation("Excel exported successfully with {Count} rows, fileName: {FileName}", documentos.Count(), fileName);

        return await Task.FromResult((package.GetAsByteArray(), fileName));
    }

    public async Task<(byte[] pdfBytes, string fileName)> GeneratePdfAsync(int empresaId, short ano, FiltrosVencimientoDto filtros, bool preview = true)
    {
        logger.LogInformation("Generating PDF for empresaId: {EmpresaId}, ano: {Ano}, preview: {Preview}", empresaId, ano, preview);

        // TODO: [FEATURE] [MEDIUM] Implementar generación de PDF con iTextSharp o similar
        // Por ahora, retornar array vacío
        logger.LogWarning("PDF generation not implemented yet");

        var fileName = $"AnalisisVencimientos_{DateTime.Now:yyyyMMdd}.pdf";
        return await Task.FromResult((Array.Empty<byte>(), fileName));
    }

    public async Task RecalcularSaldosAsync(int empresaId, short ano)
    {
        logger.LogInformation("Recalculating saldos for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        // NOTA: VB6 llama a RecalcSaldos() y RecalcSaldosFulle() al cargar el formulario.
        // Estas funciones son procedimientos globales complejos que recalculan:
        // - SaldoDoc en tabla Documento
        // - Saldos por pagos parciales
        // - Ajustes de movimientos
        // 
        // Implementación futura requiere:
        // 1. Analizar RecalcSaldos() en HyperCont.bas línea 5400
        // 2. Analizar RecalcSaldosFulle() en HyperCont.bas línea 5891
        // 3. Migrar lógica de recálculo de saldos documentales
        // 
        // Por ahora, asumimos que los saldos en BD están correctamente calculados
        // por otros procesos del sistema (centralizaciones, pagos, etc.)
            
        logger.LogWarning("Saldo recalculation not implemented - assuming DB saldos are correct");

        await Task.CompletedTask;
    }

    #region Métodos Auxiliares

    private static DateTime? ConvertirIntAFecha(int? fechaInt)
    {
        if (!fechaInt.HasValue || fechaInt.Value == 0)
            return null;

        // Formato OLE/Excel: Convertir usando FromOADate
        return DateTime.FromOADate(fechaInt.Value);
    }

    private static int ConvertirFechaAInt(DateTime fecha)
    {
        // Formato OLE/Excel: Convertir usando ToOADate
        return (int)fecha.ToOADate();
    }

    private static string ObtenerDiminutivoTipoDoc(int? tipoLib, int? tipoDoc)
    {
        // Mapeo de diminutivos según constantes VB6 (gTipoDoc)
        // LIB_COMPRAS = 1, LIB_VENTAS = 2, LIB_RETEN = 3, LIB_OTROS = 4
            
        if (!tipoLib.HasValue || !tipoDoc.HasValue)
            return "Doc";

        // Libro de Compras (LIB_COMPRAS = 1)
        if (tipoLib.Value == 1)
        {
            return tipoDoc.Value switch
            {
                1 => "FEC",     // Factura Exenta Compra
                2 => "FAC",     // Factura Afecta Compra
                3 => "FCC",     // Factura Compra
                4 => "NCC",     // Nota de Crédito Compra
                5 => "NDC",     // Nota de Débito Compra
                6 => "BOL",     // Boleta Compra
                7 => "FEE",     // Factura Electrónica Exenta
                8 => "FEA",     // Factura Electrónica Afecta
                _ => $"DOC{tipoDoc.Value}"
            };
        }
            
        // Libro de Ventas (LIB_VENTAS = 2)
        if (tipoLib.Value == 2)
        {
            return tipoDoc.Value switch
            {
                1 => "FEV",     // Factura Exenta Venta
                2 => "FAV",     // Factura Afecta Venta
                3 => "FV",      // Factura Venta
                4 => "NCV",     // Nota de Crédito Venta
                5 => "NDV",     // Nota de Débito Venta
                6 => "BOL",     // Boleta Venta
                7 => "BHE",     // Boleta Honorarios Electrónica
                _ => $"DOC{tipoDoc.Value}"
            };
        }
            
        // Libro de Retenciones (LIB_RETEN = 3)
        if (tipoLib.Value == 3)
        {
            return tipoDoc.Value switch
            {
                1 => "BH",      // Boleta de Honorarios
                2 => "FH",      // Factura Honorarios
                _ => $"DOC{tipoDoc.Value}"
            };
        }
            
        // Libro de Otros (LIB_OTROS = 4)
        if (tipoLib.Value == 4)
        {
            return tipoDoc.Value switch
            {
                1 => "ODF",     // Otro Documento Full
                2 => "OD",      // Otro Documento
                _ => $"DOC{tipoDoc.Value}"
            };
        }

        return $"Doc {tipoLib.Value}-{tipoDoc.Value}";
    }

    private static string FormatearRut(string? rut, bool useCidFormat)
    {
        if (string.IsNullOrWhiteSpace(rut))
            return string.Empty;

        if (!useCidFormat)
            return rut;

        // Formato CID: XX.XXX.XXX-X
        var rutLimpio = rut.Replace(".", "").Replace("-", "").Trim();
        if (rutLimpio.Length < 2)
            return rut;

        var dv = rutLimpio[rutLimpio.Length - 1];
        var rutNumero = rutLimpio.Substring(0, rutLimpio.Length - 1);

        // Formatear con puntos
        var rutFormateado = string.Empty;
        var contador = 0;
        for (var i = rutNumero.Length - 1; i >= 0; i--)
        {
            if (contador == 3)
            {
                rutFormateado = "." + rutFormateado;
                contador = 0;
            }
            rutFormateado = rutNumero[i] + rutFormateado;
            contador++;
        }

        return $"{rutFormateado}-{dv}";
    }

    private string CalcularDigitoVerificador(string rutNumero)
    {
        var suma = 0;
        var multiplicador = 2;

        for (var i = rutNumero.Length - 1; i >= 0; i--)
        {
            suma += int.Parse(rutNumero[i].ToString()) * multiplicador;
            multiplicador = multiplicador == 7 ? 2 : multiplicador + 1;
        }

        var resto = suma % 11;
        var dv = 11 - resto;

        if (dv == 11)
            return "0";
        else if (dv == 10)
            return "K";
        else
            return dv.ToString();
    }

    #endregion
}