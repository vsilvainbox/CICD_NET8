using Microsoft.AspNetCore.Mvc;

namespace App.Features.AjustesExtraContablesCaja;

[ApiController]
[Route("[controller]/[action]")]
public class AjustesExtraContablesCajaApiController(
    IAjustesExtraContablesCajaService service,
    ILogger<AjustesExtraContablesCajaApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<AjustesExtraContablesCajaDto>> Calcular(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        logger.LogInformation("API: Calcular ajustes called");

        {
            var data = await service.CalcularAjustesAsync(empresaId, ano);
            return Ok(data);
        }
    }

    [HttpPost]
    public async Task<ActionResult<GuardarAjustesResponseDto>> Guardar([FromBody] SaveAjustesDto dto)
    {
        logger.LogInformation("API: Guardar ajustes called");

        {
            var result = await service.GuardarAjustesAsync(dto);
            return Ok(result);
        }
    }
}

