﻿namespace App.Features.AjustesExtraContablesCaja;

public interface IAjustesExtraContablesCajaService
{
    Task<AjustesExtraContablesCajaDto> CalcularAjustesAsync(int empresaId, short ano);
    Task<GuardarAjustesResponseDto> GuardarAjustesAsync(SaveAjustesDto dto);
}
