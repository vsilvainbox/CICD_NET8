# 📊 Reporte de Gaps: AjustesExtraContablesCaja
## Comparación VB6 → .NET 9

**Fecha de análisis:** 2025-12-06  
**Feature:** Ajuste Extra Libro de Caja (Art. 14 ter)  
**Formulario VB6:** `FrmAjustesExtraLibCaja.frm`  
**Feature .NET:** `Features\AjustesExtraContablesCaja\`  
**Importancia:** 🟠 ALTA

---

## 📋 Resumen Ejecutivo

### Métricas de Paridad

| Métrica | Resultado |
|---------|-----------|
| **Paridad Global** | **62.8%** |
| Aspectos Completos (✅) | 54 / 86 |
| Gaps Críticos (🔴) | 8 |
| Gaps Altos (🟠) | 12 |
| Gaps Medios (🟡) | 10 |
| Gaps Bajos (⚪) | 2 |
| Mejoras sobre VB6 (⭐) | 5 |

### Veredicto

🔴 **NO LISTO PARA PRODUCCIÓN** - Requiere completar funcionalidades críticas antes del despliegue.

La implementación .NET tiene la **estructura base** pero carece de la **lógica de negocio completa** que existe en VB6. Se identificaron gaps críticos en:
- Cálculo de ajustes automáticos (33 Bis, empresas relacionadas, ingresos no percibidos)
- Guardado de datos en base de datos
- Detalle de documentos relacionados
- Herramientas auxiliares (calculadora, calendario, conversión de moneda)
- Vista previa e impresión avanzada

---

## 📊 Resumen por Categoría

| Categoría | Total | ✅ OK | 🔴 Crítico | 🟠 Alto | 🟡 Medio | ⚪ Bajo |
|-----------|-------|-------|------------|---------|----------|--------|
| 1️⃣ Inputs/Dependencias | 6 | 5 | 1 | 0 | 0 | 0 |
| 2️⃣ Datos/Persistencia | 10 | 4 | 4 | 2 | 0 | 0 |
| 3️⃣ Acciones/Operaciones | 6 | 3 | 1 | 2 | 0 | 0 |
| 4️⃣ Validaciones | 6 | 4 | 0 | 0 | 0 | 2 |
| 5️⃣ Cálculos/Lógica | 5 | 1 | 1 | 3 | 0 | 0 |
| 6️⃣ Interfaz/UX | 5 | 5 | 0 | 0 | 0 | 0 |
| 7️⃣ Seguridad | 2 | 1 | 0 | 0 | 1 | 0 |
| 8️⃣ Manejo de errores | 2 | 2 | 0 | 0 | 0 | 0 |
| 9️⃣ Outputs/Salidas | 6 | 4 | 1 | 1 | 0 | 0 |
| 🔟 Controles UI | 6 | 6 | 0 | 0 | 0 | 0 |
| 1️⃣1️⃣ Grids/Columnas | 2 | 2 | 0 | 0 | 0 | 0 |
| 1️⃣2️⃣ Eventos/Interacción | 5 | 3 | 1 | 1 | 0 | 0 |
| 1️⃣3️⃣ Estados/Modos | 3 | 3 | 0 | 0 | 0 | 0 |
| 1️⃣4️⃣ Inicialización | 3 | 2 | 1 | 0 | 0 | 0 |
| 1️⃣5️⃣ Filtros/Búsqueda | 2 | 2 | 0 | 0 | 0 | 0 |
| 1️⃣6️⃣ Reportes/Impresión | 2 | 0 | 0 | 2 | 0 | 0 |
| 1️⃣7️⃣ Reglas de Negocio | 4 | 1 | 2 | 1 | 0 | 0 |
| 1️⃣8️⃣ Flujos de Trabajo | 3 | 3 | 0 | 0 | 0 | 0 |
| 1️⃣9️⃣ Integraciones | 3 | 1 | 2 | 0 | 0 | 0 |
| 2️⃣0️⃣ Mensajes Usuario | 2 | 2 | 0 | 0 | 0 | 0 |
| 2️⃣1️⃣ Casos Borde | 3 | 3 | 0 | 0 | 0 | 0 |
| **TOTAL** | **86** | **54** | **8** | **12** | **10** | **2** |

---

## 1️⃣ INPUTS / DEPENDENCIAS DE ENTRADA (6 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 1 | **Variables globales** | `gEmpresa.id`, `gEmpresa.Ano`, `gDbMain`, `gAjustesExtraCont()` | `SessionHelper.EmpresaId`, `SessionHelper.Ano`, `LpContabContext` | ✅ |
| 2 | **Parámetros de entrada** | `FEdit()` - Modal sin parámetros | `Index()` - GET, usa sesión | ✅ |
| 3 | **Configuraciones** | Array global `gAjustesExtraCont(TipoAjuste, IdItem)` con nombres y tipos de ingreso | ❌ No se carga configuración de items | 🔴 |
| 4 | **Estado previo requerido** | Valida `gEmpresa.Id > 0` implícitamente | Valida `SessionHelper.EmpresaId > 0` (línea 16 Controller) | ✅ |
| 5 | **Datos maestros necesarios** | `AjustesExtLibCaja`, `LibroCaja`, `Documento`, `DocCuotas`, `Entidades`, `IPC` | Mismas tablas disponibles en `LpContabContext` | ✅ |
| 6 | **Conexión/Sesión** | `DbMain` (ADO Connection global) | `LpContabContext` (DI de EF Core) | ✅ |

**Resumen Sección:** ✅ 5/6 | 🔴 1 gap crítico

**Gap Crítico #3:** La configuración de items de ajuste (`gAjustesExtraCont`) que define nombres, tipos de ingreso y IDs de cuentas asociadas no se carga en .NET. El Service no tiene acceso a esta información vital para mostrar los conceptos correctos.

---

## 2️⃣ DATOS Y PERSISTENCIA (10 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 7 | **Queries SELECT** | 6 queries complejas: `CalcSaldosIngEgr`, `GetStoredVal`, `GetIngNoPercibRel`, `GetIngNoPercib12MesesEmiNoRel`, `GetIngNoPercib12MesesExigNoRel`, `GetIngEgrDevengados` | ❌ Solo consulta básica de LibroCaja (Service línea 50) | 🔴 |
| 8 | **Queries INSERT** | `INSERT INTO AjustesExtLibCaja` (SaveAll línea 783) | ❌ No implementado (TODO Service línea 21) | 🔴 |
| 9 | **Queries UPDATE** | `UPDATE AjustesExtLibCaja SET Valor` (SaveAll línea 769) | ❌ No implementado (TODO Service línea 21) | 🔴 |
| 10 | **Queries DELETE** | No hay eliminaciones | N/A | ✅ |
| 11 | **Stored Procedures** | No se usan | N/A | ✅ |
| 12 | **Tablas accedidas** | `LibroCaja`, `TipoDocs`, `Documento`, `Entidades`, `DocCuotas`, `AjustesExtLibCaja` | Solo `LibroCaja`, `EmpresasAno`, `DocCuotas`, `IPC` | 🟠 |
| 13 | **Campos leídos** | `Pagado`, `SaldoDoc`, `NumCuotas`, `EntRelacionada`, `FEmisionOri`, `FechaIngPercibido`, `OperDevengada` | Campos básicos de `LibroCaja` | 🟠 |
| 14 | **Campos escritos** | `AjustesExtLibCaja.Valor` | ❌ No se escribe | 🔴 |
| 15 | **Transacciones** | No usa transacciones explícitas | No usa transacciones | ✅ |
| 16 | **Concurrencia** | Sin manejo | Sin manejo | ✅ |

**Resumen Sección:** ✅ 4/10 | 🔴 4 gaps críticos | 🟠 2 gaps altos

### Queries VB6 no implementadas en .NET:

**1. CalcSaldosIngEgr (Cálculo de Saldos Ingresos/Egresos):**
```sql
-- INGRESOS
SELECT Sum(Pagado) as TotIngreso
FROM LibroCaja 
INNER JOIN TipoDocs ON LibroCaja.TipoLib = TipoDocs.TipoLib AND LibroCaja.TipoDoc = TipoDocs.TipoDoc
WHERE FechaIngresoLibro BETWEEN [01-01-Ano] AND [31-12-Ano]
  AND LibroCaja.TipoOper = 1  -- TOPERCAJA_INGRESO
  AND LibroCaja.IdEmpresa = [EmpresaId] AND LibroCaja.Ano = [Ano]

-- EGRESOS
SELECT Sum(Pagado) as TotEgreso
FROM LibroCaja 
INNER JOIN TipoDocs ON LibroCaja.TipoLib = TipoDocs.TipoLib AND LibroCaja.TipoDoc = TipoDocs.TipoDoc
WHERE FechaIngresoLibro BETWEEN [01-01-Ano] AND [31-12-Ano]
  AND LibroCaja.TipoOper = 2  -- TOPERCAJA_EGRESO
  AND LibroCaja.IdEmpresa = [EmpresaId] AND LibroCaja.Ano = [Ano]
```

**2. GetIngNoPercibRel (Item K - Empresas Relacionadas):**
```sql
SELECT Sum(SaldoDoc) as Saldo
FROM Documento INNER JOIN Entidades ON Documento.IdEntidad = Entidades.IdEntidad 
  AND Documento.IdEmpresa = Entidades.IdEmpresa
WHERE TipoLib = 2  -- LIB_VENTAS
  AND FEmision BETWEEN [01-01-Ano] AND [31-12-Ano]
  AND NOT Entidades.EntRelacionada IS NULL AND Entidades.EntRelacionada <> 0
  AND Documento.IdEmpresa = [EmpresaId] AND Documento.Ano = [Ano]
```

**3. GetIngNoPercib12MesesEmiNoRel (Item L - >12 meses desde emisión):**
```sql
SELECT Sum(SaldoDoc) as Saldo
FROM Documento LEFT JOIN Entidades ON Documento.IdEntidad = Entidades.IdEntidad
WHERE TipoLib = 2  -- LIB_VENTAS
  AND (NumCuotas IS NULL OR NumCuotas = 0)  -- Al contado
  AND (Entidades.EntRelacionada IS NULL OR Entidades.EntRelacionada = 0)  -- No relacionada
  AND DateDiff(month, FEmisionOri, [31-12-Ano]) > 12
  AND Documento.IdEmpresa = [EmpresaId] AND Documento.Ano = [Ano]
```

**4. GetIngNoPercib12MesesExigNoRel (Item M - >12 meses desde exigibilidad):**
```sql
SELECT Sum(MontoCuota) as Saldo
FROM Documento 
INNER JOIN DocCuotas ON Documento.IdDoc = DocCuotas.IdDoc
LEFT JOIN Entidades ON Documento.IdEntidad = Entidades.IdEntidad
WHERE TipoLib = 2  -- LIB_VENTAS
  AND (Entidades.EntRelacionada IS NULL OR Entidades.EntRelacionada = 0)
  AND (FechaIngPercibido IS NULL OR FechaIngPercibido = 0)  -- No pagado
  AND DateDiff(month, FEmisionOri, [31-12-Ano]) > 12
  AND Documento.IdEmpresa = [EmpresaId] AND Documento.Ano = [Ano]
```

**5. GetIngEgrDevengados (Items Ñ y W - Operaciones devengadas):**
```sql
SELECT Sum(Pagado) as Saldo
FROM LibroCaja
WHERE TipoOper = [TipoOper]  -- 1=Ingreso, 2=Egreso
  AND NOT OperDevengada IS NULL AND OperDevengada <> 0
  AND FechaIngresoLibro BETWEEN [01-01-Ano] AND [31-12-Ano]
  AND IdEmpresa = [EmpresaId] AND Ano = [Ano]
```

---

## 3️⃣ ACCIONES Y OPERACIONES (6 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 17 | **Botones/Acciones** | 10 botones: `Bt_OK`, `Bt_Cancelar`, `Bt_Print`, `Bt_Preview`, `Bt_CopyExcel`, `Bt_DetDoc`, `Bt_Calendar`, `Bt_Calc`, `Bt_ConvMoneda`, `Bt_Sum` | 3 botones: Aceptar, Imprimir (`window.print`), Excel | 🟠 |
| 18 | **Operaciones CRUD** | Read (`LoadAll`), Update/Insert (`SaveAll`) | Read (`CalcularAjustesAsync`), Update (stub) | 🟠 |
| 19 | **Operaciones especiales** | Detalle doc (`FrmLibCaja.FView`, `FrmRepActivoFijo.FView`), Calculadora, Calendario, Conversión moneda, Suma celdas | ❌ Ninguna implementada | 🔴 |
| 20 | **Búsquedas** | No hay filtros de búsqueda | No hay filtros | ✅ |
| 21 | **Ordenamiento** | Grid ordenado por posición fija (Agregados, Deducciones) | Mismo orden lógico | ✅ |
| 22 | **Paginación** | No aplica (grid único) | No aplica | ✅ |

**Resumen Sección:** ✅ 3/6 | 🔴 1 gap crítico | 🟠 2 gaps altos

### Botones VB6 faltantes en .NET:

| Botón VB6 | Funcionalidad | Estado .NET |
|-----------|---------------|:-----------:|
| `Bt_OK` | Guardar ajustes y cerrar | ✅ Parcial (sin cerrar) |
| `Bt_Cancelar` | Cancelar sin guardar | ❌ |
| `Bt_Print` | Imprimir con configuración | ❌ |
| `Bt_Preview` | Vista previa de impresión | ❌ |
| `Bt_CopyExcel` | Copiar a Excel | ✅ Mejorado |
| `Bt_DetDoc` | Ver detalle del documento | ❌ |
| `Bt_Calendar` | Abrir calendario | ❌ |
| `Bt_Calc` | Calculadora | ❌ |
| `Bt_ConvMoneda` | Convertir moneda | ❌ |
| `Bt_Sum` | Sumar celdas seleccionadas | ❌ |

---

## 4️⃣ VALIDACIONES (6 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 23 | **Campos requeridos** | `valida()` retorna siempre `True` (línea 796) - Sin validaciones | ❌ No hay validaciones | ⚪ |
| 24 | **Validación de rangos** | No hay validaciones de rango explícitas | No hay | ⚪ |
| 25 | **Validación de formato** | No hay | No hay | ✅ |
| 26 | **Validación de longitud** | No hay | No hay | ✅ |
| 27 | **Validaciones custom** | No hay (función `valida()` vacía) | No hay | ✅ |
| 28 | **Manejo de nulos** | `vFld()` para campos de DB, `vFmt()` para valores numéricos | `?? 0`, `HasValue` en nullable | ✅ |

**Resumen Sección:** ✅ 4/6 | ⚪ 2 gaps bajos

> **Nota:** Ambos sistemas carecen de validaciones porque la función `valida()` en VB6 está vacía. Esto es una paridad intencional.

---

## 5️⃣ CÁLCULOS Y LÓGICA (5 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 29 | **Funciones de cálculo** | `CalcSaldosIngEgr()`, `CalcTot()`, `GetVal33Bis()`, 5 funciones Get* para ajustes específicos | ❌ Stub de `CalcularAjustesDocumentoAsync` con TODOs | 🔴 |
| 30 | **Redondeos** | `Format(valor, NUMFMT)` para gastos presuntos (línea 722) | ❌ No implementado | 🟠 |
| 31 | **Campos calculados** | Gastos Presuntos (0.5% con tope UTM), Subtotales, Base Imponible | Subtotales básicos, sin gastos presuntos | 🟠 |
| 32 | **Dependencias campos** | `Grid_AcceptValue` recalcula todo con `CalcTot()` (línea 969) | `actualizarValor()` recalcula totales (Index.cshtml línea 195) | ✅ |
| 33 | **Valores por defecto** | Valores leídos de DB o calculados automáticamente (LoadAll) | ❌ Retorna valores vacíos/cero | 🟠 |

**Resumen Sección:** ✅ 1/5 | 🔴 1 gap crítico | 🟠 3 gaps altos

### Fórmulas VB6 no implementadas:

**Gastos Presuntos (Item R):**
```vb
Base = SaldoCajaIngresos + IngNoPercib12MesesEmi + IngNoPercib12MesesExig
Tot = Base * 0.005    ' 0.5%

' Topar en UTM
If lValUTM > 0 Then
  MaxR = 15 * lValUTM  ' Máximo 15 UTM
  MinR = lValUTM       ' Mínimo 1 UTM
  
  If Tot > MaxR Then Tot = MaxR
  ElseIf Tot < MinR Then Tot = MinR
End If
```

**Base Imponible:**
```vb
BaseImponible = SaldoFinalCaja + TotalAgregados - TotalDeducciones
```

---

## 6️⃣ INTERFAZ Y UX (5 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 34 | **Combos/Listas** | No hay combos | No hay combos | ✅ |
| 35 | **Mensajes usuario** | `MsgBox` para errores (no hay en este form) | `Swal.fire()` para éxito/error | ✅ |
| 36 | **Confirmaciones** | No hay confirmaciones explícitas | No hay | ✅ |
| 37 | **Habilitaciones UI** | Solo celdas con `TipoIngreso = TIA_INGDIRECTO` editables | Atributo `editable` controla inputs | ✅ |
| 38 | **Formatos display** | `Format(valor, NEGNUMFMT)` - negativos entre paréntesis | `formatNumber()` - negativos entre paréntesis | ✅ |

**Resumen Sección:** ✅ 5/5 | Excelente paridad en UX básica

---

## 7️⃣ SEGURIDAD (2 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 39 | **Permisos requeridos** | No hay validación de permisos en el form | ❌ No hay `[Authorize]` o validación de permisos | 🟡 |
| 40 | **Validación acceso** | Solo valida que empresa esté seleccionada | Valida empresa seleccionada (Controller línea 16) | ✅ |

**Resumen Sección:** ✅ 1/2 | 🟡 1 gap medio

---

## 8️⃣ MANEJO DE ERRORES (2 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 41 | **Captura errores** | Sin `On Error GoTo` en este form | `try/catch` en frontend JS (Index.cshtml líneas 81, 256) | ✅ |
| 42 | **Mensajes de error** | Sin manejo explícito | `Swal.fire()` con mensajes descriptivos | ✅ |

**Resumen Sección:** ✅ 2/2 | .NET tiene mejor manejo de errores

---

## 9️⃣ OUTPUTS / SALIDAS (6 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 43 | **Datos de retorno** | `Unload Me` después de guardar - no retorna datos | `Swal.fire()` con mensaje después de guardar | ✅ |
| 44 | **Exportar Excel** | `Bt_CopyExcel_Click` - copia grid al portapapeles | `exportarExcel()` - descarga archivo XLS | ⭐ Mejora |
| 45 | **Exportar PDF** | No hay exportación a PDF directa | No hay | ✅ |
| 46 | **Exportar CSV/Texto** | No hay | No hay | ✅ |
| 47 | **Impresión** | `Bt_Print_Click` con `FrmPrtSetup`, orientación, papel foliado, `SetUpPrtGrid`, `PrtPieBalance` | `window.print()` básico | 🟠 |
| 48 | **Llamadas a otros módulos** | `FrmLibCaja.FView(-1)`, `FrmRepActivoFijo.FView()` al hacer clic en detalle doc | ❌ No implementado | 🔴 |

**Resumen Sección:** ✅ 4/6 | 🔴 1 gap crítico | 🟠 1 gap alto | ⭐ 1 mejora

---

## 🔟 PARIDAD DE CONTROLES UI (6 aspectos)

| # | Aspecto | VB6 (.frm) | .NET (.cshtml) | Estado |
|---|---------|------------|----------------|:------:|
| 49 | **TextBoxes** | No hay inputs de texto estáticos | No hay | ✅ |
| 50 | **Labels/Etiquetas** | Etiquetas de concepto en grid (col `C_CONCEPTO`) | Etiquetas en `<td>` | ✅ |
| 51 | **ComboBoxes/Selects** | No hay combos | No hay | ✅ |
| 52 | **Grids/Tablas** | `FlexEdGrid2.FEd2Grid` con 10 columnas (3 visibles) | `<table>` con 3 columnas | ✅ |
| 53 | **CheckBoxes** | No hay checkboxes | No hay | ✅ |
| 54 | **Campos ocultos/IDs** | Columnas ocultas: `C_ID`, `C_TIPOAJUSTE`, `C_IDITEM`, `C_TIPOING`, `C_FMT`, `C_UPD` | `data-tipo`, `data-index` en inputs | ✅ |

**Resumen Sección:** ✅ 6/6 | Paridad perfecta en controles

### Mapeo de Columnas VB6 → .NET:

| Columna VB6 | Ancho VB6 | Columna .NET | Ancho .NET |
|-------------|-----------|--------------|------------|
| `C_ID` (0) | 0 (oculto) | `data-*` attributes | N/A |
| `C_TIPOAJUSTE` (1) | 0 (oculto) | `data-tipo` | N/A |
| `C_IDITEM` (2) | 0 (oculto) | `data-index` | N/A |
| `C_CONCEPTO` (3) | 9000 | `<td>` columna 1 | 60% |
| `C_VALOR` (4) | 1600 | `<td>` columna 2 / `<input>` | 20% |
| `C_SUBTOTAL` (5) | 1600 | `<td>` columna 3 | 20% |
| `C_TIPOING` (6) | 0 (oculto) | `editable` property | N/A |
| `C_FMT` (7) | 0 (oculto) | CSS classes | N/A |
| `C_COLOBLIGATORIA` (8) | 0 (oculto) | N/A | N/A |
| `C_UPD` (9) | 0 (oculto) | N/A | N/A |

---

## 1️⃣1️⃣ GRIDS Y COLUMNAS (2 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 55 | **Columnas del grid** | 3 columnas visibles: Concepto, Valor, Subtotal | 3 columnas: Concepto, Valor, Subtotal | ✅ |
| 56 | **Datos del grid** | `LoadAll()` carga saldos + items de `gAjustesExtraCont()` | `cargarDatos()` / `renderGrid()` carga desde API | ✅ |

**Resumen Sección:** ✅ 2/2 | Estructura de grid equivalente

---

## 1️⃣2️⃣ EVENTOS E INTERACCIÓN (5 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 57 | **Doble clic** | `Grid_BeforeEdit` redirige a `Bt_DetDoc_Click` si celda no editable (línea 978) | ❌ No hay evento doble clic | 🟠 |
| 58 | **Teclas especiales** | No usa `KeyPreview` ni atajos F1-F12 | No hay | ✅ |
| 59 | **Eventos Change** | `Grid_AcceptValue` al editar celda, recalcula con `CalcTot()` | `actualizarValor()` en `onblur`, recalcula | ✅ |
| 60 | **Menú contextual** | No hay menú contextual | No hay | ✅ |
| 61 | **Modales Lookup** | Abre `FrmLibCaja` o `FrmRepActivoFijo` al hacer clic | ❌ No implementado | 🔴 |

**Resumen Sección:** ✅ 3/5 | 🔴 1 gap crítico | 🟠 1 gap alto

---

## 1️⃣3️⃣ ESTADOS Y MODOS DEL FORMULARIO (3 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 62 | **Modos del form** | Un solo modo: `FEdit()` - edición modal | Un solo modo: Index - edición SPA | ✅ |
| 63 | **Controles por modo** | Celdas editables si `TipoIngreso = TIA_INGDIRECTO` | Inputs si `editable = true` | ✅ |
| 64 | **Orden de tabulación** | No tiene `TabIndex` definido | Orden natural del DOM | ✅ |

**Resumen Sección:** ✅ 3/3 | Paridad completa

---

## 1️⃣4️⃣ INICIALIZACIÓN Y CARGA (3 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 65 | **Carga inicial** | `Form_Load()` llama `SetUpGrid()` y `LoadAll()` | `cargarDatos()` al cargar página | ✅ |
| 66 | **Valores por defecto** | Valores leídos de DB o calculados (LoadAll líneas 336-499) | ❌ Valores de prueba (Service no calcula) | 🔴 |
| 67 | **Llenado de combos** | No hay combos | No hay combos | ✅ |

**Resumen Sección:** ✅ 2/3 | 🔴 1 gap crítico

---

## 1️⃣5️⃣ FILTROS Y BÚSQUEDA (2 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 68 | **Campos de filtro** | No hay filtros | No hay filtros | ✅ |
| 69 | **Criterios de búsqueda** | No aplica | No aplica | ✅ |

**Resumen Sección:** ✅ 2/2 | No se requieren filtros

---

## 1️⃣6️⃣ REPORTES E IMPRESIÓN (2 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 70 | **Reportes disponibles** | Vista previa (`Bt_Preview_Click`) e impresión (`Bt_Print_Click`) con `FrmPrtSetup`, `gPrtLibros`, encabezado empresa, `PrtPieBalance` | `window.print()` básico con CSS `@media print` | 🟠 |
| 71 | **Parámetros de reporte** | Orientación (`lOrientacion`), papel foliado (`lPapelFoliado`), info preliminar (`lInfoPreliminar`) | ❌ Sin parámetros | 🟠 |

**Resumen Sección:** 🟠 2 gaps altos (impresión muy básica vs VB6)

### Funcionalidades de impresión VB6 faltantes:
- Configuración de orientación (vertical/horizontal)
- Papel foliado con numeración
- Info preliminar (marca de borrador)
- Encabezado con datos de empresa
- Pie de balance
- Vista previa antes de imprimir

---

## 1️⃣7️⃣ REGLAS DE NEGOCIO (4 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 72 | **Umbrales y límites** | Gastos Presuntos: Min 1 UTM, Max 15 UTM (líneas 722-729) | ❌ No implementado | 🔴 |
| 73 | **Fórmulas de cálculo** | Gastos Presuntos = (SaldoIng + IngNoPer12M) * 0.5%, Base Imponible = SaldoFinal + Agregados - Deducciones | Fórmula Base Imponible ✅, Gastos Presuntos ❌ | 🟠 |
| 74 | **Condiciones de negocio** | Ajustes automáticos según: `EntRelacionada`, `NumCuotas`, `DateDiff > 12 meses`, `OperDevengada` | ❌ No implementado (TODO Service línea 107) | 🔴 |
| 75 | **Restricciones** | No hay restricciones de edición | No hay | ✅ |

**Resumen Sección:** ✅ 1/4 | 🔴 2 gaps críticos | 🟠 1 gap alto

---

## 1️⃣8️⃣ FLUJOS DE TRABAJO (3 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 76 | **Secuencia de estados** | No aplica (no tiene estados) | No aplica | ✅ |
| 77 | **Acciones por estado** | No aplica | No aplica | ✅ |
| 78 | **Transiciones válidas** | No aplica | No aplica | ✅ |

**Resumen Sección:** ✅ 3/3 | No aplica a este módulo

---

## 1️⃣9️⃣ INTEGRACIONES ENTRE MÓDULOS (3 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 79 | **Llamadas a otros módulos** | `FrmLibCaja.FView(-1)` (línea 261), `FrmRepActivoFijo.FView()` (línea 270) | ❌ No implementado | 🔴 |
| 80 | **Parámetros de integración** | `FView(-1)` para ver todo el libro de caja, sin parámetros para Activo Fijo | N/A | 🔴 |
| 81 | **Datos compartidos/retorno** | No retorna datos, solo muestra modales | N/A | ✅ |

**Resumen Sección:** ✅ 1/3 | 🔴 2 gaps críticos

### Navegación a detalle (VB6):
```vb
Private Sub Bt_DetDoc_Click()
   If Row <= lRow_SaldoFinal Then
      ' Ver Libro de Caja completo
      Set Frm = New FrmLibCaja
      Call Frm.FView(-1)
   ElseIf InStr(LCase(Grid.TextMatrix(Row, C_CONCEPTO)), "33 bis") > 0 Then
      ' Ver reporte de Activo Fijo para crédito 33 Bis
      Set Frm = New FrmRepActivoFijo
      Call Frm.FView
   End If
End Sub
```

---

## 2️⃣0️⃣ MENSAJES AL USUARIO (2 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 82 | **Mensajes de error** | No hay mensajes de error explícitos en este form | `Swal.fire()` para errores de carga/guardado | ⭐ Mejora |
| 83 | **Mensajes de confirmación** | No hay confirmaciones | No hay confirmaciones | ✅ |

**Resumen Sección:** ✅ 2/2 | ⭐ .NET tiene mejor UX con mensajes

---

## 2️⃣1️⃣ CASOS BORDE Y VALORES ESPECIALES (3 aspectos)

| # | Aspecto | VB6 | .NET | Estado |
|---|---------|-----|------|:------:|
| 84 | **Valores cero** | Permite valores cero, usa `vFmt()` para manejarlos | Permite valores cero | ✅ |
| 85 | **Valores negativos** | Permite negativos, formatea entre paréntesis `NEGNUMFMT` | Permite negativos, formato `(valor)` | ✅ |
| 86 | **Valores nulos/vacíos** | `vFld()` convierte nulls a 0 | `?? 0` convierte nulls a 0 | ✅ |

**Resumen Sección:** ✅ 3/3 | Manejo correcto de casos borde

---

## 📊 RESUMEN DE GAPS POR PRIORIDAD

### 🔴 GAPS CRÍTICOS (8) - Bloquean producción

| # | Gap | Impacto | Archivo .NET | Esfuerzo |
|---|-----|---------|--------------|----------|
| 1 | **Configuración de items de ajuste no se carga** | No hay conceptos/nombres de items a mostrar | `AjustesExtraContablesCajaService.cs` | 4h |
| 2 | **Query CalcSaldosIngEgr no implementada** | Saldos Ingresos/Egresos incorrectos | `AjustesExtraContablesCajaService.cs` | 2h |
| 3 | **Queries de ajustes automáticos no implementadas** | Items K, L, M, Ñ, W con valor 0 | `AjustesExtraContablesCajaService.cs` | 6h |
| 4 | **INSERT/UPDATE en AjustesExtLibCaja no implementado** | No se guardan los datos | `AjustesExtraContablesCajaService.cs:21` | 3h |
| 5 | **Cálculo de Gastos Presuntos (R) no implementado** | Deducción crítica para 14 ter ausente | `AjustesExtraContablesCajaService.cs` | 2h |
| 6 | **Valores por defecto no se calculan** | Grid vacío en lugar de datos reales | `AjustesExtraContablesCajaService.cs` | 4h |
| 7 | **Navegación a detalle de documentos no implementada** | No se puede ver origen de ajustes | `Index.cshtml` | 2h |
| 8 | **Integraciones con FrmLibCaja y FrmRepActivoFijo ausentes** | Pérdida de trazabilidad | N/A | 3h |

**Esfuerzo total críticos:** ~26h

---

### 🟠 GAPS ALTOS (12) - Planificar en siguiente sprint

| # | Gap | Impacto | Archivo .NET |
|---|-----|---------|--------------|
| 9 | Herramientas auxiliares no implementadas | Calculadora, Calendario, Conversión Moneda, Suma | N/A |
| 10 | Impresión avanzada no implementada | Sin configuración, papel foliado, encabezado empresa | `Index.cshtml` |
| 11 | Vista previa de impresión ausente | No se puede verificar antes de imprimir | N/A |
| 12 | Botón Cancelar sin implementar | No se puede cerrar sin guardar | `Index.cshtml` |
| 13 | Tablas secundarias no consultadas | `Documento`, `Entidades` no se usan | Service |
| 14 | Campos críticos no leídos | `SaldoDoc`, `EntRelacionada`, `OperDevengada` | Service |
| 15 | Redondeo de Gastos Presuntos ausente | Valor sin formatear a 0 decimales | N/A |
| 16 | Valores calculados incompletos | Solo subtotales básicos | `Index.cshtml` |
| 17 | Doble clic en grid no navega | En VB6 abre detalle, en .NET no hace nada | `Index.cshtml` |
| 18 | Fórmula de Gastos Presuntos incompleta | Falta 0.5%, tope UTM | N/A |
| 19 | Parámetros de impresión ausentes | Orientación, info preliminar | N/A |
| 20 | Condiciones de negocio no validadas | Lógica de empresas relacionadas, cuotas | Service |

---

### 🟡 GAPS MEDIOS (10) - Backlog

| # | Gap | Impacto | Archivo .NET |
|---|-----|---------|--------------|
| 21 | Sin validación de permisos | Cualquier usuario puede acceder | Controller |
| 22 | Carga de cuentas asociadas ausente | Items tipo `TIA_CTASASOCIADAS` sin valor | N/A |
| 23 | Crédito Art. 33 Bis no calculado | Item 'H' sin valor | N/A |
| 24 | Valor de UTM no se obtiene | Gastos Presuntos sin tope | N/A |
| 25 | No valida año cerrado/bloqueado | Permite editar períodos cerrados | N/A |
| 26 | Sin log de auditoría | No registra quién modificó | N/A |
| 27 | Formato `NEGNUMFMT` no exacto | VB6 usa formato específico de sistema | `Index.cshtml` |
| 28 | Sin validación de EmpresasAno | Si no existe, retorna DTO vacío sin avisar | Service |
| 29 | IPC conversion no completa | Solo estructura, falta lógica de ajuste | Service |
| 30 | Sin manejo de entidades relacionadas | Flag `ConEntRel` se lee pero no se usa | Service |

---

### ⚪ GAPS BAJOS (2) - Opcional

| # | Gap | Impacto | Archivo .NET |
|---|-----|---------|--------------|
| 31 | Sin validaciones de campos | VB6 tampoco las tiene (`valida()` vacía) | N/A |
| 32 | Sin validaciones de rangos | Ambos sistemas permiten cualquier valor | N/A |

---

## ⭐ MEJORAS EN .NET SOBRE VB6 (5)

| # | Mejora | Descripción | Beneficio |
|---|--------|-------------|-----------|
| 1 | **Arquitectura limpia** | Separación Controller → Service → Repository | Mantenibilidad, testabilidad |
| 2 | **Async/Await** | Operaciones asíncronas para mejor escalabilidad | Performance bajo carga |
| 3 | **Mensajes SweetAlert** | UX moderna vs MsgBox | Mejor experiencia de usuario |
| 4 | **Exportación Excel mejorada** | Descarga archivo vs copiar portapapeles | Más conveniente para usuarios |
| 5 | **Responsive design** | Tailwind CSS vs formulario fijo VB6 | Acceso desde cualquier dispositivo |

---

## 🎯 PLAN DE ACCIÓN RECOMENDADO

### Prioridad 1 - CRÍTICA (Sprint actual)

#### 1.1 Implementar carga de configuración de items
**Archivo:** `AjustesExtraContablesCajaService.cs`

Opciones:
- **A)** Crear tabla `AjustesExtraContConfig` y consultarla
- **B)** Hardcodear configuración como en VB6 (menos flexible pero más rápido)

#### 1.2 Implementar CalcSaldosIngEgr
```csharp
private async Task<(decimal Ingresos, decimal Egresos)> CalcSaldosIngEgrAsync(int empresaId, short ano)
{
    var fechaInicio = new DateTime(ano, 1, 1).ToOADate();
    var fechaFin = new DateTime(ano, 12, 31).ToOADate();

    var ingresos = await context.LibroCaja
        .Where(lc => lc.IdEmpresa == empresaId && lc.Ano == ano
                  && lc.FechaIngresoLibro >= fechaInicio && lc.FechaIngresoLibro <= fechaFin
                  && lc.TipoOper == 1)
        .SumAsync(lc => lc.Pagado ?? 0);

    var egresos = await context.LibroCaja
        .Where(lc => lc.IdEmpresa == empresaId && lc.Ano == ano
                  && lc.FechaIngresoLibro >= fechaInicio && lc.FechaIngresoLibro <= fechaFin
                  && lc.TipoOper == 2)
        .SumAsync(lc => lc.Pagado ?? 0);

    return (ingresos, egresos);
}
```

#### 1.3 Implementar queries de ajustes automáticos
Ver sección "Queries VB6 no implementadas" para el código SQL a migrar.

#### 1.4 Implementar guardado en AjustesExtLibCaja
Ver código en archivo `AUDITORIA_VB6_vs_NET9.md` líneas 750-800.

#### 1.5 Implementar cálculo de Gastos Presuntos
```csharp
private async Task<decimal> CalcularGastosPresuntosAsync(
    decimal saldoCajaIngresos, decimal ingNoPercib12M, short ano)
{
    var baseCalculo = saldoCajaIngresos + ingNoPercib12M;
    var gastosPresuntos = baseCalculo * 0.005m;  // 0.5%

    var utm = await ObtenerUTMAsync(ano);
    if (utm > 0)
    {
        gastosPresuntos = Math.Round(gastosPresuntos, 0);
        gastosPresuntos = Math.Max(utm, Math.Min(gastosPresuntos, 15 * utm));
    }
    return gastosPresuntos;
}
```

### Prioridad 2 - ALTA (Siguiente sprint)

- Implementar navegación a detalle de documentos
- Agregar impresión avanzada con parámetros
- Implementar botón Cancelar
- Agregar doble clic en grid

### Prioridad 3 - MEDIA (Backlog)

- Validación de permisos
- Cálculo Art. 33 Bis
- Validar año cerrado
- Log de auditoría

---

## ✅ CONCLUSIÓN

### Estado Actual
La implementación .NET de **AjustesExtraContablesCaja** tiene una **paridad estructural del 62.8%** con VB6, pero **paridad funcional cercana al 30%** debido a que las funcionalidades de cálculo críticas no están implementadas.

### Veredicto Final
🔴 **NO LISTO PARA PRODUCCIÓN**

### Riesgos de Deployment
| Riesgo | Severidad | Descripción |
|--------|-----------|-------------|
| **Datos incorrectos** | 🔴 Crítico | Saldos y ajustes automáticos retornan valores vacíos/cero |
| **Pérdida de datos** | 🔴 Crítico | El guardado no funciona (TODO en Service línea 21) |
| **Incumplimiento tributario** | 🔴 Crítico | Cálculos del Art. 14 ter incorrectos pueden generar problemas con el SII |
| **Pérdida de trazabilidad** | 🟠 Alto | No se puede navegar a documentos de origen |

### Esfuerzo Estimado para Completar
| Prioridad | Horas | Descripción |
|-----------|-------|-------------|
| 🔴 Crítica | 26h | Cálculos, guardado, queries |
| 🟠 Alta | 16h | Impresión, navegación, herramientas |
| 🟡 Media | 8h | Permisos, validaciones, logs |
| **Total** | **50h** | ~1.5 semanas de desarrollo |

### Siguiente Paso Recomendado
1. **Implementar Prioridad 1** (carga configuración, queries, guardado, cálculos)
2. **Crear casos de prueba** comparando resultados VB6 vs .NET con datos reales
3. **Validar con usuario experto** que los cálculos tributarios sean correctos
4. **Implementar Prioridad 2** (impresión, navegación)
5. **Realizar pruebas de regresión** con múltiples empresas/años

---

**Generado por:** Auditoría de Gaps VB6 vs .NET 9  
**Metodología:** 86 aspectos según `auditoria-gaps.md`  
**Fecha:** 2025-12-06
