﻿namespace App.Features.CapitalPropio;

public interface ICapitalPropioService
{
    Task<CapitalPropioResultDto> CalculateCapitalPropioAsync(int empresaId, short ano);
    Task<decimal> GetCapitalEfectivoAsync(int empresaId, short ano);
    Task SaveCapitalPropioAsync(int empresaId, short ano, decimal total);
    Task<decimal?> GetSavedCapitalPropioAsync(int empresaId, short ano);
}