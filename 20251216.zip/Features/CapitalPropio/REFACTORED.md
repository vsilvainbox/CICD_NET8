# ✅ Feature CapitalPropio Refactorizada

**Fecha:** 2025-12-07
**Guía aplicada:** D:\deploy\refactor.md

---

## Violaciones Detectadas y Corregidas

### Violaciones Iniciales
- **R19**: proxy(1) - JavaScript llamaba a WebController en lugar de ApiController directamente
- **R20**: fetch-manual(2) - Uso de fetch manual en lugar de helpers Api.*
- **R22**: hasnokey-ef(1) - Entidad ParamEmpresa (HasNoKey) usaba Add() de EF

---

## Cambios Aplicados por Archivo

### 1. CapitalPropioService.cs

#### R22: Entidad HasNoKey debe usar SQL raw
**Problema:** ParamEmpresa es una entidad sin clave primaria (HasNoKey) y estaba usando `context.ParamEmpresa.Add()`, lo cual causa error en runtime.

**Cambios:**
- ❌ **ANTES:** `context.ParamEmpresa.Add(new ParamEmpresa { ... })`
- ✅ **DESPUÉS:**
  ```csharp
  // INSERT con SQL raw
  await context.Database.ExecuteSqlRawAsync(
      @"INSERT INTO ParamEmpresa (Tipo, Codigo, Valor, IdEmpresa, Ano)
        VALUES (@p0, @p1, @p2, @p3, @p4)",
      "CAPPROPIO", 0, valorString, empresaId, ano);

  // UPDATE con SQL raw
  await context.Database.ExecuteSqlRawAsync(
      @"UPDATE ParamEmpresa
        SET Valor = @p0
        WHERE Tipo = @p1 AND IdEmpresa = @p2 AND Ano = @p3",
      valorString, "CAPPROPIO", empresaId, ano);
  ```

**Líneas modificadas:** 158-195

---

### 2. CapitalPropioController.cs (WebController)

#### R19: Eliminar métodos proxy
**Problema:** El WebController tenía métodos `Calculate()` y `Save()` que actuaban como proxy hacia el ApiController usando `ProxyRequestAsync`. JavaScript debe llamar directamente al ApiController.

**Cambios:**
- ❌ **ANTES:**
  - Método `Calculate()` con `GetFromApiAsync` + proxy
  - Método `Save()` con `ProxyRequestAsync`
  - Dependencias: `IHttpClientFactory`, `LinkGenerator`

- ✅ **DESPUÉS:**
  - Métodos proxy eliminados completamente
  - Solo queda el método `Index()` para retornar la vista
  - Dependencias simplificadas: solo `ILogger`

**Líneas modificadas:** 1-35
**Líneas eliminadas:** ~40 líneas de código proxy

---

### 3. CapitalPropioApiController.cs

#### R02: No envolver respuestas en objetos
**Problema:** El método `Save()` retornaba `Ok(new { message = "..." })` en lugar de solo `Ok()`.

**Cambios:**
- ❌ **ANTES:** `return Ok(new { message = "Capital Propio guardado exitosamente" });`
- ✅ **DESPUÉS:** `return Ok();`

**Mejoras adicionales:**
- Eliminadas llaves innecesarias `{ }` en todos los métodos
- Código más limpio y consistente

**Líneas modificadas:** 9-32

---

### 4. Views/Index.cshtml

#### R19 + R20: URLs directas a ApiController + usar Api.* helpers
**Problema:**
1. URLs apuntaban a CapitalPropioController (WebController) en lugar de CapitalPropioApiController
2. Uso de `fetch()` manual en lugar de helpers `Api.get()` y `Api.postJson()`

**Cambios en URL_ENDPOINTS:**
- ❌ **ANTES:**
  ```javascript
  const URL_ENDPOINTS = {
      calculate: '@Url.Action("Calculate", "CapitalPropio")',
      save: '@Url.Action("Save", "CapitalPropio")'
  };
  ```
- ✅ **DESPUÉS:**
  ```javascript
  // R04 + R19: URLs apuntan directamente al ApiController
  const URL_ENDPOINTS = {
      calculate: '@Url.Action("Calculate", "CapitalPropioApi")',
      save: '@Url.Action("Save", "CapitalPropioApi")'
  };
  ```

**Cambios en loadCapitalPropioData():**
- ❌ **ANTES:**
  ```javascript
  const response = await fetch(`${URL_ENDPOINTS.calculate}?...`, { ... });
  if (!response.ok) throw new Error('...');
  capitalPropioData = await response.json();
  ```
- ✅ **DESPUÉS:**
  ```javascript
  // R20: Usar Api.get en lugar de fetch manual
  const data = await Api.get(URL_ENDPOINTS.calculate, { empresaId, ano });
  if (data) {
      capitalPropioData = data;
      renderCapitalPropioTable();
      updateTotalDisplay();
      showAdvertencias();
  }
  ```

**Cambios en saveAndClose():**
- ❌ **ANTES:**
  ```javascript
  const response = await fetch(URL_ENDPOINTS.save, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ... },
      body: JSON.stringify({ ... })
  });
  if (response.ok) { ... }
  ```
- ✅ **DESPUÉS:**
  ```javascript
  // R20: Usar Api.postJson en lugar de fetch manual
  const datos = { empresaId, ano, total: capitalPropioData.capitalPropioTributario };
  const result = await Api.postJson(URL_ENDPOINTS.save, datos);
  if (result !== null) { ... }
  ```

**Líneas modificadas:** 145-149, 156-167, 402-426

**Beneficios:**
- ✅ Manejo automático de errores por Api.* (muestra SweetAlert)
- ✅ Manejo automático de anti-forgery tokens
- ✅ Menos código boilerplate
- ✅ Arquitectura correcta: Vista → ApiController directo

---

## Verificación de Reglas

### Service (CapitalPropioService.cs)
- [x] R06 - Reutiliza lógica existente (no duplica queries)
- [x] R14 - DTOs en PascalCase
- [x] R15 - No usa try-catch (excepciones fluyen)
- [x] R17 - Tipos SQL correctos
- [x] R22 - **CORREGIDO:** Entidad HasNoKey usa SQL raw

### ApiController (CapitalPropioApiController.cs)
- [x] R02 - **CORREGIDO:** Sin try-catch, retorna Ok()/Ok(data)
- [x] R06 - No duplica endpoints
- [x] R14 - Parámetros coinciden con DTOs
- [x] R15 - Excepciones fluyen al middleware

### WebController (CapitalPropioController.cs)
- [x] R02 - Sin try-catch
- [x] R03 - **MEJORADO:** Ya no llama a Service ni a API (solo retorna vista)
- [x] R19 - **CORREGIDO:** Métodos proxy eliminados

### Vista (Views/Index.cshtml)
- [x] R04 - URLs con @Url.Action
- [x] R07 - Header estilo Dashboard
- [x] R08 - Orden correcto (Header → Herramientas → Tabla)
- [x] R19 - **CORREGIDO:** JavaScript llama a CapitalPropioApi directamente
- [x] R20 - **CORREGIDO:** Usa Api.get y Api.postJson (no fetch manual)
- [x] CSS - bg-white, sin dark:, sin appearance-none

---

## Resumen de Correcciones

| Regla | Archivo | Descripción | Estado |
|-------|---------|-------------|--------|
| R22 | CapitalPropioService.cs | ParamEmpresa.Add() → ExecuteSqlRawAsync | ✅ CORREGIDO |
| R19 | CapitalPropioController.cs | Eliminados métodos proxy Calculate/Save | ✅ CORREGIDO |
| R02 | CapitalPropioApiController.cs | Save() retorna Ok() sin mensaje envuelto | ✅ CORREGIDO |
| R19 | Views/Index.cshtml | URLs apuntan a CapitalPropioApi | ✅ CORREGIDO |
| R20 | Views/Index.cshtml | fetch() → Api.get() en loadCapitalPropioData | ✅ CORREGIDO |
| R20 | Views/Index.cshtml | fetch() → Api.postJson() en saveAndClose | ✅ CORREGIDO |

---

## Arquitectura Final

```
Vista (Index.cshtml)
    ↓ (JavaScript: Api.get/Api.postJson)
CapitalPropioApiController
    ↓ (Llamada directa)
CapitalPropioService
    ↓ (LINQ + SQL raw para HasNoKey)
Base de datos
```

**Eliminado:** WebController como proxy (patrón incorrecto)

---

## Pruebas Sugeridas

1. **Cálculo:**
   - Abrir la vista
   - Verificar que se cargue automáticamente el cálculo
   - Validar que muestre todos los valores correctamente

2. **Guardado:**
   - Hacer clic en "Guardar y Cerrar"
   - Verificar que muestre SweetAlert de éxito
   - Confirmar que se guarde en ParamEmpresa (verificar en BD)

3. **Errores:**
   - Simular error de red (desconectar API)
   - Verificar que muestre SweetAlert de error automáticamente (gracias a Api.*)

4. **SQL Raw:**
   - Verificar en logs que el INSERT/UPDATE se ejecuta correctamente
   - Confirmar que no arroja error "Unable to track an instance of type 'ParamEmpresa'"

---

## Notas Adicionales

- La feature usa un patrón de solo lectura + guardado simple (no CRUD completo)
- No requiere modales de edición
- Herramientas externas (calculadora, suma, conversión) están pendientes de migración
- El cálculo es complejo con múltiples queries LINQ optimizadas
- Advertencias se muestran automáticamente si hay saldos incorrectos

---

## Estado Final

✅ **FEATURE COMPLETAMENTE REFACTORIZADA**

- 0 violaciones R19
- 0 violaciones R20
- 0 violaciones R22
- Código limpio y siguiendo todas las convenciones
- Arquitectura correcta implementada
