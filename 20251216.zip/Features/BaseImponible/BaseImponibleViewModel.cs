using System.ComponentModel.DataAnnotations;
using System.Globalization;
using ValidationResult = System.ComponentModel.DataAnnotations.ValidationResult;

namespace App.Features.BaseImponible;

/// <summary>
/// ViewModel para la vista principal de Base Imponible
/// Centraliza toda la lógica de presentación y formateo
/// </summary>
public class BaseImponibleViewModel : IValidatableObject
{
    public int IdEmpresa { get; set; }
    public short Ano { get; set; }
    public string NombreEmpresa { get; set; } = string.Empty;

    public List<BaseImponibleSeccionViewModel> Secciones { get; set; } = new();

    // Propiedades calculadas (cálculos tributarios críticos en servidor)
    public decimal TotalIngresos { get; set; }
    public decimal TotalEgresos { get; set; }
    public decimal BaseImponibleCalculada { get; set; }

    [Range(0, double.MaxValue, ErrorMessage = "El mayor valor debe ser mayor o igual a cero")]
    public decimal MayorValor { get; set; }

    // Propiedades formateadas para la vista (servidor controla el formateo)
    public string TotalIngresosFormateado => FormatearMoneda(TotalIngresos);
    public string TotalEgresosFormateado => FormatearMoneda(TotalEgresos);
    public string BaseImponibleFormateada => FormatearMoneda(BaseImponibleCalculada);
    public string MayorValorFormateado => FormatearMoneda(MayorValor);

    /// <summary>
    /// Validaciones de negocio tributarias
    /// </summary>
    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        // Validación 1: Empresa debe existir
        if (IdEmpresa <= 0)
        {
            yield return new ValidationResult(
                "Debe seleccionar una empresa válida",
                new[] { nameof(IdEmpresa) });
        }

        // Validación 2: Año debe ser válido
        if (Ano < 2000 || Ano > DateTime.Now.Year + 1)
        {
            yield return new ValidationResult(
                $"El año {Ano} no es válido. Debe estar entre 2000 y {DateTime.Now.Year + 1}",
                new[] { nameof(Ano) });
        }

        // Validación 3: Mayor valor no puede ser negativo
        if (MayorValor < 0)
        {
            yield return new ValidationResult(
                "El mayor valor no puede ser negativo",
                new[] { nameof(MayorValor) });
        }

        // Validación 4: Consistencia de cálculos (trazabilidad tributaria)
        var baseCalculada = TotalIngresos - TotalEgresos;
        if (Math.Abs(BaseImponibleCalculada - baseCalculada) > 0.01m)
        {
            yield return new ValidationResult(
                $"Error en cálculo de base imponible. Esperado: {baseCalculada}, Calculado: {BaseImponibleCalculada}",
                new[] { nameof(BaseImponibleCalculada) });
        }
    }

    /// <summary>
    /// Formateo centralizado de moneda chilena con precisión decimal
    /// </summary>
    private static string FormatearMoneda(decimal valor)
    {
        var cultura = new CultureInfo("es-CL");
        cultura.NumberFormat.CurrencySymbol = "$";
        cultura.NumberFormat.CurrencyDecimalDigits = 2;
        return valor.ToString("N2", cultura);
    }

    /// <summary>
    /// Crea un ViewModel desde el DTO del servicio
    /// </summary>
    public static BaseImponibleViewModel FromDto(BaseImponibleDto dto)
    {
        var viewModel = new BaseImponibleViewModel
        {
            IdEmpresa = dto.IdEmpresa,
            Ano = dto.Ano,
            NombreEmpresa = dto.NombreEmpresa,
            TotalIngresos = (decimal)dto.TotalIngresos,
            TotalEgresos = (decimal)dto.TotalEgresos,
            BaseImponibleCalculada = (decimal)dto.BaseImponible,
            MayorValor = (decimal)dto.MayorValor
        };

        // Mapear secciones
        foreach (var seccionDto in dto.Secciones)
        {
            viewModel.Secciones.Add(BaseImponibleSeccionViewModel.FromDto(seccionDto));
        }

        return viewModel;
    }
}

/// <summary>
/// ViewModel para una sección (Ingresos, Egresos, Totales)
/// </summary>
public class BaseImponibleSeccionViewModel
{
    public byte TipoBaseImp { get; set; }
    public string Titulo { get; set; } = string.Empty;
    public List<BaseImponibleItemViewModel> Items { get; set; } = new();
    public decimal Subtotal { get; set; }

    public string SubtotalFormateado => FormatearMoneda(Subtotal);

    private static string FormatearMoneda(decimal valor)
    {
        var cultura = new CultureInfo("es-CL");
        cultura.NumberFormat.CurrencySymbol = "$";
        cultura.NumberFormat.CurrencyDecimalDigits = 2;
        return valor.ToString("N2", cultura);
    }

    public static BaseImponibleSeccionViewModel FromDto(BaseImponibleSeccionDto dto)
    {
        var seccion = new BaseImponibleSeccionViewModel
        {
            TipoBaseImp = dto.TipoBaseImp,
            Titulo = dto.Titulo,
            Subtotal = (decimal)dto.Subtotal
        };

        foreach (var itemDto in dto.Items)
        {
            seccion.Items.Add(BaseImponibleItemViewModel.FromDto(itemDto));
        }

        return seccion;
    }
}

/// <summary>
/// ViewModel para un item individual
/// </summary>
public class BaseImponibleItemViewModel
{
    public int IdBaseImponible14Ter { get; set; }
    public byte TipoBaseImp { get; set; }
    public short IdItemBaseImp { get; set; }
    public string Concepto { get; set; } = string.Empty;

    [Range(typeof(decimal), "0", "999999999999.99", ErrorMessage = "El valor debe ser mayor o igual a cero")]
    public decimal Valor { get; set; }

    public bool EsCalculado { get; set; } = true;
    public bool EsEditable { get; set; } = false;
    public bool EsSubtotal { get; set; } = false;

    // Formateo server-side para consistencia
    public string ValorFormateado => FormatearMoneda(Valor);

    // Clases CSS calculadas en servidor
    public string ClaseFila => EsSubtotal ? "bg-gray-50 font-bold" : "";
    public string ClaseConcepto => EsSubtotal ? "pl-8" : "pl-12";

    private static string FormatearMoneda(decimal valor)
    {
        var cultura = new CultureInfo("es-CL");
        cultura.NumberFormat.CurrencySymbol = "$";
        cultura.NumberFormat.CurrencyDecimalDigits = 2;
        return valor.ToString("N2", cultura);
    }

    public static BaseImponibleItemViewModel FromDto(BaseImponibleItemDto dto)
    {
        return new BaseImponibleItemViewModel
        {
            IdBaseImponible14Ter = dto.IdBaseImponible14Ter,
            TipoBaseImp = dto.TipoBaseImp,
            IdItemBaseImp = dto.IdItemBaseImp,
            Concepto = dto.Concepto,
            Valor = (decimal)dto.Valor,
            EsCalculado = dto.EsCalculado,
            EsEditable = dto.EsEditable,
            EsSubtotal = dto.EsSubtotal
        };
    }
}

/// <summary>
/// Request para actualizar un item específico
/// Usado con Model Binding (no JSON manual)
/// </summary>
public class ActualizarItemRequest : IValidatableObject
{
    [Required(ErrorMessage = "El tipo de base imponible es requerido")]
    public byte TipoBaseImp { get; set; }

    [Required(ErrorMessage = "El ID del item es requerido")]
    public short IdItemBaseImp { get; set; }

    [Required(ErrorMessage = "El valor es requerido")]
    [Range(typeof(decimal), "0", "999999999999.99", ErrorMessage = "El valor debe estar entre 0 y 999,999,999,999.99")]
    public decimal Valor { get; set; }

    public int EmpresaId { get; set; }
    public short Ano { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        // Validación 1: Empresa válida
        if (EmpresaId <= 0)
        {
            yield return new ValidationResult(
                "ID de empresa inválido",
                new[] { nameof(EmpresaId) });
        }

        // Validación 2: Año válido
        if (Ano < 2000 || Ano > DateTime.Now.Year + 1)
        {
            yield return new ValidationResult(
                "Año inválido",
                new[] { nameof(Ano) });
        }

        // Validación 3: Solo Mayor Valor (tipo=3, item=1) es editable
        if (!(TipoBaseImp == 3 && IdItemBaseImp == 1))
        {
            yield return new ValidationResult(
                "Solo el Mayor Valor puede ser editado manualmente",
                new[] { nameof(TipoBaseImp), nameof(IdItemBaseImp) });
        }
    }
}

/// <summary>
/// Response con valores actualizados y formateados desde servidor
/// </summary>
public class ActualizarItemResponse
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;

    // Valores recalculados en servidor con precisión decimal
    public decimal ValorActualizado { get; set; }
    public decimal TotalIngresos { get; set; }
    public decimal TotalEgresos { get; set; }
    public decimal BaseImponible { get; set; }

    // Valores pre-formateados para la vista
    public string ValorActualizadoFormateado { get; set; } = string.Empty;
    public string TotalIngresosFormateado { get; set; } = string.Empty;
    public string TotalEgresosFormateado { get; set; } = string.Empty;
    public string BaseImponibleFormateada { get; set; } = string.Empty;
}

