using Microsoft.EntityFrameworkCore;
using App.Data;

namespace App.Features.CapitalSimpleAcumulado;

public class CapitalSimpleAcumuladoService(
    LpContabContext context,
    ILogger<CapitalSimpleAcumuladoService> logger) : ICapitalSimpleAcumuladoService
{
    // Diccionario de tipos de detalle CPS (basado en VB6 gTipoDetCapPropioSimpl)
    private readonly Dictionary<int, string> _tiposDetalle = new()
    {
        { 1, "Aumentos de Capital" },
        { 2, "Participaciones Recibidas" },
        { 3, "Disminuciones de Capital" },
        { 4, "Gastos Rechazados" },
        { 5, "Retiros o Dividendos" },
        { 6, "Rentas Exentas e INR Propios" },
        { 7, "Pérdidas INR Propios" },
        { 8, "Utilidades Imputadas a Pérdida" },
        { 9, "Ingreso Diferido" },
        { 10, "CTD Imputable IPE" },
        { 11, "Incentivo al Ahorro" },
        { 12, "Base IDPC Voluntario" },
        { 13, "Crédito Activos Fijos" },
        { 14, "Crédito Participaciones" },
        { 15, "Otros Ajustes Aumentos" },
        { 16, "Otros Ajustes Disminuciones" }
    };

    public async Task<CapitalSimpleAcumuladoResponseDto> ObtenerValoresAnualesAsync(
        int empresaId,
        int anoActual,
        byte tipoDetCPS)
    {
        logger.LogInformation("Obteniendo valores anuales para empresa {EmpresaId}, tipo {TipoDetCPS}",
            empresaId, tipoDetCPS);

        {
            if (anoActual < 2017)
            {
                logger.LogWarning("Año {Ano} es anterior a 2017, no hay datos", anoActual);
                return new CapitalSimpleAcumuladoResponseDto
                {
                    Titulo = _tiposDetalle.GetValueOrDefault(tipoDetCPS, "Componente CPS"),
                    Valores = new List<ValorAnualDto>(),
                    Total = 0
                };
            }

            // Obtener valores existentes desde CapPropioSimplAnual
            var valoresExistentes = await context.CapPropioSimplAnual
                .Where(c => c.IdEmpresa == empresaId && c.TipoDetCPS == tipoDetCPS)
                .OrderBy(c => c.AnoValor)
                .ToListAsync();

            var valores = new List<ValorAnualDto>();

            // Generar lista desde 2017 hasta año actual
            for (short ano = 2017; ano <= anoActual; ano++)
            {
                var existente = valoresExistentes.FirstOrDefault(v => v.AnoValor == ano);

                valores.Add(new ValorAnualDto
                {
                    IdCapPropioSimplAnual = existente?.IdCapPropioSimplAnual ?? 0,
                    AnoValor = ano,
                    Valor = existente != null ? (decimal)(existente.Valor ?? 0) : 0m,
                    IngresoManual = existente?.IngresoManual == true
                });
            }

            var total = await CalcularTotalAsync(valores);

            return new CapitalSimpleAcumuladoResponseDto
            {
                Titulo = _tiposDetalle.GetValueOrDefault(tipoDetCPS, "Componente CPS"),
                Valores = valores,
                Total = total
            };
        }
    }

    public async Task GuardarValoresAnualesAsync(int empresaId, byte tipoDetCPS, List<ValorAnualDto> valores)
    {
        logger.LogInformation("Guardando valores anuales para empresa {EmpresaId}, tipo {TipoDetCPS}",
            empresaId, tipoDetCPS);

        {
            foreach (var valor in valores)
            {
                if (valor.IdCapPropioSimplAnual == 0)
                {
                    // INSERT
                    var nuevo = new CapPropioSimplAnual
                    {
                        TipoDetCPS = tipoDetCPS,
                        IngresoManual = true,
                        AnoValor = valor.AnoValor,
                        Valor = (double)valor.Valor,
                        IdEmpresa = empresaId
                    };

                    context.CapPropioSimplAnual.Add(nuevo);
                }
                else
                {
                    // UPDATE
                    var existente = await context.CapPropioSimplAnual
                        .FirstOrDefaultAsync(c => c.IdCapPropioSimplAnual == valor.IdCapPropioSimplAnual);

                    if (existente != null)
                    {
                        existente.Valor = (double)valor.Valor;
                        existente.IngresoManual = true;
                    }
                }
            }

            await context.SaveChangesAsync();

            logger.LogInformation("Valores anuales guardados exitosamente");
        }
    }

    public Task<decimal> CalcularTotalAsync(List<ValorAnualDto> valores)
    {
        var total = valores.Sum(v => v.Valor);
        return Task.FromResult(total);
    }
}