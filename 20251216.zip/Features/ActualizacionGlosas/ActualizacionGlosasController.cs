using Microsoft.AspNetCore.Mvc;
using App.Helpers;
using App.Extensions;

namespace App.Features.ActualizacionGlosas;


public class ActualizacionGlosasController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<ActualizacionGlosasController> logger) : Controller
{
    public IActionResult Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Actualización de Glosas";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        // Obtener empresaId y ano desde la sesión
        var empresaId = SessionHelper.EmpresaId;
        var ano = SessionHelper.Ano;

        logger.LogInformation("Loading ActualizacionGlosas index for empresaId: {EmpresaId}, ano: {Ano}",
            empresaId, ano);

        var viewModel = new ActualizacionGlosasIndexViewModel
        {
            EmpresaId = empresaId,
            Ano = ano
        };

        return View(viewModel);
    }



    /// <summary>
    /// Guardar glosa desde formulario tradicional (POST)
    /// POST /ActualizacionGlosas/Save
    /// Controlador TONTO: sin try-catch, el middleware maneja errores
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Save(GuardarGlosaRequest model)
    {
        if (!ModelState.IsValid)
            return RedirectToAction("Index");

        model.IdEmpresa = SessionHelper.EmpresaId;

        var client = httpClientFactory.CreateClient();

        if (model.IdGlosa.HasValue && model.IdGlosa > 0)
        {
            // Actualizar
            var url = linkGenerator.GetApiUrl<ActualizacionGlosasApiController>(
                HttpContext,
                nameof(ActualizacionGlosasApiController.UpdateGlosa),
                new { id = model.IdGlosa.Value }
            );
            await client.PutToApiAsync(url!, model);
            TempData["Success"] = "Glosa actualizada correctamente";
        }
        else
        {
            // Crear
            var url = linkGenerator.GetApiUrl<ActualizacionGlosasApiController>(
                HttpContext,
                nameof(ActualizacionGlosasApiController.CreateGlosa)
            );
            await client.PostToApiAsync(url!, model);
            TempData["Success"] = "Glosa creada correctamente";
        }

        return RedirectToAction("Index");
    }

}
