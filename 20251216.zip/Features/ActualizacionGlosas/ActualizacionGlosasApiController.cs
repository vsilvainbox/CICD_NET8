using Microsoft.AspNetCore.Mvc;

namespace App.Features.ActualizacionGlosas;

/// <summary>
/// API Controller para gestión de glosas
/// Patrón: Controller "tonto" - sin try-catch, el middleware maneja errores
/// Respuestas: { messages: [...], data: {...} }
/// </summary>
[ApiController]
[Route("[controller]/[action]")]
public class ActualizacionGlosasApiController(
    IActualizacionGlosasService service,
    ILogger<ActualizacionGlosasApiController> logger) : ControllerBase
{
    [HttpPost]
    public async Task<IActionResult> CreateGlosa([FromBody] GuardarGlosaRequest request)
    {
        logger.LogInformation("API: CreateGlosa called for empresaId: {EmpresaId}", request.IdEmpresa);

        var result = await service.CrearGlosaAsync(request.Glosa, request.IdEmpresa);

        return Ok(new
        {
            messages = new[] { "Glosa creada correctamente" },
            data = result
        });
    }

    [HttpGet]
    public async Task<IActionResult> GetDatos([FromQuery] int empresaId)
    {
        logger.LogInformation("API: GetDatos called for empresaId: {EmpresaId}", empresaId);

        var glosas = await service.GetAllAsync(empresaId);

        // Para listados, retornar directamente el array (sin envolver en { data })
        return Ok(glosas);
    }

    [HttpPut]
    public async Task<IActionResult> UpdateGlosa(int id, [FromBody] GuardarGlosaRequest request)
    {
        logger.LogInformation("API: UpdateGlosa called for idGlosa: {IdGlosa}, empresaId: {EmpresaId}",
            id, request.IdEmpresa);

        var result = await service.ActualizarGlosaAsync(id, request.Glosa, request.IdEmpresa, request.IdGlosa);

        return Ok(new
        {
            messages = new[] { "Glosa actualizada correctamente" },
            data = result
        });
    }

    [HttpGet]
    public async Task<IActionResult> ObtenerGlosa(int id, [FromQuery] int empresaId)
    {
        logger.LogInformation("API: ObtenerGlosa called for idGlosa: {IdGlosa}, empresaId: {EmpresaId}",
            id, empresaId);

        var glosa = await service.ObtenerGlosaAsync(id, empresaId);

        return Ok(new { data = glosa });
    }

    [HttpHead("{id}")]
    public async Task<IActionResult> ExisteGlosa(int id, [FromQuery] int empresaId)
    {
        logger.LogInformation("API: ExisteGlosa called for idGlosa: {IdGlosa}, empresaId: {EmpresaId}",
            id, empresaId);

        await service.ExisteGlosaAsync(id, empresaId);
        return Ok();
    }
}
