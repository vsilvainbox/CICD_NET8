using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Text.Json;
using App.Extensions;
using App.Helpers;

namespace App.Features.AuditoriaLibrosContables;

[Authorize]
public class AuditoriaLibrosContablesController(
    IHttpClientFactory httpClientFactory,
    ILogger<AuditoriaLibrosContablesController> logger,
    LinkGenerator linkGenerator) : Controller
{
    /// <summary>
    /// Muestra la vista principal de auditoría de libros contables
    /// </summary>
    public async Task<IActionResult> Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Auditoría de Libros Contables";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        var empresaId = SessionHelper.EmpresaId;
        var ano = SessionHelper.Ano;

        logger.LogInformation("Loading AuditoriaLibrosContables index for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<AuditoriaLibrosContablesApiController>(
            HttpContext,
            nameof(AuditoriaLibrosContablesApiController.GetCurrentMonth),
            new { empresaId, ano });
        var result = await client.GetFromApiAsync<JsonElement>(url!);
        var mesActual = result.GetProperty("mes").GetInt32();
        logger.LogInformation("Successfully loaded current month");

        var viewModel = new AuditoriaLibrosContablesIndexViewModel
        {
            MesActual = mesActual
        };

        return View(viewModel);
    }

}