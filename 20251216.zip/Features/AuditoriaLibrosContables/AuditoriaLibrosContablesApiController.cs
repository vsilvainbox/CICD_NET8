using Microsoft.AspNetCore.Mvc;

namespace App.Features.AuditoriaLibrosContables;

[ApiController]
[Route("[controller]/[action]")]
public class AuditoriaLibrosContablesApiController(
    IAuditoriaLibrosContablesService service,
    ILogger<AuditoriaLibrosContablesApiController> logger) : ControllerBase
{
    /// <summary>
    /// Obtiene todos los movimientos de auditoría para un período específico
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetAuditoria([FromQuery] int empresaId, [FromQuery] short ano, [FromQuery] int mes)
    {
        logger.LogInformation("API: GetAll called with empresaId: {EmpresaId}, ano: {Ano}, mes: {Mes}", empresaId, ano, mes);

        var resultado = await service.GetAllAsync(empresaId, ano, mes);
        logger.LogInformation("API: Returning auditoría libros contables data");
        return Ok(resultado);
    }

    /// <summary>
    /// Obtiene el mes contable actual
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetCurrentMonth([FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: GetCurrentMonth called with empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        var mes = await service.GetCurrentMonthAsync(empresaId, ano);
        logger.LogInformation("API: Returning current month: {Month}", mes);
        return Ok(new { mes });
    }

    /// <summary>
    /// Exporta los datos de auditoría a Excel
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ExportarExcel([FromQuery] int empresaId, [FromQuery] short ano, [FromQuery] int mes)
    {
        logger.LogInformation("API: ExportToExcel called with empresaId: {EmpresaId}, ano: {Ano}, mes: {Mes}", empresaId, ano, mes);

        var excelResult = await service.ExportToExcelAsync(empresaId, ano, mes);
        logger.LogInformation("API: Returning Excel file");

        return File(excelResult.FileContent, excelResult.ContentType, excelResult.FileName);
    }



}