using Microsoft.AspNetCore.Mvc;
using App.Helpers;

namespace App.Features.AbrirCerrarMes;

/// <summary>
/// MVC Controller para gestión de períodos contables (Abrir/Cerrar Mes)
/// Migrado desde VB6 FrmEstadoMeses.frm
/// Refactorizado siguiendo patron ASP.NET Core MVC way (server-side rendering)
/// </summary>
public class AbrirCerrarMesController(
    ILogger<AbrirCerrarMesController> logger,
    IAbrirCerrarMesService service) : Controller
{
    /// <summary>
    /// Vista principal del control de períodos contables
    /// Muestra los 12 meses del año con sus estados (ABIERTO/CERRADO)
    /// Carga inicial con datos del servidor (no vacia)
    /// </summary>
    public async Task<IActionResult> Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Abrir/Cerrar Mes";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        logger.LogInformation("Loading AbrirCerrarMes Index view for empresaId: {EmpresaId}, año: {Ano}", SessionHelper.EmpresaId, SessionHelper.Ano);

        // Cargar datos iniciales server-side usando el Service
        var viewModel = await CargarViewModelAsync(SessionHelper.EmpresaId, SessionHelper.Ano);

        return View(viewModel);
    }

    /// <summary>
    /// Metodo helper para cargar el ViewModel usando el Service directamente
    /// </summary>
    private async Task<AbrirCerrarMesViewModel> CargarViewModelAsync(int empresaId, short ano)
    {
        // Cargar configuración
        var config = await service.GetConfigurationAsync(empresaId, ano);

        // Cargar estados de meses
        var estadosDtos = await service.GetMonthStatesAsync(empresaId, ano);

        // Mapear a ViewModel
        var viewModel = new AbrirCerrarMesViewModel
        {
            Configuracion = config,
            Meses = estadosDtos.Select(MesEstadoItem.FromDto).ToList()
        };

        return viewModel;
    }

    /// <summary>
    /// Obtiene la tabla de meses renderizada como HTML
    /// GET /AbrirCerrarMes/GetMesesHtml?empresaId=1&amp;ano=2024
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetMesesHtml(int? empresaId = null, short? ano = null)
    {
        try
        {
            var empId = empresaId ?? SessionHelper.EmpresaId;
            var year = ano ?? SessionHelper.Ano;

            logger.LogInformation("GetMesesHtml called with empresaId: {EmpresaId}, año: {Ano}", empId, year);

            var viewModel = await CargarViewModelAsync(empId, year);

            // Retornar partial view que renderiza solo el tbody
            return PartialView("_MesesLista", viewModel);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error loading meses HTML");
            return Content("<tr><td colspan='4' class='px-6 py-8 text-center text-red-500'><i class='fas fa-exclamation-circle text-3xl mb-2'></i><p>Error al cargar los estados de meses</p></td></tr>");
        }
    }

    // NOTA R19: Los métodos AbrirMes y CerrarMes fueron eliminados.
    // El JavaScript ahora llama directamente al ApiController:
    // - POST /AbrirCerrarMesApi/Abrir (AbrirCerrarMesApiController.Abrir)
    // - POST /AbrirCerrarMesApi/Cerrar (AbrirCerrarMesApiController.Cerrar)
}
