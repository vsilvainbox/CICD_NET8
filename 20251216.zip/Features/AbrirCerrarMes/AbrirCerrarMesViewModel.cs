using System.ComponentModel.DataAnnotations;

namespace App.Features.AbrirCerrarMes;

/// <summary>
/// ViewModel para la vista de Abrir/Cerrar Mes
/// Contiene toda la logica de presentacion, calculos y estado necesarios
/// </summary>
public class AbrirCerrarMesViewModel
{
    /// <summary>
    /// Configuracion de la empresa y permisos
    /// </summary>
    public EstadoMesesConfigDto Configuracion { get; set; } = new();

    /// <summary>
    /// Lista de todos los meses del año con su estado
    /// </summary>
    public List<MesEstadoItem> Meses { get; set; } = new();

    /// <summary>
    /// Datos de la empresa actual
    /// </summary>
    public string RazonSocial => Configuracion.RazonSocial;

    public int Ano => Configuracion.Ano;
    public int EmpresaId => Configuracion.EmpresaId;

    /// <summary>
    /// Mensaje de advertencia principal basado en configuracion
    /// </summary>
    public string MensajeAdvertenciaPrincipal => Configuracion.AbrirMesesParalelo
        ? "Puede tener <strong>múltiples meses abiertos</strong> simultáneamente."
        : "Solo puede haber <strong>un mes abierto</strong> a la vez.";

    /// <summary>
    /// Mensaje de advertencia secundario
    /// </summary>
    public string MensajeAdvertenciaSecundario => Configuracion.AbrirMesesParalelo
        ? "La configuración actual permite trabajar en varios meses al mismo tiempo."
        : "Para abrir un mes diferente, primero debe <strong>cerrar el mes actualmente abierto</strong>.";

    /// <summary>
    /// Indica si se debe mostrar el paso 2 en instrucciones (cerrar mes anterior)
    /// </summary>
    public bool MostrarInstruccionCerrarPrimero => !Configuracion.AbrirMesesParalelo;

    /// <summary>
    /// Cuenta cuantos meses estan abiertos
    /// </summary>
    public int CantidadMesesAbiertos => Meses.Count(m => m.EstaAbierto);
}

/// <summary>
/// Item individual que representa un mes con toda su informacion de estado
/// Contiene propiedades calculadas para la vista (badge class, iconos, etc.)
/// </summary>
public class MesEstadoItem
{
    /// <summary>
    /// Numero del mes (1-12)
    /// </summary>
    public int Mes { get; set; }

    /// <summary>
    /// Estado del mes: 0=CERRADO, 1=ABIERTO
    /// </summary>
    public int Estado { get; set; }

    /// <summary>
    /// Nombre del mes en español
    /// </summary>
    public string NombreMes { get; set; } = string.Empty;

    /// <summary>
    /// Indica si este es el ultimo mes con movimientos (se muestra flecha roja)
    /// </summary>
    public bool EsUltimoMesConMovimientos { get; set; }

    // Propiedades calculadas para la vista

    /// <summary>
    /// Indica si el mes esta ABIERTO
    /// </summary>
    public bool EstaAbierto => Estado == 1;

    /// <summary>
    /// Indica si el mes esta CERRADO
    /// </summary>
    public bool EstaCerrado => Estado == 0;

    /// <summary>
    /// Texto del estado para mostrar
    /// </summary>
    public string EstadoTexto => EstaAbierto ? "ABIERTO" : "CERRADO";

    /// <summary>
    /// Clase CSS de Tailwind para el badge del estado
    /// </summary>
    public string BadgeClass => EstaAbierto
        ? "bg-green-100 text-green-800"
        : "bg-red-100 text-red-800";

    /// <summary>
    /// Icono FontAwesome para el estado
    /// </summary>
    public string EstadoIcon => EstaAbierto
        ? "fas fa-unlock"
        : "fas fa-lock";

    /// <summary>
    /// Clase CSS para el boton Abrir
    /// </summary>
    public string BotonAbrirClass => EstaAbierto
        ? "px-4 py-2 text-xs bg-gray-200 text-gray-500 rounded-lg cursor-not-allowed"
        : "px-4 py-2 text-xs bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors";

    /// <summary>
    /// Clase CSS para el boton Cerrar
    /// </summary>
    public string BotonCerrarClass => EstaCerrado
        ? "px-4 py-2 text-xs bg-gray-200 text-gray-500 rounded-lg cursor-not-allowed"
        : "px-4 py-2 text-xs bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors";

    /// <summary>
    /// Mapea desde DTO
    /// </summary>
    public static MesEstadoItem FromDto(EstadoMesDto dto)
    {
        return new MesEstadoItem
        {
            Mes = dto.Mes,
            Estado = dto.Estado,
            NombreMes = dto.NombreMes,
            EsUltimoMesConMovimientos = dto.EsUltimoMesConMovimientos
        };
    }
}

/// <summary>
/// Request para abrir/cerrar un mes usando Model Binding
/// Reemplaza JSON.stringify manual
/// </summary>
public class AbrirCerrarMesRequest
{
    [Required(ErrorMessage = "El ID de empresa es requerido")]
    public int EmpresaId { get; set; }

    [Required(ErrorMessage = "El año es requerido")]
    [Range(2000, 2100, ErrorMessage = "Año inválido")]
    public short Ano { get; set; }

    [Required(ErrorMessage = "El mes es requerido")]
    [Range(1, 12, ErrorMessage = "El mes debe estar entre 1 y 12")]
    public int Mes { get; set; }

    /// <summary>
    /// Nombre del mes (solo para mensajes de confirmacion)
    /// </summary>
    public string NombreMes { get; set; } = string.Empty;
}
