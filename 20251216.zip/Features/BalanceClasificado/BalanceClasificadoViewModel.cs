using System.Globalization;

namespace App.Features.BalanceClasificado;

/// <summary>
/// ViewModel para Balance Clasificado - Siguiendo el patrón ASP.NET Core MVC
/// Contiene propiedades calculadas y formateadas server-side
/// </summary>
public class BalanceClasificadoViewModel
{
    public int IdEmpresa { get; set; }
    public short Ano { get; set; }
    public DateTime FechaCorte { get; set; }
    public DateTime? FechaDesde { get; set; }

    // Filtros
    public int NivelDetalle { get; set; } = 5;
    public int? IdAreaNegocio { get; set; }
    public int? IdCentroCosto { get; set; }
    public int? TipoAjuste { get; set; }
    public bool LibroOficial { get; set; } = false;
    public bool VerSubTotales { get; set; } = true;
    public bool VerCodigoCuenta { get; set; } = false;

    // Datos del balance
    public List<BalanceClasificadoFilaViewModel> Filas { get; set; } = new();

    // Totales (calculados server-side)
    public decimal TotalActivo { get; set; }
    public decimal TotalPasivo { get; set; }
    public decimal TotalPatrimonio { get; set; }

    // Propiedades calculadas (sin JavaScript)
    public decimal Diferencia => Math.Abs(TotalActivo - (TotalPasivo + TotalPatrimonio));
    public bool EstaBalanceado => Diferencia < 0.01m;

    // Propiedades formateadas para la vista (sin toLocaleString en JS)
    public string TotalActivoFormateado => TotalActivo.ToString("C0", new CultureInfo("es-CL"));
    public string TotalPasivoFormateado => TotalPasivo.ToString("C0", new CultureInfo("es-CL"));
    public string TotalPatrimonioFormateado => TotalPatrimonio.ToString("C0", new CultureInfo("es-CL"));
    public string DiferenciaFormateada => Diferencia.ToString("C0", new CultureInfo("es-CL"));

    // Estado del balance
    public string EstadoBalance => EstaBalanceado ? "equilibrado" : "desequilibrado";
    public string EstadoBalanceTexto => EstaBalanceado ? "Balance está equilibrado" : "Balance desequilibrado";
    public string EstadoBalanceClase => EstaBalanceado ? "text-green-600" : "text-red-600";
    public string EstadoBalanceIcono => EstaBalanceado ? "fas fa-check-circle" : "fas fa-exclamation-triangle";

    // Contador de registros
    public int TotalRecords => Filas.Count;

    // Estadísticas (calculadas server-side)
    public int TotalCuentas => Filas.Count(f => !f.EsLineaTotal && !f.EsResultadoEjercicio);
    public int CuentasConSaldo => Filas.Count(f => !f.EsLineaTotal && !f.EsResultadoEjercicio && f.Saldo != 0);
    public int CuentasSinSaldo => TotalCuentas - CuentasConSaldo;
}

/// <summary>
/// ViewModel para cada fila del balance - Con propiedades formateadas
/// </summary>
public class BalanceClasificadoFilaViewModel
{
    public string Codigo { get; set; } = "";
    public string Descripcion { get; set; } = "";
    public int Nivel { get; set; }
    public int Clasificacion { get; set; }
    public decimal Saldo { get; set; }
    public bool EsTitulo { get; set; }
    public bool MostrarCodigo { get; set; } = true;
    public bool EsLineaTotal { get; set; } = false;
    public bool EsResultadoEjercicio { get; set; } = false;
    public bool EsNegrita { get; set; } = false;

    // Propiedades formateadas (server-side, no JS)
    public string SaldoFormateado => Saldo != 0
        ? Saldo.ToString("C0", new CultureInfo("es-CL"))
        : "";

    // Clases CSS calculadas server-side
    public string RowClass
    {
        get
        {
            if (EsLineaTotal || EsResultadoEjercicio)
                return "bg-yellow-50 font-semibold border-t-2 border-b-2 border-gray-300";
            if (EsTitulo)
                return "bg-gray-50 font-medium";
            return "hover:bg-gray-50";
        }
    }

    public string IndentClass => Nivel > 1 ? $"pl-{(Nivel - 1) * 4}" : "";

    public string TextClass => EsNegrita ? "font-semibold" : "";

    public string SaldoClass => EsLineaTotal || EsNegrita ? "font-bold" : "";

    // Determinar si puede tener checkbox
    public bool PuedeSeleccionar => !EsLineaTotal && !EsResultadoEjercicio;

    // Determinar si puede ver libro mayor
    public bool PuedeVerLibroMayor => !EsLineaTotal && !EsTitulo && !string.IsNullOrEmpty(Codigo);
}

/// <summary>
/// ViewModel para la vista Index del Balance Clasificado
/// Patrón: Server-Side Rendering con formularios ASP.NET Core MVC
/// </summary>
public class BalanceClasificadoIndexViewModel
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public DateTime FechaDesde { get; set; }
    public DateTime FechaCorte { get; set; }

    // Filtros del formulario
    public BalanceClasificadoFiltrosViewModel Filtros { get; set; } = new();

    // Opciones para los combos
    public BalanceClasificadoOpcionesViewModel OpcionesFiltros { get; set; } = new();

    // Resultados (null si no se ha buscado)
    public BalanceClasificadoViewModel? Resultados { get; set; }

    // Indica si hay una búsqueda activa
    public bool TieneBusqueda => Resultados != null;
}

/// <summary>
/// ViewModel para los filtros del formulario
/// </summary>
public class BalanceClasificadoFiltrosViewModel
{
    public DateTime? FechaDesde { get; set; }
    public DateTime? FechaCorte { get; set; }
    public int? NivelDetalle { get; set; } = 5;
    public int? TipoAjuste { get; set; }
    public int? IdAreaNegocio { get; set; }
    public int? IdCentroCosto { get; set; }
    public bool LibroOficial { get; set; } = false;
    public bool VerSubTotales { get; set; } = true;
    public bool VerCodigoCuenta { get; set; } = false;
}

/// <summary>
/// ViewModel para las opciones de los combos
/// </summary>
public class BalanceClasificadoOpcionesViewModel
{
    public List<int> Niveles { get; set; } = new() { 1, 2, 3, 4, 5 };
    public List<SelectOption> TiposAjuste { get; set; } = new();
    public List<SelectOption> AreasNegocio { get; set; } = new();
    public List<SelectOption> CentrosCosto { get; set; } = new();
}

/// <summary>
/// Opción genérica para selects
/// </summary>
public class SelectOption
{
    public string Value { get; set; } = "";
    public string Text { get; set; } = "";
}

/// <summary>
/// ViewModel para Suma de Movimientos - Server-side rendering
/// Propiedades calculadas y formateadas sin JavaScript
/// </summary>
public class SumaMovimientosViewModel
{
    public List<string> Codigos { get; set; } = new();
    public decimal Total { get; set; }
    public bool MostrarDetalle { get; set; } = false;
    public List<DetalleMovimiento> Detalles { get; set; } = new();

    // Propiedades calculadas
    public int CantidadCuentas => Codigos.Count;

    // Propiedades formateadas (sin toLocaleString en JS)
    public string TotalFormateado => Total.ToString("C0", new CultureInfo("es-CL"));
    public string CodigosTexto => string.Join(", ", Codigos);
}

/// <summary>
/// Detalle de un movimiento individual
/// </summary>
public class DetalleMovimiento
{
    public string Codigo { get; set; } = "";
    public string Descripcion { get; set; } = "";
    public decimal Saldo { get; set; }

    // Formateado server-side
    public string SaldoFormateado => Saldo.ToString("C0", new CultureInfo("es-CL"));
}
