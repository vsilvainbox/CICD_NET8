using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using App.Helpers;

namespace App.Features.BalanceClasificado;

/// <summary>
/// MVC Controller para vistas de Balance Clasificado.
/// Patrón: JavaScript + API Directo (form.md)
/// Solo renderiza la vista. JavaScript llama directamente al ApiController.
/// </summary>
[Authorize]
public class BalanceClasificadoController : Controller
{
    /// <summary>
    /// Vista principal del balance clasificado
    /// GET /BalanceClasificado
    /// </summary>
    [HttpGet]
    public IActionResult Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder al Balance Clasificado";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        var ano = SessionHelper.Ano;
        var viewModel = new BalanceClasificadoIndexViewModel
        {
            EmpresaId = SessionHelper.EmpresaId,
            Ano = (short)ano,
            FechaDesde = new DateTime(ano, 1, 1),
            FechaCorte = new DateTime(ano, 12, 31)
        };

        return View(viewModel);
    }

    // R19: Los métodos proxy fueron eliminados.
    // JavaScript llama directamente al BalanceClasificadoApiController
    // usando URLs con @Url.Action("Action", "BalanceClasificadoApi")
}