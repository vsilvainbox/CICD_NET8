# BalanceClasificado - Análisis VB6 - PARTE 2: EVENT HANDLERS Y VALIDACIONES

**Continúa de:** `Analysis-Part1-Structure.md`

---

## 🎬 EVENT HANDLERS CRÍTICOS

### Bt_Buscar_Click() - GENERAR REPORTE

```vb6
Private Sub Bt_Buscar_Click()
  Dim F1 As Long, F2 As Long
  
  ' 1. Obtener fechas
  F1 = GetTxDate(Tx_Desde)
  F2 = GetTxDate(Tx_Hasta)
  
  ' 2. VALIDACIÓN: Fecha inicio <= Fecha término
  If F1 > F2 Then
    MsgBox1 "Fecha de inicio es posterior a la fecha de término del reporte.", _
            vbExclamation
    Tx_Hasta.SetFocus
    Exit Sub
  End If
  
  ' 3. VALIDACIÓN: Fecha inicio pertenece al año actual
  If Year(F1) <> gEmpresa.Ano Then
    MsgBox1 "La fecha de inicio no corresponde al periodo actual.", _
            vbExclamation
    Exit Sub
  End If
  
  ' 4. VALIDACIÓN: Fecha término pertenece al año actual
  If Year(F2) <> gEmpresa.Ano Then
    MsgBox1 "La fecha de término no corresponde al periodo actual.", _
            vbExclamation
    Exit Sub
  End If
  
  ' 5. Ejecutar carga de datos
  MousePointer = vbHourglass
  Call LoadAll  ' Ver PARTE 3
  MousePointer = vbDefault
End Sub
```

**Mapeo .NET:**
```csharp
// BalanceClasificadoService.GenerarBalanceAsync()
// Validation logic:
if (request.FechaDesde > request.FechaHasta)
    return ValidationResult("Fecha inicio posterior a término");
if (request.FechaDesde.Year != request.Ano || request.FechaHasta.Year != request.Ano)
    return ValidationResult("Fechas deben pertenecer al período");
```

---

### Bt_Print_Click() - IMPRESIÓN CON REGISTRO OFICIAL

```vb6
Private Sub Bt_Print_Click()
  Dim OldOrientacion As Integer
  Dim Frm As FrmPrtSetup
  Dim Fecha As Long
  Dim Usuario As String
  Dim FDesde As Long, FHasta As Long
  Dim Pag As Integer
  
  lPapelFoliado = False
  
  ' 1. VALIDACIÓN: Debe haber listado datos
  If Bt_Buscar.Enabled = True Then
    MsgBox1 "Presione el botón Listar antes de imprimir.", vbExclamation
    Exit Sub
  End If
  
  ' 2. ADVERTENCIA: Reporte mensual puede no caber
  If lMensual And Not lComparativo Then
    If MsgBox1("Es muy probable que al imprimir este informe no quepan " & _
               "todas las columnas." & vbLf & vbLf & _
               "Se sugiere copiarlo a Excel e imprimirlo desde ahí.", _
               vbInformation + vbOKCancel) = vbCancel Then
      Exit Sub
    End If
  End If
  
  ' 3. VERIFICACIÓN LIBRO OFICIAL: Ya se imprimió antes?
  If Ch_LibOficial.visible = True And Ch_LibOficial <> 0 Then
    If QryLogImpreso(lLibOf, 0, FDesde, FHasta, Fecha, Usuario) = True Then
      If MsgBox1("El " & gLibroOficial(lLibOf) & " Oficial ya ha sido " & _
                 "impreso en papel foliado el día " & Format(Fecha, DATEFMT) & _
                 " por el usuario " & Usuario & ", para el período " & _
                 "comprendido entre el " & Format(FDesde, DATEFMT) & _
                 " y el " & Format(FHasta, DATEFMT) & "." & vbNewLine & _
                 vbNewLine & "¿Desea continuar?", _
                 vbQuestion + vbYesNo) = vbNo Then
        Exit Sub
      End If
    End If
    lPapelFoliado = True
  End If
  
  ' 4. Mostrar diálogo configuración impresión
  Set Frm = New FrmPrtSetup
  If Frm.FEdit(lOrientacion, lPapelFoliado, lInfoPreliminar) = vbOK Then
    OldOrientacion = Printer.Orientation
    
    MousePointer = vbHourglass
    
    ' 5. Preparar grid para impresión
    Call SetUpPrtGrid
    
    gPrtLibros.CallEndDoc = False
    
    If lMensual Then
      gPrtLibros.PermitirMasDe1Franja = True
    End If
    
    ' 6. Imprimir a impresora
    Pag = gPrtLibros.PrtFlexGrid(Printer)
    
    ' 7. Pie con firma y folio
    Dim NumFolio As Integer
    NumFolio = 0
    If lPapelFoliado Then
      NumFolio = gPrtLibros.NumPagIni
    End If
    Call PrtPieBalanceFirma(Printer, Pag, gPrtLibros.GrLeft, _
                            gPrtLibros.GrRight, NumFolio)
    
    ' 8. Finalizar impresión
    gPrtLibros.CallEndDoc = True
    gPrtLibros.PermitirMasDe1Franja = False
    
    Printer.EndDoc
    Printer.Orientation = OldOrientacion
    
    ' 9. REGISTRAR IMPRESIÓN OFICIAL
    If lPapelFoliado Then
      FDesde = GetTxDate(Tx_Desde)
      FHasta = GetTxDate(Tx_Hasta)
      Call AddLogImpresion(lLibOf, 0, FDesde, FHasta, gPrtLibros.NumPagIni, _
                          gPrtLibros.NumPagFin, gUsuario.Nombre)
    End If
    
    MousePointer = vbDefault
  End If
  
  Set Frm = Nothing
  Call ResetPrtBas(gPrtLibros)
End Sub
```

**Funciones Críticas:**
```vb6
' QryLogImpreso: Verifica si libro ya fue impreso
Function QryLogImpreso(IdLibro, Mes, ByRef FDesde, ByRef FHasta, _
                       ByRef Fecha, ByRef Usuario) As Boolean
  Q1 = "SELECT * FROM LogImpresion"
  Q1 = Q1 & " WHERE IdLibro=" & IdLibro & " AND IdEmpresa=" & gEmpresa.Id
  Q1 = Q1 & " AND Ano=" & gEmpresa.Ano
  If Mes > 0 Then Q1 = Q1 & " AND Mes=" & Mes
  ' Retorna TRUE si existe registro
End Function

' AddLogImpresion: Registra impresión oficial
Sub AddLogImpresion(IdLibro, Mes, FDesde, FHasta, NumPagIni, NumPagFin, Usuario)
  Q1 = "INSERT INTO LogImpresion (IdLibro, IdEmpresa, Ano, Mes, " & _
       "FechaDesde, FechaHasta, Fecha, Usuario, NumPagIni, NumPagFin) VALUES (" & _
       IdLibro & "," & gEmpresa.Id & "," & gEmpresa.Ano & "," & Mes & "," & _
       FDesde & "," & FHasta & "," & CLng(Now) & ",'" & Usuario & "'," & _
       NumPagIni & "," & NumPagFin & ")"
  Call ExecSQL(DbMain, Q1)
End Sub
```

**Mapeo .NET:**
```csharp
// LibroOficialService.VerificarImpresionPrevia()
// LibroOficialService.RegistrarImpresionOficial()
// Tabla: LogImpresion
// Campos: IdLibro, IdEmpresa, Ano, Mes, FechaDesde, FechaHasta, 
//         Fecha, Usuario, NumPagIni, NumPagFin
```

---

### Bt_Preview_Click() - VISTA PREVIA

```vb6
Private Sub Bt_Preview_Click()
  Dim Frm As FrmPrintPreview
  Dim Pag As Integer
  
  ' 1. VALIDACIÓN: Debe haber listado datos
  If Bt_Buscar.Enabled = True Then
    MsgBox1 "Presione el botón Listar antes de seleccionar " & _
            "la vista previa.", vbExclamation
    Exit Sub
  End If
  
  ' 2. Configurar impresión sin papel foliado
  lPapelFoliado = False
  Call SetUpPrtGrid
  
  ' 3. Crear formulario preview
  Set Frm = Nothing
  Set Frm = New FrmPrintPreview
  
  Me.MousePointer = vbHourglass
  gPrtLibros.CallEndDoc = False
  
  If lMensual Then
    gPrtLibros.PermitirMasDe1Franja = True
  End If
  
  ' 4. Generar preview (no imprime, genera imagen)
  Pag = gPrtLibros.PrtFlexGrid(Frm)
  
  ' 5. Pie sin número de folio
  Call PrtPieBalanceFirma(Frm, Pag, gPrtLibros.GrLeft, _
                          gPrtLibros.GrRight, 0)
  
  gPrtLibros.CallEndDoc = True
  gPrtLibros.PermitirMasDe1Franja = False
  
  Set Frm.PrtControl = Bt_Print
  Me.MousePointer = vbDefault
  
  ' 6. Mostrar preview modal
  Call Frm.FView(Caption)
  Set Frm = Nothing
  
  Call ResetPrtBas(gPrtLibros)
End Sub
```

---

### Bt_VerLibMayor_Click() - NAVEGACIÓN A DETALLE

```vb6
Private Sub Bt_VerLibMayor_Click()
  Dim Frm As FrmLibMayor
  Dim lIdCuenta As Long
  Dim FDesde As Long, FHasta As Long
  
  ' Validar que hay cuenta seleccionada
  If Val(Grid.TextMatrix(Grid.Row, C_IDCUENTA)) > 0 Then
    lIdCuenta = Val(Grid.TextMatrix(Grid.Row, C_IDCUENTA))
    Set Frm = New FrmLibMayor
    
    FDesde = GetTxDate(Tx_Desde)
    FHasta = GetTxDate(Tx_Hasta)
    
    ' Abrir Libro Mayor con filtros actuales
    Call Frm.FView(lIdCuenta, FDesde, FHasta)
  End If
End Sub
```

**Mapeo .NET:**
```csharp
// Navegación a /LibroMayor?idCuenta={id}&desde={fecha}&hasta={fecha}
```

---

### Grid_DblClick() - ACCIÓN DOBLE CLICK

```vb6
Private Sub Grid_DblClick()
  ' Al hacer doble click en cuenta, abre Libro Mayor
  Call Bt_VerLibMayor_Click
End Sub
```

---

### Eventos de ComboBoxes - SIN ACCIÓN

```vb6
Private Sub Cb_Nivel_Click()
  ' No hace nada, requiere Bt_Buscar
End Sub

Private Sub Cb_TipoAjuste_Click()
  ' No hace nada, requiere Bt_Buscar
End Sub

Private Sub Cb_AreaNeg_Click()
  ' No hace nada, requiere Bt_Buscar
End Sub

Private Sub Cb_CCosto_Click()
  ' No hace nada, requiere Bt_Buscar
End Sub
```

---

### Eventos de TextBoxes - VALIDACIÓN FECHA

```vb6
Private Sub tx_Desde_Change()
  ' Habilita botón Buscar cuando cambia fecha
  Bt_Buscar.Enabled = True
End Sub

Private Sub Tx_Desde_GotFocus()
  ' Selecciona todo el texto
  Tx_Desde.SelStart = 0
  Tx_Desde.SelLength = Len(Tx_Desde)
End Sub

Private Sub Tx_Desde_LostFocus()
  ' Valida formato fecha
  Dim F1 As Long
  F1 = GetTxDate(Tx_Desde)
  If F1 < 0 Then
    MsgBox1 "Fecha no válida", vbExclamation
    Tx_Desde.SetFocus
  Else
    Call SetTxDate(Tx_Desde, F1)  ' Reformatea
  End If
End Sub

Private Sub Tx_Desde_KeyPress(KeyAscii As Integer)
  ' Solo permite números y /
  Call KeyNumPos(KeyAscii)
End Sub

' Eventos idénticos para Tx_Hasta:
Private Sub tx_Hasta_Change()
Private Sub Tx_Hasta_GotFocus()
Private Sub Tx_Hasta_LostFocus()
Private Sub Tx_Hasta_KeyPress(KeyAscii As Integer)
```

---

## ✅ VALIDACIONES COMPLETAS

### Validaciones de Fecha (Bt_Buscar)

| Validación | Condición | Mensaje Error | Acción |
|-----------|-----------|---------------|--------|
| Orden cronológico | `FDesde > FHasta` | "Fecha de inicio es posterior a la fecha de término del reporte." | `Tx_Hasta.SetFocus; Exit Sub` |
| Fecha inicio en período | `Year(FDesde) <> gEmpresa.Ano` | "La fecha de inicio no corresponde al periodo actual." | `Exit Sub` |
| Fecha término en período | `Year(FHasta) <> gEmpresa.Ano` | "La fecha de término no corresponde al periodo actual." | `Exit Sub` |

**Mapeo .NET:**
```csharp
if (request.FechaDesde > request.FechaHasta)
    return new ValidationResult { IsValid = false, Message = "Fecha de inicio es posterior a la fecha de término del reporte." };
if (request.FechaDesde.Year != request.Ano)
    return new ValidationResult { IsValid = false, Message = "La fecha de inicio no corresponde al periodo actual." };
if (request.FechaHasta.Year != request.Ano)
    return new ValidationResult { IsValid = false, Message = "La fecha de término no corresponde al periodo actual." };
```

### Validaciones de Estado Previo

| Validación | Condición | Mensaje | Acción |
|-----------|-----------|---------|--------|
| Datos listados (Preview) | `Bt_Buscar.Enabled = True` | "Presione el botón Listar antes de seleccionar la vista previa." | `Exit Sub` |
| Datos listados (Print) | `Bt_Buscar.Enabled = True` | "Presione el botón Listar antes de imprimir." | `Exit Sub` |
| Datos listados (Excel) | `Bt_Buscar.Enabled = True` | "Presione el botón Listar antes de copiar." | `Exit Sub` |

**Mapeo .NET:**
```csharp
// UI: Deshabilitar botones Export/Print hasta que se ejecute GetAllAsync()
```

### Validación Libro Oficial (Bt_Print)

```vb6
' Paso 1: Verificar si ya se imprimió
If Ch_LibOficial <> 0 Then
  If QryLogImpreso(lLibOf, 0, FDesde, FHasta, Fecha, Usuario) = True Then
    ' Mensaje de confirmación con detalles de impresión previa
    If MsgBox1("El [Libro] ya ha sido impreso en papel foliado el día [Fecha] " & _
               "por el usuario [Usuario], para el período entre [FDesde] y [FHasta]." & _
               vbNewLine & vbNewLine & "¿Desea continuar?", _
               vbQuestion + vbYesNo) = vbNo Then
      Exit Sub
    End If
  End If
  lPapelFoliado = True
End If
```

**Mapeo .NET:**
```csharp
if (request.LibroOficial)
{
    var logPrevio = await _context.LogImpresion
        .Where(l => l.IdLibro == LIBOF_BALANCEGRAL && 
                    l.IdEmpresa == empresaId && 
                    l.Ano == ano)
        .OrderByDescending(l => l.Fecha)
        .FirstOrDefaultAsync();
    
    if (logPrevio != null)
    {
        // Retornar warning al usuario para confirmación
        return new ValidationResult 
        { 
            IsValid = false, 
            RequiresConfirmation = true,
            Message = $"El Balance General Oficial ya ha sido impreso..." 
        };
    }
}
```

### Advertencia Mensual (Bt_Print)

```vb6
If lMensual And Not lComparativo Then
  If MsgBox1("Es muy probable que al imprimir este informe no quepan " & _
             "todas las columnas. Se sugiere copiarlo a Excel e " & _
             "imprimirlo desde ahí.", vbInformation + vbOKCancel) = vbCancel Then
    Exit Sub
  End If
End If
```

**Mapeo .NET:**
```csharp
// UI Warning en frontend antes de print
if (opciones.Mensual && !opciones.Comparativo)
    showWarning("Es muy probable que no quepan todas las columnas. " +
                "Se sugiere exportar a Excel.");
```

---

## 🔧 FUNCIONES AUXILIARES

### SetUpGrid - Configuración Inicial

```vb6
Private Sub SetUpGrid()
  Grid.Redraw = False
  Grid.Cols = 9
  Grid.FixedCols = 0
  Grid.rows = 1
  Grid.FixedRows = 1
  
  ' Encabezados
  Grid.TextMatrix(0, C_CODIGO) = "Código"
  Grid.TextMatrix(0, C_CUENTA) = "Cuenta"
  Grid.TextMatrix(0, C_DEBITOS) = "Débitos"
  Grid.TextMatrix(0, C_CREDITOS) = "Créditos"
  Grid.TextMatrix(0, C_SALDO) = "Saldo"
  
  ' Anchos de columna
  Grid.ColWidth(C_IDCUENTA) = 0      ' Oculta
  Grid.ColWidth(C_CODIGO) = 1500
  Grid.ColWidth(C_CUENTA) = 3500
  Grid.ColWidth(C_DEBITOS) = 1400
  Grid.ColWidth(C_CREDITOS) = 1400
  Grid.ColWidth(C_SALDO) = 1400
  Grid.ColWidth(C_NIVEL) = 0         ' Oculta
  Grid.ColWidth(C_CLASCTA) = 0       ' Oculta
  Grid.ColWidth(C_FMT) = 0           ' Oculta
  
  ' Alineación
  Grid.ColAlignment(C_CODIGO) = flexAlignLeftCenter
  Grid.ColAlignment(C_CUENTA) = flexAlignLeftCenter
  Grid.ColAlignment(C_DEBITOS) = flexAlignRightCenter
  Grid.ColAlignment(C_CREDITOS) = flexAlignRightCenter
  Grid.ColAlignment(C_SALDO) = flexAlignRightCenter
  
  Grid.Redraw = True
End Sub
```

### EnableFrm - Habilitar/Deshabilitar Controles

```vb6
Private Sub EnableFrm(bool As Boolean)
  ' Durante LoadAll, deshabilita todo para evitar cambios
  Tx_Desde.Enabled = bool
  Tx_Hasta.Enabled = bool
  Cb_Nivel.Enabled = bool
  Cb_TipoAjuste.Enabled = bool
  Cb_AreaNeg.Enabled = bool
  Cb_CCosto.Enabled = bool
  Ch_LibOficial.Enabled = bool
  Bt_Buscar.Enabled = bool
  ' Etc...
End Sub
```

### ReadResEje - Leer Resultado Ejercicio Anterior

```vb6
Private Sub ReadResEje()
  ' Lee resultado del ejercicio anterior para Balance Clasificado
  ' Se usa en AddResEjercicio() durante LoadAll
  ' Query a tabla de configuración/cierre del año anterior
End Sub
```

### SetupPriv - Aplicar Privilegios Usuario

```vb6
Private Sub SetupPriv()
  ' Aplica privilegios de usuario (permisos)
  ' Puede ocultar/deshabilitar botones según rol
  If Not gUsuario.PrivImpLibOficial Then
    Ch_LibOficial.Enabled = False
  End If
End Sub
```

---

**CONTINÚA EN:** `Analysis-Part3-LoadAll.md`

_(Siguiente parte documentará el procedimiento LoadAll completo con GenQueryPorNiveles)_
