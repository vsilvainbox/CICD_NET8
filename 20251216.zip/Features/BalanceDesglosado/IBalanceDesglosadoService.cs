﻿namespace App.Features.BalanceDesglosado;

/// <summary>
/// Interface para el servicio de Balance Desglosado
/// </summary>
public interface IBalanceDesglosadoService
{
    /// <summary>
    /// Genera el balance desglosado según los filtros especificados
    /// </summary>
    Task<BalanceDesglosadoResponse> GenerarBalanceAsync(BalanceDesglosadoRequest request);

    /// <summary>
    /// Obtiene las opciones de filtros disponibles (niveles, tipos de ajuste, desgloses)
    /// </summary>
    Task<BalanceDesglosadoOpciones> GetOpcionesFiltrosAsync(int empresaId, short ano, string tipoDesglose);

    /// <summary>
    /// Exporta el balance desglosado a Excel
    /// </summary>
    Task<BalanceDesglosadoExportResult> ExportarExcelAsync(BalanceDesglosadoRequest request);

    /// <summary>
    /// Valida los filtros del request
    /// </summary>
    Task<(bool IsValid, List<string> Errors)> ValidarFiltrosAsync(BalanceDesglosadoRequest request);
}