using Microsoft.EntityFrameworkCore;
using System.Text.Json;
using App.Data;
using App.Models.Auth;

namespace App.Features.Auth.Services;

public class SessionService(
    LpContabContext context,
    IHttpContextAccessor httpContextAccessor,
    IAuthService authService,
    ILogger<SessionService> logger) : ISessionService
{
    public async Task<SessionData> GetSessionDataAsync()
    {
        var httpContext = httpContextAccessor.HttpContext;
        if (httpContext == null)
            return new SessionData();

        var sessionData = new SessionData();

        // Obtener usuario desde Claims
        sessionData.Usuario = await authService.GetUsuarioActualAsync();

        // Obtener empresa desde Session (si se usa para datos temporales)
        var empresaJson = httpContext.Session.GetString("EmpresaActual");
        if (!string.IsNullOrEmpty(empresaJson))
        {
            sessionData.Empresa = JsonSerializer.Deserialize<EmpresaSession>(empresaJson);
        }

        return sessionData;
    }

    public async Task<List<EmpresaDto>> GetEmpresasUsuarioAsync(int idUsuario)
    {
        var usuario = await context.Usuarios.FirstOrDefaultAsync(u => u.IdUsuario == idUsuario);
        if (usuario == null)
            return new List<EmpresaDto>();

        List<EmpresaDto> empresas;

        if (usuario.PrivAdm != 0) // Es administrador
        {
            empresas = await context.Empresas
                .Where(e => e.Estado != 1)
                .Select(e => new EmpresaDto
                {
                    IdEmpresa = e.IdEmpresa,
                    Rut = e.Rut ?? string.Empty,
                    NombreCorto = e.NombreCorto ?? string.Empty
                })
                .ToListAsync();
        }
        else
        {
            // Query optimizada: JOIN con Perfiles para evitar N+1
            empresas = await (
                from ue in context.UsuarioEmpresa
                join e in context.Empresas on ue.idEmpresa equals e.IdEmpresa
                join p in context.Perfiles on ue.idPerfil equals p.IdPerfil into perfilGroup
                from perfil in perfilGroup.DefaultIfEmpty()
                where ue.idUsuario == idUsuario && e.Estado != 1
                select new EmpresaDto
                {
                    IdEmpresa = e.IdEmpresa,
                    Rut = e.Rut ?? string.Empty,
                    NombreCorto = e.NombreCorto ?? string.Empty,
                    IdPerfil = ue.idPerfil,
                    NombrePerfil = perfil != null ? perfil.Nombre : null
                })
                .ToListAsync();
        }

        foreach (var empresa in empresas)
        {
            empresa.AnosDisponibles = await context.EmpresasAno
                .Where(ea => ea.idEmpresa == empresa.IdEmpresa)
                .OrderByDescending(ea => ea.Ano)
                .Select(ea => ea.Ano)
                .ToListAsync();
        }

        return empresas;
    }

    public async Task<List<short>> GetAnosEmpresaAsync(int idEmpresa)
    {
        return await context.EmpresasAno
            .Where(ea => ea.idEmpresa == idEmpresa)
            .OrderByDescending(ea => ea.Ano)
            .Select(ea => ea.Ano)
            .ToListAsync();
    }

    public async Task<bool> SeleccionarEmpresaAnoAsync(int idEmpresa, short ano)
    {
        var httpContext = httpContextAccessor.HttpContext;
        if (httpContext == null)
            return false;

        var usuario = await authService.GetUsuarioActualAsync();
        if (usuario == null)
        {
            logger.LogWarning("No authenticated user found when selecting empresa");
            return false;
        }

        // Validar acceso (si no es admin)
        if (!usuario.EsAdmin)
        {
            var acceso = await context.UsuarioEmpresa
                .FirstOrDefaultAsync(ue => ue.idUsuario == usuario.IdUsuario
                                        && ue.idEmpresa == idEmpresa);

            if (acceso == null)
            {
                logger.LogWarning("User {IdUsuario} attempted to access unauthorized empresa {IdEmpresa}",
                    usuario.IdUsuario, idEmpresa);
                return false;
            }

            if (acceso.idPerfil.HasValue)
            {
                var perfil = await context.Perfiles
                    .FirstOrDefaultAsync(p => p.IdPerfil == acceso.idPerfil.Value);

                if (perfil != null)
                {
                    usuario.PrivilegiosActuales = perfil.Privilegios ?? 0;
                    usuario.NombrePerfilActual = perfil.Nombre;
                    usuario.IdPerfilActual = perfil.IdPerfil;
                }
                else
                {
                    usuario.PrivilegiosActuales = 0;
                }
            }
            else
            {
                usuario.PrivilegiosActuales = 0;
            }
        }
        else
        {
            usuario.PrivilegiosActuales = int.MaxValue;
            usuario.NombrePerfilActual = "Administrador";
            usuario.IdPerfilActual = null;
        }

        var empresa = await context.Empresas
            .FirstOrDefaultAsync(e => e.IdEmpresa == idEmpresa);

        if (empresa == null)
        {
            logger.LogWarning("Empresa {IdEmpresa} not found", idEmpresa);
            return false;
        }

        var empresaAno = await context.EmpresasAno
            .FirstOrDefaultAsync(ea => ea.idEmpresa == idEmpresa && ea.Ano == ano);

        if (empresaAno == null)
        {
            logger.LogWarning("Empresa {IdEmpresa} año {Ano} not found", idEmpresa, ano);
            return false;
        }

        var empresaSession = new EmpresaSession
        {
            IdEmpresa = empresa.IdEmpresa,
            Rut = empresa.Rut ?? string.Empty,
            NombreCorto = empresa.NombreCorto ?? string.Empty,
            Ano = ano,
            FCierre = ConvertirVB6Date(empresaAno.FCierre),
            FApertura = ConvertirVB6Date(empresaAno.FApertura)
        };

        // Guardar en sesión (para datos adicionales como FCierre, FApertura)
        httpContext.Session.SetString("EmpresaActual", JsonSerializer.Serialize(empresaSession));
        httpContext.Session.SetString("UsuarioActual", JsonSerializer.Serialize(usuario));
        await httpContext.Session.CommitAsync();

        logger.LogInformation("Empresa seleccionada: User {IdUsuario} → Empresa {IdEmpresa} ({NombreCorto}) Año {Ano}",
            usuario.IdUsuario, idEmpresa, empresa.NombreCorto, ano);

        return true;
    }

    public async Task<int> GetPrivilegiosAsync(int idUsuario, int idEmpresa)
    {
        var usuario = await context.Usuarios.FirstOrDefaultAsync(u => u.IdUsuario == idUsuario);
        if (usuario == null)
            return 0;

        if (usuario.PrivAdm != 0)
            return int.MaxValue;

        var usuarioEmpresa = await context.UsuarioEmpresa
            .FirstOrDefaultAsync(ue => ue.idUsuario == idUsuario && ue.idEmpresa == idEmpresa);

        if (usuarioEmpresa?.idPerfil == null)
            return 0;

        var perfil = await context.Perfiles
            .FirstOrDefaultAsync(p => p.IdPerfil == usuarioEmpresa.idPerfil.Value);

        return perfil?.Privilegios ?? 0;
    }

    public void LimpiarSeleccionEmpresa()
    {
        var httpContext = httpContextAccessor.HttpContext;
        if (httpContext != null)
        {
            httpContext.Session.Remove("EmpresaActual");
            httpContext.Session.Remove("UsuarioActual");
            logger.LogInformation("Session cleared: EmpresaActual and UsuarioActual removed");
        }
    }

    private DateTime? ConvertirVB6Date(int? serialDate)
    {
        if (!serialDate.HasValue || serialDate.Value == 0)
            return null;

        return new DateTime(1899, 12, 30).AddDays(serialDate.Value);
    }
}
