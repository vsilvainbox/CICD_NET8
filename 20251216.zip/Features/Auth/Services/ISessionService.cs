﻿using App.Models.Auth;

namespace App.Features.Auth.Services;

/// <summary>
/// Servicio de gestión de sesión de empresa/año
/// Replica la funcionalidad de FrmSelEmpresas_resp.frm (VB6)
/// </summary>
public interface ISessionService
{
    /// <summary>
    /// Obtiene los datos completos de la sesión actual
    /// </summary>
    Task<SessionData> GetSessionDataAsync();

    /// <summary>
    /// Obtiene lista de empresas disponibles para el usuario
    /// </summary>
    Task<List<EmpresaDto>> GetEmpresasUsuarioAsync(int idUsuario);

    /// <summary>
    /// Obtiene lista de años disponibles para una empresa
    /// </summary>
    Task<List<short>> GetAnosEmpresaAsync(int idEmpresa);

    /// <summary>
    /// Selecciona empresa y año para la sesión
    /// </summary>
    Task<bool> SeleccionarEmpresaAnoAsync(int idEmpresa, short ano);

    /// <summary>
    /// Obtiene privilegios del usuario para una empresa
    /// </summary>
    Task<int> GetPrivilegiosAsync(int idUsuario, int idEmpresa);

    /// <summary>
    /// Limpia la selección de empresa/año
    /// </summary>
    void LimpiarSeleccionEmpresa();
}

public class EmpresaDto
{
    public int IdEmpresa { get; set; }
    public string Rut { get; set; } = string.Empty;
    public string NombreCorto { get; set; } = string.Empty;
    public int? IdPerfil { get; set; }
    public string? NombrePerfil { get; set; }
    public List<short> AnosDisponibles { get; set; } = new();
}
