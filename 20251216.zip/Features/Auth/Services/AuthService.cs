using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Security.Claims;
using System.Text.Json;
using App.Data;
using App.Models.Auth;
using App.Exceptions;

namespace App.Features.Auth.Services;

public class AuthService(
    LpContabContext context,
    IPasswordService passwordService,
    IHttpContextAccessor httpContextAccessor,
    ILogger<AuthService> logger) : IAuthService
{
    public async Task<LoginResult> LoginAsync(string username, string password)
    {
        // Validaciones de parámetros
        if (string.IsNullOrEmpty(username))
            throw new BusinessException("El usuario es requerido");

        if (string.IsNullOrEmpty(password))
            throw new BusinessException("La contraseña es requerida");

        username = username.ToLower().Trim();

        var usuario = await context.Usuarios
            .FirstOrDefaultAsync(u => u.Usuario == username);

        if (usuario == null)
        {
            logger.LogWarning("Login attempt for non-existent user: {Username}", username);
            return LoginResult.Fail("Usuario o contraseña incorrectos");
        }

        // Validar activo (SQL Server usa bool)
        if (usuario.Activo == false || usuario.Activo == null)
        {
            logger.LogWarning("Login attempt for inactive user: {Username} (Activo={Activo})", username, usuario.Activo);
            return LoginResult.Fail("Usuario no activo");
        }

        logger.LogInformation("User {Username} active status: Activo={Activo}", username, usuario.Activo);

        // Validar fecha expiración
        if (usuario.HabilitadoHasta.HasValue && usuario.HabilitadoHasta.Value > 0)
        {
            var fechaExpiracion = ConvertirVB6Date(usuario.HabilitadoHasta.Value);
            if (DateTime.Now > fechaExpiracion)
            {
                logger.LogWarning("Login attempt for expired user: {Username}", username);
                await DesactivarUsuarioAsync(usuario.IdUsuario);
                return LoginResult.Fail("Usuario expirado");
            }
        }

        // Validar password (híbrido VB6/bcrypt)
        var validationResult = await passwordService.ValidatePasswordAsync(usuario, password);

        if (!validationResult.IsValid)
        {
            logger.LogWarning("Failed login attempt for user: {Username}", username);
            return LoginResult.Fail("Usuario o contraseña incorrectos");
        }

        // Migrar si necesario (transparente para usuario)
        if (validationResult.RequiresMigration)
        {
            logger.LogInformation("Auto-migrating password for user: {Username}", username);
            await passwordService.MigrarPasswordAsync(usuario.IdUsuario, password);
        }

        // Crear sesión
        var esAdmin = usuario.PrivAdm == 1;

        logger.LogInformation("Login: Usuario={Usuario}, IdUsuario ={IdUsuario}, PrivAdm={PrivAdm}, EsAdmin={EsAdmin}",
            usuario.Usuario, usuario.IdUsuario, usuario.PrivAdm, esAdmin);

        var usuarioSession = new UsuarioSession
        {
            IdUsuario = usuario.IdUsuario,
            Usuario = usuario.Usuario ?? string.Empty,
            NombreLargo = usuario.NombreLargo,
            EsAdmin = esAdmin,
            // Admin tiene privilegios totales
            PrivilegiosActuales = esAdmin ? int.MaxValue : 0
        };

        // Guardar usuario en cookie Claims (persistente)
        var httpContext = httpContextAccessor.HttpContext;
        if (httpContext != null)
        {
            var usuarioJson = JsonSerializer.Serialize(usuarioSession);

            var claims = new List<Claim>
            {
                new(ClaimTypes.NameIdentifier, usuario.IdUsuario.ToString()),
                new(ClaimTypes.Name, usuario.Usuario ?? string.Empty),
                new(ClaimTypes.GivenName, usuario.NombreLargo ?? string.Empty),
                new("EsAdmin", usuarioSession.EsAdmin.ToString()),
                new("UsuarioData", usuarioJson)
            };

            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            var principal = new ClaimsPrincipal(identity);

            await httpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                principal,
                new AuthenticationProperties
                {
                    IsPersistent = true,
                    ExpiresUtc = DateTimeOffset.UtcNow.AddDays(7)
                });

            logger.LogInformation("Login successful for user: {Username}", username);
        }

        return LoginResult.Succeed(usuarioSession);
    }

    public async Task LogoutAsync()
    {
        var httpContext = httpContextAccessor.HttpContext;
        if (httpContext != null)
        {
            await httpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            httpContext.Session.Clear();

            logger.LogInformation("User logged out successfully");
        }
    }

    public async Task<bool> CambiarPasswordAsync(int idUsuario, string oldPassword, string newPassword)
    {
        // Validaciones de parámetros
        if (idUsuario <= 0)
            throw new BusinessException("El ID de usuario es inválido");

        if (string.IsNullOrEmpty(oldPassword))
            throw new BusinessException("La contraseña actual es requerida");

        if (string.IsNullOrEmpty(newPassword))
            throw new BusinessException("La nueva contraseña es requerida");

        var usuario = await context.Usuarios.FirstOrDefaultAsync(u => u.IdUsuario == idUsuario);
        if (usuario == null)
            return false;

        // Validar password actual
        var validationResult = await passwordService.ValidatePasswordAsync(usuario, oldPassword);
        if (!validationResult.IsValid)
            return false;

        // Actualizar con bcrypt
        usuario.PasswordHash = passwordService.HashPassword(newPassword);
        usuario.RequiereCambioPassword = false;

        await context.SaveChangesAsync();

        logger.LogInformation("Password changed successfully for user {IdUsuario}", idUsuario);
        return true;
    }

    public Task<UsuarioSession?> GetUsuarioActualAsync()
    {
        var httpContext = httpContextAccessor.HttpContext;
        if (httpContext == null)
        {
            return Task.FromResult<UsuarioSession?>(null);
        }

        // Leer desde Claims (cookie persistente)
        var user = httpContext.User;
        if (user?.Identity?.IsAuthenticated == true)
        {
            var usuarioDataClaim = user.FindFirst("UsuarioData");
            if (usuarioDataClaim != null)
            {
                return Task.FromResult(JsonSerializer.Deserialize<UsuarioSession>(usuarioDataClaim.Value));
            }
        }

        return Task.FromResult<UsuarioSession?>(null);
    }

    // Métodos auxiliares
    private DateTime? ConvertirVB6Date(int serialDate)
    {
        if (serialDate == 0)
            return null;

        return new DateTime(1899, 12, 30).AddDays(serialDate);
    }

    private async Task DesactivarUsuarioAsync(int idUsuario)
    {
        var usuario = await context.Usuarios.FindAsync(idUsuario);
        if (usuario != null)
        {
            usuario.Activo = false;
            await context.SaveChangesAsync();
        }
    }
}
