namespace App.Features.Auth.Models;

/// <summary>
/// Enumeración de privilegios del sistema (bitflags)
/// Replica PRV_* constants de VB6
/// </summary>
[Flags]
public enum Privilegios
{
    None = 0,
    Admin = -1,                         // Admin total (VB6: -1)
    
    // Privilegios específicos (bitflags)
    ImprimirLibrosOficiales = 1 << 0,   // 0x1
    ModificarAsientos = 1 << 1,          // 0x2
    EliminarDocumentos = 1 << 2,         // 0x4
    VerInformes = 1 << 3,                // 0x8
    IngresarComprobantes = 1 << 4,       // 0x10
    AdministrarComprobantes = 1 << 5,    // 0x20
    IngresarDocumentos = 1 << 6,         // 0x40
    VerInformacion = 1 << 7,             // 0x80
    ConfigurarEmpresa = 1 << 8,          // 0x100
    AdministrarSistema = 1 << 9,         // 0x200
    ImprimirLibrosOficialesExt = 1 << 10 // 0x400
}

/// <summary>
/// Helper para verificar privilegios
/// </summary>
public static class PrivilegiosHelper
{
    /// <summary>
    /// Verifica si un usuario tiene un privilegio específico
    /// </summary>
    public static bool TienePrivilegio(int privilegiosUsuario, Privilegios privilegio)
    {
        // Admin tiene todos los privilegios
        if (privilegiosUsuario == -1)
            return true;

        // Verificar bitflag específico
        return (privilegiosUsuario & (int)privilegio) != 0;
    }

    /// <summary>
    /// Verifica si un usuario tiene alguno de varios privilegios
    /// </summary>
    public static bool TieneAlgunPrivilegio(int privilegiosUsuario, params Privilegios[] privilegios)
    {
        if (privilegiosUsuario == -1)
            return true;

        foreach (var privilegio in privilegios)
        {
            if ((privilegiosUsuario & (int)privilegio) != 0)
                return true;
        }

        return false;
    }

    /// <summary>
    /// Verifica si un usuario tiene todos los privilegios especificados
    /// </summary>
    public static bool TieneTodosLosPrivilegios(int privilegiosUsuario, params Privilegios[] privilegios)
    {
        if (privilegiosUsuario == -1)
            return true;

        foreach (var privilegio in privilegios)
        {
            if ((privilegiosUsuario & (int)privilegio) == 0)
                return false;
        }

        return true;
    }
}
