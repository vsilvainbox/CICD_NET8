using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace App.Features.Auth.Attributes;

/// <summary>
/// Atributo que requiere que el usuario tenga una empresa/año seleccionado
/// Similar al comportamiento de VB6 donde gEmpresa debe estar inicializado
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false)]
public class RequireEmpresaAttribute : Attribute, IAuthorizationFilter
{
    public void OnAuthorization(AuthorizationFilterContext context)
    {
        // Obtener logger
        var loggerFactory = context.HttpContext.RequestServices.GetService<ILoggerFactory>();
        var logger = loggerFactory?.CreateLogger<RequireEmpresaAttribute>();

        // Evitar loops: No aplicar en Auth o SeleccionarEmpresa controllers
        var controllerName = context.RouteData.Values["controller"]?.ToString();
        
        logger?.LogInformation("[RequireEmpresa] Checking controller: {Controller}", controllerName);
        
        if (controllerName == "Auth" || controllerName == "SeleccionarEmpresa")
        {
            logger?.LogInformation("[RequireEmpresa] Skipping check for {Controller}", controllerName);
            return; // Permitir acceso sin verificar empresa
        }

        // Verificar que el usuario esté autenticado
        if (!context.HttpContext.User.Identity?.IsAuthenticated ?? true)
        {
            logger?.LogWarning("[RequireEmpresa] User not authenticated, redirecting to Login");
            context.Result = new RedirectToActionResult("Login", "Auth", null);
            return;
        }

        // Verificar que tenga empresa seleccionada en sesión - con acceso seguro
        string? empresaJson = null;

        try
        {
            empresaJson = context.HttpContext.Session.GetString("EmpresaSeleccionada");
        }
        catch (Exception ex)
        {
            logger?.LogWarning(ex, "[RequireEmpresa] Session not available, redirecting to SeleccionarEmpresa");
            context.Result = new RedirectToActionResult("Index", "SeleccionarEmpresa", null);
            return;
        }

        logger?.LogInformation("[RequireEmpresa] Session EmpresaSeleccionada: {HasValue}", !string.IsNullOrEmpty(empresaJson));

        if (string.IsNullOrEmpty(empresaJson))
        {
            logger?.LogWarning("[RequireEmpresa] No empresa in session, redirecting to SeleccionarEmpresa");
            // Redirigir a selección de empresa
            context.Result = new RedirectToActionResult("Index", "SeleccionarEmpresa", null);
        }
        else
        {
            logger?.LogInformation("[RequireEmpresa] Empresa found in session: {EmpresaJson}", empresaJson);
        }
    }
}
