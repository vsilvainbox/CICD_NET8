using Microsoft.AspNetCore.Mvc;

namespace App.Features.AsistentePpm;

/// <summary>
/// API Controller para Asistente de Reajuste PPM
/// </summary>
[ApiController]
[Route("[controller]/[action]")]
public class AsistentePpmApiController(IAsistentePpmService service, ILogger<AsistentePpmApiController> logger) : ControllerBase
{
    /// <summary>
    /// Obtiene los datos de PPM Obligatorio con actualización por factores IPC
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año fiscal</param>
    /// <returns>DTO con registros PPM obligatorios, totales y reajuste</returns>
    [HttpGet]
    [ProducesResponseType(typeof(AsistentePpmObligatorioDto), 200)]
    [ProducesResponseType(400)]
    [ProducesResponseType(500)]
    public async Task<ActionResult<AsistentePpmObligatorioDto>> GetObligatorio(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        logger.LogInformation("GET PPM Obligatorio: EmpresaId={EmpresaId}, Ano={Ano}", empresaId, ano);

        var resultado = await service.GetPpmObligatorioAsync(empresaId, ano);
        return Ok(resultado);
    }

    /// <summary>
    /// Obtiene los datos de PPM Voluntario con actualización por factores IPC
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año fiscal</param>
    /// <returns>DTO con registros PPM voluntarios, totales y reajuste</returns>
    [HttpGet]
    [ProducesResponseType(typeof(AsistentePpmVoluntarioDto), 200)]
    [ProducesResponseType(400)]
    [ProducesResponseType(500)]
    public async Task<ActionResult<AsistentePpmVoluntarioDto>> GetVoluntario(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        logger.LogInformation("GET PPM Voluntario: EmpresaId={EmpresaId}, Ano={Ano}", empresaId, ano);

        var resultado = await service.GetPpmVoluntarioAsync(empresaId, ano);
        return Ok(resultado);
    }

    /// <summary>
    /// Calcula el total de reajuste a traspasar sumando el reajuste de PPM obligatorio y voluntario
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año fiscal</param>
    /// <returns>DTO con reajustes individuales y total a traspasar</returns>
    [HttpGet]
    [ProducesResponseType(typeof(AsistentePpmTotalTraspasoDto), 200)]
    [ProducesResponseType(400)]
    [ProducesResponseType(500)]
    public async Task<ActionResult<AsistentePpmTotalTraspasoDto>> GetTotalTraspaso(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        logger.LogInformation("GET PPM Total Traspaso: EmpresaId={EmpresaId}, Ano={Ano}", empresaId, ano);

        var resultado = await service.GetTotalTraspasoAsync(empresaId, ano);
        return Ok(resultado);
    }

    /// <summary>
    /// Obtiene la configuración actual de AsistentePpm
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año fiscal</param>
    /// <returns>DTO con configuración actual</returns>
    [HttpGet]
    [ProducesResponseType(typeof(AsistentePpmConfiguracionDto), 200)]
    [ProducesResponseType(400)]
    [ProducesResponseType(500)]
    public async Task<ActionResult<AsistentePpmConfiguracionDto>> GetConfiguracion(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        logger.LogInformation("GET PPM Configuracion: EmpresaId={EmpresaId}, Ano={Ano}", empresaId, ano);

        var resultado = await service.GetConfiguracionAsync(empresaId, ano);
        return Ok(resultado);
    }

    /// <summary>
    /// Actualiza la configuración de inclusión/exclusión de PPM pagados hasta 20/Enero
    /// </summary>
    /// <param name="dto">DTO con la nueva configuración</param>
    /// <returns>Resultado de la operación</returns>
    [HttpPost]
    [ProducesResponseType(200)]
    [ProducesResponseType(400)]
    [ProducesResponseType(500)]
    public async Task<ActionResult> PostConfiguracion([FromBody] ActualizarConfiguracionPpmDto dto)
    {
        logger.LogInformation("POST PPM Configuracion: EmpresaId={EmpresaId}, Ano={Ano}", dto.EmpresaId, dto.Ano);

        await service.ActualizarConfiguracionAsync(
            dto.EmpresaId,
            dto.Ano,
            dto.ExcluirHasta20Enero);

        return Ok();
    }

    /// <summary>
    /// Exporta a Excel el reporte completo de reajuste PPM
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año fiscal</param>
    /// <returns>Archivo Excel</returns>
    [HttpGet]
    [ProducesResponseType(typeof(FileContentResult), 200)]
    [ProducesResponseType(400)]
    [ProducesResponseType(500)]
    public async Task<ActionResult> ExportExcel(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        logger.LogInformation("GET PPM Export Excel: EmpresaId={EmpresaId}, Ano={Ano}", empresaId, ano);

        var excelBytes = await service.ExportarExcelAsync(empresaId, ano);
        var fileName = $"ReajustePPM_{ano}.xlsx";

        return File(
            excelBytes,
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            fileName);
    }
}
