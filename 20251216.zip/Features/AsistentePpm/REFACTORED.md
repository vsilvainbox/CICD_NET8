# Feature Refactorizada: AsistentePpm

**Fecha:** 2025-12-07
**Guía aplicada:** refactor.md

## Resumen de Cambios

Se aplicaron las correcciones para las siguientes violaciones detectadas:
- **R19:** proxy(1) - JavaScript llamaba a WebController en lugar de ApiController directamente
- **R20:** fetch-manual(4) - Uso de fetch() manual en lugar de helpers Api.*
- **R22:** hasnokey-ef(1) - Uso de Add() en entidad HasNoKey (ParamEmpresa)

## Reglas Verificadas

### Service (AsistentePpmService.cs)
- [x] R06 - Reutiliza lógica existente (no duplica queries)
- [x] R14 - Propiedades en PascalCase en DTOs de retorno
- [x] R15 - Lanza BusinessException para errores de validación
- [x] R17 - Tipos SQL coinciden con C# en raw queries
- [x] **R22 - Entidades HasNoKey usan SQL raw (no Add/Update/Remove)**

### ApiController (AsistentePpmApiController.cs)
- [x] R02 - Sin try-catch (el middleware maneja errores)
- [x] **R02 - Retorna Ok() para void, Ok(data) para datos (sin wrappers)**
- [x] R06 - No duplica endpoints de otros features
- [x] R14 - Parámetros recibidos coinciden con lo que envía el cliente
- [x] R15 - No captura excepciones (fluyen al middleware)

### WebController (AsistentePpmController.cs)
- [x] R02 - Sin try-catch
- [x] R03 - No llama a Service directo (solo muestra vista)
- [x] **R19 - Eliminados todos los métodos proxy**

### Vista (Views/Index.cshtml)
- [x] **R04 - URLs con @Url.Action apuntando a ApiController**
- [x] R07 - Header estilo consistente (icono + título + descripción)
- [x] R08 - Orden: Header → Toolbar → Contenido
- [x] R09 - Empty State cuando no hay datos
- [x] R11 - Botones no implementados: disabled (no onclick)
- [x] R13 - Tablas sin paginación
- [x] **R19 - JavaScript llama a ApiController directo (no proxy)**
- [x] **R20 - Solo Api.* helpers (eliminado fetch manual)**
- [x] CSS - Colores primary-* consistentes

## Detalles de Correcciones

### R22: ParamEmpresa HasNoKey - Service
**Archivo:** `AsistentePpmService.cs`
**Método:** `ActualizarConfiguracionAsync()`

**Antes:**
```csharp
if (paramPpm != null)
{
    // Actualizar existente
    paramPpm.Valor = nuevoValor;
}
else
{
    // Crear nuevo registro
    var nuevoParam = new App.Data.ParamEmpresa { ... };
    _context.ParamEmpresa.Add(nuevoParam);  // ❌ VIOLACIÓN
}
await _context.SaveChangesAsync();
```

**Después:**
```csharp
if (paramPpm != null)
{
    // R22: Actualizar con SQL raw (ParamEmpresa es HasNoKey)
    filasAfectadas = await _context.Database.ExecuteSqlRawAsync(
        @"UPDATE ParamEmpresa SET Valor = @p0
          WHERE IdEmpresa = @p1 AND Ano = @p2 AND Tipo = @p3",
        nuevoValor, empresaId, ano, "PPM");
}
else
{
    // R22: Insertar con SQL raw (ParamEmpresa es HasNoKey)
    filasAfectadas = await _context.Database.ExecuteSqlRawAsync(
        @"INSERT INTO ParamEmpresa (IdEmpresa, Ano, Tipo, Valor)
          VALUES (@p0, @p1, @p2, @p3)",
        empresaId, ano, "PPM", nuevoValor);
}
```

**Razón:** La entidad `ParamEmpresa` tiene `HasNoKey()` en el contexto, por lo que no puede usar métodos EF como `Add()`, `Update()` o `Remove()`. Debe usar SQL raw con `ExecuteSqlRawAsync()`.

---

### R02: Wrapper en ApiController
**Archivo:** `AsistentePpmApiController.cs`
**Método:** `PostConfiguracion()`

**Antes:**
```csharp
await service.ActualizarConfiguracionAsync(...);
return Ok(new { message = "Configuración actualizada correctamente" });  // ❌ VIOLACIÓN
```

**Después:**
```csharp
await service.ActualizarConfiguracionAsync(...);
return Ok();  // ✅ CORRECTO
```

**Razón:** Los ApiControllers no deben envolver respuestas void en objetos con mensajes. El éxito se comunica con Ok() y los errores con excepciones manejadas por el middleware.

---

### R19: Proxy en WebController
**Archivo:** `AsistentePpmController.cs`

**Antes:**
```csharp
public class AsistentePpmController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<AsistentePpmController> logger) : Controller
{
    [HttpGet]
    public async Task<IActionResult> GetObligatorio(int empresaId, short ano)
    {
        // ❌ VIOLACIÓN: Método proxy
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<AsistentePpmApiController>(...);
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }
    // ... más métodos proxy ...
}
```

**Después:**
```csharp
public class AsistentePpmController(ILogger<AsistentePpmController> logger) : Controller
{
    public IActionResult Index()
    {
        // Solo muestra la vista con datos de sesión
        var viewModel = new AsistentePpmIndexViewModel
        {
            EmpresaId = SessionHelper.EmpresaId,
            Ano = SessionHelper.Ano
        };
        return View(viewModel);
    }
    // ✅ CORRECTO: Sin métodos proxy
}
```

**Razón:** JavaScript debe llamar directamente a los ApiControllers, no hacer proxy a través del WebController. Esto elimina una capa innecesaria y simplifica el código.

---

### R04 + R19 + R20: URLs y fetch en Vista
**Archivo:** `Views/Index.cshtml`

**Antes:**
```javascript
// ❌ R04 VIOLACIÓN: URLs apuntan a WebController
const URL_ENDPOINTS = {
    getObligatorio: '@Url.Action("GetObligatorio", "AsistentePpm")',  // WebController
    // ...
};

// ❌ R20 VIOLACIÓN: fetch manual
async function cargarPpmObligatorio() {
    const response = await fetch(`${URL_ENDPOINTS.getObligatorio}?empresaId=${empresaId}&ano=${ano}`, {
        headers: { 'Accept': 'application/json' }
    });
    if (!response.ok) throw new Error('Error al cargar PPM Obligatorio');
    datosObligatorio = await response.json();
    // ...
}
```

**Después:**
```javascript
// ✅ R04 + R19: URLs apuntan directamente al ApiController
const URL_ENDPOINTS = {
    getObligatorio: '@Url.Action("GetObligatorio", "AsistentePpmApi")',  // ApiController
    // ...
};

// ✅ R20: Usar Api.get helper
async function cargarPpmObligatorio() {
    const data = await Api.get(URL_ENDPOINTS.getObligatorio, { empresaId, ano });
    if (!data) return;  // Api.get ya mostró SweetAlert si hubo error
    datosObligatorio = data;
    // ...
}
```

**Razón:**
- **R04:** URLs deben generarse con helpers type-safe apuntando al ApiController
- **R19:** JavaScript llama directamente al ApiController (no proxy)
- **R20:** Los helpers `Api.*` manejan automáticamente errores con SweetAlert y simplifican el código

---

### Cambios adicionales aplicados

#### Api.postJson en actualizarConfiguracion()
**Antes:**
```javascript
const response = await fetch(URL_ENDPOINTS.postConfiguracion, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
    body: JSON.stringify({ empresaId, ano, excluirHasta20Enero })
});
if (!response.ok) throw new Error('Error al actualizar configuración');
const data = await response.json();
if (data.success) { /* ... */ }
```

**Después:**
```javascript
const result = await Api.postJson(URL_ENDPOINTS.postConfiguracion, {
    empresaId: empresaId,
    ano: ano,
    excluirHasta20Enero: excluirHasta20Enero
});
if (result !== null) {
    await Swal.fire({ icon: 'success', title: 'Éxito', ... });
    await cargarDatos();
}
```

**Mejoras:**
- Manejo automático de errores con SweetAlert
- Código más conciso y legible
- Verificación con `result !== null` (null = error ya mostrado)

---

## Archivos Modificados

1. **AsistentePpmService.cs**
   - Método `ActualizarConfiguracionAsync()` refactorizado para usar SQL raw

2. **AsistentePpmApiController.cs**
   - Método `PostConfiguracion()` retorna `Ok()` sin wrapper

3. **AsistentePpmController.cs**
   - Eliminados todos los métodos proxy (GetObligatorio, GetVoluntario, GetTotalTraspaso, PostConfiguracion, ExportExcel)
   - Solo mantiene método `Index()` para mostrar la vista

4. **Views/Index.cshtml**
   - URLs actualizadas para apuntar a `AsistentePpmApi` en lugar de `AsistentePpm`
   - Reemplazados 4 usos de `fetch()` manual por `Api.get()` y `Api.postJson()`
   - Simplificado manejo de errores (delegado a Api.* helpers)

---

## Verificación de Violaciones

### Antes de la refactorización:
```
R19: proxy(1)         - AsistentePpmController tenía 5 métodos proxy
R20: fetch-manual(4)  - 4 llamadas fetch() manuales en la vista
R22: hasnokey-ef(1)   - ParamEmpresa.Add() en ActualizarConfiguracionAsync
```

### Después de la refactorización:
```
R19: proxy(0)         - ✅ Eliminados todos los métodos proxy
R20: fetch-manual(0)  - ✅ Reemplazados por Api.get() y Api.postJson()
R22: hasnokey-ef(0)   - ✅ Reemplazado por ExecuteSqlRawAsync()
```

---

## Notas Técnicas

### ParamEmpresa como entidad HasNoKey
La entidad `ParamEmpresa` no tiene clave primaria definida en el modelo, por lo que EF Core la trata como `HasNoKey()`. Esto significa:
- ❌ No se puede usar `Add()`, `Update()`, `Remove()`, `Attach()`
- ✅ Sí se puede leer con LINQ normal
- ✅ Se debe usar `ExecuteSqlRawAsync()` o `ExecuteSqlAsync()` para INSERT/UPDATE/DELETE

### Api.* helpers disponibles
- `Api.get(url, params)` - GET con query params
- `Api.postJson(url, data)` - POST con JSON body
- `Api.getHtml(url, params)` - GET que retorna HTML
- `Api.deleteJson(url, data)` - DELETE con JSON body

Todos manejan automáticamente:
- Errores HTTP (mostrados con SweetAlert)
- Errores de red (mostrados con SweetAlert)
- Retornan `null` si hubo error (ya mostrado al usuario)

---

## Pruebas Recomendadas

1. **Carga inicial de datos:**
   - Verificar que se carguen PPM Obligatorio y Voluntario
   - Verificar que se calcule correctamente el Total Traspaso

2. **Configuración PPM:**
   - Cambiar configuración de exclusión 20/Enero
   - Verificar que se actualice la base de datos
   - Verificar que se recarguen los datos correctamente

3. **Exportar Excel:**
   - Descargar archivo Excel
   - Verificar que contenga todas las secciones (Obligatorio, Voluntario, Total)

4. **Manejo de errores:**
   - Probar con empresa sin configuración de cuentas PPM
   - Verificar que se muestren SweetAlert apropiados

---

## Conclusión

La feature **AsistentePpm** ha sido refactorizada exitosamente siguiendo las reglas de `refactor.md`. Se eliminaron todas las violaciones detectadas:
- ✅ R19: JavaScript llama directamente a ApiController (sin proxy)
- ✅ R20: Uso de helpers Api.* (sin fetch manual)
- ✅ R22: Entidades HasNoKey usan SQL raw

El código ahora es más simple, mantenible y consistente con el resto de la aplicación.
