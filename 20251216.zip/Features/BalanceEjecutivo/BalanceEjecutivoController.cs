using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.BalanceEjecutivo;

public class BalanceEjecutivoController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<BalanceEjecutivoController> logger) : Controller
{
    public Task<IActionResult> Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder al Balance Ejecutivo";
            TempData["SwalType"] = "warning";
            return Task.FromResult<IActionResult>(RedirectToAction("Index", "SeleccionarEmpresa"));
        }

        logger.LogInformation("Loading BalanceEjecutivo Index for empresaId: {EmpresaId}, ano: {Ano}", SessionHelper.EmpresaId, SessionHelper.Ano);

        var viewModel = new BalanceEjecutivoIndexViewModel
        {
            EmpresaId = SessionHelper.EmpresaId,
            Ano = SessionHelper.Ano
        };

        return Task.FromResult<IActionResult>(View(viewModel));
    }

}