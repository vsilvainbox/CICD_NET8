# Feature Refactorizada - Ayuda

**Fecha:** 2025-12-07  
**Guía aplicada:** refactor.md

## Resumen de Violaciones Detectadas y Corregidas

### Violaciones Originales
- **R07:validacion(8)** - Headers con estilo incorrecto (iconos grandes, text-2xl/3xl font-bold)
- **R21:modal-local(1)** - Función local `cerrarAyuda()` en lugar de funciones globales de _Layout

### Total de Violaciones Corregidas: 9

---

## Reglas Aplicadas por Archivo

### Views/Modal.cshtml

#### R07 - Headers estilo Dashboard
- [x] **Línea 20-24**: Header para impresión corregido a `text-xl font-semibold`
- [x] **Líneas 26-70**: Header principal corregido de `text-3xl font-bold` con iconos a estilo Dashboard (`text-xl font-semibold` + descripción simple)
- [x] **Línea 106**: Título de sección "Ejemplos y Casos de Uso" simplificado de `text-lg font-semibold` con icono a `text-base font-medium` sin icono

**Antes:**
```html
<div class="flex justify-between items-center mb-6 no-print">
    <div>
        <h1 class="text-3xl font-bold text-gray-900">
            <i class="fas fa-plus-circle text-green-600 mr-3"></i>
            @(Model?.Titulo ?? "Ayuda")
        </h1>
```

**Después:**
```html
<header class="mb-6 no-print">
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-xl font-semibold text-gray-900">@(Model?.Titulo ?? "Ayuda")</h1>
            <p class="mt-1 text-sm text-gray-500">
                @if (tipoAyuda == "aumentos")
                {
                    @:Ejemplos de ajustes que incrementan la base imponible
                }
                ...
            </p>
        </div>
```

#### R21 - Eliminación de función modal local
- [x] **Líneas 220-235**: Eliminada función local `cerrarAyuda()`, reemplazada por navegación estándar `window.history.back()`

**Antes:**
```javascript
// Función para cerrar si se abre como modal
function cerrarAyuda() {
    if (window.opener) {
        window.close();
    } else {
        window.history.back();
    }
}
```

**Después:**
```javascript
// R21: Eliminada función cerrarAyuda() local - usar navegación estándar
// La función cerrarModal() global está disponible en _Layout para modales

// En keydown:
if (e.key === 'Escape') {
    // R21: Usar navegación estándar en lugar de función local
    window.history.back();
}
```

---

### Views/Index.cshtml

#### R07 - Headers estilo Dashboard
- [x] **Líneas 30-44**: Sección "Acerca del Sistema" corregida - `h3 text-lg font-medium` → `h2 text-base font-medium`
- [x] **Líneas 66-72**: Cards de tipos de ayuda - icono de `text-4xl` → `text-2xl`, título de `text-lg font-semibold` → `text-base font-medium`
- [x] **Líneas 89-97**: Estado vacío - icono de `w-16 h-16` → `w-12 h-12`, título de `text-lg font-medium` → `text-base font-medium`
- [x] **Líneas 100-102**: Sección "Accesos Rápidos" - `h3 text-lg font-semibold` con icono SVG → `h2 text-base font-medium` sin icono

**Antes:**
```html
<h3 class="text-lg font-semibold text-gray-900 mb-4">
    <svg class="w-5 h-5 inline-block text-primary-600 mr-2" ...>
    Accesos Rápidos
</h3>
```

**Después:**
```html
<h2 class="text-base font-medium text-gray-900 mb-4">Accesos Rápidos</h2>
```

---

## Archivos Sin Cambios

| Archivo | Motivo |
|---------|--------|
| `_ModalContent.cshtml` | Ya cumple con los estándares de estilo |
| `AyudaController.cs` | Backend sin violaciones de vista |
| `AyudaApiController.cs` | Backend sin violaciones de vista |
| `AyudaService.cs` | Backend sin violaciones de vista |
| `AyudaDto.cs` | DTOs sin violaciones |
| `IAyudaService.cs` | Interface sin violaciones |

---

## Resumen de Cambios

| Archivo | R07 | R21 | Total |
|---------|-----|-----|-------|
| `Views/Modal.cshtml` | 3 | 1 | 4 |
| `Views/Index.cshtml` | 5 | 0 | 5 |
| **Total** | **8** | **1** | **9** |

---

## Validación Post-Refactorización

```powershell
# Verificar R07: No deben existir headers con estilo incorrecto
Select-String -Path "Views\*.cshtml" -Pattern "text-2xl font-bold|text-3xl font-bold"
# Resultado esperado: Sin coincidencias ✓

# Verificar R21: No deben existir funciones modal locales
Select-String -Path "Views\*.cshtml" -Pattern "function\s+cerrarModal\s*\(|function\s+abrirModal\s*\("
# Resultado esperado: Sin coincidencias ✓
```
