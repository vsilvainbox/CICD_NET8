# Legacy Analysis: Ayuda (Help System)

## 📄 Información del Formulario VB6

**Archivo VB6:** `old/Contabilidad70/HyperContabilidad/FrmAyuda.frm`
**Fecha Análisis:** 2024-10-02
**Analista:** IA
**Complejidad:** Baja

### Propósito del Formulario
El formulario de ayuda es un sistema modal que muestra información específica sobre ajustes contables. Su función principal es proporcionar ejemplos y explicaciones sobre diferentes tipos de ajustes (aumentos y disminuciones) que se pueden aplicar en procesos contables específicos, particularmente relacionados con formularios 14D3 y 14D8.

---

## 🎨 CONTROLES UI IDENTIFICADOS

### Frames (Contenedores de Información)
| Control VB6 | Index | Caption | Visible | Propósito |
|-------------|-------|---------|---------|-----------|
| Fr_Help(1) | 1 | "Ejemplos de Otros Ajustes (Aumentos)" | False | Contenedor para información de ajustes que aumentan |
| Fr_Help(2) | 2 | "Ejemplos de Otros Ajustes (Disminuciones)" | False | Contenedor para información de ajustes que disminuyen |

### Labels de Información
| Control VB6 | Index | Caption | Propósito |
|-------------|-------|---------|-----------|
| Label1(1) | 1 | "SOLO 14D3 + Ingresos no rentas generadas por la empresa" | Ejemplo de ajuste de aumento |
| Label1(2) | 2 | "SOLO 14D3 + Ingresos exentos de IDPC" | Ejemplo de ajuste de aumento |
| Label1(3) | 3 | "SOLO 14D3 + Franquicia Letra E, art 14 LIR" | Ejemplo de ajuste de aumento |
| Label1(5) | 5 | "SOLO 14D3 + Reposición deducción por pago IDPC Voluntario en años anteriores" | Ejemplo de ajuste de aumento |
| Label1(0) | 0 | "AMBOS - Ingreso diferido imputado en el ejercicio" | Ejemplo de ajuste de disminución |
| Label1(6) | 6 | "AMBOS - Crédito total disponible por IPE" | Ejemplo de ajuste de disminución |
| Label1(7) | 7 | "SOLO 14D8 - Incremento asociado a retiros o dividendos recibidos" | Ejemplo de ajuste de disminución |

### Propiedades del Formulario
| Propiedad | Valor | Propósito |
|-----------|-------|-----------|
| BorderStyle | 1 (Fixed Single) | Formulario no redimensionable |
| Caption | "Ayuda" | Título del formulario |
| MaxButton | False | Sin botón maximizar |
| MinButton | False | Sin botón minimizar |
| StartUpPosition | 1 (CenterOwner) | Centrado respecto al formulario padre |

---

## 🔘 EVENTOS IDENTIFICADOS

### Eventos de Formulario
| Evento VB6 | Cuándo Ocurre | Acciones | Mapeo .NET |
|------------|---------------|----------|------------|
| Form_Load | Al abrir form | Mostrar frame específico, ajustar tamaño, actualizar título | InitializeModalAsync() |

### Variables de Control
| Variable VB6 | Tipo | Propósito | Mapeo .NET |
|--------------|------|-----------|------------|
| lCurFrame | Integer | Frame actual a mostrar | currentFrameType |
| lTitulo | String | Título específico del contexto | contextTitle |

---

## 🔧 FUNCIONES Y PROCEDIMIENTOS VB6

### Funciones Públicas
```vb
' Función: FViewOtrosAjustesAumentos
' Propósito: Mostrar ayuda para ajustes de aumentos
' Parámetros: Titulo As String
' Retorno: Function (no especificado, actúa como Sub)
' Mapeo .NET: ShowAjustesAumentosAsync(string titulo)
Public Function FViewOtrosAjustesAumentos(ByVal Titulo As String)
   lTitulo = Titulo
   lCurFrame = C_OTROSAJUSTAUMENTOS
   Me.Show vbModal
End Function

' Función: FViewOtrosAjustesDismin
' Propósito: Mostrar ayuda para ajustes de disminuciones
' Parámetros: Titulo As String
' Retorno: Function (no especificado, actúa como Sub)
' Mapeo .NET: ShowAjustesDisminucionesAsync(string titulo)
Public Function FViewOtrosAjustesDismin(ByVal Titulo As String)
   lTitulo = Titulo
   lCurFrame = C_OTROSAJUSTDISMIN
   Me.Show vbModal
End Function
```

### Constantes Identificadas
```vb
Const C_OTROSAJUSTAUMENTOS = 1    ' Tipo: Ajustes de Aumentos
Const C_OTROSAJUSTDISMIN = 2      ' Tipo: Ajustes de Disminuciones
Const NFRAMES = C_OTROSAJUSTDISMIN ' Total de frames disponibles
```

### Evento Form_Load
```vb
Private Sub Form_Load()
   Fr_Help(lCurFrame).visible = True
   Fr_Help(lCurFrame).Top = 180
   Me.Height = Fr_Help(lCurFrame).Height + W.YCaption + Fr_Help(lCurFrame).Top + 300
   Me.Caption = Me.Caption & " " & lTitulo
End Sub
```

**Mapeo .NET:**
- Mostrar contenido específico según tipo
- Ajustar tamaño del modal
- Actualizar título con contexto

---

## 💾 ACCESO A DATOS VB6

### Análisis de Datos
Este formulario **NO accede a base de datos**. Es un formulario de ayuda estático que muestra información hardcodeada sobre ejemplos de ajustes contables.

**Contenido Estático:**
- Ejemplos de ajustes de aumentos (4 ejemplos)
- Ejemplos de ajustes de disminuciones (3 ejemplos)
- Información específica sobre formularios 14D3 y 14D8
- Referencias a normativas tributarias (IPE, IDPC, Franquicia Letra E)

---

## ✅ VALIDACIONES Y REGLAS DE NEGOCIO

### Validaciones
- **No hay validaciones de entrada**: Es un formulario de solo lectura
- **Validación de tipo**: Debe especificarse tipo válido (C_OTROSAJUSTAUMENTOS o C_OTROSAJUSTDISMIN)

### Reglas de Negocio
1. **Modalidad exclusiva**: Solo se puede mostrar un tipo de ayuda a la vez
2. **Contexto específico**: El título se personaliza según el contexto desde donde se llama
3. **Información estática**: El contenido de ayuda es fijo, no configurable

---

## 🧮 CÁLCULOS Y FÓRMULAS

### Cálculo de Tamaño del Formulario
```vb
' Fórmula para ajustar altura del formulario
Me.Height = Fr_Help(lCurFrame).Height + W.YCaption + Fr_Help(lCurFrame).Top + 300
```
**→ Implementar:** Ajuste automático del modal según contenido

---

## 🚀 NAVEGACIÓN Y FLUJO

### Formularios Que Llaman a Ayuda
| Formulario Origen | Función Llamada | Parámetros | Contexto |
|-------------------|----------------|------------|----------|
| Formularios de Base Imponible | FViewOtrosAjustesAumentos | "Aumentos" | Ayuda sobre ajustes positivos |
| Formularios de Base Imponible | FViewOtrosAjustesDismin | "Disminuciones" | Ayuda sobre ajustes negativos |

### Flujo de Estados del Form
```
[Llamada externa] → SetTipo(aumentos/disminuciones) → [Form_Load] → [Estado: Mostrando Ayuda]
  ↓
[Usuario lee información] → [Cerrar modal] → [Retorno a formulario origen]
```

---

## 📊 EXPORTACIONES E IMPORTACIONES

**No aplica** - Este formulario no tiene funcionalidades de importación o exportación.

---

## 🎯 MAPEO FINAL: MÉTODOS .NET DETERMINADOS

### Interface del Service
```csharp
public interface IAyudaService
{
    // Contenido de Ayuda
    Task<AyudaContentDto> GetAjustesAumentosAsync();
    Task<AyudaContentDto> GetAjustesDisminucionesAsync();
    
    // Tipos de Ayuda
    Task<IEnumerable<AyudaTipoDto>> GetTiposAyudaAsync();
}
```

### DTOs Necesarios
```csharp
public class AyudaContentDto
{
    public string Titulo { get; set; }
    public string Descripcion { get; set; }
    public List<AyudaItemDto> Items { get; set; }
}

public class AyudaItemDto
{
    public string Codigo { get; set; }
    public string Descripcion { get; set; }
    public string Detalle { get; set; }
}

public class AyudaTipoDto
{
    public int Id { get; set; }
    public string Nombre { get; set; }
    public string Descripcion { get; set; }
}
```

### Resumen de Mapeo
| Funcionalidad VB6 | Método .NET | Complejidad | Prioridad |
|-------------------|-------------|-------------|-----------|
| FViewOtrosAjustesAumentos() | GetAjustesAumentosAsync() | Baja | Alta |
| FViewOtrosAjustesDismin() | GetAjustesDisminucionesAsync() | Baja | Alta |
| Form_Load ajuste tamaño | Modal responsive CSS | Baja | Media |
| Mostrar contenido específico | ShowHelpModalAsync() | Baja | Alta |

---

## ⚠️ NOTAS IMPORTANTES Y OBSERVACIONES

### Peculiaridades del Form VB6
- **Formulario modal**: Se muestra como modal bloqueante
- **Tamaño dinámico**: Ajusta su altura según el contenido a mostrar
- **Título contextual**: El título se personaliza según la llamada
- **Contenido estático**: No hay configuración dinámica del contenido
- **Sin botones de acción**: Solo información de lectura

### Decisiones de Diseño
- **Modal Bootstrap/Tailwind**: Reemplazar vbModal con modal web moderno
- **Contenido hardcodeado**: Mantener información estática como en VB6
- **Responsive**: Adaptar tamaño automáticamente en web
- **Accesibilidad**: Agregar soporte para teclado y screen readers

### Contenido Específico a Migrar

#### Ajustes de Aumentos (Frame 1):
1. "SOLO 14D3 + Ingresos no rentas generadas por la empresa"
2. "SOLO 14D3 + Ingresos exentos de IDPC"
3. "SOLO 14D3 + Franquicia Letra E, art 14 LIR"
4. "SOLO 14D3 + Reposición deducción por pago IDPC Voluntario en años anteriores"

#### Ajustes de Disminuciones (Frame 2):
1. "AMBOS - Ingreso diferido imputado en el ejercicio"
2. "AMBOS - Crédito total disponible por IPE"
3. "SOLO 14D8 - Incremento asociado a retiros o dividendos recibidos"

---

## ✅ CHECKLIST DE COMPLETITUD DEL ANÁLISIS

- [x] Todos los controles UI documentados
- [x] Todos los eventos mapeados
- [x] Todas las funciones VB6 identificadas
- [x] Contenido estático catalogado
- [x] Flujo de navegación documentado
- [x] Métodos .NET determinados
- [x] Interface del Service definida
- [x] Decisiones de diseño justificadas
- [x] Sin acceso a datos (confirmado)
- [x] Sin validaciones complejas (confirmado)
- [x] Sin cálculos matemáticos complejos (confirmado)

---

**✅ ANÁLISIS COMPLETO - LISTO PARA IMPLEMENTACIÓN**