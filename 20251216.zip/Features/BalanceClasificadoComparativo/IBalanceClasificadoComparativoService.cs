namespace App.Features.BalanceClasificadoComparativo;

public interface IBalanceClasificadoComparativoService
{
    Task<BalanceClasificadoComparativoResponseDto> GenerarAsync(BalanceClasificadoComparativoRequestDto request, CancellationToken cancellationToken = default);

    Task<BalanceClasificadoComparativoExportResponseDto> ExportarAsync(BalanceClasificadoComparativoExportRequestDto request, CancellationToken cancellationToken = default);

    string GenerarNombreArchivoExportacion(string nombreArchivo, int empresaId, string extension);

    Task<BalanceClasificadoComparativoPreviewResponseDto> GenerarPreviewAsync(BalanceClasificadoComparativoPreviewRequestDto request, CancellationToken cancellationToken = default);

    Task RegistrarImpresionAsync(BalanceClasificadoComparativoRegistroImpresionRequestDto request, CancellationToken cancellationToken = default);

    Task<IReadOnlyList<BalanceClasificadoComparativoRegistroImpresionDto>> ObtenerHistorialImpresionAsync(int empresaId, int libroOficialCodigo, CancellationToken cancellationToken = default);

    Task<BalanceClasificadoComparativoRegistroImpresionDto?> VerificarImpresionPreviaAsync(
        int empresaId,
        int libroOficialCodigo,
        DateTime fechaDesde,
        DateTime fechaHasta,
        BalanceClasificadoComparativoMode modo,
        CancellationToken cancellationToken = default);

    Task<BalanceClasificadoComparativoOpcionesDto> ObtenerOpcionesAsync(int empresaId, CancellationToken cancellationToken = default);

    Task<object> GetFechasDefaultAsync(int empresaId, short ano, CancellationToken cancellationToken = default);
}