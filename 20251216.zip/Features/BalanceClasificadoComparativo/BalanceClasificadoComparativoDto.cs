using System.ComponentModel.DataAnnotations;

namespace App.Features.BalanceClasificadoComparativo;

public enum BalanceClasificadoComparativoMode
{
    BalanceClasificado = 1,
    EstadoResultado = 2
}

public enum BalanceClasificadoComparativoTipoAjuste
{
    Financiero = 1,
    Tributario = 2,
    Ambos = 3
}

public enum BalanceClasificadoComparativoExportFormat
{
    Excel,
    Pdf
}

public class BalanceClasificadoComparativoRequestDto
{
    [Required(ErrorMessage = "La empresa es requerida")]
    public int EmpresaId { get; set; }

    [Required(ErrorMessage = "El año actual es requerido")]
    public short AnoActual { get; set; }

    [Required(ErrorMessage = "La fecha desde es requerida")]
    [Display(Name = "Desde (Periodo Actual)")]
    [DataType(DataType.Date)]
    public DateTime FechaDesdeActual { get; set; }

    [Required(ErrorMessage = "La fecha hasta es requerida")]
    [Display(Name = "Hasta (Periodo Actual)")]
    [DataType(DataType.Date)]
    public DateTime FechaHastaActual { get; set; }

    [Display(Name = "Desde (Periodo Anterior)")]
    [DataType(DataType.Date)]
    public DateTime? FechaDesdeAnterior { get; set; }

    [Display(Name = "Hasta (Periodo Anterior)")]
    [DataType(DataType.Date)]
    public DateTime? FechaHastaAnterior { get; set; }

    [Range(2, 5, ErrorMessage = "El nivel debe estar entre 2 y 5.")]
    [Display(Name = "Nivel")]
    public int Nivel { get; set; } = 5;

    [Display(Name = "Tipo Ajuste")]
    public BalanceClasificadoComparativoTipoAjuste TipoAjuste { get; set; } = BalanceClasificadoComparativoTipoAjuste.Financiero;

    [Display(Name = "Área de Negocio")]
    public int? AreaNegocioId { get; set; }

    [Display(Name = "Centro de Costo")]
    public int? CentroCostoId { get; set; }

    [Display(Name = "Solo Libro Oficial (Aprobados)")]
    public bool SoloLibroOficial { get; set; }

    [Display(Name = "Mostrar Subtotales")]
    public bool MostrarSubTotales { get; set; } = true;

    [Display(Name = "Mostrar Código Cuenta")]
    public bool MostrarCodigoCuenta { get; set; }

    public BalanceClasificadoComparativoMode Modo { get; set; } = BalanceClasificadoComparativoMode.BalanceClasificado;

    public bool UsarFechasPersonalizadasAnterior { get; set; }
}

public sealed class BalanceClasificadoComparativoResponseDto
{
    public List<BalanceClasificadoComparativoRowDto> Filas { get; set; } = new();
    public BalanceClasificadoComparativoTotalesDto Totales { get; set; } = new();
    public BalanceClasificadoComparativoResumenDto Resumen { get; set; } = new();
    public BalanceClasificadoComparativoFiltroAplicadoDto Filtros { get; set; } = new();
    public DateTime GeneradoEl { get; set; } = DateTime.UtcNow;
    public bool TieneResultadoEjercicio { get; set; }
    public List<BalanceClasificadoComparativoNivelColorDto> ColoresPorNivel { get; set; } = new();
}

public sealed class BalanceClasificadoComparativoRowDto
{
    public int? IdCuenta { get; set; }
    public string Codigo { get; set; } = string.Empty;
    public string Nombre { get; set; } = string.Empty;
    public byte Nivel { get; set; }
    public byte? Clasificacion { get; set; }
    public double DebeActual { get; set; }
    public double HaberActual { get; set; }
    public double DebeAnterior { get; set; }
    public double HaberAnterior { get; set; }
    public double SaldoActual { get; set; }
    public double SaldoAnterior { get; set; }
    public double Diferencia => SaldoActual - SaldoAnterior;
    public bool EsTotal { get; set; }
    public bool EsResultadoEjercicio { get; set; }
    public bool EsVisible { get; set; } = true;
    public bool EsFilaPadre { get; set; }
    public string Formato { get; set; } = string.Empty;
    public string? CodigoPadre { get; set; }
}

public sealed class BalanceClasificadoComparativoTotalesDto
{
    public double TotalActivo { get; set; }
    public double TotalPasivo { get; set; }
    public double TotalResultado { get; set; }
    public double TotalActual { get; set; }
    public double TotalAnterior { get; set; }
    public double ResultadoEjercicioActual { get; set; }
    public double ResultadoEjercicioAnterior { get; set; }
}

public sealed class BalanceClasificadoComparativoResumenDto
{
    public double Diferencia => TotalActual - TotalAnterior;
    public double TotalActual { get; set; }
    public double TotalAnterior { get; set; }
    public bool EstaBalanceado => Math.Round(Diferencia, 2) == 0d;
}

public sealed class BalanceClasificadoComparativoNivelColorDto
{
    public short Nivel { get; set; }
    public string ColorHex { get; set; } = string.Empty;
}

public sealed class BalanceClasificadoComparativoFiltroAplicadoDto
{
    public DateTime FechaDesdeActual { get; set; }
    public DateTime FechaHastaActual { get; set; }
    public DateTime FechaDesdeAnterior { get; set; }
    public DateTime FechaHastaAnterior { get; set; }
    public int Nivel { get; set; }
    public BalanceClasificadoComparativoTipoAjuste TipoAjuste { get; set; }
    public string? AreaNegocio { get; set; }
    public string? CentroCosto { get; set; }
    public bool SoloLibroOficial { get; set; }
    public bool MostrarSubTotales { get; set; }
    public bool MostrarCodigoCuenta { get; set; }
    public BalanceClasificadoComparativoMode Modo { get; set; }
}

public sealed class BalanceClasificadoComparativoExportRequestDto : BalanceClasificadoComparativoRequestDto
{
    public BalanceClasificadoComparativoExportFormat Formato { get; set; } = BalanceClasificadoComparativoExportFormat.Excel;
    public string? NombreArchivo { get; set; }
}

public sealed class BalanceClasificadoComparativoExportResponseDto
{
    public string FileName { get; set; } = string.Empty;
    public string ContentType { get; set; } = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    public byte[] Content { get; set; } = Array.Empty<byte>();
}

public sealed class BalanceClasificadoComparativoPreviewRequestDto : BalanceClasificadoComparativoRequestDto
{
    public bool PapelFoliado { get; set; }
    public bool InformacionPreliminar { get; set; }
}

public sealed class BalanceClasificadoComparativoPreviewResponseDto
{
    public byte[] Content { get; set; } = Array.Empty<byte>();
    public string FileName { get; set; } = string.Empty;
    public string ContentType { get; set; } = string.Empty;
}

public sealed class BalanceClasificadoComparativoRegistroImpresionRequestDto
{
    [Required(ErrorMessage = "La empresa es requerida")]
    public int EmpresaId { get; set; }

    [Required(ErrorMessage = "El código de libro oficial es requerido")]
    public int LibroOficialCodigo { get; set; }

    [Required(ErrorMessage = "La fecha desde es requerida")]
    public DateTime FechaDesde { get; set; }

    [Required(ErrorMessage = "La fecha hasta es requerida")]
    public DateTime FechaHasta { get; set; }

    [Required(ErrorMessage = "El modo es requerido")]
    public BalanceClasificadoComparativoMode Modo { get; set; }

    public int? UsuarioId { get; set; }

    public string? UsuarioNombre { get; set; }

    public bool PapelFoliado { get; set; }
}

public sealed class BalanceClasificadoComparativoRegistroImpresionDto
{
    public DateTime FechaImpresion { get; set; }
    public string Usuario { get; set; } = string.Empty;
    public DateTime FechaDesde { get; set; }
    public DateTime FechaHasta { get; set; }
    public bool PapelFoliado { get; set; }
    public int LibroOficialCodigo { get; set; }
}

public sealed class BalanceClasificadoComparativoOpcionesDto
{
    public List<SimpleComboItemDto> Niveles { get; set; } = new();
    public List<SimpleComboItemDto> TiposAjuste { get; set; } = new();
    public List<SimpleComboItemDto> AreasNegocio { get; set; } = new();
    public List<SimpleComboItemDto> CentrosCosto { get; set; } = new();
    public Dictionary<int, string> ColoresNivel { get; set; } = new();
}

public sealed class SimpleComboItemDto
{
    public int Value { get; set; }
    public string Text { get; set; } = string.Empty;
}