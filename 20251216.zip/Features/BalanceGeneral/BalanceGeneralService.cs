using App.Data;
using App.Exceptions;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;
using QuestPDF.Fluent;
using QuestPDF.Infrastructure;

namespace App.Features.BalanceGeneral;

/// <summary>
/// Servicio para Balance General de 8 Columnas
/// Implementa la lógica del formulario VB6 FrmBalTributario
/// </summary>
public class BalanceGeneralService(
    LpContabContext context,
    ILogger<BalanceGeneralService> logger) : IBalanceGeneralService
{
    // Constantes de clasificación (equivalentes a VB6)
    private const int CLASCTA_ACTIVO = 1;
    private const int CLASCTA_PASIVO = 2;
    private const int CLASCTA_RESULTADO = 3;

    // Constantes de tipo de ajuste
    private const int TAJUSTE_FINANCIERO = 1;
    private const int TAJUSTE_TRIBUTARIO = 2;
    private const int TAJUSTE_AMBOS = 3;

    public async Task<BalanceGeneralResultadoDto> GenerateBalanceAsync(BalanceGeneralParametrosDto parametros)
    {
        logger.LogInformation("Generating balance general for empresaId: {EmpresaId}, año: {Ano}", 
            parametros.EmpresaId, parametros.Ano);

        {
            var resultado = new BalanceGeneralResultadoDto
            {
                Parametros = parametros
            };

            // 1. Obtener movimientos agrupados por cuenta
            var movimientos = await GetMovimientosAsync(parametros);

            // 2. Calcular valores de 8 columnas para cada cuenta
            foreach (var mov in movimientos)
            {
                var linea = new BalanceGeneralDto
                {
                    idCuenta = mov.idCuenta,
                    Codigo = mov.Codigo,
                    Descripcion = mov.Descripcion,
                    Nivel = mov.Nivel,
                    Clasificacion = mov.Clasificacion,
                    Debitos = mov.TotalDebe,
                    Creditos = mov.TotalHaber
                };

                // Calcular saldos
                if (linea.Debitos > linea.Creditos)
                {
                    linea.SaldoDeudor = linea.Debitos - linea.Creditos;
                    linea.SaldoAcreedor = 0;
                }
                else
                {
                    linea.SaldoDeudor = 0;
                    linea.SaldoAcreedor = linea.Creditos - linea.Debitos;
                }

                // Calcular Inventario (solo Activo y Pasivo)
                if (mov.Clasificacion == CLASCTA_ACTIVO)
                {
                    linea.InventarioActivo = linea.SaldoDeudor;
                    linea.InventarioPasivo = 0;
                }
                else if (mov.Clasificacion == CLASCTA_PASIVO)
                {
                    linea.InventarioActivo = 0;
                    linea.InventarioPasivo = linea.SaldoAcreedor;
                }

                // Calcular Resultado (solo cuentas de Resultado)
                if (mov.Clasificacion >= CLASCTA_RESULTADO)
                {
                    linea.Perdida = linea.SaldoDeudor;
                    linea.Ganancia = linea.SaldoAcreedor;
                }

                resultado.Lineas.Add(linea);
            }

            // 3. Calcular totales
            resultado.Totales = CalculateTotals(resultado.Lineas);

            logger.LogInformation("Balance generated with {Count} lines", resultado.Lineas.Count);
            return resultado;
        }
    }

    public Task<double> CalculatePatrimonioAsync(BalanceGeneralResultadoDto balance)
    {
        {
            // Patrimonio = Total Inventario Activo - Total Inventario Pasivo
            var patrimonio = balance.Totales.TotalInventarioActivo - balance.Totales.TotalInventarioPasivo;
                
            logger.LogInformation("Calculated patrimonio: {Patrimonio}", patrimonio);
            return Task.FromResult(patrimonio);
        }
    }

    public Task<bool> ValidateEquationAsync(BalanceGeneralTotalesDto totales)
    {
        {
            // Ecuación contable: Activos + Pérdidas = Pasivos + Patrimonio + Ganancias
            var lado1 = totales.TotalInventarioActivo + totales.TotalPerdida;
            var lado2 = totales.TotalInventarioPasivo + totales.Patrimonio + totales.TotalGanancia;
                
            var diferencia = Math.Abs(lado1 - lado2);
            var isValid = diferencia < 0.01;

            logger.LogInformation("Equation validation: {IsValid}, Difference: {Diferencia}", 
                isValid, diferencia);

            return Task.FromResult(isValid);
        }
    }

    public async Task<byte[]> ExportAsync(BalanceGeneralExportDto exportDto)
    {
        logger.LogInformation("Exporting balance to {Formato}", exportDto.Formato);

        if (string.Equals(exportDto.Formato, "excel", StringComparison.OrdinalIgnoreCase))
        {
            return await ExportToExcelAsync(exportDto.Resultado);
        }
        else if (string.Equals(exportDto.Formato, "pdf", StringComparison.OrdinalIgnoreCase))
        {
            return await ExportToPdfAsync(exportDto.Resultado);
        }
        else
        {
            throw new BusinessException($"Formato no soportado: {exportDto.Formato}");
        }
    }

    private async Task<byte[]> ExportToExcelAsync(BalanceGeneralResultadoDto resultado)
    {
        logger.LogInformation("Exportando Balance General a Excel");

        // Obtener datos de la empresa
        var empresa = await context.Empresa.FirstOrDefaultAsync(e => e.Id == resultado.Parametros.EmpresaId);
        if (empresa == null)
        {
            throw new BusinessException($"Empresa {resultado.Parametros.EmpresaId} no encontrada");
        }

        ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

        using var package = new ExcelPackage();
        var worksheet = package.Workbook.Worksheets.Add("Balance General");

        var row = 1;

        // Encabezado empresa
        worksheet.Cells[row, 1].Value = empresa.Nombre;
        worksheet.Cells[row, 1].Style.Font.Bold = true;
        worksheet.Cells[row, 1].Style.Font.Size = 14;
        row++;

        worksheet.Cells[row, 1].Value = $"RUT: {empresa.Rut}";
        row++;

        // Título
        worksheet.Cells[row, 1].Value = "BALANCE GENERAL - 8 COLUMNAS";
        worksheet.Cells[row, 1].Style.Font.Bold = true;
        worksheet.Cells[row, 1].Style.Font.Size = 12;
        row++;

        // Período
        worksheet.Cells[row, 1].Value = $"Período: {resultado.Parametros.FechaDesde} a {resultado.Parametros.FechaHasta}";
        row++;
        row++; // Línea en blanco

        // Encabezados de columnas
        worksheet.Cells[row, 1].Value = "Código";
        worksheet.Cells[row, 2].Value = "Cuenta";
        worksheet.Cells[row, 3].Value = "Débitos";
        worksheet.Cells[row, 4].Value = "Créditos";
        worksheet.Cells[row, 5].Value = "Saldo Deudor";
        worksheet.Cells[row, 6].Value = "Saldo Acreedor";
        worksheet.Cells[row, 7].Value = "Inventario Activo";
        worksheet.Cells[row, 8].Value = "Inventario Pasivo";
        worksheet.Cells[row, 9].Value = "Resultado Pérdida";
        worksheet.Cells[row, 10].Value = "Resultado Ganancia";

        // Formatear encabezados
        using (var range = worksheet.Cells[row, 1, row, 10])
        {
            range.Style.Font.Bold = true;
            range.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
            range.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightGray);
            range.Style.Border.BorderAround(OfficeOpenXml.Style.ExcelBorderStyle.Thin);
        }
        row++;

        // Datos
        foreach (var linea in resultado.Lineas)
        {
            worksheet.Cells[row, 1].Value = linea.Codigo;
            worksheet.Cells[row, 2].Value = linea.Descripcion;
            worksheet.Cells[row, 3].Value = linea.Debitos;
            worksheet.Cells[row, 4].Value = linea.Creditos;
            worksheet.Cells[row, 5].Value = linea.SaldoDeudor;
            worksheet.Cells[row, 6].Value = linea.SaldoAcreedor;
            worksheet.Cells[row, 7].Value = linea.InventarioActivo;
            worksheet.Cells[row, 8].Value = linea.InventarioPasivo;
            worksheet.Cells[row, 9].Value = linea.Perdida;
            worksheet.Cells[row, 10].Value = linea.Ganancia;

            // Formatear números
            for (var col = 3; col <= 10; col++)
            {
                worksheet.Cells[row, col].Style.Numberformat.Format = "#,##0.00";
            }

            row++;
        }

        // Totales
        row++;
        worksheet.Cells[row, 2].Value = "TOTALES";
        worksheet.Cells[row, 2].Style.Font.Bold = true;
        worksheet.Cells[row, 3].Value = resultado.Totales.TotalDebitos;
        worksheet.Cells[row, 4].Value = resultado.Totales.TotalCreditos;
        worksheet.Cells[row, 5].Value = resultado.Totales.TotalSaldoDeudor;
        worksheet.Cells[row, 6].Value = resultado.Totales.TotalSaldoAcreedor;
        worksheet.Cells[row, 7].Value = resultado.Totales.TotalInventarioActivo;
        worksheet.Cells[row, 8].Value = resultado.Totales.TotalInventarioPasivo;
        worksheet.Cells[row, 9].Value = resultado.Totales.TotalPerdida;
        worksheet.Cells[row, 10].Value = resultado.Totales.TotalGanancia;

        for (var col = 3; col <= 10; col++)
        {
            worksheet.Cells[row, col].Style.Numberformat.Format = "#,##0.00";
            worksheet.Cells[row, col].Style.Font.Bold = true;
        }

        // Patrimonio
        row++;
        row++;
        worksheet.Cells[row, 2].Value = "PATRIMONIO";
        worksheet.Cells[row, 2].Style.Font.Bold = true;
        worksheet.Cells[row, 3].Value = resultado.Totales.Patrimonio;
        worksheet.Cells[row, 3].Style.Numberformat.Format = "#,##0.00";
        worksheet.Cells[row, 3].Style.Font.Bold = true;

        // Ajustar anchos de columnas
        worksheet.Column(1).Width = 15;
        worksheet.Column(2).Width = 40;
        for (var col = 3; col <= 10; col++)
        {
            worksheet.Column(col).Width = 15;
        }

        return package.GetAsByteArray();
    }

    private async Task<byte[]> ExportToPdfAsync(BalanceGeneralResultadoDto resultado)
    {
        logger.LogInformation("Exportando Balance General a PDF");

        // Obtener datos de la empresa
        var empresa = await context.Empresa.FirstOrDefaultAsync(e => e.Id == resultado.Parametros.EmpresaId);
        if (empresa == null)
        {
            throw new BusinessException($"Empresa {resultado.Parametros.EmpresaId} no encontrada");
        }

        QuestPDF.Settings.License = LicenseType.Community;

        var document = QuestPDF.Fluent.Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Size(QuestPDF.Helpers.PageSizes.Letter);
                page.Margin(1, Unit.Centimetre);

                page.Header().Column(column =>
                {
                    column.Item().Text(empresa.Nombre).FontSize(14).Bold();
                    column.Item().Text($"RUT: {empresa.Rut}").FontSize(10);
                    column.Item().Text("BALANCE GENERAL - 8 COLUMNAS").FontSize(12).Bold();
                    column.Item().Text($"Período: {resultado.Parametros.FechaDesde} a {resultado.Parametros.FechaHasta}").FontSize(10);
                });

                page.Content().Column(column =>
                {
                    // Tabla de balance
                    column.Item().Table(table =>
                    {
                        // Definir columnas
                        table.ColumnsDefinition(columns =>
                        {
                            columns.RelativeColumn(2); // Código
                            columns.RelativeColumn(4); // Cuenta
                            columns.RelativeColumn(2); // Débitos
                            columns.RelativeColumn(2); // Créditos
                            columns.RelativeColumn(2); // Saldo Deudor
                            columns.RelativeColumn(2); // Saldo Acreedor
                            columns.RelativeColumn(2); // Inv Activo
                            columns.RelativeColumn(2); // Inv Pasivo
                            columns.RelativeColumn(2); // Pérdida
                            columns.RelativeColumn(2); // Ganancia
                        });

                        // Encabezados
                        table.Header(header =>
                        {
                            header.Cell().Background("#CCCCCC").Padding(5).Text("Código").FontSize(8).Bold();
                            header.Cell().Background("#CCCCCC").Padding(5).Text("Cuenta").FontSize(8).Bold();
                            header.Cell().Background("#CCCCCC").Padding(5).Text("Débitos").FontSize(8).Bold();
                            header.Cell().Background("#CCCCCC").Padding(5).Text("Créditos").FontSize(8).Bold();
                            header.Cell().Background("#CCCCCC").Padding(5).Text("Saldo Deudor").FontSize(8).Bold();
                            header.Cell().Background("#CCCCCC").Padding(5).Text("Saldo Acreedor").FontSize(8).Bold();
                            header.Cell().Background("#CCCCCC").Padding(5).Text("Inv Activo").FontSize(8).Bold();
                            header.Cell().Background("#CCCCCC").Padding(5).Text("Inv Pasivo").FontSize(8).Bold();
                            header.Cell().Background("#CCCCCC").Padding(5).Text("Pérdida").FontSize(8).Bold();
                            header.Cell().Background("#CCCCCC").Padding(5).Text("Ganancia").FontSize(8).Bold();
                        });

                        // Datos
                        foreach (var linea in resultado.Lineas)
                        {
                            table.Cell().BorderBottom(0.5f).Padding(3).Text(linea.Codigo ?? "").FontSize(7);
                            table.Cell().BorderBottom(0.5f).Padding(3).Text(linea.Descripcion ?? "").FontSize(7);
                            table.Cell().BorderBottom(0.5f).Padding(3).AlignRight().Text(linea.Debitos.ToString("#,##0.00")).FontSize(7);
                            table.Cell().BorderBottom(0.5f).Padding(3).AlignRight().Text(linea.Creditos.ToString("#,##0.00")).FontSize(7);
                            table.Cell().BorderBottom(0.5f).Padding(3).AlignRight().Text(linea.SaldoDeudor.ToString("#,##0.00")).FontSize(7);
                            table.Cell().BorderBottom(0.5f).Padding(3).AlignRight().Text(linea.SaldoAcreedor.ToString("#,##0.00")).FontSize(7);
                            table.Cell().BorderBottom(0.5f).Padding(3).AlignRight().Text(linea.InventarioActivo.ToString("#,##0.00")).FontSize(7);
                            table.Cell().BorderBottom(0.5f).Padding(3).AlignRight().Text(linea.InventarioPasivo.ToString("#,##0.00")).FontSize(7);
                            table.Cell().BorderBottom(0.5f).Padding(3).AlignRight().Text(linea.Perdida.ToString("#,##0.00")).FontSize(7);
                            table.Cell().BorderBottom(0.5f).Padding(3).AlignRight().Text(linea.Ganancia.ToString("#,##0.00")).FontSize(7);
                        }

                        // Totales
                        table.Cell().ColumnSpan(2).BorderTop(1).Padding(3).Text("TOTALES").FontSize(8).Bold();
                        table.Cell().BorderTop(1).Padding(3).AlignRight().Text(resultado.Totales.TotalDebitos.ToString("#,##0.00")).FontSize(8).Bold();
                        table.Cell().BorderTop(1).Padding(3).AlignRight().Text(resultado.Totales.TotalCreditos.ToString("#,##0.00")).FontSize(8).Bold();
                        table.Cell().BorderTop(1).Padding(3).AlignRight().Text(resultado.Totales.TotalSaldoDeudor.ToString("#,##0.00")).FontSize(8).Bold();
                        table.Cell().BorderTop(1).Padding(3).AlignRight().Text(resultado.Totales.TotalSaldoAcreedor.ToString("#,##0.00")).FontSize(8).Bold();
                        table.Cell().BorderTop(1).Padding(3).AlignRight().Text(resultado.Totales.TotalInventarioActivo.ToString("#,##0.00")).FontSize(8).Bold();
                        table.Cell().BorderTop(1).Padding(3).AlignRight().Text(resultado.Totales.TotalInventarioPasivo.ToString("#,##0.00")).FontSize(8).Bold();
                        table.Cell().BorderTop(1).Padding(3).AlignRight().Text(resultado.Totales.TotalPerdida.ToString("#,##0.00")).FontSize(8).Bold();
                        table.Cell().BorderTop(1).Padding(3).AlignRight().Text(resultado.Totales.TotalGanancia.ToString("#,##0.00")).FontSize(8).Bold();
                    });

                    // Patrimonio
                    column.Item().PaddingTop(10).Row(row =>
                    {
                        row.AutoItem().Text("PATRIMONIO: ").FontSize(10).Bold();
                        row.AutoItem().Text(resultado.Totales.Patrimonio.ToString("#,##0.00")).FontSize(10).Bold();
                    });
                });

                page.Footer().AlignCenter().Text(text =>
                {
                    text.CurrentPageNumber();
                    text.Span(" / ");
                    text.TotalPages();
                });
            });
        });

        return document.GeneratePdf();
    }

    public async Task<IEnumerable<BalanceGeneralDto>> GetByNivelAsync(BalanceGeneralParametrosDto parametros)
    {
        logger.LogInformation("Getting balance by nivel: {Nivel}", parametros.Nivel);

        {
            var resultado = await GenerateBalanceAsync(parametros);
            return resultado.Lineas.Where(l => l.Nivel <= parametros.Nivel);
        }
    }

    /// <summary>
    /// Obtiene movimientos agrupados por cuenta
    /// </summary>
    private async Task<List<MovimientoAgrupado>> GetMovimientosAsync(BalanceGeneralParametrosDto parametros)
    {
        {
            // Convertir fechas a formato OLE (días desde 1899-12-30)
            var fechaDesde = (int)parametros.FechaDesde.ToOADate();
            var fechaHasta = (int)parametros.FechaHasta.ToOADate();

            var query = from mov in context.MovComprobante
                from comp in context.Comprobante
                    .Where(c => c.IdEmpresa == mov.IdEmpresa && c.Ano == mov.Ano && c.IdComp == mov.IdComp)
                from cuenta in context.Cuentas
                    .Where(c => c.IdEmpresa == mov.IdEmpresa && c.Ano == mov.Ano && c.idCuenta == mov.IdCuenta)
                where mov.IdEmpresa == parametros.EmpresaId
                      && mov.Ano == parametros.Ano
                      && comp.Fecha >= fechaDesde
                      && comp.Fecha <= fechaHasta
                      && cuenta.Nivel <= parametros.Nivel
                select new { mov, comp, cuenta };

            // Aplicar filtros adicionales
            if (parametros.LibroOficial)
            {
                query = query.Where(x => x.comp.Estado == 2); // Solo aprobados
            }

            if (parametros.TipoAjuste.HasValue)
            {
                if (parametros.TipoAjuste == TAJUSTE_FINANCIERO)
                {
                    query = query.Where(x => x.comp.TipoAjuste == null 
                                             || x.comp.TipoAjuste == TAJUSTE_FINANCIERO 
                                             || x.comp.TipoAjuste == TAJUSTE_AMBOS);
                }
                else if (parametros.TipoAjuste == TAJUSTE_TRIBUTARIO)
                {
                    query = query.Where(x => x.comp.TipoAjuste == TAJUSTE_TRIBUTARIO 
                                             || x.comp.TipoAjuste == TAJUSTE_AMBOS);
                }
            }

            if (parametros.AreaNegocio.HasValue)
            {
                query = query.Where(x => x.mov.idAreaNeg == parametros.AreaNegocio.Value);
            }

            if (parametros.CentroCosto.HasValue)
            {
                query = query.Where(x => x.mov.idCCosto == parametros.CentroCosto.Value);
            }

            // Agrupar por cuenta
            var resultado = await query
                .GroupBy(x => new 
                { 
                    x.cuenta.idCuenta, 
                    x.cuenta.Codigo, 
                    x.cuenta.Descripcion,
                    x.cuenta.Nivel,
                    x.cuenta.Clasificacion
                })
                .Select(g => new MovimientoAgrupado
                {
                    idCuenta = g.Key.idCuenta,
                    Codigo = g.Key.Codigo,
                    Descripcion = g.Key.Descripcion,
                    Nivel = g.Key.Nivel ?? 0,
                    Clasificacion = g.Key.Clasificacion ?? 0,
                    TotalDebe = g.Sum(x => x.mov.Debe ?? 0),
                    TotalHaber = g.Sum(x => x.mov.Haber ?? 0)
                })
                .OrderBy(x => x.Codigo)
                .ToListAsync();

            return resultado;
        }
    }

    /// <summary>
    /// Calcula los totales de todas las columnas
    /// </summary>
    private BalanceGeneralTotalesDto CalculateTotals(List<BalanceGeneralDto> lineas)
    {
        var totales = new BalanceGeneralTotalesDto
        {
            TotalDebitos = lineas.Sum(l => l.Debitos),
            TotalCreditos = lineas.Sum(l => l.Creditos),
            TotalSaldoDeudor = lineas.Sum(l => l.SaldoDeudor),
            TotalSaldoAcreedor = lineas.Sum(l => l.SaldoAcreedor),
            TotalInventarioActivo = lineas.Sum(l => l.InventarioActivo),
            TotalInventarioPasivo = lineas.Sum(l => l.InventarioPasivo),
            TotalPerdida = lineas.Sum(l => l.Perdida),
            TotalGanancia = lineas.Sum(l => l.Ganancia)
        };

        // Calcular patrimonio
        totales.Patrimonio = totales.TotalInventarioActivo - totales.TotalInventarioPasivo;

        return totales;
    }

    /// <summary>
    /// Clase auxiliar para agrupar movimientos
    /// </summary>
    private class MovimientoAgrupado
    {
        public int idCuenta { get; set; }
        public string? Codigo { get; set; }
        public string? Descripcion { get; set; }
        public int Nivel { get; set; }
        public int Clasificacion { get; set; }
        public double TotalDebe { get; set; }
        public double TotalHaber { get; set; }
    }
}