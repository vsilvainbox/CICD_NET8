﻿namespace App.Features.AuditoriaGeneral;

public interface IAuditoriaGeneralService
{
    Task<List<AuditoriaDto>> GetAllAsync(int empresaId, short ano, AuditoriaFiltrosDto filtros);
    void ValidateFilters(AuditoriaFiltrosDto filtros, int anoEmpresa);
    Task<List<ComboItemDto>> GetTiposComprobanteAsync();
    Task<List<ComboItemDto>> GetTiposAjusteAsync();
    Task<List<ComboItemDto>> GetOperacionesAsync();
    Task<List<ComboItemDto>> GetUsuariosAsync();
    Task CanDeleteImportedAsync(int idComp, int empresaId, short ano, bool confirmarAntiguo = false);
    Task DeleteImportedAsync(int idComp, int empresaId, short ano, int idUsuario, bool confirmarAntiguo = false);
    Task<byte[]> ExportToExcelAsync(int empresaId, short ano, AuditoriaFiltrosDto? filtros);
}