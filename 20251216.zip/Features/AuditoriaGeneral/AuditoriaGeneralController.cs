using Microsoft.AspNetCore.Mvc;
using App.Helpers;

namespace App.Features.AuditoriaGeneral;

public class AuditoriaGeneralController(ILogger<AuditoriaGeneralController> logger) : Controller
{
    public IActionResult Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Auditoría General";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        var empresaId = SessionHelper.EmpresaId;
        int ano = SessionHelper.Ano;

        logger.LogInformation("Loading AuditoriaGeneral Index view for empresaId: {EmpresaId}, año: {Ano}",
            empresaId, ano);

        var viewModel = new AuditoriaGeneralIndexViewModel
        {
            EmpresaId = empresaId,
            Ano = (short)ano
        };

        return View(viewModel);
    }
}