using System.ComponentModel.DataAnnotations;

namespace App.Features.AuditoriaGeneral;

public class AuditoriaDto
{
    public int IdLog { get; set; }
    public int IdComp { get; set; }
    public string FechaOper { get; set; } = string.Empty;
    public double FechaOperOA { get; set; }
    public int CorrComp { get; set; }
    public int CorrCompCurrent { get; set; }
    public int IdTipoComp { get; set; }
    public string TipoComp { get; set; } = string.Empty;
    public int IdTipoAjuste { get; set; }
    public string TAjuste { get; set; } = string.Empty;
    public int IdEstadoComp { get; set; }
    public string EstadoComp { get; set; } = string.Empty;
    public string FechaComp { get; set; } = string.Empty;
    public int FechaCompInt { get; set; }
    public string Usuario { get; set; } = string.Empty;
    public int IdUsuario { get; set; }
    public int IdOper { get; set; }
    public string Oper { get; set; } = string.Empty;
    public int IdEstadoOper { get; set; }
    public string EstadoOper { get; set; } = string.Empty;
    public bool EsEliminado { get; set; }
}

public class AuditoriaFiltrosDto
{
    [Display(Name = "Fecha operación desde")]
    public int? FechaOperDesde { get; set; }

    [Display(Name = "Fecha operación hasta")]
    public int? FechaOperHasta { get; set; }

    [Display(Name = "Fecha comprobante desde")]
    public int? FechaCompDesde { get; set; }

    [Display(Name = "Fecha comprobante hasta")]
    public int? FechaCompHasta { get; set; }

    [Display(Name = "Número")]
    public int? NumeroComp { get; set; }

    [Display(Name = "Usuario")]
    public int? IdUsuario { get; set; }

    [Display(Name = "Operación")]
    public int? IdOper { get; set; }

    [Display(Name = "Tipo comprobante")]
    public int? TipoComp { get; set; }

    [Display(Name = "Tipo Ajuste")]
    public int? TipoAjuste { get; set; }
}

public class ComboItemDto
{
    public int Value { get; set; }
    public string Text { get; set; } = string.Empty;
}

public class AuditoriaGeneralRequestDto
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public AuditoriaFiltrosDto? Filtros { get; set; }
}

public class DeleteImportedRequestDto
{
    public int IdComp { get; set; }
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public int IdUsuario { get; set; }
    public bool ConfirmarAntiguo { get; set; }
}

#region ViewModels

public class AuditoriaGeneralIndexViewModel
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
}

#endregion