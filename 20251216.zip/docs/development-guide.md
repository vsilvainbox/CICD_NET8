# HyperContabilidad - Development Guide

## Getting Started

### Prerequisites

| Requirement | Version | Notes |
|-------------|---------|-------|
| .NET SDK | 9.0+ | Required |
| SQL Server | 2019+ | Or SQL Server Express |
| Node.js | 18+ | For Tailwind CSS |
| IDE | VS 2022 / VS Code / Rider | Any .NET IDE |

### Initial Setup

```bash
# 1. Clone/navigate to project
cd D:\deploy

# 2. Restore .NET dependencies
dotnet restore

# 3. Install Node.js dependencies
npm install

# 4. Build Tailwind CSS
npm run css:build

# 5. Configure database connection
# Edit appsettings.json with your SQL Server connection

# 6. Run the application
dotnet run
```

### Development Mode

```bash
# Watch Tailwind CSS changes
npm run css:watch

# Run with hot reload
dotnet watch run
```

## Project Structure

```
D:\deploy/
├── Features/           # Feature modules (add new features here)
├── Data/               # Entity classes and DbContext
├── Services/           # Shared services
├── Models/             # Shared models
├── Middleware/         # Custom middleware
├── Extensions/         # Extension methods
├── Helpers/            # Utility classes
├── wwwroot/            # Static files
└── docs/               # Documentation
```

## Creating a New Feature

### Step 1: Create Feature Folder

```
Features/
└── NuevaFuncionalidad/
    ├── NuevaFuncionalidadController.cs
    ├── NuevaFuncionalidadApiController.cs
    ├── NuevaFuncionalidadService.cs
    ├── INuevaFuncionalidadService.cs
    ├── NuevaFuncionalidadDto.cs
    ├── NuevaFuncionalidadViewModel.cs
    └── Views/
        └── Index.cshtml
```

### Step 2: Create Service Interface

```csharp
// INuevaFuncionalidadService.cs
namespace App.Features.NuevaFuncionalidad;

public interface INuevaFuncionalidadService
{
    Task<IEnumerable<NuevaFuncionalidadDto>> GetAllAsync(int empresaId);
    Task<NuevaFuncionalidadDto?> GetByIdAsync(int id);
    Task<ValidationResult> CreateAsync(CreateNuevaFuncionalidadDto dto);
    Task<ValidationResult> UpdateAsync(int id, UpdateNuevaFuncionalidadDto dto);
    Task<bool> DeleteAsync(int id);
}
```

### Step 3: Implement Service

```csharp
// NuevaFuncionalidadService.cs
namespace App.Features.NuevaFuncionalidad;

public class NuevaFuncionalidadService : INuevaFuncionalidadService
{
    private readonly LpContabContext _context;
    private readonly ILogger<NuevaFuncionalidadService> _logger;

    public NuevaFuncionalidadService(
        LpContabContext context,
        ILogger<NuevaFuncionalidadService> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<IEnumerable<NuevaFuncionalidadDto>> GetAllAsync(int empresaId)
    {
        return await _context.NuevaFuncionalidad
            .Where(x => x.EmpresaId == empresaId)
            .Select(x => new NuevaFuncionalidadDto
            {
                Id = x.Id,
                // ... map properties
            })
            .ToListAsync();
    }

    // ... implement other methods
}
```

### Step 4: Create MVC Controller

```csharp
// NuevaFuncionalidadController.cs
namespace App.Features.NuevaFuncionalidad;

[Authorize]
public class NuevaFuncionalidadController : Controller
{
    private readonly INuevaFuncionalidadService _service;

    public NuevaFuncionalidadController(INuevaFuncionalidadService service)
    {
        _service = service;
    }

    public async Task<IActionResult> Index()
    {
        var empresaId = SessionHelper.GetEmpresaId();
        var data = await _service.GetAllAsync(empresaId);
        return View(data);
    }
}
```

### Step 5: Create API Controller

```csharp
// NuevaFuncionalidadApiController.cs
namespace App.Features.NuevaFuncionalidad;

[ApiController]
[Route("api/[controller]")]
public class NuevaFuncionalidadApiController : ControllerBase
{
    private readonly INuevaFuncionalidadService _service;

    public NuevaFuncionalidadApiController(INuevaFuncionalidadService service)
    {
        _service = service;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll([FromQuery] int empresaId)
    {
        var data = await _service.GetAllAsync(empresaId);
        return Ok(data);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var item = await _service.GetByIdAsync(id);
        if (item == null) return NotFound();
        return Ok(item);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateNuevaFuncionalidadDto dto)
    {
        var result = await _service.CreateAsync(dto);
        if (!result.IsValid) return BadRequest(result.Errors);
        return Ok(result);
    }
}
```

### Step 6: Create View

```html
<!-- Views/Index.cshtml -->
@model IEnumerable<NuevaFuncionalidadDto>
@{
    ViewData["Title"] = "Nueva Funcionalidad";
}

<div class="container mx-auto p-4">
    <h1 class="text-2xl font-bold mb-4">Nueva Funcionalidad</h1>

    <div class="bg-white rounded-lg shadow p-4">
        <!-- Content here -->
    </div>
</div>
```

## Coding Standards

### Naming Conventions

| Element | Convention | Example |
|---------|------------|---------|
| Classes | PascalCase | `ComprobanteService` |
| Interfaces | IPascalCase | `IComprobanteService` |
| Methods | PascalCase | `GetAllAsync` |
| Properties | PascalCase | `EmpresaId` |
| Private fields | _camelCase | `_context` |
| Parameters | camelCase | `empresaId` |
| Constants | UPPER_CASE | `MAX_RESULTS` |

### Async Pattern

```csharp
// Always use async/await for I/O operations
public async Task<IEnumerable<ItemDto>> GetAllAsync()
{
    return await _context.Items.ToListAsync();
}

// Name async methods with Async suffix
public async Task<bool> DeleteAsync(int id);
```

### Error Handling

```csharp
public async Task<IActionResult> GetById(int id)
{
    try
    {
        var item = await _service.GetByIdAsync(id);
        if (item == null)
            return NotFound(new { error = "Item no encontrado" });
        return Ok(item);
    }
    catch (Exception ex)
    {
        _logger.LogError(ex, "Error getting item {Id}", id);
        return StatusCode(500, new { error = "Error interno del servidor" });
    }
}
```

### Logging

```csharp
// Use structured logging
_logger.LogInformation("Processing {Count} items for empresa {EmpresaId}",
    items.Count, empresaId);

// Log levels
_logger.LogDebug("Detailed info for debugging");
_logger.LogInformation("General operational info");
_logger.LogWarning("Potential issues");
_logger.LogError(ex, "Errors with exception");
```

## Database Operations

### Adding a New Entity

```csharp
// 1. Create entity class in Data/
public class NuevaEntidad
{
    public int Id { get; set; }
    public string Nombre { get; set; } = "";
    public int EmpresaId { get; set; }
}

// 2. Add DbSet to LpContabContext.cs
public virtual DbSet<NuevaEntidad> NuevaEntidad { get; set; }

// 3. Create migration
dotnet ef migrations add AddNuevaEntidad

// 4. Apply migration
dotnet ef database update
```

### Query Patterns

```csharp
// Simple query
var items = await _context.Items
    .Where(x => x.EmpresaId == empresaId)
    .ToListAsync();

// With projection
var dtos = await _context.Items
    .Where(x => x.EmpresaId == empresaId)
    .Select(x => new ItemDto { Id = x.Id, Nombre = x.Nombre })
    .ToListAsync();

// With includes
var item = await _context.Items
    .Include(x => x.Movimientos)
    .FirstOrDefaultAsync(x => x.Id == id);

// Split query for complex includes
var items = await _context.Items
    .AsSplitQuery()
    .Include(x => x.Movimientos)
    .Include(x => x.Documentos)
    .ToListAsync();
```

## Frontend Development

### Tailwind CSS

```bash
# Build CSS
npm run css:build

# Watch for changes (development)
npm run css:watch
```

### Using Tailwind in Views

```html
<div class="bg-white rounded-lg shadow-md p-6">
    <h2 class="text-xl font-semibold text-gray-800 mb-4">Título</h2>
    <button class="bg-primary hover:bg-primary-700 text-white px-4 py-2 rounded">
        Guardar
    </button>
</div>
```

### JavaScript Patterns

```javascript
// API calls with jQuery
async function loadData() {
    try {
        const response = await $.ajax({
            url: '/api/NuevaFuncionalidad',
            method: 'GET',
            data: { empresaId: currentEmpresaId }
        });
        renderData(response);
    } catch (error) {
        console.error('Error loading data:', error);
        showError('Error al cargar datos');
    }
}

// Form submission
$('#myForm').on('submit', async function(e) {
    e.preventDefault();
    const formData = $(this).serializeObject();

    try {
        await $.ajax({
            url: '/api/NuevaFuncionalidad',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(formData)
        });
        showSuccess('Guardado exitosamente');
    } catch (error) {
        showError('Error al guardar');
    }
});
```

## Testing

### Manual Testing Checklist

- [ ] Feature loads without errors
- [ ] CRUD operations work correctly
- [ ] Validation messages display properly
- [ ] Error handling works
- [ ] Session/auth requirements enforced
- [ ] Company context is respected

### API Testing

```bash
# Using curl or similar tools
curl -X GET "http://localhost:5000/api/NuevaFuncionalidad?empresaId=1"
curl -X POST "http://localhost:5000/api/NuevaFuncionalidad" \
     -H "Content-Type: application/json" \
     -d '{"nombre": "Test"}'
```

## Debugging

### Common Issues

| Issue | Solution |
|-------|----------|
| View not found | Check view location format |
| Service not injected | Verify interface naming (I prefix) |
| 401 on API | Check [Authorize] attribute |
| Company not selected | Use SessionHelper.GetEmpresaId() |

### Debug Configuration

```json
// launchSettings.json
{
  "profiles": {
    "Development": {
      "environmentVariables": {
        "ASPNETCORE_ENVIRONMENT": "Development"
      }
    }
  }
}
```

## Reference: Existing Features

See `features.md` for the complete catalog of migrated features with their status and documentation.

For detailed implementation patterns, examine these well-documented features:
- `Features/Comprobante/` - Complex CRUD with movements
- `Features/BalanceClasificado/` - Report generation
- `Features/ListarComprobantes/` - Grid with filtering
- `Features/ImportarEmpresa/` - File import functionality
