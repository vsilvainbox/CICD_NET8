# Principios de Diseño UI - HyperContabilidad Web

Documento de referencia basado en el análisis del módulo **Comprobante** (vista más pulida del sistema).

---

## 1. ESTRUCTURA GENERAL DE PÁGINAS

### Contenedor Principal
```html
<div class="flex-1 overflow-auto bg-gray-50 p-4">
    <div class="max-w-[1600px] mx-auto">
        <!-- Header -->
        <!-- Contenido -->
    </div>
</div>
```

### Header de Página
```html
<header class="mb-6">
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-xl font-semibold text-gray-900">Título Principal</h1>
            <p class="mt-1 text-sm text-gray-500">Descripción contextual</p>
        </div>
        <!-- Botones solo en listados/tablas, NO en formularios -->
        <div class="flex items-center gap-2">
            <!-- Botones de acción (solo para listados) -->
        </div>
    </div>
</header>
```

**Principios:**
- Título: `text-xl font-semibold text-gray-900`
- Subtítulo: `text-sm text-gray-500`
- Botones en header **solo para listados/tablas** (ver sección 5)

---

## 2. CARDS Y CONTENEDORES

### Card Estándar (sin header separado)
```html
<div class="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
    <!-- Contenido directo -->
</div>
```

### Card Completa con Header y Footer (PATRÓN ESTÁNDAR)

Este es el patrón estándar para formularios y secciones de datos. **Todas las cards deben tener un header** que identifique su contenido.

```html
<div class="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">

    <!-- ══════════════════════════════════════════════════════════════ -->
    <!-- HEADER: Fondo gris claro, título + descripción                -->
    <!-- ══════════════════════════════════════════════════════════════ -->
    <div class="px-6 py-4 border-b border-gray-200 bg-gray-50">
        <h2 class="text-base font-semibold text-gray-900">Título de la Card</h2>
        <p class="text-xs text-gray-500 mt-0.5">Descripción breve del contenido</p>
    </div>

    <!-- ══════════════════════════════════════════════════════════════ -->
    <!-- SECCIONES: Separadas por border-b border-gray-100             -->
    <!-- ══════════════════════════════════════════════════════════════ -->
    <div class="px-6 py-4 border-b border-gray-100">
        <h3 class="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">
            Nombre de Sección
        </h3>
        <div class="grid grid-cols-6 gap-3">
            <!-- Campos del formulario -->
        </div>
    </div>

    <div class="px-6 py-4 border-b border-gray-100">
        <h3 class="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">
            Otra Sección
        </h3>
        <div class="grid grid-cols-6 gap-3">
            <!-- Más campos -->
        </div>
    </div>

    <!-- ══════════════════════════════════════════════════════════════ -->
    <!-- FOOTER: Fondo gris claro, botones alineados a la derecha      -->
    <!-- ══════════════════════════════════════════════════════════════ -->
    <div class="px-6 py-4 bg-gray-50 flex justify-end">
        <button type="submit" class="px-5 py-2 bg-primary-600 text-white text-sm rounded-lg hover:bg-primary-700 shadow-sm font-medium transition-colors">
            <i class="fas fa-save mr-1.5"></i>
            Guardar Cambios
        </button>
    </div>

</div>
```

### Especificaciones del Patrón Card

| Elemento | Clases | Descripción |
|----------|--------|-------------|
| **Card contenedor** | `bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden` | Contenedor principal |
| **Header** | `px-6 py-4 border-b border-gray-200 bg-gray-50` | Fondo gris, borde más visible |
| **Título header** | `text-base font-semibold text-gray-900` | Título principal de la card |
| **Subtítulo header** | `text-xs text-gray-500 mt-0.5` | Descripción del contenido |
| **Sección** | `px-6 py-4 border-b border-gray-100` | Borde sutil entre secciones |
| **Título sección** | `text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3` | Headers de sección internos |
| **Grid de campos** | `grid grid-cols-6 gap-3` | Layout de formulario |
| **Footer** | `px-6 py-4 bg-gray-50 flex justify-end` | Fondo gris, botones a la derecha |

### Ejemplo Real: DatosEmpresa

```
┌─────────────────────────────────────────────────────────────────┐
│ ░░░░░░░░░░░░░░░░░░░░░ HEADER (bg-gray-50) ░░░░░░░░░░░░░░░░░░░░░ │
│ Información de la Empresa                                       │
│ Datos generales, dirección, información legal y representantes  │
├─────────────────────────────────────────────────────────────────┤
│ DATOS BÁSICOS                                                   │
│ ┌─────────┐ ┌─────────────┐ ┌─────────┐                        │
│ │ RUT     │ │ Nombre Corto│ │Clave SII│                        │
│ └─────────┘ └─────────────┘ └─────────┘                        │
│ ┌─────────────────────────┐ ┌─────────┐                        │
│ │ Razón Social            │ │ Email   │ ...                    │
│ └─────────────────────────┘ └─────────┘                        │
├─────────────────────────────────────────────────────────────────┤
│ DIRECCIÓN                                                       │
│ ┌─────────────────┐ ┌────────┐ ┌────────┐ ┌────────┐           │
│ │ Calle           │ │ Número │ │ Depto  │ │ Ciudad │           │
│ └─────────────────┘ └────────┘ └────────┘ └────────┘           │
├─────────────────────────────────────────────────────────────────┤
│ DATOS LEGALES                                                   │
│ ...                                                             │
├─────────────────────────────────────────────────────────────────┤
│ ░░░░░░░░░░░░░░░░░░░░░ FOOTER (bg-gray-50) ░░░░░░░░░░░░░░░░░░░░░ │
│                                            [ Guardar Cambios ]  │
└─────────────────────────────────────────────────────────────────┘
```

### Card para Tablas/Listados

Para cards que contienen tablas o listas con acciones por fila:

```html
<div class="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
    <!-- Header con título y botón de acción -->
    <div class="px-6 py-4 border-b border-gray-200 bg-gray-50 flex items-center justify-between">
        <div>
            <h2 class="text-base font-semibold text-gray-900">Propietarios y Socios</h2>
            <p class="text-xs text-gray-500 mt-0.5">Gestión de participaciones societarias</p>
        </div>
        <button type="button" class="px-3 py-1.5 bg-primary-600 text-white text-sm rounded-lg hover:bg-primary-700">
            <i class="fas fa-plus mr-1"></i>Agregar
        </button>
    </div>

    <!-- Contenido: tabla -->
    <div class="overflow-x-auto">
        <table class="w-full">
            <!-- ... -->
        </table>
    </div>

    <!-- Footer opcional con totales o paginación -->
    <div class="px-6 py-3 bg-gray-50 border-t border-gray-100">
        <span class="text-sm text-gray-600">Total: 100%</span>
    </div>
</div>
```

**Principios:**
- **Siempre incluir header** con título descriptivo
- Sin iconos en headers de cards
- `overflow-hidden` en el contenedor padre
- Header y Footer: `bg-gray-50` con `border-gray-200`
- Secciones internas: `border-gray-100` (más sutil)
- Sombra mínima: `shadow-sm`

---

## 3. MODALES - DISEÑO MINIMALISTA

### Estructura Base del Modal
```html
<div id="modalId" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 z-50 flex items-start justify-center overflow-hidden">
    <div class="relative bg-white rounded-lg shadow-xl w-full max-w-3xl mx-4 my-8 animate-fadeIn flex flex-col"
         style="max-height: calc(100vh - 4rem);">

        <!-- Header FIJO -->
        <div class="flex items-center justify-between px-5 py-4 border-b border-gray-100 flex-shrink-0">
            <h3 class="text-base font-semibold text-gray-900">Título del Modal</h3>
            <button type="button" onclick="cerrarModal('modalId')"
                    class="p-1 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded transition-colors">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M6 18L18 6M6 6l12 12"/>
                </svg>
            </button>
        </div>

        <!-- Barra de búsqueda FIJA (opcional) -->
        <div class="px-5 py-3 border-b border-gray-100 flex-shrink-0">
            <div class="relative">
                <svg class="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400">...</svg>
                <input type="text" placeholder="Buscar..."
                       class="w-full pl-10 pr-4 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 shadow-sm">
                <span class="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-gray-400"><!-- contador --></span>
            </div>
        </div>

        <!-- Contenido con SCROLL -->
        <div class="flex-1 overflow-y-auto overflow-x-hidden">
            <!-- Tabla, lista, etc. -->
        </div>

        <!-- Preview de selección (opcional) -->
        <div class="hidden px-5 py-3 bg-primary-50/50 border-t border-primary-100 flex-shrink-0">
            <div class="flex items-center gap-2">
                <svg class="w-4 h-4 text-primary-600"><!-- check icon --></svg>
                <span class="text-sm text-gray-700">Elemento seleccionado</span>
            </div>
        </div>

        <!-- Footer FIJO -->
        <div class="flex items-center justify-end gap-2 px-5 py-4 border-t border-gray-100 flex-shrink-0">
            <button type="button" onclick="cerrarModal('modalId')"
                    class="px-4 py-2 text-sm text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors">
                Cancelar
            </button>
            <button type="button" id="btnConfirmar" disabled
                    class="px-4 py-2 text-sm bg-primary-600 text-white rounded-lg hover:bg-primary-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
                Seleccionar
            </button>
        </div>
    </div>
</div>
```

### Principios Clave de Modales

| Aspecto | Valor |
|---------|-------|
| Overlay | `bg-gray-600 bg-opacity-50` |
| Ancho máximo | `max-w-2xl` a `max-w-3xl` |
| Alto máximo | `max-height: calc(100vh - 4rem)` |
| Bordes internos | `border-gray-100` (más sutil que gray-200) |
| Padding header/footer | `px-5 py-4` |
| Padding búsqueda | `px-5 py-3` |
| Título | `text-base font-semibold text-gray-900` |
| Botón cerrar | Solo icono X, sin texto |
| Animación | `animate-fadeIn` (scale + opacity) |

### Estilos de Filas Seleccionables
```css
/* Fila base */
.item-row {
    cursor: pointer;
    transition: all 0.15s ease;
    border-left: 2px solid transparent;
}

/* Hover */
.item-row:hover {
    background-color: #f9fafb; /* gray-50 */
}

/* Seleccionado */
.item-row.selected {
    background-color: #fef7f4; /* primary-50 personalizado */
    border-left-color: #d64000; /* primary */
}
```

### Resaltado de Búsqueda
```css
.search-match {
    background-color: #fef9c3; /* yellow-100 */
    color: #854d0e; /* yellow-800 */
    padding: 1px 3px;
    border-radius: 2px;
}
```

---

## 4. ESTADOS DEL MODAL

### Estado de Carga
```html
<div class="flex flex-col items-center justify-center py-16">
    <div class="w-8 h-8 border-2 border-gray-200 border-t-primary-600 rounded-full animate-spin"></div>
    <span class="mt-3 text-sm text-gray-500">Cargando...</span>
</div>
```

### Estado Vacío
```html
<div class="flex flex-col items-center justify-center py-16">
    <div class="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mb-3">
        <svg class="w-6 h-6 text-gray-400"><!-- icono contextual --></svg>
    </div>
    <p class="text-sm text-gray-500">No hay elementos disponibles</p>
</div>
```

### Sin Resultados de Búsqueda
```html
<div class="flex flex-col items-center justify-center py-16">
    <div class="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mb-3">
        <svg class="w-6 h-6 text-gray-400"><!-- search icon --></svg>
    </div>
    <p class="text-sm text-gray-500">Sin resultados</p>
    <p class="text-xs text-gray-400 mt-1">Intenta con otro término de búsqueda</p>
</div>
```

---

## 5. UBICACIÓN DE BOTONES DE ACCIÓN

### Regla Principal: Contexto determina ubicación

| Tipo de Página | Ubicación del Botón | Ejemplo |
|----------------|---------------------|---------|
| **Formularios de datos** | Final del formulario | DatosEmpresa, DatosOficina, Configuración |
| **Listados/Tablas** | Header derecha | AreasNegocio, CentrosCosto, ListarComprobantes |
| **Editores complejos** | Header + Toolbar | Comprobante (tiene toolbar y header) |
| **Modales** | Footer del modal | Todos los modales |

### Formularios: Botón al Final

Para formularios tradicionales de ingreso/edición de datos, el botón **siempre va al final**:

```html
<div class="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
    <!-- Secciones del formulario -->
    <div class="px-6 py-5 border-b border-gray-100">
        <!-- campos... -->
    </div>
    <div class="px-6 py-5 border-b border-gray-100">
        <!-- más campos... -->
    </div>

    <!-- FOOTER: Botón al final -->
    <div class="px-6 py-4 bg-gray-50 flex justify-end">
        <button type="submit" class="px-5 py-2 bg-primary-600 text-white text-sm rounded-lg...">
            Guardar Cambios
        </button>
    </div>
</div>
```

**Razón:** Sigue el flujo natural de lectura/acción:
```
Usuario llena campo 1 → campo 2 → ... → campo N → [Guardar]
```

### Listados/Tablas: Botón en Header

Para páginas de listado con acciones globales (crear, exportar):

```html
<header class="mb-6">
    <div class="flex items-center justify-between">
        <div>
            <h1>Áreas de Negocio</h1>
            <p>Gestión de áreas...</p>
        </div>
        <div class="flex gap-2">
            <button>Exportar</button>
            <button class="bg-primary-600">Nueva Área</button>  <!-- Header derecha -->
        </div>
    </div>
</header>
```

**Razón:** La acción "Nuevo" no es parte de un flujo de formulario, es una acción global de la página.

### Resumen Visual

```
FORMULARIO (DatosEmpresa)          LISTADO (AreasNegocio)
┌─────────────────────────┐        ┌─────────────────────────┐
│ Título                  │        │ Título        [+ Nuevo] │ ← Header
├─────────────────────────┤        ├─────────────────────────┤
│ Campo 1                 │        │ Barra búsqueda          │
│ Campo 2                 │        ├─────────────────────────┤
│ Campo 3                 │        │ Fila 1          [Editar]│
│ ...                     │        │ Fila 2          [Editar]│
├─────────────────────────┤        │ ...                     │
│           [Guardar]     │ ← Final└─────────────────────────┘
└─────────────────────────┘
```

---

## 6. BOTONES - JERARQUÍA Y ESTILOS

### Jerarquía de Botones

```html
<!-- PRIMARIO - Acción principal -->
<button class="px-4 py-2 bg-primary-600 text-white text-sm rounded-lg hover:bg-primary-700 shadow-sm font-medium transition-colors">
    <i class="fas fa-save mr-1.5"></i>
    Guardar
</button>

<!-- SECUNDARIO - Acciones alternativas -->
<button class="px-4 py-2 bg-white border border-gray-300 text-gray-700 text-sm rounded-lg hover:bg-gray-50 shadow-sm font-medium transition-colors">
    <i class="fas fa-file-excel mr-1.5"></i>
    Exportar
</button>

<!-- GHOST/TEXTO - Cancelar, cerrar -->
<button class="px-4 py-2 text-sm text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors">
    Cancelar
</button>

<!-- ICON BUTTON - Toolbar compacta -->
<button class="inline-flex items-center px-2.5 py-1.5 text-gray-600 hover:bg-gray-100 rounded text-sm">
    <svg class="w-4 h-4">...</svg>
    <span class="ml-1.5 hidden sm:inline">Texto</span>
</button>

<!-- DESTRUCTIVO -->
<button class="px-2.5 py-1.5 text-red-500 hover:bg-red-50 rounded text-sm">
    <svg class="w-4 h-4">...</svg>
</button>

<!-- DISABLED -->
<button disabled class="... disabled:opacity-40 disabled:cursor-not-allowed">
```

---

## 6. FORMULARIOS INLINE (Compactos)

### Campos en Línea
```html
<div class="flex flex-wrap items-end gap-4">
    <!-- Campo con ancho fijo -->
    <div class="w-36">
        <label class="block text-xs font-medium text-gray-500 mb-1">
            Campo <span class="text-red-500">*</span>
        </label>
        <input class="w-full px-3 py-1.5 text-sm border border-gray-300 rounded focus:ring-1 focus:ring-primary-500 focus:border-primary-500">
    </div>

    <!-- Campo flexible -->
    <div class="flex-1 min-w-[200px]">
        <label class="block text-xs font-medium text-gray-500 mb-1">Glosa</label>
        <input class="w-full px-3 py-1.5 text-sm border ...">
    </div>
</div>
```

**Principios:**
- Labels: `text-xs font-medium text-gray-500`
- Inputs compactos: `py-1.5 text-sm`
- Anchos fijos para campos cortos: `w-28`, `w-32`, `w-36`, `w-40`
- `flex-1 min-w-[200px]` para campos que deben crecer

---

## 7. TOOLBAR DE ACCIONES

```html
<div class="flex items-center justify-between bg-white rounded-lg shadow-sm border border-gray-200 px-4 py-2">
    <!-- Acciones izquierda -->
    <div class="flex items-center gap-2">
        <button class="inline-flex items-center px-3 py-1.5 bg-white border border-gray-300 text-gray-700 rounded text-sm hover:bg-gray-50">
            <svg class="w-4 h-4 mr-1.5">...</svg>
            Acción
        </button>

        <!-- Separador visual -->
        <div class="h-5 w-px bg-gray-300 mx-1"></div>

        <button class="inline-flex items-center px-2.5 py-1.5 text-gray-600 hover:bg-gray-100 rounded text-sm">
            <svg class="w-4 h-4">...</svg>
            <span class="ml-1.5 hidden sm:inline">Texto</span>
        </button>
    </div>

    <!-- Acciones derecha -->
    <div class="flex items-center gap-2">
        ...
    </div>
</div>
```

---

## 8. TABLAS

### Header de Tabla (sticky)
```html
<thead class="bg-gray-50 sticky top-0 z-10 shadow-sm">
    <tr>
        <th class="px-5 py-2.5 text-left text-xs font-medium text-gray-500 uppercase tracking-wide bg-gray-50">
            Columna
        </th>
    </tr>
</thead>
```

### Celdas
```html
<td class="px-4 py-2 text-sm text-gray-900">Contenido</td>
<td class="px-4 py-2 text-sm text-gray-600">Secundario</td>
<td class="px-4 py-2 text-sm font-mono text-gray-600">Código</td>
```

---

## 9. ANIMACIONES

### Fade In Modal
```css
.animate-fadeIn {
    animation: modalFadeIn 0.2s ease-out;
}

@keyframes modalFadeIn {
    from {
        opacity: 0;
        transform: scale(0.98) translateY(-8px);
    }
    to {
        opacity: 1;
        transform: scale(1) translateY(0);
    }
}
```

---

## 10. PALETA DE COLORES

| Uso | Color | Clase Tailwind |
|-----|-------|----------------|
| Primary | #d64000 | `primary-600` |
| Primary hover | | `primary-700` |
| Primary light | #fef7f4 | `primary-50` |
| Texto principal | | `text-gray-900` |
| Texto secundario | | `text-gray-600` |
| Texto terciario | | `text-gray-500` |
| Texto muted | | `text-gray-400` |
| Bordes cards | | `border-gray-200` |
| Bordes modales | | `border-gray-100` |
| Fondos | | `bg-gray-50` |
| Fondos hover | | `bg-gray-100` |
| Error | | `text-red-500` / `bg-red-50` |
| Success | | `text-green-600` / `bg-green-100` |

---

## 11. RESPONSIVE

### Ocultar Texto en Pantallas Pequeñas
```html
<button class="...">
    <svg class="w-4 h-4">...</svg>
    <span class="ml-1.5 hidden sm:inline">Texto corto</span>
    <span class="ml-1.5 hidden lg:inline">Texto largo</span>
</button>
```

### Breakpoints Comunes
- `sm:` - Mostrar texto en botones
- `md:` - Cambiar layout
- `lg:` - Mostrar textos largos
- `xl:` - Expandir completamente

---

## CHECKLIST DE IMPLEMENTACIÓN

### Estructura General
- [ ] Header con título + subtítulo descriptivo
- [ ] Cards sin iconos en headers
- [ ] Bordes sutiles (`gray-100` en modales, `gray-200` en cards)

### Ubicación de Botones (según contexto)
- [ ] **Formularios**: Botón Guardar al FINAL del formulario
- [ ] **Listados/Tablas**: Botones (Nuevo, Exportar) en header derecha
- [ ] **Modales**: Botones en footer del modal

### Modales
- [ ] Estructura: header fijo → búsqueda fija → contenido scroll → footer fijo
- [ ] Estados: loading, empty, no-results
- [ ] Preview de selección
- [ ] Animación fadeIn
- [ ] Selección visual con `border-left` de color primary
- [ ] Highlight de búsqueda amarillo

### Formularios
- [ ] Labels: `text-xs font-medium text-gray-500`
- [ ] Inputs compactos: `py-1.5 text-sm`
- [ ] Títulos de sección: `text-xs font-semibold text-gray-400 uppercase tracking-wider`
- [ ] Footer con fondo: `bg-gray-50 px-6 py-4 flex justify-end`
