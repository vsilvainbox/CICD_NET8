# HyperContabilidad - Architecture Documentation

## Architecture Overview

HyperContabilidad uses **Vertical Slice Architecture** (also known as Feature-Based Architecture), where the codebase is organized by business features rather than technical layers.

```
┌─────────────────────────────────────────────────────────────────┐
│                        CLIENT BROWSER                          │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    ASP.NET Core Pipeline                       │
├─────────────────────────────────────────────────────────────────┤
│  ExceptionMiddleware → Static Files → Routing → Session        │
│  → Authentication → Authorization → Endpoints                  │
└─────────────────────────────────────────────────────────────────┘
                              │
              ┌───────────────┴───────────────┐
              ▼                               ▼
┌─────────────────────────┐     ┌─────────────────────────┐
│    MVC Controllers      │     │    API Controllers      │
│   (Returns Views)       │     │   (Returns JSON)        │
└─────────────────────────┘     └─────────────────────────┘
              │                               │
              └───────────────┬───────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Feature Services                            │
│         (Business Logic - Auto-registered via DI)              │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                  Entity Framework Core                         │
│                    (LpContabContext)                           │
└─────────────────────────────────────────────────────────────────┘
                              │
              ┌───────────────┴───────────────┐
              ▼                               ▼
┌─────────────────────────┐     ┌─────────────────────────┐
│      SQL Server         │     │       SQLite            │
│   (Primary - LpContab)  │     │  (Secondary - LpRemu)   │
└─────────────────────────┘     └─────────────────────────┘
```

## Design Patterns

### 1. Vertical Slice Architecture

Each feature is self-contained with all its dependencies:

```
Features/Comprobante/
├── ComprobanteController.cs      # HTTP entry point (MVC)
├── ComprobanteApiController.cs   # HTTP entry point (API)
├── ComprobanteService.cs         # Business logic
├── IComprobanteService.cs        # Abstraction
├── ComprobanteDto.cs             # Data contracts
├── ComprobanteViewModel.cs       # View binding
└── Views/                        # UI templates
```

**Benefits:**
- High cohesion within features
- Low coupling between features
- Easy to understand, modify, and test individual features
- Clear ownership boundaries

### 2. Controller Separation

Two types of controllers per feature:

| Type | Purpose | Returns | Authentication |
|------|---------|---------|----------------|
| `*Controller.cs` | Page rendering | Views (HTML) | Cookie-based |
| `*ApiController.cs` | Data operations | JSON | Optional (network-level in prod) |

### 3. Service Layer Pattern

```csharp
// Interface definition
public interface IComprobanteService
{
    Task<IEnumerable<ComprobanteDto>> GetAllAsync(int empresaId);
    Task<ComprobanteDto?> GetByIdAsync(int id);
    Task<ValidationResult> CreateAsync(CreateComprobanteDto dto);
    Task<ValidationResult> UpdateAsync(int id, UpdateComprobanteDto dto);
    Task<bool> DeleteAsync(int id);
}

// Auto-registration in Program.cs
builder.Services.AddFeatureServices(); // Scans and registers all I*Service
```

### 4. DTO Pattern

- **DTOs:** Flat data structures for API transfer
- **ViewModels:** UI-specific models with display logic
- **Entities:** EF Core mapped classes (Data folder)

## Authentication & Authorization

### Authentication Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                    Cookie Authentication                       │
├─────────────────────────────────────────────────────────────────┤
│  Login Path:     /Auth/Login                                   │
│  Logout Path:    /Auth/Logout                                  │
│  Access Denied:  /Auth/AccessDenied                            │
│  Expiration:     8 hours                                       │
│  Cookie Name:    .HyperContabilidad.Auth                       │
└─────────────────────────────────────────────────────────────────┘
```

### Session Management

```
┌─────────────────────────────────────────────────────────────────┐
│                    Session Configuration                       │
├─────────────────────────────────────────────────────────────────┤
│  Provider:       Distributed Memory Cache                      │
│  Idle Timeout:   30 minutes                                    │
│  Cookie Name:    .HyperContabilidad.Session                    │
└─────────────────────────────────────────────────────────────────┘
```

### Authorization Attributes

```csharp
[RequireEmpresa]        // Requires company selection
[RequirePrivilegio]     // Requires specific privilege
[Authorize]             // Standard ASP.NET Core auth
```

## Data Architecture

### Database Strategy

| Database | Engine | Purpose | Connection |
|----------|--------|---------|------------|
| LpContab | SQL Server | Primary accounting data | DefaultConnection |
| LpRemu | SQLite | Payroll integration | LpRemuConnection |

### Entity Framework Configuration

```csharp
builder.Services.AddDbContext<LpContabContext>(options =>
{
    options.UseSqlServer(connectionString, sqlOptions =>
    {
        sqlOptions.UseQuerySplittingBehavior(QuerySplittingBehavior.SplitQuery);
        sqlOptions.UseCompatibilityLevel(120);
        sqlOptions.CommandTimeout(120);
    });
});
```

### Key Entities Relationships

```
Empresa (Company)
    │
    ├── EmpresasAno (Company-Year)
    │       │
    │       ├── Comprobante (Vouchers)
    │       │       └── MovComprobante (Movements)
    │       │
    │       ├── Documento (Documents)
    │       │       └── MovDocumento (Doc Movements)
    │       │
    │       └── ActFijoFicha (Fixed Assets)
    │
    ├── Cuentas (Chart of Accounts)
    │
    └── Usuarios (Users)
            └── UsuarioEmpresa (User-Company Access)
```

## Frontend Architecture

### View Engine Configuration

```csharp
.AddRazorOptions(options =>
{
    options.ViewLocationFormats.Clear();
    options.ViewLocationFormats.Add("/Features/{1}/Views/{0}.cshtml");
    options.ViewLocationFormats.Add("/Features/Shared/{0}.cshtml");
    options.ViewLocationFormats.Add("/Features/{1}/EditorTemplates/{0}.cshtml");
    options.ViewLocationFormats.Add("/Features/Shared/EditorTemplates/{0}.cshtml");
})
```

### CSS Architecture (Tailwind)

```javascript
// tailwind.config.js
module.exports = {
  content: [
    './Features/**/*.cshtml',
    './Views/**/*.cshtml',
    './wwwroot/js/**/*.js'
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#d64000',  // Brand orange
          // ... shade variants
        }
      }
    }
  }
}
```

### JavaScript Libraries

| Library | Purpose |
|---------|---------|
| jQuery | DOM manipulation, AJAX |
| jQuery Validation | Form validation |
| jsTree | Hierarchical tree views |
| Font Awesome | Icons |

## Cross-Cutting Concerns

### Error Handling

```csharp
// ExceptionMiddleware catches all exceptions
app.UseMiddleware<ExceptionMiddleware>();

// Errors logged to ErrorLog table
builder.Services.AddScoped<IErrorLogService, ErrorLogService>();
```

### Logging (Serilog)

```csharp
// Configured with enrichers
- Environment enricher
- Thread enricher
- Structured logging to files
```

### External Integrations

#### SII (Chilean Tax Authority)

```csharp
// Configuration in appsettings.json
"SII": {
    "LoginUrl": "https://misiir.sii.cl/...",
    "ApiCompraUrl": "https://misiir.sii.cl/.../getDetalleCompraExport",
    "ApiVentaUrl": "https://misiir.sii.cl/.../getDetalleVentaExport"
}
```

#### PDF Generation (QuestPDF)

```csharp
QuestPDF.Settings.License = LicenseType.Community;
// Used for report generation
```

## Deployment Architecture

### IIS Configuration

```xml
<!-- web.config -->
<aspNetCore processPath="dotnet" arguments=".\App.dll">
    <environmentVariables>
        <environmentVariable name="ASPNETCORE_PATHBASE" value="/app" />
    </environmentVariables>
</aspNetCore>
```

### Path Base Support

Application supports running under a sub-path (e.g., `/app`):
```csharp
var pathBase = Environment.GetEnvironmentVariable("ASPNETCORE_PATHBASE");
if (!string.IsNullOrEmpty(pathBase))
{
    app.UsePathBase(pathBase);
}
```

## Security Considerations

### Implemented
- Cookie authentication with HttpOnly flag
- HTTPS redirection
- HSTS headers
- BCrypt password hashing
- Session timeout (30 min idle)
- Company-level access control

### Configuration Security
- Connection strings in appsettings.json
- Encryption key for sensitive data
- SII credentials managed separately

## Performance Optimizations

### Database
- Query splitting for complex queries
- Connection pooling (Max: 100, Min: 5)
- Extended command timeout (120s) for reports

### Web Server
- Extended Kestrel timeouts (15 min) for long operations
- Static file caching
- Razor runtime compilation (dev only)
