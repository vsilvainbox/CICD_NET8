# audit-features.ps1
# Analiza todas las features y detecta violaciones de refactor.md

param(
    [string]$FeaturesPath = "D:\deploy\Features",
    [switch]$Verbose,
    [switch]$ExportCsv
)

$ErrorActionPreference = "SilentlyContinue"

# Features a excluir (shared, etc)
$excludeFolders = @("Shared", "bin", "obj")

# Obtener todas las features
$features = Get-ChildItem -Path $FeaturesPath -Directory | 
    Where-Object { $_.Name -notin $excludeFolders }

Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "  AUDITORIA DE FEATURES - refactor.md" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Features encontradas: $($features.Count)" -ForegroundColor Yellow
Write-Host ""

$results = @()

foreach ($feature in $features) {
    $featurePath = $feature.FullName
    $featureName = $feature.Name
    $violations = @()
    
    # Verificar si ya tiene REFACTORED.md
    $hasRefactored = Test-Path "$featurePath\REFACTORED.md"
    
    # ========== R02: Controllers con try-catch ==========
    $r02 = Select-String -Path "$featurePath\*Controller.cs" -Pattern "try\s*\{" 2>$null
    if ($r02) { $violations += "R02:try-catch($($r02.Count))" }
    
    # ========== R04: URLs hardcodeadas en Vista ==========
    $r04a = Select-String -Path "$featurePath\Views\*.cshtml" -Pattern 'fetch\s*\(\s*[`"'']/' 2>$null
    # R04b: Excluir href="/" (link a raíz es válido), detectar otros hardcoded como href="/Feature/Action"
    $r04b = Select-String -Path "$featurePath\Views\*.cshtml" -Pattern 'href\s*=\s*[`"'']/\w+' 2>$null
    # R04c: URLs de API hardcodeadas (ej: '/FeatureApi/Action' en vez de @Url.Action)
    $r04c = Select-String -Path "$featurePath\Views\*.cshtml" -Pattern "[`"'']/\w+Api/" 2>$null
    $r04count = (($r04a | Measure-Object).Count + ($r04b | Measure-Object).Count + ($r04c | Measure-Object).Count)
    if ($r04count -gt 0) { $violations += "R04:url-hardcoded($r04count)" }
    
    # ========== R07: Validaciones manuales que retornan BadRequest (no simples null-checks) ==========
    # Busca: if (string.IsNullOrEmpty(...)) return BadRequest - validaciones que deberían estar en Service
    $r07 = Select-String -Path "$featurePath\*Controller.cs" -Pattern "IsNullOrEmpty.*return\s*(BadRequest|NotFound)|\.Length\s*[<>=].*return\s*(BadRequest|NotFound)" 2>$null
    if ($r07) { $violations += "R07:validacion($($r07.Count))" }
    
    # ========== R11: Botones próximamente ==========
    $r11 = Select-String -Path "$featurePath\Views\*.cshtml" -Pattern "onclick.*pr.ximamente|Pr.ximamente" 2>$null
    if ($r11) { $violations += "R11:proximamente($($r11.Count))" }
    
    # ========== R12: Links GET para acciones ==========
    $r12 = Select-String -Path "$featurePath\Views\*.cshtml" -Pattern 'href=".*\?(delete|remove|eliminar)' 2>$null
    if ($r12) { $violations += "R12:get-delete($($r12.Count))" }
    
    # ========== R16: PostAsJsonAsync/GetAsync directo (HttpClient, no Service) ==========
    # Busca client.GetAsync, client.PostAsJsonAsync, etc. - NO service.GetAsync
    $r16 = Select-String -Path "$featurePath\*Controller.cs" -Pattern "client\.(PostAsJsonAsync|GetAsync|PutAsJsonAsync|DeleteAsync)\s*\(" 2>$null
    if ($r16) { $violations += "R16:http-directo($($r16.Count))" }
    
    # ========== R19: JavaScript llama a WebController (proxy prohibido) ==========
    # Detecta: forms ocultos que no van a ApiController
    $r19a = Select-String -Path "$featurePath\Views\*.cshtml" -Pattern 'asp-action="[^"]+"\s+method="post"[^>]*style="display:\s*none' 2>$null
    # Detecta: WebController con ProxyRequestAsync (excluyendo comentarios)
    $r19b = Select-String -Path "$featurePath\*Controller.cs" -Pattern "ProxyRequestAsync" 2>$null | Where-Object { $_.Line -notmatch "^\s*//" }
    # Detecta: Api.postForm(form.action, ...) - patrón proxy (excluyendo comentarios)
    $r19c = Select-String -Path "$featurePath\Views\*.cshtml" -Pattern "Api\.postForm\s*\(\s*form\.action" 2>$null | Where-Object { $_.Line -notmatch "^\s*//" }
    $r19count = (($r19a | Measure-Object).Count + ($r19b | Measure-Object).Count + ($r19c | Measure-Object).Count)
    if ($r19count -gt 0) { $violations += "R19:proxy($r19count)" }
    
    # ========== R20: fetch/ajax manual ==========
    # Excluir Print.cshtml (páginas sin layout que necesitan helper Api local)
    $r20 = Select-String -Path "$featurePath\Views\*.cshtml" -Pattern "await\s+fetch\(|\.ajax\(|axios\." 2>$null | Where-Object { $_.Filename -notmatch "Print\.cshtml$" }
    if ($r20) { $violations += "R20:fetch-manual($($r20.Count))" }
    
    # ========== R21: Modal local ==========
    # Solo verificar si existe la carpeta Views
    # Detecta: funciones locales de modal y ESC que cierra modales
    if (Test-Path "$featurePath\Views") {
        $r21a = Select-String -Path "$featurePath\Views\*.cshtml" -Pattern "function\s+cerrarModal\s*\(" 2>$null
        $r21b = Select-String -Path "$featurePath\Views\*.cshtml" -Pattern "function\s+abrirModal\s*\(" 2>$null
        # Detectar ESC que cierra modales (Escape seguido de cerrar/close + Modal)
        $r21c = Select-String -Path "$featurePath\Views\*.cshtml" -Pattern "Escape.*cerrar.*[Mm]odal|Escape.*close.*[Mm]odal|\.key\s*===?\s*['""]Escape['""].*\{[^}]*cerrar|\.key\s*===?\s*['""]Escape['""].*\{[^}]*close" 2>$null
        $r21count = (($r21a | Measure-Object).Count + ($r21b | Measure-Object).Count + ($r21c | Measure-Object).Count)
        if ($r21count -gt 0) { $violations += "R21:modal-local($r21count)" }
    }

    # ========== R22: Entidades HasNoKey con Add/Update/Remove ==========
    # Entidades sin PK que no pueden usar EF tracking: Add, Update, Remove, Attach
    $hasNoKeyEntities = "AjusteIVAMensual|CuentasRazon|Equivalencia|EstadoMes|Firmas|InfoAnualDJ1847|Membrete|Notas|ParamEmpresa|PcUsr|Perfiles|PlanAvanzado|PlanBasico|PlanIntermedio|PropIVA_TotMensual|Timbraje|Tracking_AperturaCierre|tbl_Comp_Centra_Full"
    $r22 = Select-String -Path "$featurePath\*Service.cs" -Pattern "\.($hasNoKeyEntities)\.(Add|Update|Remove|Attach)\s*\(" 2>$null
    if ($r22) { $violations += "R22:hasnokey-ef($($r22.Count))" }

    # ========== CSS: appearance-none ==========
    $css1 = Select-String -Path "$featurePath\Views\*.cshtml" -Pattern "appearance-none" 2>$null
    if ($css1) { $violations += "CSS:appearance($($css1.Count))" }

    # ========== CSS: dark mode (no soportado) ==========
    $css2 = Select-String -Path "$featurePath\Views\*.cshtml" -Pattern "dark:" 2>$null
    if ($css2) { $violations += "CSS:dark-mode($($css2.Count))" }
    
    # Determinar estado
    # [!!] si tiene al menos una violación (prioridad máxima)
    # [OK] si tiene REFACTORED.md y sin violaciones
    # [--] si no tiene violaciones ni REFACTORED.md
    if ($violations.Count -gt 0) {
        $status = "PENDING"
        $statusColor = "Red"
    } elseif ($hasRefactored) {
        $status = "DONE"
        $statusColor = "Green"
    } else {
        $status = "OK"
        $statusColor = "DarkGreen"
    }
    
    # Agregar resultado
    $results += [PSCustomObject]@{
        Feature = $featureName
        Status = $status
        Violations = $violations.Count
        Details = ($violations -join ", ")
        HasRefactored = $hasRefactored
    }
    
    # Mostrar resultado
    $violationText = if ($violations.Count -gt 0) { $violations -join ", " } else { "-" }
    
    if ($Verbose -or $violations.Count -gt 0 -or $hasRefactored) {
        $icon = switch ($status) {
            "DONE" { "[OK]" }
            "OK" { "[--]" }
            "PENDING" { "[!!]" }
        }
        Write-Host "$icon " -NoNewline -ForegroundColor $statusColor
        Write-Host "$featureName" -NoNewline -ForegroundColor White
        Write-Host " - " -NoNewline
        Write-Host $violationText -ForegroundColor $(if ($violations.Count -gt 0) { "Yellow" } else { "DarkGray" })
    }
}

# Resumen
Write-Host ""
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "  RESUMEN" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan

$done = ($results | Where-Object { $_.Status -eq "DONE" }).Count
$ok = ($results | Where-Object { $_.Status -eq "OK" }).Count
$pending = ($results | Where-Object { $_.Status -eq "PENDING" }).Count

Write-Host "DONE (con REFACTORED.md): " -NoNewline
Write-Host $done -ForegroundColor Green
Write-Host "OK (sin violaciones):     " -NoNewline
Write-Host $ok -ForegroundColor DarkGreen
Write-Host "PENDING (con violaciones):" -NoNewline
Write-Host " $pending" -ForegroundColor Red
Write-Host ""

# Top violaciones
Write-Host "TOP FEATURES CON MAS VIOLACIONES:" -ForegroundColor Yellow
$results | Where-Object { $_.Violations -gt 0 } | 
    Sort-Object -Property Violations -Descending | 
    Select-Object -First 15 | 
    ForEach-Object {
        Write-Host "  $($_.Violations) - $($_.Feature): $($_.Details)" -ForegroundColor Gray
    }

# Exportar CSV si se solicita
if ($ExportCsv) {
    $csvPath = "D:\deploy\tools\audit-results.csv"
    $results | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
    Write-Host ""
    Write-Host "Resultados exportados a: $csvPath" -ForegroundColor Cyan
}

Write-Host ""
Write-Host "Para ver todas las features: .\audit-features.ps1 -Verbose" -ForegroundColor DarkGray
Write-Host "Para exportar CSV:           .\audit-features.ps1 -ExportCsv" -ForegroundColor DarkGray
