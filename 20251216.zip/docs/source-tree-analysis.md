# HyperContabilidad - Source Tree Analysis

## Directory Structure

```
D:\deploy\
├── 📁 Features/              # ~170+ Feature modules (Vertical Slices)
├── 📁 Data/                  # ~90+ Entity classes + DbContext
├── 📁 Services/              # Shared services
├── 📁 Models/                # Shared models (Auth, Validation)
├── 📁 Middleware/            # Custom middleware
├── 📁 Filters/               # MVC Filters
├── 📁 Extensions/            # Extension methods
├── 📁 Helpers/               # Utility helpers
├── 📁 Exceptions/            # Custom exceptions
├── 📁 Migrations/            # EF Core migrations
├── 📁 wwwroot/               # Static files (CSS, JS, images)
├── 📁 docs/                  # Documentation
├── 📁 vb6/                   # Legacy VB6 source (reference)
├── 📄 Program.cs             # Application entry point
├── 📄 App.csproj             # Project file
├── 📄 appsettings.json       # Configuration
└── 📄 tailwind.config.js     # Tailwind CSS config
```

## Feature Modules Detail

Each feature follows this structure:

```
Features/{FeatureName}/
├── {FeatureName}Controller.cs        # MVC Controller
├── {FeatureName}ApiController.cs     # REST API Controller
├── {FeatureName}Service.cs           # Business logic implementation
├── I{FeatureName}Service.cs          # Service interface
├── {FeatureName}Dto.cs               # Data Transfer Objects
├── {FeatureName}ViewModel.cs         # View Models
├── Views/
│   ├── Index.cshtml                  # Main view
│   ├── _Partial.cshtml               # Partial views
│   └── EditorTemplates/              # Reusable editor templates
├── Analysis.md                       # VB6 migration analysis
└── REFACTORED.md                     # Refactoring notes (if any)
```

## Feature Categories

### 🏠 INICIO (Core Navigation)
| Feature | Status | Description |
|---------|--------|-------------|
| Home | ✅ | Dashboard principal |
| SeleccionarEmpresa | ✅ | Company selector |
| Auth | ✅ | Authentication & authorization |

### 📝 COMPROBANTES Y ASIENTOS
| Feature | Status | Description |
|---------|--------|-------------|
| Comprobante | ✅ | Journal entry creation/editing |
| ListarComprobantes | ✅ | Search and list vouchers |
| ListarPorTipo | ✅ | List by voucher type |
| ImportarComprobantes | 🔄 | Batch import |
| RenumerarComprobantes | ✅ | Renumbering |
| CambioEstado | ✅ | Status changes |
| SeguimientoCambios | ✅ | Audit trail |
| SeguimientoMovimientos | ✅ | Movement tracking |

### 📄 DOCUMENTOS AUXILIARES
| Feature | Status | Description |
|---------|--------|-------------|
| GestionDocumentos | ✅ | Document management |
| ListadoDocumentos | ✅ | Document listing |
| GestionCuotas | ✅ | Installment management |
| ListadoCuotas | ✅ | Installment listing |
| DocumentosLibros | ✅ | Book documents |
| TraspasoOdToOdf | ✅ | Document conversion |

### 📚 LIBROS CONTABLES
| Feature | Status | Description |
|---------|--------|-------------|
| LibroDiario | ✅ | Daily journal |
| LibroMayor | ✅ | General ledger |
| LibroInventarioBalance | ✅ | Inventory & balance book |
| LibroRetenciones | ✅ | Withholdings book |
| LibroElectronicoCompras | ✅ | Electronic purchase book (SII) |
| LibroIngresosEgresos | ✅ | Income/expense book |
| LibroCaja | ✅ | Cash book |

### 📊 BALANCES Y ESTADOS
| Feature | Status | Description |
|---------|--------|-------------|
| BalanceClasificado | ✅ | Classified balance |
| BalanceClasificadoComparativo | ✅ | Comparative balance |
| BalanceDesglosado | ✅ | Detailed balance |
| BalanceEjecutivo | ✅ | Executive balance |
| BalanceComprobacion | ✅ | Trial balance |
| BalanceGeneral | ✅ | General balance (8 columns) |
| EstadoResultados | ✅ | Income statement |
| BalanceTributarioIfrs | ✅ | Tax/IFRS balance |
| BalanceEjecutivoIfrs | ✅ | Executive IFRS balance |

### 🔍 ANÁLISIS Y CONSULTAS
| Feature | Status | Description |
|---------|--------|-------------|
| InformeAnalitico | ✅ | Basic analysis |
| InformeAnaliticoAvanzado | ✅ | Advanced analysis |
| InformeAnaliticoCompleto | ✅ | Complete analysis |
| ConsultaComprobantes | ✅ | Voucher queries |
| AnalisisVencimientos | ✅ | Maturity analysis |

### 💰 TRIBUTARIO (Chilean Tax)
| Feature | Status | Description |
|---------|--------|-------------|
| BaseImponible | ✅ | Tax base calculation |
| BaseImponible14D | ✅ | Article 14D calculations |
| ProporcionalidadIva | ✅ | VAT proportionality |
| ExportarF29 | ✅ | F29 form export |
| ExportarF22 | ✅ | F22 form export |
| ImportarDatosSii | ✅ | SII data import |
| SincronizacionSii | ✅ | SII synchronization |

### 🏢 ACTIVO FIJO
| Feature | Status | Description |
|---------|--------|-------------|
| GestionActivoFijo | ✅ | Fixed asset management |
| FichaActivoFijo | ✅ | Asset card |
| ListadoActivoFijo | ✅ | Asset listing |
| ComponentesActivoFijo | ✅ | Asset components |
| ReporteActivoFijo | ✅ | Asset reports |
| ConfiguracionActivoFijo | ✅ | Asset configuration |

### ⚙️ CONFIGURACIÓN
| Feature | Status | Description |
|---------|--------|-------------|
| ConfiguracionPrincipal | ✅ | Main settings |
| ConfiguracionPlanCuentas | ✅ | Chart of accounts config |
| ConfiguracionFut | ✅ | FUT configuration |
| ConfiguracionImpresion | ✅ | Print settings |
| MantenimientoEmpresas | ✅ | Company maintenance |
| MantenimientoUsuarios | ✅ | User management |

### 📥 IMPORTACIÓN
| Feature | Status | Description |
|---------|--------|-------------|
| ImportarEmpresa | ✅ | Company import |
| ImportarComprobantes | 🔄 | Voucher import |
| ImportarF29 | ✅ | F29 import |
| ImportarSiiCompras | ✅ | SII purchases import |
| ImportarSiiVentas | ✅ | SII sales import |
| ImportarCartolasBancarias | ✅ | Bank statement import |

### 📤 EXPORTACIÓN
| Feature | Status | Description |
|---------|--------|-------------|
| ExportarEmpresa | ✅ | Company export |
| ExportarEntidades | ✅ | Entity export |
| ExportarFacturacion | ✅ | Billing export |
| ExportarPercepciones | ✅ | Withholding export |

## Data Layer Structure

### Entity Categories

```
Data/
├── 📁 Core Entities
│   ├── Comprobante.cs           # Journal voucher
│   ├── MovComprobante.cs        # Voucher movements
│   ├── Cuentas.cs               # Chart of accounts
│   ├── Documento.cs             # Documents
│   └── Empresa.cs               # Companies
│
├── 📁 Financial Entities
│   ├── BaseImponible14D.cs      # Tax base
│   ├── CapPropioSimplAnual.cs   # Annual capital
│   ├── ActFijoFicha.cs          # Fixed assets
│   └── Cartola.cs               # Bank statements
│
├── 📁 Configuration Entities
│   ├── Param.cs                 # Parameters
│   ├── ParamEmpresa.cs          # Company parameters
│   ├── TipoDocs.cs              # Document types
│   └── Monedas.cs               # Currencies
│
├── 📁 Security Entities
│   ├── Usuarios.cs              # Users
│   ├── Perfiles.cs              # Profiles
│   └── UsuarioEmpresa.cs        # User-company mapping
│
├── 📁 Tracking/Audit Entities
│   ├── Tracking_Comprobante.cs  # Voucher audit
│   ├── Tracking_Documento.cs    # Document audit
│   ├── LogComprobantes.cs       # Voucher logs
│   └── ErrorLog.cs              # Error logging
│
└── 📄 LpContabContext.cs        # DbContext
```

## Static Files Structure

```
wwwroot/
├── 📁 css/
│   ├── tailwind.css             # Compiled Tailwind
│   └── tailwind.input.css       # Tailwind source
├── 📁 js/
│   ├── site.js                  # Global scripts
│   └── obsolete/                # Legacy scripts
├── 📁 lib/
│   ├── jquery/                  # jQuery
│   ├── jquery-validation/       # Form validation
│   ├── jstree/                  # Tree component
│   └── fontawesome/             # Icons
└── 📁 images/                   # Static images
```

## Configuration Files

| File | Purpose |
|------|---------|
| `App.csproj` | .NET project configuration |
| `appsettings.json` | Application settings |
| `tailwind.config.js` | Tailwind CSS configuration |
| `package.json` | Node.js dependencies |
| `web.config` | IIS configuration |

## Key Patterns Used

### Controller Pattern
- **MVC Controllers:** Return views (`.cshtml`)
- **API Controllers:** Return JSON data
- Both can coexist in same feature

### Service Pattern
- Interface-based (`IFeatureService`)
- Auto-registration via reflection
- Scoped lifetime (per-request)

### View Location Pattern
Custom Razor view locations configured in `Program.cs`:
```
/Features/{1}/Views/{0}.cshtml
/Features/Shared/{0}.cshtml
```

### DTO Pattern
- `*Dto.cs` for API data transfer
- `*ViewModel.cs` for view binding
- Clear separation of concerns
