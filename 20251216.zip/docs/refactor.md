# Guía de Refactorización

> **Objetivo:** Aplicar 20 reglas de forma consistente a cada feature, sin omisiones.

---

## INSTRUCCIONES DE USO

```
FLUJO DE EJECUCIÓN (seguir en orden estricto):

┌─────────────────────────────────────────────────────────────────┐
│  FASE 0: PREPARACIÓN                                            │
│  → Leer TODOS los archivos de la feature antes de modificar     │
│  → Identificar qué archivos existen                             │
├─────────────────────────────────────────────────────────────────┤
│  FASE 1: DETECCIÓN                                              │
│  → Ejecutar comandos de detección de violaciones                │
│  → Documentar qué reglas están siendo violadas                  │
├─────────────────────────────────────────────────────────────────┤
│  FASE 2: APLICACIÓN (por tipo de archivo)                       │
│  → Aplicar reglas en orden: Service → ApiController →           │
│    WebController → DTO → Vista                                  │
│  → Marcar cada regla como aplicada                              │
├─────────────────────────────────────────────────────────────────┤
│  FASE 3: VERIFICACIÓN                                           │
│  → Re-ejecutar comandos de detección                            │
│  → Confirmar 0 violaciones                                      │
├─────────────────────────────────────────────────────────────────┤
│  FASE 4: DOCUMENTACIÓN                                          │
│  → Crear REFACTORED.md en la carpeta de la feature              │
└─────────────────────────────────────────────────────────────────┘
```

---

## CATÁLOGO DE REGLAS

| ID | Regla | Aplica a |
|----|-------|----------|
| R01 | No compilar (usuario compila manualmente) | Proceso |
| R02 | Controllers sin try-catch | ApiController, WebController |
| R03 | Web Controller → API → Service (nunca directo) | WebController |
| R04 | URLs con helpers (nunca hardcodeadas) | Vista, WebController |
| R05 | Modales en lugar de redirecciones | Vista |
| R06 | Reutilizar endpoints existentes | ApiController, Service |
| R07 | Header estilo Dashboard | Vista |
| R08 | Orden: Filtros → Toolbar → Tabla | Vista |
| R09 | Empty State cuando no hay datos | Vista |
| R10 | Forms con tag helpers | Vista |
| R11 | Botones pendientes = disabled | Vista |
| R12 | Form POST para búsquedas, Api.* para CRUD | Vista |
| R13 | Tablas sin paginación | Vista |
| R14 | Flujo de datos consistente (casing) | Todos |
| R15 | NUNCA errores silenciosos (SweetAlert) | Todos |
| R16 | Web Controller usa HttpClientExtensions | WebController |
| R17 | Tipos SQL coinciden con C# | Service, DTO |
| R18 | FormHandler para confirmación/feedback | Vista |
| R19 | JavaScript fetch → API Controller directo | Vista |
| R20 | SOLO Form POST o Api.* (prohibido fetch manual) | Vista |
| R21 | Modales usan funciones globales de _Layout | Vista |
| R22 | Entidades HasNoKey usan SQL raw (no Add/Update/Remove) | Service |

---

## FASE 0: PREPARACIÓN

### 0.1 Identificar archivos de la feature

```
Features/{NombreFeature}/
├── {Nombre}Service.cs           ← Lógica de negocio
├── I{Nombre}Service.cs          ← Interface
├── {Nombre}ApiController.cs     ← API endpoints
├── {Nombre}Controller.cs        ← Web controller
├── {Nombre}Dto.cs               ← DTOs
└── Views/
    ├── Index.cshtml             ← Vista principal
    └── _Modal*.cshtml           ← Modales (si existen)
```

### 0.2 Leer archivos en este orden

1. **Service.cs** - Entender lógica y validaciones
2. **Dto.cs** - Entender estructura de datos
3. **ApiController.cs** - Entender endpoints disponibles
4. **Controller.cs** - Entender flujo web
5. **Vista(s)** - Entender UI actual

### 0.3 Determinar tipo de feature

| Tipo | Características | Patrón principal |
|------|-----------------|------------------|
| **Reporte** | Filtros → Buscar → Mostrar datos | Form POST |
| **CRUD** | Crear/Editar/Eliminar registros | Form POST + Api.* en modales |
| **Importación** | Subir archivo → Procesar | Form POST + feedback |
| **Dashboard** | Solo visualización | Carga inicial |

---

## FASE 1: DETECCIÓN DE VIOLACIONES

### Comandos de detección (PowerShell)

```powershell
# Ejecutar desde la carpeta de la feature
$featurePath = "Features/{NombreFeature}"

# R02: Controllers con try-catch
Select-String -Path "$featurePath\*Controller.cs" -Pattern "try\s*\{" | ForEach-Object { "R02 VIOLACIÓN: $_" }

# R04: URLs hardcodeadas en Vista
Select-String -Path "$featurePath\Views\*.cshtml" -Pattern "fetch\s*\(\s*['""]/" | ForEach-Object { "R04 VIOLACIÓN: $_" }
Select-String -Path "$featurePath\Views\*.cshtml" -Pattern "href\s*=\s*['""]/" | ForEach-Object { "R04 VIOLACIÓN: $_" }
# R04: URLs de API hardcodeadas en URL_ENDPOINTS (deben usar @Url.Action)
Select-String -Path "$featurePath\Views\*.cshtml" -Pattern "['""]\/\w+Api\/" | ForEach-Object { "R04 VIOLACIÓN (url-hardcoded): $_" }

# R04: URLs hardcodeadas en Controller
Select-String -Path "$featurePath\*Controller.cs" -Pattern "['""]/(api|Api|\w+Api)/" | ForEach-Object { "R04 VIOLACIÓN: $_" }

# R11: Botones con onclick para "próximamente"
Select-String -Path "$featurePath\Views\*.cshtml" -Pattern "onclick.*próximamente|onclick.*proximamente" | ForEach-Object { "R11 VIOLACIÓN: $_" }

# R16: PostAsJsonAsync (debe ser PostToApiAsync)
Select-String -Path "$featurePath\*Controller.cs" -Pattern "PostAsJsonAsync|GetAsync\s*\(" | ForEach-Object { "R16 VIOLACIÓN: $_" }

# R20: fetch manual, $.ajax, axios
Select-String -Path "$featurePath\Views\*.cshtml" -Pattern "await\s+fetch\(|\.ajax\(|axios\." | ForEach-Object { "R20 VIOLACIÓN: $_" }

# R21: función cerrarModal local (debe usar global)
Select-String -Path "$featurePath\Views\*.cshtml" -Pattern "function\s+cerrarModal\s*\(" | ForEach-Object { "R21 VIOLACIÓN: $_" }
Select-String -Path "$featurePath\Views\*.cshtml" -Pattern "function\s+abrirModal\s*\(" | ForEach-Object { "R21 VIOLACIÓN: $_" }

# CSS: appearance-none (bug Windows)
Select-String -Path "$featurePath\Views\*.cshtml" -Pattern "appearance-none" | ForEach-Object { "CSS VIOLACIÓN: $_" }

# CSS: dark mode (no soportado)
Select-String -Path "$featurePath\Views\*.cshtml" -Pattern "dark:" | ForEach-Object { "CSS VIOLACIÓN: $_" }

# CSS: inputs sin bg-white
Select-String -Path "$featurePath\Views\*.cshtml" -Pattern "<input[^>]+class=""[^""]*""" | Where-Object { $_ -notmatch "bg-white|bg-gray-50" } | ForEach-Object { "CSS VIOLACIÓN: $_" }

# R22: Entidades HasNoKey con Add/Update/Remove (deben usar SQL raw)
# Lista de entidades sin PK: AjusteIVAMensual, CuentasRazon, Equivalencia, EstadoMes, Firmas, InfoAnualDJ1847, Membrete, Notas, ParamEmpresa, PcUsr, Perfiles, PlanAvanzado, PlanBasico, PlanIntermedio, PropIVA_TotMensual, Timbraje, Tracking_AperturaCierre, tbl_Comp_Centra_Full
$hasNoKeyEntities = "AjusteIVAMensual|CuentasRazon|Equivalencia|EstadoMes|Firmas|InfoAnualDJ1847|Membrete|Notas|ParamEmpresa|PcUsr|Perfiles|PlanAvanzado|PlanBasico|PlanIntermedio|PropIVA_TotMensual|Timbraje|Tracking_AperturaCierre|tbl_Comp_Centra_Full"
Select-String -Path "$featurePath\*Service.cs" -Pattern "\.(Add|Update|Remove|Attach)\s*\(" | Select-String -Pattern $hasNoKeyEntities | ForEach-Object { "R22 VIOLACIÓN: $_" }

# R19: JavaScript llama a WebController en vez de ApiController (proxy prohibido)
# Detecta: forms ocultos con asp-action que NO terminan en Api, usados por Api.postForm
Select-String -Path "$featurePath\Views\*.cshtml" -Pattern 'asp-action="[^"]+"\s+method="post".*style="display:\s*none' | ForEach-Object { "R19 VIOLACIÓN (form proxy): $_" }
# Detecta: WebController con métodos que usan ProxyRequestAsync (patrón proxy prohibido)
Select-String -Path "$featurePath\*Controller.cs" -Pattern "ProxyRequestAsync" | ForEach-Object { "R19 VIOLACIÓN (proxy en controller): $_" }
# Detecta: Api.postForm llamando a action sin "Api" en el nombre
Select-String -Path "$featurePath\Views\*.cshtml" -Pattern "Api\.postForm\s*\(\s*form\.action" | ForEach-Object { "R19 VIOLACIÓN (postForm a WebController): $_" }
```

---

## FASE 2: APLICACIÓN POR TIPO DE ARCHIVO

---

### ARCHIVO: Service.cs

**Reglas aplicables:** R06, R14, R15, R17, R22

#### Checklist Service

```
□ R06  Reutiliza lógica existente (no duplica queries de otros features)
□ R14  Propiedades en PascalCase en DTOs de retorno
□ R15  Lanza BusinessException para errores de validación
□ R15  Lanza Exception para errores de sistema (o deja fluir)
□ R17  Tipos C# coinciden con tipos SQL en raw queries
□ R22  Entidades HasNoKey usan SQL raw (no Add/Update/Remove)
```

#### R15: Patrón de errores en Service

```csharp
// ✅ CORRECTO
public async Task<FeatureDto> GetByIdAsync(int id)
{
    var entity = await _context.Features.FindAsync(id);
    if (entity == null)
        throw new BusinessException("Registro no encontrado");

    return MapToDto(entity);
}

public async Task CreateAsync(FeatureDto dto)
{
    // Validaciones → BusinessException
    if (string.IsNullOrEmpty(dto.Codigo))
        throw new BusinessException("El código es requerido");

    if (await ExisteCodigoAsync(dto.Codigo))
        throw new BusinessException("El código ya existe");

    // Múltiples errores
    var errores = new List<string>();
    if (dto.Monto <= 0) errores.Add("Monto debe ser mayor a cero");
    if (dto.Fecha > DateTime.Today) errores.Add("Fecha no puede ser futura");
    if (errores.Count > 0)
        throw new BusinessException(errores);

    await _context.SaveChangesAsync();
}

// ❌ INCORRECTO - No usar tuplas, Result, null para errores
public async Task<(bool Exito, string Mensaje)> CreateAsync(...)  // NO
public async Task<ResultadoOperacion> CreateAsync(...)            // NO
public async Task<FeatureDto?> GetAsync(int id) => ... ?? null;   // NO
```

#### R17: Mapeo de tipos SQL → C#

```csharp
// Verificar con: SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Tabla'

// ✅ CORRECTO
public class RawQueryDto
{
    public byte Nivel { get; set; }          // tinyint → byte
    public short Ano { get; set; }           // smallint → short
    public int IdDocumento { get; set; }     // int → int
    public long IdTransaccion { get; set; }  // bigint → long
    public double TotalDebe { get; set; }    // float → double
    public float Porcentaje { get; set; }    // real → float
    public decimal Monto { get; set; }       // decimal/money → decimal
    public bool Activo { get; set; }         // bit → bool
    public string Nombre { get; set; }       // varchar/nvarchar → string
    public DateTime Fecha { get; set; }      // datetime → DateTime
}

// ❌ INCORRECTO - Causa InvalidCastException
public int Nivel { get; set; }      // tinyint NO es int
public decimal Total { get; set; }  // float NO es decimal
```

#### R22: Entidades sin clave primaria (HasNoKey)

Las siguientes entidades tienen `HasNoKey()` en el contexto y **NO pueden** usar `Add()`, `Update()`, `Remove()` o `Attach()`:

```
AjusteIVAMensual, CuentasRazon, Equivalencia, EstadoMes, Firmas, 
InfoAnualDJ1847, Membrete, Notas, ParamEmpresa, PcUsr, Perfiles, 
PlanAvanzado, PlanBasico, PlanIntermedio, PropIVA_TotMensual, 
Timbraje, Tracking_AperturaCierre, tbl_Comp_Centra_Full
```

**Error en runtime:** `Unable to track an instance of type 'X' because it does not have a primary key`

```csharp
// ❌ INCORRECTO - Causa error en runtime
context.EstadoMes.Add(estadoMes);           // ERROR: HasNoKey
context.EstadoMes.Update(estadoMes);        // ERROR: HasNoKey
context.ParamEmpresa.Remove(param);         // ERROR: HasNoKey

// ✅ CORRECTO - Usar SQL raw para INSERT
await context.Database.ExecuteSqlRawAsync(
    @"INSERT INTO EstadoMes (IdEmpresa, Ano, Mes, Estado, FechaApertura) 
      VALUES (@p0, @p1, @p2, @p3, @p4)",
    empresaId, ano, mes, estado, fechaApertura);

// ✅ CORRECTO - Usar SQL raw para UPDATE
await context.Database.ExecuteSqlRawAsync(
    @"UPDATE EstadoMes 
      SET Estado = @p0, FechaCierre = @p1 
      WHERE IdEmpresa = @p2 AND Ano = @p3 AND Mes = @p4",
    estado, fechaCierre, empresaId, ano, mes);

// ✅ CORRECTO - Usar SQL raw para DELETE
await context.Database.ExecuteSqlRawAsync(
    "DELETE FROM ParamEmpresa WHERE IdEmpresa = @p0 AND Codigo = @p1",
    empresaId, codigo);

// ✅ ALTERNATIVA - ExecuteSqlAsync con interpolación (más seguro)
await context.Database.ExecuteSqlAsync(
    $"UPDATE EstadoMes SET Estado = {estado} WHERE IdEmpresa = {empresaId}");
```

**Nota:** Las entidades HasNoKey SÍ pueden usarse para lectura con LINQ normal.

---

### ARCHIVO: *ApiController.cs

**Reglas aplicables:** R02, R06, R14, R15

#### Checklist ApiController

```
□ R02  Sin try-catch (el middleware maneja errores)
□ R02  Retorna Ok() para void, Ok(data) para datos
□ R02  NO usa NoContent() ni envuelve en { message: "..." }
□ R06  No duplica endpoints de otros features
□ R14  Parámetros recibidos coinciden con lo que envía el cliente
□ R15  No captura excepciones (fluyen al middleware)
```

#### R02: Estructura de ApiController

```csharp
// ✅ CORRECTO - Controller "tonto"
[Route("[controller]")]
[ApiController]
public class FeatureApiController : ControllerBase
{
    private readonly IFeatureService _service;

    public FeatureApiController(IFeatureService service)
    {
        _service = service;
    }

    // GET - Retorna datos
    [HttpGet]
    public async Task<IActionResult> GetDatos(int empresaId, short ano)
    {
        var datos = await _service.GetDatosAsync(empresaId, ano);
        return Ok(datos);
    }

    // POST - Retorna datos
    [HttpPost]
    public async Task<IActionResult> Generar(FeatureRequest request)
    {
        var resultado = await _service.GenerarAsync(request);
        return Ok(resultado);
    }

    // POST - Void (crear/actualizar)
    [HttpPost]
    public async Task<IActionResult> Save(FeatureDto dto)
    {
        await _service.SaveAsync(dto);
        return Ok();  // NO: Ok(new { message = "..." })
    }

    // DELETE - Void
    [HttpDelete]
    public async Task<IActionResult> Delete(int id, int empresaId)
    {
        await _service.DeleteAsync(id, empresaId);
        return Ok();  // NO: NoContent()
    }
}

// ❌ INCORRECTO
[HttpPost]
public async Task<IActionResult> Save(FeatureDto dto)
{
    try  // ← NO
    {
        await _service.SaveAsync(dto);
        return Ok(new { message = "Guardado" });  // ← NO envolver
    }
    catch (Exception ex)  // ← NO
    {
        return BadRequest(ex.Message);  // ← NO
    }
}
```

---

### ARCHIVO: *Controller.cs (Web Controller)

**Reglas aplicables:** R02, R03, R04, R14, R15, R16

#### Checklist WebController

```
□ R02  Sin try-catch
□ R03  Llama a API Controller (no a Service directo)
□ R04  URLs con GetApiUrl<T>() (no hardcodeadas)
□ R14  Tipos genéricos coinciden con ViewModel.Filtros
□ R15  Usa PostToApiAsync/GetFromApiAsync (lanzan excepciones)
□ R16  NO usa PostAsJsonAsync, GetAsync, SendAsync manual
```

#### R03 + R04 + R16: Estructura de WebController

```csharp
// ✅ CORRECTO
public class FeatureController : Controller
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly LinkGenerator _linkGenerator;

    public FeatureController(IHttpClientFactory httpClientFactory, LinkGenerator linkGenerator)
    {
        _httpClientFactory = httpClientFactory;
        _linkGenerator = linkGenerator;
    }

    [HttpGet]
    public async Task<IActionResult> Index()
    {
        var viewModel = new FeatureViewModel();
        // Cargar datos iniciales si es necesario
        return View(viewModel);
    }

    [HttpPost]
    public async Task<IActionResult> Index(FeatureViewModel model)
    {
        var client = _httpClientFactory.CreateClient();

        // R04: URL con helper type-safe
        var url = _linkGenerator.GetApiUrl<FeatureApiController>(
            HttpContext,
            nameof(FeatureApiController.Generar));

        // R16: Usa HttpClientExtensions (lanza excepciones automáticamente)
        // R14: El tipo genérico DEBE coincidir con el tipo de model.Filtros
        var result = await client.PostToApiAsync<FeatureRequest, FeatureResponse>(
            url!,
            model.Filtros);

        model.Resultados = result;
        return View(model);
    }
}

// ❌ INCORRECTO
[HttpPost]
public async Task<IActionResult> Index(FeatureViewModel model)
{
    var client = _httpClientFactory.CreateClient();

    // R04 VIOLACIÓN: URL hardcodeada
    var url = "/FeatureApi/Generar";

    // R16 VIOLACIÓN: PostAsJsonAsync no lanza excepciones
    var response = await client.PostAsJsonAsync(url, model.Filtros);

    // R02 VIOLACIÓN: Lógica de manejo de errores en controller
    if (response.IsSuccessStatusCode)
    {
        var result = await response.Content.ReadFromJsonAsync<FeatureResponse>();
        model.Resultados = result;
    }
    else
    {
        // R15 VIOLACIÓN: Error silencioso posible
        TempData["Error"] = "Error al procesar";
    }

    return View(model);
}
```

#### R14: Verificar tipos genéricos

```csharp
// ViewModel define el tipo de Filtros:
public class FeatureViewModel
{
    public FeatureRequest Filtros { get; set; } = new();  // ← ESTE TIPO
    public FeatureResponse? Resultados { get; set; }
}

// En el Controller, el PRIMER tipo genérico debe coincidir:
await client.PostToApiAsync<FeatureRequest, FeatureResponse>(url, model.Filtros);
//                          ↑ DEBE SER FeatureRequest

// ❌ ERROR CS1503 si no coincide:
await client.PostToApiAsync<OtroTipo, FeatureResponse>(url, model.Filtros);
```

---

### ARCHIVO: *Dto.cs

**Reglas aplicables:** R14, R17

#### Checklist DTO

```
□ R14  Propiedades en PascalCase
□ R14  Nombres descriptivos (no abreviaciones crípticas)
□ R17  Tipos coinciden con BD para raw queries
□ R17  Propiedades formateadas para display (MontoFormatted, FechaStr)
```

#### R14: Nomenclatura de DTOs

```csharp
// ✅ CORRECTO
public class FeatureDto           // DTO principal
{
    public int IdDocumento { get; set; }
    public decimal Monto { get; set; }
    public string MontoFormatted => Monto.ToString("N0");
    public DateTime? FechaEmision { get; set; }
    public string FechaEmisionStr => FechaEmision?.ToString("dd/MM/yyyy") ?? "";
}

public class FeatureRequest       // Para filtros/búsquedas
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public DateTime? FechaDesde { get; set; }
    public DateTime? FechaHasta { get; set; }
}

public class FeatureFormDto       // Para formularios de edición
{
    public int Id { get; set; }
    public string Nombre { get; set; } = "";
}

// ❌ INCORRECTO
public class FeatureDto
{
    public int idDocumento { get; set; }    // camelCase en C#
    public decimal monto { get; set; }       // camelCase en C#
    public string fec_emision { get; set; } // snake_case
}
```

---

### ARCHIVO: Views/*.cshtml

**Reglas aplicables:** R04, R05, R07, R08, R09, R10, R11, R12, R13, R18, R19, R20

#### Checklist Vista

```
□ R04  URLs JS: objeto _urls con @Url.Action() (no hardcodeadas)
□ R05  Ver Comprobante/Documento abre modal (no redirección)
□ R07  Header: solo h1 + descripción (sin icono grande)
□ R08  Orden: Filtros → Toolbar → Tabla → Totales
□ R09  Empty State visible cuando no hay datos
□ R10  Forms con asp-action, asp-controller, asp-for
□ R11  Botones pendientes: disabled (no onclick "próximamente")
□ R12  Búsquedas: form POST | CRUD dinámico: Api.*
□ R13  Tablas: sin paginación
□ R18  FormHandler: data-form-submit, data-confirm-title
□ R19  JavaScript llama a *Api Controller (no Web Controller)
□ R20  Solo Form POST o Api.* (no fetch/$.ajax manual)
□ R21  Modales usan cerrarModal(id)/abrirModal(id) globales de _Layout
□ CSS  Sin appearance-none en selects
□ CSS  Inputs: bg-white text-gray-900 (editables) / bg-gray-50 (readonly)
□ CSS  Sin clases dark:*
□ CSS  Colores: solo primary-* (no blue-*, green-*, etc.)
```

---

#### R07: Header estilo Dashboard

```html
<!-- ✅ CORRECTO -->
<header class="mb-6">
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-xl font-semibold text-gray-900">Título del Feature</h1>
            <p class="mt-1 text-sm text-gray-500">Descripción breve de qué hace</p>
        </div>
    </div>
</header>

<!-- ❌ INCORRECTO - Icono grande, contenedor complejo -->
<div class="mb-6">
    <div class="flex items-start space-x-4">
        <div class="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center">
            <i class="fas fa-chart-bar text-2xl text-primary-600"></i>
        </div>
        <div>
            <h1 class="text-2xl font-bold text-gray-900">Título</h1>
        </div>
    </div>
</div>
```

---

#### R08: Orden de secciones

```html
<!-- ORDEN OBLIGATORIO -->

<!-- 1. Header -->
<header class="mb-6">...</header>

<!-- 2. Card de Filtros (con botón Buscar DENTRO) -->
<div class="bg-white rounded-xl shadow-sm border p-6 mb-6">
    <form asp-action="Index" method="post" id="frmBuscar" data-no-confirm>
        <!-- Filtros aquí -->
        <button type="button" data-form-submit="frmBuscar">Buscar</button>
    </form>
</div>

<!-- 3. Toolbar (ARRIBA de la tabla) -->
@if (Model.Resultados?.Any() == true)
{
    <div class="flex items-center gap-2 mb-4">
        <button type="button" onclick="verComprobante()">Ver Comprobante</button>
        <button type="button" onclick="verDocumento()">Ver Documento</button>
    </div>
}

<!-- 4. Tabla O Empty State -->
@if (Model.Resultados?.Any() == true)
{
    <div class="bg-white rounded-xl shadow-sm border">
        <table>...</table>
    </div>
}
else
{
    <!-- Empty State -->
    <div class="rounded-2xl border border-gray-200 bg-white p-12">
        <div class="text-center">
            <svg class="w-20 h-20 text-gray-300 mx-auto mb-4">...</svg>
            <p class="text-gray-500 text-lg mb-2">No hay datos para mostrar</p>
            <p class="text-gray-400 text-sm">Configure los filtros y presione "Buscar"</p>
        </div>
    </div>
}

<!-- 5. Totales (si aplica) -->
@if (Model.Resultados?.Any() == true)
{
    <div class="mt-4 bg-gray-50 rounded-lg p-4">
        <!-- Totales -->
    </div>
}
```

---

#### R10 + R18: Forms con FormHandler

```html
<!-- BÚSQUEDA (sin confirmación) -->
<form asp-action="Index"
      asp-controller="Feature"
      method="post"
      id="frmBuscar"
      data-no-confirm>

    <label asp-for="Filtros.FechaDesde">Fecha Desde</label>
    <input asp-for="Filtros.FechaDesde" type="date"
           class="w-full px-3 py-2 border border-gray-300 rounded-lg bg-white text-gray-900" />

    <label asp-for="Filtros.IdCuenta">Cuenta</label>
    <select asp-for="Filtros.IdCuenta"
            class="w-full px-3 py-2 border border-gray-300 rounded-lg bg-white text-gray-900">
        <option value="">Seleccione...</option>
        @foreach (var c in Model.Cuentas)
        {
            <option value="@c.IdCuenta">@c.Descripcion</option>
        }
    </select>

    <button type="button" data-form-submit="frmBuscar"
            class="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700">
        <i class="fas fa-search mr-2"></i>Buscar
    </button>
</form>

<!-- GUARDAR (con confirmación) -->
<form asp-action="Save"
      asp-controller="Feature"
      method="post"
      id="frmGuardar"
      data-confirm-title="¿Guardar cambios?"
      data-confirm-text="Se actualizarán los datos">

    @Html.AntiForgeryToken()
    <input asp-for="Datos.Id" type="hidden" />
    <input asp-for="Datos.Nombre" class="... bg-white text-gray-900" />

    <button type="button" data-form-submit="frmGuardar"
            class="px-4 py-2 bg-primary-600 text-white rounded-lg">
        <i class="fas fa-save mr-2"></i>Guardar
    </button>
</form>

<!-- GUARDAR EN MODAL (AJAX) -->
<form asp-action="Save"
      asp-controller="Feature"
      method="post"
      id="frmEditarModal"
      data-ajax="true"
      data-confirm-title="¿Guardar cambios?">

    @Html.AntiForgeryToken()
    <!-- campos -->
    <button type="button" data-form-submit="frmEditarModal">Guardar</button>
</form>
```

---

#### R04 + R19 + R20: JavaScript correcto

```html
@section Scripts {
    <partial name="_ValidationScriptsPartial" />

    <script>
    // ═══════════════════════════════════════════════════════════════
    // R04: URLs con @Url.Action (NUNCA hardcodeadas)
    // R19: Apuntan a *Api Controller (no Web Controller)
    // ═══════════════════════════════════════════════════════════════
    const URL_ENDPOINTS = {
        getDetalle: '@Url.Action("GetDetalle", "FeatureApi")',
        guardar: '@Url.Action("Save", "FeatureApi")',
        eliminar: '@Url.Action("Delete", "FeatureApi")',
        getComprobante: '@Url.Action("GetDetalleComprobante", "ComprobanteApi")',
        getDocumento: '@Url.Action("GetDocumento", "GestionDocumentosApi")'
    };

    // ═══════════════════════════════════════════════════════════════
    // R20: SOLO usar Api.* (NUNCA fetch manual, $.ajax, axios)
    // ═══════════════════════════════════════════════════════════════

    // ✅ CORRECTO - Api.get para obtener datos
    async function cargarDetalle(id) {
        const data = await Api.get(URL_ENDPOINTS.getDetalle, { id });
        if (data) {
            mostrarModal(data);
        }
        // Si data es null, Api.* ya mostró SweetAlert de error
    }

    // ✅ CORRECTO - Api.postJson para guardar
    async function guardar() {
        const datos = {
            id: document.getElementById('editId').value,
            nombre: document.getElementById('editNombre').value
        };

        const result = await Api.postJson(URL_ENDPOINTS.guardar, datos);
        if (result) {
            Swal.fire({ icon: 'success', title: 'Guardado', timer: 1500 });
            location.reload();
        }
    }

    // ✅ CORRECTO - Api.deleteJson para eliminar
    async function eliminar(id, empresaId) {
        const confirmado = await Swal.fire({
            title: '¿Eliminar?',
            icon: 'warning',
            showCancelButton: true
        });

        if (confirmado.isConfirmed) {
            const result = await Api.deleteJson(URL_ENDPOINTS.eliminar, { id, empresaId });
            if (result) {
                location.reload();
            }
        }
    }

    // ✅ CORRECTO - Api.getHtml para cargar partial views
    async function cargarModalComprobante(idComprobante) {
        const html = await Api.getHtml(URL_ENDPOINTS.getComprobante, { id: idComprobante });
        if (html) {
            document.getElementById('modalContent').innerHTML = html;
            abrirModal();
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // ❌ PROHIBIDO - Eliminar si existe
    // ═══════════════════════════════════════════════════════════════

    // ❌ fetch manual
    // const response = await fetch(url, { method: 'POST', ... });

    // ❌ jQuery AJAX
    // $.ajax({ url, method: 'POST', success: fn });
    // $.post(url, data, callback);

    // ❌ XMLHttpRequest
    // var xhr = new XMLHttpRequest();

    // ❌ axios
    // axios.post(url, data);
    </script>
}
```

---

#### R19: JavaScript → ApiController directo (NO proxy por WebController)

**Patrón PROHIBIDO (proxy):**
```html
<!-- ❌ INCORRECTO - Form oculto que apunta al WebController -->
<form id="frmAccion" asp-action="MiAccion" method="post" style="display:none;">
    @Html.AntiForgeryToken()
    <input type="hidden" name="Id" id="idInput" />
</form>

<script>
// ❌ INCORRECTO - Llama al WebController que hace proxy al ApiController
async function ejecutarAccion(id) {
    const form = document.getElementById('frmAccion');
    document.getElementById('idInput').value = id;
    const formData = new FormData(form);
    const data = await Api.postForm(form.action, formData);  // ❌ Va al WebController
}
</script>
```

**Patrón CORRECTO:**
```html
<!-- ✅ CORRECTO - Sin formularios ocultos proxy -->
<script>
// R04 + R19: URLs apuntan directamente al ApiController
const URL_ENDPOINTS = {
    miAccion: '@Url.Action("MiAccion", "FeatureApi")'  // ✅ Termina en "Api"
};

// ✅ CORRECTO - Llama directamente al ApiController
async function ejecutarAccion(id) {
    const data = await Api.postJson(URL_ENDPOINTS.miAccion, { id });
    if (data) {
        Swal.fire({ icon: 'success', title: 'Éxito', text: data.message });
        location.reload();
    }
}
</script>
```

**Corrección paso a paso:**
1. Eliminar formularios ocultos con `style="display:none"` que no sean de búsqueda
2. Agregar URL al bloque `URL_ENDPOINTS` apuntando al `*ApiController`
3. Cambiar `Api.postForm(form.action, formData)` por `Api.postJson(URL_ENDPOINTS.x, {...})`
4. Eliminar métodos proxy del WebController que usen `ProxyRequestAsync`

---

#### R11: Botones pendientes

```html
<!-- ✅ CORRECTO - Deshabilitado -->
<button type="button" disabled
        class="px-3 py-1.5 text-sm text-gray-400 bg-gray-100 rounded cursor-not-allowed"
        title="Funcionalidad en desarrollo">
    <i class="fas fa-file-excel mr-1"></i>Exportar Excel
</button>

<!-- ❌ INCORRECTO - Con onclick -->
<button type="button" onclick="alert('Próximamente')">
    Exportar Excel
</button>
```

---

#### R21: Modales centralizados

Los modales deben usar las funciones globales de `_Layout.cshtml`. **NUNCA** definir funciones locales `abrirModal()` o `cerrarModal()` en cada feature.

```html
<!-- ✅ CORRECTO - Usa función global con ID del modal -->
<button type="button" onclick="cerrarModal('editModal')" class="...">
    Cancelar
</button>

<button type="button" onclick="abrirModal('editModal')" class="...">
    Editar
</button>

<!-- ✅ CORRECTO - Botón X con ID del modal -->
<button type="button" onclick="cerrarModal('editModal')" class="text-gray-400 hover:text-gray-600">
    <svg class="w-5 h-5">...</svg>
</button>
```

```javascript
// ✅ CORRECTO - Usar funciones globales directamente
function editarRegistro(id) {
    // ... cargar datos ...
    abrirModal('editModal');  // Función global de _Layout
}

function cancelar() {
    cerrarModal('editModal');  // Función global de _Layout
}

// ❌ INCORRECTO - NO definir funciones locales
function cerrarModal() {  // PROHIBIDO - sobrescribe la global
    document.getElementById('editModal').classList.add('hidden');
}

function abrirModal() {  // PROHIBIDO - sobrescribe la global
    document.getElementById('editModal').classList.remove('hidden');
}
```

**Funciones globales disponibles en `_Layout.cshtml`:**

| Función | Descripción |
|---------|-------------|
| `abrirModal(modalId)` | Abre modal por ID, bloquea scroll body |
| `cerrarModal(modalId)` | Cierra modal por ID, restaura scroll |
| `toggleModal(modalId)` | Alterna abrir/cerrar |

**Comportamiento estandarizado:**
- ✅ Solo se cierra con botón X o Cancelar
- ❌ NO se cierra al hacer click en backdrop
- ❌ NO se cierra con tecla ESC

---

#### CSS: Reglas de estilos

```html
<!-- INPUTS EDITABLES -->
<input type="text" class="w-full px-3 py-2 border border-gray-300 rounded-lg bg-white text-gray-900 focus:ring-2 focus:ring-primary-500" />

<!-- INPUTS READONLY -->
<input type="text" readonly class="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-900" />

<!-- SELECTS (SIN appearance-none) -->
<select class="w-full px-3 py-2 border border-gray-300 rounded-lg bg-white text-gray-900">
    <option value="">Seleccione...</option>
</select>

<!-- ❌ INCORRECTO -->
<select class="... appearance-none ...">  <!-- Bug Windows: opciones invisibles -->
<input class="... dark:bg-gray-800 ...">  <!-- No hay dark mode -->
<button class="bg-blue-600 ...">          <!-- Usar primary-600 -->
```

---

## FASE 3: VERIFICACIÓN

### 3.1 Re-ejecutar detección

```powershell
# Ejecutar los mismos comandos de FASE 1
# Resultado esperado: 0 violaciones
```

### 3.2 Verificación manual

```
□ Abrir la feature en el navegador
□ Probar búsqueda con filtros
□ Verificar que errores muestran SweetAlert
□ Probar CRUD si aplica (crear, editar, eliminar)
□ Verificar modales de detalle
□ Revisar consola del navegador (sin errores JS)
```

---

## FASE 4: DOCUMENTACIÓN

### Crear REFACTORED.md

```markdown
# ✅ Feature Refactorizada

**Fecha:** YYYY-MM-DD
**Guía aplicada:** refactor2.md

## Reglas Verificadas

### Service
- [x] R06 - Reutiliza lógica existente
- [x] R15 - BusinessException para errores
- [x] R17 - Tipos SQL correctos

### ApiController
- [x] R02 - Sin try-catch
- [x] R02 - Retorna Ok()/Ok(data)

### WebController
- [x] R02 - Sin try-catch
- [x] R03 - Llama a API (no Service)
- [x] R04 - GetApiUrl<T>()
- [x] R16 - PostToApiAsync/GetFromApiAsync

### Vista
- [x] R04 - URLs con @Url.Action
- [x] R07 - Header Dashboard
- [x] R08 - Orden correcto
- [x] R09 - Empty State
- [x] R10 - Tag helpers
- [x] R11 - Botones disabled
- [x] R12 - Form POST / Api.*
- [x] R13 - Sin paginación
- [x] R18 - FormHandler
- [x] R19 - JS → ApiController
- [x] R20 - Solo Form/Api.*
- [x] CSS - bg-white, sin dark:, sin appearance-none

## Notas
- (observaciones específicas)
```

---

## REFERENCIA RÁPIDA

### Api.* disponibles

| Método | HTTP | Body | Respuesta |
|--------|------|------|-----------|
| `Api.get(url, params)` | GET | Query params | JSON |
| `Api.getHtml(url, params)` | GET | Query params | HTML |
| `Api.postJson(url, data)` | POST | JSON | JSON |
| `Api.postForm(url, formData)` | POST | FormData | JSON |
| `Api.put(url, data)` | PUT | JSON | JSON |
| `Api.delete(url, params)` | DELETE | Query params | JSON |
| `Api.deleteJson(url, data)` | DELETE | JSON body | JSON |

### Mapeo SQL → C#

| SQL Server | C# |
|------------|-----|
| `tinyint` | `byte` |
| `smallint` | `short` |
| `int` | `int` |
| `bigint` | `long` |
| `float` | `double` |
| `real` | `float` |
| `decimal/money` | `decimal` |
| `bit` | `bool` |
| `varchar/nvarchar` | `string` |
| `datetime` | `DateTime` |

### TempData keys

| Key | SweetAlert | Uso |
|-----|------------|-----|
| `TempData["Errors"]` | ⚠️ Warning | BusinessException |
| `TempData["ErrorMessage"]` | ❌ Error | Exception sistema |
| `TempData["Success"]` | ✅ Success | Operación exitosa |

### Features de referencia

| Patrón | Feature |
|--------|---------|
| Header correcto | `Features/Home/Views/Index.cshtml` |
| Empty State | `Features/InformeAnalitico/Views/Index.cshtml` |
| Modal Comprobante | `Features/InformeAnaliticoCompleto/Views/_ModalDetalleComprobante.cshtml` |
| Modal Documento | `Features/InformeAnaliticoCompleto/Views/_ModalDetalleDocumento.cshtml` |
| FormHandler POST | `Features/DatosEmpresa/Views/Index.cshtml` |
| FormHandler AJAX | `Features/Sucursales/Views/Index.cshtml` |
