---
project_name: 'HyperContabilidad'
user_name: 'Victor'
date: '2025-12-13'
sections_completed: ['technology_stack', 'implementation_rules', 'naming_conventions', 'critical_rules']
status: 'complete'
rule_count: 25
optimized_for_llm: true
---

# Project Context for AI Agents

_This file contains critical rules and patterns that AI agents must follow when implementing code in this project. Focus on unobvious details that agents might otherwise miss._

---

## Technology Stack & Versions

| Technology | Version | Notes |
|------------|---------|-------|
| .NET | 9.0 | Target framework |
| ASP.NET Core MVC | 9.0 | Web SDK |
| Entity Framework Core | 9.0.9 | ORM - use split queries for complex includes |
| SQL Server | Latest | Primary DB - DefaultConnection |
| SQLite | Latest | Secondary DB - LpRemuConnection |
| Tailwind CSS | 3.4.19 | With @tailwindcss/forms plugin |
| jQuery | Latest | DOM + AJAX |
| QuestPDF | 2024.10.0 | Community license |
| EPPlus | 7.0.0 | Excel export |
| Serilog | 9.0.0 | Structured logging |
| BCrypt.Net-Next | 4.0.3 | Password hashing |

---

## Critical Implementation Rules

### Architecture Pattern: Vertical Slice Architecture

Each feature MUST be self-contained in `Features/{FeatureName}/`:
- `{Name}Controller.cs` - MVC controller (returns Views)
- `{Name}ApiController.cs` - API controller (returns JSON)
- `I{Name}Service.cs` - Service interface
- `{Name}Service.cs` - Service implementation
- `{Name}Dto.cs` - Data transfer objects
- `{Name}ViewModel.cs` - View models
- `Views/` - Razor views

### Service Registration Rules

1. **Auto-registration**: Services matching `I{Name}Service` + `{Name}Service` in Features namespace are auto-registered as Scoped
2. **Manual registration required** for:
   - Services not ending in "Service" (e.g., `ISiiApiClient`)
   - Services in `Services/` folder (not Features)
   - Singleton services
3. **Always use Scoped lifetime** for services using DbContext

### Session & Company Context

```csharp
// ALWAYS validate company selection before operations
if (SessionHelper.EmpresaId <= 0)
    return RedirectToAction("Index", "SeleccionarEmpresa");

// Access session data via SessionHelper (never HttpContext directly)
var empresaId = SessionHelper.EmpresaId;
var ano = SessionHelper.Ano;
var userId = SessionHelper.UsuarioId;
var isAdmin = SessionHelper.EsAdmin;
```

### Database Access Patterns

```csharp
// Use async/await for ALL database operations
await _context.Items.ToListAsync();

// Use split queries for complex includes
var items = await _context.Items
    .AsSplitQuery()
    .Include(x => x.Movimientos)
    .Include(x => x.Documentos)
    .ToListAsync();

// Filter by EmpresaId for multi-tenant queries
.Where(x => x.EmpresaId == empresaId)
```

### View Location Convention

Views must be placed in feature folders:
```
Features/{FeatureName}/Views/Index.cshtml
Features/{FeatureName}/Views/_Partial.cshtml
Features/Shared/{SharedView}.cshtml
```

### Controller Patterns

```csharp
// MVC Controller - returns Views
[Authorize]
public class FeatureController : Controller
{
    public async Task<IActionResult> Index()
    {
        if (SessionHelper.EmpresaId <= 0)
            return RedirectToAction("Index", "SeleccionarEmpresa");
        // ...
        return View(viewModel);
    }
}

// API Controller - returns JSON
[ApiController]
[Route("api/[controller]")]
public class FeatureApiController : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetAll([FromQuery] int empresaId)
    {
        var data = await _service.GetAllAsync(empresaId);
        return Ok(data);
    }
}
```

---

## Naming Conventions

| Element | Convention | Example |
|---------|------------|---------|
| Feature folder | PascalCase | `GestionDocumentos/` |
| Controller | `{Feature}Controller.cs` | `GestionDocumentosController.cs` |
| API Controller | `{Feature}ApiController.cs` | `GestionDocumentosApiController.cs` |
| Service Interface | `I{Feature}Service.cs` | `IGestionDocumentosService.cs` |
| Service Implementation | `{Feature}Service.cs` | `GestionDocumentosService.cs` |
| DTO | `{Feature}Dto.cs` | `GestionDocumentosDto.cs` |
| ViewModel | `{Feature}ViewModel.cs` | `GestionDocumentosViewModel.cs` |
| Entity | PascalCase singular | `Documento.cs` |
| Private fields | `_camelCase` | `_context`, `_logger` |
| Async methods | `{Method}Async` | `GetAllAsync()` |

---

## Critical Don't-Miss Rules

### NEVER DO:
- ❌ Access HttpContext directly - use `SessionHelper`
- ❌ Create Singleton services that use DbContext
- ❌ Use synchronous database calls (use async/await)
- ❌ Skip company validation (`SessionHelper.EmpresaId > 0`)
- ❌ Put views outside `Features/{Name}/Views/`
- ❌ Create services without interface (breaks auto-registration)
- ❌ Use `Include()` without `AsSplitQuery()` for multiple includes

### ALWAYS DO:
- ✅ Validate `SessionHelper.EmpresaId > 0` at controller entry
- ✅ Use `[Authorize]` on MVC controllers
- ✅ Use `async/await` for all I/O operations
- ✅ Inject `ILogger<T>` for structured logging
- ✅ Use DTOs for API responses, ViewModels for views
- ✅ Follow feature-based folder organization
- ✅ Use Tailwind CSS classes (not custom CSS)

### Privilege System

```csharp
// Check privileges before sensitive operations
if (!SessionHelper.HasPrivilege(SessionHelper.Privileges.PRV_ADM_COMP))
    return Forbid();

// Available privileges:
// PRV_ADM_SIS     = 0x1    - Configurar Usuarios y Administrar Sistema
// PRV_CFG_EMP     = 0x2    - Definir y Configurar Empresa
// PRV_ADM_EMPRESA = 0x4    - Administrar Períodos Contables
// PRV_ADM_CTAS    = 0x8    - Administrar Plan de Cuentas
// PRV_ING_COMP    = 0x10   - Ingresar Comprobantes
// PRV_ADM_COMP    = 0x20   - Administrar Comprobantes
// PRV_ING_DOCS    = 0x40   - Ingresar Documentos
// PRV_ADM_DOCS    = 0x80   - Administrar Documentos
// PRV_VER_INFO    = 0x200  - Ver Informes
```

### Error Handling Pattern

```csharp
try
{
    // operation
}
catch (Exception ex)
{
    _logger.LogError(ex, "Error in {Method} for empresa {EmpresaId}",
        nameof(MethodName), empresaId);
    return StatusCode(500, new { error = "Error interno del servidor" });
}
```

---

## Migration Context

This project was migrated from VB6 to .NET 9. Key references:
- `docs/features.md` - Complete feature catalog with migration status
- `Features/{Name}/Analysis.md` - Per-feature VB6→.NET migration analysis
- `vb6/` - Original VB6 source code for reference

---

_Generated by BMad Method generate-project-context workflow - 2025-12-13_
