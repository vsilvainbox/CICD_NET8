# HyperContabilidad - Project Overview

## Executive Summary

**HyperContabilidad** is a comprehensive accounting system migrated from Visual Basic 6 to .NET 9 (ASP.NET Core MVC). The application provides full accounting functionality for Chilean businesses, including integration with SII (Servicio de Impuestos Internos).

| Attribute | Value |
|-----------|-------|
| **Project Type** | Web Application (Full-Stack) |
| **Architecture** | Vertical Slice Architecture |
| **Framework** | ASP.NET Core 9.0 |
| **Language** | C# 13 |
| **Database** | SQL Server + SQLite |
| **Frontend** | Razor Views + Tailwind CSS + jQuery |
| **Migration Status** | ~85% Complete |

## Project Context

This is a **brownfield migration project** from a legacy VB6 desktop application to a modern web application. The migration was performed feature-by-feature with detailed analysis documentation.

### Key Migration Artifacts

| Document | Purpose |
|----------|---------|
| `features.md` | Complete catalog of ~170+ functionalities with migration status |
| `vb2.md` | Navigation flows and user workflows from VB6 |
| `vb6/` | Original VB6 source code for reference |
| `Features/*/Analysis.md` | Per-feature migration analysis |

## Technology Stack

### Backend
- **Runtime:** .NET 9.0
- **Framework:** ASP.NET Core MVC
- **ORM:** Entity Framework Core 9.0
- **Database:** SQL Server (primary), SQLite (secondary)
- **Authentication:** Cookie-based with 8-hour sessions
- **Logging:** Serilog with structured logging

### Frontend
- **Views:** Razor (.cshtml)
- **CSS:** Tailwind CSS 3.4 with @tailwindcss/forms
- **JavaScript:** jQuery + jQuery Validation
- **UI Components:** jsTree (hierarchical data), Font Awesome (icons)
- **Typography:** Outfit font family

### Integrations
- **PDF Generation:** QuestPDF
- **Excel Export:** EPPlus 7.0
- **Email:** MailKit
- **Chilean Tax Authority:** SII API integration

## Architecture Overview

The application follows **Vertical Slice Architecture** where each feature is self-contained:

```
Features/
├── FeatureName/
│   ├── FeatureNameController.cs      # MVC Controller (returns Views)
│   ├── FeatureNameApiController.cs   # API Controller (returns JSON)
│   ├── FeatureNameService.cs         # Business logic
│   ├── IFeatureNameService.cs        # Service interface
│   ├── FeatureNameDto.cs             # Data transfer objects
│   ├── FeatureNameViewModel.cs       # View models
│   ├── Views/
│   │   ├── Index.cshtml              # Main view
│   │   └── _Partials.cshtml          # Partial views
│   └── Analysis.md                   # Migration analysis
```

### Key Metrics

| Metric | Count |
|--------|-------|
| Feature Modules | ~170+ |
| API Controllers | ~140+ |
| HTTP Endpoints | ~1,927 |
| Entity Classes | ~90+ |
| Service Interfaces | ~100+ |

## Domain Model

The application handles Chilean accounting with these core domains:

### Core Accounting
- **Comprobantes:** Accounting vouchers and journal entries
- **Cuentas:** Chart of accounts management
- **Movimientos:** Account movements and transactions
- **Documentos:** Supporting documents

### Financial Reports
- **Balances:** Classified, comparative, general balances
- **Estado de Resultados:** Income statements
- **Libros Contables:** Accounting books (Diario, Mayor, Caja)

### Tax & Compliance (Chilean SII)
- **Libros Electrónicos:** Electronic books for tax authority
- **F29/F22:** Tax form exports
- **Proporcionalidad IVA:** VAT proportionality calculations

### Asset Management
- **Activo Fijo:** Fixed asset management
- **Depreciación:** Depreciation calculations (including Ley 21210, 21256)

## Getting Started

### Prerequisites
- .NET 9.0 SDK
- SQL Server (or SQL Server Express)
- Node.js (for Tailwind CSS compilation)

### Quick Start
```bash
# Install dependencies
dotnet restore
npm install

# Build Tailwind CSS
npm run css:build

# Run the application
dotnet run
```

### Environment Configuration
- Copy `appsettings.json` and configure connection strings
- Primary database: SQL Server (DefaultConnection)
- Secondary database: SQLite for payroll integration (LpRemuConnection)

## Documentation Index

- [Architecture Documentation](./architecture.md)
- [Source Tree Analysis](./source-tree-analysis.md)
- [Development Guide](./development-guide.md)
- [API Reference](./api-contracts.md) _(To be generated)_
- [Data Models](./data-models.md) _(To be generated)_

## AI-Assisted Development

This project is optimized for AI-assisted development with:
- Comprehensive migration analysis per feature
- Detailed VB6 to .NET mapping documentation
- Structured feature organization for context clarity
- Clear architectural patterns for consistent code generation

When working with AI tools, reference:
1. `features.md` for overall system capabilities
2. `Features/{name}/Analysis.md` for specific feature context
3. This documentation for architectural decisions
