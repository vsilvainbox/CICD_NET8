/**
 * Funciones globales para manejo de modales Tailwind CSS
 * Sin dependencias de Bootstrap
 * Fecha: 4 de Octubre, 2025
 */

/**
 * Abre un modal custom Tailwind por su ID
 * @param {string} modalId - ID del modal a abrir
 */
function abrirModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('hidden');
        document.body.style.overflow = 'hidden'; // Prevenir scroll del body
        
        // Trigger evento custom para hooks
        const evento = new CustomEvent('modalAbierto', { detail: { modalId } });
        document.dispatchEvent(evento);
    } else {
        console.warn(`Modal con ID "${modalId}" no encontrado`);
    }
}

/**
 * Cierra un modal custom Tailwind
 * Puede recibir el elemento del botón que disparó el cierre
 * o el ID del modal directamente
 * @param {HTMLElement|string} elementOrId - Elemento que disparó el evento o ID del modal
 */
function cerrarModal(elementOrId) {
    let modal = null;
    
    if (typeof elementOrId === 'string') {
        // Es un ID
        modal = document.getElementById(elementOrId);
    } else if (elementOrId instanceof HTMLElement) {
        // Es un elemento, buscar el modal padre
        modal = elementOrId.closest('[class*="fixed inset-0"]');
        
        // Si no encuentra el modal como padre, buscar por ID común
        if (!modal) {
            // Intentar encontrar el modal más cercano visible
            const modales = document.querySelectorAll('[class*="fixed inset-0"]:not(.hidden)');
            if (modales.length > 0) {
                modal = modales[modales.length - 1]; // Cerrar el último abierto
            }
        }
    }
    
    if (modal) {
        modal.classList.add('hidden');
        document.body.style.overflow = ''; // Restaurar scroll
        
        // Trigger evento custom para hooks
        const modalId = modal.id || 'unknown';
        const evento = new CustomEvent('modalCerrado', { detail: { modalId } });
        document.dispatchEvent(evento);
    } else {
        console.warn('No se pudo encontrar el modal para cerrar');
    }
}

/**
 * Alterna la visibilidad de un modal (abrir/cerrar)
 * @param {string} modalId - ID del modal
 */
function toggleModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        if (modal.classList.contains('hidden')) {
            abrirModal(modalId);
        } else {
            cerrarModal(modalId);
        }
    }
}

/**
 * Inicialización de eventos globales para modales
 */
document.addEventListener('DOMContentLoaded', function() {
    
    // ✅ ESTANDARIZADO: Los modales solo se cierran con botón X o Cancelar
    // No se cierran al hacer click en el backdrop ni con ESC
    
    // Manejar botones con atributo data-modal-open
    const botonesAbrir = document.querySelectorAll('[data-modal-open]');
    botonesAbrir.forEach(boton => {
        boton.addEventListener('click', function() {
            const modalId = this.getAttribute('data-modal-open');
            abrirModal(modalId);
        });
    });
    
    // Manejar botones con atributo data-modal-close
    const botonesCerrar = document.querySelectorAll('[data-modal-close]');
    botonesCerrar.forEach(boton => {
        boton.addEventListener('click', function() {
            const modalId = this.getAttribute('data-modal-close');
            if (modalId) {
                cerrarModal(modalId);
            } else {
                cerrarModal(this);
            }
        });
    });
});

/**
 * Función auxiliar para crear modales dinámicamente
 * @param {Object} config - Configuración del modal
 * @returns {string} ID del modal creado
 */
function crearModalDinamico(config) {
    const {
        id = `modal-${Date.now()}`,
        titulo = 'Modal',
        contenido = '',
        botones = [],
        tamano = 'md' // sm, md, lg, xl
    } = config;
    
    const tamanos = {
        sm: 'max-w-sm',
        md: 'max-w-lg',
        lg: 'max-w-4xl',
        xl: 'max-w-6xl'
    };
    
    const modalHTML = `
        <div id="${id}" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50 hidden">
            <div class="flex items-center justify-center min-h-screen px-4">
                <div class="relative bg-white rounded-lg shadow-xl ${tamanos[tamano]} w-full">
                    <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                        <h5 class="text-lg font-semibold text-gray-900">${titulo}</h5>
                        <button onclick="cerrarModal('${id}')" class="text-gray-400 hover:text-gray-600 text-2xl font-bold leading-none cursor-pointer">&times;</button>
                    </div>
                    <div class="p-6">${contenido}</div>
                    ${botones.length > 0 ? `
                        <div class="bg-gray-50 px-6 py-4 border-t border-gray-200 flex justify-end gap-2">
                            ${botones.map(btn => `
                                <button 
                                    onclick="${btn.onclick || `cerrarModal('${id}')`}" 
                                    class="${btn.clase || 'px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 transition-colors'}">
                                    ${btn.texto}
                                </button>
                            `).join('')}
                        </div>
                    ` : ''}
                </div>
            </div>
        </div>
    `;
    
    // Agregar al body
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = modalHTML;
    document.body.appendChild(tempDiv.firstElementChild);
    
    return id;
}

/**
 * Clase TailwindModal - Compatibilidad con bootstrap.Modal
 * Proporciona la misma API que bootstrap.Modal pero usando Tailwind CSS
 */
class TailwindModal {
    constructor(element) {
        this.element = element;
        this.modalId = element.id;

        // Registrar instancia
        if (!TailwindModal._instances) {
            TailwindModal._instances = new Map();
        }
        TailwindModal._instances.set(element, this);
    }

    show() {
        abrirModal(this.modalId);
    }

    hide() {
        cerrarModal(this.modalId);
    }

    toggle() {
        toggleModal(this.modalId);
    }

    dispose() {
        TailwindModal._instances.delete(this.element);
    }

    static getInstance(element) {
        if (TailwindModal._instances && TailwindModal._instances.has(element)) {
            return TailwindModal._instances.get(element);
        }
        return null;
    }

    static getOrCreateInstance(element) {
        let instance = TailwindModal.getInstance(element);
        if (!instance) {
            instance = new TailwindModal(element);
        }
        return instance;
    }
}

// Crear objeto bootstrap compatible (solo modals)
window.bootstrap = window.bootstrap || {};
window.bootstrap.Modal = TailwindModal;

// Exponer funciones globalmente
window.abrirModal = abrirModal;
window.cerrarModal = cerrarModal;
window.toggleModal = toggleModal;
window.crearModalDinamico = crearModalDinamico;
