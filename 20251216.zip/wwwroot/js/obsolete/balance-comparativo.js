$(document).ready(function() {
    // Inicializar componentes
    inicializarComponentes();
    inicializarEventos();
    inicializarDataTable();
});

function inicializarComponentes() {
    // Inicializar datepickers
    $('.datepicker').datepicker({
        format: 'dd/mm/yyyy',
        autoclose: true,
        todayHighlight: true,
        language: 'es'
    });

    // Configurar tooltips
    $('[data-bs-toggle="tooltip"]').tooltip();
}

function inicializarEventos() {
    // Evento para generar balance
    $('#filtrosForm').on('submit', function(e) {
        e.preventDefault();
        generarBalance();
    });

    // Evento para exportar Excel
    $('#btnExportarExcel').on('click', function() {
        exportarExcel();
    });

    // Evento para vista previa
    $('#btnVistaPrevia').on('click', function() {
        vistaPrevia();
    });

    // Evento para sumar movimientos
    $('#btnSumar').on('click', function() {
        sumarMovimientos();
    });

    // Evento para limpiar
    $('#btnLimpiar').on('click', function() {
        limpiarFormulario();
    });

    // Evento para seleccionar todos
    $('#chkSeleccionarTodos').on('change', function() {
        $('.chk-cuenta').prop('checked', this.checked);
        actualizarBotonSumar();
    });

    // Evento para selección individual
    $(document).on('change', '.chk-cuenta', function() {
        actualizarBotonSumar();
    });

    // Evento para doble clic en fila (ver libro mayor)
    $(document).on('dblclick', '#tablaBalance tbody tr', function() {
        const idCuenta = $(this).data('id-cuenta');
        if (idCuenta && idCuenta > 0) {
            verLibroMayor(idCuenta);
        }
    });

    // Evento para checkbox de libro oficial
    $('#chkLibroOficial').on('change', function() {
        if (this.checked) {
            $('#Request_AreaNegocio').prop('disabled', true).val('');
            $('#Request_CentroCosto').prop('disabled', true).val('');
        } else {
            $('#Request_AreaNegocio').prop('disabled', false);
            $('#Request_CentroCosto').prop('disabled', false);
        }
    });

    // Evento para checkbox de ver código cuenta
    $('#chkVerCodigoCuenta').on('change', function() {
        actualizarColumnas();
    });
}

function inicializarDataTable() {
    if ($.fn.DataTable) {
        $('#tablaBalance').DataTable({
            responsive: true,
            pageLength: 25,
            lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "Todos"]],
            language: {
                url: '//cdn.datatables.net/plug-ins/1.13.7/i18n/es-ES.json'
            },
            columnDefs: [
                { orderable: false, targets: 0 }
            ],
            order: [[2, 'asc']],
            dom: 'Bfrtip',
            buttons: [
                'copy', 'csv', 'excel', 'pdf', 'print'
            ]
        });
    }
}

function generarBalance() {
    const formData = $('#filtrosForm').serialize();
    
    // Mostrar loading
    $('#btnGenerar').prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Generando...');
    
    $.ajax({
        url: '/BalanceComparativo/GenerarBalance',
        type: 'POST',
        data: formData,
        success: function(response) {
            if (response.success) {
                // Recargar la página con los datos
                location.reload();
            } else {
                mostrarError(response.message || 'Error al generar balance comparativo');
            }
        },
        error: function(xhr, status, error) {
            mostrarError('Error de conexión: ' + error);
        },
        complete: function() {
            $('#btnGenerar').prop('disabled', false).html('<i class="fas fa-search me-2"></i>Generar Balance');
        }
    });
}

function exportarExcel() {
    const request = obtenerRequestActual();
    
    // Mostrar loading
    $('#btnExportarExcel').prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Exportando...');
    
    $.ajax({
        url: '/BalanceComparativo/ExportarExcel',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(request),
        success: function(response) {
            if (response.success) {
                // Descargar archivo
                const blob = new Blob([response.archivo], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = response.nombreArchivo;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
            } else {
                mostrarError(response.message || 'Error al exportar a Excel');
            }
        },
        error: function(xhr, status, error) {
            mostrarError('Error de conexión: ' + error);
        },
        complete: function() {
            $('#btnExportarExcel').prop('disabled', false).html('<i class="fas fa-file-excel me-2"></i>Exportar Excel');
        }
    });
}

function vistaPrevia() {
    const request = obtenerRequestActual();
    
    // Mostrar loading
    $('#btnVistaPrevia').prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Generando...');
    
    $.ajax({
        url: '/BalanceComparativo/VistaPrevia',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(request),
        success: function(response) {
            if (response.success) {
                mostrarVistaPrevia(response);
            } else {
                mostrarError(response.message || 'Error al generar vista previa');
            }
        },
        error: function(xhr, status, error) {
            mostrarError('Error de conexión: ' + error);
        },
        complete: function() {
            $('#btnVistaPrevia').prop('disabled', false).html('<i class="fas fa-eye me-2"></i>Vista Previa');
        }
    });
}

function sumarMovimientos() {
    const cuentasSeleccionadas = $('.chk-cuenta:checked').map(function() {
        return parseInt($(this).val());
    }).get();
    
    if (cuentasSeleccionadas.length === 0) {
        mostrarError('Seleccione al menos una cuenta para sumar');
        return;
    }
    
    const request = {
        idsCuentas: cuentasSeleccionadas,
        fechaDesdeAnterior: $('#Request_FechaDesdeAnterior').val(),
        fechaHastaAnterior: $('#Request_FechaHastaAnterior').val(),
        fechaDesdeActual: $('#Request_FechaDesdeActual').val(),
        fechaHastaActual: $('#Request_FechaHastaActual').val(),
        tipoAjuste: $('#Request_TipoAjuste').val() || null
    };
    
    // Mostrar loading
    $('#btnSumar').prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Sumando...');
    
    $.ajax({
        url: '/BalanceComparativo/SumarMovimientos',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(request),
        success: function(response) {
            if (response.success) {
                mostrarResultadoSuma(response);
            } else {
                mostrarError(response.message || 'Error al sumar movimientos');
            }
        },
        error: function(xhr, status, error) {
            mostrarError('Error de conexión: ' + error);
        },
        complete: function() {
            $('#btnSumar').prop('disabled', false).html('<i class="fas fa-calculator me-2"></i>Sumar Seleccionados');
        }
    });
}

function verLibroMayor(idCuenta) {
    const request = {
        idCuenta: idCuenta,
        fechaDesde: $('#Request_FechaDesdeActual').val(),
        fechaHasta: $('#Request_FechaHastaActual').val(),
        tipoAjuste: $('#Request_TipoAjuste').val() || null
    };
    
    $.ajax({
        url: '/BalanceComparativo/VerLibroMayor',
        type: 'GET',
        data: request,
        success: function(response) {
            if (response.success) {
                // Redirigir al libro mayor
                window.location.href = response.url + '?' + $.param(response.parametros);
            } else {
                mostrarError(response.message || 'Error al navegar al libro mayor');
            }
        },
        error: function(xhr, status, error) {
            mostrarError('Error de conexión: ' + error);
        }
    });
}

function limpiarFormulario() {
    $('#filtrosForm')[0].reset();
    $('#Request_AreaNegocio').prop('disabled', false);
    $('#Request_CentroCosto').prop('disabled', false);
    $('.chk-cuenta').prop('checked', false);
    $('#chkSeleccionarTodos').prop('checked', false);
    actualizarBotonSumar();
    actualizarColumnas();
}

function actualizarBotonSumar() {
    const cuentasSeleccionadas = $('.chk-cuenta:checked').length;
    $('#btnSumar').prop('disabled', cuentasSeleccionadas === 0);
}

function actualizarColumnas() {
    // Esta función se implementaría si se necesita actualizar las columnas dinámicamente
    // Por ahora se mantiene la funcionalidad básica
}

function obtenerRequestActual() {
    return {
        fechaDesdeAnterior: $('#Request_FechaDesdeAnterior').val(),
        fechaHastaAnterior: $('#Request_FechaHastaAnterior').val(),
        fechaDesdeActual: $('#Request_FechaDesdeActual').val(),
        fechaHastaActual: $('#Request_FechaHastaActual').val(),
        tipoAjuste: $('#Request_TipoAjuste').val() || null,
        areaNegocio: $('#Request_AreaNegocio').val() || null,
        centroCosto: $('#Request_CentroCosto').val() || null,
        nivel: $('#Request_Nivel').val() || null,
        libroOficial: $('#chkLibroOficial').is(':checked'),
        verSubTotales: $('#chkVerSubTotales').is(':checked'),
        verCodigoCuenta: $('#chkVerCodigoCuenta').is(':checked')
    };
}

function mostrarVistaPrevia(response) {
    // Crear ventana de vista previa
    const ventana = window.open('', '_blank', 'width=800,height=600,scrollbars=yes,resizable=yes');
    
    const html = `
        <!DOCTYPE html>
        <html>
        <head>
            <title>Vista Previa - Balance Comparativo</title>
            <style>
                body { font-size: 12px; }
                .table { margin-bottom: 0; }
                .table th, .table td { padding: 0.25rem; }
                .text-end { text-align: right; }
                .text-success { color: #198754; }
                .text-danger { color: #dc3545; }
                .text-warning { color: #ffc107; }
                .text-info { color: #0dcaf0; }
                .table-success { background-color: #d1e7dd; }
                .table-danger { background-color: #f8d7da; }
                .table-warning { background-color: #fff3cd; }
                .table-info { background-color: #d1ecf1; }
            </style>
        </head>
        <body>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <h4>${response.titulo}</h4>
                        <p><strong>Período Anterior:</strong> ${response.periodoAnterior}</p>
                        <p><strong>Período Actual:</strong> ${response.periodoActual}</p>
                        <p><strong>Generado:</strong> ${new Date(response.fechaGeneracion).toLocaleString()}</p>
                        <p><strong>Usuario:</strong> ${response.usuario}</p>
                        
                        <div class="table-responsive">
                            <table class="table table-striped table-sm">
                                <thead class="table-dark">
                                    <tr>
                                        <th>Código</th>
                                        <th>Cuenta</th>
                                        <th class="text-end">Período Anterior</th>
                                        <th class="text-end">Período Actual</th>
                                        <th class="text-end">Diferencia</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${response.datos.map(item => `
                                        <tr class="${item.esTotal ? 'table-' + item.colorFila : ''}">
                                            <td>${item.codigoCuenta}</td>
                                            <td style="padding-left: ${item.indentacion}px;">${item.nombreCuenta}</td>
                                            <td class="text-end">${item.valorAnterior.toLocaleString('es-CL', {minimumFractionDigits: 2})}</td>
                                            <td class="text-end">${item.valorActual.toLocaleString('es-CL', {minimumFractionDigits: 2})}</td>
                                            <td class="text-end ${item.diferencia > 0 ? 'text-success' : item.diferencia < 0 ? 'text-danger' : ''}">
                                                ${item.diferencia.toLocaleString('es-CL', {minimumFractionDigits: 2})}
                                                ${item.porcentajeVariacion !== 0 ? `(${item.porcentajeVariacion.toFixed(1)}%)` : ''}
                                            </td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </body>
        </html>
    `;
    
    ventana.document.write(html);
    ventana.document.close();
}

function mostrarResultadoSuma(response) {
    const html = `
        <div class="row">
            <div class="col-md-12">
                <h5>Resultado de la Suma</h5>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-dark">
                            <tr>
                                <th>Concepto</th>
                                <th class="text-end">Período Anterior</th>
                                <th class="text-end">Período Actual</th>
                                <th class="text-end">Diferencia</th>
                                <th class="text-end">% Variación</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><strong>Total Seleccionado</strong></td>
                                <td class="text-end"><strong>${response.totalAnterior.toLocaleString('es-CL', {minimumFractionDigits: 2})}</strong></td>
                                <td class="text-end"><strong>${response.totalActual.toLocaleString('es-CL', {minimumFractionDigits: 2})}</strong></td>
                                <td class="text-end"><strong>${response.diferencia.toLocaleString('es-CL', {minimumFractionDigits: 2})}</strong></td>
                                <td class="text-end"><strong>${response.porcentajeVariacion.toFixed(2)}%</strong></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <p><strong>Cuentas seleccionadas:</strong> ${response.cantidadCuentas}</p>
            </div>
        </div>
    `;
    
    $('#resultadoSuma').html(html);
    $('#modalSumar').modal('show');
}

function mostrarError(mensaje) {
    // Crear alerta de error
    const alerta = `
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i>
            ${mensaje}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    // Insertar al inicio del contenido
    $('.container-fluid').prepend(alerta);
    
    // Auto-ocultar después de 5 segundos
    setTimeout(function() {
        $('.alert').fadeOut();
    }, 5000);
}

function mostrarExito(mensaje) {
    // Crear alerta de éxito
    const alerta = `
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i>
            ${mensaje}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    // Insertar al inicio del contenido
    $('.container-fluid').prepend(alerta);
    
    // Auto-ocultar después de 3 segundos
    setTimeout(function() {
        $('.alert').fadeOut();
    }, 3000);
}









