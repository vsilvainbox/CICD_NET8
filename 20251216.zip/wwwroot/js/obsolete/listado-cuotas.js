/**
 * JavaScript para funcionalidad del listado de cuotas
 */

$(document).ready(function() {
    // Inicializar componentes
    inicializarComponentes();
    
    // Configurar eventos
    configurarEventos();
    
    // Cargar datos iniciales
    cargarDatosIniciales();
});

/**
 * Inicializar componentes de la interfaz
 */
function inicializarComponentes() {
    // Inicializar Select2 para combos
    $('.select2').select2({
        placeholder: 'Seleccionar...',
        allowClear: true,
        width: '100%'
    });
    
    // Inicializar DataTable para el grid
    $('#gridCuotas').DataTable({
        responsive: true,
        paging: false,
        searching: false,
        ordering: false,
        info: false,
        columnDefs: [
            { orderable: false, targets: [0, 18] }, // Checkbox y acciones
            { className: 'text-center', targets: [0, 1, 6, 7, 12, 13, 14] },
            { className: 'text-right', targets: [11, 15, 16, 17] }
        ],
        language: {
            emptyTable: "No hay datos disponibles",
            zeroRecords: "No se encontraron registros que coincidan con los criterios de búsqueda"
        }
    });
    
    // Configurar tooltips
    $('[data-toggle="tooltip"]').tooltip();
}

/**
 * Configurar eventos de la interfaz
 */
function configurarEventos() {
    // Botón de búsqueda
    $('#btnBuscar').on('click', function() {
        buscarCuotas();
    });
    
    // Enter en campos de filtro
    $('#filtrosForm input, #filtrosForm select').on('keypress', function(e) {
        if (e.which === 13) {
            buscarCuotas();
        }
    });
    
    // Validación de RUT
    $('#btnValidarRut').on('click', function() {
        validarRut();
    });
    
    $('#txRut').on('blur', function() {
        if ($(this).val().trim() !== '') {
            validarRut();
        }
    });
    
    // Selección de entidad por RUT
    $('#txRut').on('change', function() {
        if ($(this).val().trim() !== '') {
            buscarEntidadPorRut();
        }
    });
    
    // Checkbox de selección múltiple
    $('#chkSelectAll').on('change', function() {
        $('input[name="chkCuota"]').prop('checked', $(this).is(':checked'));
        actualizarBotonesAccion();
    });
    
    // Botones de acción
    $('#btnDetDoc').on('click', function() {
        verDetalleDocumento();
    });
    
    $('#btnSum').on('click', function() {
        sumarMovimientos();
    });
    
    $('#btnOrden').on('click', function() {
        mostrarOpcionesOrdenamiento();
    });
    
    $('#btnPreview').on('click', function() {
        vistaPreviaImpresion();
    });
    
    $('#btnPrint').on('click', function() {
        imprimirListado();
    });
    
    $('#btnCopyExcel').on('click', function() {
        exportarExcel();
    });
    
    $('#btnConvMoneda').on('click', function() {
        convertirMoneda();
    });
    
    $('#btnCalc').on('click', function() {
        abrirCalculadora();
    });
    
    $('#btnCalendar').on('click', function() {
        abrirCalendario();
    });
    
    $('#btnDocCuotas').on('click', function() {
        verDetalleCuotas();
    });
    
    // Eventos del grid
    $(document).on('change', 'input[name="chkCuota"]', function() {
        actualizarBotonesAccion();
    });
    
    $(document).on('click', '.btn-ver-detalle', function() {
        var idDocumento = $(this).data('id-documento');
        verDetalleDocumento(idDocumento);
    });
    
    $(document).on('click', '.btn-ver-cuotas', function() {
        var idDocumento = $(this).data('id-documento');
        verDetalleCuotas(idDocumento);
    });
}

/**
 * Cargar datos iniciales
 */
function cargarDatosIniciales() {
    // Cargar opciones de filtros
    cargarOpcionesFiltros();
    
    // Ejecutar búsqueda inicial
    buscarCuotas();
}

/**
 * Cargar opciones para los combos de filtros
 */
function cargarOpcionesFiltros() {
    $.ajax({
        url: '/ListadoCuotas/GetOpcionesFiltros',
        type: 'GET',
        success: function(response) {
            if (response.success) {
                // Actualizar combos con las opciones recibidas
                actualizarCombo('#cbTipoLib', response.opciones.tiposLibro);
                actualizarCombo('#cbTipoDoc', response.opciones.tiposDocumento);
                actualizarCombo('#cbEstado', response.opciones.estadosDocumento);
                actualizarCombo('#cbEntidad', response.opciones.entidades);
                actualizarCombo('#cbNombre', response.opciones.entidades);
            }
        },
        error: function() {
            mostrarError('Error al cargar opciones de filtros');
        }
    });
}

/**
 * Actualizar un combo con opciones
 */
function actualizarCombo(selector, opciones) {
    var combo = $(selector);
    combo.empty();
    combo.append('<option value="">Seleccionar...</option>');
    
    opciones.forEach(function(opcion) {
        combo.append(`<option value="${opcion.valor}">${opcion.texto}</option>`);
    });
    
    combo.trigger('change');
}

/**
 * Buscar cuotas según los filtros
 */
function buscarCuotas() {
    var filtros = obtenerFiltros();
    
    mostrarCargando(true);
    
    $.ajax({
        url: '/ListadoCuotas/Buscar',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(filtros),
        success: function(response) {
            if (response.success) {
                mostrarCuotas(response.cuotas);
                actualizarPaginacion(response);
                actualizarResumen(response);
            } else {
                mostrarError(response.message || 'Error al buscar cuotas');
            }
        },
        error: function() {
            mostrarError('Error al buscar cuotas');
        },
        complete: function() {
            mostrarCargando(false);
        }
    });
}

/**
 * Obtener filtros del formulario
 */
function obtenerFiltros() {
    return {
        idEntidad: $('#cbEntidad').val() || null,
        rutEntidad: $('#txRut').val() || null,
        nombreEntidad: $('#cbNombre').val() || null,
        tipoLibro: $('#cbTipoLib').val() || null,
        tipoDocumento: $('#cbTipoDoc').val() || null,
        numeroDocumento: $('#txNumDoc').val() || null,
        estadoDocumento: $('#cbEstado').val() || null,
        fechaEmisionDesde: $('#txFEmisionDesde').val() || null,
        fechaEmisionHasta: $('#txFEmisionHasta').val() || null,
        fechaVencimientoDesde: $('#txFVencDesde').val() || null,
        fechaVencimientoHasta: $('#txFVencHasta').val() || null,
        descripcion: $('#txDescrip').val() || null,
        valorTotal: $('#txValor').val() ? parseFloat($('#txValor').val()) : null,
        saldosVigentes: $('#chSaldosVig').is(':checked'),
        verCuotas: $('#cbDocCuotas').val() || 'Todas',
        paginaActual: 1,
        registrosPorPagina: 50
    };
}

/**
 * Mostrar cuotas en el grid
 */
function mostrarCuotas(cuotas) {
    var tbody = $('#tbodyCuotas');
    tbody.empty();
    
    if (cuotas && cuotas.length > 0) {
        cuotas.forEach(function(cuota) {
            var fila = crearFilaCuota(cuota);
            tbody.append(fila);
        });
    } else {
        tbody.append('<tr><td colspan="19" class="text-center">No se encontraron cuotas</td></tr>');
    }
    
    // Actualizar contador de registros
    $('#totalRegistros').text(cuotas ? cuotas.length : 0);
}

/**
 * Crear fila para una cuota
 */
function crearFilaCuota(cuota) {
    var checkbox = `<input type="checkbox" name="chkCuota" value="${cuota.idDocumento}" class="form-check-input">`;
    var acciones = `
        <div class="btn-group btn-group-sm">
            <button type="button" class="btn btn-outline-primary btn-ver-detalle" 
                    data-id-documento="${cuota.idDocumento}" title="Ver detalle">
                <i class="fas fa-eye"></i>
            </button>
            <button type="button" class="btn btn-outline-info btn-ver-cuotas" 
                    data-id-documento="${cuota.idDocumento}" title="Ver cuotas">
                <i class="fas fa-file-invoice-dollar"></i>
            </button>
        </div>
    `;
    
    return `
        <tr>
            <td>${checkbox}</td>
            <td>${cuota.idDocumento}</td>
            <td>${cuota.tipoLibro}</td>
            <td>${cuota.tipoDocumento}</td>
            <td>${cuota.numeroDocumento}</td>
            <td><span class="badge badge-${obtenerClaseEstado(cuota.estadoDocumento)}">${cuota.estadoDocumento}</span></td>
            <td>${formatearFecha(cuota.fechaEmision)}</td>
            <td>${formatearFecha(cuota.fechaVencimiento)}</td>
            <td>${cuota.nombreEntidad}</td>
            <td>${cuota.rutEntidad}</td>
            <td>${cuota.descripcion}</td>
            <td class="text-right">${formatearMoneda(cuota.valorTotal)}</td>
            <td class="text-center">${cuota.numeroCuotas}</td>
            <td class="text-center">${cuota.cuotasPagadas}</td>
            <td class="text-center">${cuota.cuotasPendientes}</td>
            <td class="text-right">${formatearMoneda(cuota.saldoTotal)}</td>
            <td class="text-right">${formatearMoneda(cuota.montoPagado)}</td>
            <td class="text-right">${formatearMoneda(cuota.montoPendiente)}</td>
            <td>${acciones}</td>
        </tr>
    `;
}

/**
 * Obtener clase CSS para el estado
 */
function obtenerClaseEstado(estado) {
    switch (estado.toLowerCase()) {
        case 'activo':
        case 'vigente':
            return 'success';
        case 'pendiente':
            return 'warning';
        case 'cancelado':
        case 'anulado':
            return 'danger';
        default:
            return 'secondary';
    }
}

/**
 * Formatear fecha
 */
function formatearFecha(fecha) {
    if (!fecha) return '';
    var date = new Date(fecha);
    return date.toLocaleDateString('es-CL');
}

/**
 * Formatear moneda
 */
function formatearMoneda(valor) {
    if (!valor) return '$0';
    return new Intl.NumberFormat('es-CL', {
        style: 'currency',
        currency: 'CLP'
    }).format(valor);
}

/**
 * Actualizar paginación
 */
function actualizarPaginacion(response) {
    // Implementar lógica de paginación si es necesaria
    $('#registrosInicio').text(response.paginaActual * response.registrosPorPagina - response.registrosPorPagina + 1);
    $('#registrosFin').text(Math.min(response.paginaActual * response.registrosPorPagina, response.totalRegistros));
    $('#totalRegistrosPaginacion').text(response.totalRegistros);
}

/**
 * Actualizar resumen
 */
function actualizarResumen(response) {
    // Implementar actualización del resumen si es necesario
}

/**
 * Validar RUT
 */
function validarRut() {
    var rut = $('#txRut').val().trim();
    
    if (rut === '') {
        return;
    }
    
    $.ajax({
        url: '/ListadoCuotas/ValidarRut',
        type: 'POST',
        data: { rut: rut },
        success: function(response) {
            if (response.success) {
                if (response.esValido) {
                    $('#txRut').val(response.rutFormateado);
                    mostrarExito('RUT válido');
                } else {
                    mostrarError('RUT inválido');
                }
            } else {
                mostrarError(response.message || 'Error al validar RUT');
            }
        },
        error: function() {
            mostrarError('Error al validar RUT');
        }
    });
}

/**
 * Buscar entidad por RUT
 */
function buscarEntidadPorRut() {
    var rut = $('#txRut').val().trim();
    
    if (rut === '') {
        return;
    }
    
    $.ajax({
        url: '/ListadoCuotas/GetEntidadPorRut',
        type: 'GET',
        data: { rut: rut },
        success: function(response) {
            if (response.success) {
                $('#cbEntidad').val(response.entidad.idEntidad).trigger('change');
                $('#cbNombre').val(response.entidad.nombre).trigger('change');
            } else {
                // No mostrar error si no se encuentra la entidad
                console.log('Entidad no encontrada para RUT:', rut);
            }
        },
        error: function() {
            console.log('Error al buscar entidad por RUT');
        }
    });
}

/**
 * Ver detalle de documento
 */
function verDetalleDocumento(idDocumento) {
    if (!idDocumento) {
        var seleccionados = obtenerDocumentosSeleccionados();
        if (seleccionados.length === 0) {
            mostrarError('Seleccione al menos un documento');
            return;
        }
        if (seleccionados.length > 1) {
            mostrarError('Seleccione solo un documento');
            return;
        }
        idDocumento = seleccionados[0];
    }
    
    $.ajax({
        url: '/ListadoCuotas/GetDetalleDocumento',
        type: 'GET',
        data: { idDocumento: idDocumento },
        success: function(response) {
            if (response.success) {
                mostrarDetalleDocumento(response.detalle);
            } else {
                mostrarError(response.message || 'Error al obtener detalle del documento');
            }
        },
        error: function() {
            mostrarError('Error al obtener detalle del documento');
        }
    });
}

/**
 * Mostrar detalle de documento en modal
 */
function mostrarDetalleDocumento(detalle) {
    var contenido = `
        <div class="row">
            <div class="col-md-6">
                <h6>Información del Documento</h6>
                <table class="table table-sm">
                    <tr><td><strong>ID:</strong></td><td>${detalle.idDocumento}</td></tr>
                    <tr><td><strong>Tipo Libro:</strong></td><td>${detalle.tipoLibro}</td></tr>
                    <tr><td><strong>Tipo Documento:</strong></td><td>${detalle.tipoDocumento}</td></tr>
                    <tr><td><strong>N° Documento:</strong></td><td>${detalle.numeroDocumento}</td></tr>
                    <tr><td><strong>Estado:</strong></td><td>${detalle.estadoDocumento}</td></tr>
                    <tr><td><strong>Fecha Emisión:</strong></td><td>${formatearFecha(detalle.fechaEmision)}</td></tr>
                    <tr><td><strong>Fecha Vencimiento:</strong></td><td>${formatearFecha(detalle.fechaVencimiento)}</td></tr>
                </table>
            </div>
            <div class="col-md-6">
                <h6>Información de la Entidad</h6>
                <table class="table table-sm">
                    <tr><td><strong>ID:</strong></td><td>${detalle.idEntidad}</td></tr>
                    <tr><td><strong>Nombre:</strong></td><td>${detalle.nombreEntidad}</td></tr>
                    <tr><td><strong>RUT:</strong></td><td>${detalle.rutEntidad}</td></tr>
                </table>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <h6>Descripción</h6>
                <p>${detalle.descripcion}</p>
                <h6>Valor Total</h6>
                <p class="h4 text-primary">${formatearMoneda(detalle.valorTotal)}</p>
            </div>
        </div>
    `;
    
    $('#modalDetalleDocumentoBody').html(contenido);
    $('#modalDetalleDocumento').modal('show');
}

/**
 * Ver detalle de cuotas
 */
function verDetalleCuotas(idDocumento) {
    if (!idDocumento) {
        var seleccionados = obtenerDocumentosSeleccionados();
        if (seleccionados.length === 0) {
            mostrarError('Seleccione al menos un documento');
            return;
        }
        if (seleccionados.length > 1) {
            mostrarError('Seleccione solo un documento');
            return;
        }
        idDocumento = seleccionados[0];
    }
    
    $.ajax({
        url: '/ListadoCuotas/GetDetalleCuotas',
        type: 'GET',
        data: { idDocumento: idDocumento },
        success: function(response) {
            if (response.success) {
                mostrarDetalleCuotas(response.cuotas);
            } else {
                mostrarError(response.message || 'Error al obtener detalle de cuotas');
            }
        },
        error: function() {
            mostrarError('Error al obtener detalle de cuotas');
        }
    });
}

/**
 * Mostrar detalle de cuotas en modal
 */
function mostrarDetalleCuotas(cuotas) {
    var contenido = `
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th>N° Cuota</th>
                        <th>Fecha Vencimiento</th>
                        <th>Monto Cuota</th>
                        <th>Monto Pagado</th>
                        <th>Saldo Pendiente</th>
                        <th>Estado</th>
                        <th>Fecha Pago</th>
                        <th>Observaciones</th>
                    </tr>
                </thead>
                <tbody>
    `;
    
    cuotas.forEach(function(cuota) {
        var estado = cuota.estadoCuota === 'Pagada' ? 'success' : 'warning';
        var fechaPago = cuota.fechaPago ? formatearFecha(cuota.fechaPago) : '-';
        
        contenido += `
            <tr>
                <td class="text-center">${cuota.numeroCuota}</td>
                <td>${formatearFecha(cuota.fechaVencimiento)}</td>
                <td class="text-right">${formatearMoneda(cuota.montoCuota)}</td>
                <td class="text-right">${formatearMoneda(cuota.montoPagado)}</td>
                <td class="text-right">${formatearMoneda(cuota.saldoPendiente)}</td>
                <td><span class="badge badge-${estado}">${cuota.estadoCuota}</span></td>
                <td>${fechaPago}</td>
                <td>${cuota.observaciones || '-'}</td>
            </tr>
        `;
    });
    
    contenido += `
                </tbody>
            </table>
        </div>
    `;
    
    $('#modalDetalleCuotasBody').html(contenido);
    $('#modalDetalleCuotas').modal('show');
}

/**
 * Sumar movimientos seleccionados
 */
function sumarMovimientos() {
    var seleccionados = obtenerDocumentosSeleccionados();
    
    if (seleccionados.length === 0) {
        mostrarError('Seleccione al menos un documento');
        return;
    }
    
    $.ajax({
        url: '/ListadoCuotas/SumarMovimientos',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(seleccionados),
        success: function(response) {
            if (response.success) {
                mostrarSumaMovimientos(response.suma);
            } else {
                mostrarError(response.message || 'Error al sumar movimientos');
            }
        },
        error: function() {
            mostrarError('Error al sumar movimientos');
        }
    });
}

/**
 * Mostrar suma de movimientos en modal
 */
function mostrarSumaMovimientos(suma) {
    var contenido = `
        <div class="row">
            <div class="col-md-6">
                <h6>Resumen de Documentos</h6>
                <table class="table table-sm">
                    <tr><td><strong>Cantidad de Documentos:</strong></td><td class="text-right">${suma.cantidadDocumentos}</td></tr>
                    <tr><td><strong>Valor Total:</strong></td><td class="text-right">${formatearMoneda(suma.valorTotal)}</td></tr>
                    <tr><td><strong>Promedio por Documento:</strong></td><td class="text-right">${formatearMoneda(suma.promedioValorDocumento)}</td></tr>
                </table>
            </div>
            <div class="col-md-6">
                <h6>Resumen de Cuotas</h6>
                <table class="table table-sm">
                    <tr><td><strong>Total de Cuotas:</strong></td><td class="text-right">${suma.totalCuotas}</td></tr>
                    <tr><td><strong>Cuotas Pagadas:</strong></td><td class="text-right">${suma.cuotasPagadas}</td></tr>
                    <tr><td><strong>Cuotas Pendientes:</strong></td><td class="text-right">${suma.cuotasPendientes}</td></tr>
                    <tr><td><strong>Promedio por Cuota:</strong></td><td class="text-right">${formatearMoneda(suma.promedioValorCuota)}</td></tr>
                </table>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <h6>Resumen Financiero</h6>
                <table class="table table-sm">
                    <tr><td><strong>Monto Pagado:</strong></td><td class="text-right text-success">${formatearMoneda(suma.montoPagado)}</td></tr>
                    <tr><td><strong>Monto Pendiente:</strong></td><td class="text-right text-warning">${formatearMoneda(suma.montoPendiente)}</td></tr>
                </table>
            </div>
        </div>
    `;
    
    $('#modalSumaMovimientosBody').html(contenido);
    $('#modalSumaMovimientos').modal('show');
}

/**
 * Obtener documentos seleccionados
 */
function obtenerDocumentosSeleccionados() {
    var seleccionados = [];
    $('input[name="chkCuota"]:checked').each(function() {
        seleccionados.push(parseInt($(this).val()));
    });
    return seleccionados;
}

/**
 * Actualizar botones de acción según selección
 */
function actualizarBotonesAccion() {
    var seleccionados = obtenerDocumentosSeleccionados();
    var tieneSeleccion = seleccionados.length > 0;
    var tieneSeleccionUnica = seleccionados.length === 1;
    
    $('#btnDetDoc').prop('disabled', !tieneSeleccionUnica);
    $('#btnSum').prop('disabled', !tieneSeleccion);
    $('#btnDocCuotas').prop('disabled', !tieneSeleccionUnica);
}

/**
 * Exportar a Excel
 */
function exportarExcel() {
    var filtros = obtenerFiltros();
    
    $.ajax({
        url: '/ListadoCuotas/ExportarExcel',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(filtros),
        success: function(response) {
            if (response.success) {
                // Descargar archivo
                var blob = new Blob([response], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                var url = window.URL.createObjectURL(blob);
                var a = document.createElement('a');
                a.href = url;
                a.download = 'ListadoCuotas_' + new Date().toISOString().slice(0, 19).replace(/:/g, '-') + '.xlsx';
                a.click();
                window.URL.revokeObjectURL(url);
            } else {
                mostrarError(response.message || 'Error al exportar a Excel');
            }
        },
        error: function() {
            mostrarError('Error al exportar a Excel');
        }
    });
}

/**
 * Imprimir listado
 */
function imprimirListado() {
    var filtros = obtenerFiltros();
    
    $.ajax({
        url: '/ListadoCuotas/Imprimir',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(filtros),
        success: function(response) {
            if (response.success) {
                // Abrir ventana de impresión
                var ventana = window.open('', '_blank');
                ventana.document.write(generarHTMLImpresion(response.reporte));
                ventana.document.close();
                ventana.print();
            } else {
                mostrarError(response.message || 'Error al generar reporte de impresión');
            }
        },
        error: function() {
            mostrarError('Error al generar reporte de impresión');
        }
    });
}

/**
 * Generar HTML para impresión
 */
function generarHTMLImpresion(reporte) {
    return `
        <!DOCTYPE html>
        <html>
        <head>
            <title>${reporte.titulo}</title>
            <style>
                body { font-family: Arial, sans-serif; font-size: 12px; }
                table { width: 100%; border-collapse: collapse; }
                th, td { border: 1px solid #000; padding: 4px; text-align: left; }
                th { background-color: #f0f0f0; font-weight: bold; }
                .text-right { text-align: right; }
                .text-center { text-align: center; }
                .header { text-align: center; margin-bottom: 20px; }
                .footer { margin-top: 20px; font-size: 10px; }
            </style>
        </head>
        <body>
            <div class="header">
                <h2>${reporte.titulo}</h2>
                <p>Generado el: ${formatearFecha(reporte.fechaGeneracion)}</p>
                <p>Criterios: ${reporte.criteriosFiltro}</p>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>ID Doc</th>
                        <th>Tipo Libro</th>
                        <th>Tipo Doc</th>
                        <th>N° Documento</th>
                        <th>Estado</th>
                        <th>F. Emisión</th>
                        <th>F. Vencimiento</th>
                        <th>Entidad</th>
                        <th>RUT</th>
                        <th>Descripción</th>
                        <th>Valor Total</th>
                        <th>Cuotas</th>
                        <th>Pagadas</th>
                        <th>Pendientes</th>
                        <th>Saldo Total</th>
                    </tr>
                </thead>
                <tbody>
                    ${reporte.cuotas.map(cuota => `
                        <tr>
                            <td>${cuota.idDocumento}</td>
                            <td>${cuota.tipoLibro}</td>
                            <td>${cuota.tipoDocumento}</td>
                            <td>${cuota.numeroDocumento}</td>
                            <td>${cuota.estadoDocumento}</td>
                            <td>${formatearFecha(cuota.fechaEmision)}</td>
                            <td>${formatearFecha(cuota.fechaVencimiento)}</td>
                            <td>${cuota.nombreEntidad}</td>
                            <td>${cuota.rutEntidad}</td>
                            <td>${cuota.descripcion}</td>
                            <td class="text-right">${formatearMoneda(cuota.valorTotal)}</td>
                            <td class="text-center">${cuota.numeroCuotas}</td>
                            <td class="text-center">${cuota.cuotasPagadas}</td>
                            <td class="text-center">${cuota.cuotasPendientes}</td>
                            <td class="text-right">${formatearMoneda(cuota.saldoTotal)}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
            <div class="footer">
                <p>Total de registros: ${reporte.totalRegistros}</p>
            </div>
        </body>
        </html>
    `;
}

/**
 * Vista previa de impresión
 */
function vistaPreviaImpresion() {
    // Implementar vista previa
    imprimirListado();
}

/**
 * Mostrar opciones de ordenamiento
 */
function mostrarOpcionesOrdenamiento() {
    // Implementar opciones de ordenamiento
    mostrarInfo('Funcionalidad de ordenamiento en desarrollo');
}

/**
 * Convertir moneda
 */
function convertirMoneda() {
    // Implementar conversión de moneda
    mostrarInfo('Funcionalidad de conversión de moneda en desarrollo');
}

/**
 * Abrir calculadora
 */
function abrirCalculadora() {
    // Implementar calculadora
    mostrarInfo('Funcionalidad de calculadora en desarrollo');
}

/**
 * Abrir calendario
 */
function abrirCalendario() {
    // Implementar calendario
    mostrarInfo('Funcionalidad de calendario en desarrollo');
}

/**
 * Mostrar estado de carga
 */
function mostrarCargando(mostrar) {
    if (mostrar) {
        $('#btnBuscar').prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Buscando...');
    } else {
        $('#btnBuscar').prop('disabled', false).html('<i class="fas fa-search"></i> &Listar');
    }
}

/**
 * Mostrar mensaje de éxito
 */
function mostrarExito(mensaje) {
    toastr.success(mensaje);
}

/**
 * Mostrar mensaje de error
 */
function mostrarError(mensaje) {
    toastr.error(mensaje);
}

/**
 * Mostrar mensaje de información
 */
function mostrarInfo(mensaje) {
    toastr.info(mensaje);
}









