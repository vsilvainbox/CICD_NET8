/**
 * Funcionalidad para el libro diario
 */
var LibroDiario = (function() {
    'use strict';

    // Variables de configuración
    var config = {
        gridId: '#gridMovimientos',
        formFiltrosId: '#formFiltros',
        modalVistaPreviaId: '#modalVistaPrevia',
        modalConfiguracionId: '#modalConfiguracionImpresion',
        configuracion: {},
        filtrosDisponibles: {}
    };

    // Elementos del DOM
    var elements = {
        grid: null,
        formFiltros: null,
        modalVistaPrevia: null,
        modalConfiguracion: null,
        btnListar: null,
        btnLimpiar: null,
        btnVerComprobante: null,
        btnVerDocumento: null,
        btnSumar: null,
        btnCalculadora: null,
        btnVistaPrevia: null,
        btnImprimir: null,
        btnExportarExcel: null,
        btnCopiarExcel: null,
        btnImprimirDesdeVistaPrevia: null,
        btnAplicarConfiguracion: null,
        verNumDoc: null,
        totalDebe: null,
        totalHaber: null,
        diferencia: null,
        cantidadMovimientos: null
    };

    // Variables de estado
    var state = {
        movimientos: [],
        totales: null,
        movimientosSeleccionados: [],
        configuracionImpresion: {
            orientacion: 1,
            papelFoliado: false,
            informacionPreliminar: false
        }
    };

    /**
     * Inicializa la funcionalidad
     */
    function init(options) {
        // Extender configuración
        if (options) {
            Object.assign(config, options);
        }

        // Obtener elementos del DOM
        initializeElements();

        // Configurar event listeners
        setupEventListeners();

        // Inicializar grid
        initializeGrid();

        // Inicializar datepickers
        initializeDatepickers();

        console.log('LibroDiario inicializado correctamente');
    }

    /**
     * Inicializa los elementos del DOM
     */
    function initializeElements() {
        elements.grid = $(config.gridId);
        elements.formFiltros = $(config.formFiltrosId);
        elements.modalVistaPrevia = $(config.modalVistaPreviaId);
        elements.modalConfiguracion = $(config.modalConfiguracionId);
        elements.btnListar = $('#btnListar');
        elements.btnLimpiar = $('#btnLimpiar');
        elements.btnVerComprobante = $('#btnVerComprobante');
        elements.btnVerDocumento = $('#btnVerDocumento');
        elements.btnSumar = $('#btnSumar');
        elements.btnCalculadora = $('#btnCalculadora');
        elements.btnVistaPrevia = $('#btnVistaPrevia');
        elements.btnImprimir = $('#btnImprimir');
        elements.btnExportarExcel = $('#btnExportarExcel');
        elements.btnCopiarExcel = $('#btnCopiarExcel');
        elements.btnImprimirDesdeVistaPrevia = $('#btnImprimirDesdeVistaPrevia');
        elements.btnAplicarConfiguracion = $('#btnAplicarConfiguracion');
        elements.verNumDoc = $('#VerNumDoc');
        elements.totalDebe = $('#totalDebe');
        elements.totalHaber = $('#totalHaber');
        elements.diferencia = $('#diferencia');
        elements.cantidadMovimientos = $('#cantidadMovimientos');
    }

    /**
     * Configura los event listeners
     */
    function setupEventListeners() {
        // Event listeners para botones principales
        elements.btnListar.on('click', handleListar);
        elements.btnLimpiar.on('click', handleLimpiar);
        elements.btnVerComprobante.on('click', handleVerComprobante);
        elements.btnVerDocumento.on('click', handleVerDocumento);
        elements.btnSumar.on('click', handleSumar);
        elements.btnCalculadora.on('click', handleCalculadora);
        elements.btnVistaPrevia.on('click', handleVistaPrevia);
        elements.btnImprimir.on('click', handleImprimir);
        elements.btnExportarExcel.on('click', handleExportarExcel);
        elements.btnCopiarExcel.on('click', handleCopiarExcel);
        elements.btnImprimirDesdeVistaPrevia.on('click', handleImprimirDesdeVistaPrevia);
        elements.btnAplicarConfiguracion.on('click', handleAplicarConfiguracion);

        // Event listener para checkbox de ver número de documento
        elements.verNumDoc.on('change', handleVerNumDocChange);

        // Event listeners para selectores de fecha
        $('#btnFechaDesde').on('click', function() {
            $('#FechaDesde').datepicker('show');
        });

        $('#btnFechaHasta').on('click', function() {
            $('#FechaHasta').datepicker('show');
        });

        // Event listeners para cambios en filtros
        elements.formFiltros.find('input, select').on('change', handleFiltrosChange);
    }

    /**
     * Inicializa el grid de movimientos
     */
    function initializeGrid() {
        elements.grid.DataTable({
            processing: true,
            serverSide: false,
            searching: true,
            ordering: true,
            paging: true,
            pageLength: config.configuracion.grid?.tamañoPagina || 50,
            language: {
                url: '//cdn.datatables.net/plug-ins/1.10.24/i18n/Spanish.json'
            },
            columns: [
                { data: 'numeroCuenta', title: 'N° Cuenta' },
                { data: 'codigoCuenta', title: 'Código Cuenta' },
                { data: 'descripcionCuenta', title: 'Descripción Cuenta' },
                { 
                    data: 'numeroDocumento', 
                    title: 'Documento',
                    className: 'col-documento',
                    render: function(data, type, row) {
                        return data || '';
                    }
                },
                { 
                    data: 'debe', 
                    title: 'Debe',
                    className: 'text-right',
                    render: function(data, type, row) {
                        return formatCurrency(data);
                    }
                },
                { 
                    data: 'haber', 
                    title: 'Haber',
                    className: 'text-right',
                    render: function(data, type, row) {
                        return formatCurrency(data);
                    }
                },
                { data: 'glosaMovimiento', title: 'Glosa' },
                { 
                    data: 'fecha', 
                    title: 'Fecha',
                    render: function(data, type, row) {
                        return formatDate(data);
                    }
                },
                { data: 'correlativo', title: 'Comprobante' },
                { data: 'descripcionEstado', title: 'Estado' },
                {
                    data: null,
                    title: 'Acciones',
                    className: 'text-center',
                    orderable: false,
                    render: function(data, type, row) {
                        return '<button type="button" class="btn btn-sm btn-outline-primary btn-seleccionar" data-id="' + row.idMov + '">Seleccionar</button>';
                    }
                }
            ],
            select: {
                style: 'multi',
                selector: 'td:not(:last-child)'
            },
            order: [[7, 'asc']], // Ordenar por fecha
            drawCallback: function(settings) {
                // Actualizar botones según selección
                updateButtonStates();
            }
        });

        // Event listener para botones de selección
        elements.grid.on('click', '.btn-seleccionar', function() {
            var idMov = $(this).data('id');
            toggleMovimientoSeleccionado(idMov);
        });
    }

    /**
     * Inicializa los datepickers
     */
    function initializeDatepickers() {
        $('.datepicker').datepicker({
            format: 'dd/mm/yyyy',
            language: 'es',
            autoclose: true,
            todayHighlight: true
        });
    }

    /**
     * Maneja el clic en el botón de listar
     */
    function handleListar() {
        var filtros = getFiltros();
        
        if (!validarFiltros(filtros)) {
            return;
        }

        // Mostrar loading
        showLoading();

        // Realizar petición AJAX
        $.ajax({
            url: '/LibroDiario/Listar',
            type: 'POST',
            data: filtros,
            success: function(response) {
                if (response.success) {
                    state.movimientos = response.movimientos;
                    state.totales = response.totales;
                    
                    // Actualizar grid
                    updateGrid(response.movimientos);
                    
                    // Actualizar totales
                    updateTotales(response.totales);
                    
                    // Actualizar botones
                    updateButtonStates();
                } else {
                    showError(response.message || 'Error al listar movimientos');
                }
            },
            error: function(xhr, status, error) {
                showError('Error al listar movimientos: ' + error);
            },
            complete: function() {
                hideLoading();
            }
        });
    }

    /**
     * Maneja el clic en el botón de limpiar
     */
    function handleLimpiar() {
        elements.formFiltros[0].reset();
        
        // Restablecer fechas al período actual
        var hoy = new Date();
        var primerDia = new Date(hoy.getFullYear(), hoy.getMonth(), 1);
        var ultimoDia = new Date(hoy.getFullYear(), hoy.getMonth() + 1, 0);
        
        $('#FechaDesde').val(formatDate(primerDia));
        $('#FechaHasta').val(formatDate(ultimoDia));
        
        // Limpiar grid
        elements.grid.DataTable().clear().draw();
        
        // Limpiar totales
        updateTotales({
            totalDebe: 0,
            totalHaber: 0,
            diferencia: 0,
            cantidadMovimientos: 0
        });
        
        // Limpiar estado
        state.movimientos = [];
        state.totales = null;
        state.movimientosSeleccionados = [];
        
        // Actualizar botones
        updateButtonStates();
    }

    /**
     * Maneja el clic en el botón de ver comprobante
     */
    function handleVerComprobante() {
        var movimientosSeleccionados = getMovimientosSeleccionados();
        if (movimientosSeleccionados.length === 0) {
            showError('Debe seleccionar al menos un movimiento');
            return;
        }

        var idComp = movimientosSeleccionados[0].idComp;
        
        $.ajax({
            url: '/LibroDiario/VerComprobante',
            type: 'GET',
            data: { idComp: idComp },
            success: function(response) {
                if (response.success) {
                    // Mostrar modal con detalles del comprobante
                    showModalComprobante(response.data);
                } else {
                    showError(response.message || 'Error al obtener comprobante');
                }
            },
            error: function(xhr, status, error) {
                showError('Error al obtener comprobante: ' + error);
            }
        });
    }

    /**
     * Maneja el clic en el botón de ver documento
     */
    function handleVerDocumento() {
        var movimientosSeleccionados = getMovimientosSeleccionados();
        if (movimientosSeleccionados.length === 0) {
            showError('Debe seleccionar al menos un movimiento');
            return;
        }

        var idDoc = movimientosSeleccionados[0].idDoc;
        if (!idDoc) {
            showError('El movimiento seleccionado no tiene documento asociado');
            return;
        }

        $.ajax({
            url: '/LibroDiario/VerDocumento',
            type: 'GET',
            data: { idDoc: idDoc },
            success: function(response) {
                if (response.success) {
                    // Mostrar modal con detalles del documento
                    showModalDocumento(response.data);
                } else {
                    showError(response.message || 'Error al obtener documento');
                }
            },
            error: function(xhr, status, error) {
                showError('Error al obtener documento: ' + error);
            }
        });
    }

    /**
     * Maneja el clic en el botón de sumar
     */
    function handleSumar() {
        var movimientosSeleccionados = getMovimientosSeleccionados();
        if (movimientosSeleccionados.length === 0) {
            showError('Debe seleccionar al menos un movimiento');
            return;
        }

        var idsMovimientos = movimientosSeleccionados.map(m => m.idMov);
        
        $.ajax({
            url: '/LibroDiario/SumarMovimientos',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(idsMovimientos),
            success: function(response) {
                if (response.success) {
                    // Mostrar modal con totales
                    showModalTotales(response.data);
                } else {
                    showError(response.message || 'Error al sumar movimientos');
                }
            },
            error: function(xhr, status, error) {
                showError('Error al sumar movimientos: ' + error);
            }
        });
    }

    /**
     * Maneja el clic en el botón de calculadora
     */
    function handleCalculadora() {
        // Abrir calculadora del sistema
        if (navigator.userAgent.indexOf('Windows') !== -1) {
            window.open('calc.exe', '_blank');
        } else {
            showInfo('Calculadora no disponible en este sistema');
        }
    }

    /**
     * Maneja el clic en el botón de vista previa
     */
    function handleVistaPrevia() {
        var filtros = getFiltros();
        
        if (!validarFiltros(filtros)) {
            return;
        }

        // Abrir vista previa en nueva ventana
        var url = '/LibroDiario/VistaPrevia?' + $.param(filtros);
        window.open(url, '_blank');
    }

    /**
     * Maneja el clic en el botón de imprimir
     */
    function handleImprimir() {
        var filtros = getFiltros();
        
        if (!validarFiltros(filtros)) {
            return;
        }

        // Mostrar modal de configuración de impresión
        elements.modalConfiguracion.modal('show');
    }

    /**
     * Maneja el clic en el botón de exportar Excel
     */
    function handleExportarExcel() {
        var filtros = getFiltros();
        
        if (!validarFiltros(filtros)) {
            return;
        }

        // Crear formulario temporal para descarga
        var form = $('<form>', {
            method: 'POST',
            action: '/LibroDiario/ExportarExcel'
        });

        $.each(filtros, function(key, value) {
            form.append($('<input>', {
                type: 'hidden',
                name: key,
                value: value
            }));
        });

        $('body').append(form);
        form.submit();
        form.remove();
    }

    /**
     * Maneja el clic en el botón de copiar Excel
     */
    function handleCopiarExcel() {
        if (state.movimientos.length === 0) {
            showError('No hay movimientos para copiar');
            return;
        }

        // Copiar datos al portapapeles
        var datos = state.movimientos.map(function(mov) {
            return [
                mov.numeroCuenta,
                mov.codigoCuenta,
                mov.descripcionCuenta,
                mov.numeroDocumento || '',
                mov.debe,
                mov.haber,
                mov.glosaMovimiento,
                formatDate(mov.fecha),
                mov.correlativo,
                mov.descripcionEstado
            ].join('\t');
        }).join('\n');

        // Agregar encabezados
        var encabezados = [
            'N° Cuenta',
            'Código Cuenta',
            'Descripción Cuenta',
            'Documento',
            'Debe',
            'Haber',
            'Glosa',
            'Fecha',
            'Comprobante',
            'Estado'
        ].join('\t');

        var datosCompletos = encabezados + '\n' + datos;

        // Copiar al portapapeles
        navigator.clipboard.writeText(datosCompletos).then(function() {
            showSuccess('Datos copiados al portapapeles');
        }).catch(function(err) {
            showError('Error al copiar datos: ' + err);
        });
    }

    /**
     * Maneja el clic en el botón de imprimir desde vista previa
     */
    function handleImprimirDesdeVistaPrevia() {
        // Cerrar modal de vista previa
        elements.modalVistaPrevia.modal('hide');
        
        // Imprimir
        window.print();
    }

    /**
     * Maneja el clic en el botón de aplicar configuración
     */
    function handleAplicarConfiguracion() {
        var configuracion = {
            orientacion: parseInt($('#Orientacion').val()),
            papelFoliado: $('#PapelFoliado').is(':checked'),
            informacionPreliminar: $('#InformacionPreliminar').is(':checked')
        };

        state.configuracionImpresion = configuracion;
        
        // Cerrar modal
        elements.modalConfiguracion.modal('hide');
        
        // Proceder con la impresión
        procederConImpresion();
    }

    /**
     * Maneja el cambio en el checkbox de ver número de documento
     */
    function handleVerNumDocChange() {
        var mostrar = elements.verNumDoc.is(':checked');
        
        if (mostrar) {
            $('.col-documento').addClass('show');
        } else {
            $('.col-documento').removeClass('show');
        }
        
        // Redimensionar grid
        elements.grid.DataTable().columns.adjust();
    }

    /**
     * Maneja el cambio en los filtros
     */
    function handleFiltrosChange() {
        // Habilitar botón de listar
        elements.btnListar.prop('disabled', false);
    }

    /**
     * Obtiene los filtros del formulario
     */
    function getFiltros() {
        var filtros = {};
        
        elements.formFiltros.find('input, select').each(function() {
            var $this = $(this);
            var name = $this.attr('name');
            var value = $this.val();
            
            if (name && value !== '') {
                if ($this.attr('type') === 'checkbox') {
                    filtros[name] = $this.is(':checked');
                } else if (name.includes('Fecha')) {
                    filtros[name] = parseDate(value);
                } else {
                    filtros[name] = value;
                }
            }
        });
        
        return filtros;
    }

    /**
     * Valida los filtros
     */
    function validarFiltros(filtros) {
        if (!filtros.fechaDesde || !filtros.fechaHasta) {
            showError('Debe seleccionar las fechas desde y hasta');
            return false;
        }

        if (filtros.fechaDesde > filtros.fechaHasta) {
            showError('La fecha desde no puede ser mayor que la fecha hasta');
            return false;
        }

        return true;
    }

    /**
     * Actualiza el grid con los movimientos
     */
    function updateGrid(movimientos) {
        elements.grid.DataTable().clear();
        
        if (movimientos && movimientos.length > 0) {
            elements.grid.DataTable().rows.add(movimientos).draw();
        }
    }

    /**
     * Actualiza los totales
     */
    function updateTotales(totales) {
        if (totales) {
            elements.totalDebe.text(formatCurrency(totales.totalDebe));
            elements.totalHaber.text(formatCurrency(totales.totalHaber));
            elements.diferencia.text(formatCurrency(totales.diferencia));
            elements.cantidadMovimientos.text(totales.cantidadMovimientos);
            
            // Cambiar color según balance
            if (totales.estaBalanceado) {
                elements.diferencia.removeClass('text-danger').addClass('text-success');
            } else {
                elements.diferencia.removeClass('text-success').addClass('text-danger');
            }
        }
    }

    /**
     * Actualiza el estado de los botones
     */
    function updateButtonStates() {
        var tieneSeleccion = state.movimientosSeleccionados.length > 0;
        var tieneMovimientos = state.movimientos.length > 0;
        
        elements.btnVerComprobante.prop('disabled', !tieneSeleccion);
        elements.btnVerDocumento.prop('disabled', !tieneSeleccion);
        elements.btnSumar.prop('disabled', !tieneSeleccion);
        elements.btnVistaPrevia.prop('disabled', !tieneMovimientos);
        elements.btnImprimir.prop('disabled', !tieneMovimientos);
        elements.btnExportarExcel.prop('disabled', !tieneMovimientos);
        elements.btnCopiarExcel.prop('disabled', !tieneMovimientos);
    }

    /**
     * Obtiene los movimientos seleccionados
     */
    function getMovimientosSeleccionados() {
        return state.movimientosSeleccionados;
    }

    /**
     * Alterna la selección de un movimiento
     */
    function toggleMovimientoSeleccionado(idMov) {
        var index = state.movimientosSeleccionados.findIndex(m => m.idMov === idMov);
        
        if (index >= 0) {
            state.movimientosSeleccionados.splice(index, 1);
        } else {
            var movimiento = state.movimientos.find(m => m.idMov === idMov);
            if (movimiento) {
                state.movimientosSeleccionados.push(movimiento);
            }
        }
        
        updateButtonStates();
    }

    /**
     * Procede con la impresión
     */
    function procederConImpresion() {
        var filtros = getFiltros();
        
        $.ajax({
            url: '/LibroDiario/Imprimir',
            type: 'POST',
            data: $.extend(filtros, state.configuracionImpresion),
            success: function(response) {
                if (response.success) {
                    showSuccess('Impresión realizada correctamente');
                } else {
                    showError(response.message || 'Error al imprimir');
                }
            },
            error: function(xhr, status, error) {
                showError('Error al imprimir: ' + error);
            }
        });
    }

    /**
     * Muestra modal con detalles del comprobante
     */
    function showModalComprobante(comprobante) {
        // Implementar modal de comprobante
        console.log('Mostrar modal de comprobante:', comprobante);
    }

    /**
     * Muestra modal con detalles del documento
     */
    function showModalDocumento(documento) {
        // Implementar modal de documento
        console.log('Mostrar modal de documento:', documento);
    }

    /**
     * Muestra modal con totales
     */
    function showModalTotales(totales) {
        // Implementar modal de totales
        console.log('Mostrar modal de totales:', totales);
    }

    /**
     * Formatea una fecha
     */
    function formatDate(date) {
        if (typeof date === 'string') {
            date = new Date(date);
        }
        
        var day = date.getDate().toString().padStart(2, '0');
        var month = (date.getMonth() + 1).toString().padStart(2, '0');
        var year = date.getFullYear();
        
        return day + '/' + month + '/' + year;
    }

    /**
     * Parsea una fecha desde string
     */
    function parseDate(dateString) {
        var parts = dateString.split('/');
        if (parts.length === 3) {
            return new Date(parts[2], parts[1] - 1, parts[0]);
        }
        return new Date(dateString);
    }

    /**
     * Formatea una moneda
     */
    function formatCurrency(amount) {
        return new Intl.NumberFormat('es-CL', {
            style: 'currency',
            currency: 'CLP'
        }).format(amount);
    }

    /**
     * Muestra un mensaje de error
     */
    function showError(message) {
        toastr.error(message);
    }

    /**
     * Muestra un mensaje de éxito
     */
    function showSuccess(message) {
        toastr.success(message);
    }

    /**
     * Muestra un mensaje de información
     */
    function showInfo(message) {
        toastr.info(message);
    }

    /**
     * Muestra loading
     */
    function showLoading() {
        // Implementar loading
    }

    /**
     * Oculta loading
     */
    function hideLoading() {
        // Implementar ocultar loading
    }

    // API pública
    return {
        init: init,
        getFiltros: getFiltros,
        getMovimientos: function() { return state.movimientos; },
        getTotales: function() { return state.totales; },
        getMovimientosSeleccionados: getMovimientosSeleccionados
    };
})();









