// LISTAR COMPROBANTES - JAVASCRIPT
// Funcionalidad del cliente para el listado de comprobantes

$(document).ready(function() {
    // Variables globales
    let comprobantes = [];
    let comprobantesSeleccionados = [];
    let paginaActual = 1;
    let totalPaginas = 1;
    let filtrosActuales = {};

    // Inicialización
    init();

    function init() {
        // Configurar eventos
        setupEventHandlers();
        
        // Cargar datos iniciales
        cargarComprobantes();
    }

    function setupEventHandlers() {
        // Botones de filtros
        $('#btnBuscar').click(buscarComprobantes);
        $('#btnLimpiar').click(limpiarFiltros);

        // Botones de acción principales
        $('#btnDetalle').click(verDetalle);
        $('#btnVerResumido').click(verResumido);
        $('#btnEditar').click(editarComprobante);
        $('#btnEliminar').click(eliminarComprobante);
        $('#btnDuplicar').click(duplicarComprobante);
        $('#btnCambiarEstado').click(mostrarModalCambiarEstado);
        $('#btnSumar').click(sumarMovimientos);
        $('#btnVistaPrevia').click(vistaPrevia);
        $('#btnImprimir').click(imprimir);
        $('#btnExcel').click(exportarExcel);
        $('#btnAuditoria').click(verAuditoria);
        $('#btnOrdenar').click(mostrarModalOrdenar);
        $('#btnCerrar').click(cerrar);

        // Selección de comprobantes
        $('#selectAll').change(seleccionarTodos);
        $(document).on('change', '.comprobante-checkbox', actualizarSeleccion);
        $(document).on('click', '.btn-seleccionar', seleccionarComprobante);

        // Modales
        $('#btnConfirmarCambioEstado').click(confirmarCambioEstado);
        $('#btnConfirmarOrdenar').click(confirmarOrdenar);

        // Eventos de teclado
        $('#filtrosForm input, #filtrosForm select').on('keypress', function(e) {
            if (e.which === 13) { // Enter
                buscarComprobantes();
            }
        });
    }

    // FUNCIONES DE BÚSQUEDA Y FILTROS

    function buscarComprobantes() {
        const filtros = obtenerFiltros();
        filtrosActuales = filtros;
        paginaActual = 1;
        
        cargarComprobantes(filtros);
    }

    function obtenerFiltros() {
        return {
            IdComp: $('#IdComp').val() || null,
            Tipo: $('#Tipo').val() || null,
            Estado: $('#Estado').val() || null,
            FechaDesde: $('#FechaDesde').val() || null,
            FechaHasta: $('#FechaHasta').val() || null,
            Glosa: $('#Glosa').val() || null,
            Usuario: $('#Usuario').val() || null,
            ValorDesde: $('#ValorDesde').val() || null,
            ValorHasta: $('#ValorHasta').val() || null,
            IdCuenta: $('#IdCuenta').val() || null,
            IdEntidad: $('#IdEntidad').val() || null,
            Rut: $('#Rut').val() || null,
            NumDoc: $('#NumDoc').val() || null,
            DTE: $('#DTE').is(':checked'),
            IdSucursal: $('#IdSucursal').val() || null,
            Pagina: paginaActual,
            TamanoPagina: 50
        };
    }

    function cargarComprobantes(filtros = null) {
        const filtrosAUsar = filtros || filtrosActuales;
        
        $.ajax({
            url: '/ListarComprobantes/Search',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(filtrosAUsar),
            success: function(response) {
                if (response.success) {
                    comprobantes = response.comprobantes;
                    totalPaginas = response.totalPaginas;
                    actualizarGrid();
                    actualizarPaginacion();
                    actualizarBotones();
                } else {
                    mostrarMensaje('error', response.message);
                }
            },
            error: function() {
                mostrarMensaje('error', 'Error al cargar comprobantes');
            }
        });
    }

    function limpiarFiltros() {
        $('#filtrosForm')[0].reset();
        filtrosActuales = {};
        paginaActual = 1;
        cargarComprobantes();
    }

    function actualizarGrid() {
        const tbody = $('#comprobantesBody');
        
        if (comprobantes.length === 0) {
            tbody.html('<tr id="no-comprobantes"><td colspan="14" class="text-center text-muted"><i class="fas fa-info-circle"></i> No hay comprobantes. Use los filtros para buscar.</td></tr>');
            return;
        }

        let html = '';
        comprobantes.forEach(function(comprobante) {
            const estadoClass = comprobante.estado === 1 ? 'secondary' : 
                              comprobante.estado === 2 ? 'warning' : 
                              comprobante.estado === 3 ? 'success' : 'danger';
            const estadoText = comprobante.estado === 1 ? 'Borrador' : 
                             comprobante.estado === 2 ? 'Pendiente' : 
                             comprobante.estado === 3 ? 'Aprobado' : 'Rechazado';
            const diferenciaClass = Math.abs(comprobante.diferencia) < 0.01 ? 'text-success' : 'text-danger';
            
            html += `
                <tr data-id="${comprobante.id}">
                    <td>
                        <input type="checkbox" class="form-check-input comprobante-checkbox" 
                               value="${comprobante.id}">
                    </td>
                    <td>${comprobante.id}</td>
                    <td>${comprobante.correlativo}</td>
                    <td>${comprobante.tipo}</td>
                    <td>
                        <span class="badge bg-${estadoClass}">${estadoText}</span>
                    </td>
                    <td>${formatearFecha(comprobante.fecha)}</td>
                    <td>${comprobante.glosa}</td>
                    <td>${comprobante.usuario}</td>
                    <td class="text-end">${parseFloat(comprobante.totalDebe).toFixed(2)}</td>
                    <td class="text-end">${parseFloat(comprobante.totalHaber).toFixed(2)}</td>
                    <td class="text-end ${diferenciaClass}">${parseFloat(comprobante.diferencia).toFixed(2)}</td>
                    <td class="text-center">${comprobante.cantidadMovimientos}</td>
                    <td>${formatearFecha(comprobante.fechaCreacion)}</td>
                    <td>
                        <button type="button" class="btn btn-sm btn-outline-primary btn-seleccionar" 
                                data-id="${comprobante.id}" title="Seleccionar">
                            <i class="fas fa-hand-pointer"></i>
                        </button>
                    </td>
                </tr>
            `;
        });

        tbody.html(html);
    }

    function actualizarPaginacion() {
        if (totalPaginas <= 1) {
            $('#paginacion').hide();
            return;
        }

        $('#paginacion').show();
        let html = '';
        
        // Botón anterior
        if (paginaActual > 1) {
            html += `<li class="page-item"><a class="page-link" href="#" data-pagina="${paginaActual - 1}">Anterior</a></li>`;
        }
        
        // Páginas
        for (let i = 1; i <= totalPaginas; i++) {
            if (i === paginaActual) {
                html += `<li class="page-item active"><span class="page-link">${i}</span></li>`;
            } else {
                html += `<li class="page-item"><a class="page-link" href="#" data-pagina="${i}">${i}</a></li>`;
            }
        }
        
        // Botón siguiente
        if (paginaActual < totalPaginas) {
            html += `<li class="page-item"><a class="page-link" href="#" data-pagina="${paginaActual + 1}">Siguiente</a></li>`;
        }
        
        $('#paginationList').html(html);
        
        // Eventos de paginación
        $('#paginationList a').click(function(e) {
            e.preventDefault();
            const pagina = parseInt($(this).data('pagina'));
            if (pagina !== paginaActual) {
                paginaActual = pagina;
                filtrosActuales.Pagina = pagina;
                cargarComprobantes();
            }
        });
    }

    // FUNCIONES DE SELECCIÓN

    function seleccionarTodos() {
        const isChecked = $('#selectAll').is(':checked');
        $('.comprobante-checkbox').prop('checked', isChecked);
        actualizarSeleccion();
    }

    function actualizarSeleccion() {
        comprobantesSeleccionados = $('.comprobante-checkbox:checked').map(function() {
            return parseInt($(this).val());
        }).get();
        
        const totalSeleccionados = comprobantesSeleccionados.length;
        const totalComprobantes = comprobantes.length;
        
        // Actualizar checkbox "Seleccionar todos"
        if (totalSeleccionados === 0) {
            $('#selectAll').prop('indeterminate', false).prop('checked', false);
        } else if (totalSeleccionados === totalComprobantes) {
            $('#selectAll').prop('indeterminate', false).prop('checked', true);
        } else {
            $('#selectAll').prop('indeterminate', true);
        }
        
        actualizarBotones();
    }

    function seleccionarComprobante() {
        const id = parseInt($(this).data('id'));
        const checkbox = $(this).closest('tr').find('.comprobante-checkbox');
        checkbox.prop('checked', true);
        actualizarSeleccion();
    }

    // FUNCIONES DE ACCIÓN

    function verDetalle() {
        if (comprobantesSeleccionados.length === 0) {
            mostrarMensaje('warning', 'Debe seleccionar un comprobante');
            return;
        }

        if (comprobantesSeleccionados.length > 1) {
            mostrarMensaje('warning', 'Debe seleccionar solo un comprobante');
            return;
        }

        const id = comprobantesSeleccionados[0];
        cargarDetalleComprobante(id);
    }

    function cargarDetalleComprobante(id) {
        $.ajax({
            url: `/ListarComprobantes/GetComprobante/${id}`,
            method: 'GET',
            success: function(response) {
                if (response.success) {
                    mostrarDetalleComprobante(response.comprobante);
                } else {
                    mostrarMensaje('error', response.message);
                }
            },
            error: function() {
                mostrarMensaje('error', 'Error al cargar detalle del comprobante');
            }
        });
    }

    function mostrarDetalleComprobante(comprobante) {
        const html = `
            <div class="row">
                <div class="col-md-6">
                    <h6>Información General</h6>
                    <table class="table table-sm">
                        <tr><td><strong>ID:</strong></td><td>${comprobante.id}</td></tr>
                        <tr><td><strong>Correlativo:</strong></td><td>${comprobante.correlativo}</td></tr>
                        <tr><td><strong>Tipo:</strong></td><td>${comprobante.tipo}</td></tr>
                        <tr><td><strong>Estado:</strong></td><td>${comprobante.estado}</td></tr>
                        <tr><td><strong>Fecha:</strong></td><td>${formatearFecha(comprobante.fecha)}</td></tr>
                        <tr><td><strong>Usuario:</strong></td><td>${comprobante.usuario}</td></tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <h6>Totales</h6>
                    <table class="table table-sm">
                        <tr><td><strong>Total Debe:</strong></td><td class="text-end">${parseFloat(comprobante.totalDebe).toFixed(2)}</td></tr>
                        <tr><td><strong>Total Haber:</strong></td><td class="text-end">${parseFloat(comprobante.totalHaber).toFixed(2)}</td></tr>
                        <tr><td><strong>Diferencia:</strong></td><td class="text-end">${parseFloat(comprobante.diferencia).toFixed(2)}</td></tr>
                    </table>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-12">
                    <h6>Glosa</h6>
                    <p>${comprobante.glosa}</p>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-12">
                    <h6>Movimientos</h6>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Orden</th>
                                    <th>Código</th>
                                    <th>Cuenta</th>
                                    <th>Debe</th>
                                    <th>Haber</th>
                                    <th>Glosa</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${comprobante.movimientos.map(m => `
                                    <tr>
                                        <td>${m.orden}</td>
                                        <td>${m.codCuenta}</td>
                                        <td>${m.cuenta}</td>
                                        <td class="text-end">${parseFloat(m.debe).toFixed(2)}</td>
                                        <td class="text-end">${parseFloat(m.haber).toFixed(2)}</td>
                                        <td>${m.glosa}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
        
        $('#modalDetalleBody').html(html);
        $('#modalDetalleTitle').text(`Detalle del Comprobante ${comprobante.correlativo}`);
        $('#modalDetalle').modal('show');
    }

    function verResumido() {
        if (comprobantesSeleccionados.length === 0) {
            mostrarMensaje('warning', 'Debe seleccionar un comprobante');
            return;
        }

        if (comprobantesSeleccionados.length > 1) {
            mostrarMensaje('warning', 'Debe seleccionar solo un comprobante');
            return;
        }

        const id = comprobantesSeleccionados[0];
        // TODO: Implementar vista resumida
        mostrarMensaje('info', 'Vista resumida en desarrollo');
    }

    function editarComprobante() {
        if (comprobantesSeleccionados.length === 0) {
            mostrarMensaje('warning', 'Debe seleccionar un comprobante');
            return;
        }

        if (comprobantesSeleccionados.length > 1) {
            mostrarMensaje('warning', 'Debe seleccionar solo un comprobante');
            return;
        }

        const id = comprobantesSeleccionados[0];
        window.location.href = `/NuevoComprobante/Edit/${id}`;
    }

    function eliminarComprobante() {
        if (comprobantesSeleccionados.length === 0) {
            mostrarMensaje('warning', 'Debe seleccionar al menos un comprobante');
            return;
        }

        if (!confirm(`¿Está seguro de que desea eliminar ${comprobantesSeleccionados.length} comprobante(s)? Esta acción no se puede deshacer.`)) {
            return;
        }

        if (comprobantesSeleccionados.length === 1) {
            eliminarComprobanteIndividual(comprobantesSeleccionados[0]);
        } else {
            eliminarComprobantesMultiples(comprobantesSeleccionados);
        }
    }

    function eliminarComprobanteIndividual(id) {
        $.ajax({
            url: `/ListarComprobantes/Delete/${id}`,
            method: 'POST',
            success: function(response) {
                if (response.success) {
                    mostrarMensaje('success', response.message);
                    cargarComprobantes();
                } else {
                    mostrarMensaje('error', response.message);
                }
            },
            error: function() {
                mostrarMensaje('error', 'Error al eliminar comprobante');
            }
        });
    }

    function eliminarComprobantesMultiples(ids) {
        $.ajax({
            url: '/ListarComprobantes/DeleteMultiple',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(ids),
            success: function(response) {
                if (response.success) {
                    mostrarMensaje('success', response.message);
                    cargarComprobantes();
                } else {
                    mostrarMensaje('error', response.message);
                }
            },
            error: function() {
                mostrarMensaje('error', 'Error al eliminar comprobantes');
            }
        });
    }

    function duplicarComprobante() {
        if (comprobantesSeleccionados.length === 0) {
            mostrarMensaje('warning', 'Debe seleccionar al menos un comprobante');
            return;
        }

        if (comprobantesSeleccionados.length === 1) {
            duplicarComprobanteIndividual(comprobantesSeleccionados[0]);
        } else {
            duplicarComprobantesMultiples(comprobantesSeleccionados);
        }
    }

    function duplicarComprobanteIndividual(id) {
        $.ajax({
            url: `/ListarComprobantes/Duplicate/${id}`,
            method: 'POST',
            success: function(response) {
                if (response.success) {
                    mostrarMensaje('success', response.message);
                    cargarComprobantes();
                } else {
                    mostrarMensaje('error', response.message);
                }
            },
            error: function() {
                mostrarMensaje('error', 'Error al duplicar comprobante');
            }
        });
    }

    function duplicarComprobantesMultiples(ids) {
        $.ajax({
            url: '/ListarComprobantes/DuplicateMultiple',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(ids),
            success: function(response) {
                if (response.success) {
                    mostrarMensaje('success', response.message);
                    cargarComprobantes();
                } else {
                    mostrarMensaje('error', response.message);
                }
            },
            error: function() {
                mostrarMensaje('error', 'Error al duplicar comprobantes');
            }
        });
    }

    function mostrarModalCambiarEstado() {
        if (comprobantesSeleccionados.length === 0) {
            mostrarMensaje('warning', 'Debe seleccionar al menos un comprobante');
            return;
        }

        // Mostrar comprobantes seleccionados
        const html = comprobantesSeleccionados.map(id => {
            const comprobante = comprobantes.find(c => c.id === id);
            return `<div>ID: ${comprobante.id} - Correlativo: ${comprobante.correlativo}</div>`;
        }).join('');
        
        $('#comprobantesSeleccionados').html(html);
        $('#nuevoEstado').val('');
        $('#modalCambiarEstado').modal('show');
    }

    function confirmarCambioEstado() {
        const nuevoEstado = $('#nuevoEstado').val();
        if (!nuevoEstado) {
            mostrarMensaje('warning', 'Debe seleccionar un estado');
            return;
        }

        $.ajax({
            url: '/ListarComprobantes/ChangeEstado',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                Ids: comprobantesSeleccionados,
                NuevoEstado: parseInt(nuevoEstado)
            }),
            success: function(response) {
                if (response.success) {
                    mostrarMensaje('success', response.message);
                    $('#modalCambiarEstado').modal('hide');
                    cargarComprobantes();
                } else {
                    mostrarMensaje('error', response.message);
                }
            },
            error: function() {
                mostrarMensaje('error', 'Error al cambiar estado de comprobantes');
            }
        });
    }

    function sumarMovimientos() {
        if (comprobantesSeleccionados.length === 0) {
            mostrarMensaje('warning', 'Debe seleccionar al menos un comprobante');
            return;
        }

        $.ajax({
            url: '/ListarComprobantes/SumarMovimientos',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(comprobantesSeleccionados),
            success: function(response) {
                if (response.success) {
                    mostrarSumaMovimientos(response);
                } else {
                    mostrarMensaje('error', response.message);
                }
            },
            error: function() {
                mostrarMensaje('error', 'Error al sumar movimientos');
            }
        });
    }

    function mostrarSumaMovimientos(data) {
        const html = `
            <div class="alert alert-info">
                <h6>Suma de Movimientos</h6>
                <p><strong>Total Debe:</strong> ${parseFloat(data.totalDebe).toFixed(2)}</p>
                <p><strong>Total Haber:</strong> ${parseFloat(data.totalHaber).toFixed(2)}</p>
                <p><strong>Diferencia:</strong> ${parseFloat(data.diferencia).toFixed(2)}</p>
                <p><strong>Comprobantes:</strong> ${data.comprobantes.length}</p>
            </div>
        `;
        
        mostrarMensaje('info', html);
    }

    function vistaPrevia() {
        if (comprobantes.length === 0) {
            mostrarMensaje('warning', 'No hay comprobantes para mostrar');
            return;
        }

        window.open(`/ListarComprobantes/Preview?${$.param(filtrosActuales)}`, '_blank');
    }

    function imprimir() {
        if (comprobantes.length === 0) {
            mostrarMensaje('warning', 'No hay comprobantes para imprimir');
            return;
        }

        window.open(`/ListarComprobantes/Print?${$.param(filtrosActuales)}`, '_blank');
    }

    function exportarExcel() {
        if (comprobantes.length === 0) {
            mostrarMensaje('warning', 'No hay comprobantes para exportar');
            return;
        }

        const url = `/ListarComprobantes/ExportExcel?${$.param(filtrosActuales)}`;
        window.location.href = url;
    }

    function verAuditoria() {
        if (comprobantesSeleccionados.length === 0) {
            mostrarMensaje('warning', 'Debe seleccionar un comprobante');
            return;
        }

        if (comprobantesSeleccionados.length > 1) {
            mostrarMensaje('warning', 'Debe seleccionar solo un comprobante');
            return;
        }

        const id = comprobantesSeleccionados[0];
        $.ajax({
            url: `/ListarComprobantes/Auditoria/${id}`,
            method: 'GET',
            success: function(response) {
                if (response.success) {
                    mostrarAuditoria(response.auditoria);
                } else {
                    mostrarMensaje('error', response.message);
                }
            },
            error: function() {
                mostrarMensaje('error', 'Error al cargar auditoría');
            }
        });
    }

    function mostrarAuditoria(auditoria) {
        const html = `
            <div class="table-responsive">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Usuario</th>
                            <th>Acción</th>
                            <th>Descripción</th>
                            <th>Detalles</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${auditoria.map(a => `
                            <tr>
                                <td>${formatearFecha(a.fecha)}</td>
                                <td>${a.usuario}</td>
                                <td>${a.accion}</td>
                                <td>${a.descripcion}</td>
                                <td>${a.detalles}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
        
        mostrarMensaje('info', html);
    }

    function mostrarModalOrdenar() {
        $('#columnaOrden').val('');
        $('#direccionOrden').val('asc');
        $('#modalOrdenar').modal('show');
    }

    function confirmarOrdenar() {
        const columna = $('#columnaOrden').val();
        const direccion = $('#direccionOrden').val();
        
        if (!columna) {
            mostrarMensaje('warning', 'Debe seleccionar una columna');
            return;
        }

        $.ajax({
            url: '/ListarComprobantes/Ordenar',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                Comprobantes: comprobantes,
                Columna: columna,
                Direccion: direccion
            }),
            success: function(response) {
                if (response.success) {
                    comprobantes = response.comprobantes;
                    actualizarGrid();
                    $('#modalOrdenar').modal('hide');
                    mostrarMensaje('success', 'Comprobantes ordenados exitosamente');
                } else {
                    mostrarMensaje('error', response.message);
                }
            },
            error: function() {
                mostrarMensaje('error', 'Error al ordenar comprobantes');
            }
        });
    }

    function cerrar() {
        if (confirm('¿Está seguro de que desea cerrar? Los cambios no guardados se perderán.')) {
            window.location.href = '/';
        }
    }

    // FUNCIONES DE UTILIDAD

    function actualizarBotones() {
        const tieneSeleccion = comprobantesSeleccionados.length > 0;
        const tieneComprobantes = comprobantes.length > 0;
        
        // Botones que requieren selección
        $('#btnDetalle, #btnVerResumido, #btnEditar, #btnEliminar, #btnDuplicar, #btnCambiarEstado, #btnSumar, #btnAuditoria').prop('disabled', !tieneSeleccion);
        
        // Botones que requieren comprobantes
        $('#btnVistaPrevia, #btnImprimir, #btnExcel').prop('disabled', !tieneComprobantes);
        
        // Botones siempre habilitados
        $('#btnOrdenar, #btnCerrar').prop('disabled', false);
    }

    function formatearFecha(fecha) {
        if (!fecha) return '';
        const date = new Date(fecha);
        return date.toLocaleDateString('es-ES');
    }

    function mostrarMensaje(tipo, mensaje) {
        const alertClass = tipo === 'error' ? 'alert-danger' : 
                          tipo === 'warning' ? 'alert-warning' : 
                          tipo === 'success' ? 'alert-success' : 'alert-info';
        
        const alertHtml = `
            <div class="alert ${alertClass} alert-dismissible fade show" role="alert">
                ${mensaje}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `;
        
        // Insertar al inicio del contenido
        $('.card-body').prepend(alertHtml);
        
        // Auto-ocultar después de 5 segundos
        setTimeout(function() {
            $('.alert').fadeOut();
        }, 5000);
    }
});

