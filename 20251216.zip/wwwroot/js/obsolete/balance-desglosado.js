$(document).ready(function() {
    // Inicializar componentes
    inicializarComponentes();
    inicializarEventos();
    inicializarDataTable();
    cargarOpcionesDesglose();
});

function inicializarComponentes() {
    // Inicializar datepickers
    $('.datepicker').datepicker({
        format: 'dd/mm/yyyy',
        autoclose: true,
        todayHighlight: true,
        language: 'es'
    });

    // Configurar tooltips
    $('[data-bs-toggle="tooltip"]').tooltip();
}

function inicializarEventos() {
    // Evento para generar balance
    $('#filtrosForm').on('submit', function(e) {
        e.preventDefault();
        generarBalance();
    });

    // Evento para exportar Excel
    $('#btnExportarExcel').on('click', function() {
        exportarExcel();
    });

    // Evento para vista previa
    $('#btnVistaPrevia').on('click', function() {
        vistaPrevia();
    });

    // Evento para sumar movimientos
    $('#btnSumar').on('click', function() {
        sumarMovimientos();
    });

    // Evento para limpiar
    $('#btnLimpiar').on('click', function() {
        limpiarFormulario();
    });

    // Evento para seleccionar todos
    $('#chkSeleccionarTodos').on('change', function() {
        $('.chk-cuenta').prop('checked', this.checked);
        actualizarBotonSumar();
    });

    // Evento para selección individual
    $(document).on('change', '.chk-cuenta', function() {
        actualizarBotonSumar();
    });

    // Evento para doble clic en fila (ver libro mayor)
    $(document).on('dblclick', '#tablaBalance tbody tr', function() {
        const idCuenta = $(this).data('id-cuenta');
        if (idCuenta && idCuenta > 0) {
            verLibroMayor(idCuenta);
        }
    });

    // Evento para cambio de tipo de desglose
    $('input[name="tipoDesglose"]').on('change', function() {
        cargarOpcionesDesglose();
    });

    // Evento para seleccionar todos los desgloses
    $('#btnSeleccionarTodos').on('click', function() {
        $('#listaDesgloses input[type="checkbox"]').prop('checked', true);
    });

    // Evento para limpiar selección de desgloses
    $('#btnLimpiarSeleccion').on('click', function() {
        $('#listaDesgloses input[type="checkbox"]').prop('checked', false);
    });
}

function inicializarDataTable() {
    if ($.fn.DataTable) {
        $('#tablaBalance').DataTable({
            responsive: true,
            pageLength: 25,
            lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "Todos"]],
            language: {
                url: '//cdn.datatables.net/plug-ins/1.13.7/i18n/es-ES.json'
            },
            columnDefs: [
                { orderable: false, targets: 0 }
            ],
            order: [[2, 'asc']],
            dom: 'Bfrtip',
            buttons: [
                'copy', 'csv', 'excel', 'pdf', 'print'
            ]
        });
    }
}

function cargarOpcionesDesglose() {
    const tipoDesglose = $('input[name="tipoDesglose"]:checked').val();
    
    $.ajax({
        url: '/BalanceDesglosado/ObtenerOpcionesDesglose',
        type: 'GET',
        data: { tipoDesglose: tipoDesglose },
        success: function(opciones) {
            let html = '';
            opciones.forEach(function(opcion) {
                html += `
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="${opcion.id}" id="desglose_${opcion.id}">
                        <label class="form-check-label" for="desglose_${opcion.id}">
                            ${opcion.nombre}
                        </label>
                    </div>
                `;
            });
            $('#listaDesgloses').html(html);
        },
        error: function(xhr, status, error) {
            mostrarError('Error al cargar opciones de desglose: ' + error);
        }
    });
}

function generarBalance() {
    const formData = $('#filtrosForm').serialize();
    
    // Agregar desgloses seleccionados
    const desglosesSeleccionados = [];
    $('#listaDesgloses input[type="checkbox"]:checked').each(function() {
        desglosesSeleccionados.push(parseInt($(this).val()));
    });
    
    formData += '&Request.IdsDesglose=' + desglosesSeleccionados.join(',');
    
    // Mostrar loading
    $('#btnGenerar').prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Generando...');
    
    $.ajax({
        url: '/BalanceDesglosado/GenerarBalance',
        type: 'POST',
        data: formData,
        success: function(response) {
            if (response.success) {
                // Recargar la página con los datos
                location.reload();
            } else {
                mostrarError(response.message || 'Error al generar balance desglosado');
            }
        },
        error: function(xhr, status, error) {
            mostrarError('Error de conexión: ' + error);
        },
        complete: function() {
            $('#btnGenerar').prop('disabled', false).html('<i class="fas fa-search me-2"></i>Generar Balance');
        }
    });
}

function exportarExcel() {
    const request = obtenerRequestActual();
    
    // Mostrar loading
    $('#btnExportarExcel').prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Exportando...');
    
    $.ajax({
        url: '/BalanceDesglosado/ExportarExcel',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(request),
        success: function(response) {
            if (response.success) {
                // Descargar archivo
                const blob = new Blob([response.archivo], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = response.nombreArchivo;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
            } else {
                mostrarError(response.message || 'Error al exportar a Excel');
            }
        },
        error: function(xhr, status, error) {
            mostrarError('Error de conexión: ' + error);
        },
        complete: function() {
            $('#btnExportarExcel').prop('disabled', false).html('<i class="fas fa-file-excel me-2"></i>Exportar Excel');
        }
    });
}

function vistaPrevia() {
    const request = obtenerRequestActual();
    
    // Mostrar loading
    $('#btnVistaPrevia').prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Generando...');
    
    $.ajax({
        url: '/BalanceDesglosado/VistaPrevia',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(request),
        success: function(response) {
            if (response.success) {
                mostrarVistaPrevia(response);
            } else {
                mostrarError(response.message || 'Error al generar vista previa');
            }
        },
        error: function(xhr, status, error) {
            mostrarError('Error de conexión: ' + error);
        },
        complete: function() {
            $('#btnVistaPrevia').prop('disabled', false).html('<i class="fas fa-eye me-2"></i>Vista Previa');
        }
    });
}

function sumarMovimientos() {
    const cuentasSeleccionadas = $('.chk-cuenta:checked').map(function() {
        return parseInt($(this).val());
    }).get();
    
    if (cuentasSeleccionadas.length === 0) {
        mostrarError('Seleccione al menos una cuenta para sumar');
        return;
    }
    
    const request = {
        idsCuentas: cuentasSeleccionadas,
        fechaDesde: $('#Request_FechaDesde').val(),
        fechaHasta: $('#Request_FechaHasta').val(),
        tipoAjuste: $('#Request_TipoAjuste').val() || null,
        tipoDesglose: $('input[name="tipoDesglose"]:checked').val(),
        idsDesglose: $('#listaDesgloses input[type="checkbox"]:checked').map(function() {
            return parseInt($(this).val());
        }).get()
    };
    
    // Mostrar loading
    $('#btnSumar').prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Sumando...');
    
    $.ajax({
        url: '/BalanceDesglosado/SumarMovimientos',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(request),
        success: function(response) {
            if (response.success) {
                mostrarResultadoSuma(response);
            } else {
                mostrarError(response.message || 'Error al sumar movimientos');
            }
        },
        error: function(xhr, status, error) {
            mostrarError('Error de conexión: ' + error);
        },
        complete: function() {
            $('#btnSumar').prop('disabled', false).html('<i class="fas fa-calculator me-2"></i>Sumar Seleccionados');
        }
    });
}

function verLibroMayor(idCuenta) {
    const request = {
        idCuenta: idCuenta,
        fechaDesde: $('#Request_FechaDesde').val(),
        fechaHasta: $('#Request_FechaHasta').val(),
        tipoAjuste: $('#Request_TipoAjuste').val() || null
    };
    
    $.ajax({
        url: '/BalanceDesglosado/VerLibroMayor',
        type: 'GET',
        data: request,
        success: function(response) {
            if (response.success) {
                // Redirigir al libro mayor
                window.location.href = response.url + '?' + $.param(response.parametros);
            } else {
                mostrarError(response.message || 'Error al navegar al libro mayor');
            }
        },
        error: function(xhr, status, error) {
            mostrarError('Error de conexión: ' + error);
        }
    });
}

function limpiarFormulario() {
    $('#filtrosForm')[0].reset();
    $('#listaDesgloses input[type="checkbox"]').prop('checked', false);
    $('.chk-cuenta').prop('checked', false);
    $('#chkSeleccionarTodos').prop('checked', false);
    actualizarBotonSumar();
    cargarOpcionesDesglose();
}

function actualizarBotonSumar() {
    const cuentasSeleccionadas = $('.chk-cuenta:checked').length;
    $('#btnSumar').prop('disabled', cuentasSeleccionadas === 0);
}

function obtenerRequestActual() {
    const desglosesSeleccionados = $('#listaDesgloses input[type="checkbox"]:checked').map(function() {
        return parseInt($(this).val());
    }).get();
    
    return {
        fechaDesde: $('#Request_FechaDesde').val(),
        fechaHasta: $('#Request_FechaHasta').val(),
        tipoAjuste: $('#Request_TipoAjuste').val() || null,
        nivel: $('#Request_Nivel').val() || null,
        tipoDesglose: $('input[name="tipoDesglose"]:checked').val(),
        idsDesglose: desglosesSeleccionados,
        verSubTotales: $('#chkVerSubTotales').is(':checked'),
        verCodigoCuenta: $('#chkVerCodigoCuenta').is(':checked'),
        verSoloNivelSeleccionado: $('#chkVerSoloNivelSeleccionado').is(':checked'),
        verColSinDesglose: $('#chkVerColSinDesglose').is(':checked')
    };
}

function mostrarVistaPrevia(response) {
    // Crear ventana de vista previa
    const ventana = window.open('', '_blank', 'width=1200,height=800,scrollbars=yes,resizable=yes');
    
    const html = `
        <!DOCTYPE html>
        <html>
        <head>
            <title>Vista Previa - Balance Desglosado</title>
            <style>
                body { font-size: 11px; }
                .table { margin-bottom: 0; }
                .table th, .table td { padding: 0.2rem; }
                .text-end { text-align: right; }
                .text-success { color: #198754; }
                .text-danger { color: #dc3545; }
                .text-warning { color: #ffc107; }
                .text-info { color: #0dcaf0; }
                .table-success { background-color: #d1e7dd; }
                .table-danger { background-color: #f8d7da; }
                .table-warning { background-color: #fff3cd; }
                .table-info { background-color: #d1ecf1; }
            </style>
        </head>
        <body>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <h4>${response.titulo}</h4>
                        <p><strong>Período:</strong> ${response.periodo}</p>
                        <p><strong>Tipo de Desglose:</strong> ${response.tipoDesglose}</p>
                        <p><strong>Generado:</strong> ${new Date(response.fechaGeneracion).toLocaleString()}</p>
                        <p><strong>Usuario:</strong> ${response.usuario}</p>
                        
                        <div class="table-responsive">
                            <table class="table table-striped table-sm">
                                <thead class="table-dark">
                                    <tr>
                                        <th>Código</th>
                                        <th>Cuenta</th>
                                        <th class="text-end">Total</th>
                                        ${response.datos[0]?.desgloses?.map(d => `<th class="text-end">${d.nombre}</th>`).join('') || ''}
                                    </tr>
                                </thead>
                                <tbody>
                                    ${response.datos.map(item => `
                                        <tr class="${item.esTotal ? 'table-' + item.colorFila : ''}">
                                            <td>${item.codigoCuenta}</td>
                                            <td style="padding-left: ${item.indentacion}px;">${item.nombreCuenta}</td>
                                            <td class="text-end">${item.valorTotal.toLocaleString('es-CL', {minimumFractionDigits: 2})}</td>
                                            ${item.desgloses?.map(d => `<td class="text-end">${d.valor.toLocaleString('es-CL', {minimumFractionDigits: 2})}</td>`).join('') || ''}
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </body>
        </html>
    `;
    
    ventana.document.write(html);
    ventana.document.close();
}

function mostrarResultadoSuma(response) {
    const html = `
        <div class="row">
            <div class="col-md-12">
                <h5>Resultado de la Suma</h5>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-dark">
                            <tr>
                                <th>Concepto</th>
                                <th class="text-end">Total General</th>
                                ${response.totalesPorDesglose?.map(d => `<th class="text-end">${d.nombre}</th>`).join('') || ''}
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><strong>Total Seleccionado</strong></td>
                                <td class="text-end"><strong>${response.totalGeneral.toLocaleString('es-CL', {minimumFractionDigits: 2})}</strong></td>
                                ${response.totalesPorDesglose?.map(d => `<td class="text-end"><strong>${d.valor.toLocaleString('es-CL', {minimumFractionDigits: 2})}</strong></td>`).join('') || ''}
                            </tr>
                        </tbody>
                    </table>
                </div>
                <p><strong>Cuentas seleccionadas:</strong> ${response.cantidadCuentas}</p>
            </div>
        </div>
    `;
    
    $('#resultadoSuma').html(html);
    $('#modalSumar').modal('show');
}

function mostrarError(mensaje) {
    // Crear alerta de error
    const alerta = `
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i>
            ${mensaje}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    // Insertar al inicio del contenido
    $('.container-fluid').prepend(alerta);
    
    // Auto-ocultar después de 5 segundos
    setTimeout(function() {
        $('.alert').fadeOut();
    }, 5000);
}

function mostrarExito(mensaje) {
    // Crear alerta de éxito
    const alerta = `
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i>
            ${mensaje}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    // Insertar al inicio del contenido
    $('.container-fluid').prepend(alerta);
    
    // Auto-ocultar después de 3 segundos
    setTimeout(function() {
        $('.alert').fadeOut();
    }, 3000);
}









