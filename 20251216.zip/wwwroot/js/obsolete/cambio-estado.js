$(document).ready(function() {
    // Variables globales
    let comprobantesSeleccionados = [];
    let nuevoEstado = $('#nuevoEstado').val();
    let estados = @Html.Raw(Json.Serialize(Model.Estados));

    // Inicializar
    inicializar();

    function inicializar() {
        configurarEventos();
        actualizarInfoEstado();
    }

    function configurarEventos() {
        // Cambio de estado
        $('#nuevoEstado').change(function() {
            nuevoEstado = $(this).val();
            actualizarInfoEstado();
            validarEstado();
        });

        // Botones principales
        $('#btnCambiarEstado').click(confirmarCambioEstado);
        $('#btnCancelar').click(cancelarCambioEstado);
        $('#btnValidarPermisos').click(validarPermisos);
        $('#btnRevertir').click(mostrarModalRevertir);
        $('#btnAplicarFiltros').click(aplicarFiltros);
        $('#btnLimpiarFiltros').click(limpiarFiltros);

        // Confirmaciones
        $('#btnConfirmarAccion').click(ejecutarCambioEstado);
        $('#btnConfirmarRevertir').click(ejecutarRevertir);
    }

    function actualizarInfoEstado() {
        const estadoSeleccionado = estados.find(e => e.id == nuevoEstado);
        if (estadoSeleccionado) {
            const info = `
                <div class="d-flex align-items-center">
                    <span class="badge badge-${estadoSeleccionado.color} mr-2">${estadoSeleccionado.nombre}</span>
                    <div>
                        <strong>${estadoSeleccionado.nombre}</strong><br>
                        <small class="text-muted">${estadoSeleccionado.descripcion}</small>
                    </div>
                </div>
            `;
            $('#infoEstado').html(info);
        }
    }

    function validarEstado() {
        if (!nuevoEstado || comprobantesSeleccionados.length === 0) {
            $('#btnCambiarEstado').prop('disabled', true);
            return;
        }

        $.ajax({
            url: '/CambioEstado/ValidateEstado',
            type: 'POST',
            data: JSON.stringify({
                estado: parseInt(nuevoEstado),
                comprobantesIds: comprobantesSeleccionados
            }),
            contentType: 'application/json',
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                mostrarValidacionEstado(response);
                $('#btnCambiarEstado').prop('disabled', !response.success);
            },
            error: function() {
                mostrarError('Error al validar estado');
            }
        });
    }

    function mostrarValidacionEstado(response) {
        const container = $('#validacionEstado');
        container.show();

        let html = '<div class="alert alert-' + (response.success ? 'success' : 'danger') + '">';
        html += '<h6><i class="fas fa-' + (response.success ? 'check-circle' : 'exclamation-circle') + '"></i> ';
        html += response.success ? 'Validación exitosa' : 'Errores de validación';
        html += '</h6>';
        html += '<p>' + response.message + '</p>';

        if (response.errors && response.errors.length > 0) {
            html += '<ul class="mb-0">';
            response.errors.forEach(error => {
                html += '<li>' + error + '</li>';
            });
            html += '</ul>';
        }

        if (response.warnings && response.warnings.length > 0) {
            html += '<div class="mt-2"><strong>Advertencias:</strong><ul class="mb-0">';
            response.warnings.forEach(warning => {
                html += '<li>' + warning + '</li>';
            });
            html += '</ul></div>';
        }

        html += '</div>';
        container.html(html);
    }

    function confirmarCambioEstado() {
        if (!nuevoEstado || comprobantesSeleccionados.length === 0) {
            mostrarError('Debe seleccionar un estado y al menos un comprobante');
            return;
        }

        const estadoSeleccionado = estados.find(e => e.id == nuevoEstado);
        const mensaje = `Se cambiará el estado de ${comprobantesSeleccionados.length} comprobante(s) a "${estadoSeleccionado.nombre}".\n\n¿Desea continuar?`;
        $('#mensajeConfirmacion').text(mensaje);
        $('#modalConfirmar').modal('show');
    }

    function ejecutarCambioEstado() {
        $('#modalConfirmar').modal('hide');
        
        mostrarCargando('Cambiando estado...');
        $('#btnCambiarEstado').prop('disabled', true);
        $('#btnCancelar').prop('disabled', false).show();

        $.ajax({
            url: '/CambioEstado/CambiarEstado',
            type: 'POST',
            data: JSON.stringify({
                comprobantesIds: comprobantesSeleccionados,
                nuevoEstado: parseInt(nuevoEstado)
            }),
            contentType: 'application/json',
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                if (response.success) {
                    mostrarResultados(response);
                    mostrarExito('Estado cambiado exitosamente');
                    limpiarSeleccion();
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al cambiar estado');
            },
            complete: function() {
                ocultarCargando();
                $('#btnCambiarEstado').prop('disabled', false);
                $('#btnCancelar').prop('disabled', true).hide();
            }
        });
    }

    function mostrarResultados(response) {
        const container = $('#resultadosContainer');
        const resultados = $('#resultadosCambioEstado');
        
        let html = '<div class="row">';
        html += '<div class="col-md-3"><div class="card bg-success text-white"><div class="card-body text-center">';
        html += '<h4>' + response.comprobantesActualizados + '</h4><p>Comprobantes Actualizados</p></div></div></div>';
        html += '<div class="col-md-3"><div class="card bg-danger text-white"><div class="card-body text-center">';
        html += '<h4>' + response.comprobantesConError + '</h4><p>Con Errores</p></div></div></div>';
        html += '<div class="col-md-3"><div class="card bg-info text-white"><div class="card-body text-center">';
        html += '<h4>' + comprobantesSeleccionados.length + '</h4><p>Total Seleccionados</p></div></div></div>';
        html += '<div class="col-md-3"><div class="card bg-warning text-white"><div class="card-body text-center">';
        html += '<h4>' + Math.round((response.comprobantesActualizados / comprobantesSeleccionados.length) * 100) + '%</h4><p>Éxito</p></div></div></div>';
        html += '</div>';

        if (response.errores && response.errores.length > 0) {
            html += '<div class="mt-3"><h6>Errores encontrados:</h6><ul class="list-group">';
            response.errores.forEach(error => {
                html += '<li class="list-group-item">' + error + '</li>';
            });
            html += '</ul></div>';
        }

        resultados.html(html);
        container.show();
    }

    function cancelarCambioEstado() {
        mostrarInfo('Operación cancelada');
        $('#btnCambiarEstado').prop('disabled', false);
        $('#btnCancelar').prop('disabled', true).hide();
    }

    function validarPermisos() {
        if (comprobantesSeleccionados.length === 0) {
            mostrarError('Debe seleccionar al menos un comprobante');
            return;
        }

        mostrarCargando('Validando permisos...');

        $.ajax({
            url: '/CambioEstado/ValidarPermisos',
            type: 'POST',
            data: JSON.stringify({
                estado: parseInt(nuevoEstado),
                comprobantesIds: comprobantesSeleccionados
            }),
            contentType: 'application/json',
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                if (response.success) {
                    if (response.puedeCambiar) {
                        mostrarExito('Tiene permisos para realizar el cambio de estado');
                    } else {
                        mostrarError('No tiene permisos para realizar el cambio de estado');
                        if (response.restricciones && response.restricciones.length > 0) {
                            mostrarError('Restricciones: ' + response.restricciones.join(', '));
                        }
                    }
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al validar permisos');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function mostrarModalRevertir() {
        if (comprobantesSeleccionados.length === 0) {
            mostrarError('Debe seleccionar al menos un comprobante');
            return;
        }

        $('#modalRevertir').modal('show');
    }

    function ejecutarRevertir() {
        const estadoAnterior = $('#estadoAnterior').val();
        if (!estadoAnterior) {
            mostrarError('Debe seleccionar un estado anterior');
            return;
        }

        $('#modalRevertir').modal('hide');
        
        mostrarCargando('Revirtiendo cambio...');

        $.ajax({
            url: '/CambioEstado/RevertirCambio',
            type: 'POST',
            data: JSON.stringify({
                comprobantesIds: comprobantesSeleccionados,
                estadoAnterior: parseInt(estadoAnterior)
            }),
            contentType: 'application/json',
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                if (response.success) {
                    mostrarExito('Cambio revertido exitosamente');
                    mostrarResultados(response);
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al revertir cambio');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function aplicarFiltros() {
        const filtros = {
            tipo: $('#filtroTipo').val(),
            estadoActual: $('#filtroEstadoActual').val() ? parseInt($('#filtroEstadoActual').val()) : null,
            fechaDesde: $('#filtroFechaDesde').val() ? new Date($('#filtroFechaDesde').val()) : null,
            fechaHasta: $('#filtroFechaHasta').val() ? new Date($('#filtroFechaHasta').val()) : null,
            glosa: $('#filtroGlosa').val(),
            correlativo: $('#filtroCorrelativo').val()
        };

        mostrarCargando('Aplicando filtros...');

        $.ajax({
            url: '/CambioEstado/CambiarEstadoMasivo',
            type: 'POST',
            data: JSON.stringify({
                filtros: filtros,
                nuevoEstado: parseInt(nuevoEstado)
            }),
            contentType: 'application/json',
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                if (response.success) {
                    mostrarExito(`Se procesaron ${response.totalComprobantes} comprobantes`);
                    mostrarResultados(response);
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al aplicar filtros');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function limpiarFiltros() {
        $('#filtroTipo').val('');
        $('#filtroEstadoActual').val('');
        $('#filtroFechaDesde').val('');
        $('#filtroFechaHasta').val('');
        $('#filtroGlosa').val('');
        $('#filtroCorrelativo').val('');
    }

    function limpiarSeleccion() {
        comprobantesSeleccionados = [];
        $('#validacionEstado').hide();
        $('#resultadosContainer').hide();
        $('#infoComprobantes').hide();
    }

    function mostrarCargando(mensaje) {
        // Implementar indicador de carga
        console.log('Cargando: ' + mensaje);
    }

    function ocultarCargando() {
        // Ocultar indicador de carga
        console.log('Carga completada');
    }

    function mostrarError(mensaje) {
        toastr.error(mensaje);
    }

    function mostrarExito(mensaje) {
        toastr.success(mensaje);
    }

    function mostrarInfo(mensaje) {
        toastr.info(mensaje);
    }

    // Función para ser llamada desde el listado de comprobantes
    window.seleccionarComprobantes = function(ids) {
        comprobantesSeleccionados = ids;
        validarEstado();
        mostrarInfoComprobantes();
    };

    function mostrarInfoComprobantes() {
        if (comprobantesSeleccionados.length === 0) {
            $('#infoComprobantes').hide();
            return;
        }

        $('#infoComprobantes').show();
        
        $.ajax({
            url: '/CambioEstado/GetComprobantesInfo',
            type: 'GET',
            data: { comprobantesIds: comprobantesSeleccionados.join(',') },
            success: function(response) {
                if (response.success) {
                    mostrarListaComprobantes(response.comprobantes);
                }
            },
            error: function() {
                mostrarError('Error al obtener información de comprobantes');
            }
        });
    }

    function mostrarListaComprobantes(comprobantes) {
        let html = '<div class="table-responsive"><table class="table table-striped table-hover">';
        html += '<thead class="thead-dark">';
        html += '<tr><th>ID</th><th>Correlativo</th><th>Tipo</th><th>Estado Actual</th><th>Fecha</th><th>Glosa</th></tr>';
        html += '</thead><tbody>';

        comprobantes.forEach(function(comp) {
            const estadoClass = getEstadoClass(comp.estadoActual);
            html += '<tr>';
            html += '<td>' + comp.idComp + '</td>';
            html += '<td>' + comp.correlativo + '</td>';
            html += '<td><span class="badge badge-' + getTipoClass(comp.tipo) + '">' + comp.tipo + '</span></td>';
            html += '<td><span class="badge badge-' + estadoClass + '">' + comp.estadoActualNombre + '</span></td>';
            html += '<td>' + formatearFecha(comp.fecha) + '</td>';
            html += '<td>' + comp.glosa + '</td>';
            html += '</tr>';
        });

        html += '</tbody></table></div>';
        $('#listaComprobantes').html(html);
    }

    function getEstadoClass(estadoId) {
        const estado = estados.find(e => e.id == estadoId);
        return estado ? estado.color : 'secondary';
    }

    function getTipoClass(tipo) {
        switch(tipo) {
            case 'I': return 'success';
            case 'E': return 'danger';
            case 'T': return 'info';
            case 'A': return 'warning';
            default: return 'secondary';
        }
    }

    function formatearFecha(fecha) {
        return new Date(fecha).toLocaleDateString('es-CL');
    }
});

