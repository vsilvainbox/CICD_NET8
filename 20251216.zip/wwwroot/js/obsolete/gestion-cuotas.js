$(document).ready(function() {
    // Variables globales
    let cuotasSeleccionadas = [];
    let idDoc = null;
    
    // Inicialización
    inicializar();
    
    function inicializar() {
        idDoc = $('#IdDoc').val() || null;
        configurarEventos();
        configurarDataTable();
        actualizarTotales();
    }
    
    function configurarEventos() {
        // Botón generar cuotas
        $('#btnGenerarCuotas').click(function() {
            generarCuotas();
        });
        
        // Botón ver comprobante
        $('#btnVerComp').click(function() {
            if (idDoc) {
                window.open(`/Comprobantes/View/${idDoc}`, '_blank');
            }
        });
        
        // Botón ver libro caja
        $('#btnVerLibCaja').click(function() {
            if (idDoc) {
                window.open(`/LibroCaja/View/${idDoc}`, '_blank');
            }
        });
        
        // Botón eliminar cuota
        $('#btnEliminarCuota').click(function() {
            const id = obtenerCuotaSeleccionada();
            if (id) {
                eliminarCuota(id);
            }
        });
        
        // Botón sumar
        $('#btnSumar').click(function() {
            const ids = obtenerCuotasSeleccionadas();
            if (ids.length > 0) {
                sumarCuotas(ids);
            }
        });
        
        // Botón vista previa
        $('#btnPreview').click(function() {
            vistaPrevia();
        });
        
        // Botón imprimir
        $('#btnPrint').click(function() {
            imprimir();
        });
        
        // Botón exportar Excel
        $('#btnExportExcel').click(function() {
            exportarExcel();
        });
        
        // Botón exportar PDF
        $('#btnExportPDF').click(function() {
            exportarPDF();
        });
        
        // Botón calculadora
        $('#btnCalculadora').click(function() {
            abrirCalculadora();
        });
        
        // Botón convertir moneda
        $('#btnConvertirMoneda').click(function() {
            abrirConvertidorMoneda();
        });
        
        // Botón calendario
        $('#btnCalendario').click(function() {
            abrirCalendario();
        });
        
        // Checkbox select all
        $('#selectAll').change(function() {
            const isChecked = $(this).is(':checked');
            $('.cuota-checkbox').prop('checked', isChecked);
            actualizarSeleccion();
        });
        
        // Checkboxes individuales
        $(document).on('change', '.cuota-checkbox', function() {
            actualizarSeleccion();
        });
        
        // Click en fila para seleccionar
        $(document).on('click', 'tbody tr', function(e) {
            if (!$(e.target).is('input, button, a')) {
                const checkbox = $(this).find('.cuota-checkbox');
                checkbox.prop('checked', !checkbox.prop('checked'));
                actualizarSeleccion();
            }
        });
        
        // Botones de acción en fila
        $(document).on('click', '.btn-editar', function(e) {
            e.stopPropagation();
            const id = $(this).closest('tr').data('id');
            editarCuota(id);
        });
        
        $(document).on('click', '.btn-marcar-pagada', function(e) {
            e.stopPropagation();
            const id = $(this).closest('tr').data('id');
            marcarComoPagada(id);
        });
        
        $(document).on('click', '.btn-desmarcar-pagada', function(e) {
            e.stopPropagation();
            const id = $(this).closest('tr').data('id');
            desmarcarComoPagada(id);
        });
        
        // Botón guardar cuota
        $('#btnGuardarCuota').click(function() {
            guardarCuota();
        });
        
        // Botón marcar como pagada
        $('#btnMarcarPagada').click(function() {
            confirmarMarcarPagada();
        });
        
        // Botón fecha inicio
        $('#btnFechaInicio').click(function() {
            abrirCalendario();
        });
    }
    
    function configurarDataTable() {
        $('#gridCuotas').DataTable({
            responsive: true,
            pageLength: 25,
            lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
            order: [[1, 'asc']], // Ordenar por número de cuota
            columnDefs: [
                { orderable: false, targets: [0, 10] }, // Columnas no ordenables
                { className: 'text-center', targets: [0, 1, 8] },
                { className: 'text-right', targets: [3, 4] }
            ],
            language: {
                url: '//cdn.datatables.net/plug-ins/1.10.24/i18n/Spanish.json'
            }
        });
    }
    
    function generarCuotas() {
        const datos = {
            IdDoc: idDoc,
            NumCuotas: parseInt($('#NumCuotas').val()),
            FInicio: $('#FInicio').val(),
            EliminarExistentes: $('#EliminarExistentes').is(':checked')
        };
        
        if (!datos.NumCuotas || datos.NumCuotas <= 0) {
            mostrarError('El número de cuotas debe ser mayor a cero');
            return;
        }
        
        if (!datos.FInicio) {
            mostrarError('Debe seleccionar una fecha de primera cuota');
            return;
        }
        
        $.ajax({
            url: '/GestionCuotas/GenerarCuotas',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(datos),
            success: function(response) {
                if (response.success) {
                    mostrarExito(response.message);
                    actualizarGrid(response.cuotas);
                    actualizarTotales(response.totales);
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al generar cuotas');
            }
        });
    }
    
    function editarCuota(id) {
        const fila = $(`tr[data-id="${id}"]`);
        const numCuota = fila.find('td:eq(1)').text();
        const fechaVenc = fila.find('td:eq(2)').text();
        const valor = fila.find('td:eq(3)').text().replace(/[$,]/g, '');
        const observaciones = fila.find('td:eq(9)').text();
        
        $('#IdDocCuota').val(id);
        $('#FVenc').val(convertirFecha(fechaVenc));
        $('#Valor').val(valor);
        $('#Observaciones').val(observaciones);
        
        $('#modalEditarCuota').modal('show');
    }
    
    function guardarCuota() {
        const datos = {
            IdDocCuota: parseInt($('#IdDocCuota').val()),
            FVenc: $('#FVenc').val(),
            Valor: parseFloat($('#Valor').val()),
            Observaciones: $('#Observaciones').val()
        };
        
        if (!datos.Valor || datos.Valor <= 0) {
            mostrarError('El valor debe ser mayor a cero');
            return;
        }
        
        $.ajax({
            url: '/GestionCuotas/EditarCuota',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(datos),
            success: function(response) {
                if (response.success) {
                    mostrarExito(response.message);
                    $('#modalEditarCuota').modal('hide');
                    actualizarGrid();
                    actualizarTotales(response.totales);
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al editar cuota');
            }
        });
    }
    
    function eliminarCuota(id) {
        if (confirm('¿Está seguro de que desea eliminar esta cuota?')) {
            $.ajax({
                url: '/GestionCuotas/EliminarCuota',
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ IdDocCuota: id }),
                success: function(response) {
                    if (response.success) {
                        mostrarExito(response.message);
                        actualizarGrid();
                        actualizarTotales(response.totales);
                    } else {
                        mostrarError(response.message);
                    }
                },
                error: function() {
                    mostrarError('Error al eliminar cuota');
                }
            });
        }
    }
    
    function marcarComoPagada(id) {
        $('#IdDocCuotaPagada').val(id);
        $('#FIngresoPercibido').val(new Date().toISOString().split('T')[0]);
        $('#ObservacionesPagada').val('');
        
        $('#modalMarcarPagada').modal('show');
    }
    
    function confirmarMarcarPagada() {
        const datos = {
            IdDocCuota: parseInt($('#IdDocCuotaPagada').val()),
            FIngresoPercibido: $('#FIngresoPercibido').val(),
            Observaciones: $('#ObservacionesPagada').val()
        };
        
        $.ajax({
            url: '/GestionCuotas/MarcarComoPagada',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(datos),
            success: function(response) {
                if (response.success) {
                    mostrarExito(response.message);
                    $('#modalMarcarPagada').modal('hide');
                    actualizarGrid();
                    actualizarTotales();
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al marcar cuota como pagada');
            }
        });
    }
    
    function desmarcarComoPagada(id) {
        if (confirm('¿Está seguro de que desea desmarcar esta cuota como pagada?')) {
            $.ajax({
                url: '/GestionCuotas/DesmarcarComoPagada',
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ IdDocCuota: id }),
                success: function(response) {
                    if (response.success) {
                        mostrarExito(response.message);
                        actualizarGrid();
                        actualizarTotales();
                    } else {
                        mostrarError(response.message);
                    }
                },
                error: function() {
                    mostrarError('Error al desmarcar cuota como pagada');
                }
            });
        }
    }
    
    function sumarCuotas(ids) {
        $.ajax({
            url: '/GestionCuotas/SumarSeleccionados',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ IdsCuotas: ids }),
            success: function(response) {
                if (response.success) {
                    mostrarModalSuma(response);
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al sumar cuotas');
            }
        });
    }
    
    function mostrarModalSuma(suma) {
        const contenido = `
            <div class="row">
                <div class="col-md-6">
                    <h6>Resumen de la Suma</h6>
                    <table class="table table-sm">
                        <tr><td><strong>Total Valor:</strong></td><td class="text-right">${formatearMoneda(suma.total)}</td></tr>
                        <tr><td><strong>Total Saldo Pendiente:</strong></td><td class="text-right">${formatearMoneda(suma.saldoPendiente)}</td></tr>
                        <tr><td><strong>Cantidad de Cuotas:</strong></td><td class="text-right">${suma.cantidad}</td></tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <h6>Desglose por Cuota</h6>
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>N° Cuota</th>
                                <th class="text-right">Cantidad</th>
                                <th class="text-right">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${suma.desglose.map(item => `
                                <tr>
                                    <td>${item.numCuota}</td>
                                    <td class="text-right">${item.cantidad}</td>
                                    <td class="text-right">${formatearMoneda(item.total)}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
        
        $('#modalSumaBody').html(contenido);
        $('#modalSuma').modal('show');
    }
    
    function vistaPrevia() {
        if (!idDoc) {
            mostrarError('No hay documento seleccionado');
            return;
        }
        
        $.ajax({
            url: '/GestionCuotas/Print',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ IdDoc: idDoc }),
            success: function(response) {
                if (response.success) {
                    const ventana = window.open('', '_blank');
                    ventana.document.write(generarHTMLImpresion(response.data));
                    ventana.document.close();
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al generar vista previa');
            }
        });
    }
    
    function imprimir() {
        if (!idDoc) {
            mostrarError('No hay documento seleccionado');
            return;
        }
        
        $.ajax({
            url: '/GestionCuotas/Print',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ IdDoc: idDoc }),
            success: function(response) {
                if (response.success) {
                    const ventana = window.open('', '_blank');
                    ventana.document.write(generarHTMLImpresion(response.data));
                    ventana.document.close();
                    ventana.print();
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al generar datos para impresión');
            }
        });
    }
    
    function exportarExcel() {
        if (!idDoc) {
            mostrarError('No hay documento seleccionado');
            return;
        }
        
        $.ajax({
            url: '/GestionCuotas/ExportExcel',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ IdDoc: idDoc }),
            success: function(response) {
                if (response.success) {
                    // Descargar archivo
                    const link = document.createElement('a');
                    link.href = response.url;
                    link.download = response.filename;
                    link.click();
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al exportar a Excel');
            }
        });
    }
    
    function exportarPDF() {
        if (!idDoc) {
            mostrarError('No hay documento seleccionado');
            return;
        }
        
        $.ajax({
            url: '/GestionCuotas/ExportPDF',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ IdDoc: idDoc }),
            success: function(response) {
                if (response.success) {
                    // Descargar archivo
                    const link = document.createElement('a');
                    link.href = response.url;
                    link.download = response.filename;
                    link.click();
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al exportar a PDF');
            }
        });
    }
    
    function generarHTMLImpresion(data) {
        return `
            <!DOCTYPE html>
            <html>
            <head>
                <title>${data.titulo}</title>
                <style>
                    body { font-family: Arial, sans-serif; font-size: 12px; }
                    table { width: 100%; border-collapse: collapse; }
                    th, td { border: 1px solid #000; padding: 4px; text-align: left; }
                    th { background-color: #f0f0f0; font-weight: bold; }
                    .text-right { text-align: right; }
                    .text-center { text-align: center; }
                </style>
            </head>
            <body>
                <h2>${data.titulo}</h2>
                <p>Fecha de generación: ${formatearFecha(data.fechaGeneracion)}</p>
                <p>Total de cuotas: ${data.totalCuotas}</p>
                <p>Total valor: ${formatearMoneda(data.totalValor)}</p>
                <table>
                    <thead>
                        <tr>
                            <th>N° Cuota</th>
                            <th>Fecha Vencimiento</th>
                            <th>Valor</th>
                            <th>Saldo Pendiente</th>
                            <th>Fecha Ingreso</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${data.cuotas.map(cuota => `
                            <tr>
                                <td>${cuota.numCuota}</td>
                                <td>${formatearFecha(cuota.fVenc)}</td>
                                <td class="text-right">${formatearMoneda(cuota.valor)}</td>
                                <td class="text-right">${formatearMoneda(cuota.saldoPendiente)}</td>
                                <td>${cuota.fIngresoPercibido ? formatearFecha(cuota.fIngresoPercibido) : ''}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </body>
            </html>
        `;
    }
    
    function abrirCalculadora() {
        // Implementar calculadora
        console.log('Abrir calculadora');
    }
    
    function abrirConvertidorMoneda() {
        // Implementar convertidor de moneda
        console.log('Abrir convertidor de moneda');
    }
    
    function abrirCalendario() {
        // Implementar calendario
        console.log('Abrir calendario');
    }
    
    function actualizarSeleccion() {
        const seleccionados = $('.cuota-checkbox:checked').length;
        const total = $('.cuota-checkbox').length;
        
        $('#btnEliminarCuota').prop('disabled', seleccionados !== 1);
        $('#btnSumar').prop('disabled', seleccionados === 0);
        
        if (seleccionados === total) {
            $('#selectAll').prop('indeterminate', false).prop('checked', true);
        } else if (seleccionados === 0) {
            $('#selectAll').prop('indeterminate', false).prop('checked', false);
        } else {
            $('#selectAll').prop('indeterminate', true);
        }
    }
    
    function obtenerCuotaSeleccionada() {
        const checkbox = $('.cuota-checkbox:checked').first();
        return checkbox.length ? parseInt(checkbox.val()) : null;
    }
    
    function obtenerCuotasSeleccionadas() {
        return $('.cuota-checkbox:checked').map(function() {
            return parseInt($(this).val());
        }).get();
    }
    
    function actualizarGrid(cuotas = null) {
        if (cuotas) {
            const tbody = $('#gridCuotas tbody');
            tbody.empty();
            
            cuotas.forEach(function(cuota) {
                const fila = `
                    <tr data-id="${cuota.idDocCuota}">
                        <td>
                            <input type="checkbox" class="form-check-input cuota-checkbox" value="${cuota.idDocCuota}">
                        </td>
                        <td>${cuota.numCuota}</td>
                        <td>${formatearFecha(cuota.fVenc)}</td>
                        <td class="text-right">${formatearMoneda(cuota.valor)}</td>
                        <td class="text-right">${formatearMoneda(cuota.saldoPendiente)}</td>
                        <td>${cuota.fIngresoPercibido ? formatearFecha(cuota.fIngresoPercibido) : ''}</td>
                        <td>${cuota.compPago || ''}</td>
                        <td>${cuota.libCaja || ''}</td>
                        <td>
                            <span class="badge badge-${cuota.saldoPendiente == 0 ? 'success' : 'warning'}">
                                ${cuota.saldoPendiente == 0 ? 'Pagada' : 'Pendiente'}
                            </span>
                        </td>
                        <td>${cuota.observaciones || ''}</td>
                        <td>
                            <div class="btn-group btn-group-sm">
                                <button type="button" class="btn btn-info btn-sm btn-editar" title="Editar cuota">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button type="button" class="btn btn-success btn-sm btn-marcar-pagada" title="Marcar como pagada" 
                                        ${cuota.saldoPendiente == 0 ? 'disabled' : ''}>
                                    <i class="fas fa-check"></i>
                                </button>
                                <button type="button" class="btn btn-warning btn-sm btn-desmarcar-pagada" title="Desmarcar como pagada" 
                                        ${cuota.saldoPendiente > 0 ? 'disabled' : ''}>
                                    <i class="fas fa-undo"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                `;
                tbody.append(fila);
            });
        }
        
        $('#totalCuotas').text(`${$('.cuota-checkbox').length} cuotas`);
    }
    
    function actualizarTotales(totales = null) {
        if (totales) {
            $('#totalCuotasEst').text(totales.totalCuotas);
            $('#totalValorEst').text(formatearMoneda(totales.totalValor));
            $('#totalSaldoEst').text(formatearMoneda(totales.totalSaldoPendiente));
            $('#cuotasPagadasEst').text(totales.cuotasPagadas);
            $('#cuotasPendientesEst').text(totales.cuotasPendientes);
            $('#porcentajePagadoEst').text(totales.porcentajePagado.toFixed(1) + '%');
        }
    }
    
    function convertirFecha(fecha) {
        if (!fecha) return '';
        const partes = fecha.split('/');
        if (partes.length === 3) {
            return `${partes[2]}-${partes[1].padStart(2, '0')}-${partes[0].padStart(2, '0')}`;
        }
        return fecha;
    }
    
    function formatearFecha(fecha) {
        if (!fecha) return '';
        const date = new Date(fecha);
        return date.toLocaleDateString('es-CL');
    }
    
    function formatearMoneda(valor) {
        if (!valor) return '$0';
        return new Intl.NumberFormat('es-CL', {
            style: 'currency',
            currency: 'CLP',
            minimumFractionDigits: 0
        }).format(valor);
    }
    
    function mostrarExito(mensaje) {
        toastr.success(mensaje);
    }
    
    function mostrarError(mensaje) {
        toastr.error(mensaje);
    }
    
    function mostrarInfo(mensaje) {
        toastr.info(mensaje);
    }
});









