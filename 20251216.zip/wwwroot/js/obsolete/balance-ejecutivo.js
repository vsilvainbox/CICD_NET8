$(document).ready(function() {
    // Inicializar DataTable si existe
    if ($.fn.DataTable) {
        $('#balanceTable').DataTable({
            "paging": false,
            "searching": false,
            "ordering": false,
            "info": false,
            "responsive": true,
            "scrollX": true,
            "scrollY": "600px",
            "scrollCollapse": true,
            "fixedColumns": {
                leftColumns: 3
            }
        });
    }

    // Manejar envío del formulario
    $('#filtrosForm').on('submit', function(e) {
        e.preventDefault();
        cargarBalance();
    });

    // Botón Listar
    $('#btnListar').on('click', function() {
        cargarBalance();
    });

    // Botón Exportar Excel
    $('#btnExportExcel').on('click', function() {
        exportarExcel();
    });

    // Botón Vista Previa
    $('#btnPreview').on('click', function() {
        vistaPrevia();
    });

    // Botón Imprimir
    $('#btnPrint').on('click', function() {
        imprimir();
    });

    // Botón Email
    $('#btnEmail').on('click', function() {
        mostrarModalEmail();
    });

    // Botón Libro Mayor
    $('#btnLibroMayor').on('click', function() {
        mostrarModalLibroMayor();
    });

    // Botón Sumar
    $('#btnSumar').on('click', function() {
        mostrarModalSumar();
    });

    // Botones de fecha
    $('#btnFechaDesde').on('click', function() {
        mostrarCalendario('FechaDesde');
    });

    $('#btnFechaHasta').on('click', function() {
        mostrarCalendario('FechaHasta');
    });

    // Cambios en filtros
    $('#TipoAjuste, #Nivel, #AreaNegocio, #CentroCosto, #LibroOficial, #SaldosVigentes, #VerCodigoCuenta').on('change', function() {
        // Habilitar botón de búsqueda
        $('#btnListar').prop('disabled', false);
    });

    // Doble clic en filas de la tabla
    $('#balanceTable tbody').on('dblclick', 'tr', function() {
        var idCuenta = $(this).data('id-cuenta');
        if (idCuenta) {
            abrirLibroMayor(idCuenta);
        }
    });

    // Selección de filas para sumar
    $('#balanceTable tbody').on('click', 'tr', function() {
        $(this).toggleClass('table-warning');
        actualizarSuma();
    });

    // Enviar email
    $('#btnEnviarEmail').on('click', function() {
        enviarEmail();
    });

    // Función para cargar balance
    function cargarBalance() {
        var formData = {
            FechaDesde: $('#FechaDesde').val(),
            FechaHasta: $('#FechaHasta').val(),
            IdAreaNegocio: $('#AreaNegocio').val() || null,
            IdCentroCosto: $('#CentroCosto').val() || null,
            Nivel: $('#Nivel').val() || null,
            TipoAjuste: $('#TipoAjuste').val() || null,
            LibroOficial: $('#LibroOficial').is(':checked'),
            SaldosVigentes: $('#SaldosVigentes').is(':checked'),
            VerCodigoCuenta: $('#VerCodigoCuenta').is(':checked')
        };

        // Validar fechas
        if (!validarFechas(formData.FechaDesde, formData.FechaHasta)) {
            return;
        }

        // Mostrar loading
        mostrarLoading();

        $.ajax({
            url: '/BalanceEjecutivo/GetBalanceData',
            type: 'GET',
            data: formData,
            success: function(response) {
                if (response.success) {
                    mostrarBalance(response.data);
                } else {
                    mostrarError(response.message);
                }
            },
            error: function(xhr, status, error) {
                mostrarError('Error al cargar el balance: ' + error);
            },
            complete: function() {
                ocultarLoading();
            }
        });
    }

    // Función para validar fechas
    function validarFechas(fechaDesde, fechaHasta) {
        if (!fechaDesde || !fechaHasta) {
            mostrarError('Debe seleccionar las fechas de inicio y término');
            return false;
        }

        var desde = new Date(fechaDesde);
        var hasta = new Date(fechaHasta);

        if (desde > hasta) {
            mostrarError('La fecha de inicio no puede ser posterior a la fecha de término');
            return false;
        }

        // Validar que las fechas correspondan al año actual
        var añoActual = new Date().getFullYear();
        if (desde.getFullYear() !== añoActual || hasta.getFullYear() !== añoActual) {
            mostrarError('Las fechas deben corresponder al año actual de la empresa');
            return false;
        }

        return true;
    }

    // Función para mostrar balance
    function mostrarBalance(data) {
        // Limpiar tabla existente
        $('#balanceTable tbody').empty();

        // Construir filas de activos y pasivos
        var maxRows = Math.max(data.activos.length, data.pasivos.length);
        
        for (var i = 0; i < maxRows; i++) {
            var row = '<tr>';
            
            // Activos
            if (i < data.activos.length) {
                var activo = data.activos[i];
                row += '<td>' + (activo.codigoCuenta || '') + '</td>';
                row += '<td>' + (activo.indentacion || '') + activo.nombreCuenta + '</td>';
                row += '<td class="text-end">' + formatearNumero(activo.saldo) + '</td>';
            } else {
                row += '<td></td><td></td><td></td>';
            }
            
            // Pasivos
            if (i < data.pasivos.length) {
                var pasivo = data.pasivos[i];
                row += '<td>' + (pasivo.codigoCuenta || '') + '</td>';
                row += '<td>' + (pasivo.indentacion || '') + pasivo.nombreCuenta + '</td>';
                row += '<td class="text-end">' + formatearNumero(pasivo.saldo) + '</td>';
            } else {
                row += '<td></td><td></td><td></td>';
            }
            
            row += '</tr>';
            $('#balanceTable tbody').append(row);
        }

        // Agregar totales
        var totalesRow = '<tr class="table-primary">' +
            '<td colspan="2" class="fw-bold">TOTAL ACTIVOS</td>' +
            '<td class="text-end fw-bold">' + formatearNumero(data.totales.totalActivos) + '</td>' +
            '<td colspan="2" class="fw-bold">TOTAL PASIVOS</td>' +
            '<td class="text-end fw-bold">' + formatearNumero(data.totales.totalPasivos) + '</td>' +
            '</tr>';
        $('#balanceTable tbody').append(totalesRow);

        var resultadoRow = '<tr class="table-success">' +
            '<td colspan="2" class="fw-bold">RESULTADO DEL EJERCICIO</td>' +
            '<td class="text-end fw-bold">' + formatearNumero(data.totales.resultadoEjercicio) + '</td>' +
            '<td colspan="2" class="fw-bold">TOTAL PATRIMONIO</td>' +
            '<td class="text-end fw-bold">' + formatearNumero(data.totales.totalPatrimonio) + '</td>' +
            '</tr>';
        $('#balanceTable tbody').append(resultadoRow);

        // Mostrar tabla
        $('#balanceTable').show();
    }

    // Función para exportar a Excel
    function exportarExcel() {
        var formData = obtenerFiltros();
        
        $.ajax({
            url: '/BalanceEjecutivo/ExportToExcel',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(formData),
            success: function(response) {
                if (response.success) {
                    // Descargar archivo
                    var blob = new Blob([response.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                    var url = window.URL.createObjectURL(blob);
                    var a = document.createElement('a');
                    a.href = url;
                    a.download = 'BalanceEjecutivo_' + formData.FechaDesde + '_' + formData.FechaHasta + '.xlsx';
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    window.URL.revokeObjectURL(url);
                } else {
                    mostrarError(response.message);
                }
            },
            error: function(xhr, status, error) {
                mostrarError('Error al exportar: ' + error);
            }
        });
    }

    // Función para vista previa
    function vistaPrevia() {
        var formData = obtenerFiltros();
        
        $.ajax({
            url: '/BalanceEjecutivo/GetPrintPreviewData',
            type: 'GET',
            data: formData,
            success: function(response) {
                if (response.success) {
                    mostrarVistaPrevia(response.data);
                } else {
                    mostrarError(response.message);
                }
            },
            error: function(xhr, status, error) {
                mostrarError('Error al generar vista previa: ' + error);
            }
        });
    }

    // Función para imprimir
    function imprimir() {
        window.print();
    }

    // Función para mostrar modal de email
    function mostrarModalEmail() {
        $('#emailModal').modal('show');
    }

    // Función para enviar email
    function enviarEmail() {
        var email = $('#emailDestino').val();
        var asunto = $('#emailAsunto').val();
        var mensaje = $('#emailMensaje').val();

        if (!email) {
            mostrarError('Debe ingresar un email destino');
            return;
        }

        var formData = obtenerFiltros();
        formData.Email = email;
        formData.Subject = asunto;
        formData.Body = mensaje;

        $.ajax({
            url: '/BalanceEjecutivo/SendEmail',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(formData),
            success: function(response) {
                if (response.success) {
                    mostrarExito(response.message);
                    $('#emailModal').modal('hide');
                } else {
                    mostrarError(response.message);
                }
            },
            error: function(xhr, status, error) {
                mostrarError('Error al enviar email: ' + error);
            }
        });
    }

    // Función para mostrar modal de libro mayor
    function mostrarModalLibroMayor() {
        $('#libroMayorModal').modal('show');
    }

    // Función para abrir libro mayor
    function abrirLibroMayor(idCuenta) {
        var formData = obtenerFiltros();
        
        $.ajax({
            url: '/BalanceEjecutivo/GetLibroMayorUrl',
            type: 'GET',
            data: {
                idCuenta: idCuenta,
                fechaDesde: formData.FechaDesde,
                fechaHasta: formData.FechaHasta,
                tipoAjuste: formData.TipoAjuste
            },
            success: function(response) {
                if (response.success) {
                    window.open(response.url, '_blank');
                } else {
                    mostrarError(response.message);
                }
            },
            error: function(xhr, status, error) {
                mostrarError('Error al abrir libro mayor: ' + error);
            }
        });
    }

    // Función para mostrar modal de sumar
    function mostrarModalSumar() {
        $('#sumarModal').modal('show');
    }

    // Función para actualizar suma
    function actualizarSuma() {
        var total = 0;
        $('#balanceTable tbody tr.table-warning').each(function() {
            var saldo = parseFloat($(this).find('td:eq(2)').text().replace(/,/g, '')) || 0;
            total += saldo;
        });
        
        $('#sumarTotal').text(formatearNumero(total));
        $('#sumarResultado').show();
    }

    // Función para mostrar calendario
    function mostrarCalendario(campo) {
        // Implementar calendario si es necesario
        $('#' + campo).focus();
    }

    // Función para obtener filtros
    function obtenerFiltros() {
        return {
            FechaDesde: $('#FechaDesde').val(),
            FechaHasta: $('#FechaHasta').val(),
            IdAreaNegocio: $('#AreaNegocio').val() || null,
            IdCentroCosto: $('#CentroCosto').val() || null,
            Nivel: $('#Nivel').val() || null,
            TipoAjuste: $('#TipoAjuste').val() || null,
            LibroOficial: $('#LibroOficial').is(':checked'),
            SaldosVigentes: $('#SaldosVigentes').is(':checked'),
            VerCodigoCuenta: $('#VerCodigoCuenta').is(':checked')
        };
    }

    // Función para formatear números
    function formatearNumero(numero) {
        return parseFloat(numero || 0).toLocaleString('es-CL', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }

    // Función para mostrar loading
    function mostrarLoading() {
        $('#btnListar').prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Cargando...');
    }

    // Función para ocultar loading
    function ocultarLoading() {
        $('#btnListar').prop('disabled', false).html('<i class="fas fa-search me-2"></i>Listar');
    }

    // Función para mostrar error
    function mostrarError(mensaje) {
        toastr.error(mensaje);
    }

    // Función para mostrar éxito
    function mostrarExito(mensaje) {
        toastr.success(mensaje);
    }

    // Función para mostrar vista previa
    function mostrarVistaPrevia(data) {
        // Implementar vista previa de impresión
        var ventana = window.open('', '_blank', 'width=800,height=600');
        var contenido = '<html><head><title>' + data.titulo + '</title></head><body>';
        contenido += '<h1>' + data.titulo + '</h1>';
        contenido += '<p>' + data.periodo + '</p>';
        contenido += '<p>' + data.empresa + '</p>';
        contenido += '<table border="1" style="width:100%; border-collapse: collapse;">';
        contenido += '<tr><th colspan="3">ACTIVOS</th><th colspan="3">PASIVOS</th></tr>';
        contenido += '<tr><th>Código</th><th>Cuenta</th><th>Saldo</th><th>Código</th><th>Cuenta</th><th>Saldo</th></tr>';
        
        // Agregar filas de datos
        var maxRows = Math.max(data.activos.length, data.pasivos.length);
        for (var i = 0; i < maxRows; i++) {
            contenido += '<tr>';
            
            // Activos
            if (i < data.activos.length) {
                contenido += '<td>' + (data.activos[i].codigoCuenta || '') + '</td>';
                contenido += '<td>' + (data.activos[i].indentacion || '') + data.activos[i].nombreCuenta + '</td>';
                contenido += '<td>' + formatearNumero(data.activos[i].saldo) + '</td>';
            } else {
                contenido += '<td></td><td></td><td></td>';
            }
            
            // Pasivos
            if (i < data.pasivos.length) {
                contenido += '<td>' + (data.pasivos[i].codigoCuenta || '') + '</td>';
                contenido += '<td>' + (data.pasivos[i].indentacion || '') + data.pasivos[i].nombreCuenta + '</td>';
                contenido += '<td>' + formatearNumero(data.pasivos[i].saldo) + '</td>';
            } else {
                contenido += '<td></td><td></td><td></td>';
            }
            
            contenido += '</tr>';
        }
        
        contenido += '</table>';
        contenido += '</body></html>';
        
        ventana.document.write(contenido);
        ventana.document.close();
    }
});









