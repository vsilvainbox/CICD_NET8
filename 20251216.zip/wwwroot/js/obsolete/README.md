# 📦 Archivos JavaScript Obsoletos

## 📋 Resumen

Esta carpeta contiene archivos JavaScript que **ya no se utilizan** en la aplicación.

**Fecha de Migración**: 2024-10-23  
**Razón**: Migración completa a `@Url.Action()` en vistas Razor

## 🎯 ¿Por Qué Están Aquí?

Todos estos archivos fueron reemplazados por JavaScript inline en las vistas `.cshtml` usando `@Url.Action()` para generar URLs correctas.

### Antes (Archivos Externos)
```javascript
// En wwwroot/js/listar-comprobantes.js
$.ajax({
    url: '/ListarComprobantes/Search',  // ❌ Ruta hardcodeada
    type: 'POST'
});
```

### Después (Inline en Vista)
```html
<!-- En ListarComprobantes/Index.cshtml -->
@section Scripts {
<script>
    const URL_ENDPOINTS = {
        search: '@Url.Action("Search", "ListarComprobantes")'  // ✅ Razor genera la ruta
    };
    
    $.ajax({
        url: URL_ENDPOINTS.search,  // ✅ Usa variable con ruta correcta
        type: 'POST'
    });
</script>
}
```

## 📁 Archivos en Esta Carpeta

### Archivos de Libros Contables
- `libro-diario.js` - Reemplazado por `LibroDiario/Index.cshtml`
- `libro-mayor.js` - Reemplazado por `LibroMayor/Index.cshtml`
- `libro-caja.js` - Reemplazado por vista correspondiente
- `libro-retenciones.js` - Reemplazado por vista correspondiente
- `libro-electronico-compras.js` - Reemplazado por vista correspondiente
- `libro-inventario-balance.js` - Reemplazado por vista correspondiente
- `libro-ingresos-egresos.js` - Reemplazado por vista correspondiente

### Archivos de Comprobantes
- `nuevo-comprobante.js` - Reemplazado por `NuevoComprobante/Index.cshtml`
- `listar-comprobantes.js` - Reemplazado por `ListarComprobantes/Index.cshtml`
- `listar-por-tipo.js` - Reemplazado por `ListarPorTipo/Index.cshtml`
- `renumerar-comprobantes.js` - Reemplazado por vista correspondiente
- `importar-comprobantes.js` - Reemplazado por vista correspondiente
- `cambio-estado.js` - Reemplazado por vista correspondiente

### Archivos de Documentos
- `documentos-libros.js` - Reemplazado por `DocumentosLibros/Index.cshtml`
- `documentos-libros-form.js` - Reemplazado por vista correspondiente
- `listado-documentos.js` - Reemplazado por `ListadoDocumentos/Index.cshtml`
- `importar-otros-docs.js` - Reemplazado por vista correspondiente
- `importar-otros-docs-completa.js` - Reemplazado por vista correspondiente
- `traspaso-od-to-odf.js` - Reemplazado por vista correspondiente

### Archivos de Balances y Reportes
- `balance-clasificado.js` - Reemplazado por vista correspondiente
- `balance-comparativo.js` - Reemplazado por vista correspondiente
- `balance-comprobacion.js` - Reemplazado por vista correspondiente
- `balance-desglosado.js` - Reemplazado por vista correspondiente
- `balance-ejecutivo.js` - Reemplazado por vista correspondiente
- `balance-tributario.js` - Reemplazado por vista correspondiente
- `balance-tributario-ifrs.js` - Reemplazado por vista correspondiente
- `ReporteActivoFijo.js` - Reemplazado por vista correspondiente
- `DetalleBaseImponible14D.js` - Reemplazado por vista correspondiente

### Archivos de Selección y Gestión
- `seleccion-libros.js` - Reemplazado por vista correspondiente
- `seleccion-libro-caja.js` - Reemplazado por vista correspondiente
- `seleccion-libros-docs.js` - Reemplazado por vista correspondiente
- `seleccion-libro-14ter.js` - Reemplazado por vista correspondiente
- `seleccion-tipo.js` - Reemplazado por vista correspondiente
- `seleccion-importacion-od.js` - Reemplazado por vista correspondiente
- `selector-comprobante-tipo.js` - Reemplazado por vista correspondiente
- `gestion-cuotas.js` - Reemplazado por vista correspondiente
- `listado-cuotas.js` - Reemplazado por vista correspondiente

### Archivos de Seguimiento
- `seguimiento-cambios.js` - Reemplazado por vista correspondiente
- `seguimiento-movimientos.js` - Reemplazado por vista correspondiente

### Archivos de Importación
- `importar-empresa.js` - Reemplazado por vista correspondiente

## ✅ Archivos Activos (NO Obsoletos)

Los siguientes archivos **SÍ se siguen usando** y están en `wwwroot/js/`:

1. **modales-tailwind.js** - Componente reutilizable para modales (sin rutas hardcodeadas)
2. **suma-movimientos.js** - Componente reutilizable para suma de movimientos (sin rutas hardcodeadas)
3. **mensaje-sincronizacion.js** - Componente reutilizable para mensajes de sincronización (configurado desde vistas)
4. **site.js** - Archivo estándar de ASP.NET Core

## 🗑️ ¿Se Pueden Eliminar?

**Recomendación**: Mantener estos archivos por 3-6 meses como backup.

Después de ese período, si no se han necesitado, se pueden eliminar permanentemente.

## 📊 Estadísticas

| Métrica | Valor |
|---------|-------|
| **Total de archivos obsoletos** | 34 |
| **Líneas de código obsoletas** | ~15,000 |
| **Archivos activos restantes** | 4 |
| **Reducción de archivos** | 89% |

## 🎉 Beneficios de la Migración

1. ✅ **Rutas nativas de ASP.NET Core** - Todas las URLs usan `@Url.Action()`
2. ✅ **Funciona en cualquier subdirectorio** - PathBase automático
3. ✅ **Más mantenible** - Todo el código en las vistas
4. ✅ **Type-safe** - Errores detectados en compile-time
5. ✅ **Sin monkey-patching** - No más código "mágico"

## 📝 Notas

- Todos estos archivos tenían rutas hardcodeadas como `/Controller/Action`
- Fueron reemplazados por JavaScript inline en vistas usando `@Url.Action()`
- El monkey-patching en `_Layout.cshtml` fue eliminado (ya no es necesario)
- La aplicación ahora funciona correctamente en cualquier ruta sin configuración adicional

---

**Última Actualización**: 2024-10-23  
**Migrado por**: Claude Code  
**Estado**: ✅ Migración Completada

