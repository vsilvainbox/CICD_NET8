$(document).ready(function() {
    let balanceData = null;
    let selectedRow = null;

    // Inicializar DataTable
    const table = $('#gridBalance').DataTable({
        paging: false,
        searching: false,
        ordering: false,
        info: false,
        scrollY: '400px',
        scrollCollapse: true,
        columns: [
            { data: 'codigo', title: 'Código', className: 'text-start' },
            { data: 'cuenta', title: 'Cuentas', className: 'text-start' },
            { data: 'debitos', title: 'Débitos', className: 'text-end', render: formatNumber },
            { data: 'creditos', title: 'Créditos', className: 'text-end', render: formatNumber },
            { data: 'saldoDeudor', title: 'Deudor', className: 'text-end', render: formatNumber },
            { data: 'saldoAcreedor', title: 'Acreedor', className: 'text-end', render: formatNumber },
            { data: 'inventarioActivo', title: 'Inventario Activo', className: 'text-end', render: formatNumber },
            { data: 'inventarioPasivo', title: 'Inventario Pasivo', className: 'text-end', render: formatNumber },
            { data: 'perdida', title: 'Pérdida', className: 'text-end', render: formatNumber },
            { data: 'ganancia', title: 'Ganancia', className: 'text-end', render: formatNumber }
        ],
        select: {
            style: 'single'
        }
    });

    // Evento de selección de fila
    $('#gridBalance tbody').on('click', 'tr', function() {
        if ($(this).hasClass('selected')) {
            $(this).removeClass('selected');
            selectedRow = null;
        } else {
            table.$('tr.selected').removeClass('selected');
            $(this).addClass('selected');
            selectedRow = table.row(this).data();
        }
        
        updateButtonStates();
    });

    // Botón Listar
    $('#btnListar').click(function() {
        loadBalanceData();
    });

    // Botón Cerrar
    $('#btnCerrar').click(function() {
        window.close();
    });

    // Botón Ver Libro Mayor
    $('#btnVerLibMayor').click(function() {
        if (selectedRow) {
            showLibroMayor(selectedRow.idCuenta);
        }
    });

    // Botón Sumar
    $('#btnSumar').click(function() {
        if (selectedRow) {
            sumarMovimientos();
        }
    });

    // Botón Calculadora
    $('#btnCalculadora').click(function() {
        // Abrir calculadora del sistema
        window.open('calc:', '_blank');
    });

    // Botón Convertir Moneda
    $('#btnConvertirMoneda').click(function() {
        // Implementar conversión de moneda
        alert('Funcionalidad de conversión de moneda no implementada');
    });

    // Botón Calendario
    $('#btnCalendario').click(function() {
        // Implementar calendario
        alert('Funcionalidad de calendario no implementada');
    });

    // Botón Copiar Excel
    $('#btnCopiarExcel').click(function() {
        copyToExcel();
    });

    // Botón Vista Previa
    $('#btnVistaPrevia').click(function() {
        // Implementar vista previa
        alert('Funcionalidad de vista previa no implementada');
    });

    // Botón Imprimir
    $('#btnImprimir').click(function() {
        window.print();
    });

    // Botón Email
    $('#btnEmail').click(function() {
        $('#modalEmail').modal('show');
    });

    // Botón Enviar Email
    $('#btnEnviarEmail').click(function() {
        sendEmail();
    });

    // Checkbox Ver Código Cuenta
    $('#verCodigoCuenta').change(function() {
        toggleCodigoCuenta();
    });

    // Checkbox Libro Oficial
    $('#libroOficial').change(function() {
        toggleLibroOficial();
    });

    // Cargar datos iniciales
    loadBalanceData();

    function loadBalanceData() {
        const request = {
            fechaDesde: $('#fechaDesde').val(),
            fechaHasta: $('#fechaHasta').val(),
            tipoAjuste: parseInt($('#tipoAjuste').val()),
            idAreaNegocio: $('#areaNegocio').val() ? parseInt($('#areaNegocio').val()) : null,
            idCentroCosto: $('#centroCosto').val() ? parseInt($('#centroCosto').val()) : null,
            nivel: parseInt($('#nivel').val()),
            libroOficial: $('#libroOficial').is(':checked'),
            verCodigoCuenta: $('#verCodigoCuenta').is(':checked')
        };

        $.ajax({
            url: '/BalanceTributario/GetBalanceData',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(request),
            success: function(response) {
                if (response.success) {
                    balanceData = response.data;
                    populateGrid(response.data);
                    updateButtonStates();
                } else {
                    alert('Error: ' + response.message);
                }
            },
            error: function(xhr, status, error) {
                alert('Error al cargar datos: ' + error);
            }
        });
    }

    function populateGrid(data) {
        table.clear();
        
        if (data.rows && data.rows.length > 0) {
            data.rows.forEach(function(row) {
                table.row.add({
                    idCuenta: row.idCuenta,
                    codigo: row.codigo,
                    cuenta: row.cuenta,
                    debitos: row.debitos,
                    creditos: row.creditos,
                    saldoDeudor: row.saldoDeudor,
                    saldoAcreedor: row.saldoAcreedor,
                    inventarioActivo: row.inventarioActivo,
                    inventarioPasivo: row.inventarioPasivo,
                    perdida: row.perdida,
                    ganancia: row.ganancia
                });
            });
        }
        
        table.draw();
        
        // Actualizar totales
        updateTotales(data);
    }

    function updateTotales(data) {
        // Sub Total
        $('#gridSubTotal tbody tr').html(`
            <td>Sub Total</td>
            <td class="text-end">${formatNumber(data.subTotal.debitos)}</td>
            <td class="text-end">${formatNumber(data.subTotal.creditos)}</td>
            <td class="text-end">${formatNumber(data.subTotal.saldoDeudor)}</td>
            <td class="text-end">${formatNumber(data.subTotal.saldoAcreedor)}</td>
            <td class="text-end">${formatNumber(data.subTotal.inventarioActivo)}</td>
            <td class="text-end">${formatNumber(data.subTotal.inventarioPasivo)}</td>
            <td class="text-end">${formatNumber(data.subTotal.perdida)}</td>
            <td class="text-end">${formatNumber(data.subTotal.ganancia)}</td>
        `);

        // Utilidad/Pérdida
        $('#gridUtilidadPerdida tbody tr').html(`
            <td>${data.utilidadPerdida.descripcion}</td>
            <td class="text-end">${formatNumber(data.utilidadPerdida.debitos)}</td>
            <td class="text-end">${formatNumber(data.utilidadPerdida.creditos)}</td>
            <td class="text-end">${formatNumber(data.utilidadPerdida.saldoDeudor)}</td>
            <td class="text-end">${formatNumber(data.utilidadPerdida.saldoAcreedor)}</td>
            <td class="text-end">${formatNumber(data.utilidadPerdida.inventarioActivo)}</td>
            <td class="text-end">${formatNumber(data.utilidadPerdida.inventarioPasivo)}</td>
            <td class="text-end">${formatNumber(data.utilidadPerdida.perdida)}</td>
            <td class="text-end">${formatNumber(data.utilidadPerdida.ganancia)}</td>
        `);

        // Totales
        $('#gridTotales tbody tr').html(`
            <td><strong>TOTALES</strong></td>
            <td class="text-end"><strong>${formatNumber(data.totales.debitos)}</strong></td>
            <td class="text-end"><strong>${formatNumber(data.totales.creditos)}</strong></td>
            <td class="text-end"><strong>${formatNumber(data.totales.saldoDeudor)}</strong></td>
            <td class="text-end"><strong>${formatNumber(data.totales.saldoAcreedor)}</strong></td>
            <td class="text-end"><strong>${formatNumber(data.totales.inventarioActivo)}</strong></td>
            <td class="text-end"><strong>${formatNumber(data.totales.inventarioPasivo)}</strong></td>
            <td class="text-end"><strong>${formatNumber(data.totales.perdida)}</strong></td>
            <td class="text-end"><strong>${formatNumber(data.totales.ganancia)}</strong></td>
        `);
    }

    function updateButtonStates() {
        const hasData = balanceData && balanceData.rows && balanceData.rows.length > 0;
        const hasSelection = selectedRow !== null;

        $('#btnVerLibMayor').prop('disabled', !hasSelection);
        $('#btnSumar').prop('disabled', !hasSelection);
        $('#btnCopiarExcel').prop('disabled', !hasData);
        $('#btnVistaPrevia').prop('disabled', !hasData);
        $('#btnImprimir').prop('disabled', !hasData);
        $('#btnEmail').prop('disabled', !hasData);
    }

    function showLibroMayor(idCuenta) {
        const request = {
            fechaDesde: $('#fechaDesde').val(),
            fechaHasta: $('#fechaHasta').val(),
            tipoAjuste: parseInt($('#tipoAjuste').val())
        };

        $.ajax({
            url: `/BalanceTributario/GetLibroMayor?idCuenta=${idCuenta}&fechaDesde=${request.fechaDesde}&fechaHasta=${request.fechaHasta}&tipoAjuste=${request.tipoAjuste}`,
            type: 'GET',
            success: function(response) {
                if (response.success) {
                    populateLibroMayor(response.data);
                    $('#modalLibroMayor').modal('show');
                } else {
                    alert('Error: ' + response.message);
                }
            },
            error: function(xhr, status, error) {
                alert('Error al cargar libro mayor: ' + error);
            }
        });
    }

    function populateLibroMayor(data) {
        const tbody = $('#gridLibroMayor tbody');
        tbody.empty();

        if (data.rows && data.rows.length > 0) {
            data.rows.forEach(function(row) {
                tbody.append(`
                    <tr>
                        <td>${formatDate(row.fecha)}</td>
                        <td>${row.comprobante}</td>
                        <td>${row.glosa}</td>
                        <td class="text-end">${formatNumber(row.debitos)}</td>
                        <td class="text-end">${formatNumber(row.creditos)}</td>
                        <td class="text-end">${formatNumber(row.saldo)}</td>
                    </tr>
                `);
            });
        }
    }

    function sumarMovimientos() {
        if (selectedRow) {
            const suma = selectedRow.debitos + selectedRow.creditos + 
                        selectedRow.saldoDeudor + selectedRow.saldoAcreedor +
                        selectedRow.inventarioActivo + selectedRow.inventarioPasivo +
                        selectedRow.perdida + selectedRow.ganancia;
            
            alert(`Suma de movimientos: ${formatNumber(suma)}`);
        }
    }

    function copyToExcel() {
        if (!balanceData) return;

        let csv = 'Código,Cuentas,Débitos,Créditos,Deudor,Acreedor,Inventario Activo,Inventario Pasivo,Pérdida,Ganancia\n';
        
        if (balanceData.rows) {
            balanceData.rows.forEach(function(row) {
                csv += `"${row.codigo}","${row.cuenta}",${row.debitos},${row.creditos},${row.saldoDeudor},${row.saldoAcreedor},${row.inventarioActivo},${row.inventarioPasivo},${row.perdida},${row.ganancia}\n`;
            });
        }

        // Agregar totales
        csv += `"Sub Total","",${balanceData.subTotal.debitos},${balanceData.subTotal.creditos},${balanceData.subTotal.saldoDeudor},${balanceData.subTotal.saldoAcreedor},${balanceData.subTotal.inventarioActivo},${balanceData.subTotal.inventarioPasivo},${balanceData.subTotal.perdida},${balanceData.subTotal.ganancia}\n`;
        csv += `"${balanceData.utilidadPerdida.descripcion}","",${balanceData.utilidadPerdida.debitos},${balanceData.utilidadPerdida.creditos},${balanceData.utilidadPerdida.saldoDeudor},${balanceData.utilidadPerdida.saldoAcreedor},${balanceData.utilidadPerdida.inventarioActivo},${balanceData.utilidadPerdida.inventarioPasivo},${balanceData.utilidadPerdida.perdida},${balanceData.utilidadPerdida.ganancia}\n`;
        csv += `"TOTALES","",${balanceData.totales.debitos},${balanceData.totales.creditos},${balanceData.totales.saldoDeudor},${balanceData.totales.saldoAcreedor},${balanceData.totales.inventarioActivo},${balanceData.totales.inventarioPasivo},${balanceData.totales.perdida},${balanceData.totales.ganancia}\n`;

        // Copiar al portapapeles
        navigator.clipboard.writeText(csv).then(function() {
            alert('Datos copiados al portapapeles');
        }).catch(function(err) {
            console.error('Error al copiar: ', err);
            alert('Error al copiar datos');
        });
    }

    function sendEmail() {
        const email = $('#emailDestino').val();
        const asunto = $('#asuntoEmail').val();
        const mensaje = $('#mensajeEmail').val();

        if (!email) {
            alert('Por favor ingrese un email válido');
            return;
        }

        const request = {
            request: {
                fechaDesde: $('#fechaDesde').val(),
                fechaHasta: $('#fechaHasta').val(),
                tipoAjuste: parseInt($('#tipoAjuste').val()),
                idAreaNegocio: $('#areaNegocio').val() ? parseInt($('#areaNegocio').val()) : null,
                idCentroCosto: $('#centroCosto').val() ? parseInt($('#centroCosto').val()) : null,
                nivel: parseInt($('#nivel').val()),
                libroOficial: $('#libroOficial').is(':checked'),
                verCodigoCuenta: $('#verCodigoCuenta').is(':checked')
            },
            email: email,
            asunto: asunto,
            mensaje: mensaje
        };

        $.ajax({
            url: '/BalanceTributario/SendEmail',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(request),
            success: function(response) {
                if (response.success) {
                    alert('Email enviado correctamente');
                    $('#modalEmail').modal('hide');
                } else {
                    alert('Error: ' + response.message);
                }
            },
            error: function(xhr, status, error) {
                alert('Error al enviar email: ' + error);
            }
        });
    }

    function toggleCodigoCuenta() {
        const showCodigo = $('#verCodigoCuenta').is(':checked');
        if (showCodigo) {
            $('#gridBalance th:first-child').show();
            $('#gridBalance td:first-child').show();
        } else {
            $('#gridBalance th:first-child').hide();
            $('#gridBalance td:first-child').hide();
        }
    }

    function toggleLibroOficial() {
        const libroOficial = $('#libroOficial').is(':checked');
        if (libroOficial) {
            $('#areaNegocio').val('').prop('disabled', true);
            $('#centroCosto').val('').prop('disabled', true);
        } else {
            $('#areaNegocio').prop('disabled', false);
            $('#centroCosto').prop('disabled', false);
        }
    }

    function formatNumber(value) {
        if (value === null || value === undefined) return '0';
        return new Intl.NumberFormat('es-CL', {
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(value);
    }

    function formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('es-CL');
    }
});









