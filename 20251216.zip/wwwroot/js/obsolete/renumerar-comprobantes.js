$(document).ready(function() {
    // Variables globales
    let renumeracionId = null;
    let progressInterval = null;
    let fechaDesde = $('#fechaDesde').val();
    let correlativosIniciales = {
        apertura: parseInt($('#correlativoApertura').val()) || 0,
        ingresos: parseInt($('#correlativoIngresos').val()) || 0,
        egresos: parseInt($('#correlativoEgresos').val()) || 0,
        traspasos: parseInt($('#correlativoTraspasos').val()) || 0
    };

    // Inicializar
    inicializar();

    function inicializar() {
        configurarEventos();
        validarFecha();
    }

    function configurarEventos() {
        // Cambio de fecha
        $('#fechaDesde').change(function() {
            fechaDesde = $(this).val();
            validarFecha();
        });

        // Cambio de correlativos
        $('#correlativoApertura, #correlativoIngresos, #correlativoEgresos, #correlativoTraspasos').change(function() {
            actualizarCorrelativos();
            validarFecha();
        });

        // Botones principales
        $('#btnRenumerar').click(confirmarRenumeracion);
        $('#btnCancelar').click(cancelarRenumeracion);
        $('#btnPreview').click(mostrarVistaPrevia);
        $('#btnValidateSystem').click(validarSistema);
        $('#btnSeleccionarFecha').click(seleccionarFecha);

        // Confirmaciones
        $('#btnConfirmarRenumeracion').click(confirmarRenumeracion);
        $('#btnConfirmarAccion').click(ejecutarRenumeracion);
    }

    function actualizarCorrelativos() {
        correlativosIniciales = {
            apertura: parseInt($('#correlativoApertura').val()) || 0,
            ingresos: parseInt($('#correlativoIngresos').val()) || 0,
            egresos: parseInt($('#correlativoEgresos').val()) || 0,
            traspasos: parseInt($('#correlativoTraspasos').val()) || 0
        };
    }

    function validarFecha() {
        if (!fechaDesde) return;

        $.ajax({
            url: '/RenumerarComprobantes/ValidateDate',
            type: 'POST',
            data: JSON.stringify({
                fechaDesde: fechaDesde,
                correlativosIniciales: correlativosIniciales
            }),
            contentType: 'application/json',
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                mostrarValidacionFecha(response);
            },
            error: function() {
                mostrarError('Error al validar fecha');
            }
        });
    }

    function mostrarValidacionFecha(response) {
        const container = $('#validacionFecha');
        container.show();

        let html = '<div class="alert alert-' + (response.success ? 'success' : 'danger') + '">';
        html += '<h6><i class="fas fa-' + (response.success ? 'check-circle' : 'exclamation-circle') + '"></i> ';
        html += response.success ? 'Validación exitosa' : 'Errores de validación';
        html += '</h6>';
        html += '<p>' + response.message + '</p>';

        if (response.errors && response.errors.length > 0) {
            html += '<ul class="mb-0">';
            response.errors.forEach(error => {
                html += '<li>' + error + '</li>';
            });
            html += '</ul>';
        }

        if (response.warnings && response.warnings.length > 0) {
            html += '<div class="mt-2"><strong>Advertencias:</strong><ul class="mb-0">';
            response.warnings.forEach(warning => {
                html += '<li>' + warning + '</li>';
            });
            html += '</ul></div>';
        }

        html += '</div>';
        container.html(html);

        // Habilitar/deshabilitar botón de renumeración
        $('#btnRenumerar').prop('disabled', !response.success);
    }

    function mostrarVistaPrevia() {
        if (!fechaDesde) {
            mostrarError('Debe seleccionar una fecha');
            return;
        }

        mostrarCargando('Generando vista previa...');

        $.ajax({
            url: '/RenumerarComprobantes/PreviewRenumeracion',
            type: 'POST',
            data: JSON.stringify({
                fechaDesde: fechaDesde,
                correlativosIniciales: correlativosIniciales
            }),
            contentType: 'application/json',
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                if (response.success) {
                    mostrarContenidoPreview(response.preview);
                    $('#modalPreview').modal('show');
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al generar vista previa');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function mostrarContenidoPreview(preview) {
        let html = '<div class="row mb-3">';
        html += '<div class="col-md-3"><div class="card bg-info text-white"><div class="card-body text-center">';
        html += '<h4>' + preview.totalComprobantes + '</h4><p>Total Comprobantes</p></div></div></div>';
        html += '<div class="col-md-3"><div class="card bg-success text-white"><div class="card-body text-center">';
        html += '<h4>' + preview.comprobantesPorTipo + '</h4><p>Tipos Diferentes</p></div></div></div>';
        html += '<div class="col-md-3"><div class="card bg-warning text-white"><div class="card-body text-center">';
        html += '<h4>' + preview.correlativosFinales.apertura + '</h4><p>Final Apertura</p></div></div></div>';
        html += '<div class="col-md-3"><div class="card bg-primary text-white"><div class="card-body text-center">';
        html += '<h4>' + preview.correlativosFinales.ingresos + '</h4><p>Final Ingresos</p></div></div></div>';
        html += '</div>';

        if (preview.warnings && preview.warnings.length > 0) {
            html += '<div class="alert alert-warning">';
            html += '<h6>Advertencias:</h6><ul class="mb-0">';
            preview.warnings.forEach(warning => {
                html += '<li>' + warning + '</li>';
            });
            html += '</ul></div>';
        }

        html += '<div class="table-responsive">';
        html += '<table class="table table-striped table-hover">';
        html += '<thead class="thead-dark">';
        html += '<tr><th>ID</th><th>Tipo</th><th>Correlativo Actual</th><th>Correlativo Nuevo</th><th>Fecha</th><th>Glosa</th></tr>';
        html += '</thead><tbody>';

        preview.comprobantes.forEach(function(comp) {
            html += '<tr>';
            html += '<td>' + comp.idComp + '</td>';
            html += '<td><span class="badge badge-' + getTipoClass(comp.tipo) + '">' + comp.tipo + '</span></td>';
            html += '<td>' + comp.correlativoActual + '</td>';
            html += '<td><strong>' + comp.correlativoNuevo + '</strong></td>';
            html += '<td>' + formatearFecha(comp.fecha) + '</td>';
            html += '<td>' + comp.glosa + '</td>';
            html += '</tr>';
        });

        html += '</tbody></table></div>';
        $('#contenidoPreview').html(html);
    }

    function getTipoClass(tipo) {
        switch(tipo) {
            case 'I': return 'success';
            case 'E': return 'danger';
            case 'T': return 'info';
            case 'A': return 'warning';
            default: return 'secondary';
        }
    }

    function validarSistema() {
        mostrarCargando('Validando estado del sistema...');

        $.ajax({
            url: '/RenumerarComprobantes/ValidateSystemState',
            type: 'POST',
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                mostrarContenidoValidacionSistema(response);
                $('#modalValidacionSistema').modal('show');
            },
            error: function() {
                mostrarError('Error al validar sistema');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function mostrarContenidoValidacionSistema(response) {
        let html = '<div class="alert alert-' + (response.success ? 'success' : 'danger') + '">';
        html += '<h6><i class="fas fa-' + (response.success ? 'check-circle' : 'exclamation-circle') + '"></i> ';
        html += response.success ? 'Sistema listo' : 'Sistema no listo';
        html += '</h6>';
        html += '<p>' + response.message + '</p>';
        html += '</div>';

        html += '<div class="row">';
        html += '<div class="col-md-6"><strong>Usuarios Activos:</strong> ' + response.usuariosActivos + '</div>';
        html += '<div class="col-md-6"><strong>Sistema Bloqueado:</strong> ' + (response.sistemaBloqueado ? 'Sí' : 'No') + '</div>';
        html += '</div>';

        if (response.warnings && response.warnings.length > 0) {
            html += '<div class="alert alert-warning mt-3">';
            html += '<h6>Advertencias:</h6><ul class="mb-0">';
            response.warnings.forEach(warning => {
                html += '<li>' + warning + '</li>';
            });
            html += '</ul></div>';
        }

        $('#contenidoValidacionSistema').html(html);
    }

    function confirmarRenumeracion() {
        if (!fechaDesde) {
            mostrarError('Debe seleccionar una fecha');
            return;
        }

        const mensaje = `Se renumerarán los comprobantes desde ${formatearFecha(fechaDesde)}.\n\n¿Desea continuar?`;
        $('#mensajeConfirmacion').text(mensaje);
        $('#modalConfirmar').modal('show');
    }

    function ejecutarRenumeracion() {
        $('#modalConfirmar').modal('hide');
        
        mostrarCargando('Iniciando renumeración...');
        $('#btnRenumerar').prop('disabled', true);
        $('#btnCancelar').prop('disabled', false).show();

        $.ajax({
            url: '/RenumerarComprobantes/Renumerar',
            type: 'POST',
            data: JSON.stringify({
                fechaDesde: fechaDesde,
                correlativosIniciales: correlativosIniciales
            }),
            contentType: 'application/json',
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                if (response.success) {
                    renumeracionId = response.renumeracionId;
                    iniciarSeguimientoProgreso();
                    mostrarExito('Renumeración iniciada correctamente');
                } else {
                    mostrarError(response.message);
                    $('#btnRenumerar').prop('disabled', false);
                    $('#btnCancelar').prop('disabled', true).hide();
                }
            },
            error: function() {
                mostrarError('Error al iniciar renumeración');
                $('#btnRenumerar').prop('disabled', false);
                $('#btnCancelar').prop('disabled', true).hide();
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function iniciarSeguimientoProgreso() {
        if (progressInterval) {
            clearInterval(progressInterval);
        }

        progressInterval = setInterval(function() {
            if (!renumeracionId) return;

            $.ajax({
                url: `/RenumerarComprobantes/GetProgress/${renumeracionId}`,
                type: 'GET',
                success: function(response) {
                    if (response.success) {
                        actualizarProgreso(response);
                        
                        if (response.isComplete) {
                            clearInterval(progressInterval);
                            mostrarResultados(response);
                            finalizarRenumeracion();
                        }
                    }
                },
                error: function() {
                    clearInterval(progressInterval);
                    mostrarError('Error al obtener progreso de renumeración');
                    finalizarRenumeracion();
                }
            });
        }, 1000);
    }

    function actualizarProgreso(progress) {
        $('#estadoProceso').text(progress.message);
        $('#progressContainer').show();
        $('#progressBar').css('width', progress.progress + '%');
        $('#progressText').text(progress.progress + '%');
    }

    function mostrarResultados(progress) {
        const container = $('#resultadosContainer');
        const resultados = $('#resultadosRenumeracion');
        
        let html = '<div class="row">';
        html += '<div class="col-md-3"><div class="card bg-success text-white"><div class="card-body text-center">';
        html += '<h4>' + progress.processedCount + '</h4><p>Comprobantes Procesados</p></div></div></div>';
        html += '<div class="col-md-3"><div class="card bg-danger text-white"><div class="card-body text-center">';
        html += '<h4>' + progress.errorCount + '</h4><p>Errores</p></div></div></div>';
        html += '<div class="col-md-3"><div class="card bg-info text-white"><div class="card-body text-center">';
        html += '<h4>' + progress.totalCount + '</h4><p>Total Comprobantes</p></div></div></div>';
        html += '<div class="col-md-3"><div class="card bg-warning text-white"><div class="card-body text-center">';
        html += '<h4>' + Math.round(progress.progress) + '%</h4><p>Progreso</p></div></div></div>';
        html += '</div>';

        if (progress.errors && progress.errors.length > 0) {
            html += '<div class="mt-3"><h6>Errores encontrados:</h6><ul class="list-group">';
            progress.errors.forEach(error => {
                html += '<li class="list-group-item">' + error + '</li>';
            });
            html += '</ul></div>';
        }

        resultados.html(html);
        container.show();
    }

    function finalizarRenumeracion() {
        $('#btnRenumerar').prop('disabled', false);
        $('#btnCancelar').prop('disabled', true).hide();
        $('#progressContainer').hide();
        $('#estadoProceso').text('Renumeración completada');
        
        // Limpiar variables
        renumeracionId = null;
    }

    function cancelarRenumeracion() {
        if (!renumeracionId) return;

        $.ajax({
            url: `/RenumerarComprobantes/Cancel/${renumeracionId}`,
            type: 'POST',
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                if (response.success) {
                    mostrarInfo('Renumeración cancelada');
                    finalizarRenumeracion();
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al cancelar renumeración');
            }
        });
    }

    function seleccionarFecha() {
        // Implementar selector de fecha si es necesario
        $('#fechaDesde').focus();
    }

    function mostrarCargando(mensaje) {
        // Implementar indicador de carga
        console.log('Cargando: ' + mensaje);
    }

    function ocultarCargando() {
        // Ocultar indicador de carga
        console.log('Carga completada');
    }

    function mostrarError(mensaje) {
        toastr.error(mensaje);
    }

    function mostrarExito(mensaje) {
        toastr.success(mensaje);
    }

    function mostrarInfo(mensaje) {
        toastr.info(mensaje);
    }

    function formatearFecha(fecha) {
        return new Date(fecha).toLocaleDateString('es-CL');
    }
});

