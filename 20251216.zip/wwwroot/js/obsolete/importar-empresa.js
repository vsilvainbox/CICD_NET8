/**
 * JavaScript para la funcionalidad de Importar Empresas
 * Migración de FrmImpEmpresa.frm (VB6)
 */

(function () {
    'use strict';

    const API_BASE = '/api/importar-empresa';
    let formatoArchivo = null;

    // Referencias a elementos del DOM
    const formImportacion = document.getElementById('formImportacion');
    const archivoTxt = document.getElementById('archivoTxt');
    const ignorarAntiguo = document.getElementById('ignorarAntiguo');
    const btnProcesar = document.getElementById('btnProcesar');
    const btnExaminar = document.getElementById('btnExaminar');
    const btnLimpiar = document.getElementById('btnLimpiar');
    const btnDescripcion = document.getElementById('btnDescripcion');
    const btnVerLog = document.getElementById('btnVerLog');
    const progressContainer = document.getElementById('progressContainer');
    const progressBar = document.getElementById('progressBar');
    const progressText = document.getElementById('progressText');
    const progressLabel = document.getElementById('progressLabel');
    const logContainer = document.getElementById('logContainer');
    const resumenContainer = document.getElementById('resumenContainer');
    const resumenImportadas = document.getElementById('resumenImportadas');
    const resumenTotal = document.getElementById('resumenTotal');
    const resumenErrores = document.getElementById('resumenErrores');

    // Inicialización
    document.addEventListener('DOMContentLoaded', function () {
        console.log('Inicializando módulo Importar Empresas');
        inicializarEventos();
        cargarFormatoArchivo();
    });

    /**
     * Inicializa los event listeners
     */
    function inicializarEventos() {
        // Evento de selección de archivo
        archivoTxt.addEventListener('change', function () {
            const archivo = this.files[0];
            if (archivo) {
                btnProcesar.disabled = false;
                agregarMensajeLog(`Archivo seleccionado: ${archivo.name} (${formatBytes(archivo.size)})`, 'info');
            } else {
                btnProcesar.disabled = true;
            }
        });

        // Botón Examinar (abre selector de archivo)
        btnExaminar.addEventListener('click', function () {
            archivoTxt.click();
        });

        // Botón Procesar
        btnProcesar.addEventListener('click', function () {
            procesarImportacion();
        });

        // Botón Limpiar
        btnLimpiar.addEventListener('click', function () {
            limpiarFormulario();
        });

        // Botón Descripción
        btnDescripcion.addEventListener('click', function () {
            mostrarDescripcionFormato();
        });

        // Botón Ver Log
        btnVerLog.addEventListener('click', function () {
            mostrarLogCompleto();
        });
    }

    /**
     * Carga la especificación del formato del archivo desde la API
     */
    async function cargarFormatoArchivo() {
        try {
            const response = await fetch(`${API_BASE}/formato`);
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            formatoArchivo = await response.json();
            console.log('Formato de archivo cargado:', formatoArchivo);
        } catch (error) {
            console.error('Error cargando formato de archivo:', error);
            mostrarError('No se pudo cargar la especificación del formato de archivo');
        }
    }

    /**
     * Procesa la importación del archivo
     */
    async function procesarImportacion() {
        const archivo = archivoTxt.files[0];
        if (!archivo) {
            mostrarError('Debe seleccionar un archivo');
            return;
        }

        // Validar extensión
        if (!archivo.name.toLowerCase().endsWith('.txt')) {
            mostrarError('El archivo debe tener extensión .txt');
            return;
        }

        // Validar tamaño (10 MB máximo)
        if (archivo.size > 10 * 1024 * 1024) {
            mostrarError('El archivo no debe exceder 10 MB');
            return;
        }

        // Preparar FormData
        const formData = new FormData();
        formData.append('archivo', archivo);
        formData.append('ignorarArchivoAntiguo', ignorarAntiguo.checked);

        // Deshabilitar controles
        btnProcesar.disabled = true;
        btnExaminar.disabled = true;
        btnLimpiar.disabled = true;
        archivoTxt.disabled = true;
        ignorarAntiguo.disabled = true;

        // Limpiar log y resumen
        logContainer.innerHTML = '';
        resumenContainer.style.display = 'none';

        // Mostrar barra de progreso
        progressContainer.style.display = 'block';
        progressBar.style.width = '0%';
        progressBar.setAttribute('aria-valuenow', 0);
        progressText.textContent = '0%';
        progressLabel.textContent = 'Importando...';

        // Simular progreso (indeterminado)
        let progresoSimulado = 0;
        const intervalo = setInterval(() => {
            progresoSimulado += 5;
            if (progresoSimulado <= 90) {
                progressBar.style.width = `${progresoSimulado}%`;
                progressBar.setAttribute('aria-valuenow', progresoSimulado);
                progressText.textContent = `${progresoSimulado}%`;
            }
        }, 500);

        try {
            agregarMensajeLog('Iniciando importación...', 'info');

            const response = await fetch(`${API_BASE}/procesar`, {
                method: 'POST',
                body: formData
            });

            clearInterval(intervalo);

            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.detail || `HTTP ${response.status}: ${response.statusText}`);
            }

            const resultado = await response.json();

            // Completar barra de progreso
            progressBar.style.width = '100%';
            progressBar.setAttribute('aria-valuenow', 100);
            progressText.textContent = '100%';
            progressLabel.textContent = 'Completado';
            progressBar.classList.remove('progress-bar-animated');
            progressBar.classList.add('bg-success');

            // Mostrar mensajes del log
            if (resultado.mensajesLog && resultado.mensajesLog.length > 0) {
                resultado.mensajesLog.forEach(mensaje => {
                    const tipo = mensaje.toLowerCase().includes('error') ? 'danger' :
                        mensaje.toLowerCase().includes('advertencia') ? 'warning' : 'info';
                    agregarMensajeLog(mensaje, tipo);
                });
            }

            // Mostrar resumen
            resumenImportadas.textContent = resultado.empresasImportadas;
            resumenTotal.textContent = resultado.totalLineas;
            resumenErrores.textContent = resultado.errores;
            resumenContainer.style.display = 'block';

            // Notificación
            if (resultado.exitoso) {
                mostrarExito(`Se importaron ${resultado.empresasImportadas} empresas exitosamente`);
            } else {
                mostrarAdvertencia('No se pudo importar ninguna empresa. Revise el log de errores.');
            }

        } catch (error) {
            clearInterval(intervalo);
            console.error('Error durante importación:', error);
            agregarMensajeLog(`ERROR CRÍTICO: ${error.message}`, 'danger');
            mostrarError(`Error durante la importación: ${error.message}`);

            // Barra de progreso en error
            progressBar.classList.remove('progress-bar-animated', 'bg-primary');
            progressBar.classList.add('bg-danger');
            progressLabel.textContent = 'Error';
        } finally {
            // Rehabilitar controles
            btnProcesar.disabled = false;
            btnExaminar.disabled = false;
            btnLimpiar.disabled = false;
            archivoTxt.disabled = false;
            ignorarAntiguo.disabled = false;
        }
    }

    /**
     * Agrega un mensaje al log
     */
    function agregarMensajeLog(mensaje, tipo = 'info') {
        const div = document.createElement('div');
        
        // Definir colores según tipo
        const colores = {
            'danger': 'bg-red-50 border-red-200 text-red-800',
            'warning': 'bg-yellow-50 border-yellow-200 text-yellow-800',
            'success': 'bg-green-50 border-green-200 text-green-800',
            'info': 'bg-blue-50 border-blue-200 text-blue-800'
        };
        
        const iconos = {
            'danger': 'fa-times-circle text-red-600',
            'warning': 'fa-exclamation-triangle text-yellow-600',
            'success': 'fa-check-circle text-green-600',
            'info': 'fa-info-circle text-blue-600'
        };

        div.className = `flex items-start p-3 mb-2 border rounded-lg ${colores[tipo] || colores.info}`;
        div.innerHTML = `
            <i class="fas ${iconos[tipo] || iconos.info} mr-3 mt-0.5"></i>
            <span class="text-sm flex-1">${escapeHtml(mensaje)}</span>
        `;

        logContainer.appendChild(div);

        // Scroll automático hacia abajo
        logContainer.scrollTop = logContainer.scrollHeight;
    }

    /**
     * Muestra el modal con la descripción del formato
     */
    function mostrarDescripcionFormato() {
        if (!formatoArchivo) {
            mostrarError('No se ha cargado la especificación del formato');
            return;
        }

        // Llenar datos del modal
        document.getElementById('modalNombreArchivo').textContent = formatoArchivo.nombreArchivo;
        document.getElementById('modalSeparador').textContent = formatoArchivo.separador;
        document.getElementById('modalEncoding').textContent = formatoArchivo.encoding;
        document.getElementById('modalMaxRegistros').textContent = formatoArchivo.maxRegistros;

        // Llenar tabla de columnas
        const tbody = document.querySelector('#tablaColumnas tbody');
        tbody.innerHTML = '';

        formatoArchivo.columnas.forEach(columna => {
            const tr = document.createElement('tr');
            tr.className = 'hover:bg-gray-50';
            tr.innerHTML = `
                <td class="px-4 py-3 text-center font-semibold text-gray-900">${columna.numero}</td>
                <td class="px-4 py-3 text-gray-900">${escapeHtml(columna.campo)}</td>
                <td class="px-4 py-3"><code class="text-xs bg-gray-100 px-2 py-1 rounded">${escapeHtml(columna.formato)}</code></td>
                <td class="px-4 py-3 text-center">
                    ${columna.obligatorio 
                        ? '<span class="inline-block px-2 py-1 text-xs font-semibold text-red-700 bg-red-100 rounded">Sí</span>' 
                        : '<span class="inline-block px-2 py-1 text-xs font-semibold text-gray-700 bg-gray-100 rounded">No</span>'}
                </td>
                <td class="px-4 py-3"><code class="text-xs bg-gray-100 px-2 py-1 rounded">${escapeHtml(columna.ejemplo || '-')}</code></td>
            `;
            tbody.appendChild(tr);
        });

        // Mostrar modal
        document.getElementById('modalDescripcion').classList.remove('hidden');
    }

    /**
     * Muestra el modal con el log completo
     */
    async function mostrarLogCompleto() {
        const logCompleto = document.getElementById('logCompleto');

        logCompleto.textContent = 'Cargando log...';
        document.getElementById('modalLog').classList.remove('hidden');

        try {
            const response = await fetch(`${API_BASE}/log?numeroLineas=200`);
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const lineas = await response.json();
            logCompleto.textContent = lineas.length > 0 ? lineas.join('\n') : 'No hay log disponible';
        } catch (error) {
            console.error('Error cargando log:', error);
            logCompleto.textContent = `Error cargando log: ${error.message}`;
        }
    }

    /**
     * Limpia el formulario y resetea el estado
     */
    function limpiarFormulario() {
        formImportacion.reset();
        btnProcesar.disabled = true;
        progressContainer.style.display = 'none';
        resumenContainer.style.display = 'none';
        logContainer.innerHTML = `
            <div class="text-muted">
                <i class="bi bi-info-circle me-2"></i>
                Seleccione un archivo y haga clic en "Procesar" para iniciar la importación.
            </div>
        `;
        progressBar.classList.remove('bg-success', 'bg-danger');
        progressBar.classList.add('bg-primary', 'progress-bar-animated');
    }

    /**
     * Muestra un mensaje de error con SweetAlert2
     */
    function mostrarError(mensaje) {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: mensaje,
            confirmButtonColor: '#dc3545'
        });
    }

    /**
     * Muestra un mensaje de éxito con SweetAlert2
     */
    function mostrarExito(mensaje) {
        Swal.fire({
            icon: 'success',
            title: 'Éxito',
            text: mensaje,
            confirmButtonColor: '#198754'
        });
    }

    /**
     * Muestra un mensaje de advertencia con SweetAlert2
     */
    function mostrarAdvertencia(mensaje) {
        Swal.fire({
            icon: 'warning',
            title: 'Advertencia',
            text: mensaje,
            confirmButtonColor: '#ffc107'
        });
    }

    /**
     * Formatea bytes a tamaño legible
     */
    function formatBytes(bytes, decimales = 2) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const dm = decimales < 0 ? 0 : decimales;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    }

    /**
     * Escapa HTML para prevenir XSS
     */
    function escapeHtml(text) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text ? text.toString().replace(/[&<>"']/g, m => map[m]) : '';
    }

    /**
     * Función global para cerrar modales (accesible desde onclick en HTML)
     */
    window.cerrarModal = function(modal) {
        if (modal && modal.classList) {
            modal.classList.add('hidden');
        }
    };

})();
