$(document).ready(function() {
    // Variables globales
    let documentosSeleccionados = [];
    let ordenamientoActual = { columna: 'FEmision', direccion: 'desc' };
    
    // Inicialización
    inicializar();
    
    function inicializar() {
        configurarEventos();
        configurarSelect2();
        configurarDataTable();
        cargarEstadisticas();
    }
    
    function configurarEventos() {
        // Botón buscar
        $('#btnBuscar').click(function() {
            buscarDocumentos();
        });
        
        // Botón limpiar
        $('#btnLimpiar').click(function() {
            limpiarFiltros();
        });
        
        // Botón nuevo documento
        $('#btnNuevoDoc').click(function() {
            window.location.href = '/GestionDocumentos/Create';
        });
        
        // Botón modificar documento
        $('#btnModificarDoc').click(function() {
            const id = obtenerDocumentoSeleccionado();
            if (id) {
                window.location.href = `/GestionDocumentos/Edit/${id}`;
            }
        });
        
        // Botón eliminar documento
        $('#btnEliminarDoc').click(function() {
            const id = obtenerDocumentoSeleccionado();
            if (id) {
                eliminarDocumento(id);
            }
        });
        
        // Botón seleccionar
        $('#btnSeleccionar').click(function() {
            const id = obtenerDocumentoSeleccionado();
            if (id) {
                seleccionarDocumento(id);
            }
        });
        
        // Botón detalle
        $('#btnDetalle').click(function() {
            const id = obtenerDocumentoSeleccionado();
            if (id) {
                mostrarDetalle(id);
            }
        });
        
        // Botón sumar
        $('#btnSumar').click(function() {
            const ids = obtenerDocumentosSeleccionados();
            if (ids.length > 0) {
                sumarDocumentos(ids);
            }
        });
        
        // Botón ordenar
        $('#btnOrdenar').click(function() {
            mostrarModalOrdenamiento();
        });
        
        // Botón exportar Excel
        $('#btnExportarExcel').click(function() {
            exportarExcel();
        });
        
        // Botón exportar PDF
        $('#btnExportarPDF').click(function() {
            exportarPDF();
        });
        
        // Botón imprimir
        $('#btnImprimir').click(function() {
            imprimir();
        });
        
        // Botón calculadora
        $('#btnCalculadora').click(function() {
            abrirCalculadora();
        });
        
        // Botón convertir moneda
        $('#btnConvertirMoneda').click(function() {
            abrirConvertidorMoneda();
        });
        
        // Botón calendario
        $('#btnCalendario').click(function() {
            abrirCalendario();
        });
        
        // Checkbox select all
        $('#selectAll').change(function() {
            const isChecked = $(this).is(':checked');
            $('.documento-checkbox').prop('checked', isChecked);
            actualizarSeleccion();
        });
        
        // Checkboxes individuales
        $(document).on('change', '.documento-checkbox', function() {
            actualizarSeleccion();
        });
        
        // Click en fila para seleccionar
        $(document).on('click', 'tbody tr', function(e) {
            if (!$(e.target).is('input, button, a')) {
                const checkbox = $(this).find('.documento-checkbox');
                checkbox.prop('checked', !checkbox.prop('checked'));
                actualizarSeleccion();
            }
        });
        
        // Botones de acción en fila
        $(document).on('click', '.btn-detalle', function(e) {
            e.stopPropagation();
            const id = $(this).closest('tr').data('id');
            mostrarDetalle(id);
        });
        
        $(document).on('click', '.btn-editar', function(e) {
            e.stopPropagation();
            const id = $(this).closest('tr').data('id');
            window.location.href = `/GestionDocumentos/Edit/${id}`;
        });
        
        $(document).on('click', '.btn-eliminar', function(e) {
            e.stopPropagation();
            const id = $(this).closest('tr').data('id');
            eliminarDocumento(id);
        });
        
        // Cambio en tipo de libro para cargar tipos de documento
        $('#TipoLib').change(function() {
            cargarTiposDocumento();
        });
        
        // Validación de RUT
        $('#RutEntidad').blur(function() {
            if ($(this).val() && $('#Ch_Rut').is(':checked')) {
                validarRUT($(this).val());
            }
        });
    }
    
    function configurarSelect2() {
        $('#IdEntidad, #TipoLib, #TipoDoc, #Estado').select2({
            placeholder: 'Seleccione una opción',
            allowClear: true,
            width: '100%'
        });
    }
    
    function configurarDataTable() {
        $('#gridDocumentos').DataTable({
            responsive: true,
            pageLength: 25,
            lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
            order: [[6, 'desc']], // Ordenar por fecha de emisión
            columnDefs: [
                { orderable: false, targets: [0, 14] }, // Columnas no ordenables
                { className: 'text-center', targets: [0, 5, 13] },
                { className: 'text-right', targets: [11, 12] }
            ],
            language: {
                url: '//cdn.datatables.net/plug-ins/1.10.24/i18n/Spanish.json'
            }
        });
    }
    
    function buscarDocumentos() {
        const filtros = obtenerFiltros();
        
        $.ajax({
            url: '/ListadoDocumentos/Buscar',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(filtros),
            success: function(response) {
                if (response.success) {
                    actualizarGrid(response.documentos);
                    actualizarEstadisticas(response.documentos);
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al buscar documentos');
            }
        });
    }
    
    function obtenerFiltros() {
        return {
            TipoLib: $('#TipoLib').val() || null,
            TipoDoc: $('#TipoDoc').val() || null,
            NumDoc: $('#NumDoc').val() || null,
            Estado: $('#Estado').val() || null,
            FEmisionDesde: $('#FEmisionDesde').val() || null,
            FEmisionHasta: $('#FEmisionHasta').val() || null,
            FVencDesde: $('#FVencDesde').val() || null,
            FVencHasta: $('#FVencHasta').val() || null,
            Descrip: $('#Descrip').val() || null,
            Valor: $('#Valor').val() || null,
            IdEntidad: $('#IdEntidad').val() || null,
            RutEntidad: $('#RutEntidad').val() || null,
            SaldosVigentes: $('#SaldosVigentes').is(':checked'),
            VerCuotas: $('#VerCuotas').is(':checked'),
            NumCuotas: $('#NumCuotas').val() || null,
            OrdenarPor: ordenamientoActual.columna,
            DireccionOrden: ordenamientoActual.direccion
        };
    }
    
    function actualizarGrid(documentos) {
        const tbody = $('#gridDocumentos tbody');
        tbody.empty();
        
        documentos.forEach(function(doc) {
            const fila = `
                <tr data-id="${doc.idDoc}">
                    <td>
                        <input type="checkbox" class="form-check-input documento-checkbox" value="${doc.idDoc}">
                    </td>
                    <td>${doc.idDoc}</td>
                    <td>${doc.tipoLibNombre}</td>
                    <td>${doc.tipoDocNombre}</td>
                    <td>${doc.numDoc}</td>
                    <td>
                        <span class="badge badge-${doc.estado == 1 ? 'success' : doc.estado == 2 ? 'danger' : 'warning'}">
                            ${doc.estadoNombre}
                        </span>
                    </td>
                    <td>${formatearFecha(doc.fEmision)}</td>
                    <td>${doc.fVenc ? formatearFecha(doc.fVenc) : ''}</td>
                    <td>${doc.entidadNombre}</td>
                    <td>${doc.entidadRut}</td>
                    <td>${doc.descrip || ''}</td>
                    <td class="text-right">${formatearMoneda(doc.valor)}</td>
                    <td class="text-right">${formatearMoneda(doc.saldoPendiente)}</td>
                    <td class="text-center">
                        ${doc.dTE ? '<i class="fas fa-check text-success"></i>' : ''}
                    </td>
                    <td>
                        <div class="btn-group btn-group-sm">
                            <button type="button" class="btn btn-info btn-sm btn-detalle" title="Ver detalle">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button type="button" class="btn btn-warning btn-sm btn-editar" title="Editar">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button type="button" class="btn btn-danger btn-sm btn-eliminar" title="Eliminar">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `;
            tbody.append(fila);
        });
        
        $('#totalDocumentos').text(`${documentos.length} documentos`);
    }
    
    function actualizarSeleccion() {
        const seleccionados = $('.documento-checkbox:checked').length;
        const total = $('.documento-checkbox').length;
        
        $('#btnModificarDoc, #btnEliminarDoc, #btnSeleccionar, #btnDetalle').prop('disabled', seleccionados !== 1);
        $('#btnSumar').prop('disabled', seleccionados === 0);
        
        if (seleccionados === total) {
            $('#selectAll').prop('indeterminate', false).prop('checked', true);
        } else if (seleccionados === 0) {
            $('#selectAll').prop('indeterminate', false).prop('checked', false);
        } else {
            $('#selectAll').prop('indeterminate', true);
        }
    }
    
    function obtenerDocumentoSeleccionado() {
        const checkbox = $('.documento-checkbox:checked').first();
        return checkbox.length ? parseInt(checkbox.val()) : null;
    }
    
    function obtenerDocumentosSeleccionados() {
        return $('.documento-checkbox:checked').map(function() {
            return parseInt($(this).val());
        }).get();
    }
    
    function mostrarDetalle(id) {
        $.ajax({
            url: `/ListadoDocumentos/GetDetalle/${id}`,
            type: 'GET',
            success: function(response) {
                if (response.success) {
                    mostrarModalDetalle(response.detalle);
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al obtener detalle del documento');
            }
        });
    }
    
    function mostrarModalDetalle(detalle) {
        const contenido = `
            <div class="row">
                <div class="col-md-6">
                    <h6>Información del Documento</h6>
                    <table class="table table-sm">
                        <tr><td><strong>ID:</strong></td><td>${detalle.idDoc}</td></tr>
                        <tr><td><strong>Tipo Libro:</strong></td><td>${detalle.tipoLibNombre}</td></tr>
                        <tr><td><strong>Tipo Doc:</strong></td><td>${detalle.tipoDocNombre}</td></tr>
                        <tr><td><strong>Número:</strong></td><td>${detalle.numDoc}</td></tr>
                        <tr><td><strong>Estado:</strong></td><td>${detalle.estadoNombre}</td></tr>
                        <tr><td><strong>Fecha Emisión:</strong></td><td>${formatearFecha(detalle.fEmision)}</td></tr>
                        <tr><td><strong>Fecha Vencimiento:</strong></td><td>${detalle.fVenc ? formatearFecha(detalle.fVenc) : 'N/A'}</td></tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <h6>Información de la Entidad</h6>
                    <table class="table table-sm">
                        <tr><td><strong>Nombre:</strong></td><td>${detalle.entidadNombre}</td></tr>
                        <tr><td><strong>RUT:</strong></td><td>${detalle.entidadRut}</td></tr>
                        <tr><td><strong>Descripción:</strong></td><td>${detalle.descrip || 'N/A'}</td></tr>
                        <tr><td><strong>Valor:</strong></td><td>${formatearMoneda(detalle.valor)}</td></tr>
                        <tr><td><strong>Saldo Pendiente:</strong></td><td>${formatearMoneda(detalle.saldoPendiente)}</td></tr>
                        <tr><td><strong>DTE:</strong></td><td>${detalle.dTE ? 'Sí' : 'No'}</td></tr>
                    </table>
                </div>
            </div>
            ${detalle.cuotas && detalle.cuotas.length > 0 ? `
                <div class="row mt-3">
                    <div class="col-12">
                        <h6>Cuotas del Documento</h6>
                        <table class="table table-sm table-bordered">
                            <thead>
                                <tr>
                                    <th>Número</th>
                                    <th>Fecha Vencimiento</th>
                                    <th>Valor</th>
                                    <th>Saldo Pendiente</th>
                                    <th>Estado</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${detalle.cuotas.map(cuota => `
                                    <tr>
                                        <td>${cuota.numCuota}</td>
                                        <td>${cuota.fVenc ? formatearFecha(cuota.fVenc) : 'N/A'}</td>
                                        <td class="text-right">${formatearMoneda(cuota.valor)}</td>
                                        <td class="text-right">${formatearMoneda(cuota.saldoPendiente)}</td>
                                        <td>${cuota.estado || 'N/A'}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            ` : ''}
        `;
        
        $('#modalDetalleBody').html(contenido);
        $('#modalDetalle').modal('show');
    }
    
    function sumarDocumentos(ids) {
        $.ajax({
            url: '/ListadoDocumentos/SumarSeleccionados',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ idsDocumentos: ids }),
            success: function(response) {
                if (response.success) {
                    mostrarModalSuma(response);
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al sumar documentos');
            }
        });
    }
    
    function mostrarModalSuma(suma) {
        const contenido = `
            <div class="row">
                <div class="col-md-6">
                    <h6>Resumen de la Suma</h6>
                    <table class="table table-sm">
                        <tr><td><strong>Total Valor:</strong></td><td class="text-right">${formatearMoneda(suma.total)}</td></tr>
                        <tr><td><strong>Total Saldo Pendiente:</strong></td><td class="text-right">${formatearMoneda(suma.saldoPendiente)}</td></tr>
                        <tr><td><strong>Cantidad de Documentos:</strong></td><td class="text-right">${suma.cantidad}</td></tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <h6>Desglose por Tipo</h6>
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>Tipo Doc</th>
                                <th class="text-right">Cantidad</th>
                                <th class="text-right">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${suma.desglose.map(item => `
                                <tr>
                                    <td>${item.tipoDoc}</td>
                                    <td class="text-right">${item.cantidad}</td>
                                    <td class="text-right">${formatearMoneda(item.total)}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
        
        $('#modalSumaBody').html(contenido);
        $('#modalSuma').modal('show');
    }
    
    function eliminarDocumento(id) {
        if (confirm('¿Está seguro de que desea eliminar este documento?')) {
            $.ajax({
                url: `/ListadoDocumentos/Delete/${id}`,
                type: 'POST',
                headers: {
                    'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
                },
                success: function(response) {
                    if (response.success) {
                        mostrarExito(response.message);
                        buscarDocumentos(); // Recargar la lista
                    } else {
                        mostrarError(response.message);
                    }
                },
                error: function() {
                    mostrarError('Error al eliminar el documento');
                }
            });
        }
    }
    
    function seleccionarDocumento(id) {
        // Implementar lógica de selección
        console.log('Documento seleccionado:', id);
    }
    
    function mostrarModalOrdenamiento() {
        // Implementar modal de ordenamiento
        console.log('Mostrar modal de ordenamiento');
    }
    
    function exportarExcel() {
        const filtros = obtenerFiltros();
        
        $.ajax({
            url: '/ListadoDocumentos/ExportExcel',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(filtros),
            success: function(response) {
                if (response.success) {
                    // Descargar archivo
                    const link = document.createElement('a');
                    link.href = response.url;
                    link.download = response.filename;
                    link.click();
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al exportar a Excel');
            }
        });
    }
    
    function exportarPDF() {
        const filtros = obtenerFiltros();
        
        $.ajax({
            url: '/ListadoDocumentos/ExportPDF',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(filtros),
            success: function(response) {
                if (response.success) {
                    // Descargar archivo
                    const link = document.createElement('a');
                    link.href = response.url;
                    link.download = response.filename;
                    link.click();
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al exportar a PDF');
            }
        });
    }
    
    function imprimir() {
        const filtros = obtenerFiltros();
        
        $.ajax({
            url: '/ListadoDocumentos/Print',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(filtros),
            success: function(response) {
                if (response.success) {
                    // Abrir ventana de impresión
                    const ventana = window.open('', '_blank');
                    ventana.document.write(generarHTMLImpresion(response.data));
                    ventana.document.close();
                    ventana.print();
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al generar datos para impresión');
            }
        });
    }
    
    function generarHTMLImpresion(data) {
        return `
            <!DOCTYPE html>
            <html>
            <head>
                <title>${data.titulo}</title>
                <style>
                    body { font-family: Arial, sans-serif; font-size: 12px; }
                    table { width: 100%; border-collapse: collapse; }
                    th, td { border: 1px solid #000; padding: 4px; text-align: left; }
                    th { background-color: #f0f0f0; font-weight: bold; }
                    .text-right { text-align: right; }
                    .text-center { text-align: center; }
                </style>
            </head>
            <body>
                <h2>${data.titulo}</h2>
                <p>Fecha de generación: ${formatearFecha(data.fechaGeneracion)}</p>
                <p>Total de documentos: ${data.totalDocumentos}</p>
                <p>Total valor: ${formatearMoneda(data.totalValor)}</p>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Número Doc</th>
                            <th>Fecha Emisión</th>
                            <th>Entidad</th>
                            <th>Valor</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${data.documentos.map(doc => `
                            <tr>
                                <td>${doc.idDoc}</td>
                                <td>${doc.numDoc}</td>
                                <td>${formatearFecha(doc.fEmision)}</td>
                                <td>${doc.entidadNombre}</td>
                                <td class="text-right">${formatearMoneda(doc.valor)}</td>
                                <td>${doc.estadoNombre}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </body>
            </html>
        `;
    }
    
    function abrirCalculadora() {
        // Implementar calculadora
        console.log('Abrir calculadora');
    }
    
    function abrirConvertidorMoneda() {
        // Implementar convertidor de moneda
        console.log('Abrir convertidor de moneda');
    }
    
    function abrirCalendario() {
        // Implementar calendario
        console.log('Abrir calendario');
    }
    
    function cargarTiposDocumento() {
        const tipoLib = $('#TipoLib').val();
        
        if (tipoLib) {
            $.ajax({
                url: `/ListadoDocumentos/GetTiposDocumento?tipoLib=${tipoLib}`,
                type: 'GET',
                success: function(response) {
                    if (response.success) {
                        const select = $('#TipoDoc');
                        select.empty().append('<option value="">Todos los tipos</option>');
                        
                        response.tipos.forEach(function(tipo) {
                            select.append(`<option value="${tipo.idTipoDoc}">${tipo.nombre}</option>`);
                        });
                    }
                },
                error: function() {
                    console.error('Error al cargar tipos de documento');
                }
            });
        } else {
            $('#TipoDoc').empty().append('<option value="">Todos los tipos</option>');
        }
    }
    
    function validarRUT(rut) {
        // Implementar validación de RUT
        console.log('Validar RUT:', rut);
    }
    
    function limpiarFiltros() {
        $('#filtrosForm')[0].reset();
        $('#TipoLib, #TipoDoc, #IdEntidad, #Estado').val(null).trigger('change');
        buscarDocumentos();
    }
    
    function cargarEstadisticas() {
        $.ajax({
            url: '/ListadoDocumentos/GetEstadisticas',
            type: 'GET',
            success: function(response) {
                if (response.success) {
                    actualizarEstadisticas(response.estadisticas);
                }
            },
            error: function() {
                console.error('Error al cargar estadísticas');
            }
        });
    }
    
    function actualizarEstadisticas(estadisticas) {
        if (typeof estadisticas === 'object') {
            $('#totalDocumentosEst').text(estadisticas.totalDocumentos || 0);
            $('#totalValorEst').text(formatearMoneda(estadisticas.totalValor || 0));
            $('#totalSaldoEst').text(formatearMoneda(estadisticas.totalSaldoPendiente || 0));
            $('#totalVigentesEst').text(estadisticas.porEstado?.find(e => e.estado === 1)?.cantidad || 0);
        } else if (Array.isArray(estadisticas)) {
            // Si es un array de documentos, calcular estadísticas
            const total = estadisticas.length;
            const totalValor = estadisticas.reduce((sum, doc) => sum + (doc.valor || 0), 0);
            const totalSaldo = estadisticas.reduce((sum, doc) => sum + (doc.saldoPendiente || 0), 0);
            const vigentes = estadisticas.filter(doc => doc.estado === 1).length;
            
            $('#totalDocumentosEst').text(total);
            $('#totalValorEst').text(formatearMoneda(totalValor));
            $('#totalSaldoEst').text(formatearMoneda(totalSaldo));
            $('#totalVigentesEst').text(vigentes);
        }
    }
    
    function formatearFecha(fecha) {
        if (!fecha) return '';
        const date = new Date(fecha);
        return date.toLocaleDateString('es-CL');
    }
    
    function formatearMoneda(valor) {
        if (!valor) return '$0';
        return new Intl.NumberFormat('es-CL', {
            style: 'currency',
            currency: 'CLP',
            minimumFractionDigits: 0
        }).format(valor);
    }
    
    function mostrarExito(mensaje) {
        toastr.success(mensaje);
    }
    
    function mostrarError(mensaje) {
        toastr.error(mensaje);
    }
    
    function mostrarInfo(mensaje) {
        toastr.info(mensaje);
    }
});









