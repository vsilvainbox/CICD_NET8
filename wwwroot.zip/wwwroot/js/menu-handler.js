/**
 * Menu Handler for HyperContabilidad - TailAdmin Style
 * Maneja la apertura/cierre de menús desplegables con persistencia en localStorage
 */

// Toggle menu dropdown
function toggleMenu(menuId) {
    const menu = document.getElementById(menuId);
    const icon = document.getElementById(menuId + '-icon');

    if (!menu) return;

    const isHidden = menu.classList.contains('hidden');

    // Toggle visibility
    menu.classList.toggle('hidden');

    // Rotate icon
    if (icon) {
        if (isHidden) {
            icon.classList.add('rotate-180');
        } else {
            icon.classList.remove('rotate-180');
        }
    }

    // Save state to localStorage
    localStorage.setItem('menu_' + menuId, isHidden ? 'open' : 'closed');
}

// Initialize menus from localStorage on page load
document.addEventListener('DOMContentLoaded', function() {
    // Restore menu states
    const menus = document.querySelectorAll('[id^="menu-"]');
    menus.forEach(menu => {
        if (menu.id.endsWith('-icon')) return;

        const savedState = localStorage.getItem('menu_' + menu.id);
        const icon = document.getElementById(menu.id + '-icon');

        if (savedState === 'open') {
            menu.classList.remove('hidden');
            if (icon) {
                icon.classList.add('rotate-180');
            }
        }
    });
});
