/**
 * TailAdmin App - Alpine.js Configuration for HyperContabilidad
 * Integra funcionalidad del template TailAdmin con color primario naranja
 */

// Configuración global de Alpine.js
document.addEventListener('alpine:init', () => {
    // Global state management
    Alpine.store('app', {
        // Sidebar state
        sidebarOpen: window.innerWidth >= 1024, // Desktop abierto por defecto
        sidebarToggle: false, // Modo colapsado

        // Dark mode state (opcional - puede activarse más tarde)
        darkMode: false,

        // Search state
        searchOpen: false,

        // Mobile menu state
        mobileMenuOpen: false,

        // Notification state
        notifying: true,

        // Current page
        page: 'dashboard',

        // Toggle sidebar
        toggleSidebar() {
            this.sidebarOpen = !this.sidebarOpen;
        },

        // Toggle sidebar collapse mode
        toggleSidebarCollapse() {
            this.sidebarToggle = !this.sidebarToggle;
        },

        // Toggle dark mode
        toggleDarkMode() {
            this.darkMode = !this.darkMode;
            if (this.darkMode) {
                document.documentElement.classList.add('dark');
            } else {
                document.documentElement.classList.remove('dark');
            }
            localStorage.setItem('darkMode', this.darkMode);
        },

        // Initialize from localStorage
        init() {
            const savedDarkMode = localStorage.getItem('darkMode');
            if (savedDarkMode !== null) {
                this.darkMode = savedDarkMode === 'true';
                if (this.darkMode) {
                    document.documentElement.classList.add('dark');
                }
            }
        }
    });

    // Menu dropdown component
    Alpine.data('dropdown', () => ({
        open: false,

        toggle() {
            this.open = !this.open;
        },

        close() {
            this.open = false;
        }
    }));

    // Notification dropdown
    Alpine.data('notificationDropdown', () => ({
        open: false,
        notifying: true,

        toggle() {
            this.open = !this.open;
            if (this.open) {
                this.notifying = false;
            }
        },

        close() {
            this.open = false;
        }
    }));

    // User dropdown
    Alpine.data('userDropdown', () => ({
        open: false,

        toggle() {
            this.open = !this.open;
        },

        close() {
            this.open = false;
        }
    }));

    // Sidebar menu item
    Alpine.data('menuItem', (itemName) => ({
        name: itemName,
        open: false,

        init() {
            // Restore state from localStorage
            const savedState = localStorage.getItem(`menu_${this.name}`);
            this.open = savedState === 'open';
        },

        toggle() {
            this.open = !this.open;
            localStorage.setItem(`menu_${this.name}`, this.open ? 'open' : 'closed');
        },

        get isOpen() {
            return this.open;
        }
    }));
});

// Initialize Alpine store
document.addEventListener('DOMContentLoaded', () => {
    if (window.Alpine) {
        Alpine.store('app').init();
    }
});

// Handle window resize for sidebar responsiveness
let resizeTimer;
window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
        if (window.Alpine && Alpine.store('app')) {
            const store = Alpine.store('app');
            if (window.innerWidth >= 1024) {
                store.sidebarOpen = true;
                store.mobileMenuOpen = false;
            } else {
                store.sidebarOpen = false;
            }
        }
    }, 250);
});

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Cmd/Ctrl + K para abrir búsqueda
    if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        const searchInput = document.getElementById('globalSearchInput');
        if (searchInput) {
            searchInput.focus();
            searchInput.select();
        }
    }

    // Escape para cerrar modales/dropdowns
    if (e.key === 'Escape') {
        if (window.Alpine && Alpine.store('app')) {
            const store = Alpine.store('app');
            store.searchOpen = false;
            store.mobileMenuOpen = false;
        }
    }
});

/**
 * Compatibilidad con funciones existentes de HyperContabilidad
 * Estas funciones mantienen la funcionalidad actual mientras se integra Alpine.js
 */

// Toggle sidebar (función existente mejorada)
window.toggleSidebar = function() {
    if (window.Alpine && Alpine.store('app')) {
        Alpine.store('app').toggleSidebar();
    } else {
        // Fallback si Alpine no está cargado
        const sidebar = document.getElementById('sidebar');
        if (sidebar) {
            sidebar.classList.toggle('-translate-x-full');
        }
    }
};

// Toggle menu section (mantiene compatibilidad)
window.toggleMenu = function(menuId) {
    const menu = document.getElementById(menuId);
    const icon = document.getElementById(menuId + '-icon');

    if (menu) {
        const isHidden = menu.classList.contains('hidden');
        menu.classList.toggle('hidden');

        if (icon) {
            icon.classList.toggle('rotate-90');
        }

        // Save state
        localStorage.setItem('menu_' + menuId, isHidden ? 'open' : 'closed');
    }
};

// Scroll to top function
window.scrollToTop = function() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
};

// Loading bar (mantiene funcionalidad existente)
window.showLoadingBar = function() {
    const loadingBar = document.getElementById('loadingBar');
    if (loadingBar) {
        loadingBar.style.display = 'block';
    }
};

window.hideLoadingBar = function() {
    const loadingBar = document.getElementById('loadingBar');
    if (loadingBar) {
        setTimeout(() => {
            loadingBar.style.display = 'none';
        }, 300);
    }
};

// Toast notifications (compatible con sistema existente)
if (!window.showToast) {
    window.showToast = function(type, title, message, duration = 5000) {
        console.log(`[Toast ${type}] ${title}: ${message}`);
    };
}

// Utility: Detect if element is in viewport
window.isInViewport = function(element) {
    const rect = element.getBoundingClientRect();
    return (
        rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
};

// Smooth scroll to element
window.scrollToElement = function(selector, offset = 0) {
    const element = document.querySelector(selector);
    if (element) {
        const elementPosition = element.getBoundingClientRect().top + window.pageYOffset;
        const offsetPosition = elementPosition - offset;

        window.scrollTo({
            top: offsetPosition,
            behavior: 'smooth'
        });
    }
};

console.log('✅ TailAdmin App initialized for HyperContabilidad');
