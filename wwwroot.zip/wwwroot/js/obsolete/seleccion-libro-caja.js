$(document).ready(function() {
    let tipoOperacionSeleccionado = null;
    let configuracionTipoOperacion = null;
    let mesSeleccionado = null;
    let anoSeleccionado = null;
    let modoEdicion = true;

    // Inicializar
    inicializar();

    function inicializar() {
        configurarEventos();
        configurarTiposOperacion();
    }

    function configurarEventos() {
        // Selección de tipo de operación
        $('input[name="tipoOperacion"]').change(function() {
            const tipoOperacion = parseInt($(this).val());
            seleccionarTipoOperacion(tipoOperacion);
        });

        // Doble clic en tarjeta de tipo de operación
        $('.tipo-operacion-option').dblclick(function() {
            const tipoOperacion = parseInt($(this).data('tipo-operacion'));
            $('input[name="tipoOperacion"][value="' + tipoOperacion + '"]').prop('checked', true);
            seleccionarTipoOperacion(tipoOperacion);
        });

        // Cambio de mes
        $('#mes').change(function() {
            mesSeleccionado = parseInt($(this).val());
            validarSeleccion();
        });

        // Cambio de año
        $('#ano').change(function() {
            anoSeleccionado = parseInt($(this).val());
            validarSeleccion();
        });

        // Botón usar mes actual
        $('#btnUsarMesActual').click(function() {
            usarMesActual();
        });

        // Botón seleccionar
        $('#btnSeleccionar').click(function() {
            mostrarConfirmacion();
        });

        // Botón cancelar
        $('#btnCancelar').click(function() {
            cancelarSeleccion();
        });

        // Botón confirmar selección
        $('#btnConfirmarSeleccion').click(function() {
            confirmarSeleccion();
        });

        // Hover en tarjetas de tipos de operación
        $('.tipo-operacion-option').hover(
            function() {
                $(this).addClass('border-primary shadow-sm');
            },
            function() {
                if (!$(this).find('input[type="radio"]').is(':checked')) {
                    $(this).removeClass('border-primary shadow-sm');
                }
            }
        );
    }

    function configurarTiposOperacion() {
        // Configurar tarjetas de tipos de operación
        $('.tipo-operacion-option').each(function() {
            const tipoOperacion = parseInt($(this).data('tipo-operacion'));
            const radio = $(this).find('input[type="radio"]');
            
            // Agregar evento de clic a la tarjeta
            $(this).click(function() {
                radio.prop('checked', true);
                seleccionarTipoOperacion(tipoOperacion);
            });
        });
    }

    function seleccionarTipoOperacion(tipoOperacion) {
        tipoOperacionSeleccionado = tipoOperacion;
        
        // Actualizar apariencia de las tarjetas
        $('.tipo-operacion-option').removeClass('border-primary shadow-sm');
        $('.tipo-operacion-option[data-tipo-operacion="' + tipoOperacion + '"]').addClass('border-primary shadow-sm');
        
        // Obtener configuración del tipo de operación
        obtenerConfiguracionTipoOperacion(tipoOperacion);
    }

    function obtenerConfiguracionTipoOperacion(tipoOperacion) {
        $.ajax({
            url: '/SeleccionLibroCaja/ObtenerConfiguracionTipoOperacion',
            type: 'GET',
            data: { tipoOperacion: tipoOperacion },
            success: function(response) {
                if (response.success) {
                    configuracionTipoOperacion = response.data;
                    mostrarInformacionTipoOperacion();
                    validarSeleccion();
                } else {
                    mostrarError('Error al obtener configuración del tipo de operación: ' + response.message);
                }
            },
            error: function() {
                mostrarError('Error al obtener configuración del tipo de operación');
            }
        });
    }

    function mostrarInformacionTipoOperacion() {
        if (configuracionTipoOperacion) {
            const contenido = `
                <div class="row">
                    <div class="col-md-6">
                        <strong>Nombre:</strong> ${configuracionTipoOperacion.nombre}
                    </div>
                    <div class="col-md-6">
                        <strong>Modo:</strong> ${modoEdicion ? 'Edición' : 'Vista'}
                    </div>
                    <div class="col-12">
                        <strong>Descripción:</strong> ${configuracionTipoOperacion.descripcion}
                    </div>
                </div>
            `;
            
            $('#detallesTipoOperacion').html(contenido);
            $('#informacionTipoOperacion').show();
        }
    }

    function validarSeleccion() {
        let valido = true;
        let mensajes = [];

        // Validar tipo de operación
        if (!tipoOperacionSeleccionado) {
            valido = false;
            mensajes.push('Debe seleccionar un tipo de operación');
        }

        // Validar mes
        if (!mesSeleccionado || mesSeleccionado < 1 || mesSeleccionado > 12) {
            valido = false;
            mensajes.push('Debe seleccionar un mes válido');
        }

        // Validar año
        if (!anoSeleccionado || anoSeleccionado < 2000 || anoSeleccionado > 2100) {
            valido = false;
            mensajes.push('Debe seleccionar un año válido');
        }

        // Habilitar/deshabilitar botón
        $('#btnSeleccionar').prop('disabled', !valido);

        // Mostrar mensajes de validación
        if (!valido && mensajes.length > 0) {
            mostrarAdvertencia(mensajes.join(', '));
        }
    }

    function usarMesActual() {
        const mesActual = new Date().getMonth() + 1;
        const anoActual = new Date().getFullYear();
        
        $('#mes').val(mesActual);
        $('#ano').val(anoActual);
        
        mesSeleccionado = mesActual;
        anoSeleccionado = anoActual;
        
        validarSeleccion();
        mostrarMensaje('Se ha seleccionado el mes actual');
    }

    function mostrarConfirmacion() {
        if (!tipoOperacionSeleccionado) {
            mostrarError('Debe seleccionar un tipo de operación');
            return;
        }

        const tipo = obtenerTipoOperacionPorId(tipoOperacionSeleccionado);
        const nombreMes = obtenerNombreMes(mesSeleccionado);
        
        let contenido = `
            <div class="row">
                <div class="col-12">
                    <h6>Tipo de Operación Seleccionado:</h6>
                    <p><strong>${tipo.nombre}</strong></p>
                    <p>${tipo.descripcion}</p>
                </div>
                <div class="col-12">
                    <h6>Período Seleccionado:</h6>
                    <p><strong>Mes:</strong> ${nombreMes}<br>
                    <strong>Año:</strong> ${anoSeleccionado}</p>
                </div>
                <div class="col-12">
                    <h6>Modo de Acceso:</h6>
                    <p><strong>${modoEdicion ? 'Edición' : 'Vista'}</strong></p>
                </div>
            </div>
        `;

        $('#contenidoConfirmacion').html(contenido);
        $('#modalConfirmacion').modal('show');
    }

    function confirmarSeleccion() {
        const request = {
            tipoOperacion: tipoOperacionSeleccionado,
            mes: mesSeleccionado,
            ano: anoSeleccionado,
            requiereTipoOperacion: true,
            modoEdicion: modoEdicion
        };

        $.ajax({
            url: '/SeleccionLibroCaja/SeleccionarLibroCaja',
            type: 'POST',
            data: request,
            success: function(response) {
                if (response.success) {
                    $('#modalConfirmacion').modal('hide');
                    redirigirALibroCaja(response.data);
                } else {
                    mostrarError('Error al seleccionar libro de caja: ' + response.message);
                }
            },
            error: function() {
                mostrarError('Error al seleccionar libro de caja');
            }
        });
    }

    function redirigirALibroCaja(resultado) {
        if (resultado.urlRedireccion) {
            // Construir URL con parámetros
            let url = resultado.urlRedireccion;
            const parametros = [];

            if (resultado.parametros) {
                Object.keys(resultado.parametros).forEach(key => {
                    parametros.push(`${key}=${encodeURIComponent(resultado.parametros[key])}`);
                });
            }

            if (parametros.length > 0) {
                url += '?' + parametros.join('&');
            }

            // Redirigir
            window.location.href = url;
        } else {
            mostrarError('No se pudo determinar la URL de destino');
        }
    }

    function cancelarSeleccion() {
        if (confirm('¿Está seguro de que desea cancelar la selección?')) {
            window.history.back();
        }
    }

    function obtenerTipoOperacionPorId(tipoOperacion) {
        const tipos = [
            { nombre: 'Libro de Caja - Ingresos', descripcion: 'Movimientos de ingresos de caja' },
            { nombre: 'Libro de Caja - Egresos', descripcion: 'Movimientos de egresos de caja' }
        ];

        return tipos[tipoOperacion - 1] || { nombre: 'Tipo Desconocido', descripcion: 'Tipo no identificado' };
    }

    function obtenerNombreMes(mes) {
        const nombresMeses = [
            'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
            'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
        ];

        return nombresMeses[mes - 1] || 'Mes Inválido';
    }

    function mostrarError(mensaje) {
        // Implementar notificación de error
        alert('Error: ' + mensaje);
    }

    function mostrarAdvertencia(mensaje) {
        // Implementar notificación de advertencia
        console.warn('Advertencia: ' + mensaje);
    }

    function mostrarMensaje(mensaje) {
        // Implementar notificación de mensaje
        console.log('Mensaje: ' + mensaje);
    }
});









