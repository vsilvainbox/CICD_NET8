$(document).ready(function() {
    let tipoLibroSeleccionado = null;
    let configuracionLibro = null;
    let mesSeleccionado = null;
    let anoSeleccionado = null;

    // Inicializar
    inicializar();

    function inicializar() {
        configurarEventos();
        configurarLibros();
    }

    function configurarEventos() {
        // Selección de libro
        $('input[name="tipoLibro"]').change(function() {
            const tipoLibro = parseInt($(this).val());
            seleccionarLibro(tipoLibro);
        });

        // Doble clic en tarjeta de libro
        $('.libro-option').dblclick(function() {
            const tipoLibro = parseInt($(this).data('tipo-libro'));
            $('input[name="tipoLibro"][value="' + tipoLibro + '"]').prop('checked', true);
            seleccionarLibro(tipoLibro);
        });

        // Cambio de mes
        $('#mes').change(function() {
            mesSeleccionado = parseInt($(this).val());
            validarSeleccion();
        });

        // Cambio de año
        $('#ano').change(function() {
            anoSeleccionado = parseInt($(this).val());
            validarSeleccion();
        });

        // Botón usar mes actual
        $('#btnUsarMesActual').click(function() {
            usarMesActual();
        });

        // Botón seleccionar
        $('#btnSeleccionar').click(function() {
            mostrarConfirmacion();
        });

        // Botón cancelar
        $('#btnCancelar').click(function() {
            cancelarSeleccion();
        });

        // Botón confirmar selección
        $('#btnConfirmarSeleccion').click(function() {
            confirmarSeleccion();
        });

        // Hover en tarjetas de libros
        $('.libro-option').hover(
            function() {
                $(this).addClass('border-primary shadow-sm');
            },
            function() {
                if (!$(this).find('input[type="radio"]').is(':checked')) {
                    $(this).removeClass('border-primary shadow-sm');
                }
            }
        );
    }

    function configurarLibros() {
        // Configurar tarjetas de libros
        $('.libro-option').each(function() {
            const tipoLibro = parseInt($(this).data('tipo-libro'));
            const radio = $(this).find('input[type="radio"]');
            
            // Agregar evento de clic a la tarjeta
            $(this).click(function() {
                radio.prop('checked', true);
                seleccionarLibro(tipoLibro);
            });
        });
    }

    function seleccionarLibro(tipoLibro) {
        tipoLibroSeleccionado = tipoLibro;
        
        // Actualizar apariencia de las tarjetas
        $('.libro-option').removeClass('border-primary shadow-sm');
        $('.libro-option[data-tipo-libro="' + tipoLibro + '"]').addClass('border-primary shadow-sm');
        
        // Obtener configuración del libro
        obtenerConfiguracionLibro(tipoLibro);
    }

    function obtenerConfiguracionLibro(tipoLibro) {
        $.ajax({
            url: '/SeleccionLibros/ObtenerConfiguracionLibro',
            type: 'GET',
            data: { tipoLibro: tipoLibro },
            success: function(response) {
                if (response.success) {
                    configuracionLibro = response.data;
                    mostrarSeccionPeriodo();
                    mostrarInformacionLibro();
                    validarSeleccion();
                } else {
                    mostrarError('Error al obtener configuración del libro: ' + response.message);
                }
            },
            error: function() {
                mostrarError('Error al obtener configuración del libro');
            }
        });
    }

    function mostrarSeccionPeriodo() {
        if (configuracionLibro && configuracionLibro.requierePeriodo) {
            $('#seccionPeriodo').show();
            
            // Configurar campos requeridos
            if (configuracionLibro.requiereMes) {
                $('#mes').prop('required', true);
            } else {
                $('#mes').prop('required', false);
            }
            
            if (configuracionLibro.requiereAno) {
                $('#ano').prop('required', true);
            } else {
                $('#ano').prop('required', false);
            }
        } else {
            $('#seccionPeriodo').hide();
        }
    }

    function mostrarInformacionLibro() {
        if (configuracionLibro) {
            const contenido = `
                <div class="row">
                    <div class="col-md-6">
                        <strong>Nombre:</strong> ${configuracionLibro.nombre}
                    </div>
                    <div class="col-md-6">
                        <strong>Tipo:</strong> ${configuracionLibro.requierePeriodo ? 'Con período' : 'Sin período'}
                    </div>
                    <div class="col-12">
                        <strong>Descripción:</strong> ${configuracionLibro.descripcion}
                    </div>
                </div>
            `;
            
            $('#detallesLibro').html(contenido);
            $('#informacionLibro').show();
        }
    }

    function validarSeleccion() {
        let valido = true;
        let mensajes = [];

        // Validar tipo de libro
        if (!tipoLibroSeleccionado && tipoLibroSeleccionado !== 0) {
            valido = false;
            mensajes.push('Debe seleccionar un libro');
        }

        // Validar período si es requerido
        if (configuracionLibro && configuracionLibro.requierePeriodo) {
            if (configuracionLibro.requiereMes && (!mesSeleccionado || mesSeleccionado < 1 || mesSeleccionado > 12)) {
                valido = false;
                mensajes.push('Debe seleccionar un mes válido');
            }
            
            if (configuracionLibro.requiereAno && (!anoSeleccionado || anoSeleccionado < 2000 || anoSeleccionado > 2100)) {
                valido = false;
                mensajes.push('Debe seleccionar un año válido');
            }
        }

        // Habilitar/deshabilitar botón
        $('#btnSeleccionar').prop('disabled', !valido);

        // Mostrar mensajes de validación
        if (!valido && mensajes.length > 0) {
            mostrarAdvertencia(mensajes.join(', '));
        }
    }

    function usarMesActual() {
        const mesActual = new Date().getMonth() + 1;
        const anoActual = new Date().getFullYear();
        
        $('#mes').val(mesActual);
        $('#ano').val(anoActual);
        
        mesSeleccionado = mesActual;
        anoSeleccionado = anoActual;
        
        validarSeleccion();
        mostrarMensaje('Se ha seleccionado el mes actual');
    }

    function mostrarConfirmacion() {
        if (!tipoLibroSeleccionado && tipoLibroSeleccionado !== 0) {
            mostrarError('Debe seleccionar un libro');
            return;
        }

        const libro = obtenerLibroPorTipo(tipoLibroSeleccionado);
        let contenido = `
            <div class="row">
                <div class="col-12">
                    <h6>Libro Seleccionado:</h6>
                    <p><strong>${libro.nombre}</strong></p>
                    <p>${libro.descripcion}</p>
        `;

        if (configuracionLibro && configuracionLibro.requierePeriodo) {
            contenido += `
                <h6>Período Seleccionado:</h6>
                <p>
            `;
            
            if (configuracionLibro.requiereMes && mesSeleccionado) {
                const nombreMes = obtenerNombreMes(mesSeleccionado);
                contenido += `<strong>Mes:</strong> ${nombreMes}<br>`;
            }
            
            if (configuracionLibro.requiereAno && anoSeleccionado) {
                contenido += `<strong>Año:</strong> ${anoSeleccionado}`;
            }
            
            contenido += `</p>`;
        }

        contenido += `
                </div>
            </div>
        `;

        $('#contenidoConfirmacion').html(contenido);
        $('#modalConfirmacion').modal('show');
    }

    function confirmarSeleccion() {
        const request = {
            tipoLibro: tipoLibroSeleccionado,
            mes: mesSeleccionado,
            ano: anoSeleccionado,
            requierePeriodo: configuracionLibro ? configuracionLibro.requierePeriodo : false,
            filtrosAdicionales: configuracionLibro ? configuracionLibro.filtrosAdicionales : null,
            tituloPersonalizado: configuracionLibro ? configuracionLibro.tituloPersonalizado : null
        };

        $.ajax({
            url: '/SeleccionLibros/SeleccionarLibro',
            type: 'POST',
            data: request,
            success: function(response) {
                if (response.success) {
                    $('#modalConfirmacion').modal('hide');
                    redirigirALibro(response.data);
                } else {
                    mostrarError('Error al seleccionar libro: ' + response.message);
                }
            },
            error: function() {
                mostrarError('Error al seleccionar libro');
            }
        });
    }

    function redirigirALibro(resultado) {
        if (resultado.urlRedireccion) {
            // Construir URL con parámetros
            let url = resultado.urlRedireccion;
            const parametros = [];

            if (resultado.parametros) {
                Object.keys(resultado.parametros).forEach(key => {
                    parametros.push(`${key}=${encodeURIComponent(resultado.parametros[key])}`);
                });
            }

            if (parametros.length > 0) {
                url += '?' + parametros.join('&');
            }

            // Redirigir
            window.location.href = url;
        } else {
            mostrarError('No se pudo determinar la URL de destino');
        }
    }

    function cancelarSeleccion() {
        if (confirm('¿Está seguro de que desea cancelar la selección?')) {
            window.history.back();
        }
    }

    function obtenerLibroPorTipo(tipoLibro) {
        const libros = [
            { nombre: 'Libro Diario', descripcion: 'Registro cronológico de movimientos contables' },
            { nombre: 'Libro Mayor', descripcion: 'Movimientos por cuenta contable' },
            { nombre: 'Libro de Inventario y Balance', descripcion: 'Inventario de cuentas con saldos' },
            { nombre: 'Libro de Compras', descripcion: 'Documentos de compras y gastos' },
            { nombre: 'Libro de Ventas', descripcion: 'Documentos de ventas e ingresos' },
            { nombre: 'Libro de Retenciones', descripcion: 'Retenciones tributarias' },
            { nombre: 'Libro de Ventas Exportación', descripcion: 'Documentos de exportación' },
            { nombre: 'Libro de Ventas con Boletas', descripcion: 'Documentos con boletas' },
            { nombre: 'Libro Especial de Compras', descripcion: 'Facturas de compra del libro de ventas' }
        ];

        return libros[tipoLibro] || { nombre: 'Libro Desconocido', descripcion: 'Libro no identificado' };
    }

    function obtenerNombreMes(mes) {
        const nombresMeses = [
            'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
            'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
        ];

        return nombresMeses[mes - 1] || 'Mes Inválido';
    }

    function mostrarError(mensaje) {
        // Implementar notificación de error
        alert('Error: ' + mensaje);
    }

    function mostrarAdvertencia(mensaje) {
        // Implementar notificación de advertencia
        console.warn('Advertencia: ' + mensaje);
    }

    function mostrarMensaje(mensaje) {
        // Implementar notificación de mensaje
        console.log('Mensaje: ' + mensaje);
    }
});









