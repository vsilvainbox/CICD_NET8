/**
 * JavaScript para el Libro Electrónico de Compras
 */
var LibroElectronicoCompras = {
    // Variables globales
    configuracion: {
        tipoExportacion: 'SII',
        rutaExportacion: ''
    },

    /**
     * Inicializa la página
     */
    init: function() {
        this.inicializarEventos();
        this.cargarFiltros();
        this.validarPeriodo();
    },

    /**
     * Inicializa los eventos de la página
     */
    inicializarEventos: function() {
        // Botones de exportación
        $('#btnExportarSII').on('click', this.exportarSII.bind(this));
        $('#btnExportarAcepta').on('click', this.exportarAcepta.bind(this));

        // Botones de utilidades
        $('#btnVistaPrevia').on('click', this.vistaPrevia.bind(this));
        $('#btnValidar').on('click', this.validarDocumentos.bind(this));
        $('#btnManual').on('click', this.abrirManual.bind(this));
        $('#btnEstadisticas').on('click', this.mostrarEstadisticas.bind(this));
        $('#btnCerrar').on('click', this.cerrar);

        // Cambios en filtros
        $('#cbMes').on('change', this.onFiltrosChange.bind(this));
        $('#txAno').on('change', this.onFiltrosChange.bind(this));

        // Radio buttons de tipo de libro
        $('input[name="tipoLibro"]').on('change', this.onTipoLibroChange.bind(this));

        // Modal vista previa
        $('#btnExportarDesdeVistaPrevia').on('click', this.exportarDesdeVistaPrevia.bind(this));
    },

    /**
     * Carga los filtros disponibles
     */
    cargarFiltros: function() {
        $.ajax({
            url: '/LibroElectronicoCompras/GetFiltros',
            type: 'GET',
            success: function(data) {
                if (data.success) {
                    LibroElectronicoCompras.configurarFiltros(data.data);
                }
            },
            error: function() {
                toastr.error('Error al cargar los filtros');
            }
        });
    },

    /**
     * Configura los filtros
     */
    configurarFiltros: function(filtros) {
        // Configurar año actual
        $('#txAno').val(filtros.anoActual);
        
        // Configurar mes actual si no hay selección
        if (!$('#cbMes').val()) {
            $('#cbMes').val(filtros.mesActual);
        }
    },

    /**
     * Evento cuando cambian los filtros
     */
    onFiltrosChange: function() {
        this.validarPeriodo();
        this.actualizarRutaExportacion();
    },

    /**
     * Evento cuando cambia el tipo de libro
     */
    onTipoLibroChange: function() {
        var tipoLibro = $('input[name="tipoLibro"]:checked').val();
        this.configuracion.tipoExportacion = tipoLibro === 'compras' ? 'SII' : 'ACEPTA';
        this.actualizarRutaExportacion();
    },

    /**
     * Valida el período seleccionado
     */
    validarPeriodo: function() {
        var mes = parseInt($('#cbMes').val());
        var ano = parseInt($('#txAno').val());

        if (!mes || !ano) {
            return;
        }

        $.ajax({
            url: '/LibroElectronicoCompras/ValidarPeriodo',
            type: 'GET',
            data: { mes: mes, ano: ano },
            success: function(data) {
                if (data.success) {
                    LibroElectronicoCompras.mostrarValidacionPeriodo(data.data);
                }
            },
            error: function() {
                toastr.error('Error al validar el período');
            }
        });
    },

    /**
     * Muestra la validación del período
     */
    mostrarValidacionPeriodo: function(validacion) {
        var $alert = $('.alert-warning');
        
        if (!validacion.esValido) {
            $alert.show().find('strong').next().text(validacion.mensaje);
        } else {
            $alert.hide();
        }
    },

    /**
     * Actualiza la ruta de exportación
     */
    actualizarRutaExportacion: function() {
        var tipoExportacion = this.configuracion.tipoExportacion;
        
        $.ajax({
            url: '/LibroElectronicoCompras/ObtenerRutaExportacion',
            type: 'GET',
            data: { tipoExportacion: tipoExportacion },
            success: function(data) {
                if (data.success) {
                    $('#txPath').val(data.data);
                }
            },
            error: function() {
                toastr.error('Error al obtener la ruta de exportación');
            }
        });
    },

    /**
     * Exporta para SII
     */
    exportarSII: function() {
        if (!this.validarFiltros()) {
            return;
        }

        var filtros = this.obtenerFiltros();
        filtros.tipoExportacion = 'SII';
        
        this.exportar(filtros, 'SII');
    },

    /**
     * Exporta para ACEPTA
     */
    exportarAcepta: function() {
        if (!this.validarFiltros()) {
            return;
        }

        var filtros = this.obtenerFiltros();
        filtros.tipoExportacion = 'ACEPTA';
        
        this.exportar(filtros, 'ACEPTA');
    },

    /**
     * Función genérica de exportación
     */
    exportar: function(filtros, tipo) {
        var url = tipo === 'SII' ? '/LibroElectronicoCompras/ExportarSII' : '/LibroElectronicoCompras/ExportarAcepta';
        
        $.ajax({
            url: url,
            type: 'POST',
            data: filtros,
            beforeSend: function() {
                LibroElectronicoCompras.mostrarCargando(true);
            },
            success: function(data) {
                if (data.success) {
                    LibroElectronicoCompras.mostrarResultadoExportacion(data.data);
                    toastr.success(data.data.mensaje);
                } else {
                    toastr.error(data.message || 'Error al exportar');
                }
            },
            error: function() {
                toastr.error('Error al exportar');
            },
            complete: function() {
                LibroElectronicoCompras.mostrarCargando(false);
            }
        });
    },

    /**
     * Muestra el resultado de la exportación
     */
    mostrarResultadoExportacion: function(resultado) {
        var html = `
            <div class="alert alert-success">
                <h5><i class="fas fa-check-circle"></i> Exportación Completada</h5>
                <p><strong>Archivo:</strong> ${resultado.nombreArchivo}</p>
                <p><strong>Documentos:</strong> ${resultado.cantidadDocumentos}</p>
                <p><strong>Total Bruto:</strong> ${LibroElectronicoCompras.formatearMoneda(resultado.totalMontoNeto)}</p>
                <p><strong>Total IVA:</strong> ${LibroElectronicoCompras.formatearMoneda(resultado.totalMontoIVARecuperable)}</p>
                <p><strong>Total:</strong> ${LibroElectronicoCompras.formatearMoneda(resultado.totalMontoTotal)}</p>
                <div class="mt-2">
                    <a href="~/LibroElectronicoCompras/DescargarArchivo?nombreArchivo=${resultado.nombreArchivo}" class="btn btn-primary btn-sm">
                        <i class="fas fa-download"></i> Descargar Archivo
                    </a>
                </div>
            </div>
        `;

        $('#listaArchivos').html(html);
        $('#infoArchivos').show();
    },

    /**
     * Muestra la vista previa
     */
    vistaPrevia: function() {
        if (!this.validarFiltros()) {
            return;
        }

        var filtros = this.obtenerFiltros();
        
        $.ajax({
            url: '/LibroElectronicoCompras/GenerarVistaPrevia',
            type: 'GET',
            data: filtros,
            beforeSend: function() {
                LibroElectronicoCompras.mostrarCargando(true);
            },
            success: function(data) {
                $('#contenidoVistaPrevia').html(data);
                $('#modalVistaPrevia').modal('show');
            },
            error: function() {
                toastr.error('Error al generar vista previa');
            },
            complete: function() {
                LibroElectronicoCompras.mostrarCargando(false);
            }
        });
    },

    /**
     * Exporta desde la vista previa
     */
    exportarDesdeVistaPrevia: function() {
        $('#modalVistaPrevia').modal('hide');
        
        var tipoLibro = $('input[name="tipoLibro"]:checked').val();
        if (tipoLibro === 'compras') {
            this.exportarSII();
        } else {
            this.exportarAcepta();
        }
    },

    /**
     * Valida los documentos
     */
    validarDocumentos: function() {
        if (!this.validarFiltros()) {
            return;
        }

        var filtros = this.obtenerFiltros();
        
        $.ajax({
            url: '/LibroElectronicoCompras/ValidarDocumentos',
            type: 'POST',
            data: filtros,
            beforeSend: function() {
                LibroElectronicoCompras.mostrarCargando(true);
            },
            success: function(data) {
                if (data.success) {
                    LibroElectronicoCompras.mostrarResultadoValidacion(data.data);
                } else {
                    toastr.error(data.message || 'Error al validar documentos');
                }
            },
            error: function() {
                toastr.error('Error al validar documentos');
            },
            complete: function() {
                LibroElectronicoCompras.mostrarCargando(false);
            }
        });
    },

    /**
     * Muestra el resultado de la validación
     */
    mostrarResultadoValidacion: function(validacion) {
        var tipoAlerta = validacion.esValido ? 'success' : 'warning';
        var icono = validacion.esValido ? 'check-circle' : 'exclamation-triangle';
        
        var html = `
            <div class="alert alert-${tipoAlerta}">
                <h5><i class="fas fa-${icono}"></i> Validación de Documentos</h5>
                <p>${validacion.mensaje}</p>
        `;

        if (validacion.errores && validacion.errores.length > 0) {
            html += '<ul><li>' + validacion.errores.join('</li><li>') + '</li></ul>';
        }

        if (validacion.advertencias && validacion.advertencias.length > 0) {
            html += '<h6>Advertencias:</h6><ul><li>' + validacion.advertencias.join('</li><li>') + '</li></ul>';
        }

        html += '</div>';

        toastr.info(html);
    },

    /**
     * Abre el manual
     */
    abrirManual: function() {
        window.open('/LibroElectronicoCompras/ObtenerManual', '_blank');
    },

    /**
     * Muestra las estadísticas
     */
    mostrarEstadisticas: function() {
        if (!this.validarFiltros()) {
            return;
        }

        var filtros = this.obtenerFiltros();
        
        $.ajax({
            url: '/LibroElectronicoCompras/ObtenerEstadisticas',
            type: 'GET',
            data: filtros,
            beforeSend: function() {
                LibroElectronicoCompras.mostrarCargando(true);
            },
            success: function(data) {
                if (data.success) {
                    LibroElectronicoCompras.mostrarContenidoEstadisticas(data.data);
                    $('#modalEstadisticas').modal('show');
                } else {
                    toastr.error(data.message || 'Error al obtener estadísticas');
                }
            },
            error: function() {
                toastr.error('Error al obtener estadísticas');
            },
            complete: function() {
                LibroElectronicoCompras.mostrarCargando(false);
            }
        });
    },

    /**
     * Muestra el contenido de las estadísticas
     */
    mostrarContenidoEstadisticas: function(estadisticas) {
        var html = `
            <div class="row">
                <div class="col-md-6">
                    <h6>Documentos por Tipo</h6>
                    <ul class="list-unstyled">
                        <li><strong>Total:</strong> ${estadisticas.cantidadDocumentos}</li>
                        <li><strong>Facturas:</strong> ${estadisticas.cantidadFacturas}</li>
                        <li><strong>Notas de Crédito:</strong> ${estadisticas.cantidadNotasCredito}</li>
                        <li><strong>Notas de Débito:</strong> ${estadisticas.cantidadNotasDebito}</li>
                        <li><strong>Guías de Despacho:</strong> ${estadisticas.cantidadGuiasDespacho}</li>
                        <li><strong>Otros:</strong> ${estadisticas.cantidadOtros}</li>
                    </ul>
                </div>
                <div class="col-md-6">
                    <h6>Montos</h6>
                    <ul class="list-unstyled">
                        <li><strong>Total Exento:</strong> ${LibroElectronicoCompras.formatearMoneda(estadisticas.totalMontoExento)}</li>
                        <li><strong>Total Neto:</strong> ${LibroElectronicoCompras.formatearMoneda(estadisticas.totalMontoNeto)}</li>
                        <li><strong>Total IVA Recuperable:</strong> ${LibroElectronicoCompras.formatearMoneda(estadisticas.totalMontoIVARecuperable)}</li>
                        <li><strong>Total IVA No Recuperable:</strong> ${LibroElectronicoCompras.formatearMoneda(estadisticas.totalMontoIVANoRecuperable)}</li>
                        <li><strong>Total General:</strong> ${LibroElectronicoCompras.formatearMoneda(estadisticas.totalMontoTotal)}</li>
                    </ul>
                </div>
            </div>
        `;

        if (estadisticas.documentosExcluidos && estadisticas.documentosExcluidos.length > 0) {
            html += `
                <div class="row mt-3">
                    <div class="col-12">
                        <h6>Documentos Excluidos</h6>
                        <ul class="list-unstyled">
            `;
            
            estadisticas.documentosExcluidos.forEach(function(doc) {
                html += `<li><strong>${doc.tipoDocumento}:</strong> ${doc.descripcion} (${doc.cantidad})</li>`;
            });
            
            html += '</ul></div></div>';
        }

        $('#contenidoEstadisticasModal').html(html);
    },

    /**
     * Valida los filtros antes de procesar
     */
    validarFiltros: function() {
        var mes = $('#cbMes').val();
        var ano = $('#txAno').val();

        if (!mes) {
            toastr.error('Debe seleccionar un mes');
            $('#cbMes').focus();
            return false;
        }

        if (!ano) {
            toastr.error('Debe ingresar un año');
            $('#txAno').focus();
            return false;
        }

        return true;
    },

    /**
     * Obtiene los filtros del formulario
     */
    obtenerFiltros: function() {
        return {
            Mes: parseInt($('#cbMes').val()),
            Ano: parseInt($('#txAno').val()),
            TipoExportacion: this.configuracion.tipoExportacion
        };
    },

    /**
     * Cierra la página
     */
    cerrar: function() {
        if (confirm('¿Está seguro que desea cerrar el generador de libro electrónico?')) {
            window.close();
        }
    },

    /**
     * Muestra el indicador de carga
     */
    mostrarCargando: function(mostrar) {
        if (mostrar) {
            $('.btn').prop('disabled', true);
            $('body').append('<div id="loading" class="loading-overlay"><div class="spinner-border" role="status"><span class="sr-only">Cargando...</span></div></div>');
        } else {
            $('.btn').prop('disabled', false);
            $('#loading').remove();
        }
    },

    /**
     * Formatea una moneda
     */
    formatearMoneda: function(valor) {
        if (valor === null || valor === undefined) return '$0.00';
        
        return '$' + parseFloat(valor).toLocaleString('es-CL', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }
};

// Inicializar cuando el documento esté listo
$(document).ready(function() {
    LibroElectronicoCompras.init();
});









