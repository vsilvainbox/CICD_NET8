/**
 * JavaScript para el selector de opciones 14ter
 */

document.addEventListener('DOMContentLoaded', function() {
    const seleccionForm = document.getElementById('seleccionForm');
    const opcionSeleccionadaInput = document.getElementById('opcionSeleccionada');
    const btnSeleccionar = document.getElementById('btnSeleccionar');
    const btnCancelar = document.getElementById('btnCancelar');
    const confirmacionModal = new bootstrap.Modal(document.getElementById('confirmacionModal'));
    const validacionModal = new bootstrap.Modal(document.getElementById('validacionModal'));
    const opcionSeleccionadaTexto = document.getElementById('opcionSeleccionadaTexto');
    const mensajeValidacion = document.getElementById('mensajeValidacion');
    
    let opcionActual = null;

    // Inicialización
    inicializar();

    function inicializar() {
        // Configurar eventos de las tarjetas de opciones
        document.querySelectorAll('.opcion-card').forEach(card => {
            card.addEventListener('click', function() {
                seleccionarOpcion(this);
            });
            
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-5px)';
                this.style.transition = 'transform 0.3s ease';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0)';
            });
        });

        // Configurar eventos de los botones de selección
        document.querySelectorAll('.seleccionar-opcion').forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                const card = this.closest('.opcion-card');
                seleccionarOpcion(card);
            });
        });

        // Configurar eventos de los botones principales
        btnSeleccionar.addEventListener('click', function() {
            if (opcionActual) {
                confirmarSeleccion();
            }
        });

        btnCancelar.addEventListener('click', function() {
            cancelarSeleccion();
        });

        // Configurar evento de confirmación del modal
        document.getElementById('confirmarSeleccion').addEventListener('click', function() {
            confirmacionModal.hide();
            procesarSeleccion();
        });

        // Configurar evento de doble clic en las tarjetas
        document.querySelectorAll('.opcion-card').forEach(card => {
            card.addEventListener('dblclick', function() {
                seleccionarOpcion(this);
                if (opcionActual) {
                    confirmarSeleccion();
                }
            });
        });
    }

    function seleccionarOpcion(card) {
        // Remover selección anterior
        document.querySelectorAll('.opcion-card').forEach(c => {
            c.classList.remove('border-primary', 'border-success', 'border-info', 'border-warning', 'border-danger', 'border-secondary');
            c.classList.add('border-light');
        });

        // Seleccionar nueva opción
        card.classList.remove('border-light');
        const opcionId = parseInt(card.dataset.opcionId);
        const requiereValidacion = card.dataset.requiereValidacion === 'true';
        const mensajeValidacionTexto = card.dataset.mensajeValidacion;

        // Obtener información de la opción
        const titulo = card.querySelector('.card-title').textContent;
        const descripcion = card.querySelector('.card-text').textContent;

        opcionActual = {
            id: opcionId,
            titulo: titulo,
            descripcion: descripcion,
            requiereValidacion: requiereValidacion,
            mensajeValidacion: mensajeValidacionTexto
        };

        // Aplicar estilo de selección
        const color = card.querySelector('.seleccionar-opcion').classList.contains('btn-primary') ? 'primary' :
                     card.querySelector('.seleccionar-opcion').classList.contains('btn-success') ? 'success' :
                     card.querySelector('.seleccionar-opcion').classList.contains('btn-info') ? 'info' :
                     card.querySelector('.seleccionar-opcion').classList.contains('btn-warning') ? 'warning' :
                     card.querySelector('.seleccionar-opcion').classList.contains('btn-danger') ? 'danger' :
                     'secondary';
        
        card.classList.add(`border-${color}`);

        // Habilitar botón de selección
        btnSeleccionar.disabled = false;
        btnSeleccionar.classList.remove('btn-secondary');
        btnSeleccionar.classList.add('btn-primary');

        // Actualizar input hidden
        opcionSeleccionadaInput.value = opcionId;
    }

    function confirmarSeleccion() {
        if (!opcionActual) return;

        // Verificar si requiere validación
        if (opcionActual.requiereValidacion) {
            mostrarValidacion(opcionActual.mensajeValidacion);
            return;
        }

        // Mostrar modal de confirmación
        opcionSeleccionadaTexto.textContent = `${opcionActual.titulo} - ${opcionActual.descripcion}`;
        confirmacionModal.show();
    }

    function mostrarValidacion(mensaje) {
        mensajeValidacion.textContent = mensaje;
        validacionModal.show();
    }

    function procesarSeleccion() {
        if (!opcionActual) return;

        // Mostrar indicador de carga
        btnSeleccionar.disabled = true;
        btnSeleccionar.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Procesando...';

        // Enviar formulario
        seleccionForm.submit();
    }

    function cancelarSeleccion() {
        // Limpiar selección
        document.querySelectorAll('.opcion-card').forEach(card => {
            card.classList.remove('border-primary', 'border-success', 'border-info', 'border-warning', 'border-danger', 'border-secondary');
            card.classList.add('border-light');
        });

        // Deshabilitar botón de selección
        btnSeleccionar.disabled = true;
        btnSeleccionar.classList.remove('btn-primary');
        btnSeleccionar.classList.add('btn-secondary');
        btnSeleccionar.innerHTML = '<i class="fas fa-check me-2"></i>Seleccionar...';

        // Limpiar input hidden
        opcionSeleccionadaInput.value = '';
        opcionActual = null;
    }

    // Función para validar franquicia 14 TER (si es necesaria)
    function validarFranquicia14Ter() {
        return fetch('/SeleccionLibro14ter/ValidarFranquicia14Ter')
            .then(response => response.json())
            .then(data => {
                if (!data.valido) {
                    mostrarError(data.mensaje);
                    return false;
                }
                return true;
            })
            .catch(error => {
                console.error('Error al validar franquicia 14 TER:', error);
                mostrarError('Error al validar la configuración de la empresa');
                return false;
            });
    }

    function mostrarError(mensaje) {
        // Crear o actualizar mensaje de error
        let errorAlert = document.querySelector('.alert-danger');
        if (!errorAlert) {
            errorAlert = document.createElement('div');
            errorAlert.className = 'alert alert-danger d-flex align-items-center mb-4';
            errorAlert.innerHTML = '<i class="fas fa-exclamation-triangle me-2"></i><div></div>';
            document.querySelector('.card-body').insertBefore(errorAlert, document.querySelector('.alert-info'));
        }
        
        errorAlert.querySelector('div').textContent = mensaje;
        errorAlert.style.display = 'block';
    }

    function mostrarInfo(mensaje) {
        // Crear o actualizar mensaje de información
        let infoAlert = document.querySelector('.alert-success');
        if (!infoAlert) {
            infoAlert = document.createElement('div');
            infoAlert.className = 'alert alert-success d-flex align-items-center mb-4';
            infoAlert.innerHTML = '<i class="fas fa-check-circle me-2"></i><div></div>';
            document.querySelector('.card-body').insertBefore(infoAlert, document.querySelector('.alert-info'));
        }
        
        infoAlert.querySelector('div').textContent = mensaje;
        infoAlert.style.display = 'block';
    }

    // Función para obtener opciones disponibles (si es necesaria)
    function obtenerOpcionesDisponibles() {
        return fetch('/SeleccionLibro14ter/ObtenerOpcionesDisponibles')
            .then(response => response.json())
            .then(data => {
                console.log('Opciones disponibles:', data);
                return data;
            })
            .catch(error => {
                console.error('Error al obtener opciones disponibles:', error);
                return [];
            });
    }

    // Función para obtener configuración de la empresa (si es necesaria)
    function obtenerConfiguracionEmpresa() {
        return fetch('/SeleccionLibro14ter/ObtenerConfiguracionEmpresa')
            .then(response => response.json())
            .then(data => {
                console.log('Configuración de empresa:', data);
                return data;
            })
            .catch(error => {
                console.error('Error al obtener configuración de empresa:', error);
                return null;
            });
    }

    // Exponer funciones globalmente si es necesario
    window.SeleccionLibro14ter = {
        validarFranquicia14Ter,
        obtenerOpcionesDisponibles,
        obtenerConfiguracionEmpresa,
        mostrarError,
        mostrarInfo
    };
});









