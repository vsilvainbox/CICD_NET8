$(document).ready(function() {
    // Variables globales
    let movimientos = [];
    let ordenActual = 'fechahora';
    let direccionOrden = 'desc';
    let idCompActual = $('#idComp').val();

    // Inicializar
    inicializar();

    function inicializar() {
        configurarEventos();
        
        // Si hay un ID de comprobante, cargar movimientos automáticamente
        if (idCompActual) {
            cargarMovimientos(idCompActual);
        }
    }

    function configurarEventos() {
        // Botones principales
        $('#btnBuscar').click(buscar);
        $('#btnExportExcel').click(exportarExcel);
        $('#btnExportPDF').click(exportarPDF);
        $('#btnImprimir').click(imprimir);
        $('#btnResumen').click(mostrarResumen);
        $('#btnEstadisticas').click(mostrarEstadisticas);

        // Ordenamiento de columnas
        $('#gridMovimientos th[data-sort]').click(function() {
            const columna = $(this).data('sort');
            ordenarPorColumna(columna);
        });
    }

    function cargarMovimientos(idComp) {
        if (!idComp) {
            mostrarError('Debe especificar un ID de comprobante');
            return;
        }

        mostrarCargando('Cargando movimientos...');

        $.ajax({
            url: `/SeguimientoMovimientos/GetMovimientos/${idComp}`,
            type: 'GET',
            success: function(response) {
                if (response.success) {
                    movimientos = response.movimientos;
                    mostrarMovimientos(movimientos);
                    $('#totalMovimientos').text(response.total + ' movimientos');
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al cargar movimientos');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function buscar() {
        const filtros = obtenerFiltros();
        
        if (!filtros.IdComp && !filtros.IdCuenta && !filtros.IdCentroCosto && !filtros.IdAreaNegocio) {
            mostrarError('Debe especificar al menos un filtro');
            return;
        }

        mostrarCargando('Buscando movimientos...');

        $.ajax({
            url: '/SeguimientoMovimientos/BuscarMovimientos',
            type: 'POST',
            data: JSON.stringify(filtros),
            contentType: 'application/json',
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                if (response.success) {
                    movimientos = response.movimientos;
                    mostrarMovimientos(movimientos);
                    $('#totalMovimientos').text(response.total + ' movimientos');
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al buscar movimientos');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function obtenerFiltros() {
        return {
            IdComp: $('#idComp').val() ? parseInt($('#idComp').val()) : null,
            IdCuenta: $('#idCuenta').val() ? parseInt($('#idCuenta').val()) : null,
            IdCentroCosto: $('#idCentroCosto').val() ? parseInt($('#idCentroCosto').val()) : null,
            IdAreaNegocio: $('#idAreaNegocio').val() ? parseInt($('#idAreaNegocio').val()) : null,
            FechaDesde: $('#fechaDesde').val() ? new Date($('#fechaDesde').val()) : null,
            FechaHasta: $('#fechaHasta').val() ? new Date($('#fechaHasta').val()) : null,
            TipoAjuste: $('#tipoAjuste').val() ? parseInt($('#tipoAjuste').val()) : null,
            FormaIngreso: $('#formaIngreso').val() ? parseInt($('#formaIngreso').val()) : null,
            Vigente: $('#vigente').val() ? $('#vigente').val() === 'true' : null,
            Glosa: $('#glosa').val(),
            OrdenPor: ordenActual,
            DireccionOrden: direccionOrden.toUpperCase(),
            Pagina: 1,
            TamañoPagina: 100
        };
    }

    function mostrarMovimientos(datos) {
        const tbody = $('#gridBody');
        tbody.empty();

        if (datos.length === 0) {
            tbody.append('<tr><td colspan="12" class="text-center">No se encontraron movimientos</td></tr>');
            return;
        }

        datos.forEach(function(item) {
            const row = `
                <tr>
                    <td>${formatearFechaHora(item.fechaHora)}</td>
                    <td>${item.orden}</td>
                    <td>${item.descripcionCuenta}</td>
                    <td class="text-right">${formatearNumero(item.debe)}</td>
                    <td class="text-right">${formatearNumero(item.haber)}</td>
                    <td>${item.glosa}</td>
                    <td>${item.cCosto}</td>
                    <td>${item.areaNeg}</td>
                    <td><span class="badge badge-${item.vigente === 'VIGENTE' ? 'success' : 'danger'}">${item.vigente}</span></td>
                    <td><span class="badge badge-${item.formaIngreso === 1 ? 'primary' : 'info'}">${item.formaIngresoTexto}</span></td>
                    <td><span class="badge badge-${getAjusteClass(item.ajuste)}">${item.ajusteTexto}</span></td>
                    <td>
                        <button type="button" class="btn btn-sm btn-info" onclick="verDetalle(${item.idMov})">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button type="button" class="btn btn-sm btn-warning" onclick="verHistorial(${item.idMov})">
                            <i class="fas fa-history"></i>
                        </button>
                    </td>
                </tr>
            `;
            tbody.append(row);
        });
    }

    function ordenarPorColumna(columna) {
        if (ordenActual === columna) {
            direccionOrden = direccionOrden === 'desc' ? 'asc' : 'desc';
        } else {
            ordenActual = columna;
            direccionOrden = 'desc';
        }

        // Actualizar indicadores visuales
        $('#gridMovimientos th[data-sort]').removeClass('sort-asc sort-desc');
        const th = $(`#gridMovimientos th[data-sort="${columna}"]`);
        th.addClass(direccionOrden === 'asc' ? 'sort-asc' : 'sort-desc');

        // Re-buscar con nuevo ordenamiento
        buscar();
    }

    function verDetalle(idMov) {
        mostrarCargando('Cargando detalle...');

        $.ajax({
            url: `/SeguimientoMovimientos/GetDetalleMovimiento/${idMov}`,
            type: 'GET',
            success: function(response) {
                if (response.success) {
                    mostrarDetalleMovimiento(response.detalle);
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al obtener detalle del movimiento');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function mostrarDetalleMovimiento(detalle) {
        const content = `
            <div class="row">
                <div class="col-md-6">
                    <h6>Información del Movimiento</h6>
                    <table class="table table-sm">
                        <tr><td><strong>ID Movimiento:</strong></td><td>${detalle.idMov}</td></tr>
                        <tr><td><strong>Fecha y Hora:</strong></td><td>${formatearFechaHora(detalle.fechaHora)}</td></tr>
                        <tr><td><strong>Comprobante:</strong></td><td>${detalle.correlativoComp}</td></tr>
                        <tr><td><strong>Orden:</strong></td><td>${detalle.orden}</td></tr>
                        <tr><td><strong>Cuenta:</strong></td><td>${detalle.codigoCuenta} - ${detalle.descripcionCuenta}</td></tr>
                        <tr><td><strong>Debe:</strong></td><td>${formatearNumero(detalle.debe)}</td></tr>
                        <tr><td><strong>Haber:</strong></td><td>${formatearNumero(detalle.haber)}</td></tr>
                        <tr><td><strong>Glosa:</strong></td><td>${detalle.glosa}</td></tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <h6>Información Adicional</h6>
                    <table class="table table-sm">
                        <tr><td><strong>Centro Costo:</strong></td><td>${detalle.centroCosto}</td></tr>
                        <tr><td><strong>Área Negocio:</strong></td><td>${detalle.areaNegocio}</td></tr>
                        <tr><td><strong>Cartola:</strong></td><td>${detalle.cartola}</td></tr>
                        <tr><td><strong>Centralización:</strong></td><td>${detalle.centralizacion}</td></tr>
                        <tr><td><strong>Pago:</strong></td><td>${detalle.pago}</td></tr>
                        <tr><td><strong>Remuneraciones:</strong></td><td>${detalle.remuneraciones}</td></tr>
                        <tr><td><strong>Nota:</strong></td><td>${detalle.nota}</td></tr>
                        <tr><td><strong>Vigente:</strong></td><td>${detalle.vigente}</td></tr>
                        <tr><td><strong>Forma Ingreso:</strong></td><td>${detalle.formaIngreso}</td></tr>
                        <tr><td><strong>Ajuste:</strong></td><td>${detalle.ajuste}</td></tr>
                    </table>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-12">
                    <h6>Historial de Cambios</h6>
                    <div class="table-responsive">
                        <table class="table table-sm table-striped">
                            <thead>
                                <tr>
                                    <th>Fecha y Hora</th>
                                    <th>Usuario</th>
                                    <th>Operación</th>
                                    <th>Campo</th>
                                    <th>Valor Anterior</th>
                                    <th>Valor Nuevo</th>
                                    <th>Observaciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${detalle.historial.map(hist => `
                                    <tr>
                                        <td>${formatearFechaHora(hist.fechaHora)}</td>
                                        <td>${hist.usuario}</td>
                                        <td>${hist.operacion}</td>
                                        <td>${hist.campo}</td>
                                        <td>${hist.valorAnterior}</td>
                                        <td>${hist.valorNuevo}</td>
                                        <td>${hist.observaciones}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;

        $('#detalleContent').html(content);
        $('#modalDetalle').modal('show');
    }

    function verHistorial(idMov) {
        mostrarCargando('Cargando historial...');

        $.ajax({
            url: `/SeguimientoMovimientos/GetHistorialMovimiento/${idMov}`,
            type: 'GET',
            success: function(response) {
                if (response.success) {
                    mostrarHistorialMovimiento(response.historial);
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al obtener historial del movimiento');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function mostrarHistorialMovimiento(historial) {
        const content = `
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Fecha y Hora</th>
                            <th>Usuario</th>
                            <th>Operación</th>
                            <th>Detalle</th>
                            <th>Observaciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${historial.map(hist => `
                            <tr>
                                <td>${formatearFechaHora(hist.fechaHora)}</td>
                                <td>${hist.usuario}</td>
                                <td><span class="badge badge-info">${hist.operacion}</span></td>
                                <td>${hist.detalle}</td>
                                <td>${hist.observaciones}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;

        $('#detalleContent').html(content);
        $('#modalDetalle').modal('show');
    }

    function mostrarResumen() {
        const idComp = $('#idComp').val();
        if (!idComp) {
            mostrarError('Debe especificar un ID de comprobante');
            return;
        }

        mostrarCargando('Cargando resumen...');

        $.ajax({
            url: `/SeguimientoMovimientos/GetResumenComprobante/${idComp}`,
            type: 'GET',
            success: function(response) {
                if (response.success) {
                    mostrarResumenModal(response.resumen);
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al obtener resumen del comprobante');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function mostrarResumenModal(resumen) {
        const content = `
            <div class="row">
                <div class="col-md-6">
                    <h6>Información General</h6>
                    <table class="table table-sm">
                        <tr><td><strong>ID Comprobante:</strong></td><td>${resumen.idComp}</td></tr>
                        <tr><td><strong>Correlativo:</strong></td><td>${resumen.correlativo}</td></tr>
                        <tr><td><strong>Fecha:</strong></td><td>${formatearFecha(resumen.fecha)}</td></tr>
                        <tr><td><strong>Tipo:</strong></td><td>${resumen.tipo}</td></tr>
                        <tr><td><strong>Estado:</strong></td><td>${resumen.estado}</td></tr>
                        <tr><td><strong>Glosa:</strong></td><td>${resumen.glosa}</td></tr>
                        <tr><td><strong>Total Debe:</strong></td><td>${formatearNumero(resumen.totalDebe)}</td></tr>
                        <tr><td><strong>Total Haber:</strong></td><td>${formatearNumero(resumen.totalHaber)}</td></tr>
                        <tr><td><strong>Total Movimientos:</strong></td><td>${resumen.totalMovimientos}</td></tr>
                        <tr><td><strong>Movimientos Vigentes:</strong></td><td>${resumen.movimientosVigentes}</td></tr>
                        <tr><td><strong>Movimientos Eliminados:</strong></td><td>${resumen.movimientosEliminados}</td></tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <h6>Resumen por Cuenta</h6>
                    <div class="table-responsive">
                        <table class="table table-sm table-striped">
                            <thead>
                                <tr>
                                    <th>Cuenta</th>
                                    <th>Debe</th>
                                    <th>Haber</th>
                                    <th>Cantidad</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${resumen.porCuenta.map(cuenta => `
                                    <tr>
                                        <td>${cuenta.codigoCuenta} - ${cuenta.descripcionCuenta}</td>
                                        <td class="text-right">${formatearNumero(cuenta.totalDebe)}</td>
                                        <td class="text-right">${formatearNumero(cuenta.totalHaber)}</td>
                                        <td class="text-center">${cuenta.cantidadMovimientos}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;

        $('#resumenModalContent').html(content);
        $('#modalResumen').modal('show');
    }

    function mostrarEstadisticas() {
        const idComp = $('#idComp').val();
        if (!idComp) {
            mostrarError('Debe especificar un ID de comprobante');
            return;
        }

        mostrarCargando('Cargando estadísticas...');

        $.ajax({
            url: `/SeguimientoMovimientos/GetEstadisticas/${idComp}`,
            type: 'GET',
            success: function(response) {
                if (response.success) {
                    mostrarEstadisticasModal(response.estadisticas);
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al obtener estadísticas');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function mostrarEstadisticasModal(estadisticas) {
        const content = `
            <div class="row">
                <div class="col-md-3">
                    <div class="card bg-primary text-white">
                        <div class="card-body text-center">
                            <h4>${estadisticas.totalMovimientos}</h4>
                            <p>Total Movimientos</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-success text-white">
                        <div class="card-body text-center">
                            <h4>${estadisticas.movimientosVigentes}</h4>
                            <p>Vigentes</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-danger text-white">
                        <div class="card-body text-center">
                            <h4>${estadisticas.movimientosEliminados}</h4>
                            <p>Eliminados</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-info text-white">
                        <div class="card-body text-center">
                            <h4>${estadisticas.totalCuentas}</h4>
                            <p>Cuentas</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-md-6">
                    <div class="card bg-light">
                        <div class="card-body text-center">
                            <h5>Total Debe</h5>
                            <h3>${formatearNumero(estadisticas.totalDebe)}</h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card bg-light">
                        <div class="card-body text-center">
                            <h5>Total Haber</h5>
                            <h3>${formatearNumero(estadisticas.totalHaber)}</h3>
                        </div>
                    </div>
                </div>
            </div>
        `;

        $('#estadisticasModalContent').html(content);
        $('#modalEstadisticas').modal('show');
    }

    function exportarExcel() {
        const filtros = obtenerFiltros();
        
        if (!filtros.IdComp) {
            mostrarError('Debe especificar un ID de comprobante');
            return;
        }

        mostrarCargando('Exportando a Excel...');

        $.ajax({
            url: '/SeguimientoMovimientos/ExportExcel',
            type: 'POST',
            data: JSON.stringify(filtros),
            contentType: 'application/json',
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                if (response.success) {
                    descargarArchivo(response.data, 'SeguimientoMovimientos.xlsx');
                    mostrarExito('Archivo Excel exportado exitosamente');
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al exportar a Excel');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function exportarPDF() {
        const filtros = obtenerFiltros();
        
        if (!filtros.IdComp) {
            mostrarError('Debe especificar un ID de comprobante');
            return;
        }

        mostrarCargando('Exportando a PDF...');

        $.ajax({
            url: '/SeguimientoMovimientos/ExportPDF',
            type: 'POST',
            data: JSON.stringify(filtros),
            contentType: 'application/json',
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                if (response.success) {
                    descargarArchivo(response.data, 'SeguimientoMovimientos.pdf');
                    mostrarExito('Archivo PDF exportado exitosamente');
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al exportar a PDF');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function imprimir() {
        const filtros = obtenerFiltros();
        
        if (!filtros.IdComp) {
            mostrarError('Debe especificar un ID de comprobante');
            return;
        }

        mostrarCargando('Generando datos para impresión...');

        $.ajax({
            url: '/SeguimientoMovimientos/Print',
            type: 'POST',
            data: JSON.stringify(filtros),
            contentType: 'application/json',
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                if (response.success) {
                    imprimirDatos(response.data);
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al generar datos para impresión');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function imprimirDatos(datos) {
        const ventanaImpresion = window.open('', '_blank');
        const contenido = `
            <html>
                <head>
                    <title>${datos.titulo}</title>
                    <style>
                        body { font-family: Arial, sans-serif; font-size: 12px; }
                        table { width: 100%; border-collapse: collapse; }
                        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                        th { background-color: #f2f2f2; }
                        .text-right { text-align: right; }
                        .text-center { text-align: center; }
                    </style>
                </head>
                <body>
                    <h2>${datos.titulo}</h2>
                    <p><strong>Fecha de Generación:</strong> ${formatearFechaHora(datos.fechaGeneracion)}</p>
                    <p><strong>Total de Movimientos:</strong> ${datos.totalRegistros}</p>
                    <table>
                        <thead>
                            <tr>
                                <th>Fecha y Hora</th>
                                <th>Orden</th>
                                <th>Cuenta</th>
                                <th>Debe</th>
                                <th>Haber</th>
                                <th>Glosa</th>
                                <th>Centro Costo</th>
                                <th>Área Negocio</th>
                                <th>Vigente</th>
                                <th>Forma Ingreso</th>
                                <th>Ajuste</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${datos.datos.map(item => `
                                <tr>
                                    <td>${formatearFechaHora(item.fechaHora)}</td>
                                    <td>${item.orden}</td>
                                    <td>${item.descripcionCuenta}</td>
                                    <td class="text-right">${formatearNumero(item.debe)}</td>
                                    <td class="text-right">${formatearNumero(item.haber)}</td>
                                    <td>${item.glosa}</td>
                                    <td>${item.cCosto}</td>
                                    <td>${item.areaNeg}</td>
                                    <td>${item.vigente}</td>
                                    <td>${item.formaIngresoTexto}</td>
                                    <td>${item.ajusteTexto}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </body>
            </html>
        `;
        
        ventanaImpresion.document.write(contenido);
        ventanaImpresion.document.close();
        ventanaImpresion.print();
    }

    function descargarArchivo(data, nombreArchivo) {
        const blob = new Blob([data], { type: 'application/octet-stream' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = nombreArchivo;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    }

    // Funciones de utilidad
    function formatearFecha(fecha) {
        return new Date(fecha).toLocaleDateString('es-CL');
    }

    function formatearFechaHora(fecha) {
        return new Date(fecha).toLocaleString('es-CL');
    }

    function formatearNumero(numero) {
        return new Intl.NumberFormat('es-CL').format(numero);
    }

    function getAjusteClass(ajuste) {
        switch(ajuste) {
            case 1: return 'success'; // Creado
            case 2: return 'warning'; // Modificado
            case 3: return 'danger';  // Eliminado
            default: return 'secondary';
        }
    }

    function mostrarCargando(mensaje) {
        // Implementar indicador de carga
        console.log('Cargando: ' + mensaje);
    }

    function ocultarCargando() {
        // Ocultar indicador de carga
        console.log('Carga completada');
    }

    function mostrarError(mensaje) {
        toastr.error(mensaje);
    }

    function mostrarExito(mensaje) {
        toastr.success(mensaje);
    }

    function mostrarInfo(mensaje) {
        toastr.info(mensaje);
    }
});









