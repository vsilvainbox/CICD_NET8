/**
 * Funcionalidad para importación de otros documentos completa (ODF)
 */
var ImportarOtrosDocsCompleta = {
    // Configuración
    config: {
        urls: {
            seleccionarArchivo: '/ImportarOtrosDocsCompleta/SeleccionarArchivo',
            importar: '/ImportarOtrosDocsCompleta/Importar',
            getFormato: '/ImportarOtrosDocsCompleta/GetFormatoArchivo',
            descargarEjemplo: '/ImportarOtrosDocsCompleta/DescargarEjemplo',
            getLog: '/ImportarOtrosDocsCompleta/GetLogImportacion',
            descargarLog: '/ImportarOtrosDocsCompleta/DescargarLog',
            getEstadisticas: '/ImportarOtrosDocsCompleta/GetEstadisticasImportacion',
            validarConfiguracion: '/ImportarOtrosDocsCompleta/ValidarConfiguracion',
            getTiposDocumento: '/ImportarOtrosDocsCompleta/GetTiposDocumento',
            getConfiguracion: '/ImportarOtrosDocsCompleta/GetConfiguracionImportacion',
            getTratamientos: '/ImportarOtrosDocsCompleta/GetTratamientosDisponibles'
        },
        selectors: {
            formSeleccionArchivo: '#formSeleccionArchivo',
            fileArchivo: '#fileArchivo',
            txtNombreArchivo: '#txtNombreArchivo',
            btnSeleccionarArchivo: '#btnSeleccionarArchivo',
            btnImportar: '#btnImportar',
            btnVerFormato: '#btnVerFormato',
            btnCerrarFormato: '#btnCerrarFormato',
            btnDescargarEjemplo: '#btnDescargarEjemplo',
            panelFormato: '#panelFormato',
            panelProgreso: '#panelProgreso',
            panelResultados: '#panelResultados',
            panelErrores: '#panelErrores',
            panelConfiguracion: '#panelConfiguracion',
            barraProgreso: '#barraProgreso',
            mensajeProgreso: '#mensajeProgreso',
            tbodyFormato: '#tbodyFormato',
            ejemploLinea: '#ejemploLinea',
            tbodyErrores: '#tbodyErrores',
            documentosODFCreados: '#documentosODFCreados',
            documentosODFActualizados: '#documentosODFActualizados',
            erroresEncontrados: '#erroresEncontrados',
            tiempoProcesamiento: '#tiempoProcesamiento',
            mensajeResultado: '#mensajeResultado',
            btnConfiguracion: '#btnConfiguracion',
            btnEstadisticas: '#btnEstadisticas',
            btnLogs: '#btnLogs',
            btnCerrar: '#btnCerrar'
        }
    },

    // Estado actual
    estado: {
        archivoSeleccionado: null,
        validacionArchivo: null,
        formatoArchivo: null,
        estaProcesando: false,
        resultadoImportacion: null
    },

    /**
     * Inicializar la funcionalidad
     */
    init: function() {
        this.bindEvents();
        this.cargarConfiguracion();
        this.cargarFormatoArchivo();
    },

    /**
     * Vincular eventos
     */
    bindEvents: function() {
        var self = this;

        // Selección de archivo
        $(this.config.selectors.btnSeleccionarArchivo).on('click', function() {
            $(self.config.selectors.fileArchivo).click();
        });

        $(this.config.selectors.fileArchivo).on('change', function() {
            self.seleccionarArchivo(this.files[0]);
        });

        // Importación
        $(this.config.selectors.btnImportar).on('click', function() {
            self.importarDocumentosODF();
        });

        // Formato de archivo
        $(this.config.selectors.btnVerFormato).on('click', function() {
            self.mostrarFormatoArchivo();
        });

        $(this.config.selectors.btnCerrarFormato).on('click', function() {
            self.ocultarFormatoArchivo();
        });

        $(this.config.selectors.btnDescargarEjemplo).on('click', function() {
            self.descargarArchivoEjemplo();
        });

        // Paneles
        $(this.config.selectors.btnConfiguracion).on('click', function() {
            self.togglePanel('configuracion');
        });

        $(this.config.selectors.btnEstadisticas).on('click', function() {
            self.togglePanel('estadisticas');
            self.cargarEstadisticas();
        });

        $(this.config.selectors.btnLogs).on('click', function() {
            self.mostrarLogs();
        });

        $(this.config.selectors.btnCerrar).on('click', function() {
            self.cerrar();
        });
    },

    /**
     * Seleccionar archivo
     */
    seleccionarArchivo: function(archivo) {
        if (!archivo) return;

        this.estado.archivoSeleccionado = archivo;
        $(this.config.selectors.txtNombreArchivo).val(archivo.name);

        // Validar archivo
        this.validarArchivo(archivo);
    },

    /**
     * Validar archivo
     */
    validarArchivo: function(archivo) {
        var self = this;
        var formData = new FormData();
        formData.append('archivo', archivo);

        $.ajax({
            url: this.config.urls.seleccionarArchivo,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    self.estado.validacionArchivo = response.validacion;
                    $(self.config.selectors.btnImportar).prop('disabled', false);
                    self.mostrarMensaje('Archivo válido para importación ODF', 'success');
                } else {
                    self.estado.validacionArchivo = response.validacion;
                    $(self.config.selectors.btnImportar).prop('disabled', true);
                    self.mostrarMensaje(response.message, 'error');
                }
            },
            error: function(xhr, status, error) {
                self.mostrarMensaje('Error al validar archivo', 'error');
            }
        });
    },

    /**
     * Importar documentos ODF
     */
    importarDocumentosODF: function() {
        if (!this.estado.archivoSeleccionado) {
            this.mostrarMensaje('Debe seleccionar un archivo', 'error');
            return;
        }

        var self = this;
        var formData = new FormData();
        formData.append('Archivo', this.estado.archivoSeleccionado);
        formData.append('ValidarAntesImportar', $('#chkValidarAntesImportar').is(':checked'));
        formData.append('CrearEntidadesAutomaticamente', $('#chkCrearEntidadesAutomaticamente').is(':checked'));
        formData.append('ActualizarDocumentosExistentes', $('#chkActualizarDocumentosExistentes').is(':checked'));
        formData.append('ActualizarEntidadesExistentes', $('#chkActualizarEntidadesExistentes').is(':checked'));
        formData.append('RegistrarSeguimiento', $('#chkRegistrarSeguimiento').is(':checked'));
        formData.append('TratamientoPorDefecto', $('#cmbTratamientoPorDefecto').val());

        this.estado.estaProcesando = true;
        this.mostrarPanelProgreso();
        this.actualizarProgreso(0, 'Iniciando importación ODF...');

        $.ajax({
            url: this.config.urls.importar,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                self.estado.estaProcesando = false;
                self.ocultarPanelProgreso();
                
                if (response.success) {
                    self.estado.resultadoImportacion = response.resultado;
                    self.mostrarResultados(response.resultado);
                    self.mostrarMensaje('Importación ODF completada exitosamente', 'success');
                } else {
                    self.mostrarMensaje(response.message, 'error');
                }
            },
            error: function(xhr, status, error) {
                self.estado.estaProcesando = false;
                self.ocultarPanelProgreso();
                self.mostrarMensaje('Error durante la importación ODF', 'error');
            }
        });
    },

    /**
     * Mostrar formato de archivo
     */
    mostrarFormatoArchivo: function() {
        if (this.estado.formatoArchivo) {
            this.renderizarFormatoArchivo();
            $(this.config.selectors.panelFormato).show();
        } else {
            this.cargarFormatoArchivo();
        }
    },

    /**
     * Ocultar formato de archivo
     */
    ocultarFormatoArchivo: function() {
        $(this.config.selectors.panelFormato).hide();
    },

    /**
     * Cargar formato de archivo
     */
    cargarFormatoArchivo: function() {
        var self = this;

        $.ajax({
            url: this.config.urls.getFormato,
            type: 'GET',
            success: function(response) {
                if (response.success) {
                    self.estado.formatoArchivo = response.formato;
                    self.renderizarFormatoArchivo();
                }
            },
            error: function(xhr, status, error) {
                self.mostrarMensaje('Error al cargar formato de archivo ODF', 'error');
            }
        });
    },

    /**
     * Renderizar formato de archivo
     */
    renderizarFormatoArchivo: function() {
        if (!this.estado.formatoArchivo) return;

        var tbody = $(this.config.selectors.tbodyFormato);
        tbody.empty();

        this.estado.formatoArchivo.campos.forEach(function(campo) {
            var row = $('<tr>');
            row.append($('<td>').text(campo.orden));
            row.append($('<td>').text(campo.nombre));
            row.append($('<td>').text(campo.descripcion));
            row.append($('<td>').text(campo.tipoDato));
            row.append($('<td>').html(campo.obligatorio ? '<span class="badge bg-danger">Sí</span>' : '<span class="badge bg-secondary">No</span>'));
            
            var formato = '';
            if (campo.formato) {
                formato = campo.formato;
            } else if (campo.valoresPermitidos && campo.valoresPermitidos.length > 0) {
                formato = campo.valoresPermitidos.join(', ');
            }
            row.append($('<td>').text(formato));
            row.append($('<td>').text(campo.ejemploValor || ''));
            
            var notas = '';
            if (campo.seIgnora) {
                notas = 'Se ignora - se fuerza "' + campo.valorPorDefecto + '"';
            }
            row.append($('<td>').text(notas));
            
            tbody.append(row);
        });

        $(this.config.selectors.ejemploLinea).text(this.estado.formatoArchivo.ejemploLinea);
    },

    /**
     * Descargar archivo de ejemplo
     */
    descargarArchivoEjemplo: function() {
        window.location.href = this.config.urls.descargarEjemplo;
    },

    /**
     * Mostrar panel de progreso
     */
    mostrarPanelProgreso: function() {
        $(this.config.selectors.panelProgreso).show();
    },

    /**
     * Ocultar panel de progreso
     */
    ocultarPanelProgreso: function() {
        $(this.config.selectors.panelProgreso).hide();
    },

    /**
     * Actualizar progreso
     */
    actualizarProgreso: function(porcentaje, mensaje) {
        $(this.config.selectors.barraProgreso).css('width', porcentaje + '%').text(porcentaje + '%');
        $(this.config.selectors.mensajeProgreso).text(mensaje);
    },

    /**
     * Mostrar resultados
     */
    mostrarResultados: function(resultado) {
        $(this.config.selectors.documentosODFCreados).text(resultado.documentosODFCreados);
        $(this.config.selectors.documentosODFActualizados).text(resultado.documentosODFActualizados);
        $(this.config.selectors.erroresEncontrados).text(resultado.erroresEncontrados);
        $(this.config.selectors.tiempoProcesamiento).text(resultado.tiempoProcesamiento.toFixed(2));
        $(this.config.selectors.mensajeResultado).text(resultado.mensaje);

        $(this.config.selectors.panelResultados).show();

        if (resultado.erroresDetallados && resultado.erroresDetallados.length > 0) {
            this.mostrarErrores(resultado.erroresDetallados);
        }
    },

    /**
     * Mostrar errores
     */
    mostrarErrores: function(errores) {
        var tbody = $(this.config.selectors.tbodyErrores);
        tbody.empty();

        errores.forEach(function(error) {
            var row = $('<tr>');
            row.append($('<td>').text(error.numeroLinea));
            row.append($('<td>').text(error.campo));
            row.append($('<td>').text(error.mensaje));
            row.append($('<td>').text(error.tipo));
            tbody.append(row);
        });

        $(this.config.selectors.panelErrores).show();
    },

    /**
     * Cargar configuración
     */
    cargarConfiguracion: function() {
        var self = this;

        $.ajax({
            url: this.config.urls.getConfiguracion,
            type: 'GET',
            success: function(response) {
                if (response.success) {
                    self.configurarOpciones(response.configuracion);
                }
            },
            error: function(xhr, status, error) {
                console.error('Error al cargar configuración ODF:', error);
            }
        });
    },

    /**
     * Configurar opciones
     */
    configurarOpciones: function(configuracion) {
        $('#chkValidarAntesImportar').prop('checked', configuracion.requiereValidacionPrevia);
        $('#chkCrearEntidadesAutomaticamente').prop('checked', configuracion.crearEntidadesAutomaticamente);
        $('#chkActualizarDocumentosExistentes').prop('checked', configuracion.actualizarDocumentosExistentes);
        $('#chkActualizarEntidadesExistentes').prop('checked', configuracion.actualizarEntidadesExistentes);
        $('#chkRegistrarSeguimiento').prop('checked', configuracion.registrarSeguimiento);
        $('#cmbTratamientoPorDefecto').val(configuracion.tratamientoPorDefecto);
    },

    /**
     * Cargar estadísticas
     */
    cargarEstadisticas: function() {
        var self = this;

        $.ajax({
            url: this.config.urls.getEstadisticas,
            type: 'GET',
            success: function(response) {
                if (response.success) {
                    self.mostrarEstadisticas(response.estadisticas);
                }
            },
            error: function(xhr, status, error) {
                self.mostrarMensaje('Error al cargar estadísticas ODF', 'error');
            }
        });
    },

    /**
     * Mostrar estadísticas
     */
    mostrarEstadisticas: function(estadisticas) {
        // Implementar visualización de estadísticas ODF
        console.log('Estadísticas ODF:', estadisticas);
    },

    /**
     * Mostrar logs
     */
    mostrarLogs: function() {
        var self = this;

        $.ajax({
            url: this.config.urls.getLog,
            type: 'GET',
            data: { fecha: new Date().toISOString().split('T')[0] },
            success: function(response) {
                if (response.success) {
                    self.mostrarMensaje('Log ODF cargado exitosamente', 'info');
                }
            },
            error: function(xhr, status, error) {
                self.mostrarMensaje('Error al cargar logs ODF', 'error');
            }
        });
    },

    /**
     * Toggle panel
     */
    togglePanel: function(panel) {
        var selector = '#panel' + panel.charAt(0).toUpperCase() + panel.slice(1);
        $(selector).toggle();
    },

    /**
     * Cerrar
     */
    cerrar: function() {
        if (this.estado.estaProcesando) {
            if (!confirm('Hay una importación ODF en progreso. ¿Desea cerrar de todos modos?')) {
                return;
            }
        }
        
        window.close();
    },

    /**
     * Mostrar mensaje
     */
    mostrarMensaje: function(mensaje, tipo) {
        if (typeof toastr !== 'undefined') {
            switch (tipo) {
                case 'success':
                    toastr.success(mensaje);
                    break;
                case 'error':
                    toastr.error(mensaje);
                    break;
                case 'warning':
                    toastr.warning(mensaje);
                    break;
                case 'info':
                    toastr.info(mensaje);
                    break;
                default:
                    toastr.info(mensaje);
            }
        } else {
            alert(mensaje);
        }
    }
};









