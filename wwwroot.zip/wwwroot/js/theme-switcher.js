/**
 * HyperContabilidad Theme Switcher
 * Permite cambiar dinámicamente el color primario de la aplicación
 */

const themes = {
  green: {
    name: 'Verde Esmeralda',
    description: 'Profesional y financiero',
    colors: {
      '25': '#f0fdf4',
      '50': '#dcfce7',
      '100': '#bbf7d0',
      '200': '#86efac',
      '300': '#4ade80',
      '400': '#22c55e',
      '500': '#16a34a',
      '600': '#15803d',
      '700': '#166534',
      '800': '#14532d',
      '900': '#14532d',
      '950': '#052e16'
    }
  },
  blue: {
    name: 'Azul Original',
    description: 'Tema por defecto TailAdmin',
    colors: {
      '25': '#f2f7ff',
      '50': '#ecf3ff',
      '100': '#dde9ff',
      '200': '#c2d6ff',
      '300': '#9cb9ff',
      '400': '#7592ff',
      '500': '#465fff',
      '600': '#3641f5',
      '700': '#2a31d8',
      '800': '#252dae',
      '900': '#262e89',
      '950': '#161950'
    }
  },
  orange: {
    name: 'Naranja Energético',
    description: 'Dinámico y activo',
    colors: {
      '25': '#fffaf0',
      '50': '#ffedd5',
      '100': '#fed7aa',
      '200': '#fdba74',
      '300': '#fb923c',
      '400': '#f97316',
      '500': '#ea580c',
      '600': '#c2410c',
      '700': '#9a3412',
      '800': '#7c2d12',
      '900': '#431407',
      '950': '#1a0a03'
    }
  },
  purple: {
    name: 'Morado Premium',
    description: 'Creativo y elegante',
    colors: {
      '25': '#faf5ff',
      '50': '#f3e8ff',
      '100': '#e9d5ff',
      '200': '#d8b4fe',
      '300': '#c084fc',
      '400': '#a855f7',
      '500': '#9333ea',
      '600': '#7e22ce',
      '700': '#6b21a8',
      '800': '#581c87',
      '900': '#3b0764',
      '950': '#1e0435'
    }
  },
  teal: {
    name: 'Teal Corporativo',
    description: 'Confianza y profesionalismo',
    colors: {
      '25': '#f0fdfa',
      '50': '#ccfbf1',
      '100': '#99f6e4',
      '200': '#5eead4',
      '300': '#2dd4bf',
      '400': '#14b8a6',
      '500': '#0d9488',
      '600': '#0f766e',
      '700': '#115e59',
      '800': '#134e4a',
      '900': '#042f2e',
      '950': '#022020'
    }
  },
  indigo: {
    name: 'Índigo Tech',
    description: 'Tecnológico y corporativo',
    colors: {
      '25': '#f5f7ff',
      '50': '#eef2ff',
      '100': '#e0e7ff',
      '200': '#c7d2fe',
      '300': '#a5b4fc',
      '400': '#818cf8',
      '500': '#6366f1',
      '600': '#4f46e5',
      '700': '#4338ca',
      '800': '#3730a3',
      '900': '#312e81',
      '950': '#1e1b4b'
    }
  }
};

/**
 * Aplica un tema cambiando las variables CSS
 * @param {string} themeName - Nombre del tema (green, blue, orange, etc.)
 */
function applyTheme(themeName) {
  const theme = themes[themeName];
  if (!theme) {
    console.error(`Tema "${themeName}" no encontrado`);
    return;
  }

  const root = document.documentElement;

  // Aplicar cada tonalidad del color brand
  Object.entries(theme.colors).forEach(([shade, color]) => {
    root.style.setProperty(`--color-brand-${shade}`, color);
  });

  // Actualizar shadow con el nuevo color base (500)
  const baseColor = theme.colors['500'];
  const rgb = hexToRgb(baseColor);
  if (rgb) {
    root.style.setProperty(
      '--shadow-focus-ring',
      `0px 0px 0px 4px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.12)`
    );
  }

  // Guardar preferencia en localStorage
  localStorage.setItem('hypercontab-theme', themeName);

  // Dispatch evento para que otros componentes reaccionen
  window.dispatchEvent(new CustomEvent('themeChanged', { detail: { theme: themeName } }));

  console.log(`Tema "${theme.name}" aplicado correctamente`);
}

/**
 * Convierte color HEX a RGB
 * @param {string} hex - Color en formato #RRGGBB
 * @returns {{r: number, g: number, b: number}|null}
 */
function hexToRgb(hex) {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16)
  } : null;
}

/**
 * Carga el tema guardado en localStorage al iniciar
 */
function loadSavedTheme() {
  const savedTheme = localStorage.getItem('hypercontab-theme');
  if (savedTheme && themes[savedTheme]) {
    applyTheme(savedTheme);
  }
  // Si no hay tema guardado, se usa el definido en brand-colors.css
}

/**
 * Obtiene el tema actual
 * @returns {string}
 */
function getCurrentTheme() {
  return localStorage.getItem('hypercontab-theme') || 'green';
}

/**
 * Obtiene todos los temas disponibles
 * @returns {Object}
 */
function getAvailableThemes() {
  return themes;
}

// Auto-cargar tema al iniciar
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', loadSavedTheme);
} else {
  loadSavedTheme();
}

// Exportar funciones para uso global
window.ThemeSwitcher = {
  applyTheme,
  getCurrentTheme,
  getAvailableThemes,
  themes
};
