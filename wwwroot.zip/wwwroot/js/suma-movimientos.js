/**
 * SumaMovimientos - Componente JavaScript
 * Migrado desde: FrmSumMov.frm (VB6)
 * 
 * Modal reutilizable para mostrar estadísticas de suma y promedio de movimientos contables
 * NO requiere backend - es un componente de visualización puro
 */

/**
 * Muestra modal con estadísticas de suma de movimientos
 * Equivale a FrmSumMov.FView() en VB6
 * 
 * @param {Object} datos - Datos calculados para mostrar
 * @param {number} datos.nMov - Cantidad total de movimientos
 * @param {number} datos.nValDebe - Cantidad de valores Debe <> 0
 * @param {number} datos.nValHaber - Cantidad de valores Haber <> 0
 * @param {number} datos.sumDebe - Suma total de Debe
 * @param {number} datos.sumHaber - Suma total de Haber
 * @param {number} datos.promDebe - Promedio de Debe
 * @param {number} datos.promHaber - Promedio de Haber
 */
function mostrarSumaMovimientos(datos) {
    // Validar datos de entrada
    if (!datos || typeof datos !== 'object') {
        console.error('SumaMovimientos: datos requeridos');
        return;
    }

    // Calcular diferencias (como en VB6 Form_Load)
    const diffTotal = datos.sumDebe - datos.sumHaber;
    const diffPromedio = datos.promDebe - datos.promHaber;

    const htmlContent = `
        <div class="space-y-6">
            <!-- Cantidad de movimientos -->
            <div class="bg-gray-50 p-4 rounded-lg border">
                <div class="text-center">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Cantidad de Movimientos:</label>
                    <div class="text-2xl font-bold text-primary-600">${formatNumber(datos.nMov, 0)}</div>
                </div>
            </div>

            <!-- Suma de Movimientos -->
            <div class="border border-gray-200 rounded-lg p-4">
                <h3 class="text-lg font-bold text-primary-600 mb-4 text-center">Suma de Movimientos</h3>
                <div class="grid grid-cols-3 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Debe:</label>
                        <input type="text" readonly value="${formatNumber(datos.sumDebe)}"
                               class="w-full px-3 py-2 bg-gray-100 border border-gray-300 rounded text-right font-mono">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Haber:</label>
                        <input type="text" readonly value="${formatNumber(datos.sumHaber)}"
                               class="w-full px-3 py-2 bg-gray-100 border border-gray-300 rounded text-right font-mono">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Total:</label>
                        <input type="text" readonly value="${formatNumber(diffTotal)}"
                               class="w-full px-3 py-2 bg-gray-100 border border-gray-300 rounded text-right font-mono font-bold ${diffTotal !== 0 ? 'text-red-600' : 'text-green-600'}">
                    </div>
                </div>
            </div>

            <!-- Promedio de Movimientos -->
            <div class="border border-gray-200 rounded-lg p-4">
                <h3 class="text-lg font-bold text-primary-600 mb-4 text-center">Promedio de Movimientos</h3>
                <div class="grid grid-cols-3 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Debe:</label>
                        <input type="text" readonly value="${formatNumber(datos.promDebe)}"
                               class="w-full px-3 py-2 bg-gray-100 border border-gray-300 rounded text-right font-mono">
                        <div class="text-xs text-gray-500 mt-1 text-center">Valores ≠ 0: ${formatNumber(datos.nValDebe, 0)}</div>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Haber:</label>
                        <input type="text" readonly value="${formatNumber(datos.promHaber)}"
                               class="w-full px-3 py-2 bg-gray-100 border border-gray-300 rounded text-right font-mono">
                        <div class="text-xs text-gray-500 mt-1 text-center">Valores ≠ 0: ${formatNumber(datos.nValHaber, 0)}</div>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Total:</label>
                        <input type="text" readonly value="${formatNumber(diffPromedio)}"
                               class="w-full px-3 py-2 bg-gray-100 border border-gray-300 rounded text-right font-mono font-bold ${diffPromedio !== 0 ? 'text-red-600' : 'text-green-600'}">
                    </div>
                </div>
            </div>
        </div>
    `;

    // Mostrar modal (equivale a mostrar Form modal en VB6)
    Swal.fire({
        title: '<i class="fas fa-calculator text-primary-600 mr-2"></i>Suma de Movimientos',
        html: htmlContent,
        width: '850px',
        showCloseButton: true,
        confirmButtonText: '<i class="fas fa-times mr-2"></i>Cerrar',
        confirmButtonColor: '#d64000',
        customClass: {
            confirmButton: 'px-6 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors',
            popup: 'rounded-lg shadow-xl'
        },
        buttonsStyling: false
    });
}

/**
 * Calcula estadísticas desde una grilla de datos
 * Equivale a FrmSumMov.FViewSum() en VB6
 * 
 * @param {Array} filas - Array de objetos/arrays con datos de las filas
 * @param {string|number} colDebe - Índice o key de la columna Debe
 * @param {string|number} colHaber - Índice o key de la columna Haber
 * @param {number} [firstRow] - Primera fila a considerar (opcional)
 * @param {number} [lastRow] - Última fila a considerar (opcional)
 * @returns {Object} Datos calculados para mostrarSumaMovimientos()
 */
function calcularSumaDesdeGrilla(filas, colDebe, colHaber, firstRow = 0, lastRow = null) {
    if (!Array.isArray(filas) || filas.length === 0) {
        console.warn('SumaMovimientos: Array de filas vacío o inválido');
        return {
            nMov: 0, nValDebe: 0, nValHaber: 0,
            sumDebe: 0, sumHaber: 0,
            promDebe: 0, promHaber: 0
        };
    }

    // Determinar rango de filas (como en VB6)
    const startRow = Math.max(0, firstRow || 0);
    const endRow = lastRow !== null ? Math.min(lastRow, filas.length - 1) : filas.length - 1;

    let sumDebe = 0;
    let sumHaber = 0;
    let nValDebe = 0;  // Contador de valores Debe <> 0
    let nValHaber = 0; // Contador de valores Haber <> 0
    let nMov = 0;      // Contador de movimientos procesados

    // Iterar filas en el rango especificado (como en VB6)
    for (let i = startRow; i <= endRow; i++) {
        if (i >= filas.length) break;
        
        const fila = filas[i];
        if (!fila) continue;

        // Obtener valores Debe y Haber (usando vFmt equivalente)
        const valorDebe = parseFloat(fila[colDebe]) || 0;
        const valorHaber = parseFloat(fila[colHaber]) || 0;

        // Acumular sumas
        sumDebe += valorDebe;
        sumHaber += valorHaber;

        // Contar valores diferentes de cero (para promedio)
        if (valorDebe !== 0) nValDebe++;
        if (valorHaber !== 0) nValHaber++;

        nMov++;
    }

    // Calcular promedios (con protección división por cero como en VB6)
    const promDebe = nValDebe > 0 ? sumDebe / nValDebe : 0;
    const promHaber = nValHaber > 0 ? sumHaber / nValHaber : 0;

    return {
        nMov,
        nValDebe,
        nValHaber,
        sumDebe,
        sumHaber,
        promDebe,
        promHaber
    };
}

/**
 * Formatea número con separadores de miles y formato de negativos
 * Equivale a Format(valor, NEGNUMFMT) en VB6
 * 
 * @param {number} valor - Número a formatear
 * @param {number} [decimales=2] - Cantidad de decimales
 * @returns {string} Número formateado
 */
function formatNumber(valor, decimales = 2) {
    if (valor === null || valor === undefined || isNaN(valor)) {
        return '0' + (decimales > 0 ? '.' + '0'.repeat(decimales) : '');
    }

    const esNegativo = valor < 0;
    const valorAbs = Math.abs(valor);
    
    // Formatear con separadores de miles y decimales
    const formatted = valorAbs.toLocaleString('es-CL', {
        minimumFractionDigits: decimales,
        maximumFractionDigits: decimales
    });

    // Formato VB6: negativos con paréntesis
    return esNegativo ? `(${formatted})` : formatted;
}

/**
 * Función helper para invocar desde botones en vistas
 * Ejemplo de uso en vistas que tienen grillas de movimientos
 * 
 * @param {string} [selectorGrilla] - Selector CSS de la tabla/grilla
 * @param {string} [colDebe='debe'] - Nombre de columna Debe
 * @param {string} [colHaber='haber'] - Nombre de columna Haber
 */
function mostrarEstadisticasGrilla(selectorGrilla = 'table tbody tr', colDebe = 'debe', colHaber = 'haber') {
    try {
        // Obtener filas visibles de la grilla
        const filas = [];
        const rows = document.querySelectorAll(selectorGrilla);
        
        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            if (cells.length > 0) {
                // Crear objeto con datos de la fila
                const fila = {};
                cells.forEach((cell, index) => {
                    const key = cell.dataset.column || index.toString();
                    fila[key] = cell.textContent.trim();
                });
                filas.push(fila);
            }
        });

        if (filas.length === 0) {
            Swal.fire({
                icon: 'warning',
                title: 'Sin datos',
                text: 'No hay movimientos para analizar',
                confirmButtonColor: '#d64000'
            });
            return;
        }

        // Calcular y mostrar estadísticas
        const datos = calcularSumaDesdeGrilla(filas, colDebe, colHaber);
        mostrarSumaMovimientos(datos);

    } catch (error) {
        console.error('Error al calcular estadísticas:', error);
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Error al calcular estadísticas de la grilla',
            confirmButtonColor: '#d64000'
        });
    }
}

// Hacer funciones disponibles globalmente
window.mostrarSumaMovimientos = mostrarSumaMovimientos;
window.calcularSumaDesdeGrilla = calcularSumaDesdeGrilla;
window.mostrarEstadisticasGrilla = mostrarEstadisticasGrilla;
window.formatNumber = formatNumber;