using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApplicationModels;

namespace App.Conventions;

/// <summary>
/// Convención automática para rutas de API Controllers
/// Convierte "XxxApiController" → "api/Xxx"
/// </summary>
public class ApiControllerConvention : IControllerModelConvention
{
    public void Apply(ControllerModel controller)
    {
        // Solo aplicar a controladores API (que heredan de ControllerBase)
        if (!typeof(ControllerBase).IsAssignableFrom(controller.ControllerType))
            return;

        // Solo aplicar a controladores que terminan en "ApiController"
        if (!controller.ControllerName.EndsWith("Api"))
            return;

        // Solo aplicar a controladores en namespace Features
        if (controller.ControllerType.Namespace?.Contains("Features") != true)
            return;

        // Obtener el nombre sin "Api"
        var featureName = controller.ControllerName.Replace("Api", "");

        // Crear la ruta automática (sin PathBase, se maneja automáticamente)
        var routeTemplate = $"api/{featureName}";
        
        // SWAGGER-COMPATIBLE: Modificar rutas existentes en lugar de eliminar/agregar
        foreach (var selector in controller.Selectors)
        {
            if (selector.AttributeRouteModel != null)
            {
                // Reemplazar [controller] con el nombre de la feature
                if (selector.AttributeRouteModel.Template?.Contains("[controller]") == true)
                {
                    selector.AttributeRouteModel.Template = routeTemplate;
                }
                // Si no hay template o no usa [controller], establecer la ruta automática
                else if (string.IsNullOrEmpty(selector.AttributeRouteModel.Template))
                {
                    selector.AttributeRouteModel.Template = routeTemplate;
                }
            }
            else
            {
                // Si no hay AttributeRouteModel, crearlo
                selector.AttributeRouteModel = new AttributeRouteModel
                {
                    Template = routeTemplate
                };
            }
        }
        
        // Si no hay selectores, agregar uno nuevo
        if (controller.Selectors.Count == 0)
        {
            controller.Selectors.Add(new SelectorModel
            {
                AttributeRouteModel = new AttributeRouteModel
                {
                    Template = routeTemplate
                }
            });
        }
        
        //Console.WriteLine($"🔧 API Route: {controller.ControllerType.Name} → {routeTemplate}");
    }
}
