using System.Text.Json;
using App.Models;

namespace App.Extensions;

/// <summary>
/// Extensiones para facilitar el trabajo con sesión de empresa seleccionada
/// </summary>
public static class SessionExtensions
{
    private const string EMPRESA_SELECCIONADA_KEY = "EmpresaSeleccionada";

    /// <summary>
    /// Guarda la empresa seleccionada en sesión
    /// </summary>
    public static void SetEmpresaSeleccionada(this ISession session, EmpresaSeleccionadaSession empresa)
    {
        var json = JsonSerializer.Serialize(empresa);
        session.SetString(EMPRESA_SELECCIONADA_KEY, json);
    }

    /// <summary>
    /// Obtiene la empresa seleccionada de la sesión
    /// </summary>
    public static EmpresaSeleccionadaSession? GetEmpresaSeleccionada(this ISession session)
    {
        var json = session.GetString(EMPRESA_SELECCIONADA_KEY);
        if (string.IsNullOrEmpty(json))
            return null;

        return JsonSerializer.Deserialize<EmpresaSeleccionadaSession>(json);
    }

    /// <summary>
    /// Elimina la empresa seleccionada de la sesión
    /// </summary>
    public static void RemoveEmpresaSeleccionada(this ISession session)
    {
        session.Remove(EMPRESA_SELECCIONADA_KEY);
    }

    /// <summary>
    /// Verifica si hay una empresa seleccionada en sesión
    /// </summary>
    public static bool HasEmpresaSeleccionada(this ISession session)
    {
        return session.GetString(EMPRESA_SELECCIONADA_KEY) != null;
    }

    /// <summary>
    /// Obtiene el ID de empresa desde sesión o Claims (para usar en Services)
    /// Útil cuando no tienes acceso a BaseController
    /// </summary>
    public static int GetCurrentEmpresaId(this HttpContext httpContext)
    {
        // Primero intenta desde sesión (rápido)
        var empresaSession = httpContext.Session.GetEmpresaSeleccionada();
        if (empresaSession != null && empresaSession.IdEmpresa > 0)
            return empresaSession.IdEmpresa;

        // Fallback a Claims (persistente)
        var claim = httpContext.User.FindFirst("EmpresaId");
        if (claim != null && int.TryParse(claim.Value, out var empresaId))
            return empresaId;

        return 0;
    }

    /// <summary>
    /// Obtiene el año actual desde sesión o Claims (para usar en Services)
    /// Útil cuando no tienes acceso a BaseController
    /// </summary>
    public static int GetCurrentAno(this HttpContext httpContext)
    {
        // Primero intenta desde sesión (rápido)
        var empresaSession = httpContext.Session.GetEmpresaSeleccionada();
        if (empresaSession != null && empresaSession.Ano > 0)
            return empresaSession.Ano;

        // Fallback a Claims (persistente)
        var claim = httpContext.User.FindFirst("Ano");
        if (claim != null && int.TryParse(claim.Value, out var ano))
            return ano;

        return DateTime.Now.Year;
    }

    /// <summary>
    /// Obtiene la empresa completa desde sesión o Claims (para usar en Services)
    /// </summary>
    public static EmpresaSeleccionadaSession? GetCurrentEmpresa(this HttpContext httpContext)
    {
        // Primero intenta desde sesión (rápido)
        var empresaSession = httpContext.Session.GetEmpresaSeleccionada();
        if (empresaSession != null && empresaSession.IdEmpresa > 0)
            return empresaSession;

        // Reconstruir desde Claims si es necesario
        var empresaIdClaim = httpContext.User.FindFirst("EmpresaId");
        if (empresaIdClaim == null)
            return null;

        return new EmpresaSeleccionadaSession
        {
            IdEmpresa = int.Parse(empresaIdClaim.Value),
            Ano = short.Parse(httpContext.User.FindFirst("Ano")?.Value ?? "0"),
            NombreCorto = httpContext.User.FindFirst("EmpresaNombre")?.Value ?? "",
            Rut = httpContext.User.FindFirst("EmpresaRut")?.Value ?? "",
            IdPerfil = int.TryParse(httpContext.User.FindFirst("IdPerfil")?.Value, out var perfil) ? perfil : null,
            Privilegios = httpContext.User.FindFirst("Privilegios")?.Value ?? "0"
        };
    }

    /// <summary>
    /// Obtiene el ID del usuario actual desde Claims
    /// </summary>
    public static int GetCurrentUserId(this HttpContext httpContext)
    {
        var claim = httpContext.User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier);
        if (claim != null && int.TryParse(claim.Value, out var userId))
            return userId;

        return 0;
    }

    /// <summary>
    /// Verifica si el usuario actual es administrador desde Claims
    /// </summary>
    public static bool IsCurrentUserAdmin(this HttpContext httpContext)
    {
        var claim = httpContext.User.FindFirst("EsAdmin");
        return claim?.Value == "True";
    }
}
