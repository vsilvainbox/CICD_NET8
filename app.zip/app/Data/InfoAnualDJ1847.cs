﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class InfoAnualDJ1847
{
    public int IdEmpresa { get; set; }

    public short Ano { get; set; }

    public byte? IdEntSupervisora { get; set; }

    public short? AnoAjusteIFRS { get; set; }

    public double? FolioInicial { get; set; }

    public double? FolioFinal { get; set; }

    public byte? IdAjustesRLI { get; set; }
}
