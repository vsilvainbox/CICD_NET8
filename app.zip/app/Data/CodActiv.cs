﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class CodActiv
{
    public string Codigo { get; set; } = null!;

    public string? Descrip { get; set; }

    public double? Version { get; set; }

    public string? OldCodigo { get; set; }
}
