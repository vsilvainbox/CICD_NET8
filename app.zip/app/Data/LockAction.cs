﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class LockAction
{
    public DateTime? Fecha { get; set; }

    public int idLock { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public string? PcName { get; set; }

    public int? hInstance { get; set; }

    public int idAction { get; set; }

    public int idItem { get; set; }
}
