﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class CT_MovComprobanteBase
{
    public int IdMov { get; set; }

    public int? IdEmpresa { get; set; }

    public int? IdComp { get; set; }

    public byte? Orden { get; set; }

    public int? IdCuenta { get; set; }

    public string? CodCuenta { get; set; }

    public double? Debe { get; set; }

    public double? Haber { get; set; }

    public string? Glosa { get; set; }

    public int? IdCCosto { get; set; }

    public int? IdAreaNeg { get; set; }

    public bool? Conciliado { get; set; }
}
