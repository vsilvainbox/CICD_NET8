﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class LogComprobantes
{
    public int IdLog { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public int? IdComp { get; set; }

    public int? IdUsuario { get; set; }

    public double? Fecha { get; set; }

    public short? IdOper { get; set; }

    public short? Estado { get; set; }

    public int? CorrComp { get; set; }

    public int? FechaComp { get; set; }

    public short? TipoComp { get; set; }

    public short? EstadoComp { get; set; }

    public short? TipoAjusteComp { get; set; }
}
