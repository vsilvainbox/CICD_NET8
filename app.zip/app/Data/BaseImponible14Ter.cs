﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class BaseImponible14Ter
{
    public int IdBaseImponible14Ter { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public byte? TipoBaseImp { get; set; }

    public short? IdItemBaseImp { get; set; }

    public double? Valor { get; set; }
}
