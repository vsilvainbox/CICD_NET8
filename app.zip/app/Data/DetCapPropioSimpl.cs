﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class DetCapPropioSimpl
{
    public int IdDetCapPropioSimpl { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public byte? TipoDetCPS { get; set; }

    public bool? IngresoManual { get; set; }

    public int? IdCuenta { get; set; }

    public string? CodCuenta { get; set; }

    public int? Fecha { get; set; }

    public int? IdMovComp { get; set; }

    public double? Valor { get; set; }

    public string? Descrip { get; set; }
}
