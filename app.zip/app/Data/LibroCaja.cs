﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class LibroCaja
{
    public int IdLibroCaja { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public int? IdDoc { get; set; }

    public short? TipoOper { get; set; }

    public int? TipoDoc { get; set; }

    public int? TipoLib { get; set; }

    public string? NumDoc { get; set; }

    public string? NumDocHasta { get; set; }

    public bool? DTE { get; set; }

    public int? IdEntidad { get; set; }

    public string? RutEntidad { get; set; }

    public string? NombreEntidad { get; set; }

    public int? FechaOperacion { get; set; }

    public double? Afecto { get; set; }

    public double? IVA { get; set; }

    public double? Exento { get; set; }

    public double? OtroImp { get; set; }

    public double? Total { get; set; }

    public double? Pagado { get; set; }

    public string? Descrip { get; set; }

    public bool? ConEntRel { get; set; }

    public bool? OperDevengada { get; set; }

    public bool? PagoAPlazo { get; set; }

    public int? FechaExigPago { get; set; }

    public short? Estado { get; set; }

    public int? IdUsuario { get; set; }

    public int? FechaCreacion { get; set; }

    public double? IVAIrrec { get; set; }

    public int? FechaIngresoLibro { get; set; }

    public int? IdEntReal { get; set; }

    public int? IdComp { get; set; }

    public double? Ingreso { get; set; }

    public double? Egreso { get; set; }

    public double? MontoAfectaBaseImp { get; set; }
}
