using Microsoft.AspNetCore.Mvc;

namespace App.Features.ConfiguracionFut;

[ApiController]
[Route("api/[controller]/[action]")]
public class ConfiguracionFutApiController(
    IConfiguracionFutService service,
    ILogger<ConfiguracionFutApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<ConfiguracionFutDto>> GetConfiguracion([FromQuery] int empresaId)
    {
        logger.LogInformation("API: GetConfiguracion called with empresaId: {EmpresaId}", empresaId);

        {
            var config = await service.GetConfiguracionAsync(empresaId);
            return Ok(config);
        }
    }

    [HttpGet]
    public async Task<ActionResult<bool>> IsDisponible()
    {
        logger.LogInformation("API: IsDisponible called");

        {
            var disponible = await service.IsHrFutDisponibleAsync();
            return Ok(disponible);
        }
    }
}
