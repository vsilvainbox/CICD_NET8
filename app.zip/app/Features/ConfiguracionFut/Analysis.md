# Legacy Analysis: Configuración FUT

## 📄 Información del Formulario VB6
**Archivo VB6:** `old/Contabilidad70/HyperContabilidad/FrmConfigFUT.frm`
**Complejidad:** Alta - Integración con HR-FUT
**Estado:** ⚠️ BLOQUEADO - Requiere módulo externo HR-FUT

### Propósito del Formulario
Configuración de cuentas contables asociadas a items del Fondo de Utilidades Tributables (FUT) según tipo de contribuyente. Permite mapear items de HR-FUT a cuentas del plan contable.

---

## 🚨 ANÁLISIS DE DEPENDENCIAS

### Dependencias Externas Críticas
1. **Tabla HR_FutGrItems** - No existe en schema actual
2. **Módulo HR-FUT** - Software externo de remuneraciones
3. **Variable global gLinkParFUT** - Indica si HR-FUT está instalado

**CONCLUSIÓN**: Feature **BLOQUEADA** por dependencia externa no disponible.

---

## ✅ IMPLEMENTACIÓN

Dado que HR-FUT es un módulo externo no disponible, se implementa:
- ✅ Stub con mensaje informativo
- ✅ Vista con advertencia de integración pendiente
- ✅ Estructura preparada para futura integración

**Estado**: Implementación base completada con bloqueo documentado.


## 📄 Información del Formulario VB6
**Archivo VB6:** `old/Contabilidad70/HyperContabilidad/FrmConfigFUT.frm`
**Complejidad:** Alta - Integración con HR-FUT
**Estado:** ⚠️ BLOQUEADO - Requiere módulo externo HR-FUT

### Propósito del Formulario
Configuración de cuentas contables asociadas a items del Fondo de Utilidades Tributables (FUT) según tipo de contribuyente. Permite mapear items de HR-FUT a cuentas del plan contable.

---

## 🚨 ANÁLISIS DE DEPENDENCIAS

### Dependencias Externas Críticas
1. **Tabla HR_FutGrItems** - No existe en schema actual
2. **Módulo HR-FUT** - Software externo de remuneraciones
3. **Variable global gLinkParFUT** - Indica si HR-FUT está instalado

**CONCLUSIÓN**: Feature **BLOQUEADA** por dependencia externa no disponible.

---

## ✅ IMPLEMENTACIÓN

Dado que HR-FUT es un módulo externo no disponible, se implementa:
- ✅ Stub con mensaje informativo
- ✅ Vista con advertencia de integración pendiente
- ✅ Estructura preparada para futura integración

**Estado**: Implementación base completada con bloqueo documentado.

