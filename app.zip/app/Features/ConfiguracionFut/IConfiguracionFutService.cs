namespace App.Features.ConfiguracionFut;

public interface IConfiguracionFutService
{
    Task<ConfiguracionFutDto> GetConfiguracionAsync(int empresaId);
    Task<bool> IsHrFutDisponibleAsync();
}
