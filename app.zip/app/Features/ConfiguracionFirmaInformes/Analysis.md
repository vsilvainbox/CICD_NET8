# Legacy Analysis: Configuración Firma Informes

## 📄 Información del Formulario VB6
**Archivo VB6:** `old/Contabilidad70/HyperContabilidad/FrmConfigInformeFirma.frm`
**Complejidad:** Media
**Propósito:** Configuración de imágenes de firmas digitales para informes contables

### Funcionalidad Principal
Permite cargar y gestionar imágenes de firmas (JPG 228x112px) para:
- Contador
- Representante Legal 1
- Representante Legal 2

**Entidad:** `Firmas` (tabla existente)
**Almacenamiento:** Archivos JPG + ruta en BD
**Carpeta:** `/Firma/[RUT]_fir[Tipo]_[Año].jpg`

---

## 🎨 CONTROLES PRINCIPALES

| Control | Tipo | Propósito |
|---------|------|-----------|
| Tx_Contador | TextBox | Ruta imagen contador |
| Tx_RepLegal1 | TextBox | Ruta imagen rep legal 1 |
| Tx_RepLegal2 | TextBox | Ruta imagen rep legal 2 |
| Bt_SearchContador | Button | Seleccionar archivo contador |
| Bt_SearchRepLegal1 | Button | Seleccionar archivo rep 1 |
| Bt_SearchRepLegal2 | Button | Seleccionar archivo rep 2 |
| Bt_Del(0-2) | Button Array | Eliminar firmas |
| Bt_Aceptar | Button | Guardar configuración |

---

## 💾 OPERACIONES BD

### Cargar Firmas Existentes
```vb
SELECT patch, idempresa, tipo FROM Firmas 
WHERE idempresa = [id] AND ano = [año]
```

### Guardar/Actualizar
```vb
' Si existe:
UPDATE Firmas SET patch = '[ruta]' 
WHERE Tipo = '[tipo]' AND idEmpresa = [id] AND ano = [año]

' Si no existe:
INSERT INTO Firmas (patch, IdEmpresa, Tipo, ano) 
VALUES ('[ruta]', [id], '[tipo]', [año])
```

### Eliminar
```vb
DELETE FROM Firmas 
WHERE idEmpresa = [id] AND Tipo = '[tipo]' AND ano = [año]
```

---

## ✅ IMPLEMENTACIÓN .NET

**Adaptaciones modernas:**
- Upload de archivos via `<input type="file">`
- Almacenamiento en `wwwroot/firmas/`
- Validación de dimensiones en servidor
- Preview de imagen antes de guardar
- Base64 encoding para preview
