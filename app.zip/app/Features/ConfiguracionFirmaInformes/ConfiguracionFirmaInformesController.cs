using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.ConfiguracionFirmaInformes;


public class ConfiguracionFirmaInformesController(
    IHttpClientFactory httpClientFactory,
    ILogger<ConfiguracionFirmaInformesController> logger, LinkGenerator linkGenerator) : Controller
{
    public async Task<IActionResult> Index()
    {
        logger.LogInformation("Loading ConfiguracionFirmaInformes for empresa {EmpresaId}, año {Ano}", SessionHelper.EmpresaId, SessionHelper.Ano);

        ViewData["EmpresaId"] = SessionHelper.EmpresaId;
        ViewData["Ano"] = SessionHelper.Ano;

        {
            var client = httpClientFactory.CreateClient("ApiClient");
            var url = linkGenerator.GetPathByAction(
                action: nameof(ConfiguracionFirmaInformesApiController.GetConfiguracion),
                controller: nameof(ConfiguracionFirmaInformesApiController).Replace("Controller", ""),
                values: new { empresaId = SessionHelper.EmpresaId, ano = SessionHelper.Ano });

            var config = await client.GetFromApiAsync<ConfiguracionFirmaInformesDto>(url!);

            return View(config);
        }
    }

    [HttpPost]
    public async Task<IActionResult> UploadFirma([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: UploadFirma called");

        {
            var client = httpClientFactory.CreateClient("ApiClient");
            var url = linkGenerator.GetPathByAction(
                action: nameof(ConfiguracionFirmaInformesApiController.UploadFirma),
                controller: nameof(ConfiguracionFirmaInformesApiController).Replace("Controller", ""));

            var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
            return new ContentResult
            {
                Content = content,
                ContentType = "application/json",
                StatusCode = statusCode
            };
        }
    }

    [HttpDelete]
    public async Task<IActionResult> DeleteFirma([FromQuery] int empresaId, [FromQuery] short ano, [FromQuery] string tipo)
    {
        logger.LogInformation("MVC Proxy: DeleteFirma called for empresa {EmpresaId}, tipo {Tipo}", empresaId, tipo);

        {
            var client = httpClientFactory.CreateClient("ApiClient");
            var url = linkGenerator.GetPathByAction(
                action: nameof(ConfiguracionFirmaInformesApiController.DeleteFirma),
                controller: nameof(ConfiguracionFirmaInformesApiController).Replace("Controller", ""),
                values: new { empresaId, ano, tipo });

            var (statusCode, content) = await client.ProxyRequestAsync(url!, null, HttpMethod.Delete);
            return new ContentResult
            {
                Content = content,
                ContentType = "application/json",
                StatusCode = statusCode
            };
        }
    }
}
