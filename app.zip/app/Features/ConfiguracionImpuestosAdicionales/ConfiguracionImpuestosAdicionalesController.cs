﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.ConfiguracionImpuestosAdicionales;

/// <summary>
/// MVC Controller para configuraci�n de impuestos adicionales
/// </summary>
public class ConfiguracionImpuestosAdicionalesController(
    IHttpClientFactory httpClientFactory,
    ILogger<ConfiguracionImpuestosAdicionalesController> logger, LinkGenerator linkGenerator) : Controller
{
    /// <summary>
    /// Vista principal de configuraci�n
    /// </summary>
    public IActionResult Index(int tipoLib = 1)
    {
        logger.LogInformation("Accediendo a configuraci�n de impuestos adicionales. EmpresaId: {EmpresaId}, año: {Ano}, TipoLib: {TipoLib}",
            SessionHelper.EmpresaId, SessionHelper.Ano, tipoLib);

        ViewData["EmpresaId"] = SessionHelper.EmpresaId;
        ViewData["Ano"] = SessionHelper.Ano;
        ViewData["TipoLib"] = tipoLib;
        ViewData["TipoLibNombre"] = tipoLib == 1 ? "Compras" : "Ventas";

        return View();
    }

    /// <summary>
    /// Vista para seleccionar impuestos en documento
    /// </summary>
    public IActionResult Seleccionar(int tipoLib = 1, int tipoDoc = 30)
    {
        logger.LogInformation("Seleccionando impuestos para documento. EmpresaId: {EmpresaId}, TipoLib: {TipoLib}, TipoDoc: {TipoDoc}",
            SessionHelper.EmpresaId, tipoLib, tipoDoc);

        ViewData["EmpresaId"] = SessionHelper.EmpresaId;
        ViewData["Ano"] = SessionHelper.Ano;
        ViewData["TipoLib"] = tipoLib;
        ViewData["TipoDoc"] = tipoDoc;
        ViewData["TipoLibNombre"] = tipoLib == 1 ? "Compras" : "Ventas";

        return View();
    }

    /// <summary>
    /// Proxy: Obtener impuestos adicionales
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetImpuestos(int empresaId, short ano, int tipoLib)
    {
        var client = httpClientFactory.CreateClient("ApiClient");
        var url = linkGenerator.GetPathByAction(
            action: nameof(ConfiguracionImpuestosAdicionalesApiController.GetImpuestosAdicionales),
            controller: nameof(ConfiguracionImpuestosAdicionalesApiController).Replace("Controller", ""),
            values: new { empresaId, ano, tipoLib });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Proxy: Guardar configuración
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Guardar([FromBody] JsonElement request)
    {
        var client = httpClientFactory.CreateClient("ApiClient");
        var url = linkGenerator.GetPathByAction(
            action: nameof(ConfiguracionImpuestosAdicionalesApiController.GuardarConfiguracion),
            controller: nameof(ConfiguracionImpuestosAdicionalesApiController).Replace("Controller", ""));
        var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }

    /// <summary>
    /// Proxy: Copiar configuración de otra empresa
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Copiar([FromBody] JsonElement request)
    {
        var client = httpClientFactory.CreateClient("ApiClient");
        var url = linkGenerator.GetPathByAction(
            action: nameof(ConfiguracionImpuestosAdicionalesApiController.CopiarConfiguracion),
            controller: nameof(ConfiguracionImpuestosAdicionalesApiController).Replace("Controller", ""));
        var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }

    /// <summary>
    /// Proxy: Eliminar configuración de impuesto
    /// </summary>
    [HttpDelete]
    public async Task<IActionResult> Eliminar(int id, int empresaId, short ano)
    {
        var client = httpClientFactory.CreateClient("ApiClient");
        var url = linkGenerator.GetPathByAction(
            action: nameof(ConfiguracionImpuestosAdicionalesApiController.EliminarImpuesto),
            controller: nameof(ConfiguracionImpuestosAdicionalesApiController).Replace("Controller", ""),
            values: new { idImpAdic = id, empresaId, ano });
        var (statusCode, content) = await client.ProxyRequestAsync(url!, null, HttpMethod.Delete);
        return StatusCode(statusCode, content);
    }
}