using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using App.Helpers;
using App.Extensions;

namespace App.Features.AnalisisVencimientos;

[Authorize]

public class AnalisisVencimientosController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<AnalisisVencimientosController> logger) : Controller
{
    /// <summary>
    /// Vista principal del informe de vencimientos
    /// </summary>
    public Task<IActionResult> Index(int? dias = 30)
    {
        // Obtener empresaId y ano desde la sesi�n
        var empresaId = SessionHelper.EmpresaId;
        var ano = SessionHelper.Ano;

        logger.LogInformation("Loading AnalisisVencimientos index for empresaId: {EmpresaId}, ano: {Ano}, dias: {Dias}", empresaId, ano, dias);

        ViewData["EmpresaId"] = empresaId;
        ViewData["Ano"] = ano;
        ViewData["Dias"] = dias ?? 30;

        // Calcular fecha inicial (hoy + dias)
        var fechaInicial = DateTime.Now.AddDays(dias ?? 30);
        ViewData["FechaInicial"] = fechaInicial.ToString("yyyy-MM-dd");

        return Task.FromResult<IActionResult>(View());
    }

    [HttpGet]
    public async Task<IActionResult> GetTiposLibro()
    {
        logger.LogInformation("Proxying GetTiposLibro");

        var client = httpClientFactory.CreateClient("ApiClient");

        var url = linkGenerator.GetPathByAction(
            action: nameof(AnalisisVencimientosApiController.GetTiposLibro),
            controller: nameof(AnalisisVencimientosApiController).Replace("Controller", "")
        );
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    [HttpGet]
    public async Task<IActionResult> GetClasificaciones()
    {
        logger.LogInformation("Proxying GetClasificaciones");

        var client = httpClientFactory.CreateClient("ApiClient");

        var url = linkGenerator.GetPathByAction(
            action: nameof(AnalisisVencimientosApiController.GetClasificaciones),
            controller: nameof(AnalisisVencimientosApiController).Replace("Controller", "")
        );
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    [HttpGet]
    public async Task<IActionResult> GetCuentas(int empresaId, short ano)
    {
        logger.LogInformation("Proxying GetCuentas: empresaId={EmpresaId}, ano={Ano}", empresaId, ano);

        var client = httpClientFactory.CreateClient("ApiClient");

        var url = linkGenerator.GetPathByAction(
            action: nameof(AnalisisVencimientosApiController.GetCuentas),
            controller: nameof(AnalisisVencimientosApiController).Replace("Controller", ""),
            values: new { empresaId, ano }
        );
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    [HttpGet]
    public async Task<IActionResult> SearchEntity(string rut, int empresaId)
    {
        logger.LogInformation("Proxying SearchEntity: rut={Rut}, empresaId={EmpresaId}", rut, empresaId);

        var client = httpClientFactory.CreateClient("ApiClient");

        var url = linkGenerator.GetPathByAction(
            action: nameof(AnalisisVencimientosApiController.SearchEntity),
            controller: nameof(AnalisisVencimientosApiController).Replace("Controller", ""),
            values: new { rut, empresaId }
        );
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    [HttpGet]
    public async Task<IActionResult> GetEntitiesByClassification(string clasificacion, int empresaId)
    {
        logger.LogInformation("Proxying GetEntitiesByClassification: clasificacion={Clasificacion}, empresaId={EmpresaId}", clasificacion, empresaId);

        var client = httpClientFactory.CreateClient("ApiClient");

        var url = linkGenerator.GetPathByAction(
            action: nameof(AnalisisVencimientosApiController.GetEntitiesByClassification),
            controller: nameof(AnalisisVencimientosApiController).Replace("Controller", ""),
            values: new { clasificacion, empresaId }
        );
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Proxy para obtener documentos vencidos con filtros
    /// GET /AnalisisVencimientos/GetDocumentos
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetDocumentos(int empresaId, short ano, string? fechaVencimiento = null,
        string? tipoLib = null, int? idCuenta = null, int? idEntidad = null)
    {
        logger.LogInformation("AnalisisVencimientos: GetDocumentos proxy called for empresaId={EmpresaId}, ano={Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var values = new Dictionary<string, object?>
            {
                ["empresaId"] = empresaId,
                ["ano"] = ano
            };

            if (!string.IsNullOrEmpty(fechaVencimiento))
                values["fechaVencimiento"] = fechaVencimiento;
            if (!string.IsNullOrEmpty(tipoLib))
                values["tipoLib"] = tipoLib;
            if (idCuenta.HasValue)
                values["idCuenta"] = idCuenta;
            if (idEntidad.HasValue)
                values["idEntidad"] = idEntidad;

            var url = linkGenerator.GetPathByAction(
                action: nameof(AnalisisVencimientosApiController.GetDocumentos),
                controller: nameof(AnalisisVencimientosApiController).Replace("Controller", ""),
                values: values
            );
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Proxy para exportar documentos vencidos a Excel
    /// GET /AnalisisVencimientos/ExportExcel
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ExportExcel(int empresaId, short ano, string? fechaVencimiento = null,
        string? tipoLib = null, int? idCuenta = null)
    {
        logger.LogInformation("AnalisisVencimientos: ExportExcel proxy called for empresaId={EmpresaId}, ano={Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var values = new Dictionary<string, object?>
            {
                ["empresaId"] = empresaId,
                ["ano"] = ano
            };

            if (!string.IsNullOrEmpty(fechaVencimiento))
                values["fechaVencimiento"] = fechaVencimiento;
            if (!string.IsNullOrEmpty(tipoLib))
                values["tipoLib"] = tipoLib;
            if (idCuenta.HasValue)
                values["idCuenta"] = idCuenta;

            var url = linkGenerator.GetPathByAction(
                action: nameof(AnalisisVencimientosApiController.ExportExcel),
                controller: nameof(AnalisisVencimientosApiController).Replace("Controller", ""),
                values: values
            );
            var (fileBytes, contentType) = await client.DownloadFileAsync(url, HttpMethod.Get);
            var fileName = $"AnalisisVencimientos_{empresaId}_{ano}.xlsx";
            return File(fileBytes, contentType, fileName);
        }
    }
}