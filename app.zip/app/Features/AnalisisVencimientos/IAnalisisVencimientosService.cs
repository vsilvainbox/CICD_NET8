﻿namespace App.Features.AnalisisVencimientos;

public interface IAnalisisVencimientosService
{
    // CRUD Principal (solo lectura, es un informe)
    Task<IEnumerable<DocumentoVencimientoDto>> GetDocumentosVencidosAsync(int empresaId, short ano, FiltrosVencimientoDto filtros);

    // Búsquedas y Filtros
    Task<EntidadBusquedaDto?> SearchEntityByRutAsync(int empresaId, string rut);
    Task<IEnumerable<EntidadComboDto>> GetEntitiesByClassificationAsync(int empresaId, int clasificacion);

    // Combos y Lookups
    Task<IEnumerable<CuentaComboDto>> GetCuentasActivasAsync(int empresaId, short ano);
    Task<IEnumerable<TipoLibroDto>> GetTiposLibroAsync();
    Task<IEnumerable<ClasificacionEntidadDto>> GetClasificacionesEntidadAsync();

    // Validaciones
    Task<bool> ValidateRutFormatAsync(string rut, bool useCidFormat);
    Task<bool> CheckEntityExistsAsync(int empresaId, string rut);

    // Cálculos
    Task<TotalesVencimientoDto> CalculateTotalsAsync(IEnumerable<DocumentoVencimientoDto> documentos);
    Task<Dictionary<string, decimal>> SumSelectedColumnsAsync(IEnumerable<DocumentoVencimientoDto> documentos, string[] columnas);

    // Exportación
    Task<byte[]> ExportToExcelAsync(int empresaId, short ano, FiltrosVencimientoDto filtros);
    Task<byte[]> GeneratePdfAsync(int empresaId, short ano, FiltrosVencimientoDto filtros, bool preview = true);

    // Mantenimiento
    Task RecalcularSaldosAsync(int empresaId, short ano);
}