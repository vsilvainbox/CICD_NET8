using Microsoft.AspNetCore.Mvc;

namespace App.Features.AnalisisVencimientos;

[ApiController]
[Route("api/[controller]/[action]")]
public class AnalisisVencimientosApiController(IAnalisisVencimientosService service, ILogger<AnalisisVencimientosApiController> logger) : ControllerBase
{
    /// <summary>
    /// Obtiene documentos vencidos según filtros
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<IEnumerable<DocumentoVencimientoDto>>> GetDocumentos(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        [FromQuery] DateTime? fechaVencimiento = null,
        [FromQuery] int? tipoLib = null,
        [FromQuery] int? idCuenta = null,
        [FromQuery] int? idEntidad = null,
        [FromQuery] string? rut = null,
        [FromQuery] bool useCidFormat = true)
    {
        logger.LogInformation("API: GetDocumentos called with empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var filtros = new FiltrosVencimientoDto
            {
                FechaVencimiento = fechaVencimiento,
                TipoLib = tipoLib,
                IdCuenta = idCuenta,
                IdEntidad = idEntidad,
                Rut = rut,
                UseCidFormat = useCidFormat
            };

            var documentos = await service.GetDocumentosVencidosAsync(empresaId, ano, filtros);
            logger.LogInformation("API: Returning {Count} documentos", ((List<DocumentoVencimientoDto>)documentos).Count);
            return Ok(documentos);
        }
    }

    /// <summary>
    /// Busca una entidad por RUT
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<EntidadBusquedaDto>> SearchEntity(
        string rut,
        [FromQuery] int empresaId)
    {
        logger.LogInformation("API: SearchEntity called with rut: {Rut}, empresaId: {EmpresaId}", rut, empresaId);

        {
            var entidad = await service.SearchEntityByRutAsync(empresaId, rut);

            // if (entidad == null)
            // {
            //     logger.LogWarning("API: Entity not found for RUT: {Rut}", rut);
            //     return NotFound(new { message = "Entidad no encontrada" });
            // }

            return Ok(entidad);
        }
    }

    /// <summary>
    /// Obtiene entidades por clasificación
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<IEnumerable<EntidadComboDto>>> GetEntitiesByClassification(
        int clasificacion,
        [FromQuery] int empresaId)
    {
        logger.LogInformation("API: GetEntitiesByClassification called with clasificacion: {Clasificacion}, empresaId: {EmpresaId}", clasificacion, empresaId);

        {
            var entidades = await service.GetEntitiesByClassificationAsync(empresaId, clasificacion);
            return Ok(entidades);
        }
    }

    /// <summary>
    /// Obtiene cuentas activas
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<IEnumerable<CuentaComboDto>>> GetCuentas(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        logger.LogInformation("API: GetCuentas called with empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var cuentas = await service.GetCuentasActivasAsync(empresaId, ano);
            return Ok(cuentas);
        }
    }

    /// <summary>
    /// Obtiene tipos de libro
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<IEnumerable<TipoLibroDto>>> GetTiposLibro()
    {
        logger.LogInformation("API: GetTiposLibro called");

        {
            var tipos = await service.GetTiposLibroAsync();
            return Ok(tipos);
        }
    }

    /// <summary>
    /// Obtiene clasificaciones de entidad
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<IEnumerable<ClasificacionEntidadDto>>> GetClasificaciones()
    {
        logger.LogInformation("API: GetClasificaciones called");

        {
            var clasificaciones = await service.GetClasificacionesEntidadAsync();
            return Ok(clasificaciones);
        }
    }

    /// <summary>
    /// Valida formato de RUT
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<bool>> ValidateRutFormat(
        [FromQuery] string rut,
        [FromQuery] bool useCidFormat = true)
    {
        logger.LogInformation("API: ValidateRutFormat called with rut: {Rut}", rut);

        {
            var isValid = await service.ValidateRutFormatAsync(rut, useCidFormat);
            return Ok(new { valid = isValid });
        }
    }

    /// <summary>
    /// Verifica si una entidad existe
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<bool>> CheckEntityExists(
        [FromQuery] int empresaId,
        [FromQuery] string rut)
    {
        logger.LogInformation("API: CheckEntityExists called with empresaId: {EmpresaId}, rut: {Rut}", empresaId, rut);

        {
            var exists = await service.CheckEntityExistsAsync(empresaId, rut);
            return Ok(new { exists });
        }
    }

    /// <summary>
    /// Calcula totales de documentos
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<TotalesVencimientoDto>> CalculateTotals(
        [FromBody] IEnumerable<DocumentoVencimientoDto> documentos)
    {
        logger.LogInformation("API: CalculateTotals called");

        {
            var totales = await service.CalculateTotalsAsync(documentos);
            return Ok(totales);
        }
    }

    /// <summary>
    /// Suma columnas seleccionadas
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<Dictionary<string, decimal>>> SumColumns(
        [FromBody] SumColumnsRequest request)
    {
        logger.LogInformation("API: SumColumns called");

        {
            var sumas = await service.SumSelectedColumnsAsync(request.Documentos, request.Columnas);
            return Ok(sumas);
        }
    }

    /// <summary>
    /// Exporta a Excel
    /// </summary>
    [HttpGet]
    public async Task<ActionResult> ExportExcel(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        [FromQuery] DateTime? fechaVencimiento = null,
        [FromQuery] int? tipoLib = null,
        [FromQuery] int? idCuenta = null,
        [FromQuery] int? idEntidad = null,
        [FromQuery] string? rut = null)
    {
        logger.LogInformation("API: ExportExcel called with empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var filtros = new FiltrosVencimientoDto
            {
                FechaVencimiento = fechaVencimiento,
                TipoLib = tipoLib,
                IdCuenta = idCuenta,
                IdEntidad = idEntidad,
                Rut = rut
            };

            var excelBytes = await service.ExportToExcelAsync(empresaId, ano, filtros);
            return File(excelBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", $"AnalisisVencimientos_{DateTime.Now:yyyyMMdd}.xlsx");
        }
    }

    /// <summary>
    /// Genera PDF
    /// </summary>
    [HttpGet]
    public async Task<ActionResult> GeneratePdf(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        [FromQuery] bool preview = true,
        [FromQuery] DateTime? fechaVencimiento = null,
        [FromQuery] int? tipoLib = null,
        [FromQuery] int? idCuenta = null,
        [FromQuery] int? idEntidad = null)
    {
        logger.LogInformation("API: GeneratePdf called with empresaId: {EmpresaId}, ano: {Ano}, preview: {Preview}", empresaId, ano, preview);

        {
            var filtros = new FiltrosVencimientoDto
            {
                FechaVencimiento = fechaVencimiento,
                TipoLib = tipoLib,
                IdCuenta = idCuenta,
                IdEntidad = idEntidad
            };

            var pdfBytes = await service.GeneratePdfAsync(empresaId, ano, filtros, preview);
            return File(pdfBytes, "application/pdf", $"AnalisisVencimientos_{DateTime.Now:yyyyMMdd}.pdf");
        }
    }

    /// <summary>
    /// Recalcula saldos
    /// </summary>
    [HttpPost]
    public async Task<ActionResult> RecalcularSaldos(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        logger.LogInformation("API: RecalcularSaldos called with empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            await service.RecalcularSaldosAsync(empresaId, ano);
            return Ok(new { message = "Saldos recalculados correctamente" });
        }
    }
}

public class SumColumnsRequest
{
    public IEnumerable<DocumentoVencimientoDto> Documentos { get; set; } = new List<DocumentoVencimientoDto>();
    public string[] Columnas { get; set; } = Array.Empty<string>();
}