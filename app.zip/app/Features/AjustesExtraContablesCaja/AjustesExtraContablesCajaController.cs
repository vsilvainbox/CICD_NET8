using Microsoft.AspNetCore.Mvc;
using App.Helpers;
using System.Text.Json;
using App.Extensions;

namespace App.Features.AjustesExtraContablesCaja;


public class AjustesExtraContablesCajaController(
    ILogger<AjustesExtraContablesCajaController> logger,
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator) : Controller
{
    public IActionResult Index()
    {
        logger.LogInformation("AjustesExtraContablesCaja accessed for EmpresaId: {EmpresaId}, Ano: {Ano}",
            SessionHelper.EmpresaId, SessionHelper.Ano);

        // Establecer datos comunes en ViewBag desde la sesi�n
        return View();
    }

    [HttpGet]
    public async Task<IActionResult> Calcular(int empresaId, short ano)
    {
        logger.LogInformation("Calcular called for EmpresaId: {EmpresaId}, Ano: {Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AjustesExtraContablesCajaApiController.Calcular),
                controller: nameof(AjustesExtraContablesCajaApiController).Replace("Controller", ""),
                values: new { empresaId, ano }
            );
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    [HttpPost]
    public async Task<IActionResult> Guardar([FromBody] JsonElement request)
    {
        logger.LogInformation("Guardar called for EmpresaId: {EmpresaId}, Ano: {Ano}", SessionHelper.EmpresaId, SessionHelper.Ano);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AjustesExtraContablesCajaApiController.Guardar),
                controller: nameof(AjustesExtraContablesCajaApiController).Replace("Controller", "")
            );
            var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }
}
