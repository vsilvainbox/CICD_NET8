namespace App.Features.AjustesExtraContablesCaja;

public class AjustesExtraContablesCajaDto
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public decimal SaldoCajaIngresos { get; set; }
    public decimal SaldoCajaEgresos { get; set; }
    public decimal SaldoFinalCaja { get; set; }
    public List<ItemAjusteDto> Agregados { get; set; } = new();
    public decimal TotalAgregados { get; set; }
    public List<ItemAjusteDto> Deducciones { get; set; } = new();
    public decimal TotalDeducciones { get; set; }
    public decimal BaseImponible { get; set; }
    public List<DocumentoAjusteDto> Documentos { get; set; } = new();
}

public class ItemAjusteDto
{
    public int IdAjustesExtLibCaja { get; set; }
    public int TipoAjuste { get; set; } // 1=Agregados, 2=Deducciones
    public int IdItemAjuste { get; set; }
    public string? Concepto { get; set; }
    public decimal Valor { get; set; }
    public int TipoIngreso { get; set; } // 1=Directo editable, 2=Cuentas asociadas calculado
    public bool Editable { get; set; }
}

public class AjusteItemDto
{
    public int TipoAjuste { get; set; }
    public string? Concepto { get; set; }
    public double Monto { get; set; }
}

public class DocumentoAjusteDto
{
    public int IdDoc { get; set; }
    public int TipoLib { get; set; }
    public int TipoDoc { get; set; }
    public string NumDoc { get; set; } = string.Empty;
    public int FechaOperacion { get; set; }
    public string RutEntidad { get; set; } = string.Empty;
    public string NombreEntidad { get; set; } = string.Empty;
    public double Total { get; set; }
    public List<AjusteItemDto> Ajustes { get; set; } = new();
}

public class RentaLiquidaImponibleDto
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public double RentaBruta { get; set; }
    public double TotalAgregados { get; set; }
    public double TotalDeducciones { get; set; }
    public double RentaLiquida { get; set; }
}

public class SaveAjustesDto
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public List<ItemAjusteUpdateDto> Items { get; set; } = new();
}

public class ItemAjusteUpdateDto
{
    public int IdAjustesExtLibCaja { get; set; }
    public int TipoAjuste { get; set; }
    public int IdItemAjuste { get; set; }
    public decimal Valor { get; set; }
}
