namespace App.Features.ActualizacionGlosas;

/// <summary>
/// Request para guardar (crear o actualizar) una glosa
/// </summary>
public class GuardarGlosaRequest
{
    /// <summary>
    /// ID de la glosa (null para crear nueva, valor para actualizar)
    /// </summary>
    public int? IdGlosa { get; set; }
    
    /// <summary>
    /// ID de la empresa propietaria
    /// </summary>
    public int IdEmpresa { get; set; }
    
    /// <summary>
    /// Texto de la glosa (máximo 250 caracteres)
    /// </summary>
    public string Glosa { get; set; } = string.Empty;
}

/// <summary>
/// Response de guardado de glosa
/// </summary>
public class GuardarGlosaResponse
{
    /// <summary>
    /// Indica si la operación fue exitosa
    /// </summary>
    public bool Success { get; set; }
    
    /// <summary>
    /// Mensaje descriptivo del resultado
    /// </summary>
    public string Message { get; set; } = string.Empty;
    
    /// <summary>
    /// ID de la glosa (generado para nuevas, mismo para actualizaciones)
    /// </summary>
    public int IdGlosa { get; set; }
    
    /// <summary>
    /// Texto de la glosa guardada
    /// </summary>
    public string Glosa { get; set; } = string.Empty;
}

/// <summary>
/// DTO para obtener una glosa
/// </summary>
public class GlosaDto
{
    /// <summary>
    /// ID de la glosa
    /// </summary>
    public int IdGlosa { get; set; }
    
    /// <summary>
    /// ID de la empresa propietaria
    /// </summary>
    public int IdEmpresa { get; set; }
    
    /// <summary>
    /// Texto de la glosa
    /// </summary>
    public string Glosa { get; set; } = string.Empty;
}
