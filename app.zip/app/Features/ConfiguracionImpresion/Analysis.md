# Análisis de FrmPrtSetup.frm - Configuración de Impresión

## 1. INFORMACIÓN GENERAL

**Formulario VB6:** `FrmPrtSetup.frm`  
**Propósito:** Diálogo modal para configurar las opciones de impresión antes de imprimir documentos y libros contables  
**Tipo:** Formulario de configuración (Fixed Dialog)  
**Ubicación Destino:** `\app\Features\ConfiguracionImpresion`

## 2. ANÁLISIS DE CONTROLES DEL FORMULARIO

### 2.1 Controles de Interfaz

| Control | Tipo | Propiedad Caption/Text | Propósito |
|---------|------|----------------------|-----------|
| Frame2 | Frame | - | Contenedor de opciones adicionales |
| Ch_PapelFoliado | CheckBox | "Papel Foliado" | Indica si se imprime en papel foliado (oficial) |
| Ch_InfoPreliminar | CheckBox | "Nota" | Marca el informe como preliminar |
| Label1 | Label | "Informe Preliminar" | Etiqueta descriptiva con subrayado |
| Bt_ConfigPrt | CommandButton | "Configurar Impresora..." | Abre diálogo de configuración de impresora del sistema |
| Bt_OK | CommandButton | "Imprimir" | Acepta configuración y continúa con impresión |
| Bt_Cerrar | CommandButton | "Cancelar" | Cancela la operación |
| Frame1 | Frame | "Orientación Papel" | Contenedor de opciones de orientación |
| Op_Orientacion(1) | OptionButton | "Vertical" | Orientación vertical (Portrait) |
| Op_Orientacion(2) | OptionButton | "Horizontal" | Orientación horizontal (Landscape) |
| Image1 | Image | - | Icono de impresora |
| Image2(0) | Image | - | Icono vertical |
| Image2(1) | Image | - | Icono horizontal |

### 2.2 Variables y Constantes

```vb6
' Variables de módulo
Dim lIdxOrientacion As Integer      ' 1=Vertical, 2=Horizontal
Dim lPapelFoliado As Boolean        ' True si es papel foliado (oficial)
Dim lInfoPreliminar As Boolean      ' True si es informe preliminar
Dim lRc As Integer                  ' Resultado del diálogo (vbOK o vbCancel)
```

## 3. ANÁLISIS DE PROCEDIMIENTOS Y FUNCIONES

### 3.1 Form_Load
**Propósito:** Inicializa el formulario con los valores recibidos  
**Lógica:**
1. Establece la orientación seleccionada según `lIdxOrientacion`
2. Marca el checkbox de papel foliado según el valor booleano
3. Llama a `SetupPriv` para verificar privilegios

### 3.2 bt_OK_Click
**Propósito:** Acepta la configuración y cierra el formulario  
**Lógica:**
1. Lee el estado de `Ch_PapelFoliado` y lo guarda en `lPapelFoliado`
2. Lee el estado de `Ch_InfoPreliminar` y lo guarda en `lInfoPreliminar`
3. Establece `lRc = vbOK`
4. Descarga el formulario (Unload Me)

### 3.3 bt_Cerrar_Click
**Propósito:** Cancela la operación  
**Lógica:**
1. Establece `lRc = vbCancel`
2. Descarga el formulario

### 3.4 Bt_ConfigPrt_Click
**Propósito:** Abre el diálogo de configuración de impresora del sistema  
**Lógica:**
1. Establece la orientación actual en `FrmMain.Cm_PrtDlg.Orientation`
2. Llama a `PrepararPrt(FrmMain.Cm_PrtDlg)` para mostrar diálogo de Windows
3. Actualiza la selección de orientación según lo elegido en el diálogo

### 3.5 Op_Orientacion_Click(Index As Integer)
**Propósito:** Maneja el cambio de orientación  
**Lógica:**
- Actualiza `lIdxOrientacion` con el índice seleccionado (1 o 2)

### 3.6 Ch_PapelFoliado_Click
**Propósito:** Validación de papel foliado (actualmente comentada)  
**Lógica:**
- Código comentado que advertía sobre imprimir libros oficiales en papel no foliado y viceversa
- No se implementa actualmente

### 3.7 FEdit (Función Pública)
**Propósito:** Función principal para mostrar el diálogo y obtener la configuración  
**Firma:**
```vb6
Public Function FEdit(
    Orientacion As Integer,           ' IN/OUT: 1=Vertical, 2=Horizontal
    PapelFoliado As Boolean,          ' IN/OUT: Papel foliado
    InfoPreliminar As Boolean,        ' IN/OUT: Informe preliminar
    Optional ConfigPrt As Boolean = True  ' Parámetro sin uso
) As Integer                          ' Retorna vbOK o vbCancel
```

**Lógica:**
1. Inicializa variables locales con los parámetros recibidos
2. Muestra el formulario como modal
3. Al cerrar, retorna los valores modificados por referencia
4. Retorna `lRc` (vbOK=1 o vbCancel=2)

### 3.8 SetupPriv
**Propósito:** Configura privilegios de usuario  
**Lógica:**
1. Verifica si el usuario tiene privilegio `PRV_IMP_LIBOF` (imprimir libros oficiales)
2. Si NO tiene privilegio:
   - Desmarca `Ch_PapelFoliado`
   - Deshabilita el control

**Constantes de privilegios:**
- `PRV_IMP_LIBOF`: Privilegio para imprimir libros oficiales en papel foliado

## 4. FLUJO DE DATOS

### 4.1 Entrada (Parámetros de FEdit)
- **Orientacion** (Integer): 1=Vertical, 2=Horizontal
- **PapelFoliado** (Boolean): Indica si es papel foliado
- **InfoPreliminar** (Boolean): Indica si es informe preliminar
- **ConfigPrt** (Boolean, opcional): No se utiliza actualmente

### 4.2 Salida (Parámetros de FEdit modificados por referencia)
- **Orientacion**: Orientación seleccionada por el usuario
- **PapelFoliado**: Estado del checkbox de papel foliado
- **InfoPreliminar**: Estado del checkbox de informe preliminar
- **Retorno**: vbOK (1) si se acepta, vbCancel (2) si se cancela

### 4.3 Interacción con el Sistema
- **Diálogo de impresora:** A través de `FrmMain.Cm_PrtDlg` (CommonDialog de VB6)
- **Privilegios:** Consulta privilegios del usuario para habilitar/deshabilitar opciones

## 5. REGLAS DE NEGOCIO

### 5.1 Orientación de Papel
- **Vertical (Portrait):** Opción por defecto (Index = 1)
- **Horizontal (Landscape):** Alternativa para informes más anchos (Index = 2)
- Solo puede seleccionarse una opción

### 5.2 Papel Foliado
- **Propósito:** Indica que se imprime en papel pre-foliado y timbrado
- **Implicaciones:** 
  - Libros oficiales generalmente requieren papel foliado
  - Libros no oficiales (borradores) no deberían usar papel foliado
- **Privilegios:** Usuario debe tener privilegio `PRV_IMP_LIBOF` para habilitar esta opción

### 5.3 Informe Preliminar (Nota)
- **Propósito:** Marca el informe como preliminar/borrador
- **Efecto:** Generalmente agrega una marca de agua o texto indicando que es preliminar
- **Sin restricciones:** Cualquier usuario puede marcar como preliminar

### 5.4 Validaciones (Comentadas)
- Código comentado sugiere que originalmente había validaciones para advertir sobre:
  - Imprimir libros oficiales en papel no foliado
  - Imprimir libros no oficiales en papel foliado

## 6. CONSIDERACIONES DE MIGRACIÓN

### 6.1 Características Obsoletas
- **CommonDialog de VB6:** Debe reemplazarse por:
  - En .NET: `PrintDialog` o API de JavaScript en navegador
  - Para web: Usar configuración del navegador o PDF con configuración

### 6.2 Modelo de Datos
**DTO necesario: `ConfiguracionImpresionDto`**
```csharp
public class ConfiguracionImpresionDto
{
    public OrientacionPapel Orientacion { get; set; } = OrientacionPapel.Vertical;
    public bool PapelFoliado { get; set; } = false;
    public bool InfoPreliminar { get; set; } = false;
}

public enum OrientacionPapel
{
    Vertical = 1,    // Portrait
    Horizontal = 2   // Landscape
}
```

### 6.3 Privilegios
- Verificar privilegio `PRV_IMP_LIBOF` antes de habilitar checkbox de papel foliado
- Usuario sin privilegio no puede marcar papel foliado

### 6.4 Funcionalidad Web
Para una aplicación web moderna:

**Opción 1: Configuración previa a generación de PDF**
1. Mostrar diálogo modal con opciones
2. Usuario selecciona configuración
3. Generar PDF con la configuración aplicada
4. Navegador maneja la impresión

**Opción 2: Configuración en el navegador**
1. Generar PDF con configuración por defecto
2. Usuario usa diálogo de impresión del navegador para ajustes finales
3. Marcar en el PDF si es preliminar o papel foliado

### 6.5 Implementación Recomendada

**Modal de configuración:**
- Vista con opciones de orientación (radio buttons)
- Checkbox para papel foliado (condicionado a privilegio)
- Checkbox para informe preliminar
- Botón "Imprimir" que aplica la configuración
- Botón "Cancelar" que cierra sin aplicar

**Almacenamiento:**
- Guardar preferencias en sesión del usuario
- Opcionalmente persistir en base de datos como preferencias del usuario

**Generación de documentos:**
- Al generar PDF, aplicar:
  - Orientación (portrait/landscape)
  - Marca de agua si es preliminar
  - Metadatos indicando si es papel foliado (afecta numeración/formato)

## 7. ENDPOINTS Y MÉTODOS NECESARIOS

### 7.1 API Controller
```csharp
[HttpGet("configuracion")]
Task<ActionResult<ConfiguracionImpresionDto>> GetConfiguracion();

[HttpPost("validar-privilegios")]
Task<ActionResult<PrivilegiosImpresionDto>> ValidarPrivilegios();
```

### 7.2 Service Interface
```csharp
Task<ConfiguracionImpresionDto> GetConfiguracionDefaultAsync();
Task<PrivilegiosImpresionDto> ValidarPrivilegiosUsuarioAsync();
```

## 8. CASOS DE USO

### UC-1: Configurar Impresión Estándar
**Actor:** Usuario con privilegios básicos  
**Flujo:**
1. Usuario selecciona imprimir un reporte
2. Sistema muestra modal de configuración
3. Usuario elige orientación vertical u horizontal
4. Usuario puede marcar como informe preliminar
5. Checkbox de papel foliado está deshabilitado (sin privilegio)
6. Usuario presiona "Imprimir"
7. Sistema genera documento con configuración seleccionada

### UC-2: Configurar Impresión de Libro Oficial
**Actor:** Usuario con privilegio PRV_IMP_LIBOF  
**Flujo:**
1. Usuario selecciona imprimir libro oficial
2. Sistema muestra modal de configuración
3. Usuario elige orientación (generalmente vertical para libros)
4. Usuario marca checkbox "Papel Foliado" (habilitado por privilegio)
5. Usuario NO marca como preliminar (libro oficial)
6. Usuario presiona "Imprimir"
7. Sistema genera libro con formato oficial

### UC-3: Imprimir Borrador
**Actor:** Cualquier usuario  
**Flujo:**
1. Usuario quiere ver un borrador antes de impresión oficial
2. Sistema muestra modal de configuración
3. Usuario marca "Informe Preliminar"
4. NO marca papel foliado
5. Usuario presiona "Imprimir"
6. Sistema genera documento con marca de agua "PRELIMINAR"

### UC-4: Cancelar Impresión
**Actor:** Cualquier usuario  
**Flujo:**
1. Usuario abre diálogo de configuración
2. Usuario decide no imprimir
3. Usuario presiona "Cancelar"
4. Sistema cierra modal sin generar documento

## 9. DEPENDENCIAS

### 9.1 Entidades
- **PcUsr** (Usuarios): Para verificar privilegios

### 9.2 Privilegios
- **PRV_IMP_LIBOF**: Privilegio para imprimir libros oficiales en papel foliado

### 9.3 Componentes Relacionados
- Sistema de generación de PDF
- Sistema de privilegios/permisos
- Componentes de impresión de libros contables

## 10. NOTAS DE IMPLEMENTACIÓN

### 10.1 Vista (Razor/HTML)
- Formulario modal con Tailwind CSS
- Radio buttons para orientación con iconos visuales
- Checkboxes para opciones adicionales
- Botones de acción estilizados
- Deshabilitar papel foliado condicionalmente con JavaScript

### 10.2 JavaScript
- Validar privilegios al cargar
- Deshabilitar/habilitar controles según privilegios
- Mostrar/ocultar modal
- Enviar configuración al servidor

### 10.3 Generación de Documentos
- PDF con orientación configurable
- Marca de agua para preliminares
- Formato especial para papel foliado (considerar márgenes, numeración)

### 10.4 Sesión y Preferencias
- Guardar última configuración usada por usuario
- Precargar configuración en próxima impresión
- Opción de "recordar mis preferencias"

## 11. TESTING

### 11.1 Casos de Prueba
1. **Privilegios:**
   - Usuario SIN privilegio PRV_IMP_LIBOF → Papel foliado deshabilitado
   - Usuario CON privilegio → Papel foliado habilitado

2. **Configuraciones:**
   - Orientación vertical + preliminar
   - Orientación horizontal + papel foliado
   - Todas las combinaciones posibles

3. **Acciones:**
   - Aceptar configuración → Retorna valores correctos
   - Cancelar → No aplica cambios

4. **Persistencia:**
   - Configuración se mantiene en sesión
   - Valores por defecto correctos

## 12. RESUMEN

**FrmPrtSetup.frm** es un diálogo de configuración simple pero esencial que permite a los usuarios:
- Seleccionar orientación del papel (vertical/horizontal)
- Indicar si se imprime en papel foliado (requiere privilegio)
- Marcar documento como preliminar

Es un componente transversal usado antes de cualquier impresión de reportes y libros contables, por lo que debe ser:
- Rápido y responsive
- Intuitivo
- Respetar los privilegios de usuario
- Mantener las preferencias del usuario

En .NET/Web moderno, se implementa como un componente modal que configura la generación de PDF antes de la impresión.
