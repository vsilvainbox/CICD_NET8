using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using App.Extensions;

namespace App.Features.ConfiguracionImpresion;

/// <summary>
/// Controlador MVC para la configuración de impresión
/// </summary>
[Authorize]

public class ConfiguracionImpresionController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<ConfiguracionImpresionController> logger) : Controller
{
    /// <summary>
    /// Muestra la vista de configuración de impresión
    /// GET: /ConfiguracionImpresion
    /// </summary>
    public IActionResult Index()
    {
        logger.LogInformation("Mostrando vista de configuración de impresión");

        ViewData["Title"] = "Configuración de Impresión";

        return View();
    }

    /// <summary>
    /// Proxy: Obtiene la configuración de impresión actual
    /// GET: /ConfiguracionImpresion/GetConfiguracion
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetConfiguracion()
    {
        logger.LogInformation("Proxy MVC: Obteniendo configuración de impresión");

        {
            var client = httpClientFactory.CreateClient("ApiClient");
            var url = linkGenerator.GetPathByAction(
                action: nameof(ConfiguracionImpresionApiController.GetConfiguracion),
                controller: nameof(ConfiguracionImpresionApiController).Replace("Controller", ""));
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Proxy: Valida privilegios del usuario para impresión
    /// GET: /ConfiguracionImpresion/GetPrivilegios
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetPrivilegios()
    {
        logger.LogInformation("Proxy MVC: Obteniendo privilegios de impresión");

        {
            var client = httpClientFactory.CreateClient("ApiClient");
            var url = linkGenerator.GetPathByAction(
                action: nameof(ConfiguracionImpresionApiController.GetPrivilegios),
                controller: nameof(ConfiguracionImpresionApiController).Replace("Controller", ""));
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Proxy: Guarda la configuración de impresión
    /// POST: /ConfiguracionImpresion/SaveConfiguracion
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> SaveConfiguracion([FromBody] System.Text.Json.JsonElement configuracion)
    {
        logger.LogInformation("Proxy MVC: Guardando configuración de impresión");

        {
            var client = httpClientFactory.CreateClient("ApiClient");
            var url = linkGenerator.GetPathByAction(
                action: nameof(ConfiguracionImpresionApiController.SaveConfiguracion),
                controller: nameof(ConfiguracionImpresionApiController).Replace("Controller", ""));
            var (statusCode, content) = await client.ProxyRequestAsync(url!, configuracion, HttpMethod.Post);
            return new ContentResult
            {
                Content = content,
                ContentType = "application/json",
                StatusCode = statusCode
            };
        }
    }
}
