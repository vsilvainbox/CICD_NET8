using Microsoft.AspNetCore.Mvc;

namespace App.Features.CierreAnual;

/// <summary>
/// API Controller para cierre anual (cierre de ejercicio)
/// Migrado desde VB6 FrmCierreAnual.frm
/// </summary>
[ApiController]
[Route("api/[controller]/[action]")]
public class CierreAnualApiController(ICierreAnualService service, ILogger<CierreAnualApiController> _logger) : ControllerBase
{
    /// <summary>
    /// Obtiene el estado del cierre anual
    /// GET /api/CierreAnual/status?empresaId=1&amp;ano=2024
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<CierreAnualStatusDto>> GetStatus([FromQuery] int empresaId, [FromQuery] short ano)
    {
        _logger.LogInformation("API: GetStatus called with empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        {
            if (empresaId <= 0)
            {
                return BadRequest(new { message = "EmpresaId es requerido y debe ser mayor a 0" });
            }

            if (ano <= 0)
            {
                return BadRequest(new { message = "año es requerido y debe ser mayor a 0" });
            }

            var status = await service.GetCloseStatusAsync(empresaId, ano);
            return Ok(status);
        }
    }

    /// <summary>
    /// Obtiene vista previa del cierre sin ejecutarlo
    /// GET /api/CierreAnual/preview?empresaId=1&amp;ano=2024
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<CierreAnualPreviewDto>> GetPreview([FromQuery] int empresaId, [FromQuery] short ano)
    {
        _logger.LogInformation("API: GetPreview called with empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        {
            if (empresaId <= 0)
            {
                return BadRequest(new { message = "EmpresaId es requerido y debe ser mayor a 0" });
            }

            if (ano <= 0)
            {
                return BadRequest(new { message = "año es requerido y debe ser mayor a 0" });
            }

            var preview = await service.GetClosePreviewAsync(empresaId, ano);
            return Ok(preview);
        }
    }

    /// <summary>
    /// Ejecuta el cierre anual
    /// POST /api/CierreAnual/execute
    /// Body: { "empresaId": 1, "ano": 2024, "confirmarLibrosImpresos": true, "confirmarIrreversible": true }
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<CierreAnualResultDto>> Execute([FromBody] CierreAnualRequestDto request)
    {
        _logger.LogInformation("API: Execute called with empresaId: {EmpresaId}, año: {Ano}",
            request.EmpresaId, request.Ano);

        {
            if (request.EmpresaId <= 0)
            {
                return BadRequest(new { message = "EmpresaId es requerido y debe ser mayor a 0" });
            }

            if (request.Ano <= 0)
            {
                return BadRequest(new { message = "año es requerido y debe ser mayor a 0" });
            }

            if (!request.ConfirmarLibrosImpresos)
            {
                return BadRequest(new { message = "Debe confirmar que los libros anuales han sido impresos" });
            }

            if (!request.ConfirmarIrreversible)
            {
                return BadRequest(new { message = "Debe confirmar que entiende que el proceso es irreversible" });
            }

            // Check if already closed
            var status = await service.GetCloseStatusAsync(request.EmpresaId, request.Ano);
            if (status.IsClosed)
            {
                return BadRequest(new { message = $"El año {request.Ano} ya fue cerrado el {status.FechaCierre:dd/MM/yyyy}" });
            }

            // Execute close
            var result = await service.ExecuteAnnualCloseAsync(request.EmpresaId, request.Ano);

            if (result.Success)
            {
                return Ok(result);
            }
            else
            {
                return BadRequest(result);
            }
        }
    }

    /// <summary>
    /// Valida si los libros anuales han sido impresos
    /// GET /api/CierreAnual/validate-books?empresaId=1&amp;ano=2024
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<ValidationResult>> ValidateBooks([FromQuery] int empresaId, [FromQuery] short ano)
    {
        _logger.LogInformation("API: ValidateBooks called with empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        {
            if (empresaId <= 0)
            {
                return BadRequest(new { message = "EmpresaId es requerido y debe ser mayor a 0" });
            }

            if (ano <= 0)
            {
                return BadRequest(new { message = "año es requerido y debe ser mayor a 0" });
            }

            var result = await service.ValidateAnnualBooksPrintedAsync(empresaId, ano);
            return Ok(result);
        }
    }
}
