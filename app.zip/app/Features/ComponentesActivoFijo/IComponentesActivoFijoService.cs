namespace App.Features.ComponentesActivoFijo;

public interface IComponentesActivoFijoService
{
    Task<ComponentesActivoFijoDto?> GetDatosActivoFijoAsync(int idActFijo, int empresaId, short ano);
    Task<List<ComponenteDisponibleDto>> GetComponentesDisponiblesAsync(int idGrupo, int idActFijo, int empresaId, short ano);
    Task<ValidationResult> GuardarComponenteAsync(GuardarComponenteDto dto);
    Task<ValidationResult> EliminarComponenteAsync(int idCompFicha, int empresaId, short ano);
    Task<ValidationResult> ActualizarSinDetCompsAsync(int idActFijo, int empresaId, short ano, bool sinDetComps);
    ComponenteDto CalcularCamposComponente(ComponenteDto componente, double? precioFactura, double? derechosIntern,
        double? transporte, double? obrasAdapt, int? cantidad);
}
