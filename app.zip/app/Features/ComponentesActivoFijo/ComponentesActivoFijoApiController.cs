using Microsoft.AspNetCore.Mvc;

namespace App.Features.ComponentesActivoFijo;

[ApiController]
[Route("api/[controller]/[action]")]
public class ComponentesActivoFijoApiController(IComponentesActivoFijoService service, ILogger<ComponentesActivoFijoApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetDatos([FromQuery] int idActFijo, [FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: GetDatos called with IdActFijo: {IdActFijo}, EmpresaId: {EmpresaId}, Ano: {Ano}", 
            idActFijo, empresaId, ano);

        {
            var datos = await service.GetDatosActivoFijoAsync(idActFijo, empresaId, ano);
            if (datos == null)
            {
                return NotFound(new { message = "Activo fijo no encontrado" });
            }

            return Ok(datos);
        }
    }

    [HttpGet]
    public async Task<IActionResult> GetDisponibles([FromQuery] int idGrupo, [FromQuery] int idActFijo, [FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: GetDisponibles called for IdGrupo: {IdGrupo}", idGrupo);

        {
            var disponibles = await service.GetComponentesDisponiblesAsync(idGrupo, idActFijo, empresaId, ano);
            return Ok(disponibles);
        }
    }

    [HttpPost]
    public async Task<IActionResult> Guardar([FromBody] GuardarComponenteDto dto)
    {
        logger.LogInformation("API: Guardar called for IdActFijo: {IdActFijo}", dto.IdActFijo);

        {
            var result = await service.GuardarComponenteAsync(dto);
            if (!result.IsValid)
            {
                return BadRequest(new { message = result.ErrorMessage });
            }

            return Ok(new { message = result.SuccessMessage, idCompFicha = result.IdCompFicha });
        }
    }

    [HttpDelete]
    public async Task<IActionResult> Eliminar(int idCompFicha, [FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: Eliminar called for IdCompFicha: {IdCompFicha}", idCompFicha);

        {
            var result = await service.EliminarComponenteAsync(idCompFicha, empresaId, ano);
            if (!result.IsValid)
            {
                return BadRequest(new { message = result.ErrorMessage });
            }

            return Ok(new { message = result.SuccessMessage });
        }
    }

    [HttpPost]
    public async Task<IActionResult> ActualizarSinDetComps([FromBody] SinDetCompsRequest request)
    {
        logger.LogInformation("API: ActualizarSinDetComps called for IdActFijo: {IdActFijo}", request.IdActFijo);

        {
            var result = await service.ActualizarSinDetCompsAsync(request.IdActFijo, request.EmpresaId, request.Ano, request.SinDetComps);
            if (!result.IsValid)
            {
                return BadRequest(new { message = result.ErrorMessage });
            }

            return Ok(new { message = result.SuccessMessage });
        }
    }

}

public class SinDetCompsRequest
{
    public int IdActFijo { get; set; }
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public bool SinDetComps { get; set; }
}
