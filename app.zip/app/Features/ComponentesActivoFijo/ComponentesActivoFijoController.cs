using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.ComponentesActivoFijo;


public class ComponentesActivoFijoController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<ComponentesActivoFijoController> logger) : Controller
{
    public IActionResult Index(int idActFijo)
    {
        // Obtener empresaId y ano desde la sesi�n
        var empresaId = SessionHelper.EmpresaId;
        var ano = SessionHelper.Ano;

        logger.LogInformation("Loading ComponentesActivoFijo for IdActFijo: {IdActFijo}, EmpresaId: {EmpresaId}, Ano: {Ano}",
            idActFijo, empresaId, ano);

        ViewData["IdActFijo"] = idActFijo;
        ViewData["EmpresaId"] = empresaId;
        ViewData["Ano"] = ano;

        return View();
    }

    [HttpGet]
    public async Task<IActionResult> GetDatos(int idActFijo, int empresaId, short ano)
    {
        logger.LogInformation("MVC Proxy: GetDatos for IdActFijo: {IdActFijo}", idActFijo);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(ComponentesActivoFijoApiController.GetDatos),
                controller: nameof(ComponentesActivoFijoApiController).Replace("Controller", ""),
                values: new { idActFijo, empresaId, ano });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    [HttpGet]
    public async Task<IActionResult> GetDisponibles(int idGrupo, int idActFijo, int empresaId, short ano)
    {
        logger.LogInformation("MVC Proxy: GetDisponibles for IdGrupo: {IdGrupo}", idGrupo);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(ComponentesActivoFijoApiController.GetDisponibles),
                controller: nameof(ComponentesActivoFijoApiController).Replace("Controller", ""),
                values: new { idGrupo, idActFijo, empresaId, ano });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    [HttpPost]
    public async Task<IActionResult> Guardar([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: Guardar component");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(ComponentesActivoFijoApiController.Guardar),
                controller: nameof(ComponentesActivoFijoApiController).Replace("Controller", ""));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    [HttpDelete]
    public async Task<IActionResult> Eliminar(int idCompFicha, int empresaId, short ano)
    {
        logger.LogInformation("MVC Proxy: Eliminar for IdCompFicha: {IdCompFicha}", idCompFicha);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(ComponentesActivoFijoApiController.Eliminar),
                controller: nameof(ComponentesActivoFijoApiController).Replace("Controller", ""),
                values: new { idCompFicha, empresaId, ano });
            var (statusCode, content) = await client.ProxyRequestAsync(url!, null, HttpMethod.Delete);
            return StatusCode(statusCode, content);
        }
    }

    [HttpPost]
    public async Task<IActionResult> SinDetComps([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: SinDetComps");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(ComponentesActivoFijoApiController.ActualizarSinDetComps),
                controller: nameof(ComponentesActivoFijoApiController).Replace("Controller", ""));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }
}
