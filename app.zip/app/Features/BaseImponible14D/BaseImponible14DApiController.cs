using Microsoft.AspNetCore.Mvc;

namespace App.Features.BaseImponible14D;

[ApiController]
[Route("api/[controller]/[action]")]
public class BaseImponible14DApiController(
    IBaseImponible14DService service,
    ILogger<BaseImponible14DApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<BaseImponible14DDto>> Get([FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: Get called with empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);
            
        {
            var data = await service.GetAsync(empresaId, ano);
                
            if (data == null)
            {
                logger.LogWarning("API: No data found for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);
                return NotFound(new { message = "No se encontraron datos para la empresa y año especificados" });
            }
                
            logger.LogInformation("API: Returning Base Imponible 14D data");
            return Ok(data);
        }
    }
        
    [HttpPost]
    public async Task<ActionResult> Save([FromQuery] int empresaId, [FromQuery] short ano, [FromBody] BaseImponible14DSaveDto dto)
    {
        logger.LogInformation("API: Save called with empresaId: {EmpresaId}, ano: {Ano}, valor: {Valor}", 
            empresaId, ano, dto.Valor);
            
        {
            var result = await service.SaveAsync(empresaId, ano, dto);
                
            if (!result.IsValid)
            {
                logger.LogWarning("API: Validation failed: {ErrorMessage}", result.ErrorMessage);
                return BadRequest(new { message = result.ErrorMessage });
            }
                
            logger.LogInformation("API: Save completed successfully");
            return Ok(new { message = "Base Imponible guardada exitosamente" });
        }
    }
        
    [HttpGet]
    public async Task<ActionResult> ExportExcel([FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: ExportExcel called with empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);
            
        {
            var excelData = await service.ExportToExcelAsync(empresaId, ano);
                
            logger.LogInformation("API: Excel export completed, returning file");
                
            return File(
                excelData, 
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", 
                $"BaseImponible14D_{ano}.xlsx"
            );
        }
    }
        
    [HttpGet]
    public async Task<ActionResult> ExportPdf([FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: ExportPdf called with empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);
            
        {
            var pdfData = await service.GeneratePdfAsync(empresaId, ano);
                
            logger.LogInformation("API: PDF generation completed, returning file");
                
            return File(
                pdfData, 
                "application/pdf", 
                $"BaseImponible14D_{ano}.pdf"
            );
        }
    }
        
    [HttpGet]
    public async Task<ActionResult<decimal>> GetPerdidaAnoAnterior([FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: GetPerdidaAnoAnterior called with empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);
            
        {
            var perdida = await service.GetPerdidaAnoAnteriorAsync(empresaId, ano);
                
            logger.LogInformation("API: Perdida año anterior: {Perdida}", perdida);
            return Ok(perdida);
        }
    }
        
    [HttpPost]
    public async Task<ActionResult> TraspasarPerdidaAnterior([FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: TraspasarPerdidaAnterior called with empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);
            
        {
            var result = await service.TraspasarPerdidaAnteriorAsync(empresaId, ano);
                
            if (!result.IsValid)
            {
                logger.LogWarning("API: Traspaso failed: {ErrorMessage}", result.ErrorMessage);
                return BadRequest(new { message = result.ErrorMessage });
            }
                
            logger.LogInformation("API: Traspaso completed successfully");
            return Ok(new { message = "Pérdida del año anterior traspasada exitosamente" });
        }
    }
}