using App.Features.Shared;

namespace App.Features.BaseImponible14D;

public interface IBaseImponible14DService
{
    /// <summary>
    /// Obtiene la base imponible 14D para una empresa y año específico
    /// </summary>
    Task<BaseImponible14DDto?> GetAsync(int empresaId, short ano);
        
    /// <summary>
    /// Guarda la base imponible en EmpresasAno y CapPropioSimplAnual
    /// </summary>
    Task<ValidationResult> SaveAsync(int empresaId, short ano, BaseImponible14DSaveDto dto);
        
    /// <summary>
    /// Obtiene el tipo de régimen Pro Pyme de la empresa (General o Transparente)
    /// </summary>
    Task<string> GetTipoRegimenAsync(int empresaId, short ano);
        
    /// <summary>
    /// Exporta la base imponible a Excel
    /// </summary>
    Task<byte[]> ExportToExcelAsync(int empresaId, short ano);
        
    /// <summary>
    /// Genera PDF para impresión/preview
    /// </summary>
    Task<byte[]> GeneratePdfAsync(int empresaId, short ano);
        
    /// <summary>
    /// Obtiene la pérdida del año anterior (si existe)
    /// </summary>
    Task<decimal> GetPerdidaAnoAnteriorAsync(int empresaId, short ano);
        
    /// <summary>
    /// Traspasa la pérdida del año anterior al año actual con código 9600
    /// </summary>
    Task<ValidationResult> TraspasarPerdidaAnteriorAsync(int empresaId, short ano);
}