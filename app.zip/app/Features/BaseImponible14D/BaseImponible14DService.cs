using Microsoft.EntityFrameworkCore;
using App.Data;
using App.Features.Shared;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace App.Features.BaseImponible14D;

public class BaseImponible14DService : IBaseImponible14DService
{
    private readonly LpContabContext _context;
    private readonly ILogger<BaseImponible14DService> _logger;
        
    // Constante de VB6: TipoDetCPS para Base Imponible
    private const byte CPS_BASEIMPONIBLE = 1; // Valor según sistema VB6
        
    public BaseImponible14DService(LpContabContext context, ILogger<BaseImponible14DService> logger)
    {
        _context = context;
        _logger = logger;
            
        // Configurar licencia de QuestPDF (Community)
        QuestPDF.Settings.License = LicenseType.Community;
    }
        
    public async Task<BaseImponible14DDto?> GetAsync(int empresaId, short ano)
    {
        _logger.LogInformation("Getting Base Imponible 14D for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);
            
        {
            var empresaAno = await _context.EmpresasAno
                .Where(ea => ea.idEmpresa == empresaId && ea.Ano == ano)
                .FirstOrDefaultAsync();
                
            var empresa = await _context.Empresas
                .Where(e => e.IdEmpresa == empresaId)
                .FirstOrDefaultAsync();
                
            if (empresaAno == null || empresa == null)
            {
                _logger.LogWarning("EmpresaAno or Empresa not found for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);
                return null;
            }
                
            var tipoRegimen = await GetTipoRegimenAsync(empresaId, ano);
                
            var dto = new BaseImponible14DDto
            {
                IdEmpresa = empresaId,
                Ano = ano,
                BaseImp14DN3 = (decimal)(empresaAno.CPS_BaseImpPrimCat_14DN3 ?? 0),
                BaseImp14DN8 = (decimal)(empresaAno.CPS_BaseImpPrimCat_14DN8 ?? 0),
                TipoRegimen = tipoRegimen,
                NombreEmpresa = empresa.NombreCorto ?? ""
            };
                
            _logger.LogInformation("Retrieved Base Imponible 14D: 14DN3={BaseImp14DN3}, 14DN8={BaseImp14DN8}, Regimen={TipoRegimen}", 
                dto.BaseImp14DN3, dto.BaseImp14DN8, dto.TipoRegimen);
                
            return dto;
        }
    }
        
    public async Task<ValidationResult> SaveAsync(int empresaId, short ano, BaseImponible14DSaveDto dto)
    {
        _logger.LogInformation("Saving Base Imponible 14D for empresaId: {EmpresaId}, ano: {Ano}, valor: {Valor}", 
            empresaId, ano, dto.Valor);
            
        {
            var empresaAno = await _context.EmpresasAno
                .FirstOrDefaultAsync(ea => ea.idEmpresa == empresaId && ea.Ano == ano);
                
            if (empresaAno == null)
            {
                _logger.LogWarning("EmpresaAno not found for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);
                return new ValidationResult
                {
                    IsValid = false,
                    ErrorMessage = "No se encontró el registro EmpresaAno para la empresa y año especificados"
                };
            }
                
            var tipoRegimen = await GetTipoRegimenAsync(empresaId, ano);
                
            // Actualizar EmpresasAno según tipo de régimen
            if (tipoRegimen == "ProPymeGeneral")
            {
                empresaAno.CPS_BaseImpPrimCat_14DN3 = (double)dto.Valor;
                empresaAno.CPS_BaseImpPrimCat_14DN8 = 0;
                _logger.LogInformation("Updated ProPyme General: 14DN3={Valor}", dto.Valor);
            }
            else if (tipoRegimen == "ProPymeTransp")
            {
                empresaAno.CPS_BaseImpPrimCat_14DN3 = 0;
                empresaAno.CPS_BaseImpPrimCat_14DN8 = (double)dto.Valor;
                _logger.LogInformation("Updated ProPyme Transparente: 14DN8={Valor}", dto.Valor);
            }
            else
            {
                _logger.LogWarning("Unknown regime type: {TipoRegimen}", tipoRegimen);
                return new ValidationResult
                {
                    IsValid = false,
                    ErrorMessage = "Tipo de régimen Pro Pyme desconocido o no configurado"
                };
            }
                
            // Actualizar o crear en CapPropioSimplAnual
            var capPropio = await _context.CapPropioSimplAnual
                .FirstOrDefaultAsync(c => 
                    c.TipoDetCPS == CPS_BASEIMPONIBLE && 
                    c.AnoValor == ano && 
                    c.IdEmpresa == empresaId);
                
            if (capPropio != null)
            {
                capPropio.Valor = (double)dto.Valor;
                capPropio.IngresoManual = false;
                _logger.LogInformation("Updated existing CapPropioSimplAnual with ID: {Id}", capPropio.IdCapPropioSimplAnual);
            }
            else
            {
                var newCapPropio = new App.Data.CapPropioSimplAnual
                {
                    TipoDetCPS = CPS_BASEIMPONIBLE,
                    IngresoManual = false,
                    AnoValor = ano,
                    Valor = (double)dto.Valor,
                    IdEmpresa = empresaId
                };
                _context.CapPropioSimplAnual.Add(newCapPropio);
                _logger.LogInformation("Created new CapPropioSimplAnual for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);
            }
                
            await _context.SaveChangesAsync();
                
            _logger.LogInformation("Successfully saved Base Imponible 14D");
                
            return new ValidationResult { IsValid = true };
        }
    }
        
    public async Task<string> GetTipoRegimenAsync(int empresaId, short ano)
    {
        _logger.LogInformation("Getting tipo regimen for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);
            
        {
            // Buscar en ParamEmpresa el tipo de régimen configurado
            // TIPOPARAM = "REGPYME" según VB6
            var proPymeGeneral = await _context.ParamEmpresa
                .Where(p => p.IdEmpresa == empresaId && 
                            p.Ano == ano && 
                            p.Tipo == "REGPYME" && 
                            p.Codigo == 1) // Código 1 = Pro Pyme General
                .FirstOrDefaultAsync();
                
            if (proPymeGeneral != null && proPymeGeneral.Valor == "1")
            {
                _logger.LogInformation("Regime type: ProPymeGeneral");
                return "ProPymeGeneral";
            }
                
            var proPymeTransp = await _context.ParamEmpresa
                .Where(p => p.IdEmpresa == empresaId && 
                            p.Ano == ano && 
                            p.Tipo == "REGPYME" && 
                            p.Codigo == 2) // Código 2 = Pro Pyme Transparente
                .FirstOrDefaultAsync();
                
            if (proPymeTransp != null && proPymeTransp.Valor == "1")
            {
                _logger.LogInformation("Regime type: ProPymeTransp");
                return "ProPymeTransp";
            }
                
            _logger.LogWarning("No Pro Pyme regime configured for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);
            return "Ninguno";
        }
    }
        
    public async Task<byte[]> ExportToExcelAsync(int empresaId, short ano)
    {
        _logger.LogInformation("Exporting Base Imponible 14D to Excel for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);
            
        ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            
        {
            var data = await GetAsync(empresaId, ano);
                
            if (data == null)
            {
                throw new InvalidOperationException("No se encontraron datos para exportar");
            }
                
            using var package = new ExcelPackage();
            var worksheet = package.Workbook.Worksheets.Add("Base Imponible 14D");
                
            // Títulos
            worksheet.Cells["A1"].Value = "Base Imponible Primera Categoría Reg 14 D";
            worksheet.Cells["A2"].Value = $"Año {ano}";
            worksheet.Cells["A1:B1"].Merge = true;
            worksheet.Cells["A2:B2"].Merge = true;
            worksheet.Cells["A1:A2"].Style.Font.Bold = true;
            worksheet.Cells["A1:A2"].Style.Font.Size = 14;
                
            // Headers
            worksheet.Cells["A4"].Value = "Régimen";
            worksheet.Cells["B4"].Value = "Monto";
            worksheet.Cells["A4:B4"].Style.Font.Bold = true;
            worksheet.Cells["A4:B4"].Style.Fill.PatternType = ExcelFillStyle.Solid;
            worksheet.Cells["A4:B4"].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightGray);
                
            // Datos
            worksheet.Cells["A5"].Value = "14 D N°3 Régimen Pro Pyme General";
            worksheet.Cells["B5"].Value = data.BaseImp14DN3;
            worksheet.Cells["B5"].Style.Numberformat.Format = "#,##0.00";
                
            worksheet.Cells["A6"].Value = "14 D N°8 Régimen Pro Pyme Transparente";
            worksheet.Cells["B6"].Value = data.BaseImp14DN8;
            worksheet.Cells["B6"].Style.Numberformat.Format = "#,##0.00";
                
            // Ajustar anchos
            worksheet.Column(1).Width = 50;
            worksheet.Column(2).Width = 20;
                
            _logger.LogInformation("Excel export completed successfully");
                
            return package.GetAsByteArray();
        }
    }
        
    public async Task<byte[]> GeneratePdfAsync(int empresaId, short ano)
    {
        _logger.LogInformation("Generating PDF for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);
            
        {
            var data = await GetAsync(empresaId, ano);
                
            if (data == null)
            {
                throw new InvalidOperationException("No se encontraron datos para exportar");
            }

            var document = Document.Create(container =>
            {
                container.Page(page =>
                {
                    page.Size(PageSizes.Letter);
                    page.Margin(2, Unit.Centimetre);
                    page.PageColor(Colors.White);
                    page.DefaultTextStyle(x => x.FontSize(10).FontFamily("Arial"));

                    page.Header()
                        .Column(column =>
                        {
                            column.Item().Text("BASE IMPONIBLE PRIMERA CATEGORÍA REG 14 D")
                                .FontSize(14).Bold().AlignCenter();
                            column.Item().PaddingTop(5).Text($"Empresa: {data.NombreEmpresa}")
                                .FontSize(11);
                            column.Item().Text($"Año Tributario: {ano}")
                                .FontSize(11);
                            column.Item().Text($"Régimen: {GetDescripcionRegimen(data.TipoRegimen)}")
                                .FontSize(11);
                            column.Item().PaddingTop(10).LineHorizontal(1);
                        });

                    page.Content()
                        .PaddingTop(10)
                        .Column(column =>
                        {
                            // Tabla de datos
                            column.Item().Table(table =>
                            {
                                table.ColumnsDefinition(columns =>
                                {
                                    columns.RelativeColumn(3); // Régimen
                                    columns.RelativeColumn(1); // Monto
                                });

                                // Header
                                table.Cell().Background(Colors.Grey.Lighten3)
                                    .Padding(5)
                                    .Text("Régimen").Bold();
                                table.Cell().Background(Colors.Grey.Lighten3)
                                    .Padding(5)
                                    .AlignRight()
                                    .Text("Monto").Bold();

                                // Fila 1: Pro Pyme General
                                table.Cell().BorderBottom(0.5f)
                                    .Padding(5)
                                    .Text("14 D N°3 Régimen Pro Pyme General");
                                table.Cell().BorderBottom(0.5f)
                                    .Padding(5)
                                    .AlignRight()
                                    .Text($"${data.BaseImp14DN3:N2}");

                                // Fila 2: Pro Pyme Transparente
                                table.Cell().BorderBottom(0.5f)
                                    .Padding(5)
                                    .Text("14 D N°8 Régimen Pro Pyme Transparente");
                                table.Cell().BorderBottom(0.5f)
                                    .Padding(5)
                                    .AlignRight()
                                    .Text($"${data.BaseImp14DN8:N2}");
                            });

                            // Total
                            column.Item().PaddingTop(20)
                                .Table(table =>
                                {
                                    table.ColumnsDefinition(columns =>
                                    {
                                        columns.RelativeColumn(3);
                                        columns.RelativeColumn(1);
                                    });

                                    table.Cell().Background(Colors.Grey.Lighten2)
                                        .Padding(5)
                                        .Text("BASE IMPONIBLE TOTAL").Bold().FontSize(12);

                                    table.Cell().Background(Colors.Grey.Lighten2)
                                        .Padding(5)
                                        .AlignRight()
                                        .Text($"${(data.BaseImp14DN3 + data.BaseImp14DN8):N2}").Bold().FontSize(12);
                                });
                        });

                    page.Footer()
                        .AlignCenter()
                        .DefaultTextStyle(x => x.FontSize(8))
                        .Text(x =>
                        {
                            x.Span("Página ");
                            x.CurrentPageNumber();
                            x.Span(" de ");
                            x.TotalPages();
                            x.Span($" - Generado el {DateTime.Now:dd/MM/yyyy HH:mm}");
                        });
                });
            });

            _logger.LogInformation("PDF generated successfully");
            return document.GeneratePdf();
        }
    }

    private string GetDescripcionRegimen(string tipoRegimen)
    {
        return tipoRegimen switch
        {
            "ProPymeGeneral" => "Pro Pyme General (14 D N°3)",
            "ProPymeTransp" => "Pro Pyme Transparente (14 D N°8)",
            _ => "No configurado"
        };
    }
        
    public async Task<decimal> GetPerdidaAnoAnteriorAsync(int empresaId, short ano)
    {
        _logger.LogInformation("Getting perdida año anterior for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano - 1);
            
        {
            // Consultar BaseImponible14D del año anterior con Fecha = 0 (total anual)
            var perdida = await _context.BaseImponible14D
                .Where(b => b.IdEmpresa == empresaId && 
                            b.Ano == ano - 1 && 
                            b.Fecha == 0)
                .SumAsync(b => b.Valor ?? 0);
                
            // Si es negativa, retornar como positivo (es una pérdida)
            if (perdida < 0)
            {
                _logger.LogInformation("Perdida encontrada: {Perdida}", Math.Abs(perdida));
                return Math.Abs((decimal)perdida);
            }
                
            _logger.LogInformation("No hay pérdida del año anterior");
            return 0;
        }
    }
        
    public async Task<ValidationResult> TraspasarPerdidaAnteriorAsync(int empresaId, short ano)
    {
        _logger.LogInformation("Traspasando pérdida año anterior for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);
            
        {
            var perdida = await GetPerdidaAnoAnteriorAsync(empresaId, ano);
                
            if (perdida <= 0)
            {
                _logger.LogInformation("No hay pérdida para traspasar");
                return new ValidationResult
                {
                    IsValid = false,
                    ErrorMessage = "No existe pérdida del año anterior para traspasar"
                };
            }
                
            // Verificar si ya existe el registro con código 9600
            var existeTraspaso = await _context.BaseImponible14D
                .AnyAsync(b => b.IdEmpresa == empresaId && 
                               b.Ano == ano && 
                               b.Codigo == 9600 &&
                               b.Fecha > 0);
                
            if (existeTraspaso)
            {
                _logger.LogWarning("Ya existe traspaso de pérdida para año {Ano}", ano);
                return new ValidationResult
                {
                    IsValid = false,
                    ErrorMessage = "Ya se encuentra registrada la pérdida del año anterior"
                };
            }
                
            // Crear fecha de fin de año (31/12/año)
            var fechaOperacion = new DateTime(ano, 12, 31);
            var fechaInt = int.Parse(fechaOperacion.ToString("yyyyMMdd"));
                
            // Insertar registro con código 9600 (Pérdida del año anterior)
            var registro = new App.Data.BaseImponible14D
            {
                IdEmpresa = empresaId,
                Ano = ano,
                Tipo = (byte?)2, // BIMP14D_EGRESO
                Nivel = (byte?)5,
                Codigo = 9600, // Código específico para pérdida año anterior
                Fecha = fechaInt,
                Valor = (double)perdida
            };
                
            _context.BaseImponible14D.Add(registro);
            await _context.SaveChangesAsync();
                
            _logger.LogInformation("Successfully traspasada pérdida: {Perdida}", perdida);
                
            return new ValidationResult
            {
                IsValid = true
            };
        }
    }
}