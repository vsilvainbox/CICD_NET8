using System.ComponentModel.DataAnnotations;

namespace App.Features.CentroCostoIndividual;

/// <summary>
/// DTO para representar un centro de costo
/// Mapea desde FrmCCosto.frm (Type CCosto_t)
/// </summary>
public class CentroCostoDto
{
    public int IdCCosto { get; set; }
    public string? Codigo { get; set; }
    public string? Descripcion { get; set; }
    public bool? Vigente { get; set; }
    public int IdEmpresa { get; set; }
}

/// <summary>
/// DTO para crear un nuevo centro de costo
/// Mapea: FrmCCosto.FNew() → bt_OK_Click()
/// </summary>
public class CrearCentroCostoDto
{
    [Required(ErrorMessage = "El código es obligatorio")]
    [MaxLength(15, ErrorMessage = "El código no puede exceder 15 caracteres")]
    public string Codigo { get; set; } = string.Empty;
    
    [MaxLength(50, ErrorMessage = "La descripción no puede exceder 50 caracteres")]
    public string? Descripcion { get; set; }
    
    public bool? Vigente { get; set; } = true;
}

/// <summary>
/// DTO para actualizar un centro de costo existente
/// Mapea: FrmCCosto.FEdit() → bt_OK_Click()
/// </summary>
public class ActualizarCentroCostoDto
{
    [Required(ErrorMessage = "El código es obligatorio")]
    [MaxLength(15, ErrorMessage = "El código no puede exceder 15 caracteres")]
    public string Codigo { get; set; } = string.Empty;
    
    [MaxLength(50, ErrorMessage = "La descripción no puede exceder 50 caracteres")]
    public string? Descripcion { get; set; }
    
    public bool? Vigente { get; set; }
}
