using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.BalanceComprobacion;

public class BalanceComprobacionController(
    ILogger<BalanceComprobacionController> logger,
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator) : Controller
{
    /// <summary>
    /// Vista principal del Balance de Comprobación
    /// </summary>
    [HttpGet]
    public IActionResult Index()
    {
        logger.LogInformation("Cargando Balance de Comprobación para Empresa {EmpresaId}, Año {Ano}",
            SessionHelper.EmpresaId, SessionHelper.Ano);

            
        ViewBag.FechaDesde = new DateTime(SessionHelper.Ano, 1, 1).ToString("yyyy-MM-dd");
        ViewBag.FechaHasta = new DateTime(SessionHelper.Ano, 12, 31).ToString("yyyy-MM-dd");

        return View();
    }

    /// <summary>
    /// Método proxy: Obtiene las opciones de filtros para el Balance de Comprobación
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Opciones(int empresaId)
    {
        logger.LogInformation("MVC Proxy: Obteniendo opciones para empresaId={EmpresaId}", empresaId);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(BalanceComprobacionApiController.GetOpciones),
                controller: nameof(BalanceComprobacionApiController).Replace("Controller", ""),
                values: new { empresaId });

            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Método proxy: Genera el Balance de Comprobación según los parámetros especificados
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Generar([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: Generando Balance de Comprobación");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(BalanceComprobacionApiController.Generar),
                controller: nameof(BalanceComprobacionApiController).Replace("Controller", ""));

            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// Método proxy: Exporta el Balance de Comprobación a Excel
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> ExportarExcel([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: Exportando Balance de Comprobación a Excel");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(BalanceComprobacionApiController.ExportarExcel),
                controller: nameof(BalanceComprobacionApiController).Replace("Controller", ""));

            var (fileBytes, contentType) = await client.DownloadFileAsync(
                url,
                HttpMethod.Post,
                request);

            var fileName = "BalanceComprobacion.xlsx";
            return File(fileBytes, contentType, fileName);
        }
    }
}