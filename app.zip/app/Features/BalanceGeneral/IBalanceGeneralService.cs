namespace App.Features.BalanceGeneral;

/// <summary>
/// Interface para servicio de Balance General de 8 Columnas
/// </summary>
public interface IBalanceGeneralService
{
    /// <summary>
    /// Genera el balance general de 8 columnas
    /// </summary>
    Task<BalanceGeneralResultadoDto> GenerateBalanceAsync(BalanceGeneralParametrosDto parametros);

    /// <summary>
    /// Calcula el patrimonio (Activos - Pasivos)
    /// </summary>
    Task<double> CalculatePatrimonioAsync(BalanceGeneralResultadoDto balance);

    /// <summary>
    /// Valida la ecuación contable
    /// </summary>
    Task<bool> ValidateEquationAsync(BalanceGeneralTotalesDto totales);

    /// <summary>
    /// Exporta el balance a diferentes formatos
    /// </summary>
    Task<byte[]> ExportAsync(BalanceGeneralExportDto exportDto);

    /// <summary>
    /// Obtiene datos para un nivel específico
    /// </summary>
    Task<IEnumerable<BalanceGeneralDto>> GetByNivelAsync(BalanceGeneralParametrosDto parametros);
}