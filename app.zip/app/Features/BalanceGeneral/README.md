# Balance General de 8 Columnas

## Descripción

Módulo de Balance General Tributario que presenta un informe contable de 8 columnas mostrando débitos, créditos, saldos, inventario y resultados. Migrado desde el formulario VB6 `FrmBalTributario.frm`.

## Características

### Columnas del Balance

1. **Movimiento**
   - Débitos: Total de cargos del período
   - Créditos: Total de abonos del período

2. **Saldos**
   - Saldo Deudor: Cuando Débitos > Créditos
   - Saldo Acreedor: Cuando Créditos > Débitos

3. **Inventario** (solo cuentas de Activo y Pasivo)
   - Inventario Activo: Saldo deudor de cuentas de activo
   - Inventario Pasivo: Saldo acreedor de cuentas de pasivo

4. **Resultados** (solo cuentas de Resultado)
   - Pérdida: Saldo deudor de cuentas de resultado
   - Ganancia: Saldo acreedor de cuentas de resultado

### Cálculos Especiales

- **Patrimonio** = Total Inventario Activo - Total Inventario Pasivo
- **Ecuación Contable**: Activos + Pérdidas = Pasivos + Patrimonio + Ganancias

### Filtros Disponibles

- **Empresa y Año**: Obligatorios
- **Rango de Fechas**: Desde/Hasta
- **Nivel**: Máximo nivel de cuenta a mostrar (1-10)
- **Tipo de Ajuste**: Financiero, Tributario, Ambos o Todos
- **Área de Negocio**: Filtro opcional
- **Centro de Costo**: Filtro opcional
- **Libro Oficial**: Solo movimientos aprobados
- **Mostrar Cero**: Incluir/excluir cuentas sin movimiento

## Estructura de Archivos

```
Features/BalanceGeneral/
├── Analysis.md                           # Análisis detallado del VB6
├── BalanceGeneralDto.cs                   # 5 DTOs del dominio
├── IBalanceGeneralService.cs              # Interface del servicio
├── BalanceGeneralService.cs               # Lógica de negocio (250 líneas)
├── BalanceGeneralApiController.cs         # 5 endpoints REST
├── BalanceGeneralController.cs            # Controlador MVC
└── Views/
    ├── _ViewImports.cshtml                # Imports de Razor
    └── Index.cshtml                       # Vista principal (400 líneas)
```

## API Endpoints

### 1. Generar Balance
```http
POST /api/balancegeneral/generate
Content-Type: application/json

{
  "empresaId": 1,
  "ano": 2024,
  "fechaDesde": "2024-01-01",
  "fechaHasta": "2024-12-31",
  "nivel": 9,
  "tipoAjuste": 2,
  "libroOficial": true,
  "mostrarCero": false
}
```

**Respuesta:**
```json
{
  "parametros": { ... },
  "lineas": [
    {
      "idCuenta": 1,
      "codigo": "1.1.01.001",
      "descripcion": "Caja",
      "nivel": 4,
      "clasificacion": 1,
      "debitos": 1000000.00,
      "creditos": 500000.00,
      "saldoDeudor": 500000.00,
      "saldoAcreedor": 0.00,
      "inventarioActivo": 500000.00,
      "inventarioPasivo": 0.00,
      "perdida": 0.00,
      "ganancia": 0.00
    }
  ],
  "totales": {
    "totalDebitos": 10000000.00,
    "totalCreditos": 10000000.00,
    "totalSaldoDeudor": 5000000.00,
    "totalSaldoAcreedor": 5000000.00,
    "totalInventarioActivo": 3000000.00,
    "totalInventarioPasivo": 2000000.00,
    "patrimonio": 1000000.00,
    "totalPerdida": 200000.00,
    "totalGanancia": 1200000.00,
    "ecuacionBalanceada": true
  }
}
```

### 2. Calcular Patrimonio
```http
POST /api/balancegeneral/patrimonio
Content-Type: application/json

{
  "totales": { ... }
}
```

**Respuesta:**
```json
{
  "patrimonio": 1000000.00
}
```

### 3. Validar Ecuación
```http
POST /api/balancegeneral/validate
Content-Type: application/json

{
  "totalInventarioActivo": 3000000.00,
  "totalInventarioPasivo": 2000000.00,
  "patrimonio": 1000000.00,
  "totalPerdida": 200000.00,
  "totalGanancia": 1200000.00
}
```

**Respuesta:**
```json
{
  "isValid": true
}
```

### 4. Exportar Balance
```http
POST /api/balancegeneral/export
Content-Type: application/json

{
  "formato": "excel",
  "incluirTotales": true,
  "resultado": { ... }
}
```

**Respuesta:** Archivo binario (Excel/PDF/CSV)

### 5. Filtrar por Nivel
```http
POST /api/balancegeneral/bynivel
Content-Type: application/json

{
  "empresaId": 1,
  "ano": 2024,
  "nivel": 3,
  ...
}
```

## Uso desde la Interfaz Web

1. Acceder a `/BalanceGeneral`
2. Seleccionar empresa y año
3. Definir rango de fechas
4. Ajustar nivel y otros filtros opcionales
5. Click en "Generar Balance"
6. Revisar las 8 columnas con totales
7. Verificar la ecuación contable en el panel de validación
8. Exportar a Excel o imprimir según necesidad

## Reglas de Negocio

### Clasificación de Cuentas

- **Clasificación 1 (Activo)**: Saldo deudor va a Inventario Activo
- **Clasificación 2 (Pasivo)**: Saldo acreedor va a Inventario Pasivo
- **Clasificación 3+ (Resultado)**: Saldos van a Pérdida/Ganancia

### Cálculo de Saldos

```
Si Débitos > Créditos:
  Saldo Deudor = Débitos - Créditos
  Saldo Acreedor = 0

Si Créditos > Débitos:
  Saldo Deudor = 0
  Saldo Acreedor = Créditos - Débitos
```

### Validación de Ecuación

```
Lado 1 = Total Inventario Activo + Total Pérdida
Lado 2 = Total Inventario Pasivo + Patrimonio + Total Ganancia

Ecuación Balanceada = |Lado 1 - Lado 2| < 0.01
```

## Entidades Relacionadas

- **Cuentas**: Plan de cuentas (código, descripción, nivel, clasificación)
- **MovComprobante**: Movimientos contables (debe, haber)
- **Comprobante**: Comprobantes contables (fecha, estado, tipo ajuste)
- **EmpresasAno**: Empresa y año fiscal

## Dependencias

- Entity Framework Core
- jQuery + DataTables
- Bootstrap 5
- Bootstrap Icons
- SheetJS (para exportación Excel - pendiente)

## Notas Técnicas

- Los valores se formatean con 2 decimales
- Las fechas se convierten a formato entero YYYYMMDD para consultas
- Solo se incluyen comprobantes con Estado=2 cuando Libro Oficial está activado
- Las cuentas en cero se pueden ocultar con el checkbox "Mostrar Cuentas en Cero"
- El patrimonio se calcula automáticamente como Activos - Pasivos
- La ecuación contable valida el balance con tolerancia de $0.01

## Estado del Módulo

✅ **Completado** - Migración funcional desde VB6
⚠️ **Pendiente** - Implementación de exportación a Excel/PDF

## Autor

Migrado desde VB6 (FrmBalTributario.frm) - 2024
