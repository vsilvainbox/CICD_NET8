namespace App.Features.BalanceClasificadoComparativo;

public interface IBalanceClasificadoComparativoService
{
    Task<BalanceClasificadoComparativoResponseDto> GenerarAsync(BalanceClasificadoComparativoRequestDto request, CancellationToken cancellationToken = default);

    Task<BalanceClasificadoComparativoExportResponseDto> ExportarAsync(BalanceClasificadoComparativoExportRequestDto request, CancellationToken cancellationToken = default);

    Task<BalanceClasificadoComparativoPreviewResponseDto> GenerarPreviewAsync(BalanceClasificadoComparativoPreviewRequestDto request, CancellationToken cancellationToken = default);

    Task RegistrarImpresionAsync(BalanceClasificadoComparativoRegistroImpresionRequestDto request, CancellationToken cancellationToken = default);

    Task<IReadOnlyList<BalanceClasificadoComparativoRegistroImpresionDto>> ObtenerHistorialImpresionAsync(int empresaId, int libroOficialCodigo, CancellationToken cancellationToken = default);

    Task<BalanceClasificadoComparativoOpcionesDto> ObtenerOpcionesAsync(int empresaId, CancellationToken cancellationToken = default);
}