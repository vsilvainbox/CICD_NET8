# Implementation Plan: BalanceClasificadoComparativo

## 1. Data & Contracts
- [ ] Define request/response DTOs capturing filters, options, row results, totals, and metadata required by the UI, export, and printing flows.
- [ ] Introduce enums/value objects for `TipoAjuste`, `BalanceMode`, and optional flags (Libro Oficial, mostrar subtotales).
- [ ] Ensure DTOs match entity property casing (e.g., `MovComprobante.idAreaNeg`, `idCCosto`).
- [ ] Document validation rules within DTOs (data annotations + custom validator methods in service).

## 2. Service Layer (`BalanceClasificadoComparativoService`)
- [ ] Implement `IBalanceClasificadoComparativoService` with async methods:
  - `GenerarAsync` – core report builder mirroring VB6 `LoadAll`.
  - `ExportarExcelAsync` – reuse `GenerarAsync` output and produce `.xlsx` via EPPlus.
  - `GenerarPreviewAsync` – create printable payload (initial version returns structured data; PDF generation optional placeholder with TODO LEGACY if backend printing cannot be replicated yet).
  - `RegistrarImpresionOficialAsync` – check prior logs and append new record when printing with Libro Oficial.
- [ ] Inject `LpContabContext`, `ILogger`, and helpers (e.g., `IClock` optional) via constructor.
- [ ] Build reusable queries:
  - Fetch account hierarchy (Cuentas + parent relationships) limited by requested nivel.
  - Aggregate movements for both periods (current/previous) applying filters: fechas, tipo ajuste, libro oficial, área negocio, centro costo.
- [ ] Use EF Core with raw SQL or LINQ + recursion (consider temporary in-memory structure for totals). Validate performance with indexes.
- [ ] Implement result-of-exercise injection logic mirroring VB6 (`AddResEjercicio`, `ReadResEje`). Source account IDs from `CuentasBasicas` (matching types, confirm mapping).
- [ ] Handle companies without previous year gracefully (throw domain exception handled by API).
- [ ] Log entry/exit, parameter values, and errors.

## 3. API Controller (`BalanceClasificadoComparativoApiController`)
- [ ] Create controller with `[ApiController]`, `[Route("api/[controller]/[action]")]`.
- [ ] Expose POST endpoints: `listar`, `exportar`, `preview`, `registrar-impresion` calling service methods.
- [ ] Validate inputs, map service results to HTTP responses (400 on validation, 500 with logged errors).
- [ ] Return file responses for Excel/preview as needed.

## 4. MVC Controller (`BalanceClasificadoComparativoController`)
- [ ] Index action renders view and seeds default filter values (pull from API or using auxiliary endpoint `defaults`).
- [ ] Provide actions for navigation/redirects if required (e.g., linking to Libro Mayor via existing controllers).
- [ ] Use `IHttpClientFactory` to consume API; handle error messages and pass to view via `ViewData`/TempData.
- [ ] Maintain `ILogger` injection for tracing.

## 5. Views & Front-End (`Views/Index.cshtml`, `Views/_ViewImports.cshtml`)
- [ ] Mirror VB6 layout: toolbar with buttons (Listar, Ver Libro Mayor, Copiar Excel, Preview, Imprimir, Email, Suma, Conversor, Calculadora, Calendarios, Ver Código Cuenta, Libro Oficial, Ver Subtotales).
- [ ] Implement responsive grid using Tailwind: hierarchical rows with indenting and toggles; show period headers and difference column.
- [ ] Add modals for sum, currency converter, printing confirmation.
- [ ] Implement date pickers (flatpickr or native `<input type="date">`), ensuring previous/current period logic.
- [ ] Use fetch + async/await to call API endpoints, disable Listar button until parameters change, replicate validations and warnings (mes mismatch, missing año anterior, confirm Libro Oficial printing history).
- [ ] Provide copy-to-clipboard with structured TSV and Excel download triggers.
- [ ] Integrate with existing JS utilities if available (check Shared scripts); otherwise, add feature-specific JS within the view.

## 6. Menu Integration & Routing
- [ ] Add sidebar entry under balances/financial statements in `_Layout.cshtml` referencing `BalanceClasificadoComparativo` route.
- [ ] Update `features.md` once implementation is complete (❌ → ✅).

## 7. Testing & Validation
- [ ] Introduce unit tests for service calculations (mock DbContext via SQLite in-memory) ensuring:
  - Active vs pasivo classification math.
  - Filtering by tipo ajuste, área, centro costo.
  - Resultado del ejercicio adjustments.
  - Handling of companies without year anterior.
- [ ] Add integration tests for API endpoints if feasible.
- [ ] Manual smoke checklist comparing VB6 vs .NET outputs for representative datasets.

## 8. Deliverables & Finalization
- [ ] Ensure logging coverage (Information entry/exit, Warning on edge cases, Error on exceptions).
- [ ] Remove TODOs except structured LEGACY/INTEGRATION blockers (e.g., pending PDF engine) with tooltips in UI.
- [ ] Run `dotnet build` and relevant tests before marking feature complete.
- [ ] Document usage in README snippet or help tooltip within UI if necessary.
