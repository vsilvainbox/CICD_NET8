namespace App.Features.ConfiguracionPrincipal;

public interface IConfiguracionPrincipalService
{
    Task<ConfiguracionDto> GetConfigAsync(int? empresaId = null, short? ano = null);
    Task SaveConfigAsync(GuardarConfiguracionDto request);
    Task RestoreDefaultsAsync(int? empresaId = null, short? ano = null);
    Task<IEnumerable<ComboItemDto>> GetTiposComprobanteAsync();
    Task<IEnumerable<ComboItemDto>> GetMonedasAsync();
}