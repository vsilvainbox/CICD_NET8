namespace App.Features.ConfiguracionPrincipal;

public class ConfiguracionDto
{
    public int? EmpresaId { get; set; }
    public short? Ano { get; set; }
        
    // Configuraciones de visualización
    public bool MostrarCodigoCuenta { get; set; }
    public bool ImprimirLogo { get; set; }
    public int NumeroDecimales { get; set; } = 2;
        
    // Configuraciones de operación
    public bool UsarMonedaExtranjera { get; set; }
    public bool ModoLibroOficial { get; set; }
    public int? TipoComprobanteDefault { get; set; }
    public int? MonedaPrincipalId { get; set; }
    public int? EmpresaDefecto { get; set; }
        
    // Configuraciones de impresión
    public bool ImprimirFechaReportes { get; set; }
    public bool ImprimirNombreUsuario { get; set; }
    public string FormatoFecha { get; set; } = "dd/MM/yyyy";
        
    // Configuraciones de libros
    public bool ValidarComprobantesBalanceados { get; set; } = true;
    public bool PermitirComprobantesNegativos { get; set; }
    public bool AutonumerarComprobantes { get; set; } = true;
}

public class ComboItemDto
{
    public int Id { get; set; }
    public string Descripcion { get; set; } = string.Empty;
    public string Codigo { get; set; } = string.Empty;
}

public class GuardarConfiguracionDto
{
    public int? EmpresaId { get; set; }
    public short? Ano { get; set; }
    public ConfiguracionDto Configuracion { get; set; } = new();
}