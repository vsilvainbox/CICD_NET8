using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.ConfiguracionPrincipal;

public class ConfiguracionPrincipalController(IHttpClientFactory httpClientFactory, ILogger<ConfiguracionPrincipalController> logger, LinkGenerator linkGenerator) : Controller
{
    public Task<IActionResult> Index()
    {
        logger.LogInformation("Loading ConfiguracionPrincipal Index for empresaId: {EmpresaId}, ano: {Ano}", SessionHelper.EmpresaId, SessionHelper.Ano);

            

        return Task.FromResult<IActionResult>(View());
    }

    /// <summary>
    /// Proxy: GET /api/ConfiguracionPrincipal
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetConfiguracion(int? empresaId, short? ano)
    {
        {
            logger.LogInformation("Proxy GetConfiguracion called for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

            var client = httpClientFactory.CreateClient("ApiClient");
            var queryParams = string.Empty;

            if (empresaId.HasValue || ano.HasValue)
            {
                var parts = new System.Collections.Generic.List<string>();
                if (empresaId.HasValue)
                    parts.Add($"empresaId={empresaId.Value}");
                if (ano.HasValue)
                    parts.Add($"ano={ano.Value}");
                queryParams = "?" + string.Join("&", parts);
            }

            var url = linkGenerator.GetPathByAction(
                action: nameof(ConfiguracionPrincipalApiController.GetConfiguracion),
                controller: nameof(ConfiguracionPrincipalApiController).Replace("Controller", ""),
                values: new { empresaId, ano });

            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Proxy: GET /api/ConfiguracionPrincipalApi/tipos-comprobante
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetTiposComprobante()
    {
        {
            logger.LogInformation("Proxy GetTiposComprobante called");

            var client = httpClientFactory.CreateClient("ApiClient");
            var url = linkGenerator.GetPathByAction(
                action: nameof(ConfiguracionPrincipalApiController.GetTiposComprobante),
                controller: nameof(ConfiguracionPrincipalApiController).Replace("Controller", ""));

            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Proxy: GET /api/ConfiguracionPrincipalApi/monedas
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetMonedas()
    {
        {
            logger.LogInformation("Proxy GetMonedas called");

            var client = httpClientFactory.CreateClient("ApiClient");
            var url = linkGenerator.GetPathByAction(
                action: nameof(ConfiguracionPrincipalApiController.GetMonedas),
                controller: nameof(ConfiguracionPrincipalApiController).Replace("Controller", ""));

            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Proxy: POST /api/ConfiguracionPrincipal
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> SaveConfiguracion([FromBody] JsonElement request)
    {
        {
            logger.LogInformation("Proxy SaveConfiguracion called");

            var client = httpClientFactory.CreateClient("ApiClient");
            var url = linkGenerator.GetPathByAction(
                action: nameof(ConfiguracionPrincipalApiController.SaveConfiguracion),
                controller: nameof(ConfiguracionPrincipalApiController).Replace("Controller", ""));

            var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
            return new ContentResult
            {
                Content = content,
                ContentType = "application/json",
                StatusCode = statusCode
            };
        }
    }

    /// <summary>
    /// Proxy: POST /api/ConfiguracionPrincipalApi/restaurar
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> RestaurarDefectos(int? empresaId, short? ano)
    {
        {
            logger.LogInformation("Proxy RestaurarDefectos called for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

            var client = httpClientFactory.CreateClient("ApiClient");
            var queryParams = string.Empty;

            if (empresaId.HasValue || ano.HasValue)
            {
                var parts = new System.Collections.Generic.List<string>();
                if (empresaId.HasValue) parts.Add($"empresaId={empresaId.Value}");
                if (ano.HasValue) parts.Add($"ano={ano.Value}");
                queryParams = "?" + string.Join("&", parts);
            }

            var url = linkGenerator.GetPathByAction(
                action: nameof(ConfiguracionPrincipalApiController.RestaurarDefectos),
                controller: nameof(ConfiguracionPrincipalApiController).Replace("Controller", ""),
                values: new { empresaId, ano });

            var (statusCode, content) = await client.ProxyRequestAsync(url!, null, HttpMethod.Post);
            return new ContentResult
            {
                Content = content,
                ContentType = "application/json",
                StatusCode = statusCode
            };
        }
    }
}