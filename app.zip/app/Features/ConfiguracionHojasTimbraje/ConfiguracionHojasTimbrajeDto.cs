namespace App.Features.ConfiguracionHojasTimbraje;

/// <summary>
/// DTO para información de timbraje (folios impresos, timbrados, usados)
/// Mapea entidad Timbraje y variable global gFoliacion de VB6
/// </summary>
public class TimbrajeDto
{
    /// <summary>
    /// ID de la empresa
    /// </summary>
    public int EmpresaId { get; set; }

    /// <summary>
    /// Último número de folio impreso
    /// </summary>
    public int? UltImpreso { get; set; }

    /// <summary>
    /// Fecha del último folio impreso (formato YYYYMMDD)
    /// </summary>
    public int? FUltImpreso { get; set; }

    /// <summary>
    /// Fecha del último folio impreso (formato DateTime para UI)
    /// </summary>
    public DateTime? FUltImpresoDate { get; set; }

    /// <summary>
    /// Último número de folio timbrado por SII
    /// </summary>
    public int? UltTimbrado { get; set; }

    /// <summary>
    /// Fecha del último timbraje (formato YYYYMMDD)
    /// </summary>
    public int? FUltTimbrado { get; set; }

    /// <summary>
    /// Fecha del último timbraje (formato DateTime para UI)
    /// </summary>
    public DateTime? FUltTimbradoDate { get; set; }

    /// <summary>
    /// Último número de folio efectivamente usado
    /// </summary>
    public int? UltUsado { get; set; }

    /// <summary>
    /// Fecha del último uso de folio (formato YYYYMMDD)
    /// </summary>
    public int? FUltUsado { get; set; }

    /// <summary>
    /// Fecha del último uso (formato DateTime para UI)
    /// </summary>
    public DateTime? FUltUsadoDate { get; set; }

    /// <summary>
    /// Folio desde sugerido (UltImpreso + 1)
    /// </summary>
    public int FolioDesde { get; set; }
}

/// <summary>
/// DTO para validar rango de folios antes de imprimir
/// </summary>
public class ValidarRangoFoliosDto
{
    /// <summary>
    /// ID de la empresa
    /// </summary>
    public int EmpresaId { get; set; }

    /// <summary>
    /// Folio inicial del rango
    /// </summary>
    public int Desde { get; set; }

    /// <summary>
    /// Folio final del rango
    /// </summary>
    public int Hasta { get; set; }
}

/// <summary>
/// DTO para actualizar último folio impreso después de imprimir
/// </summary>
public class ActualizarImpresoDto
{
    /// <summary>
    /// ID de la empresa
    /// </summary>
    public int EmpresaId { get; set; }

    /// <summary>
    /// Último folio impreso (Tx_Hasta del formulario)
    /// </summary>
    public int UltImpreso { get; set; }

    /// <summary>
    /// Actualizar registro en BD (mapea Ch_Prt checkbox)
    /// </summary>
    public bool ActualizarBD { get; set; } = true;
}

/// <summary>
/// DTO para datos de empresa necesarios en hojas de timbraje
/// Mapea variable global gEmpresa de VB6
/// </summary>
public class EmpresaTimbrajeDto
{
    public int Id { get; set; }
    public string RazonSocial { get; set; } = string.Empty;
    public string Rut { get; set; } = string.Empty;
    public string? RutDisp { get; set; }  // RUT para display (si existe)
    public string Direccion { get; set; } = string.Empty;
    public string? Ciudad { get; set; }
    public string? Comuna { get; set; }
    public string Giro { get; set; } = string.Empty;
    public string? RepLegal1 { get; set; }
    public string? RutRepLegal1 { get; set; }
    public string? RepLegal2 { get; set; }
    public string? RutRepLegal2 { get; set; }
    public bool RepConjunta { get; set; }
}

/// <summary>
/// DTO para generar datos de hojas foliadas (para PDF o impresión)
/// </summary>
public class HojasTimbrajeDto
{
    /// <summary>
    /// Empresa propietaria de las hojas
    /// </summary>
    public EmpresaTimbrajeDto Empresa { get; set; } = new();

    /// <summary>
    /// Folio inicial
    /// </summary>
    public int FolioDesde { get; set; }

    /// <summary>
    /// Folio final
    /// </summary>
    public int FolioHasta { get; set; }

    /// <summary>
    /// Orientación del papel: "vertical" o "horizontal"
    /// </summary>
    public string Orientacion { get; set; } = "vertical";

    /// <summary>
    /// Lista de folios a imprimir con sus datos
    /// </summary>
    public List<HojaFolioDto> Hojas { get; set; } = new();
}

/// <summary>
/// DTO para una hoja individual con folio
/// </summary>
public class HojaFolioDto
{
    /// <summary>
    /// Número de folio (ej: 1)
    /// </summary>
    public int Numero { get; set; }

    /// <summary>
    /// Número de folio formateado (ej: "00000001")
    /// </summary>
    public string NumeroFormateado { get; set; } = string.Empty;
}

/// <summary>
/// DTO para resultado de validación
/// </summary>
public class ValidationResult
{
    public bool IsValid { get; set; }
    public string? ErrorMessage { get; set; }
    public string? WarningMessage { get; set; }  // Para advertencias (ej: reimprimir timbrados)
}