using Microsoft.AspNetCore.Mvc;

namespace App.Features.AyudaCredito33bis;

/// <summary>
/// Controller MVC para la feature de Ayuda sobre Crédito Art. 33 bis.
/// Migrado desde FrmHelpCred33bis.frm - Formulario de ayuda informativa estático.
/// 
/// VB6 Original: FrmHelpCred33bis.frm
/// - Form_Load: Llama SetUpGrid() y FillGrid()
/// - SetUpGrid(): Configura grilla (4 columnas, 8 filas)
/// - FillGrid(): Llena datos estáticos de tasas de crédito Art. 33 bis
/// 
/// Este formulario muestra información ESTÁTICA tributaria, no requiere:
/// - Service (no hay lógica de negocio)
/// - API (no hay operaciones CRUD)
/// - DTOs (no se transfieren datos)
/// </summary>

public class AyudaCredito33bisController(ILogger<AyudaCredito33bisController> logger) : Controller
{
    /// <summary>
    /// Muestra la ventana de ayuda sobre el Crédito por Activo Fijo según Art. 33 bis.
    /// Replica exactamente FrmHelpCred33bis.frm: Form_Load() → SetUpGrid() + FillGrid()
    /// </summary>
    /// <returns>Vista con tabla informativa de tasas de crédito tributario</returns>
    [HttpGet]
    public IActionResult Index()
    {
        logger.LogInformation("Accediendo a Ayuda Crédito 33 bis - Información estática tributaria");
        
        // VB6: Form_Load simplemente muestra el formulario con la grilla pre-llenada
        // .NET: La vista Index.cshtml replica la grilla con datos estáticos idénticos
        
        return View();
    }
}
