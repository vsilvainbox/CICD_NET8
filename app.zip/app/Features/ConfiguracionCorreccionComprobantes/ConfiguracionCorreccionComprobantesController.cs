using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.ConfiguracionCorreccionComprobantes;

[Authorize]

public class ConfiguracionCorreccionComprobantesController(
    IHttpClientFactory httpClientFactory,
    ILogger<ConfiguracionCorreccionComprobantesController> logger,
    LinkGenerator linkGenerator) : Controller
{
    [HttpGet]
    public IActionResult Index()
    {
        logger.LogInformation("Loading ConfiguracionCorreccionComprobantes for empresaId: {EmpresaId}, ano: {Ano}",
            SessionHelper.EmpresaId, SessionHelper.Ano);

        // Validar que haya una empresa seleccionada en la sesión
        if (SessionHelper.EmpresaId <= 0)
        {
            logger.LogWarning("No hay empresa seleccionada en la sesión. Redirigiendo a SeleccionarEmpresa");
            TempData["ErrorMessage"] = "Debe seleccionar una empresa antes de acceder a esta página";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        // Pasar datos de sesión a la vista


        return View();
    }

    [HttpGet]
    public async Task<IActionResult> GetConfiguracion(int empresaId, short ano)
    {
        logger.LogInformation("Proxy: GetConfiguracion - empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient("ApiClient");
            var url = linkGenerator.GetPathByAction(
                action: nameof(ConfiguracionCorreccionComprobantesApiController.GetConfiguracion),
                controller: nameof(ConfiguracionCorreccionComprobantesApiController).Replace("Controller", ""),
                values: new { empresaId, ano });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    [HttpPost]
    public async Task<IActionResult> SaveConfiguracion([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: SaveConfiguracion");

        {
            var client = httpClientFactory.CreateClient("ApiClient");
            var url = linkGenerator.GetPathByAction(
                action: nameof(ConfiguracionCorreccionComprobantesApiController.ActualizarConfiguracion),
                controller: nameof(ConfiguracionCorreccionComprobantesApiController).Replace("Controller", ""));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    [HttpPost]
    public async Task<IActionResult> AplicarResumidoCentralizacion(int empresaId, short ano)
    {
        logger.LogInformation("Proxy: AplicarResumidoCentralizacion - empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient("ApiClient");
            var url = linkGenerator.GetPathByAction(
                action: nameof(ConfiguracionCorreccionComprobantesApiController.AplicarResumidoCentralizacion),
                controller: nameof(ConfiguracionCorreccionComprobantesApiController).Replace("Controller", ""),
                values: new { empresaId, ano });
            var (statusCode, content) = await client.ProxyRequestAsync(url!, null, HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }
}
