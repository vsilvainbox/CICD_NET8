﻿namespace App.Features.AuditoriaLibrosContables;

public interface IAuditoriaLibrosContablesService
{
    /// <summary>
    /// Obtiene todos los movimientos contables de auditoría para un período específico
    /// </summary>
    Task<IEnumerable<AuditoriaLibrosContablesDto>> GetAllAsync(int empresaId, short ano, int mes);
        
    /// <summary>
    /// Obtiene el mes contable actual de la empresa
    /// </summary>
    Task<int> GetCurrentMonthAsync(int empresaId, short ano);
        
    /// <summary>
    /// Exporta los datos de auditoría a Excel
    /// </summary>
    Task<byte[]> ExportToExcelAsync(int empresaId, short ano, int mes);
}