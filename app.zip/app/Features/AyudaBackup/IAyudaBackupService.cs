namespace App.Features.AyudaBackup;

/// <summary>
/// Interface para el servicio de Ayuda Backup
/// </summary>
public interface IAyudaBackupService
{
    /// <summary>
    /// Obtiene el contenido completo de ayuda para backup
    /// </summary>
    /// <returns>DTO con todo el contenido de ayuda construido dinámicamente</returns>
    Task<AyudaBackupDto> GetHelpContentAsync();
        
    /// <summary>
    /// Obtiene información de la aplicación actual
    /// </summary>
    /// <returns>DTO con título, path y versión de la aplicación</returns>
    Task<ApplicationInfoDto> GetApplicationInfoAsync();
        
    /// <summary>
    /// Detecta el tipo de base de datos configurado
    /// </summary>
    /// <returns>DTO con información del tipo de BD</returns>
    Task<DatabaseTypeDto> GetDatabaseTypeAsync();
        
    /// <summary>
    /// Obtiene fecha formateada para nombrar carpetas de backup
    /// </summary>
    /// <returns>Fecha actual en formato para carpetas (ej: "03-01-2025")</returns>
    Task<string> GetFormattedDateForBackupAsync();
}