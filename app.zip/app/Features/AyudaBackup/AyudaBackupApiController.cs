using Microsoft.AspNetCore.Mvc;

namespace App.Features.AyudaBackup;

[ApiController]
[Route("api/[controller]/[action]")]
public class AyudaBackupApiController(IAyudaBackupService service, ILogger<AyudaBackupApiController> logger) : ControllerBase
{
    /// <summary>
    /// Obtiene el contenido completo de ayuda para backup
    /// </summary>
    /// <returns>Contenido de ayuda dinÃ¡mico</returns>
    [HttpGet]
    public async Task<ActionResult<AyudaBackupDto>> GetHelpContent()
    {
        logger.LogInformation("API: GetHelpContent called");

        {
            var helpContent = await service.GetHelpContentAsync();
            logger.LogInformation("API: Successfully retrieved help content");
            return Ok(helpContent);
        }
    }

    /// <summary>
    /// Obtiene informaciÃ³n de la aplicaciÃ³n
    /// </summary>
    /// <returns>InformaciÃ³n de la aplicaciÃ³n</returns>
    [HttpGet]
    public async Task<ActionResult<ApplicationInfoDto>> GetApplicationInfo()
    {
        logger.LogInformation("API: GetApplicationInfo called");

        {
            var appInfo = await service.GetApplicationInfoAsync();
            logger.LogInformation("API: Successfully retrieved application info for: {Title}", appInfo.Title);
            return Ok(appInfo);
        }
    }

    /// <summary>
    /// Obtiene el tipo de base de datos
    /// </summary>
    /// <returns>InformaciÃ³n del tipo de BD</returns>
    [HttpGet]
    public async Task<ActionResult<DatabaseTypeDto>> GetDatabaseType()
    {
        logger.LogInformation("API: GetDatabaseType called");

        {
            var dbType = await service.GetDatabaseTypeAsync();
            logger.LogInformation("API: Successfully detected database type: {TipoBD}", dbType.TipoBD);
            return Ok(dbType);
        }
    }

    /// <summary>
    /// Obtiene fecha formateada para backup
    /// </summary>
    /// <returns>Fecha formateada</returns>
    [HttpGet]
    public async Task<ActionResult<string>> GetFormattedDate()
    {
        logger.LogInformation("API: GetFormattedDate called");

        {
            var formattedDate = await service.GetFormattedDateForBackupAsync();
            logger.LogInformation("API: Successfully generated formatted date: {Date}", formattedDate);
            return Ok(formattedDate);
        }
    }
}