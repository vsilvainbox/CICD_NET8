# Legacy Analysis: Ayuda Backup

## 📄 Información del Formulario VB6

**Archivo VB6:** `old/VB50/FrmHlpBackup.frm`
**Fecha Análisis:** 2025-01-03
**Analista:** IA
**Complejidad:** Baja

### Propósito del Formulario
Formulario de ayuda que proporciona información detallada y recomendaciones sobre la importancia de realizar respaldos de información en forma periódica. Es un diálogo informativo sin operaciones de base de datos, que educa al usuario sobre buenas prácticas de backup.

---

## 🎨 CONTROLES UI IDENTIFICADOS

### Labels de Información
| Control VB6 | Propiedad/Valor | Tipo | Validación | Propósito |
|-------------|----------------|------|------------|-----------|
| Label1 | "¿ Respaldó su información esta semana ?" | Label/Caption | N/A | Título principal del diálogo |

### Textboxes (Campos de Información)
| Control VB6 | Propiedad Bound | Tipo | Validación | Propósito |
|-------------|----------------|------|------------|-----------|
| Tx_Msg | Text contenido dinámico | TextBox | ReadOnly=True, MultiLine=True | Área de texto con el contenido completo de ayuda sobre backup |

### Imágenes
| Control VB6 | Fuente | Propósito | Mapeo .NET |
|-------------|--------|-----------|------------|
| Image1 | "FrmHlpBackup.frx":0012 | Icono principal del diálogo | Font Awesome icon |
| Image2 | Copy of Image1 | Icono duplicado (decorativo) | Font Awesome icon duplicado |

### Botones de Acción
| Botón VB6 | Caption | Habilitado Si | Acción | Mapeo .NET |
|-----------|---------|---------------|--------|------------|
| N/A | N/A | N/A | Cerrar implícito (X del diálogo) | Botón Cerrar modal |

#### 🚨 ANÁLISIS DE BOTONES: 
**✅ TODOS LOS BOTONES DOCUMENTADOS:** El formulario VB6 es un simple diálogo informativo sin botones explícitos de acción más allá del cierre estándar del formulario.

### Otros Controles
| Tipo Control | Nombre | Propósito | Eventos |
|--------------|--------|-----------|---------|
| Form | FrmHlpBackup | Contenedor principal | Form_Load |

---

## 🔘 EVENTOS IDENTIFICADOS

### Eventos de Formulario
| Evento VB6 | Cuándo Ocurre | Acciones | Mapeo .NET |
|------------|---------------|----------|------------|
| Form_Load | Al abrir el diálogo | Construir mensaje de ayuda dinámicamente, configurar imágenes | GetHelpContentAsync() |

### Eventos de Controles
| Control.Evento | Trigger | Acción VB6 | Mapeo .NET |
|----------------|---------|------------|------------|
| N/A | N/A | Solo lectura | N/A |

---

## 🔧 FUNCIONES Y PROCEDIMIENTOS VB6

### Funciones del Evento Form_Load
```vb
' Función: Form_Load
' Propósito: Inicializar el formulario y construir el contenido de ayuda
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: GetHelpContentAsync() en Service
Private Sub Form_Load()
    ' Copia imagen decorativa
    Image2 = Image1
    
    ' Construye contenido dinámico del mensaje
    Tx_Msg = "* * *  IMPORTANTE  * * *"
    Tx_Msg = Tx_Msg & vbCrLf & vbCrLf
    ' ... [contenido completo documentado abajo]
End Sub
```

### Lista Completa de Funciones
| Función VB6 | Tipo | Propósito | Mapeo .NET Method |
|-------------|------|-----------|-------------------|
| Form_Load() | Private Sub | Inicializar diálogo y construir ayuda | GetHelpContentAsync() |

---

## 💾 ACCESO A DATOS VB6

### Variables Globales Utilizadas
```vb
' Variables utilizadas en la construcción del mensaje
App.Title           ' Título de la aplicación
W.AppPath          ' Ruta de la aplicación  
gDbType            ' Tipo de base de datos (MySQL check)
SQL_MYSQL          ' Constante para MySQL
Now                ' Fecha actual
FmtFecha(Now)      ' Función de formateo de fecha
```

**Mapeo Entity Framework:**
```csharp
// No requiere acceso a base de datos
// Solo variables de configuración de la aplicación
```

---

## ✅ VALIDACIONES Y REGLAS DE NEGOCIO

### Lógica Condicional
| Condición | Regla | Mensaje Adicional VB6 | Implementar en .NET |
|-----------|-------|-------------------|---------------------|
| gDbType = SQL_MYSQL | Si BD es MySQL | "En esta versión la base de datos está en un servidor MySQL, debe solicitar la asistencia de un técnico para realizar el respado de los datos." | Detectar tipo BD y mostrar mensaje apropiado |

### Reglas de Negocio
1. **Mensaje Dinámico**: El contenido se construye dinámicamente basado en configuración de la aplicación
2. **Detección de BD**: Comportamiento diferente según tipo de base de datos
3. **Formato de Fecha**: Uso de función de formateo específica para nombres de carpetas de backup

---

## 🧮 CÁLCULOS Y FÓRMULAS

### Construcción del Mensaje de Ayuda
```vb
' Estructura del mensaje completo:
' 1. Título importante
' 2. Párrafo sobre importancia de respaldos
' 3. Consecuencias de pérdida de información
' 4. Recomendación sobre medios externos
' 5. Verificación de respaldos
' 6. Recomendación de almacenamiento
' 7. Medios recomendados (CD/DVD)
' 8. Carpeta específica a respaldar (W.AppPath)
' 9. [Condicional] Mensaje especial para MySQL
' 10. Instrucciones de organización con fecha
' 11. Estrategia de múltiples CDs
' 12. Recomendación final antivirus
```

**→ Implementar:** `BuildHelpMessageAsync()` que construye mensaje con misma estructura

---

## 🚀 NAVEGACIÓN Y FLUJO

### Formularios Llamados
| Desde VB6 | Formulario Destino | Parámetros | Retorno | Mapeo .NET |
|-----------|-------------------|------------|---------|------------|
| N/A | N/A | N/A | N/A | Solo diálogo informativo |

### Flujo de Estados del Form
```
[Inicio] → Form_Load() → [Estado: Mostrando Ayuda]
  ↓
[Usuario Lee] → [Estado: Informado]
  ↓
[Cerrar X] → [Estado: Cerrado]
```

---

## 📊 EXPORTACIONES E IMPORTACIONES

### Exportación/Importación
**N/A** - Es un formulario puramente informativo sin funciones de datos.

---

## 🎯 MAPEO FINAL: MÉTODOS .NET DETERMINADOS

### Interface del Service
```csharp
public interface IAyudaBackupService
{
    // Información y Contenido
    Task<AyudaBackupDto> GetHelpContentAsync();
    Task<ApplicationInfoDto> GetApplicationInfoAsync();
    
    // Detección de Configuración
    Task<DatabaseTypeDto> GetDatabaseTypeAsync();
    
    // Utilidades
    Task<string> GetFormattedDateForBackupAsync();
}
```

### Resumen de Mapeo
| Funcionalidad VB6 | Método .NET | Complejidad | Prioridad |
|-------------------|-------------|-------------|-----------|
| Form_Load construir mensaje | GetHelpContentAsync() | Baja | Alta |
| Detectar App.Title y W.AppPath | GetApplicationInfoAsync() | Baja | Alta |
| Verificar gDbType = SQL_MYSQL | GetDatabaseTypeAsync() | Baja | Media |
| FmtFecha(Now) para carpetas | GetFormattedDateForBackupAsync() | Baja | Media |

---

## ⚠️ NOTAS IMPORTANTES Y OBSERVACIONES

### Peculiaridades del Form VB6
- Es un diálogo modal de solo lectura (BorderStyle = Fixed Dialog)
- No tiene botones de acción explícitos, solo el cierre estándar
- El contenido es 100% dinámico construido en Form_Load
- Usa variables globales de la aplicación (App.Title, W.AppPath, gDbType)
- Incluye formateo de fecha específico para nombrar carpetas de backup
- Mensaje condicional especial para bases de datos MySQL

### Decisiones de Diseño
- **Modal Dialog**: VB6 usa diálogo modal, mantener approach con modal en .NET
- **Contenido Dinámico**: Construir mensaje igual que en VB6, no estático
- **Detección BD**: Implementar detección de tipo de BD para mensaje condicional
- **Formato Fecha**: Replicar formato de fecha para consistencia

### Contenido Completo del Mensaje VB6
```
* * *  IMPORTANTE  * * *

Es de suma importancia realizar respaldos de la información en forma periódica. Es responsabilidad del usuario o empresa definir una política adecuada al respecto.

En el caso de la pérdida de información debido al ataque de un virus, la falla de un disco, etc., la única forma de recuperar y no perder el trabajo de meses, es recurrir a los respaldos.

Los programas pueden ser instalados nuevamente, pero si no hay respaldos, la información ingresada se perderá irremediablemente.

Los respaldos deben se hechos en un medio externo, no deben ser hechos en el mismo disco o en el mismo equipo en que se encuentra la aplicación. Un virus puede destruir el contenido de todo el disco o los discos del equipo, o bien puede fallar el disco en que se hizo el respaldo.

Es importante verificar que los respaldos queden bien hechos, de modo que cuando se necesiten puedan ser utilizados. Para esto es bueno probar a recuperar un respaldo y ver si la información es la correcta. Los dispositivos donde se hace el respaldo (ej CDs), es recomendable que se almacenen fuera de la oficina.

Una forma segura, sencilla y económica es utilizar CDs o DVDs. Estos permiten almacenar gran cantidad de información.

Para nuestra aplicación [App.Title], usted debería respaldar toda la carpeta '[W.AppPath]'.

[Si MySQL]: En esta versión la base de datos está en un servidor MySQL, debe solicitar la asistencia de un técnico para realizar el respado de los datos.

Si el respaldo lo hace hoy, cree en el CD una carpeta llamada '[FmtFecha(Now)]'. En esta carpeta agregue el contenido de la carpeta '[W.AppPath]' y toda otra información importante para usted.
En el siguiente respaldo, utilice otro CD, cree una carpeta con la nueva fecha y agregue en esta nueva carpeta su información.

Si sólo respalda esta aplicación en el CD, seguramente podrá realizar varios respaldos en el mismo CD. Sin embargo, no sería recomendable tener más de cuatro respaldos seguidos en el mismo CD, porque si éste se daña se pierde toda su información.

Se recomienda tener dos o más CDs (CD1, CD2, CD3, ...) e ir usando un CD distinto cada vez, primero el CD1, luego el CD2, después el CD3, ... luego nuevamente el CD1 y así. De ese modo si se daña un CD quedan los otros.

Recuerde mantener actualizado su Antivirus y chequear periódicamente sus discos para reducir los riesgos.
```

---

## ✅ CHECKLIST DE COMPLETITUD DEL ANÁLISIS

- [x] Todos los controles UI documentados
- [x] Todos los botones y eventos mapeados  
- [x] **TODOS los botones tienen "Mapeo .NET" definido** (solo cierre implícito)
- [x] **Botones con excepciones documentados** (N/A - no hay excepciones)
- [x] Todas las funciones VB6 identificadas
- [x] Todas las consultas SQL traducidas a EF Core (N/A - no hay consultas)
- [x] Todas las validaciones documentadas
- [x] Todas las reglas de negocio identificadas
- [x] Todos los cálculos documentados
- [x] Navegación y flujos mapeados
- [x] Métodos .NET determinados
- [x] Interface del Service definida
- [x] **Decisiones de excepción justificadas y estructuradas** (N/A)

---

**✅ ANÁLISIS COMPLETO - LISTO PARA IMPLEMENTACIÓN**