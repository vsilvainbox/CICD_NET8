using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Authorization;
using App.Extensions;

namespace App.Features.BalanceTributarioIfrs;

/// <summary>
/// Controller MVC para Balance Tributario IFRS.
/// </summary>
[Authorize]

public class BalanceTributarioIfrsController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<BalanceTributarioIfrsController> logger) : Controller
{
    /// <summary>
    /// Página principal del Balance Tributario IFRS.
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Index()
    {
        await CargarDatosIniciales();
        return View();
    }

    /// <summary>
    /// Genera el balance (llamada AJAX - proxy a API).
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Generar([FromBody] BalanceTributarioIfrsRequestDto request)
    {
        logger.LogInformation("Proxy: Generar Balance Tributario IFRS llamado");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(BalanceTributarioIfrsApiController.Generar),
                controller: nameof(BalanceTributarioIfrsApiController).Replace("Controller", ""));

            var resultado = await client.PostToApiAsync<BalanceTributarioIfrsRequestDto, BalanceTributarioIfrsResponseDto>(
                url,
                request);

            return Ok(new { success = true, data = resultado });
        }
    }

    /// <summary>
    /// Exporta el balance a PDF (llamada AJAX - proxy a API).
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> ExportarPdf([FromBody] BalanceTributarioIfrsRequestDto request, [FromQuery] bool incluirMembrete = true)
    {
        logger.LogInformation("Proxy: ExportarPdf Balance Tributario IFRS llamado");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(BalanceTributarioIfrsApiController.ExportarPdf),
                controller: nameof(BalanceTributarioIfrsApiController).Replace("Controller", ""),
                values: new { incluirMembrete });

            var (pdfBytes, contentType) = await client.DownloadFileAsync(
                url,
                HttpMethod.Post,
                request);

            return File(pdfBytes, contentType, $"BalanceTributarioIFRS_{DateTime.Now:yyyy-MM-dd}.pdf");
        }
    }

    private async Task CargarDatosIniciales()
    {
        var client = httpClientFactory.CreateClient("ApiClient");

        // Niveles (1-5)
        ViewBag.Niveles = Enumerable.Range(1, 5)
            .Select(n => new SelectListItem { Value = n.ToString(), Text = $"Nivel {n}" })
            .ToList();

        // Áreas de negocio desde API
        {
            var url = linkGenerator.GetPathByAction(
                action: nameof(BalanceTributarioIfrsApiController.ObtenerAreasNegocio),
                controller: nameof(BalanceTributarioIfrsApiController).Replace("Controller", ""));

            var areas = await client.GetFromApiAsync<List<Shared.ComboItemDto>>(url!);
            ViewBag.AreasNegocio = (areas ?? new()).Select(a => new SelectListItem
            {
                Value = a.Value.ToString(),
                Text = a.Text
            }).ToList();
        }

        // Centros de costo desde API
        {
            var url = linkGenerator.GetPathByAction(
                action: nameof(BalanceTributarioIfrsApiController.ObtenerCentrosCosto),
                controller: nameof(BalanceTributarioIfrsApiController).Replace("Controller", ""));

            var centros = await client.GetFromApiAsync<List<Shared.ComboItemDto>>(url!);
            ViewBag.CentrosCosto = (centros ?? new()).Select(c => new SelectListItem
            {
                Value = c.Value.ToString(),
                Text = c.Text
            }).ToList();
        }

        // Validaciones desde API
        {
            var url = linkGenerator.GetPathByAction(
                action: nameof(BalanceTributarioIfrsApiController.ValidarPlan),
                controller: nameof(BalanceTributarioIfrsApiController).Replace("Controller", ""));

            var validacion = await client.GetFromApiAsync<JsonElement>(url!);

            ViewBag.PlanValido = validacion.TryGetProperty("esValido", out var esValidoProp)
                ? esValidoProp.GetBoolean()
                : false;

            ViewBag.PlanActual = validacion.TryGetProperty("planActual", out var planActualProp)
                ? planActualProp.GetString() ?? "Desconocido"
                : "Desconocido";
        }

        // Fecha por defecto
        var hoy = DateTime.Now;
        ViewBag.FechaDesde = new DateTime(hoy.Year, 1, 1);
        ViewBag.FechaHasta = hoy;
    }
}
