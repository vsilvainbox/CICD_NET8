# Balance Tributario IFRS

## Estado
✅ **Estructura base completada** - Migración desde `FrmBalTributarioIFRS.frm`

## Descripción
Balance General 8 Columnas con formato IFRS (International Financial Reporting Standards).

## Funcionalidad Base
Este reporte es una variante del Balance Clasificado estándar pero con:
- **Formato IFRS**: Presenta cuentas según normativa contable internacional
- **8 Columnas**: Activo/Pasivo con subdivisiones
- **Codificación IFRS**: Usa mapeo de cuentas a códigos IFRS definidos

## Implementación Actual
La funcionalidad base está cubierta por:
- `/Features/BalanceClasificado` - Motor de balance general
- `/Features/BalanceGeneral` - Balance 8 columnas
- Configuración IFRS se puede agregar extendiendo el servicio existente

## Pendiente de Implementación
Para completar la funcionalidad IFRS específica se requiere:

1. **Mapeo de Cuentas IFRS**
   - Tabla de equivalencias cuenta local → código IFRS
   - Configuración de agrupaciones IFRS

2. **Formatos IFRS**
   - Estado de Situación Financiera (Balance)
   - Estado de Resultados Integrales
   - Estado de Cambios en Patrimonio
   - Estado de Flujos de Efectivo

3. **Reglas de Presentación**
   - Clasificación Corriente/No Corriente
   - Revelaciones requeridas
   - Notas a los estados financieros

## Migración VB6 → .NET
El formulario VB6 original tiene:
- Filtros: Fecha desde/hasta, Área Negocio, Centro Costo, Nivel
- Grid con 8 columnas
- Exportación a Excel/PDF
- Impresión en papel foliado

## Uso Recomendado
Para reportes IFRS básicos, usar:
```
/BalanceClasificado/Index?empresaId=1&ano=2025&formatoIFRS=true
```

Para implementación completa IFRS, se requiere análisis contable especializado.

---
**Nota**: La migración completa requiere conocimiento profundo de normativa IFRS chilena.
