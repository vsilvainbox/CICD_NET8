namespace App.Features.BalanceTributarioIfrs;

/// <summary>
/// DTO que representa una línea en el Balance Tributario IFRS (8 columnas).
/// </summary>
public class BalanceTributarioIfrsLineaDto
{
    /// <summary>
    /// ID de la cuenta (null para líneas de totales).
    /// </summary>
    public long? IdCuenta { get; set; }

    /// <summary>
    /// Código IFRS de la cuenta.
    /// </summary>
    public string Codigo { get; set; } = string.Empty;

    /// <summary>
    /// Nombre de la cuenta.
    /// </summary>
    public string Cuenta { get; set; } = string.Empty;

    /// <summary>
    /// Nivel jerárquico de la cuenta (1-5).
    /// </summary>
    public int Nivel { get; set; }

    /// <summary>
    /// Clasificación de la cuenta (1=Activo, 2=Pasivo, 4/5=Resultado).
    /// </summary>
    public string Clasificacion { get; set; } = string.Empty;

    /// <summary>
    /// Total de débitos del período.
    /// </summary>
    public decimal Debitos { get; set; }

    /// <summary>
    /// Total de créditos del período.
    /// </summary>
    public decimal Creditos { get; set; }

    /// <summary>
    /// Saldo deudor (débitos - créditos si es positivo).
    /// </summary>
    public decimal SaldoDeudor { get; set; }

    /// <summary>
    /// Saldo acreedor (créditos - débitos si es positivo).
    /// </summary>
    public decimal SaldoAcreedor { get; set; }

    /// <summary>
    /// Inventario - Activo (cuentas de activo/pasivo con saldo deudor).
    /// </summary>
    public decimal InventarioActivo { get; set; }

    /// <summary>
    /// Inventario - Pasivo (cuentas de activo/pasivo con saldo acreedor).
    /// </summary>
    public decimal InventarioPasivo { get; set; }

    /// <summary>
    /// Resultado - Pérdida (cuentas de resultado con saldo deudor).
    /// </summary>
    public decimal ResultadoPerdida { get; set; }

    /// <summary>
    /// Resultado - Ganancia (cuentas de resultado con saldo acreedor).
    /// </summary>
    public decimal ResultadoGanancia { get; set; }

    /// <summary>
    /// Indica si esta línea es un total.
    /// </summary>
    public bool EsTotal { get; set; }

    /// <summary>
    /// Indica si esta línea debe mostrarse en negrita.
    /// </summary>
    public bool MostrarNegrita { get; set; }
}
