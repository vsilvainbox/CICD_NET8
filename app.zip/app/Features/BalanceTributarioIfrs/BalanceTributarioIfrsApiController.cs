using Microsoft.AspNetCore.Mvc;

namespace App.Features.BalanceTributarioIfrs;

/// <summary>
/// API Controller para Balance Tributario IFRS (8 columnas).
/// </summary>
[ApiController]
[Route("api/[controller]/[action]")]
public class BalanceTributarioIfrsApiController(
    IBalanceTributarioIfrsService service,
    ILogger<BalanceTributarioIfrsApiController> logger) : ControllerBase
{
    /// <summary>
    /// Genera el Balance Tributario IFRS.
    /// </summary>
    /// <param name="request">Parámetros de filtrado.</param>
    /// <returns>Balance con estructura de 8 columnas.</returns>
    [HttpPost]
    public async Task<ActionResult<BalanceTributarioIfrsResponseDto>> Generar(
        [FromBody] BalanceTributarioIfrsRequestDto request)
    {
        {
            var resultado = await service.GenerarAsync(request);
            return Ok(resultado);
        }
    }

    /// <summary>
    /// Valida el plan de cuentas actual.
    /// </summary>
    /// <returns>Información sobre la validez del plan.</returns>
    [HttpGet]
    public async Task<ActionResult> ValidarPlan()
    {
        {
            var (esValido, planActual) = await service.ValidarPlanCuentasAsync();

            return Ok(new
            {
                esValido,
                planActual,
                mensaje = esValido
                    ? $"Plan de cuentas '{planActual}' es compatible con IFRS"
                    : "El plan de cuentas actual no es compatible. Se requiere: Básico, Intermedio, Avanzado o IFRS"
            });
        }
    }

    /// <summary>
    /// Verifica si existen cuentas sin clasificación IFRS.
    /// </summary>
    /// <param name="fechaHasta">Fecha hasta para verificar saldos.</param>
    /// <returns>True si hay cuentas sin clasificar con saldo.</returns>
    [HttpGet]
    public async Task<ActionResult> ValidarClasificacion([FromQuery] DateTime fechaHasta)
    {
        {
            var existen = await service.ExistenCuentasSinClasificacionIfrsAsync(fechaHasta);

            return Ok(new
            {
                existen,
                mensaje = existen
                    ? "Atención: Existen cuentas con saldo distinto de cero que no tienen clasificación IFRS"
                    : "Todas las cuentas con saldo tienen clasificación IFRS"
            });
        }
    }

    /// <summary>
    /// Obtiene las áreas de negocio disponibles.
    /// </summary>
    /// <returns>Lista de áreas de negocio.</returns>
    [HttpGet]
    public async Task<ActionResult> ObtenerAreasNegocio()
    {
        {
            var items = await service.ObtenerAreasNegocioAsync();
            return Ok(items);
        }
    }

    /// <summary>
    /// Obtiene los centros de costo disponibles.
    /// </summary>
    /// <returns>Lista de centros de costo.</returns>
    [HttpGet]
    public async Task<ActionResult> ObtenerCentrosCosto()
    {
        {
            var items = await service.ObtenerCentrosCostoAsync();
            return Ok(items);
        }
    }

    /// <summary>
    /// Exporta el Balance Tributario IFRS a PDF.
    /// </summary>
    /// <param name="request">Parámetros del balance a exportar.</param>
    /// <param name="incluirMembrete">Si debe incluir membrete de la empresa.</param>
    /// <returns>Archivo PDF del balance.</returns>
    [HttpPost]
    public async Task<ActionResult> ExportarPdf(
        [FromBody] BalanceTributarioIfrsRequestDto request,
        [FromQuery] bool incluirMembrete = true)
    {
        {
            var pdfBytes = await service.ExportarPdfAsync(request, incluirMembrete);

            if (pdfBytes.Length == 0)
            {
                return BadRequest(new
                {
                    error = "La generación de PDF aún no está implementada completamente",
                    mensaje = "Por favor use 'Imprimir' o 'Copiar a Excel' como alternativa"
                });
            }

            var fileName = $"BalanceTributarioIFRS_{DateTime.Now:yyyyMMdd_HHmmss}.pdf";
            return File(pdfBytes, "application/pdf", fileName);
        }
    }
}
