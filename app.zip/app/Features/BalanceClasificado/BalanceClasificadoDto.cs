namespace App.Features.BalanceClasificado;

public class BalanceClasificadoDto
{
    public int IdEmpresa { get; set; }
    public short Ano { get; set; }
    public DateTime FechaCorte { get; set; }
    public List<BalanceClasificadoFila> Filas { get; set; } = new();
    public decimal TotalActivo { get; set; }
    public decimal TotalPasivo { get; set; }
    public decimal TotalPatrimonio { get; set; }
}

public class BalanceClasificadoFila
{
    public string Codigo { get; set; } = "";
    public string Descripcion { get; set; } = "";
    public int Nivel { get; set; }
    public int Clasificacion { get; set; }
    public decimal Saldo { get; set; }
    public bool EsTitulo { get; set; }
    public bool MostrarCodigo { get; set; } = true; // VB6: Ch_VerCodCuenta
    public bool EsLineaTotal { get; set; } = false; // TOTAL ACTIVO, TOTAL PASIVO, etc.
    public bool EsResultadoEjercicio { get; set; } = false; // L�nea "Resultado del Ejercicio"
    public bool EsNegrita { get; set; } = false; // VB6: FGrSetRowStyle "B"
}

public class BalanceClasificadoRequest
{
    public int IdEmpresa { get; set; }
    public int EmpresaId 
    { 
        get => IdEmpresa; 
        set => IdEmpresa = value; 
    }
    
    public short Ano { get; set; }
    public DateTime FechaCorte { get; set; }
    
    // Alias para fechas (frontend env�a fechaDesde/fechaHasta)
    public DateTime? FechaDesde { get; set; }
    public DateTime? FechaHasta 
    { 
        get => FechaCorte != default ? FechaCorte : null; 
        set => FechaCorte = value ?? DateTime.Now; 
    }
    
    public int NivelDetalle { get; set; } = 5;
    
    // Alias para compatibilidad con frontend (nivel ? nivelDetalle)
    public int? Nivel 
    { 
        get => NivelDetalle; 
        set => NivelDetalle = value ?? 5; 
    }
    
    // Filtros VB6
    public int? IdAreaNegocio { get; set; }
    public int? IdCentroCosto { get; set; }
    public int? TipoAjuste { get; set; }
    public int? AreaNegocioId { get => IdAreaNegocio; set => IdAreaNegocio = value; } // Alias
    public int? CentroCostoId { get => IdCentroCosto; set => IdCentroCosto = value; } // Alias
    public bool LibroOficial { get; set; } = false; // Ch_LibOficial
    public bool SoloLibroOficial { get => LibroOficial; set => LibroOficial = value; } // Alias
    public bool VerSubTotales { get; set; } = false; // Ch_VerSubTot
    public bool VerCodigoCuenta { get; set; } = true; // Ch_VerCodCuenta
}

public class BalanceClasificadoResponse
{
    public BalanceClasificadoDto Balance { get; set; } = new();
    public bool Success { get; set; } = true;
    public string Message { get; set; } = "";
}

public class BalanceClasificadoOpciones
{
    public List<int> Niveles { get; set; } = new();
    public List<OpcionSelect> Clasificaciones { get; set; } = new();
    public List<OpcionSelect> TiposAjuste { get; set; } = new();
    public List<OpcionSelect> AreasNegocio { get; set; } = new();
    public List<OpcionSelect> CentrosCosto { get; set; } = new();
}

public class OpcionSelect
{
    public int Id { get; set; }
    public string? Codigo { get; set; }
    public string Nombre { get; set; } = "";
    public string? Descripcion { get; set; }
    
    // Propiedades para compatibilidad con Views
    public int Value => Id;
    public string Text => !string.IsNullOrEmpty(Descripcion) ? $"{Codigo} - {Descripcion}" : 
                          !string.IsNullOrEmpty(Codigo) ? $"{Codigo} - {Nombre}" : Nombre;
}

public class BalanceClasificadoExportRequest
{
    public BalanceClasificadoRequest Request { get; set; } = new();
    public string Formato { get; set; } = "PDF"; // PDF, EXCEL
}

public class BalanceClasificadoExportResponse
{
    public byte[] Data { get; set; } = new byte[0];
    public byte[] FileContent => Data; // Alias para compatibilidad con views
    public string ContentType { get; set; } = "";
    public string FileName { get; set; } = "";
}

public class SumaMovimientosRequest
{
    public int IdEmpresa { get; set; }
    public short Ano { get; set; }
    public List<int> IdCuentas { get; set; } = new();
}

public class SumaMovimientosResponse
{
    public decimal Total { get; set; }
    public List<object> Detalles { get; set; } = new();
}

public class ValidationResult
{
    public bool IsValid { get; set; } = true;
    public List<string> Errors { get; set; } = new();
    public List<string> Warnings { get; set; } = new();
    
    public static ValidationResult Success() => new() { IsValid = true };
    public static ValidationResult Error(string message) => new() { IsValid = false, Errors = { message } };
}
