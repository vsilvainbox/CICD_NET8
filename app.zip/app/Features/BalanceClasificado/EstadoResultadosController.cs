using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.BalanceClasificado;

/// <summary>
/// Controller para Estado de Resultados por Función
/// </summary>
public class EstadoResultadosController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<EstadoResultadosController> logger) : Controller
{
    /// <summary>
    /// Vista principal del estado de resultados
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Index()
    {
        {
            ViewBag.FechaDesde = new DateTime(SessionHelper.Ano, 1, 1).ToString("yyyy-MM-dd");
            ViewBag.FechaHasta = DateTime.Now.ToString("yyyy-MM-dd");

            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(BalanceClasificadoApiController.GetOpcionesFiltros),
                controller: nameof(BalanceClasificadoApiController).Replace("Controller", ""),
                values: new { empresaId = SessionHelper.EmpresaId, ano = SessionHelper.Ano });
            var opcionesFiltros = await client.GetFromApiAsync<BalanceClasificadoOpciones>(url!);

            ViewBag.OpcionesFiltros = opcionesFiltros;
            logger.LogInformation("Index: Opciones de filtros cargadas exitosamente para empresaId={EmpresaId}, ano={Ano}",
                SessionHelper.EmpresaId, SessionHelper.Ano);

            return View("~/Features/BalanceClasificado/Views/EstadoResultados/Index.cshtml");
        }
    }

    /// <summary>
    /// Proxy: Genera el estado de resultados (POST a Index)
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Index([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: Generar estado de resultados via Index POST");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(EstadoResultadosApiController.Generar),
                controller: nameof(EstadoResultadosApiController).Replace("Controller", ""));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// Obtiene las funciones disponibles para clasificación
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ObtenerFunciones()
    {
        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(EstadoResultadosApiController.ObtenerFunciones),
                controller: nameof(EstadoResultadosApiController).Replace("Controller", ""));
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Proxy: Genera el estado de resultados (POST)
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Generar([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: Generar estado de resultados");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(EstadoResultadosApiController.Generar),
                controller: nameof(EstadoResultadosApiController).Replace("Controller", ""));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// Proxy: Exporta el estado de resultados (POST)
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Exportar([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: Exportar estado de resultados");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(EstadoResultadosApiController.Exportar),
                controller: nameof(EstadoResultadosApiController).Replace("Controller", ""));
            var (fileBytes, contentType) = await client.DownloadFileAsync(
                url,
                HttpMethod.Post,
                request);

            var fileName = "EstadoResultados.xlsx";
            return File(fileBytes, contentType, fileName);
        }
    }

    /// <summary>
    /// Proxy: Obtiene análisis del estado de resultados (POST)
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Analisis([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: Obtener análisis estado de resultados");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(EstadoResultadosApiController.ObtenerAnalisis),
                controller: nameof(EstadoResultadosApiController).Replace("Controller", ""));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// Proxy: Obtiene gráficos del estado de resultados (POST)
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Graficos([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: Obtener gráficos estado de resultados");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(EstadoResultadosApiController.ObtenerGraficos),
                controller: nameof(EstadoResultadosApiController).Replace("Controller", ""));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }
}