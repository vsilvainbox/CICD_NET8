# VALIDACIÓN: BalanceClasificado Implementation vs VB6 Analysis

**Fecha:** 11 de Octubre de 2025  
**Service:** `BalanceClasificadoService.cs` (459 líneas)  
**Analysis:** `Analysis.md` + Parts 1-3 (~2,100 líneas documentación)

---

## ✅ IMPLEMENTACIONES CORRECTAS

### 1. Constantes y Configuración ✓

```csharp
// Lines 14-27
private const int CLASCTA_ACTIVO = 1;
private const int CLASCTA_PASIVO = 2;
private const int CLASCTA_RESULTADO = 3;
private const int CLASCTA_ORDEN = 4;

private const int EC_APROBADO = 1;
private const int EC_PENDIENTE = 2;
private const int EC_ANULADO = 3;

private const int TAJUSTE_FINANCIERO = 1;
private const int TAJUSTE_TRIBUTARIO = 2;
private const int TAJUSTE_AMBOS = 3;
```

**Status:** ✅ CORRECTO - Mapeo fiel a VB6

---

### 2. GenerarBalanceAsync() ✓

**Lines 36-114**

```csharp
public async Task<BalanceClasificadoResponse> GenerarBalanceAsync(...)
{
    // Construcción de WHERE clause con filtros
    var whereClause = $"c.Fecha BETWEEN {fechaDesde} AND {fechaHasta}";
    
    if (request.IdAreaNegocio.HasValue && request.IdAreaNegocio > 0)
        whereClause += $" AND m.idAreaNeg = {request.IdAreaNegocio}";
    
    if (request.IdCentroCosto.HasValue && request.IdCentroCosto > 0)
        whereClause += $" AND m.idCCosto = {request.IdCentroCosto}";
    
    if (request.TipoAjuste.HasValue && request.TipoAjuste > 0) { ... }
    
    if (request.LibroOficial)
        whereClause += $" AND c.Estado = {EC_APROBADO}";
    else
        whereClause += $" AND c.Estado IN ({EC_APROBADO}, {EC_PENDIENTE})";
}
```

**Status:** ✅ CORRECTO - Lógica idéntica a VB6 Bt_Buscar_Click() y LoadAll()

---

### 3. GetOpcionesFiltrosAsync() ✓

**Lines 116-163**

```csharp
// Áreas de Negocio
var areasNegocio = await _context.AreaNegocio
    .Where(a => a.IdEmpresa == empresaId)
    .OrderBy(a => a.Codigo)
    .ToListAsync();

// Centros de Costo
var centrosCosto = await _context.CentroCosto
    .Where(c => c.IdEmpresa == empresaId)
    .OrderBy(c => c.Codigo)
    .ToListAsync();

// Niveles 2-5
Niveles = Enumerable.Range(2, 4).ToList(),

// Tipos de Ajuste
TiposAjuste = new List<OpcionSelect>
{
    new OpcionSelect { Id = TAJUSTE_FINANCIERO, Nombre = "FINANCIERO" },
    new OpcionSelect { Id = TAJUSTE_TRIBUTARIO, Nombre = "TRIBUTARIO" }
}
```

**Status:** ✅ CORRECTO - Mapeo fiel a VB6 Form_Load combos

---

### 4. CalcularSaldoCuenta() ✓

**Lines 239-252**

```csharp
private decimal CalcularSaldoCuenta(decimal debe, decimal haber, int clasificacion)
{
    switch (clasificacion)
    {
        case CLASCTA_ACTIVO:
        case CLASCTA_ORDEN:
            return debe - haber;  // Activo: Debe - Haber
        case CLASCTA_PASIVO:
        case CLASCTA_RESULTADO:
            return haber - debe;  // Pasivo/Resultado: Haber - Debe
        default:
            return debe - haber;
    }
}
```

**Status:** ✅ CORRECTO - Lógica idéntica a VB6 LoadAll

---

### 5. ValidarFiltrosAsync() ✓

**Lines 397-420**

```csharp
if (request.FechaCorte < new DateTime(request.Ano, 1, 1) || 
    request.FechaCorte > new DateTime(request.Ano, 12, 31))
    errors.Add("Fecha de corte debe estar dentro del año seleccionado");
```

**Status:** ✅ CORRECTO - Equivale a validaciones VB6 Bt_Buscar_Click()

**⚠️ FALTA:**
- Validación: `FechaDesde <= FechaHasta`
- Mensaje: "Fecha de inicio es posterior a la fecha de término del reporte."

---

## ❌ IMPLEMENTACIONES INCOMPLETAS

### 1. GenQueryPorNiveles() - PARCIAL ⚠️

**VB6:** UNION de 6 queries (IdQ 1-6) para jerarquía completa  
**Actual (Lines 165-235):** Solo 2 queries implementadas

```csharp
// ✅ Query 1: Cuentas sin movimientos (líneas 165-179)
var cuentasSinMov = await _context.Cuentas
    .Where(c => c.IdEmpresa == empresaId && c.Ano == ano && c.Nivel <= nivel)
    .Select(...).ToListAsync();

// ✅ Query 2: Cuentas con movimientos directos (líneas 181-208)
var sql = @"SELECT c.Codigo, c.Descripcion, c.Nivel, c.Clasificacion,
            SUM(m.Debe) as TotalDebe, SUM(m.Haber) as TotalHaber
            FROM Cuentas c
            INNER JOIN MovComprobante m ON c.idCuenta = m.IdCuenta
            INNER JOIN Comprobante co ON m.IdComp = co.IdComp
            WHERE c.IdEmpresa = {empresaId} AND c.Nivel <= {nivel} ...
            GROUP BY c.idCuenta, c.Codigo, c.Descripcion, c.Nivel, c.Clasificacion";

// ❌ FALTA: Query 3 (padre), Query 4 (abuelo), Query 5 (bisabuelo), Query 6 (tatarabuelo)
// TODO: Implementar UNION 3, 4, 5 para niveles padre, abuelo, bisabuelo
```

**IMPACTO:**  
- ❌ Cuentas de nivel inferior no suman a cuentas padre
- ❌ Totales por clasificación incorrectos si hay jerarquías >2 niveles

**RECOMENDACIÓN:**
```csharp
// Query 3: Suma de hijos (padre = nivel X)
var sql3 = @"SELECT c1.Codigo, c1.Descripcion, c1.Nivel, c1.Clasificacion,
             SUM(m.Debe) as TotalDebe, SUM(m.Haber) as TotalHaber
             FROM Cuentas c
             INNER JOIN MovComprobante m ON c.idCuenta = m.IdCuenta
             INNER JOIN Comprobante co ON m.IdComp = co.IdComp
             INNER JOIN Cuentas c1 ON c.idPadre = c1.idCuenta
             WHERE c1.Nivel = {nivel} AND c1.IdEmpresa = {empresaId} ...
             GROUP BY c1.idCuenta, c1.Codigo, c1.Descripcion, c1.Nivel, c1.Clasificacion";

// Repetir patrón para Query 4, 5, 6 con más INNER JOINs (abuelo, bisabuelo, tatarabuelo)
```

---

### 2. AddResEjercicio() - NO IMPLEMENTADO ❌

**VB6:** FrmBalClasif.frm líneas 1764-1813  
**Actual:** NO EXISTE

**Propósito:**  
Insertar fila "Resultado del Ejercicio" en Balance Clasificado (lBalClasif=TRUE)  
Ubicación: Después de TOTAL PASIVO, antes de TOTAL PATRIMONIO

**Lógica VB6:**
```vb6
ResEjercicio = TotClasif(CLASCTA_PASIVO) - TotClasif(CLASCTA_ACTIVO)

Grid.TextMatrix(i, C_CUENTA) = "Resultado del Ejercicio"
Grid.TextMatrix(i, C_NIVEL) = 1
Grid.TextMatrix(i, C_CLASCTA) = CLASCTA_PASIVO
Grid.TextMatrix(i, C_SALDO) = Format(ResEjercicio, NEGNUMFMT)

TotClasif(CLASCTA_PASIVO) = TotClasif(CLASCTA_PASIVO) + ResEjercicio
```

**IMPLEMENTACIÓN REQUERIDA:**
```csharp
// En GenerarBalanceAsync(), después de calcular totales por clasificación:

if (request.TipoReporte == "Balance") // Solo para Balance, no Estado Resultados
{
    var resEjercicio = totalPasivo - totalActivo;
    
    var filaResEjercicio = new BalanceClasificadoFila
    {
        IdCuenta = 0,
        Codigo = "",
        Descripcion = "Resultado del Ejercicio",
        Nivel = 1,
        Clasificacion = CLASCTA_PASIVO,
        Saldo = resEjercicio,
        EsTitulo = false,
        Formato = "B"
    };
    
    // Insertar después de cuentas PASIVO y antes del TOTAL PATRIMONIO
    int indexInsert = filas.FindLastIndex(f => f.Clasificacion == CLASCTA_PASIVO);
    if (indexInsert >= 0)
        filas.Insert(indexInsert + 1, filaResEjercicio);
    
    // Actualizar total Pasivo
    totalPasivo += resEjercicio;
}
```

---

### 3. Líneas TOTAL por Clasificación - NO IMPLEMENTADO ❌

**VB6:** FrmBalClasif.frm líneas 1088-1152 (sección 7.1)  
**Actual:** NO EXISTE

**Propósito:**  
Agregar filas "TOTAL ACTIVO", "TOTAL PASIVO", "TOTAL RESULTADO" al cambiar de cuenta padre nivel 1

**Lógica VB6:**
```vb6
If CodPadre <> "" Then
  i = i + 1
  Grid.rows = i + 1
  Call FGrSetRowStyle(Grid, i, "B")  ' Bold
  
  Grid.TextMatrix(i, C_CUENTA) = "TOTAL " & UCase(NomPadre)  ' "TOTAL ACTIVO"
  Grid.TextMatrix(i, C_IDCUENTA) = TOT_CUENTA  ' -1
  Grid.TextMatrix(i, C_CLASCTA) = ClasifPadre
  Grid.TextMatrix(i, C_FMT) = "B"
  
  Grid.TextMatrix(i, C_DEBITOS) = Format(Total(1).Debe, NEGNUMFMT)
  Grid.TextMatrix(i, C_CREDITOS) = Format(Total(1).Haber, NEGNUMFMT)
  Grid.TextMatrix(i, C_SALDO) = Format(TotClasif(ClasifPadre), NEGNUMFMT)
End If
```

**IMPLEMENTACIÓN REQUERIDA:**
```csharp
// Después de procesar todas las cuentas, agrupar por Clasificación
var filasPorClasif = filas.GroupBy(f => f.Clasificacion);

foreach (var grupo in filasPorClasif)
{
    var totalDebe = grupo.Sum(f => f.Debe);
    var totalHaber = grupo.Sum(f => f.Haber);
    var totalSaldo = grupo.Sum(f => f.Saldo);
    
    var nombreClasif = grupo.Key switch
    {
        CLASCTA_ACTIVO => "ACTIVO",
        CLASCTA_PASIVO => "PASIVO",
        CLASCTA_RESULTADO => "RESULTADO",
        CLASCTA_ORDEN => "ORDEN",
        _ => "DESCONOCIDO"
    };
    
    var filaTotal = new BalanceClasificadoFila
    {
        IdCuenta = -1, // TOT_CUENTA
        Codigo = "",
        Descripcion = $"TOTAL {nombreClasif}",
        Nivel = 1,
        Clasificacion = grupo.Key,
        Debe = totalDebe,
        Haber = totalHaber,
        Saldo = totalSaldo,
        EsTitulo = true,
        Formato = "B"
    };
    
    // Insertar después de última cuenta de esta clasificación
    int lastIndex = filas.FindLastIndex(f => f.Clasificacion == grupo.Key && f.IdCuenta != -1);
    if (lastIndex >= 0)
        filas.Insert(lastIndex + 1, filaTotal);
}
```

---

### 4. Formato de Filas (Bold/Underline) - NO IMPLEMENTADO ❌

**VB6:** FrmBalClasif.frm líneas 1056-1062  
**Actual:** Property `Formato` existe en DTO pero NO se asigna

**Lógica VB6:**
```vb6
If vFld(Rs("Nivel")) = 1 Then
  Call FGrSetRowStyle(Grid, i, "BU")  ' Bold + Underline
ElseIf vFld(Rs("Nivel")) = 2 Then
  Call FGrSetRowStyle(Grid, i, "B")   ' Bold
End If
```

**IMPLEMENTACIÓN REQUERIDA:**
```csharp
// En GenerarQueryPorNivelesAsync(), al convertir a FilaBalance:

foreach (var cuenta in cuentasConMov)
{
    var fila = new BalanceClasificadoFila
    {
        // ... otros campos
        Formato = cuenta.Nivel switch
        {
            1 => "BU", // Bold + Underline
            2 => "B",  // Bold
            _ => ""    // Normal
        }
    };
    
    filas.Add(fila);
}
```

---

### 5. Exportaciones Excel/PDF - PLACEHOLDERS ❌

**Lines 435-445**

```csharp
private async Task<byte[]> GenerarPdfAsync(BalanceClasificadoDto balance)
{
    // TODO: Implementar generación PDF con librería como iTextSharp o QuestPDF
    _logger.LogWarning("Generación PDF no implementada - retornando placeholder");
    return System.Text.Encoding.UTF8.GetBytes($"Balance Clasificado PDF - {balance.Ano}");
}

private async Task<byte[]> GenerarExcelAsync(BalanceClasificadoDto balance)
{
    // TODO: Implementar generación Excel con EPPlus
    _logger.LogWarning("Generación Excel no implementada - retornando placeholder");
    return System.Text.Encoding.UTF8.GetBytes($"Balance Clasificado Excel - {balance.Ano}");
}
```

**IMPACTO:** ❌ Botones "Copiar Excel" y "Vista Previa PDF" no funcionan

**IMPLEMENTACIÓN REQUERIDA:** Ver `Analysis.md` líneas 481-599 (código completo EPPlus y QuestPDF)

---

### 6. Libro Oficial - NO IMPLEMENTADO ❌

**VB6:** 
- `QryLogImpreso()` - Verificar impresión previa (líneas 157-167 VB6)
- `AddLogImpresion()` - Registrar impresión (líneas 169-180 VB6)
- Tabla: `LogImpresion`

**Actual:** NO EXISTE

**FUNCIONALIDADES FALTANTES:**
1. Verificar si balance oficial ya fue impreso
2. Mostrar warning con fecha, usuario, período previo
3. Registrar nueva impresión oficial con folio
4. Validar papel foliado (número página inicio/fin)

**IMPLEMENTACIÓN REQUERIDA:**
```csharp
public interface IBalanceClasificadoService
{
    Task<LogImpresionDto?> VerificarImpresionPreviaAsync(int empresaId, int ano, int idLibro);
    Task RegistrarImpresionOficialAsync(LogImpresionDto log);
}

// Ver Analysis.md líneas 370-392 para código VB6 completo
```

---

### 7. Columnas Mensuales - NO IMPLEMENTADO ❌

**VB6:** FrmBalClasif.frm líneas 1026-1033  
**Actual:** NO EXISTE

**Propósito:**  
Si `lMensual = TRUE`, agregar 12 columnas (Enero-Diciembre) con saldos mensuales

**Lógica VB6:**
```vb6
If lMensual And Not lComparativo Then
  For k = 1 To 12
    Mes = C_INI_MES + k - 1
    Grid.ColWidth(Mes) = G_VALWIDTH + 100
    Grid.TextMatrix(0, Mes) = gNomMes(k)  ' "Enero", "Febrero", ...
  Next k
End If

' En LoadAll, por cada fila:
If lMensual Then
  For k = 1 To 12
    Mes = C_INI_MES + k - 1
    Grid.TextMatrix(i, Mes) = Format(SaldoMes(k), NEGNUMFMT)
  Next k
End If
```

**IMPLEMENTACIÓN REQUERIDA:**
- DTO `FilaBalance` debe tener `Dictionary<int, decimal>? SaldosPorMes`
- GenQueryPorNiveles debe agregar `SELECT MONTH(c.Fecha) as Mes` y `GROUP BY MONTH(c.Fecha)`
- Vista debe renderizar 12 columnas adicionales

---

## 📊 RESUMEN DE GAPS

| Feature | VB6 | .NET | Status | Prioridad |
|---------|-----|------|--------|-----------|
| Constantes y configuración | ✓ | ✓ | ✅ COMPLETO | - |
| GenerarBalanceAsync() | ✓ | ✓ | ✅ COMPLETO | - |
| GetOpcionesFiltrosAsync() | ✓ | ✓ | ✅ COMPLETO | - |
| CalcularSaldoCuenta() | ✓ | ✓ | ✅ COMPLETO | - |
| ValidarFiltrosAsync() | ✓ | ⚠️ | ⚠️ PARCIAL | MEDIA |
| GenQueryPorNiveles (UNION 1-2) | ✓ | ✓ | ✅ COMPLETO | - |
| GenQueryPorNiveles (UNION 3-6) | ✓ | ❌ | ❌ FALTA | **ALTA** |
| AddResEjercicio() | ✓ | ❌ | ❌ FALTA | **ALTA** |
| Líneas TOTAL clasificación | ✓ | ❌ | ❌ FALTA | **ALTA** |
| Formato filas (Bold/Underline) | ✓ | ❌ | ❌ FALTA | BAJA |
| Exportar Excel (EPPlus) | ✓ | ❌ | ❌ FALTA | **ALTA** |
| Exportar PDF (QuestPDF) | ✓ | ❌ | ❌ FALTA | **ALTA** |
| Libro Oficial - Verificar | ✓ | ❌ | ❌ FALTA | **ALTA** |
| Libro Oficial - Registrar | ✓ | ❌ | ❌ FALTA | **ALTA** |
| Columnas mensuales | ✓ | ❌ | ❌ FALTA | MEDIA |

---

## 🎯 RECOMENDACIONES PRIORITARIAS

### 1. CRÍTICO: Completar GenQueryPorNiveles (UNION 3-6)

**Sin esto, los saldos jerárquicos están incorrectos.**

```csharp
// Implementar queries 3-6 con patrón:
// Query 3: padre (C1), Query 4: abuelo (C2), Query 5: bisabuelo (C3), Query 6: tatarabuelo (C4)
```

**Estimación:** 4-6 horas  
**Riesgo actual:** ALTO - Totales incorrectos en balances con >2 niveles

---

### 2. CRÍTICO: Implementar AddResEjercicio()

**Balance Clasificado no muestra "Resultado del Ejercicio".**

**Estimación:** 1-2 horas  
**Riesgo actual:** ALTO - Balance no cuadra (Activo ≠ Pasivo + Patrimonio)

---

### 3. CRÍTICO: Implementar Líneas TOTAL

**Sin totales por clasificación, reporte es ilegible.**

**Estimación:** 2-3 horas  
**Riesgo actual:** ALTO - Falta información esencial

---

### 4. ALTA: Implementar Exportaciones

**Usuarios necesitan Excel/PDF para compartir/imprimir.**

**Estimación:** 
- Excel: 3-4 horas
- PDF: 4-5 horas

**Riesgo actual:** MEDIO - Workaround: copiar/pegar manual

---

### 5. ALTA: Implementar Libro Oficial

**Requisito legal para auditorías.**

**Estimación:** 3-4 horas  
**Riesgo actual:** MEDIO - Falta trazabilidad legal

---

## ✅ CONCLUSIÓN

**Estado Actual:** ~50% implementado  
**Fidelidad VB6:** ⚠️ PARCIAL

**Funcionalidades Core:** ✅ Funcionan (queries básicas, filtros, cálculos)  
**Funcionalidades Avanzadas:** ❌ Faltan (jerarquías completas, totales, exports, libro oficial)

**Próximos Pasos:**
1. Implementar UNION 3-6 en GenQueryPorNiveles
2. Agregar AddResEjercicio()
3. Agregar líneas TOTAL por clasificación
4. Implementar exportaciones Excel/PDF
5. Implementar registro libro oficial

**Tiempo Estimado Total:** 18-25 horas de desarrollo adicional
