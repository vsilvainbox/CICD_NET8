using Microsoft.AspNetCore.Mvc;

namespace App.Features.AsistenteImportacionPrimeraCategoria;

[ApiController]
[Route("api/[controller]/[action]")]
public class AsistenteImportacionPrimeraCategoriaApiController(
    IAsistenteImportacionPrimeraCategoriaService service,
    ILogger<AsistenteImportacionPrimeraCategoriaApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IEnumerable<AsistenteImportacionPrimeraCategoriaDto>>> GetDatos(
        [FromQuery] int empresaId, 
        [FromQuery] short ano)
    {
        logger.LogInformation("API: GetDatos called with empresaId: {EmpresaId}, ano: {Ano}", 
            empresaId, ano);

        {
            if (empresaId <= 0 || ano <= 0)
                return BadRequest(new { message = "EmpresaId y Ano son requeridos y deben ser mayores a 0" });

            var items = await service.GetAllItemsAsync(empresaId, ano);
            logger.LogInformation("API: Returning {Count} items", items.Count());
            return Ok(items);
        }
    }

    [HttpGet]
    public async Task<ActionResult<AsistenteImportacionPrimeraCategoriaDto>> GetById(int id)
    {
        logger.LogInformation("API: GetById called with id: {Id}", id);

        {
            var item = await service.GetByIdAsync(id);
            if (item == null)
            {
                logger.LogWarning("API: Item not found with id: {Id}", id);
                return NotFound(new { message = $"Item with id {id} not found" });
            }

            logger.LogInformation("API: Returning item with id: {Id}", id);
            return Ok(item);
        }
    }

    [HttpPost]
    public async Task<ActionResult<ValidationResult>> Save(
        [FromQuery] int empresaId, 
        [FromQuery] short ano, 
        [FromBody] List<AsistenteImportacionPrimeraCategoriaDto> items)
    {
        logger.LogInformation("API: Save called with empresaId: {EmpresaId}, ano: {Ano}, count: {Count}", 
            empresaId, ano, items.Count);

        {
            if (empresaId <= 0 || ano <= 0)
                return BadRequest(new { message = "EmpresaId y Ano son requeridos" });

            if (items == null || !items.Any())
                return BadRequest(new { message = "No hay ítems para guardar" });

            var result = await service.SaveAllAsync(empresaId, ano, items);
                
            if (!result.IsValid)
            {
                logger.LogWarning("API: Validation failed: {Message}", result.ErrorMessage);
                return BadRequest(result);
            }

            logger.LogInformation("API: Successfully saved all items");
            return Ok(result);
        }
    }

    [HttpPost]
    public async Task<ActionResult<CalculationResult>> Calculate(
        [FromQuery] int empresaId, 
        [FromQuery] short ano, 
        [FromBody] List<AsistenteImportacionPrimeraCategoriaDto> items)
    {
        logger.LogInformation("API: Calculate called with empresaId: {EmpresaId}, ano: {Ano}", 
            empresaId, ano);

        {
            if (empresaId <= 0 || ano <= 0)
                return BadRequest(new { message = "EmpresaId y Ano son requeridos" });

            var result = await service.CalculateTotalsAsync(empresaId, ano, items);
            logger.LogInformation("API: Calculations completed");
            return Ok(result);
        }
    }

    [HttpPost]
    public async Task<ActionResult<ValidationResult>> Validate(
        [FromBody] List<AsistenteImportacionPrimeraCategoriaDto> items)
    {
        logger.LogInformation("API: Validate called with {Count} items", items.Count);

        {
            var result = await service.ValidateAsync(items);
            return Ok(result);
        }
    }

    [HttpGet]
    public async Task<ActionResult> ExportPdf([FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: ExportPdf called with empresaId: {EmpresaId}, ano: {Ano}", 
            empresaId, ano);

        {
            var pdfBytes = await service.ExportToPdfAsync(empresaId, ano);
                
            if (pdfBytes == null || pdfBytes.Length == 0)
                return NotFound(new { message = "No se pudo generar el PDF" });

            return File(pdfBytes, "application/pdf", 
                $"AsistenteIDPC_{empresaId}_{ano}.pdf");
        }
    }

    [HttpGet]
    public async Task<ActionResult<string>> ExportClipboard(
        [FromQuery] int empresaId, 
        [FromQuery] short ano)
    {
        logger.LogInformation("API: ExportClipboard called with empresaId: {EmpresaId}, ano: {Ano}", 
            empresaId, ano);

        {
            var clipboardText = await service.ExportToClipboardAsync(empresaId, ano);
            return Ok(new { data = clipboardText });
        }
    }
}