# Legacy Analysis: Configuración Remuneraciones

## 📄 Información del Formulario VB6

**Archivo VB6:** `old/Contabilidad70/HyperContabilidad/FrmConfigRemu.frm`
**Fecha Análisis:** 2025-01-01
**Analista:** IA
**Complejidad:** Media

### Propósito del Formulario

El formulario `FrmConfigRemu` permite configurar la integración entre el sistema de contabilidad y el módulo de remuneraciones (nóminas). Incluye:
- Mapeo de cuentas contables para remuneraciones
- Configuración de centros de costo para sueldos
- Cuentas para provisiones y descuentos
- Integración con sistemas externos de RRHH

## 🎨 CONTROLES UI IDENTIFICADOS

### ComboBoxes/TextBoxes (Mapeo de Cuentas)
| Control VB6 | Propiedad | Propósito |
|-------------|-----------|-----------|
| txtCtaSueldos | IdCuenta | Cuenta contable para sueldos |
| txtCtaGratificaciones | IdCuenta | Cuenta para gratificaciones |
| txtCtaBonoProduccion | IdCuenta | Cuenta para bonos |
| txtCtaProvisionVacaciones | IdCuenta | Cuenta provisión vacaciones |
| txtCtaDescuentosAFP | IdCuenta | Cuenta descuentos AFP |
| txtCtaDescuentosSalud | IdCuenta | Cuenta descuentos salud |
| txtCtaDescuentosImpuestos | IdCuenta | Cuenta retención impuestos |

### CheckBoxes (Opciones de Integración)
| Control VB6 | Propiedad | Propósito |
|-------------|-----------|-----------|
| chkIntegrarAutomatico | Config | Integración automática |
| chkGenerarComprobante | Config | Generar comprobante al importar |
| chkUsarCentroCosto | Config | Usar centros de costo por empleado |

### Botones de Acción
| Botón VB6 | Caption | Acción | Mapeo .NET |
|-----------|---------|--------|------------|
| cmdGuardar | "Guardar" | Guarda configuración | SaveAsync() |
| cmdCancelar | "Cancelar" | Cierra sin guardar | N/A (navegación) |
| cmdProbar | "Probar Conexión" | Prueba integración | TestConnectionAsync() |

## 💾 ACCESO A DATOS VB6

### Tabla Param (Configuración Remuneraciones)
```vb
Q1 = "SELECT * FROM Param WHERE Tipo = 'REMU'"
```

**Mapeo Entity Framework:**
```csharp
await _context.Param
    .Where(p => p.Tipo == "REMU")
    .ToListAsync();
```

## 🎯 MAPEO FINAL: MÉTODOS .NET DETERMINADOS

### Interface del Service
```csharp
public interface IConfiguracionRemuneracionesService
{
    Task<ConfiguracionRemuDto> GetConfigAsync(int empresaId);
    Task SaveConfigAsync(ConfiguracionRemuDto config);
    Task<bool> TestConnectionAsync(int empresaId);
    Task<IEnumerable<CuentaComboDto>> GetCuentasDisponiblesAsync(int empresaId);
}
```

### Endpoints API
```
GET  /api/ConfiguracionRemuneraciones?empresaId={id}  - Obtiene configuración
POST /api/ConfiguracionRemuneraciones                 - Guarda configuración
POST /api/ConfiguracionRemuneraciones/probar          - Prueba conexión
GET  /api/ConfiguracionRemuneraciones/cuentas         - Lista cuentas
```

## 📋 CASOS DE USO PRINCIPALES

### CU1: Configurar Mapeo de Cuentas
1. Usuario selecciona cuentas contables
2. Usuario configura opciones de integración
3. Usuario guarda configuración

### CU2: Probar Conexión
1. Usuario hace click en "Probar Conexión"
2. Sistema valida configuración
3. Sistema muestra resultado

## ⚠️ COMPLEJIDAD ESTIMADA

- **Media**: Configuración de mapeo de cuentas
- **Tiempo estimado**: 3-4 horas de desarrollo + testing

