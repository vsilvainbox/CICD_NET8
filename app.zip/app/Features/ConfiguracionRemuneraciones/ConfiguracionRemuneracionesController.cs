﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.ConfiguracionRemuneraciones;

public class ConfiguracionRemuneracionesController(IHttpClientFactory httpClientFactory, ILogger<ConfiguracionRemuneracionesController> logger, LinkGenerator linkGenerator) : Controller
{
    public Task<IActionResult> Index(int? ano = null)
    {
        logger.LogInformation("Loading ConfiguracionRemuneraciones Index for empresaId: {EmpresaId}", SessionHelper.EmpresaId);

        if (!ano.HasValue)
        {
            ano = SessionHelper.Ano;
        }

        ViewData["EmpresaId"] = SessionHelper.EmpresaId;
        ViewData["Ano"] = ano;

        return Task.FromResult<IActionResult>(View());
    }

    [HttpGet]
    public async Task<IActionResult> GetCuentas(int empresaId, short ano)
    {
        logger.LogInformation("Proxy: GetCuentas - empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        var client = httpClientFactory.CreateClient("ApiClient");
        var url = linkGenerator.GetPathByAction(
            action: nameof(ConfiguracionRemuneracionesApiController.GetCuentas),
            controller: nameof(ConfiguracionRemuneracionesApiController).Replace("Controller", ""),
            values: new { empresaId, ano });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    [HttpGet]
    public async Task<IActionResult> GetConfiguracion(int empresaId, short ano)
    {
        logger.LogInformation("Proxy: GetConfiguracion - empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        var client = httpClientFactory.CreateClient("ApiClient");
        var url = linkGenerator.GetPathByAction(
            action: nameof(ConfiguracionRemuneracionesApiController.GetConfiguracion),
            controller: nameof(ConfiguracionRemuneracionesApiController).Replace("Controller", ""),
            values: new { empresaId, ano });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    [HttpPost]
    public async Task<IActionResult> SaveConfiguracion([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: SaveConfiguracion");

        var client = httpClientFactory.CreateClient("ApiClient");
        var url = linkGenerator.GetPathByAction(
            action: nameof(ConfiguracionRemuneracionesApiController.SaveConfiguracion),
            controller: nameof(ConfiguracionRemuneracionesApiController).Replace("Controller", ""));
        var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }

    [HttpPost]
    public async Task<IActionResult> ProbarConexion(int empresaId)
    {
        logger.LogInformation("Proxy: ProbarConexion - empresaId: {EmpresaId}", empresaId);

        var client = httpClientFactory.CreateClient("ApiClient");
        var url = linkGenerator.GetPathByAction(
            action: nameof(ConfiguracionRemuneracionesApiController.ProbarConexion),
            controller: nameof(ConfiguracionRemuneracionesApiController).Replace("Controller", ""),
            values: new { empresaId });
        var (statusCode, content) = await client.ProxyRequestAsync(url!, null, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }
}