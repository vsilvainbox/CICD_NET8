using Microsoft.AspNetCore.Mvc;

namespace App.Features.ConfiguracionRemuneraciones;

[ApiController]
[Route("api/[controller]/[action]")]
public class ConfiguracionRemuneracionesApiController(
    IConfiguracionRemuneracionesService service,
    ILogger<ConfiguracionRemuneracionesApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<ConfiguracionRemuDto>> GetConfiguracion([FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        logger.LogInformation("API: GetConfiguracion called for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var config = await service.GetConfigAsync(empresaId, ano);
            return Ok(config);
        }
    }

    [HttpPost]
    public async Task<IActionResult> SaveConfiguracion([FromBody] ConfiguracionRemuDto config)
    {
        logger.LogInformation("API: SaveConfiguracion called for empresaId: {EmpresaId}", config.EmpresaId);

        {
            await service.SaveConfigAsync(config);
            return Ok(new { message = "ConfiguraciÃ³n guardada exitosamente" });
        }
    }

    [HttpPost]
    public async Task<ActionResult<ProbarConexionResultDto>> ProbarConexion([FromQuery] int empresaId)
    {
        logger.LogInformation("API: ProbarConexion called for empresaId: {EmpresaId}", empresaId);

        {
            var result = await service.TestConnectionAsync(empresaId);
            return Ok(result);
        }
    }

    [HttpGet]
    public async Task<ActionResult> GetCuentas([FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: GetCuentas called for empresaId: {EmpresaId}", empresaId);

        {
            var cuentas = await service.GetCuentasDisponiblesAsync(empresaId, ano);
            return Ok(cuentas);
        }
    }
}