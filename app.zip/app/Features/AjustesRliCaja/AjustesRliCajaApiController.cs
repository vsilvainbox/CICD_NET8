using Microsoft.AspNetCore.Mvc;

namespace App.Features.AjustesRliCaja;

[ApiController]
[Route("api/[controller]/[action]")]
public class AjustesRliCajaApiController(IAjustesRliCajaService service, ILogger<AjustesRliCajaApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<AjustesRliCajaDto>> GetAjustes(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        logger.LogInformation("API: GetAjustes ajustes RLI called");

        {
            var data = await service.GetAjustesAsync(empresaId, ano);
            return Ok(data);
        }
    }

    [HttpGet]
    public async Task<ActionResult> ExportarHrRabRad(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        logger.LogInformation("API: ExportarHrRabRad HR RAB/RAD called");

        {
            var csvData = await service.ExportarHrRabRadAsync(empresaId, ano);
            
            if (csvData == null || csvData.Length == 0)
            {
                return BadRequest(new { message = "No existen datos para generar archivo" });
            }

            var fileName = ano >= 2020 
                ? $"RLI_HR_RAD_{ano.ToString().Substring(2)}.csv"
                : $"RLI_HR_RAB_{ano.ToString().Substring(2)}.csv";

            return File(csvData, "text/csv", fileName);
        }
    }
}

