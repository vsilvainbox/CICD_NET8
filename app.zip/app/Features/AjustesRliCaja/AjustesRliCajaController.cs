using Microsoft.AspNetCore.Mvc;
using App.Extensions;

namespace App.Features.AjustesRliCaja;

public class AjustesRliCajaController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<AjustesRliCajaController> logger) : Controller
{
    public IActionResult Index()
    {
        logger.LogInformation("AjustesRliCaja index accessed");
            
        return View();
    }

    [HttpGet]
    public async Task<IActionResult> GetAjustes(int empresaId, short ano)
    {
        logger.LogInformation("Proxying GetAjustes: empresaId={EmpresaId}, ano={Ano}", empresaId, ano);

        var client = httpClientFactory.CreateClient("ApiClient");

        var url = linkGenerator.GetPathByAction(
            action: nameof(AjustesRliCajaApiController.GetAjustes),
            controller: nameof(AjustesRliCajaApiController).Replace("Controller", ""),
            values: new { empresaId, ano }
        );
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    [HttpGet]
    public async Task<IActionResult> ExportarHrRabRad(int empresaId, short ano)
    {
        logger.LogInformation("Proxying ExportarHrRabRad: empresaId={EmpresaId}, ano={Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AjustesRliCajaApiController.ExportarHrRabRad),
                controller: nameof(AjustesRliCajaApiController).Replace("Controller", ""),
                values: new { empresaId, ano }
            );
            var (fileBytes, contentType) = await client.DownloadFileAsync(url, HttpMethod.Get);
            return File(fileBytes, contentType);
        }
    }
}