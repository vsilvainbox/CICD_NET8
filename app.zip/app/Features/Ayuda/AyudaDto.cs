namespace App.Features.Ayuda;

/// <summary>
/// DTO para contenido de ayuda específico
/// </summary>
public class AyudaContentDto
{
    public string Titulo { get; set; } = string.Empty;
    public string Descripcion { get; set; } = string.Empty;
    public List<AyudaItemDto> Items { get; set; } = new();
}

/// <summary>
/// DTO para un elemento individual de ayuda
/// </summary>
public class AyudaItemDto
{
    public string Codigo { get; set; } = string.Empty;
    public string Descripcion { get; set; } = string.Empty;
    public string Detalle { get; set; } = string.Empty;
    public string Categoria { get; set; } = string.Empty; // "SOLO 14D3", "AMBOS", "SOLO 14D8"
    public string TipoOperacion { get; set; } = string.Empty; // "+", "-"
}

/// <summary>
/// DTO para tipos de ayuda disponibles
/// </summary>
public class AyudaTipoDto
{
    public int Id { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public string Descripcion { get; set; } = string.Empty;
    public string Icono { get; set; } = string.Empty;
}

/// <summary>
/// Enumeración para tipos de ayuda
/// </summary>
public enum TipoAyuda
{
    AjustesAumentos = 1,
    AjustesDisminuciones = 2
}