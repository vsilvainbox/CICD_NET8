using Microsoft.AspNetCore.Mvc;

namespace App.Features.ConfiguracionImpresionCheques;

/// <summary>
/// API Controller para gestionar configuración de impresión de cheques
/// </summary>
[Route("api/[controller]/[action]")]
[ApiController]
public class ConfiguracionImpresionChequesApiController(
    IConfiguracionImpresionChequesService service,
    ILogger<ConfiguracionImpresionChequesApiController> logger) : ControllerBase
{
    /// <summary>
    /// Obtiene la configuración de cheques para un tipo de papel
    /// </summary>
    /// <param name="tipoPapel">1=Hoja Carta, 2=Papel Continuo</param>
    /// <returns>Configuración de cheques</returns>
    [HttpGet]
    [ProducesResponseType(typeof(ConfiguracionChequesDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<ActionResult<ConfiguracionChequesDto>> GetConfiguracion(int tipoPapel)
    {
        {
            logger.LogInformation("GET api/ConfiguracionImpresionCheques/{TipoPapel}", tipoPapel);

            if (tipoPapel != 1 && tipoPapel != 2)
            {
                logger.LogWarning("Tipo de papel inválido: {TipoPapel}", tipoPapel);
                return BadRequest(new { message = "El tipo de papel debe ser 1 (Hoja Carta) o 2 (Papel Continuo)." });
            }

            var dto = await service.GetAsync(tipoPapel);

            return Ok(dto);
        }
    }

    /// <summary>
    /// Guarda la configuración de cheques
    /// </summary>
    /// <param name="dto">Datos de configuración a guardar</param>
    /// <returns>Resultado de la operación</returns>
    [HttpPost]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> SaveConfiguracion([FromBody] ConfiguracionChequesUpdateDto dto)
    {
        {
            logger.LogInformation("POST api/ConfiguracionImpresionCheques");

            if (!ModelState.IsValid)
            {
                logger.LogWarning("ModelState inválido al guardar configuración de cheques");
                return BadRequest(ModelState);
            }

            var success = await service.SaveAsync(dto);

            if (!success)
            {
                return BadRequest(new { message = "No se pudo guardar la configuración de cheques." });
            }

            return Ok(new { message = "Configuración de cheques guardada exitosamente." });
        }
    }

    /// <summary>
    /// Obtiene el tipo de papel actual configurado
    /// </summary>
    /// <returns>1=Hoja Carta, 2=Papel Continuo</returns>
    [HttpGet]
    [ProducesResponseType(typeof(int), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<ActionResult<int>> GetTipoPapelActual()
    {
        {
            logger.LogInformation("GET api/ConfiguracionImpresionCheques/tipo-papel-actual");

            var tipoPapel = await service.GetTipoPapelActualAsync();

            return Ok(tipoPapel);
        }
    }

    /// <summary>
    /// Establece el tipo de papel actual
    /// </summary>
    /// <param name="tipoPapel">1=Hoja Carta, 2=Papel Continuo</param>
    /// <returns>Resultado de la operación</returns>
    [HttpPost]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> SetTipoPapelActual(int tipoPapel)
    {
        {
            logger.LogInformation("POST api/ConfiguracionImpresionCheques/tipo-papel-actual/{TipoPapel}", tipoPapel);

            if (tipoPapel != 1 && tipoPapel != 2)
            {
                logger.LogWarning("Tipo de papel inválido: {TipoPapel}", tipoPapel);
                return BadRequest(new { message = "El tipo de papel debe ser 1 (Hoja Carta) o 2 (Papel Continuo)." });
            }

            var success = await service.SetTipoPapelActualAsync(tipoPapel);

            if (!success)
            {
                return BadRequest(new { message = "No se pudo establecer el tipo de papel actual." });
            }

            return Ok(new { message = "Tipo de papel actualizado exitosamente." });
        }
    }
}
