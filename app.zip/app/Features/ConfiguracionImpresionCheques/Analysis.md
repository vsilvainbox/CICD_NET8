# Legacy Analysis: Configuración Impresión Cheques

## 📄 Información del Formulario VB6

**Archivo VB6:** `vb6\VB50\FrmConfigCheque.frm`
**Fecha Análisis:** 2025-10-03
**Analista:** IA
**Complejidad:** Media

### Propósito del Formulario

Este formulario permite configurar los parámetros de posicionamiento para la impresión de cheques. El sistema soporta dos tipos de papel:

1. **Hoja Carta**: Cheques individuales en hoja tamaño carta
2. **Papel Continuo**: Cheques continuos para impresoras matriciales

Para cada tipo de papel, se configuran las posiciones (en twips) de los siguientes elementos en el cheque:
- Borde superior e izquierdo del cheque
- Valor en dígitos (posición vertical y horizontal)
- Fecha (posición vertical y horizontal)
- Año (opción para omitir primeros 2 dígitos, movimiento horizontal)
- "Orden De" (posición vertical y horizontal)
- Opciones para borrar "a la Orden De" y "al Portador"

**Nota:** 1 cm = 567 twips (unidad de medida VB6)

---

## 🎨 CONTROLES UI IDENTIFICADOS

### ComboBox (Selección)

| Control VB6 | Propiedad Bound | Tipo | Valores | Propósito |
|-------------|----------------|------|---------|-----------|
| Cb_Tipo | - | Integer | CHEQUE_CARTA (1), CHEQUE_CONTINUO (2) | Seleccionar tipo de papel |

### Textboxes (Campos Numéricos)

| Control VB6 | Propiedad Bound | Tipo | Validación | Propósito |
|-------------|----------------|------|------------|-----------|
| Tx_Sup | Param[Tipo="Cheques"] | Integer | Numérico | Distancia desde borde superior (o inferior si carta) |
| Tx_Izq | Param[Tipo="Cheques"] | Integer | Numérico | Distancia desde borde izquierdo |
| Tx_ValDig | Param[Tipo="Cheques"] | Integer | Numérico | Bajar valor en dígitos (vertical) |
| Tx_ValDigMove | Param[Tipo="Cheques"] | Integer | Numérico | Mover valor izq/der (horizontal) |
| Tx_Fecha | Param[Tipo="Cheques"] | Integer | Numérico | Bajar fecha (vertical) |
| Tx_FechaMove | Param[Tipo="Cheques"] | Integer | Numérico | Mover fecha izq/der (horizontal) |
| Tx_AnoMove | Param[Tipo="Cheques"] | Integer | Numérico | Mover año izq/der (horizontal) |
| Tx_OrdenDe | Param[Tipo="Cheques"] | Integer | Numérico | Bajar "Orden De" (vertical) |
| Tx_OrdenDeMove | Param[Tipo="Cheques"] | Integer | Numérico | Mover "Orden De" izq/der (horizontal) |

### Checkboxes

| Control VB6 | Propiedad Bound | Propósito |
|-------------|----------------|-----------|
| Ch_Omitir2DigAno | Param[Tipo="Cheques"] | Omitir primeros 2 dígitos del año (20XX → XX) |
| Ch_BorrarAlaOrden | Param[Tipo="Cheques"] | Borrar texto "a la Orden De" en cheque |
| Ch_BorrarAlPortador | Param[Tipo="Cheques"] | Borrar texto "al Portador" en cheque |

### Botones de Acción

| Botón VB6 | Caption | Habilitado Si | Acción | Mapeo .NET |
|-----------|---------|---------------|--------|------------|
| Bt_Ok | "Aceptar" | Siempre | Guardar configuración en INI file | SaveAsync() |
| Bt_Cancel | "Cancelar" | Siempre | Cerrar sin guardar | N/A (navegación) |
| Bt_Test | "Imprimir marca" | Siempre | Imprime marca de prueba en borde superior izquierdo | TestPrintAsync() |

---

## 🔘 EVENTOS IDENTIFICADOS

### Eventos de Formulario

| Evento VB6 | Cuándo Ocurre | Acciones | Mapeo .NET |
|------------|---------------|----------|------------|
| Form_Load | Al abrir form | Cargar combo tipo papel, cargar configuración actual | GetAsync(), cargar vista |

### Eventos de Combo

| Control.Evento | Trigger | Acción VB6 | Mapeo .NET |
|----------------|---------|------------|------------|
| Cb_Tipo_Click | Cambio tipo papel | LoadAll() - Cargar valores según tipo seleccionado | GetAsync(tipoPapel), actualizar campos en cliente |

### Eventos de TextBox

| Control.Evento | Trigger | Acción VB6 | Mapeo .NET |
|----------------|---------|------------|------------|
| Tx_*.Change | Cambio en cualquier campo | Cb_Tipo.Locked = True (bloquear cambio de tipo) | Validación en cliente |
| Tx_*.KeyPress | Tecla presionada | KeyNum() - Solo permitir números | HTML5 type="number" |

### Eventos de CheckBox

| Control.Evento | Trigger | Acción VB6 | Mapeo .NET |
|----------------|---------|------------|------------|
| Ch_*.Click | Click en checkbox | Cb_Tipo.Locked = True (bloquear cambio de tipo) | Validación en cliente |

---

## 🔧 FUNCIONES Y PROCEDIMIENTOS VB6

### Funciones Privadas

```vb
' Función: LoadAll
' Propósito: Cargar configuración actual desde INI file según tipo papel
' Parámetros: Ninguno (usa Cb_Tipo.ItemData global)
' Retorno: Void
' Mapeo .NET: GetAsync(tipoPapel) en Service
Private Sub LoadAll()
   Dim Tipo As Long
   Tipo = CbItemData(Cb_Tipo)
   
   If Tipo = CHEQUE_CARTA Then
      ' Cargar desde INI: "Cheques" -> "Altura", "BordeIzq", etc.
      Tx_Sup = GetIniString(gIniFile, "Cheques", "Altura", "")
      ' ... cargar demás campos
   Else
      ' Cargar desde INI: "Cheques" -> "PCont-BordeSup", "PCont-BordeIzq", etc.
      Tx_Sup = GetIniString(gIniFile, "Cheques", "PCont-BordeSup", "")
      ' ... cargar demás campos con prefijo "PCont-"
   End If
End Sub
```

```vb
' Función: Bt_OK_Click
' Propósito: Guardar configuración en INI file
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: SaveAsync(dto) en Service
Private Sub Bt_OK_Click()
   ' Guardar TipoPapel
   Call SetIniString(gIniFile, "Cheques", "TipoPapel", CbItemData(Cb_Tipo))
   
   If CbItemData(Cb_Tipo) = CHEQUE_CARTA Then
      ' Guardar sin prefijo: "Altura", "BordeIzq", etc.
      Call SetIniString(gIniFile, "Cheques", "Altura", vFmt(Tx_Sup))
      ' ... guardar demás campos
   Else
      ' Guardar con prefijo "PCont-": "PCont-BordeSup", etc.
      Call SetIniString(gIniFile, "Cheques", "PCont-BordeSup", vFmt(Tx_Sup))
      ' ... guardar demás campos con prefijo
   End If
   
   ' También actualiza variable global gPrtCheques
   Unload Me
End Sub
```

```vb
' Función: bt_Test_Click
' Propósito: Imprimir marca de prueba en esquina superior izquierda
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: TestPrintAsync() - Generar PDF de prueba
Private Sub bt_Test_Click()
   If Not PrepararPrt(FrmMain.Cm_PrtDlg) Then
      Exit Sub
   End If
   
   Call gPrtCheques.PrtMarca(Printer)
End Sub
```

### Lista Completa de Funciones

| Función VB6 | Tipo | Propósito | Mapeo .NET Method |
|-------------|------|-----------|-------------------|
| LoadAll() | Private Sub | Cargar configuración desde INI | GetAsync(tipoPapel) |
| Bt_OK_Click() | Private Sub | Guardar configuración en INI | SaveAsync(dto) |
| bt_Test_Click() | Private Sub | Imprimir marca de prueba | TestPrintAsync() - Opcional |
| Cb_Tipo_Click() | Private Sub | Cambiar tipo papel y recargar | GetAsync(tipoPapel) |

---

## 💾 ACCESO A DATOS VB6

### Almacenamiento: Archivo INI

**VB6 NO usa base de datos** para esta funcionalidad. Toda la configuración se guarda en archivo INI (gIniFile).

**Estructura INI:**

```ini
[Cheques]
TipoPapel=1

; Hoja Carta (TipoPapel=1)
Altura=5000
BordeIzq=1000
BajarValDig=500
MoverValDig=0
BajarFecha=800
MoverFecha=100
Omitir2DigAno=0
MoverAno=0
BajarOrdenDe=1200
MoverOrdenDe=0
BorrarOrden=0
BorrarPortador=0

; Papel Continuo (TipoPapel=2)
PCont-BordeSup=3000
PCont-BordeIzq=800
PCont-BajarValDig=400
PCont-MoverValDig=50
PCont-BajarFecha=700
PCont-MoverFecha=80
PCont-Omitir2DigAno=1
PCont-MoverAno=-50
PCont-BajarOrdenDe=1000
PCont-MoverOrdenDe=0
PCont-BorrarOrden=0
PCont-BorrarPortador=0
```

### Mapeo a .NET

En .NET, usaremos **tabla Param** con `Tipo = "Cheques"` y diferentes `Codigo` para cada parámetro:

```csharp
// Ejemplo de registros en tabla Param
Tipo = "Cheques", Codigo = 1, Valor = "1" (TipoPapel: 1=Carta, 2=Continuo)

// Hoja Carta
Tipo = "Cheques", Codigo = 10, Valor = "5000" (Altura)
Tipo = "Cheques", Codigo = 11, Valor = "1000" (BordeIzq)
Tipo = "Cheques", Codigo = 12, Valor = "500" (BajarValDig)
Tipo = "Cheques", Codigo = 13, Valor = "0" (MoverValDig)
// ... etc

// Papel Continuo (Codigo con sufijo +100)
Tipo = "Cheques", Codigo = 110, Valor = "3000" (PCont-BordeSup)
Tipo = "Cheques", Codigo = 111, Valor = "800" (PCont-BordeIzq)
// ... etc
```

**Queries Entity Framework:**

```csharp
// Obtener configuración de cheques
var paramsCheques = await _context.Param
    .Where(p => p.Tipo == "Cheques")
    .ToListAsync();

// Obtener TipoPapel actual
var tipoPapel = paramsCheques
    .FirstOrDefault(p => p.Codigo == 1)?.Valor ?? "1";

// Obtener Altura para Hoja Carta
var altura = paramsCheques
    .FirstOrDefault(p => p.Codigo == 10)?.Valor ?? "0";

// Guardar configuración
var param = await _context.Param
    .FirstOrDefaultAsync(p => p.Tipo == "Cheques" && p.Codigo == 10);

if (param != null)
{
    param.Valor = dto.Altura.ToString();
}
else
{
    _context.Param.Add(new Param
    {
        Tipo = "Cheques",
        Codigo = 10,
        Valor = dto.Altura.ToString()
    });
}

await _context.SaveChangesAsync();
```

---

## ✅ VALIDACIONES Y REGLAS DE NEGOCIO

### Validaciones de Campos

| Campo | Regla | Mensaje Error VB6 | Implementar en .NET |
|-------|-------|-------------------|---------------------|
| Todos los Tx_* | Solo números (positivos o negativos) | N/A (KeyPress valida) | HTML5 type="number", DataAnnotations |
| Cb_Tipo | Bloquear cambio si hay modificaciones | N/A (UI behavior) | Validación cliente |

### Reglas de Negocio

1. **Dos conjuntos de configuración independientes**: Hoja Carta y Papel Continuo tienen parámetros separados
   **→ Implementar:** Códigos diferentes en tabla Param (10-50 para Carta, 110-150 para Continuo)

2. **Bloqueo de tipo papel**: Si se modifica cualquier campo, bloquear cambio de tipo hasta guardar
   **→ Implementar:** Validación en cliente (JavaScript)

3. **Unidad de medida twips**: Todos los valores se guardan en twips (1 cm = 567 twips)
   **→ Implementar:** Mostrar ayuda en UI, validar rangos razonables

4. **Valores pueden ser negativos**: Para mover hacia izquierda/arriba
   **→ Implementar:** Permitir números negativos en validación

5. **Test de impresión**: Botón para imprimir marca de prueba en esquina
   **→ Implementar:** Opcional - Generar PDF con marca en posición configurada

---

## 🧮 CÁLCULOS Y FÓRMULAS

**No hay cálculos matemáticos complejos**. Solo conversión de unidades:

- **1 cm = 567 twips** (información de ayuda)
- Los valores se guardan directamente en twips sin conversión

---

## 🚀 NAVEGACIÓN Y FLUJO

### Formularios Llamados

**No llama a otros formularios**. Solo interactúa con diálogo de impresora para test (opcional en .NET).

### Flujo de Estados del Form

```
[Inicio] → Form_Load() → LoadAll() → [Estado: Visualizando Configuración]
  ↓
[Usuario selecciona Tipo Papel] → Cb_Tipo_Click() → LoadAll() → [Recargar valores]
  ↓
[Usuario edita campos] → [Bloquear Cb_Tipo] → [Estado: Editando]
  ↓
[Bt_Ok] → Guardar en INI → Actualizar gPrtCheques → [Cerrar]
  
[Bt_Test] → PrepararPrt() → PrtMarca() → [Imprimir marca de prueba]

[Bt_Cancel] → [Cerrar sin Guardar]
```

---

## 📊 EXPORTACIONES E IMPORTACIONES

**No hay exportaciones ni importaciones**. Solo configuración local guardada en INI file.

---

## 🎯 MAPEO FINAL: MÉTODOS .NET DETERMINADOS

### Interface del Service

```csharp
public interface IConfiguracionImpresionChequesService
{
    // CRUD Principal
    Task<ConfiguracionChequesDto?> GetAsync(int tipoPapel);
    Task<bool> SaveAsync(ConfiguracionChequesUpdateDto dto);

    // Utilidades
    Task<int> GetTipoPapelActualAsync();
    Task<bool> SetTipoPapelActualAsync(int tipoPapel);
}
```

### Resumen de Mapeo

| Funcionalidad VB6 | Método .NET | Complejidad | Prioridad |
|-------------------|-------------|-------------|-----------|
| LoadAll() | GetAsync(tipoPapel) | Media | Alta |
| Bt_OK_Click() | SaveAsync(dto) | Media | Alta |
| Cb_Tipo_Click() | GetAsync(tipoPapel) | Baja | Alta |
| GetIniString() | Leer de tabla Param | Media | Alta |
| SetIniString() | Guardar en tabla Param | Media | Alta |
| bt_Test_Click() | TestPrintAsync() - Opcional | Alta | Baja |

---

## ⚠️ NOTAS IMPORTANTES Y OBSERVACIONES

### Peculiaridades del Form VB6

- **Archivo INI**: VB6 usa archivo INI para configuración. En .NET usamos tabla Param
- **Variable global gPrtCheques**: VB6 mantiene configuración en memoria. En .NET solo BD
- **Unidad twips**: Medida antigua de VB6. Mantener compatibilidad o documentar conversión
- **Prefijo PCont-**: Papel continuo usa prefijo en nombres de parámetros INI
- **Bloqueo UI**: Cb_Tipo se bloquea al editar campos (comportamiento UI específico)
- **Test de impresión**: Requiere acceso a impresora física (opcional en web)

### Decisiones de Diseño

- **Almacenamiento en tabla Param**: Usar `Tipo = "Cheques"`, diferentes `Codigo` para cada parámetro
- **Códigos estructurados**: 
  - Codigo 1: TipoPapel actual
  - Codigos 10-50: Parámetros Hoja Carta
  - Codigos 110-150: Parámetros Papel Continuo (mismo orden, +100)
- **Test de impresión**: Implementar como generación PDF opcional (no prioritario)
- **Formulario simple**: No requiere validaciones complejas, solo inputs numéricos

### Pendientes/Incompletos en VB6

- **Test de impresión**: En .NET web, implementar como generación de PDF de prueba (opcional)
- **Diálogo impresora**: No aplicable en web. Test genera PDF descargable

---

## ✅ CHECKLIST DE COMPLETITUD DEL ANÁLISIS

- [x] Todos los controles UI documentados
- [x] Todos los botones y eventos mapeados
- [x] **TODOS los botones tienen "Mapeo .NET" definido**
- [x] **Botón Test marcado como opcional (no crítico)**
- [x] Todas las funciones VB6 identificadas
- [x] Almacenamiento INI file documentado
- [x] Mapeo a tabla Param definido
- [x] Todas las validaciones documentadas
- [x] Todas las reglas de negocio identificadas
- [x] No hay cálculos complejos (solo conversión info)
- [x] Navegación y flujos mapeados
- [x] Métodos .NET determinados
- [x] Interface del Service definida
- [x] **Decisiones de excepción justificadas (Test opcional)**

---

**✅ ANÁLISIS COMPLETO - LISTO PARA IMPLEMENTACIÓN**
