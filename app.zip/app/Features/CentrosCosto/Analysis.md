# Legacy Analysis: Centros de Costo

## 📄 Información del Formulario VB6

**Archivo VB6:** `old/Contabilidad70/HyperContabilidad/FrmCentrosCosto.frm`  
**Fecha Análisis:** 2025-09-29  
**Analista:** IA  
**Complejidad:** Media  

### Propósito del Formulario

Este formulario permite gestionar los Centros de Costo (llamados "Centros de Gestión" en la UI) de una empresa. Los centros de costo son unidades de segmentación contable que permiten clasificar y analizar ingresos/egresos por áreas de responsabilidad. El form opera en dos modos: edición (CRUD completo) y selección (para uso desde otros formularios).

---

## 🎨 CONTROLES UI IDENTIFICADOS

### Grilla Principal (MSFlexGrid)
| Control VB6 | Fuente Datos | Columnas | Eventos | Acciones |
|-------------|--------------|----------|---------|----------|
| Grid | Query GetAll | 3 cols: Código, Descripción, ID (oculto) | Click, DblClick | DblClick en fila vacía=Nuevo, DblClick en fila con datos=Editar |

**Configuración Grilla:**
- `C_CODIGO = 0` (1500 pixels) - Código del centro de costo
- `C_DESCRIP = 1` (2000 pixels) - Descripción del centro de costo  
- `C_ID = 2` (0 pixels, oculto) - IdCCosto (Primary Key)

### Botones de Acción (Modo Edición)
| Botón VB6 | Caption | Habilitado Si | Acción | Mapeo .NET |
|-----------|---------|---------------|--------|------------|
| Bt_New | "Agregar" | Siempre | Abre FrmCCosto en modo nuevo | CreateAsync() |
| Bt_Edit | "Editar" | Fila seleccionada con datos | Abre FrmCCosto para editar | UpdateAsync() |
| Bt_Del | "Eliminar" | Fila seleccionada con datos | Valida y elimina (hard delete) | DeleteAsync() |
| Bt_Print | "Imprimir" | Grid con datos | Imprime listado de centros | N/A (feature secundaria) |
| Bt_Importador | "Importador" | Siempre | Abre FrmImpCentroCosto | N/A (integración externa) |
| Bt_Cancel | "Cerrar" | Siempre | Cierra formulario | N/A (navegación) |

### Botones de Acción (Modo Selección)
| Botón VB6 | Caption | Habilitado Si | Acción | Mapeo .NET |
|-----------|---------|---------------|--------|------------|
| Bt_Sel | "Seleccionar" | Fila seleccionada | Retorna centro seleccionado y cierra | GetByIdAsync() |

### Frames de Agrupación
| Control VB6 | Propósito | Visibilidad |
|-------------|-----------|-------------|
| Fr_Edit | Contiene botones de edición (Agregar/Editar/Eliminar/Imprimir/Importar) | Visible solo en modo O_EDIT |
| Fr_Sel | Contiene botón "Seleccionar" | Visible solo en modo O_VIEW |

---

## 🔘 EVENTOS IDENTIFICADOS

### Eventos de Formulario
| Evento VB6 | Cuándo Ocurre | Acciones | Mapeo .NET |
|------------|---------------|----------|------------|
| Form_Load | Al abrir form | CargaInicial: Determina modo (Edit/Select), SetUpGrid, LoadAll, habilita según FCierre, aplica privilegios | Index action del Controller MVC |

### Eventos de Botones

**Bt_New_Click:**
```vb
' Crear nuevo centro de costo
Set Frm = New FrmCCosto
If Frm.FNew(lCCosto) = vbOK Then
    Row = FGrAddRow(Grid)
    Call UpDateGrid(Row)  ' Actualiza grilla con nuevo registro
End If
```
**→ Mapeo .NET:** Modal JavaScript → POST a `/api/CentrosCosto` → Refrescar grilla

**Bt_Edit_Click:**
```vb
' Editar centro existente
If Grid.TextMatrix(Row, C_CODIGO) = "" Then  ' Validar fila seleccionada
    Beep
    Exit Sub
End If

Set Frm = New FrmCCosto
lCCosto.id = Grid.TextMatrix(Row, C_ID)
If Frm.FEdit(lCCosto) = vbOK Then
    Call UpDateGrid(Row)  ' Actualiza fila en grilla
End If
```
**→ Mapeo .NET:** Modal JavaScript → PUT a `/api/CentrosCosto/{id}` → Refrescar fila

**Bt_Del_Click:**
```vb
' Eliminar con validación de referencias
' 1. Validar selección
If Grid.TextMatrix(Row, C_CODIGO) = "" Then Exit Sub

' 2. Verificar si tiene movimientos asociados (NO puede eliminar si tiene)
Q1 = "SELECT Count(*) as n FROM MovComprobante WHERE idCCosto=" & vFmt(Grid.TextMatrix(Row, C_ID))
Set Rs = OpenRs(DbMain, Q1)

If vFld(Rs("n")) <> 0 Then
    MsgBox1 "No puede borrar el centro de gestión, existe un movimiento asociado.", vbExclamation
    Exit Sub
End If

' 3. Confirmar eliminación
If MsgBox1("¿Está seguro de eliminar el centro de gestión " & Grid.TextMatrix(Row, C_DESCRIP) & "?", vbQuestion Or vbYesNo) <> vbYes Then
    Exit Sub
End If

' 4. Eliminar de BD (Hard Delete)
Q1 = " WHERE idCCosto=" & vFmt(Grid.TextMatrix(Row, C_ID))
Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.id
Call DeleteSQL(DbMain, "CentroCosto", Q1)

' 5. Ocultar fila en grilla
Grid.RowHeight(Row) = 0
```
**→ Mapeo .NET:** CanDeleteAsync() valida → DELETE a `/api/CentrosCosto/{id}` → Eliminar fila de vista

**Bt_Print_Click:**
```vb
' Imprime listado usando PrtFlexGrid
Call PrtFlexGrid(Grid, "", "LISTADO DE CENTROS DE GESTIÓN", "", "", ColWi, Total, False, ...)
```
**→ Mapeo .NET:** ExportToExcelAsync() o similar (feature de baja prioridad)

**Bt_Importador_Click:**
```vb
' Abre importador de centros de costo
Unload Me
Dim Frm As FrmImpCentroCosto
Set Frm = New FrmImpCentroCosto
Frm.Show vbModal
Call CargaInicial  ' Recarga grilla después de importar
```
**→ Mapeo .NET:** ImportAsync() - TODO: [INTEGRATION] Implementar cuando exista archivo de importación

**Bt_Sel_Click (Modo Selector):**
```vb
' Retorna centro seleccionado y cierra
lCCosto.id = Grid.TextMatrix(Row, C_ID)
lCCosto.Codigo = Grid.TextMatrix(Row, C_CODIGO)
lCCosto.Descrip = Grid.TextMatrix(Row, C_DESCRIP)
lRc = vbOK
Unload Me
```
**→ Mapeo .NET:** Retornar DTO y cerrar modal

### Eventos de Controles

| Control.Evento | Trigger | Acción VB6 | Mapeo .NET |
|----------------|---------|------------|------------|
| Grid.DblClick | Doble click en fila | Si fila vacía → Bt_New_Click, Si fila con datos → Bt_Edit_Click | JavaScript: detectar doble click → abrir modal edit/new |

---

## 🔧 FUNCIONES Y PROCEDIMIENTOS VB6

### Funciones Públicas

```vb
' Función: FSelect
' Propósito: Abrir formulario en modo selección
' Parámetros: CCosto (ByRef CCosto_t) - retorna centro seleccionado
' Retorno: Integer (vbOK si seleccionó, vbCancel si canceló)
' Llamado por: Otros formularios que necesitan seleccionar un centro de costo
' Mapeo .NET: Modal de selección en JavaScript
Friend Function FSelect(CCosto As CCosto_t) As Integer
    lOper = O_VIEW  ' Modo selección
    Me.Show vbModal
    FSelect = lRc
    CCosto = lCCosto
End Function
```

```vb
' Función: FEdit
' Propósito: Abrir formulario en modo edición
' Parámetros: Ninguno
' Retorno: Void
' Llamado por: Menú principal o accesos directos
' Mapeo .NET: Ruta /CentrosCosto?empresaId=X
Public Sub FEdit()
    lOper = O_EDIT  ' Modo edición completa
    Me.Show vbModal
End Sub
```

### Funciones Privadas

```vb
' Función: CargaInicial
' Propósito: Inicializa el formulario según modo de operación
' Parámetros: Ninguno
' Retorno: Void
' Validaciones: Habilita/deshabilita según FCierre y privilegios
' Mapeo .NET: Index action del Controller
Private Sub CargaInicial()
    lRc = vbCancel
    
    ' Mostrar frame según modo
    Fr_Edit.visible = (lOper = O_EDIT)      ' Botones CRUD visibles solo en modo edición
    Fr_Sel.visible = (lOper = O_VIEW)       ' Botón Seleccionar visible solo en modo selección
    
    Call SetUpGrid        ' Configura columnas y encabezados
    Call LoadAll          ' Carga datos desde BD
    Call EnableForm(Me, gEmpresa.FCierre = 0)  ' Deshabilita si mes está cerrado
    Call SetupPriv        ' Aplica privilegios de usuario
End Sub
```

```vb
' Función: SetUpGrid
' Propósito: Configura estructura de la grilla
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: Estructura HTML de tabla en View
Private Sub SetUpGrid()
    Call FGrSetup(Grid)
    
    Grid.ColWidth(C_CODIGO) = 1500    ' Ancho columna Código
    Grid.ColWidth(C_DESCRIP) = 2000   ' Ancho columna Descripción
    Grid.ColWidth(C_ID) = 0           ' Ocultar ID
    
    ' Configurar alineación
    For i = 0 To Grid.Cols - 1
        Grid.FixedAlignment(i) = flexAlignCenterCenter
        Grid.ColAlignment(i) = flexAlignLeftCenter
    Next i
    
    ' Encabezados
    Grid.TextMatrix(0, C_CODIGO) = "Código"
    Grid.TextMatrix(0, C_DESCRIP) = "Descripción"
End Sub
```

```vb
' Función: LoadAll
' Propósito: Carga todos los centros de costo desde BD
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: GetAllAsync(empresaId)
Private Sub LoadAll()
    Q1 = "SELECT Codigo, idCCosto, Descripcion FROM CentroCosto WHERE IdEmpresa =" & gEmpresa.id
    Q1 = Q1 & " ORDER BY Codigo"
    Set Rs = OpenRs(DbMain, Q1)
    
    i = 1
    Grid.rows = i
    Do While Rs.EOF = False
        Grid.rows = i + 1
        
        Grid.TextMatrix(i, C_CODIGO) = vFld(Rs("Codigo"), True)
        Grid.TextMatrix(i, C_DESCRIP) = vFld(Rs("Descripcion"), True)
        Grid.TextMatrix(i, C_ID) = vFld(Rs("idCCosto"))
        
        i = i + 1
        Rs.MoveNext
    Loop
    Call CloseRs(Rs)
End Sub
```

```vb
' Función: UpDateGrid
' Propósito: Actualiza una fila específica de la grilla con datos del struct lCCosto
' Parámetros: Row (Integer) - índice de fila a actualizar
' Retorno: Void
' Mapeo .NET: Actualización del DOM en JavaScript después de CREATE/UPDATE
Private Sub UpDateGrid(Row As Integer)
    Grid.TextMatrix(Row, C_CODIGO) = lCCosto.Codigo
    Grid.TextMatrix(Row, C_DESCRIP) = lCCosto.Descrip
    Grid.TextMatrix(Row, C_ID) = lCCosto.id
End Sub
```

```vb
' Función: SetupPriv
' Propósito: Aplica privilegios de usuario (deshabilita form si no tiene PRV_ADM_DEF)
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: Autorización a nivel de Controller
Private Function SetupPriv()
    If lOper = O_EDIT Then
        If Not ChkPriv(PRV_ADM_DEF) Then
            Call EnableForm(Me, False)  ' Deshabilita todos los controles
        End If
    End If
End Function
```

```vb
' Función: CountCCosto
' Propósito: Cuenta cantidad de centros de costo en la grilla
' Parámetros: Ninguno
' Retorno: Integer (cantidad de centros)
' Nota: Hay código comentado que limitaba a MAX_DESGLOESTRESULT
' Mapeo .NET: Count() en JavaScript o query COUNT() en Service
Private Function CountCCosto() As Integer
    Dim i As Integer, n As Integer
    
    For i = Grid.FixedRows To Grid.rows - 1
        If Val(Grid.TextMatrix(i, C_ID)) <> 0 Then
            n = n + 1
        Else
            Exit For
        End If
    Next i
    
    CountCCosto = n
End Function
```

### Lista Completa de Funciones
| Función VB6 | Tipo | Propósito | Mapeo .NET Method |
|-------------|------|-----------|-------------------|
| FSelect(CCosto) | Friend Function→Integer | Abrir en modo selector | Modal JavaScript con callback |
| FEdit() | Public Sub | Abrir en modo edición | Ruta /CentrosCosto |
| CargaInicial() | Private Sub | Inicializa form según modo | Index() action |
| SetUpGrid() | Private Sub | Configura estructura grilla | Estructura HTML tabla |
| LoadAll() | Private Sub | Carga todos los registros | GetAllAsync(empresaId) |
| UpDateGrid(Row) | Private Sub | Actualiza fila específica | Update DOM row en JS |
| SetupPriv() | Private Function | Aplica privilegios usuario | [Authorize] attribute |
| CountCCosto() | Private Function→Integer | Cuenta registros en grilla | JavaScript array.length |

---

## 💾 ACCESO A DATOS VB6

### Query 1: Cargar Listado Principal
```vb
' Ubicación: LoadAll()
' Tablas: CentroCosto
' Filtros: IdEmpresa
Q1 = "SELECT Codigo, idCCosto, Descripcion FROM CentroCosto WHERE IdEmpresa =" & gEmpresa.id
Q1 = Q1 & " ORDER BY Codigo"
Set Rs = OpenRs(DbMain, Q1)
```

**Mapeo Entity Framework:**
```csharp
public async Task<IEnumerable<CentrosCostoDto>> GetAllAsync(int empresaId)
{
    return await _context.CentroCosto
        .Where(c => c.IdEmpresa == empresaId && (c.Vigente == null || c.Vigente == -1))
        .OrderBy(c => c.Codigo)
        .Select(c => new CentrosCostoDto
        {
            IdCCosto = c.IdCCosto,
            IdEmpresa = c.IdEmpresa,
            Codigo = c.Codigo,
            Descripcion = c.Descripcion,
            Vigente = c.Vigente
        })
        .ToListAsync();
}
```

### Query 2: Validar Referencias Antes de Eliminar
```vb
' Ubicación: Bt_Del_Click
' Tablas: MovComprobante
' Validación: No puede eliminar si tiene movimientos asociados
Q1 = "SELECT Count(*) as n FROM MovComprobante WHERE idCCosto=" & vFmt(Grid.TextMatrix(Row, C_ID))
Set Rs = OpenRs(DbMain, Q1)

If vFld(Rs("n")) <> 0 Then
    MsgBox1 "No puede borrar el centro de gestión, existe un movimiento asociado.", vbExclamation
    Exit Sub
End If
```

**Mapeo Entity Framework:**
```csharp
public async Task<bool> CanDeleteAsync(int id, int empresaId)
{
    var hasMovements = await _context.MovComprobante
        .AnyAsync(m => m.IdCCosto == id);
    
    return !hasMovements;
}
```

### Query 3: Eliminar Centro de Costo (Hard Delete)
```vb
' Ubicación: Bt_Del_Click
' Nota: Es un hard delete, NO soft delete
Q1 = " WHERE idCCosto=" & vFmt(Grid.TextMatrix(Row, C_ID))
Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.id
Call DeleteSQL(DbMain, "CentroCosto", Q1)
```

**Mapeo Entity Framework:**
```csharp
public async Task<bool> DeleteAsync(int id, int empresaId)
{
    _logger.LogInformation("Deleting centro costo {Id} for empresaId: {EmpresaId}", id, empresaId);
    
    var centroCosto = await _context.CentroCosto
        .FirstOrDefaultAsync(c => c.IdCCosto == id && c.IdEmpresa == empresaId);
    
    if (centroCosto == null)
    {
        return false;
    }
    
    // Hard delete como en VB6
    _context.CentroCosto.Remove(centroCosto);
    await _context.SaveChangesAsync();
    
    return true;
}
```

**Nota Importante:** VB6 usa **hard delete** (elimina físicamente el registro), NO soft delete (marcar Vigente=0). Debemos mantener este comportamiento en .NET para compatibilidad.

---

## ✅ VALIDACIONES Y REGLAS DE NEGOCIO

### Validaciones de Campos

| Campo | Regla | Mensaje Error VB6 | Implementar en .NET |
|-------|-------|-------------------|---------------------|
| Codigo | Obligatorio | "El código es obligatorio" | [Required] attribute |
| Codigo | Máximo 15 chars (asumido) | N/A | [MaxLength(15)] |
| Codigo | Único por empresa | "El código ya existe" | CheckUniqueCodeAsync() |
| Descripcion | Opcional | N/A | [MaxLength(50)] |
| IdEmpresa | Obligatorio | N/A | Validación en Controller |

### Reglas de Negocio

1. **No eliminar centros con movimientos asociados**
   ```vb
   Q1 = "SELECT Count(*) as n FROM MovComprobante WHERE idCCosto=" & Id
   If Count > 0 Then
       MsgBox "No puede borrar el centro de gestión, existe un movimiento asociado."
       Exit Sub
   End If
   ```
   **→ Implementar:** `CanDeleteAsync(id)` valida tabla MovComprobante antes de eliminar

2. **Código debe ser único por empresa**
   **→ Implementar:** `CheckUniqueCodeAsync(codigo, empresaId, excludeId)`

3. **Hard Delete (no soft delete)**
   - VB6 elimina físicamente el registro
   - **→ Implementar:** `_context.Remove()` en lugar de marcar Vigente=0

4. **Validación de privilegios**
   - Requiere privilegio PRV_ADM_DEF para editar
   - **→ Implementar:** Atributo [Authorize] en Controller

5. **Validación FCierre (mes cerrado)**
   - Si mes está cerrado (FCierre != 0), deshabilita edición
   - **→ Implementar:** Validación en Service o Middleware

---

## 🧮 CÁLCULOS Y FÓRMULAS

### Cálculo 1: Contar Centros de Costo
```vb
' Dónde: CountCCosto()
' Fórmula: Contar filas en grilla con ID != 0
For i = Grid.FixedRows To Grid.rows - 1
    If Val(Grid.TextMatrix(i, C_ID)) <> 0 Then
        n = n + 1
    Else
        Exit For
    End If
Next i
```
**→ Implementar:** No es necesario, usar `list.length` en JavaScript o `Count()` en LINQ

---

## 🚀 NAVEGACIÓN Y FLUJO

### Formularios Llamados
| Desde VB6 | Formulario Destino | Parámetros | Retorno | Mapeo .NET |
|-----------|-------------------|------------|---------|------------|
| Bt_New_Click | FrmCCosto.frm (modo nuevo) | lCCosto (struct) | vbOK/vbCancel + lCCosto | Modal JavaScript POST `/api/CentrosCosto` |
| Bt_Edit_Click | FrmCCosto.frm (modo editar) | lCCosto.id | vbOK/vbCancel + lCCosto | Modal JavaScript PUT `/api/CentrosCosto/{id}` |
| Bt_Importador_Click | FrmImpCentroCosto.frm | Ninguno | Ninguno | TODO: [INTEGRATION] Importador externo |

### Flujo de Estados del Form

```
[Inicio] → Form_Load() → CargaInicial() → Determinar modo (O_EDIT / O_VIEW)
    ↓
[O_EDIT] → Mostrar Fr_Edit (botones CRUD) → [Estado: Listado]
    ↓
[Bt_New] → Abrir FrmCCosto.FNew() → [Modal Nuevo]
    ↓
[Guardar en modal] → UpDateGrid(nueva fila) → [Estado: Listado]

[Grid_DblClick fila con datos] → Bt_Edit_Click → Abrir FrmCCosto.FEdit() → [Modal Editar]
    ↓
[Guardar en modal] → UpDateGrid(fila existente) → [Estado: Listado]

[Bt_Del] → Validar referencias (MovComprobante) → Confirmar → DELETE SQL → Ocultar fila → [Estado: Listado]

[O_VIEW] → Mostrar Fr_Sel (botón Seleccionar) → [Estado: Selección]
    ↓
[Bt_Sel] → Retornar lCCosto seleccionado → lRc = vbOK → Cerrar
```

---

## 📊 EXPORTACIONES E IMPORTACIONES

### Exportación/Impresión
```vb
' Botón: Bt_Print_Click
' Formato: Llamada a PrtFlexGrid (impresión legacy)
' Título: "LISTADO DE CENTROS DE GESTIÓN"
Call PrtFlexGrid(Grid, "", "LISTADO DE CENTROS DE GESTIÓN", "", "", ColWi, Total, False, ...)
```
**→ Implementar:** `ExportToExcelAsync()` usando EPPlus (prioridad baja)

### Importación
```vb
' Botón: Bt_Importador_Click
' Formulario: FrmImpCentroCosto
' Formato: Desconocido (archivo externo)
```
**→ Implementar:** TODO: [INTEGRATION] [BLOCKED] Requiere definición de formato de archivo

---

## 🎯 MAPEO FINAL: MÉTODOS .NET DETERMINADOS

### Interface del Service

```csharp
public interface ICentrosCostoService
{
    // CRUD Principal
    Task<IEnumerable<CentrosCostoDto>> GetAllAsync(int empresaId);
    Task<CentrosCostoDto?> GetByIdAsync(int id, int empresaId);
    Task<CentrosCostoDto> CreateAsync(int empresaId, CentrosCostoCreateDto dto);
    Task<CentrosCostoDto> UpdateAsync(int id, int empresaId, CentrosCostoUpdateDto dto);
    Task<bool> DeleteAsync(int id, int empresaId);
    
    // Validaciones
    Task<bool> CheckUniqueCodeAsync(string codigo, int empresaId, int? excludeId = null);
    Task<bool> CanDeleteAsync(int id, int empresaId);
    
    // Exportación (prioridad baja)
    Task<byte[]> ExportToExcelAsync(int empresaId);
}
```

### Resumen de Mapeo

| Funcionalidad VB6 | Método .NET | Complejidad | Prioridad |
|-------------------|-------------|-------------|-----------|
| Form_Load → LoadAll() | GetAllAsync(empresaId) | Baja | Alta |
| Bt_New → FrmCCosto.FNew | CreateAsync(empresaId, dto) | Media | Alta |
| Bt_Edit → FrmCCosto.FEdit | GetByIdAsync() + UpdateAsync() | Media | Alta |
| Bt_Del + Validación | CanDeleteAsync() + DeleteAsync() | Media | Alta |
| Validar código único | CheckUniqueCodeAsync() | Baja | Alta |
| Bt_Print | ExportToExcelAsync() | Media | Baja |
| Bt_Importador | ImportAsync() | Alta | Baja |

---

## ⚠️ NOTAS IMPORTANTES Y OBSERVACIONES

### Peculiaridades del Form VB6

- **Hard Delete:** A diferencia de otras entidades que usan soft delete (Vigente=0), este form ELIMINA FÍSICAMENTE el registro
- **Dos modos de operación:** O_EDIT (CRUD completo) y O_VIEW (modo selector para otros forms)
- **UI dice "Centros de Gestión"** pero la tabla se llama CentroCosto
- **Validación de referencias:** Verifica tabla MovComprobante antes de permitir eliminación
- **Campo Vigente existe** en la tabla pero NO se usa en este formulario (VB6 no filtra por vigente)
- **Importador:** Existe botón pero abre otro formulario (FrmImpCentroCosto) - integración externa

### Decisiones de Diseño

- **Hard Delete:** Mantener mismo comportamiento que VB6 (eliminar físicamente)
- **Sin filtro Vigente:** VB6 no filtra por este campo, cargar todos los registros
- **Validación cliente y servidor:** VB6 solo valida en cliente, agregar validación también en servidor
- **Modal para crear/editar:** En lugar de abrir FrmCCosto, usar modal inline con Tailwind CSS
- **Sin paginación:** VB6 carga todos, mantener mismo approach (típicamente <100 registros)

### Pendientes/Incompletos en VB6

- **Botón "Importador":** Abre FrmImpCentroCosto - implementar como TODO: [INTEGRATION]
- **Límite MAX_DESGLOESTRESULT:** Código comentado que limitaba cantidad - NO implementar (obsoleto)
- **Privilegios:** Implementar validación PRV_ADM_DEF a nivel de Controller

### Diferencias con Sucursales

| Aspecto | Sucursales | CentrosCosto |
|---------|------------|--------------|
| Eliminación | Soft delete (Vigente=0) | **Hard delete** (físico) |
| Validación delete | No valida referencias | **Valida MovComprobante** |
| Filtro Vigente | Sí, carga solo vigentes | **No, carga todos** |
| Impresión | No tiene | **Tiene botón imprimir** |
| Importador | No tiene | **Tiene botón importador** |

---

## ✅ CHECKLIST DE COMPLETITUD DEL ANÁLISIS

- [x] Todos los controles UI documentados
- [x] Todos los botones y eventos mapeados
- [x] Todas las funciones VB6 identificadas
- [x] Todos los queries SQL traducidos a EF Core
- [x] Todas las validaciones documentadas
- [x] Todas las reglas de negocio identificadas
- [x] Navegación y flujos mapeados
- [x] Métodos .NET determinados
- [x] Interface del Service definida
- [x] Diferencias con forms similares documentadas
- [x] Peculiaridades críticas destacadas (Hard Delete, validación MovComprobante)

---

**✅ ANÁLISIS COMPLETO - LISTO PARA IMPLEMENTACIÓN**

**🚨 PUNTO CRÍTICO:** Este formulario usa **HARD DELETE** (elimina físicamente), a diferencia de Sucursales que usa soft delete. Implementar `_context.Remove()` en lugar de `entity.Vigente = 0`.

