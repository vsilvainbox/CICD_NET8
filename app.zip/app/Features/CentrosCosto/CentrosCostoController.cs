using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.CentrosCosto;

/// <summary>
/// Controller MVC para Centros de Costo
/// Migraci�n de FrmCentrosCosto.frm (VB6)
/// </summary>

public class CentrosCostoController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<CentrosCostoController> logger) : Controller
{
    /// <summary>
    /// Vista principal de Centros de Costo
    /// Mapeo VB6: FrmCentrosCosto.FEdit() - modo edici�n completa
    /// GET /CentrosCosto
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Index()
    {

        logger.LogInformation("Loading CentrosCosto index for empresaId: {EmpresaId}", SessionHelper.EmpresaId);

        {
            // Cargar datos iniciales desde API interna
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(CentrosCostoApiController.GetAll),
                controller: nameof(CentrosCostoApiController).Replace("Controller", ""),
                values: new { empresaId = SessionHelper.EmpresaId }
            );
            var centrosCosto = await client.GetFromApiAsync<List<CentrosCostoDto>>(url!);

            logger.LogInformation("Successfully loaded {Count} centros costo for empresaId: {EmpresaId}",
                centrosCosto?.Count ?? 0, SessionHelper.EmpresaId);

            return View(centrosCosto ?? new List<CentrosCostoDto>());
        }
    }

    /// <summary>
    /// Proxy: Obtener todos los centros de costo
    /// GET /CentrosCosto/GetAll
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetAll(int empresaId)
    {
        logger.LogInformation("Proxy: GetAll centros costo for empresaId: {EmpresaId}", empresaId);

        var client = httpClientFactory.CreateClient("ApiClient");

        var url = linkGenerator.GetPathByAction(
            action: nameof(CentrosCostoApiController.GetAll),
            controller: nameof(CentrosCostoApiController).Replace("Controller", ""),
            values: new { empresaId }
        );
        var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
    }

    /// <summary>
    /// Proxy: Obtener centro de costo por ID
    /// GET /CentrosCosto/GetById
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetById(int id, int empresaId)
    {
        logger.LogInformation("Proxy: GetById centro costo {Id} for empresaId: {EmpresaId}", id, empresaId);

        var client = httpClientFactory.CreateClient("ApiClient");

        var url = linkGenerator.GetPathByAction(
            action: nameof(CentrosCostoApiController.GetById),
            controller: nameof(CentrosCostoApiController).Replace("Controller", ""),
            values: new { id, empresaId }
        );
        var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
    }

    /// <summary>
    /// Proxy: Verificar si puede eliminarse
    /// GET /CentrosCosto/CanDelete
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> CanDelete(int id, int empresaId)
    {
        logger.LogInformation("Proxy: CanDelete centro costo {Id} for empresaId: {EmpresaId}", id, empresaId);

        var client = httpClientFactory.CreateClient("ApiClient");

        var url = linkGenerator.GetPathByAction(
            action: nameof(CentrosCostoApiController.CanDelete),
            controller: nameof(CentrosCostoApiController).Replace("Controller", ""),
            values: new { id, empresaId }
        );
        var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
    }

    /// <summary>
    /// Proxy: Crear centro de costo
    /// POST /CentrosCosto/Create
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] JsonElement request)
    {
        var empresaId = SessionHelper.EmpresaId;
        logger.LogInformation("Proxy: Create centro costo for empresaId: {EmpresaId}", empresaId);

        var client = httpClientFactory.CreateClient("ApiClient");

        var url = linkGenerator.GetPathByAction(
            action: nameof(CentrosCostoApiController.Create),
            controller: nameof(CentrosCostoApiController).Replace("Controller", ""),
            values: new { empresaId }
        );
        var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return new ContentResult
            {
                Content = content,
                ContentType = "application/json",
                StatusCode = statusCode
            };
    }

    /// <summary>
    /// Proxy: Actualizar centro de costo
    /// PUT /CentrosCosto/Update
    /// </summary>
    [HttpPut]
    public async Task<IActionResult> Update(int id, [FromBody] JsonElement request)
    {
        var empresaId = SessionHelper.EmpresaId;
        logger.LogInformation("Proxy: Update centro costo {Id} for empresaId: {EmpresaId}", id, empresaId);

        var client = httpClientFactory.CreateClient("ApiClient");

        var url = linkGenerator.GetPathByAction(
            action: nameof(CentrosCostoApiController.Update),
            controller: nameof(CentrosCostoApiController).Replace("Controller", ""),
            values: new { id, empresaId }
        );
        var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Put);
            return new ContentResult
            {
                Content = content,
                ContentType = "application/json",
                StatusCode = statusCode
            };
    }

    /// <summary>
    /// Proxy: Eliminar centro de costo
    /// DELETE /CentrosCosto/Delete
    /// </summary>
    [HttpDelete]
    public async Task<IActionResult> Delete(int id, int empresaId)
    {
        logger.LogInformation("Proxy: Delete centro costo {Id} for empresaId: {EmpresaId}", id, empresaId);

        var client = httpClientFactory.CreateClient("ApiClient");

        var url = linkGenerator.GetPathByAction(
            action: nameof(CentrosCostoApiController.Delete),
            controller: nameof(CentrosCostoApiController).Replace("Controller", ""),
            values: new { id, empresaId }
        );
        var (statusCode, content) = await client.ProxyRequestAsync(url!, null, HttpMethod.Delete);
            return new ContentResult
            {
                Content = content,
                ContentType = "application/json",
                StatusCode = statusCode
            };
    }
}
