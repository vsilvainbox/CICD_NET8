using Microsoft.AspNetCore.Mvc;

namespace App.Features.CentrosCosto;

[ApiController]
[Route("api/[controller]/[action]")]
public class CentrosCostoApiController(ICentrosCostoService service, ILogger<CentrosCostoApiController> logger) : ControllerBase
{
    /// <summary>
    /// Obtiene todos los centros de costo de una empresa
    /// GET /api/CentrosCosto?empresaId=1
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<IEnumerable<CentrosCostoDto>>> GetAll([FromQuery] int empresaId)
    {
        logger.LogInformation("API: GetAll called with empresaId: {EmpresaId}", empresaId);

        {
            if (empresaId <= 0)
            {
                logger.LogWarning("API: Invalid empresaId: {EmpresaId}", empresaId);
                return BadRequest(new { message = "EmpresaId inválido" });
            }

            var centrosCosto = await service.GetAllAsync(empresaId);
            logger.LogInformation("API: Returning {Count} centros costo", centrosCosto.Count());
            return Ok(centrosCosto);
        }
    }

    /// <summary>
    /// Obtiene un centro de costo específico
    /// GET /api/CentrosCosto/5?empresaId=1
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<CentrosCostoDto>> GetById(int id, [FromQuery] int empresaId)
    {
        logger.LogInformation("API: GetById called with id: {Id}, empresaId: {EmpresaId}", id, empresaId);

        {
            if (empresaId <= 0)
            {
                return BadRequest(new { message = "EmpresaId inválido" });
            }

            var centroCosto = await service.GetByIdAsync(id, empresaId);
            
            if (centroCosto == null)
            {
                logger.LogWarning("API: Centro costo {Id} not found", id);
                return NotFound(new { message = $"Centro de costo con ID {id} no encontrado" });
            }

            return Ok(centroCosto);
        }
    }

    /// <summary>
    /// Crea un nuevo centro de costo
    /// POST /api/CentrosCosto?empresaId=1
    /// Body: { "codigo": "CC001", "descripcion": "Centro 1", "vigente": true }
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<CentrosCostoDto>> Create([FromQuery] int empresaId, [FromBody] CentrosCostoCreateDto dto)
    {
        logger.LogInformation("API: Create called with codigo: {Codigo}, empresaId: {EmpresaId}", dto.Codigo, empresaId);

        {
            if (empresaId <= 0)
            {
                return BadRequest(new { message = "EmpresaId inválido" });
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var centroCosto = await service.CreateAsync(empresaId, dto);
            logger.LogInformation("API: Created centro costo with ID: {Id}", centroCosto.IdCCosto);
            
            return CreatedAtAction(nameof(GetById), 
                new { id = centroCosto.IdCCosto, empresaId = empresaId }, 
                centroCosto);
        }
    }

    /// <summary>
    /// Actualiza un centro de costo existente
    /// PUT /api/CentrosCosto/5?empresaId=1
    /// Body: { "codigo": "CC001", "descripcion": "Centro 1 Modificado", "vigente": true }
    /// </summary>
    [HttpPut]
    public async Task<ActionResult<CentrosCostoDto>> Update(int id, [FromQuery] int empresaId, [FromBody] CentrosCostoUpdateDto dto)
    {
        logger.LogInformation("API: Update called for id: {Id}, codigo: {Codigo}, empresaId: {EmpresaId}", 
            id, dto.Codigo, empresaId);

        {
            if (empresaId <= 0)
            {
                return BadRequest(new { message = "EmpresaId inválido" });
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var centroCosto = await service.UpdateAsync(id, empresaId, dto);
            logger.LogInformation("API: Updated centro costo {Id}", id);
            
            return Ok(centroCosto);
        }
    }

    /// <summary>
    /// Elimina un centro de costo (HARD DELETE)
    /// DELETE /api/CentrosCosto/5?empresaId=1
    /// IMPORTANTE: Valida primero si puede eliminarse (no tiene movimientos)
    /// </summary>
    [HttpDelete]
    public async Task<ActionResult> Delete(int id, [FromQuery] int empresaId)
    {
        logger.LogInformation("API: Delete called for id: {Id}, empresaId: {EmpresaId}", id, empresaId);

        {
            if (empresaId <= 0)
            {
                return BadRequest(new { message = "EmpresaId inválido" });
            }

            // Verificar si puede eliminarse (no tiene movimientos asociados)
            var canDelete = await service.CanDeleteAsync(id, empresaId);
            
            if (!canDelete)
            {
                logger.LogWarning("API: Cannot delete centro costo {Id}. Has associated movements or not found", id);
                return BadRequest(new 
                { 
                    message = "No puede borrar el centro de gestión, existe un movimiento asociado." 
                });
            }

            // Eliminar (hard delete)
            var deleted = await service.DeleteAsync(id, empresaId);
            
            if (!deleted)
            {
                return NotFound(new { message = $"Centro de costo con ID {id} no encontrado" });
            }

            logger.LogInformation("API: Deleted centro costo {Id}", id);
            return NoContent();
        }
    }

    /// <summary>
    /// Verifica si un código ya existe
    /// GET /api/CentrosCosto/check-code?codigo=CC001&amp;empresaId=1&amp;excludeId=5
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<bool>> CheckCode(
        [FromQuery] string codigo, 
        [FromQuery] int empresaId, 
        [FromQuery] int? excludeId = null)
    {
        logger.LogDebug("API: CheckCode called for codigo: {Codigo}, empresaId: {EmpresaId}, excludeId: {ExcludeId}", 
            codigo, empresaId, excludeId);

        {
            if (string.IsNullOrWhiteSpace(codigo) || empresaId <= 0)
            {
                return BadRequest(new { message = "Código y EmpresaId son requeridos" });
            }

            var exists = await service.CheckUniqueCodeAsync(codigo, empresaId, excludeId);
            return Ok(new { exists = exists });
        }
    }

    /// <summary>
    /// Verifica si un centro de costo puede eliminarse
    /// GET /api/CentrosCosto/5/can-delete?empresaId=1
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<bool>> CanDelete(int id, [FromQuery] int empresaId)
    {
        logger.LogDebug("API: CanDelete called for id: {Id}, empresaId: {EmpresaId}", id, empresaId);

        {
            if (empresaId <= 0)
            {
                return BadRequest(new { message = "EmpresaId inválido" });
            }

            var canDelete = await service.CanDeleteAsync(id, empresaId);
            return Ok(new { canDelete = canDelete });
        }
    }
}

