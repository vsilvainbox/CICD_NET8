using System.ComponentModel.DataAnnotations;

namespace App.Features.CambioEstado;

public class CambioEstadoRequestDto
{
    [Required]
    public int EmpresaId { get; set; }

    [Required]
    public short Ano { get; set; }

    [Required]
    public List<int> IdComprobantes { get; set; } = new();

    [Required]
    [Range(1, 3)] // 1=Aprobado, 2=Pendiente, 3=Anulado
    public byte NuevoEstado { get; set; }
}

public class CambioEstadoResponseDto
{
    public int ComprobantesActualizados { get; set; }
    public string Mensaje { get; set; } = string.Empty;
    public bool Exitoso { get; set; }
}