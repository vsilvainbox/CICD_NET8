using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.CambioEstado;

public class CambioEstadoController(
    IHttpClientFactory httpClientFactory,
    ILogger<CambioEstadoController> logger,
    LinkGenerator linkGenerator) : Controller
{
    [HttpGet]
    public IActionResult Index([FromQuery] string? ids = null)
    {
        // Verificar permiso PRV_ADM_COMP para cambiar estado de comprobantes
        var hasAdmCompPermission = SessionHelper.HasPrivilege(SessionHelper.Privileges.PRV_ADM_COMP);
            
        ViewBag.EmpresaId = SessionHelper.EmpresaId;
        ViewBag.Ano = SessionHelper.Ano;
        ViewBag.IdComprobantes = ids ?? string.Empty;
        ViewBag.HasAdmCompPermission = hasAdmCompPermission;
            
        return View();
    }

    /// <summary>
    /// Método proxy para cambiar estado de comprobantes (Vista → MVC → API)
    /// VB6: No verifica permisos, pero debería verificar PRV_ADM_COMP
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> CambiarEstado([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: CambiarEstado called");

        // Verificar permiso antes de permitir cambio
        if (!SessionHelper.HasPrivilege(SessionHelper.Privileges.PRV_ADM_COMP))
        {
            logger.LogWarning("User attempted to change voucher status without permission");
            return Json(new
            {
                exitoso = false,
                mensaje = "No tiene permisos para cambiar el estado de comprobantes. Requiere permiso: Administrar Comprobantes"
            });
        }

        {
            var client = httpClientFactory.CreateClient("ApiClient");
            var url = linkGenerator.GetPathByAction(
                action: nameof(CambioEstadoApiController.CambiarEstado),
                controller: nameof(CambioEstadoApiController).Replace("Controller", ""));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request,
                HttpMethod.Post);

            logger.LogInformation("MVC Proxy: API response status {StatusCode}", statusCode);

            return StatusCode(statusCode, content);
        }
    }
}