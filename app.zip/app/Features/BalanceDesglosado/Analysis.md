# Balance Desglosado - Análisis de Migración

## 1. Propósito del Feature

El **Balance Desglosado** genera un balance clasificado con desglose (breakdown) de saldos por **Centro de Costo** o **Área de Negocio**. A diferencia del Balance Ejecutivo que muestra un formato paralelo compacto, este balance incluye columnas adicionales dinámicas para mostrar el detalle de cada centro de costo o área de negocio seleccionada.

**Características principales:**
- Balance clasificado por niveles jerárquicos (1-5)
- Desglose por Centro de Costo o Área de Negocio (hasta MAX_DESGLOESTRESULT = 20)
- Columnas dinámicas: una por cada CCosto/AreaNeg seleccionada + columna Total
- Filtros múltiples: Rango de fechas, TipoAjuste, Nivel, Libro Oficial, Saldos Vigentes
- Opciones de visualización: "Ver solo nivel seleccionado" vs jerarquía completa
- Cálculo automático del "Resultado del Ejercicio"
- Exportación a Excel y generación de PDF
- Funcionalidad de impresión con firma al pie
- Envío por correo electrónico

## 2. Estructura de Datos VB6

### 2.1. Entidades Principales

**MovComprobante**:
```vb6
' Tabla principal con movimientos contables
IdMov, IdComp, Orden, IdCuenta, Glosa, Debe, Haber, TipoAjuste, 
AreaNeg, CentroCosto, Actualizado, ...
```

**Comprobante**:
```vb6
' Encabezado de comprobante
IdComp, Tipo, Fecha, Estado, TotDebe, TotHaber, Glosa, ...
```

**Cuentas**:
```vb6
' Plan de cuentas con jerarquía de 5 niveles
Codigo, Descripcion, Clasificacion (1-6), 
Nivel1, Nivel2, Nivel3, Nivel4, Nivel5, CtaAjusteCM, CtaAjusteCP, ...
```

**CentroCosto** / **AreaNegocio**:
```vb6
' Entidades para el desglose
IdCCosto/IdAreaNeg, Codigo, Descripcion
```

### 2.2. Constantes del Grid

```vb6
' Columnas del grid (16 columnas)
Const C_CODIGO = 0           ' Código de cuenta
Const C_NOMBRE = 1           ' Nombre de cuenta
Const C_CLASIF = 2           ' Clasificación (1-6)
Const C_NIVEL = 3            ' Nivel jerárquico (1-5)
Const C_NIVEL1 = 4           ' Código Nivel 1
Const C_NIVEL2 = 5           ' Código Nivel 2
Const C_NIVEL3 = 6           ' Código Nivel 3
Const C_NIVEL4 = 7           ' Código Nivel 4
Const C_NIVEL5 = 8           ' Código Nivel 5
Const C_AJUSTECM = 9         ' Cuenta ajuste corrección monetaria
Const C_AJUSTECP = 10        ' Cuenta ajuste capital propio
Const C_INI_DESGLO = 11      ' Inicio de columnas de desglose

' Columnas dinámicas de desglose
' C_INI_DESGLO + 0 to C_INI_DESGLO + MAX_DESGLOESTRESULT
Const MAX_DESGLOESTRESULT = 20   ' Máximo 20 desgloses
Const C_SALDOFIN = C_INI_DESGLO + MAX_DESGLOESTRESULT + 1  ' = 32 (Columna Total)
Const C_UPD = 33             ' Marca de actualización
Const C_IDCUENTA = 34        ' ID de cuenta

' Total de columnas: 35
```

### 2.3. Tipos de Clasificación

```vb6
' Clasificaciones de cuentas para el balance
CLASCTA_ACTIVO = 1           ' Activo
CLASCTA_PASIVO = 2           ' Pasivo
CLASCTA_PERDIDA = 3          ' Pérdida
CLASCTA_GANANCIA = 4         ' Ganancia
CLASCTA_PATRIMONIO = 5       ' Patrimonio
CLASCTA_ORDEN = 6            ' Cuentas de orden
```

## 3. Operaciones Principales

### 3.1. LoadAll() - Carga Principal del Balance

**Algoritmo complejo de 4 fases:**

**Fase 1: Generación de SQL**
```vb6
' Construcción de query SQL para obtener saldos por cuenta y desglose
If Ch_TipoDesglose(C_CCOSTO) Then
    ' Desglose por Centro de Costo
    Q1 = GenQueryPorNiveles(FDesde, FHasta, TipoAjuste, AreaNeg, _
                            CCostos, Nivel, EsOficial, SaldosVigentes, TRUE)
Else
    ' Desglose por Área de Negocio
    Q1 = GenQueryPorNiveles(FDesde, FHasta, TipoAjuste, AreaNeg, _
                            CCostos, Nivel, EsOficial, SaldosVigentes, FALSE)
End If
```

**Fase 2: Carga de Datos en Grid**
```vb6
' Ejecutar query y llenar grid con resultados
Rs.Open Q1, DbMain
Grid.rows = Grid.FixedRows
Do While Rs.EOF = False
    Grid.rows = Grid.rows + 1
    Row = Grid.rows - 1
    
    ' Cargar datos de cuenta
    Grid.TextMatrix(Row, C_CODIGO) = Rs("Codigo")
    Grid.TextMatrix(Row, C_NOMBRE) = Rs("Descripcion")
    Grid.TextMatrix(Row, C_CLASIF) = Rs("Clasificacion")
    Grid.TextMatrix(Row, C_NIVEL) = Rs("Nivel")
    Grid.TextMatrix(Row, C_NIVEL1) = Rs("Nivel1")
    Grid.TextMatrix(Row, C_NIVEL2) = Rs("Nivel2")
    Grid.TextMatrix(Row, C_NIVEL3) = Rs("Nivel3")
    Grid.TextMatrix(Row, C_NIVEL4) = Rs("Nivel4")
    Grid.TextMatrix(Row, C_NIVEL5) = Rs("Nivel5")
    Grid.TextMatrix(Row, C_IDCUENTA) = Rs("IdCuenta")
    
    ' Cargar saldos de desglose (columnas dinámicas)
    For k = 0 To NumDesgloses - 1
        Saldo = Val(Rs("Desglose" & k))
        Grid.TextMatrix(Row, C_INI_DESGLO + k) = Format(Saldo, NUMFMT)
        TotalDesglo(Nivel, k).Total = TotalDesglo(Nivel, k).Total + Saldo
    Next k
    
    Rs.MoveNext
Loop
```

**Fase 3: Cálculo de Totales Jerárquicos**
```vb6
' 4 loops anidados para calcular totales de todos los niveles
For i = Grid.FixedRows To Grid.rows - 1
    Nivel = Val(Grid.TextMatrix(i, C_NIVEL))
    Clasificacion = Val(Grid.TextMatrix(i, C_CLASIF))
    
    ' Loop por cada columna de desglose + total
    For k = 0 To NumDesgloses
        Saldo = Val(vFmt(Grid.TextMatrix(i, C_INI_DESGLO + k)))
        
        ' Acumular en niveles superiores (2 a 5)
        If Nivel = 2 Then
            ' Buscar cuenta padre de Nivel 1 y sumar
            CodNivel1 = Grid.TextMatrix(i, C_NIVEL1)
            For j = Grid.FixedRows To i - 1
                If Grid.TextMatrix(j, C_CODIGO) = CodNivel1 Then
                    OldSaldo = Val(vFmt(Grid.TextMatrix(j, C_INI_DESGLO + k)))
                    Grid.TextMatrix(j, C_INI_DESGLO + k) = Format(OldSaldo + Saldo, NUMFMT)
                    Exit For
                End If
            Next j
        ElseIf Nivel = 3 Then
            ' Similar para Nivel 2
        ElseIf Nivel = 4 Then
            ' Similar para Nivel 3
        ElseIf Nivel = 5 Then
            ' Similar para Nivel 4
        End If
        
        ' Acumular en TotalDesglo por clasificación y nivel
        TotalDesglo(Nivel, k).Activo += (Clasificacion = CLASCTA_ACTIVO) ? Saldo : 0
        TotalDesglo(Nivel, k).Pasivo += (Clasificacion = CLASCTA_PASIVO) ? Saldo : 0
        TotalDesglo(Nivel, k).Perdida += (Clasificacion = CLASCTA_PERDIDA) ? Saldo : 0
        TotalDesglo(Nivel, k).Ganancia += (Clasificacion = CLASCTA_GANANCIA) ? Saldo : 0
        TotalDesglo(Nivel, k).Patrimonio += (Clasificacion = CLASCTA_PATRIMONIO) ? Saldo : 0
    Next k
Next i
```

**Fase 4: Cálculo de Resultado del Ejercicio**
```vb6
' Resultado = Ganancias - Pérdidas
For k = 0 To NumDesgloses
    ResEjercicio(k) = TotalDesglo(Nivel, k).Ganancia - TotalDesglo(Nivel, k).Perdida
Next k

' Insertar línea de "Resultado del Ejercicio" en sección Patrimonio
Call AddResEjercicio(ResEjercicio(), NumDesgloses)
```

### 3.2. AddResEjercicio() - Inserción del Resultado

```vb6
' Buscar dónde insertar la línea de Resultado del Ejercicio
For i = Grid.FixedRows To Grid.rows - 1
    Clasificacion = Val(Grid.TextMatrix(i, C_CLASIF))
    If Clasificacion = CLASCTA_PATRIMONIO Then
        ' Insertar nueva línea después de primera cuenta de Patrimonio
        Grid.AddItem "", i + 1
        Grid.TextMatrix(i + 1, C_CODIGO) = "RES.EJER"
        Grid.TextMatrix(i + 1, C_NOMBRE) = "RESULTADO DEL EJERCICIO"
        
        ' Rellenar columnas de desglose con resultado calculado
        For k = 0 To NumDesgloses
            Grid.TextMatrix(i + 1, C_INI_DESGLO + k) = Format(ResEjercicio(k), NUMFMT)
        Next k
        
        Exit For
    End If
Next i
```

### 3.3. Desglose por Centro de Costo vs Área de Negocio

**Desglose por Centro de Costo:**
```vb6
' Usuario selecciona hasta 20 centros de costo en Ls_Desglose (ListBox)
If Ch_TipoDesglose(C_CCOSTO).Value = 1 Then
    Call FillCbCCosto(Ls_Desglose, False, True, MAX_DESGLOESTRESULT, _
                      "El máximo de Centros de Costo que permite este reporte es: " & MAX_DESGLOESTRESULT)
    
    ' Construir array de IDs seleccionados
    NumDesgloses = Ls_Desglose.SelCount
    ReDim CCostos(NumDesgloses)
    idx = 0
    For i = 0 To Ls_Desglose.ListCount - 1
        If Ls_Desglose.Selected(i) Then
            CCostos(idx) = Ls_Desglose.ItemData(i)
            idx = idx + 1
        End If
    Next i
End If
```

**Desglose por Área de Negocio:**
```vb6
' Similar pero con Áreas de Negocio
If Ch_TipoDesglose(C_AREANEG).Value = 1 Then
    Call FillCbAreaNeg(Ls_Desglose, False, True, MAX_DESGLOESTRESULT, _
                       "El máximo de Áreas de Negocio que permite este reporte es: " & MAX_DESGLOESTRESULT)
    ' ... mismo proceso
End If
```

### 3.4. Opciones de Visualización

**Ver Solo Nivel Seleccionado:**
```vb6
If Ch_VerSoloNivSel.Value = 1 Then
    ' Filtrar grid para mostrar solo cuentas del nivel seleccionado
    For i = Grid.rows - 1 To Grid.FixedRows Step -1
        Nivel = Val(Grid.TextMatrix(i, C_NIVEL))
        If Nivel <> NivelSeleccionado Then
            Grid.RemoveItem i
        End If
    Next i
End If
```

### 3.5. Generación de Columnas Dinámicas

```vb6
Private Sub SetUpGrid()
    ' Configurar columnas fijas
    Grid.ColWidth(C_CODIGO) = 1200
    Grid.ColWidth(C_NOMBRE) = 3000
    Grid.ColWidth(C_CLASIF) = 0       ' Hidden
    Grid.ColWidth(C_NIVEL) = 0        ' Hidden
    Grid.ColWidth(C_NIVEL1) = 0       ' Hidden
    ' ... más columnas hidden
    
    ' Configurar columnas dinámicas de desglose
    NumDesgloses = Ls_Desglose.SelCount
    For k = 0 To NumDesgloses - 1
        ColIdx = C_INI_DESGLO + k
        Grid.ColWidth(ColIdx) = 1500
        Grid.TextMatrix(0, ColIdx) = Ls_Desglose.List(k)  ' Nombre del CCosto/AreaNeg
    Next k
    
    ' Columna Total
    Grid.ColWidth(C_SALDOFIN) = 1800
    Grid.TextMatrix(0, C_SALDOFIN) = "TOTAL"
    
    ' Ocultar columnas no usadas
    For k = NumDesgloses + 1 To MAX_DESGLOESTRESULT
        Grid.ColWidth(C_INI_DESGLO + k) = 0
    Next k
End Sub
```

## 4. Reglas de Negocio

### 4.1. Clasificación de Cuentas

- **Activo (1)**: Cuentas de activo (circulante, fijo, otros)
- **Pasivo (2)**: Cuentas de pasivo (circulante, largo plazo)
- **Pérdida (3)**: Cuentas de resultado desfavorable
- **Ganancia (4)**: Cuentas de resultado favorable
- **Patrimonio (5)**: Capital, reservas, utilidades retenidas
- **Orden (6)**: Cuentas de memorándum

### 4.2. Jerarquía de Cuentas

```
Nivel 1: 1 dígito (ej: "1")
Nivel 2: 3 dígitos (ej: "101")
Nivel 3: 5 dígitos (ej: "10101")
Nivel 4: 7 dígitos (ej: "1010101")
Nivel 5: 9 dígitos (ej: "101010101")
```

Cada nivel hereda y acumula los saldos de sus niveles inferiores.

### 4.3. Tipos de Ajuste

- **Sin Ajuste**: Solo movimientos sin ajuste
- **Ajuste CM**: Solo ajuste por corrección monetaria
- **Ajuste CP**: Solo ajuste por capital propio
- **Tributario**: Movimientos tributarios
- **IFRS**: Movimientos bajo normas IFRS
- **Todos**: Incluye todos los tipos

### 4.4. Resultado del Ejercicio

```
Resultado del Ejercicio = Suma(Ganancias) - Suma(Pérdidas)
```

Se inserta automáticamente en la sección de Patrimonio para cuadrar el balance.

**Validación:**
```
Total Activos = Total Pasivos + Total Patrimonio + Resultado del Ejercicio
```

### 4.5. Límites y Validaciones

- **Máximo de desgloses**: 20 (MAX_DESGLOESTRESULT)
- **Columnas dinámicas**: 11 + NumDesgloses + 1 (Total) = hasta 32 columnas
- **Rango de fechas**: Fecha Desde <= Fecha Hasta
- **Nivel válido**: 2, 3, 4, o 5 (Nivel 1 siempre se muestra)
- **Tipo de desglose**: Excluyente (CCosto XOR AreaNeg)

## 5. Mapeo a .NET 9

### 5.1. DTOs

```csharp
// BalanceDesglosadoDto.cs

public class BalanceDesglosadoDto
{
    public DateTime FechaDesde { get; set; }
    public DateTime FechaHasta { get; set; }
    public int TipoAjuste { get; set; }
    public int? IdAreaNegocio { get; set; }
    public int? IdCentroCosto { get; set; }
    public int Nivel { get; set; }
    public bool EsLibroOficial { get; set; }
    public bool SaldosVigentes { get; set; }
    public bool VerSoloNivelSeleccionado { get; set; }
    public TipoDesglose TipoDesglose { get; set; }  // CCosto o AreaNeg
    public List<int> IdsDesglose { get; set; }  // IDs de CCosto o AreaNeg
    public List<CuentaBalanceDesglosadoDto> Cuentas { get; set; }
    public BalanceDesglosadoResultadoDto Resultado { get; set; }
}

public class CuentaBalanceDesglosadoDto
{
    public string Codigo { get; set; }
    public string Descripcion { get; set; }
    public int Clasificacion { get; set; }  // 1-6
    public int Nivel { get; set; }  // 1-5
    public string Nivel1 { get; set; }
    public string Nivel2 { get; set; }
    public string Nivel3 { get; set; }
    public string Nivel4 { get; set; }
    public string Nivel5 { get; set; }
    public Dictionary<string, decimal> SaldosDesglose { get; set; }  // Key: IdDesglose, Value: Saldo
    public decimal SaldoTotal { get; set; }
    public int IdCuenta { get; set; }
}

public class BalanceDesglosadoResultadoDto
{
    public Dictionary<string, decimal> ResultadoPorDesglose { get; set; }
    public decimal ResultadoTotal { get; set; }
    public Dictionary<string, TotalesDto> TotalesPorDesglose { get; set; }
    public TotalesDto TotalesGenerales { get; set; }
}

public class TotalesDto
{
    public decimal TotalActivos { get; set; }
    public decimal TotalPasivos { get; set; }
    public decimal TotalPerdidas { get; set; }
    public decimal TotalGanancias { get; set; }
    public decimal TotalPatrimonio { get; set; }
    public decimal ResultadoEjercicio { get; set; }
}

public class EncabezadoDesglosesDto
{
    public List<DesgloseMeta> Desgloses { get; set; }
}

public class DesgloseMeta
{
    public int Id { get; set; }
    public string Codigo { get; set; }
    public string Descripcion { get; set; }
}

public enum TipoDesglose
{
    CentroCosto = 1,
    AreaNegocio = 2
}
```

### 5.2. Service Interface

```csharp
// IBalanceDesglosadoService.cs

public interface IBalanceDesglosadoService
{
    /// <summary>
    /// Genera el balance desglosado con columnas por CCosto/AreaNeg
    /// </summary>
    Task<BalanceDesglosadoDto> GenerarBalanceDesglosadoAsync(
        int idEmpresa, 
        int ano,
        DateTime fechaDesde,
        DateTime fechaHasta,
        int tipoAjuste,
        int? idAreaNegocio,
        int? idCentroCosto,
        int nivel,
        bool esLibroOficial,
        bool saldosVigentes,
        bool verSoloNivelSeleccionado,
        TipoDesglose tipoDesglose,
        List<int> idsDesglose);
    
    /// <summary>
    /// Obtiene lista de centros de costo disponibles para desglose
    /// </summary>
    Task<List<DesgloseMeta>> ObtenerCentrosCostoDisponiblesAsync(int idEmpresa);
    
    /// <summary>
    /// Obtiene lista de áreas de negocio disponibles para desglose
    /// </summary>
    Task<List<DesgloseMeta>> ObtenerAreasNegocioDisponiblesAsync(int idEmpresa);
    
    /// <summary>
    /// Exporta el balance desglosado a Excel con columnas dinámicas
    /// </summary>
    Task<byte[]> ExportarExcelAsync(BalanceDesglosadoDto balance);
    
    /// <summary>
    /// Genera PDF del balance desglosado (orientación horizontal)
    /// </summary>
    Task<byte[]> GenerarPdfAsync(BalanceDesglosadoDto balance, int idEmpresa, int ano);
}
```

### 5.3. API Endpoints

```csharp
// BalanceDesglosadoApiController.cs

[ApiController]
[Route("api/[controller]/[action]")]
public class BalanceDesglosadoApiController : ControllerBase
{
    private readonly IBalanceDesglosadoService _service;

    [HttpPost("generar")]
    public async Task<ActionResult<BalanceDesglosadoDto>> GenerarBalance(
        [FromBody] GenerarBalanceDesglosadoRequest request)
    {
        var balance = await _service.GenerarBalanceDesglosadoAsync(
            request.IdEmpresa,
            request.Ano,
            request.FechaDesde,
            request.FechaHasta,
            request.TipoAjuste,
            request.IdAreaNegocio,
            request.IdCentroCosto,
            request.Nivel,
            request.EsLibroOficial,
            request.SaldosVigentes,
            request.VerSoloNivelSeleccionado,
            request.TipoDesglose,
            request.IdsDesglose);
        
        return Ok(balance);
    }
    
    [HttpGet("centros-costo/{idEmpresa}")]
    public async Task<ActionResult<List<DesgloseMeta>>> ObtenerCentrosCosto(int idEmpresa)
    {
        var centros = await _service.ObtenerCentrosCostoDisponiblesAsync(idEmpresa);
        return Ok(centros);
    }
    
    [HttpGet("areas-negocio/{idEmpresa}")]
    public async Task<ActionResult<List<DesgloseMeta>>> ObtenerAreasNegocio(int idEmpresa)
    {
        var areas = await _service.ObtenerAreasNegocioDisponiblesAsync(idEmpresa);
        return Ok(areas);
    }
    
    [HttpPost("exportar-excel")]
    public async Task<IActionResult> ExportarExcel([FromBody] BalanceDesglosadoDto balance)
    {
        var excelBytes = await _service.ExportarExcelAsync(balance);
        return File(excelBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", 
                    "BalanceDesglosado.xlsx");
    }
    
    [HttpPost("generar-pdf")]
    public async Task<IActionResult> GenerarPdf([FromBody] GenerarPdfBalanceRequest request)
    {
        var pdfBytes = await _service.GenerarPdfAsync(request.Balance, request.IdEmpresa, request.Ano);
        return File(pdfBytes, "application/pdf", "BalanceDesglosado.pdf");
    }
}
```

### 5.4. Vista MVC (Razor)

```html
<!-- Views/Index.cshtml -->

@model BalanceDesglosadoViewModel

<div class="container-fluid">
    <h2>Balance Clasificado Desglosado</h2>
    
    <form id="formBalanceDesglosado" method="post">
        <!-- Filtros de fecha -->
        <div class="row mb-3">
            <div class="col-md-3">
                <label>Fecha Desde</label>
                <input type="date" class="form-control" name="fechaDesde" required />
            </div>
            <div class="col-md-3">
                <label>Fecha Hasta</label>
                <input type="date" class="form-control" name="fechaHasta" required />
            </div>
            <div class="col-md-3">
                <label>Nivel</label>
                <select class="form-control" name="nivel">
                    <option value="2">Nivel 2</option>
                    <option value="3">Nivel 3</option>
                    <option value="4">Nivel 4</option>
                    <option value="5">Nivel 5</option>
                </select>
            </div>
            <div class="col-md-3">
                <label>Tipo Ajuste</label>
                <select class="form-control" name="tipoAjuste">
                    <option value="0">Sin Ajuste</option>
                    <option value="1">Ajuste CM</option>
                    <option value="2">Ajuste CP</option>
                    <option value="3">Tributario</option>
                    <option value="4">IFRS</option>
                    <option value="5">Todos</option>
                </select>
            </div>
        </div>
        
        <!-- Tipo de Desglose -->
        <div class="row mb-3">
            <div class="col-md-6">
                <label>Tipo de Desglose</label>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="tipoDesglose" 
                           id="radioCCosto" value="1" checked />
                    <label class="form-check-label" for="radioCCosto">
                        Centro de Costo
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="tipoDesglose" 
                           id="radioAreaNeg" value="2" />
                    <label class="form-check-label" for="radioAreaNeg">
                        Área de Negocio
                    </label>
                </div>
            </div>
        </div>
        
        <!-- Lista de selección múltiple para desglose -->
        <div class="row mb-3">
            <div class="col-md-6">
                <label>Seleccione Centros de Costo / Áreas de Negocio (máx. 20)</label>
                <select id="lstDesglose" class="form-control" multiple size="10" name="idsDesglose">
                    <!-- Se llena dinámicamente con JS -->
                </select>
                <small class="text-muted">Máximo 20 selecciones</small>
            </div>
        </div>
        
        <!-- Opciones adicionales -->
        <div class="row mb-3">
            <div class="col-md-4">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="esLibroOficial" />
                    <label class="form-check-label">Libro Oficial</label>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="saldosVigentes" />
                    <label class="form-check-label">Solo Saldos Vigentes</label>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="verSoloNivelSeleccionado" />
                    <label class="form-check-label">Ver Solo Nivel Seleccionado</label>
                </div>
            </div>
        </div>
        
        <!-- Botones de acción -->
        <div class="row mb-3">
            <div class="col-md-12">
                <button type="button" class="btn btn-primary" onclick="generarBalance()">
                    <i class="fas fa-play"></i> Generar Balance
                </button>
                <button type="button" class="btn btn-success" onclick="exportarExcel()">
                    <i class="fas fa-file-excel"></i> Exportar Excel
                </button>
                <button type="button" class="btn btn-danger" onclick="generarPdf()">
                    <i class="fas fa-file-pdf"></i> Generar PDF
                </button>
                <button type="button" class="btn btn-secondary" onclick="limpiar()">
                    <i class="fas fa-eraser"></i> Limpiar Desglose
                </button>
            </div>
        </div>
    </form>
    
    <!-- Tabla de resultados con columnas dinámicas -->
    <div class="table-responsive mt-4">
        <table id="tblBalanceDesglosado" class="table table-bordered table-sm">
            <thead>
                <tr id="headerRow">
                    <th>Código</th>
                    <th>Nombre</th>
                    <!-- Columnas dinámicas de desglose se insertan aquí -->
                    <th>TOTAL</th>
                </tr>
            </thead>
            <tbody id="bodyBalance">
                <!-- Se llena dinámicamente con JS -->
            </tbody>
        </table>
    </div>
</div>

<script>
async function generarBalance() {
    const formData = new FormData(document.getElementById('formBalanceDesglosado'));
    const idsDesglose = Array.from(document.getElementById('lstDesglose').selectedOptions)
                             .map(opt => parseInt(opt.value));
    
    if (idsDesglose.length === 0) {
        alert('Debe seleccionar al menos un Centro de Costo o Área de Negocio');
        return;
    }
    
    if (idsDesglose.length > 20) {
        alert('El máximo de desgloses es 20');
        return;
    }
    
    const request = {
        idEmpresa: @Model.IdEmpresa,
        ano: @Model.Ano,
        fechaDesde: formData.get('fechaDesde'),
        fechaHasta: formData.get('fechaHasta'),
        tipoAjuste: parseInt(formData.get('tipoAjuste')),
        nivel: parseInt(formData.get('nivel')),
        esLibroOficial: formData.get('esLibroOficial') === 'on',
        saldosVigentes: formData.get('saldosVigentes') === 'on',
        verSoloNivelSeleccionado: formData.get('verSoloNivelSeleccionado') === 'on',
        tipoDesglose: parseInt(formData.get('tipoDesglose')),
        idsDesglose: idsDesglose
    };
    
    const response = await fetch('/api/BalanceDesglosado/generar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(request)
    });
    
    const balance = await response.json();
    renderizarBalance(balance);
}

function renderizarBalance(balance) {
    // Construir encabezado dinámico
    const headerRow = document.getElementById('headerRow');
    headerRow.innerHTML = '<th>Código</th><th>Nombre</th>';
    
    // Agregar columnas de desglose
    balance.encabezadosDesglose.forEach(desglose => {
        const th = document.createElement('th');
        th.textContent = desglose.descripcion;
        headerRow.appendChild(th);
    });
    
    // Columna total
    const thTotal = document.createElement('th');
    thTotal.textContent = 'TOTAL';
    headerRow.appendChild(thTotal);
    
    // Construir filas de cuentas
    const tbody = document.getElementById('bodyBalance');
    tbody.innerHTML = '';
    
    balance.cuentas.forEach(cuenta => {
        const tr = document.createElement('tr');
        
        // Código
        const tdCodigo = document.createElement('td');
        tdCodigo.textContent = cuenta.codigo;
        tr.appendChild(tdCodigo);
        
        // Nombre (con indentación por nivel)
        const tdNombre = document.createElement('td');
        tdNombre.style.paddingLeft = (cuenta.nivel * 15) + 'px';
        tdNombre.textContent = cuenta.descripcion;
        if (cuenta.nivel === 1) {
            tdNombre.style.fontWeight = 'bold';
        }
        tr.appendChild(tdNombre);
        
        // Saldos de desglose
        balance.encabezadosDesglose.forEach(desglose => {
            const td = document.createElement('td');
            td.textContent = formatNumber(cuenta.saldosDesglose[desglose.id]);
            td.style.textAlign = 'right';
            tr.appendChild(td);
        });
        
        // Total
        const tdTotal = document.createElement('td');
        tdTotal.textContent = formatNumber(cuenta.saldoTotal);
        tdTotal.style.textAlign = 'right';
        tdTotal.style.fontWeight = 'bold';
        tr.appendChild(tdTotal);
        
        tbody.appendChild(tr);
    });
}

// Cargar lista de desglose según tipo seleccionado
document.querySelectorAll('input[name="tipoDesglose"]').forEach(radio => {
    radio.addEventListener('change', async (e) => {
        const tipoDesglose = parseInt(e.target.value);
        const lstDesglose = document.getElementById('lstDesglose');
        lstDesglose.innerHTML = '';
        
        let endpoint = tipoDesglose === 1 
            ? '/api/BalanceDesglosado/centros-costo/' + @Model.IdEmpresa
            : '/api/BalanceDesglosado/areas-negocio/' + @Model.IdEmpresa;
        
        const response = await fetch(endpoint);
        const items = await response.json();
        
        items.forEach(item => {
            const option = document.createElement('option');
            option.value = item.id;
            option.textContent = item.codigo + ' - ' + item.descripcion;
            lstDesglose.appendChild(option);
        });
    });
});

// Validar máximo 20 selecciones
document.getElementById('lstDesglose').addEventListener('change', (e) => {
    if (e.target.selectedOptions.length > 20) {
        alert('Máximo 20 desgloses permitidos');
        // Deseleccionar el último
        e.target.options[e.target.options.length - 1].selected = false;
    }
});

function formatNumber(num) {
    return new Intl.NumberFormat('es-CL', { 
        minimumFractionDigits: 0,
        maximumFractionDigits: 0 
    }).format(num);
}
</script>
```

## 6. Consideraciones Técnicas

### 6.1. Generación Dinámica de Columnas

**Desafío**: El número de columnas varía según cuántos CCostos/AreaNegs se seleccionen (1-20).

**Solución**:
1. Usar `Dictionary<string, decimal>` para almacenar saldos por desglose en cada cuenta
2. Generar encabezados dinámicamente en frontend con JavaScript
3. Usar DataTable o Grid component que soporte columnas dinámicas

### 6.2. Consulta SQL Compleja

El VB6 usa `GenQueryPorNiveles()` que genera SQL dinámico complejo con:
- PIVOT/UNPIVOT para columnas de desglose
- CROSS JOIN para expandir por cada CCosto/AreaNeg
- Múltiples subconsultas para cada nivel jerárquico

**Opción .NET**:
- Usar SQL raw con `FromSqlRaw()` o `ExecuteSqlRaw()`
- O usar LINQ con proyecciones complejas
- Considerar crear View o Stored Procedure en BD

### 6.3. Performance

**Riesgo**: Con 20 desgloses y 5 niveles jerárquicos, la cantidad de datos puede ser muy grande.

**Mitigaciones**:
- Paginación en frontend
- Índices en `MovComprobante(IdCuenta, CentroCosto, AreaNeg)`
- Cachear resultados para exportaciones subsiguientes
- Lazy loading de niveles inferiores

### 6.4. Exportación a Excel

**Requerimientos**:
- Columnas dinámicas (hasta 32)
- Formato de moneda con separadores de miles
- Negrita en totales y Nivel 1
- Freeze panes en header y primeras 2 columnas
- Auto-width para columnas

**Librería**: EPPlus 7.0

### 6.5. Generación de PDF

**Desafío**: Tabla horizontal con muchas columnas puede no caber en hoja Letter.

**Soluciones**:
- Orientación horizontal (Landscape)
- Reducir tamaño de fuente para acomodar
- Dividir en múltiples páginas si superan 10-12 desgloses
- Considerar formato A3 o múltiples hojas

**Librería**: QuestPDF o iText7

### 6.6. Cálculo Jerárquico Eficiente

**Algoritmo VB6**: 4 loops anidados (O(n²) en peor caso)

**Mejora .NET**:
1. Cargar cuentas ordenadas por Nivel1, Nivel2, ..., Nivel5
2. Usar Dictionary para acceso rápido a cuentas padre
3. Un solo paso de agregación bottom-up

```csharp
// Pseudo-código optimizado
var cuentasPorCodigo = cuentas.ToDictionary(c => c.Codigo);

for (int nivel = 5; nivel >= 2; nivel--)
{
    foreach (var cuenta in cuentas.Where(c => c.Nivel == nivel))
    {
        var codigoPadre = cuenta.GetCodigoPadre(); // Ej: "10101" -> "101"
        
        if (cuentasPorCodigo.TryGetValue(codigoPadre, out var cuentaPadre))
        {
            foreach (var kvp in cuenta.SaldosDesglose)
            {
                cuentaPadre.SaldosDesglose[kvp.Key] += kvp.Value;
            }
            cuentaPadre.SaldoTotal += cuenta.SaldoTotal;
        }
    }
}
```

## 7. Casos de Uso

### 7.1. Balance Desglosado por Centro de Costo

**Escenario**: Gerente quiere ver saldos de todas las cuentas de Activo y Pasivo separados por sucursales (centros de costo).

**Pasos**:
1. Seleccionar rango de fechas (01/01/2025 - 31/12/2025)
2. Seleccionar Nivel 3
3. Tipo de Desglose: Centro de Costo
4. Seleccionar 5 centros (Sucursal Norte, Sur, Este, Oeste, Central)
5. Generar Balance
6. Ver tabla con 7 columnas: Código | Nombre | Norte | Sur | Este | Oeste | Central | TOTAL
7. Exportar a Excel para análisis

### 7.2. Balance Desglosado por Área de Negocio

**Escenario**: Contador necesita analizar rentabilidad por línea de negocio.

**Pasos**:
1. Seleccionar rango (trimestre actual)
2. Seleccionar Nivel 4
3. Tipo de Desglose: Área de Negocio
4. Seleccionar 3 áreas (Ventas, Servicios, Manufactura)
5. Generar Balance
6. Ver Ganancias y Pérdidas separadas por área
7. Calcular Resultado del Ejercicio por cada área

### 7.3. Balance Solo Nivel Seleccionado

**Escenario**: Auditor necesita revisar solo cuentas de Nivel 5 (máximo detalle).

**Pasos**:
1. Seleccionar Nivel 5
2. Marcar "Ver Solo Nivel Seleccionado"
3. Generar Balance
4. Grid muestra SOLO cuentas de Nivel 5 (sin padres)

### 7.4. Balance con Múltiples Filtros

**Escenario**: Informe financiero trimestral con filtros específicos.

**Pasos**:
1. Rango: Trimestre completo
2. Tipo Ajuste: Solo Sin Ajuste (sin ajustes contables)
3. Área de Negocio específica: "Ventas"
4. Centro de Costo: No especificar (todos)
5. Libro Oficial: Sí
6. Saldos Vigentes: Sí
7. Tipo Desglose: Centro de Costo
8. Seleccionar 8 sucursales
9. Generar Balance
10. Generar PDF para adjuntar a informe ejecutivo

## 8. Notas de Migración

### 8.1. Diferencias con Balance Ejecutivo

| Aspecto | Balance Ejecutivo | Balance Desglosado |
|---------|-------------------|---------------------|
| Layout | Paralelo (Activos \| Pasivos) | Lineal con columnas dinámicas |
| Columnas | Fijo (8 columnas) | Variable (11 + NumDesgloses + 1) |
| Desglose | No tiene | Sí (CCosto o AreaNeg) |
| Complejidad | Alta | Muy Alta |
| Usuarios | Gerencia | Contadores y Auditores |
| Exportación | Excel simple | Excel con columnas dinámicas |

### 8.2. Dependencias

**Tablas DB**:
- MovComprobante (JOIN principal)
- Comprobante
- Cuentas
- CentroCosto
- AreaNegocio
- Empresa
- EmpresasAno
- ParamEmpresa
- EstadoMes
- Firmas (para PDF con firmas)

**Módulos Compartidos**:
- DateHelper (conversión fechas VB6 ↔ .NET)
- NumberHelper (formato moneda chilena)
- PdfHelper (generación PDF)
- ExcelHelper (generación Excel con EPPlus)

### 8.3. Migración de GenQueryPorNiveles()

**VB6 Function**:
```vb6
Function GenQueryPorNiveles(FDesde, FHasta, TipoAjuste, AreaNeg, CCostos, _
                            Nivel, EsOficial, SaldosVigentes, ByCCosto) As String
    ' Genera SQL dinámico complejo con:
    ' - CASE WHEN para cada columna de desglose
    ' - SUM con filtro por CCosto/AreaNeg
    ' - GROUP BY por cuenta
    ' - ORDER BY por Clasificación y Niveles jerárquicos
    ' ... 200+ líneas de string concatenation
End Function
```

**Estrategia .NET**:

**Opción 1 - LINQ Dinámico**:
```csharp
// Complejo pero type-safe
var query = context.MovComprobante
    .Where(m => m.Comprobante.Fecha >= fechaDesde && m.Comprobante.Fecha <= fechaHasta)
    .Where(m => tipoAjuste == 0 || m.TipoAjuste == tipoAjuste)
    .GroupBy(m => new { m.IdCuenta, m.CentroCosto })  // o m.AreaNeg
    .Select(g => new {
        g.Key.IdCuenta,
        g.Key.CentroCosto,
        Saldo = g.Sum(m => m.Debe - m.Haber)
    });
```

**Opción 2 - SQL Raw** (Recomendada):
```csharp
// Más eficiente, similar a VB6
var sql = @"
SELECT 
    c.Codigo, c.Descripcion, c.Clasificacion, c.Nivel,
    c.Nivel1, c.Nivel2, c.Nivel3, c.Nivel4, c.Nivel5,
    " + GenerarColumnasDesglose(idsDesglose, tipoDesglose) + @"
FROM Cuentas c
LEFT JOIN (
    SELECT 
        mc.IdCuenta,
        " + (tipoDesglose == CCosto ? "mc.CentroCosto" : "mc.AreaNeg") + @" AS IdDesglose,
        SUM(mc.Debe - mc.Haber) AS Saldo
    FROM MovComprobante mc
    INNER JOIN Comprobante co ON mc.IdComp = co.IdComp
    WHERE co.Fecha >= @FechaDesde AND co.Fecha <= @FechaHasta
      AND (@TipoAjuste = 0 OR mc.TipoAjuste = @TipoAjuste)
      " + (idCCosto.HasValue ? "AND mc.CentroCosto = @IdCCosto" : "") + @"
    GROUP BY mc.IdCuenta, " + (tipoDesglose == CCosto ? "mc.CentroCosto" : "mc.AreaNeg") + @"
) movs ON c.IdCuenta = movs.IdCuenta
ORDER BY c.Clasificacion, c.Nivel1, c.Nivel2, c.Nivel3, c.Nivel4, c.Nivel5
";

string GenerarColumnasDesglose(List<int> ids, TipoDesglose tipo)
{
    var columnas = new List<string>();
    for (int i = 0; i < ids.Count; i++)
    {
        columnas.Add($"SUM(CASE WHEN movs.IdDesglose = {ids[i]} THEN movs.Saldo ELSE 0 END) AS Desglose{i}");
    }
    columnas.Add("SUM(movs.Saldo) AS SaldoTotal");
    return string.Join(", ", columnas);
}

var cuentas = await context.Database
    .SqlQueryRaw<CuentaBalanceDesglosadoDto>(sql, parameters)
    .ToListAsync();
```

### 8.4. Testing

**Unit Tests**:
- Cálculo de totales jerárquicos
- Cálculo de Resultado del Ejercicio
- Validación de límites (máx. 20 desgloses)
- Formato de números (separador de miles)

**Integration Tests**:
- Generación de balance completo con datos reales
- Exportación Excel con columnas dinámicas
- Generación PDF horizontal

**Manual Testing**:
- Comparar resultados con VB6 (mismos filtros y desgloses)
- Validar que Total Activos = Total Pasivos + Patrimonio + Resultado
- Verificar formato de exportación Excel

## 9. Estimación de Complejidad

**Complejidad**: **MUY ALTA** (Similar a Balance Ejecutivo pero con mayor complejidad por columnas dinámicas)

**Tiempo Estimado**: 20-24 horas

**Desglose**:
- DTOs y Enums: 1 hora
- Service Interface: 0.5 hora
- Implementación Service (SQL dinámico): 6-7 horas
- Cálculo jerárquico optimizado: 3-4 horas
- API Controller: 1 hora
- MVC Controller y ViewModel: 1 hora
- Razor View con columnas dinámicas: 3-4 horas
- JavaScript para renderizado dinámico: 2-3 horas
- Exportación Excel con EPPlus: 2 horas
- Generación PDF: 2 horas
- Testing y debugging: 2-3 horas

**Factores de Complejidad**:
- ⚠️ Columnas dinámicas (1-20)
- ⚠️ SQL dinámico complejo con PIVOT/CASE
- ⚠️ Cálculo jerárquico de 5 niveles
- ⚠️ Múltiples filtros combinados
- ⚠️ Exportación con formato preservado
- ⚠️ Renderizado eficiente de tablas grandes

## 10. Dependencias Externas

### 10.1. Tablas de Base de Datos

```
MovComprobante (principal)
├── Comprobante (fechas)
├── Cuentas (jerarquía)
├── CentroCosto (desglose)
├── AreaNegocio (desglose)
├── Empresa
├── EmpresasAno
├── ParamEmpresa (configuración)
├── EstadoMes (validaciones)
└── Firmas (PDF con firma)
```

### 10.2. Librerías NuGet

- **EPPlus 7.0**: Exportación Excel con columnas dinámicas
- **QuestPDF o iText7**: Generación PDF orientación horizontal
- **System.Linq.Dynamic.Core**: Para construir expresiones LINQ dinámicas (opcional)

## 11. Recomendaciones de Implementación

### 11.1. Enfoque Incremental

**Fase 1 - Base**:
1. Crear DTOs básicos
2. Implementar service con 1 solo desglose (simplificado)
3. Vista básica sin columnas dinámicas
4. Validar cálculos contra VB6

**Fase 2 - Desglose Múltiple**:
1. Agregar soporte para múltiples desgloses (hasta 20)
2. Generación dinámica de columnas en SQL
3. Renderizado dinámico en frontend

**Fase 3 - Exportación**:
1. Implementar exportación Excel
2. Implementar generación PDF
3. Agregar envío por correo

**Fase 4 - Optimización**:
1. Optimizar query SQL
2. Implementar caching
3. Performance testing con datos grandes

### 11.2. Alternativa: Stored Procedure

Dada la complejidad del SQL dinámico, considerar crear Stored Procedure en BD:

```sql
CREATE PROCEDURE sp_GenerarBalanceDesglosado
    @IdEmpresa INT,
    @Ano INT,
    @FechaDesde DATE,
    @FechaHasta DATE,
    @TipoAjuste INT,
    @Nivel INT,
    @TipoDesglose INT,  -- 1=CCosto, 2=AreaNeg
    @IdsDesglose VARCHAR(200),  -- CSV: "1,5,8,12"
    @EsLibroOficial BIT,
    @SaldosVigentes BIT
AS
BEGIN
    -- SQL optimizado con performance tuning
    -- Retorna resultados con columnas pivoteadas
END
```

Ventajas:
- Performance superior
- Lógica compleja encapsulada en BD
- Fácil mantenimiento y tuning
- Menos código .NET

Desventajas:
- Menos portable
- Requiere permisos de BD
- Testing más complejo

### 11.3. Componente de Grid Recomendado

Para manejar columnas dinámicas en frontend:

**Opción 1 - ag-Grid** (Recomendada):
- Soporte nativo para columnas dinámicas
- Performance excelente con miles de filas
- Exportación integrada a Excel
- Libre para uso no comercial

**Opción 2 - Handsontable**:
- Comportamiento tipo Excel
- Edición inline (si se requiere)
- Menos features que ag-Grid

**Opción 3 - Tabla HTML + DataTables.js**:
- Más simple
- Suficiente para visualización
- Exportación con plugins

### 11.4. Manejo de Errores

**Validaciones Críticas**:
- Rango de fechas válido
- Máximo 20 desgloses
- Al menos 1 desglose seleccionado
- Tipo de desglose excluyente (CCosto XOR AreaNeg)
- IdEmpresa y Ano válidos

**Mensajes de Usuario**:
- "Debe seleccionar al menos un Centro de Costo o Área de Negocio"
- "El máximo de desgloses permitido es 20"
- "La fecha Desde debe ser menor o igual a la fecha Hasta"
- "No se encontraron movimientos para los filtros seleccionados"

### 11.5. Documentación

**Documentar**:
- Algoritmo de cálculo jerárquico
- Lógica de Resultado del Ejercicio
- Estructura de SQL dinámico
- Formato de diccionario de saldos por desglose
- Ejemplos de uso de API

## 12. Comparación con Balance Ejecutivo

| Característica | Balance Ejecutivo | Balance Desglosado |
|---------------|-------------------|---------------------|
| **Complejidad** | Alta (16-20 hrs) | Muy Alta (20-24 hrs) |
| **Layout** | Paralelo (2 columnas) | Lineal (columnas dinámicas) |
| **Columnas Grid** | 17 fijas | 35 (11 fijas + 20 dinámicas + 4) |
| **SQL** | Complejo | Muy complejo (PIVOT/CASE) |
| **Desglose** | No | Sí (CCosto/AreaNeg) |
| **Frontend** | Estático | Dinámico (JS) |
| **Excel Export** | Simple | Columnas dinámicas |
| **PDF** | Vertical | Horizontal (landscape) |
| **Uso** | Gerencia (resumen) | Contabilidad (detalle) |
| **Prioridad** | Media | Baja (menos usado) |

**Recomendación**: Implementar **Balance Ejecutivo primero**, luego reutilizar componentes para Balance Desglosado.

## 13. Conclusión

El **Balance Desglosado** es una de las features más complejas del sistema debido a:

1. **Columnas dinámicas** (1-20 desgloses)
2. **SQL dinámico** con PIVOT/CASE complejos
3. **Cálculo jerárquico** de 5 niveles
4. **Múltiples dimensiones** de filtro
5. **Exportación avanzada** con formato preservado

**Estrategia Recomendada**:
- Implementar Balance Ejecutivo primero (base sólida)
- Implementar Balance Desglosado en Fase 2
- Considerar Stored Procedure para SQL complejo
- Usar ag-Grid para columnas dinámicas
- Testing exhaustivo con datos reales
- Comparar resultados con VB6 para validación

**Riesgo**: ALTO - Requiere experiencia con SQL dinámico, grid libraries, y exportación avanzada.

**Beneficio**: Una vez implementado, proporciona análisis financiero detallado muy valioso para contadores y auditores.
