using App.Data;
using Microsoft.EntityFrameworkCore;

namespace App.Features.CapitalSimpleMini;

public class CapitalSimpleMiniService(
    LpContabContext context,
    ILogger<CapitalSimpleMiniService> logger) : ICapitalSimpleMiniService
{
    // Constantes del VB6 - TipoDetCPS
    private const int CPS_OTROSAJUSTAUMENTOS = 1;
    private const int CPS_OTROSAJUSTDISMIN = 2;
    
    // Constantes del VB6 - TipoInforme
    private const int CPS_TIPOINFO_GENERAL = 0;
    private const int CPS_TIPOINFO_VARANUAL = 1;

    public async Task<CapitalSimpleMiniDto> GetAllAsync(int empresaId, short ano, byte tipoDetCps, int tipoInforme)
    {
        logger.LogInformation("Getting CapitalSimpleMini for empresa: {EmpresaId}, ano: {Ano}, tipo: {TipoDetCps}, informe: {TipoInforme}",
            empresaId, ano, tipoDetCps, tipoInforme);

        {
            var result = new CapitalSimpleMiniDto
            {
                EmpresaId = empresaId,
                Ano = ano,
                TipoDetCps = tipoDetCps,
                TipoInforme = tipoInforme,
                Titulo = GetTitulo(tipoDetCps),
                MostrarBotonAcumulado = tipoInforme == CPS_TIPOINFO_GENERAL,
                AcumuladosAnteriores = new List<AcumuladoAnualDto>(),
                DetallesAnoActual = new List<DetalleCapitalDto>()
            };

            // VB6: LoadAll - Cargar acumulados de años anteriores (solo si TipoInforme = GENERAL)
            if (tipoInforme == CPS_TIPOINFO_GENERAL)
            {
                var acumulados = await context.CapPropioSimplAnual
                    .Where(c => c.TipoDetCPS == tipoDetCps
                             && c.AnoValor < ano
                             && c.Valor != 0
                             && c.IdEmpresa == empresaId)
                    .OrderBy(c => c.AnoValor)
                    .Select(c => new AcumuladoAnualDto
                    {
                        AnoValor = c.AnoValor ?? 0,
                        Valor = Math.Abs((decimal)(c.Valor ?? 0))
                    })
                    .ToListAsync();

                result.AcumuladosAnteriores = acumulados;
                logger.LogInformation("Loaded {Count} acumulados anteriores", acumulados.Count);
            }

            // VB6: LoadAll - Cargar SOLO registros de ingreso manual del año actual
            // IMPORTANTE: VB6 tiene TODO el código de comprobantes comentado
            var detalles = await context.DetCapPropioSimpl
                .Where(d => d.IngresoManual == true
                         && d.TipoDetCPS == tipoDetCps
                         && d.IdEmpresa == empresaId
                         && d.Ano == ano)
                .OrderBy(d => d.Fecha)
                .ThenBy(d => d.IdDetCapPropioSimpl)
                .Select(d => new DetalleCapitalDto
                {
                    IdDetCapPropioSimpl = d.IdDetCapPropioSimpl,
                    IngresoManual = d.IngresoManual ?? true,
                    Fecha = d.Fecha.HasValue && d.Fecha.Value > 0 ? IntToDateTime(d.Fecha.Value) : null,
                    Descrip = d.Descrip ?? string.Empty,
                    Valor = Math.Abs((decimal)(d.Valor ?? 0))
                })
                .ToListAsync();

            result.DetallesAnoActual = detalles;
            logger.LogInformation("Loaded {Count} detalles manuales del año {Ano}", detalles.Count, ano);

            // Calcular totales
            var totales = CalculateTotals(empresaId, ano, result.AcumuladosAnteriores, result.DetallesAnoActual);
            result.TotalAno = totales.TotalAno;
            result.TotalAcumulado = totales.TotalAcumulado;

            logger.LogInformation("Totals - TotalAno: {TotalAno}, TotalAcumulado: {TotalAcum}",
                result.TotalAno, result.TotalAcumulado);

            return result;
        }
    }

    public async Task<CapitalSimpleMiniDto> SaveAsync(int empresaId, short ano, byte tipoDetCps, CapitalSimpleMiniSaveDto dto)
    {
        logger.LogInformation("Saving CapitalSimpleMini for empresa: {EmpresaId}, ano: {Ano}, tipo: {TipoDetCps}",
            empresaId, ano, tipoDetCps);

        {
            // VB6: Valida() - Validar datos antes de guardar
            foreach (var detalle in dto.Detalles.Where(d => !d.IsDeleted && d.IngresoManual == true))
            {
                if (!detalle.Fecha.HasValue)
                {
                    throw new Exception("Falta ingresar la fecha.");
                }

                if (detalle.Valor == 0)
                {
                    throw new Exception("Falta ingresar el valor.");
                }

                // Validar que la fecha esté en el año
                if (detalle.Fecha.Value.Year != ano)
                {
                    logger.LogWarning("Fecha {Fecha} no pertenece al año {Ano}", detalle.Fecha.Value, ano);
                    // VB6 muestra advertencia pero permite continuar
                }
            }

            // VB6: SaveAll - Procesar cambios de ingreso manual
            foreach (var detalle in dto.Detalles)
            {
                if (detalle.IngresoManual == true)
                {
                    if (detalle.IsDeleted && detalle.IdDetCapPropioSimpl > 0)
                    {
                        // DELETE
                        var existing = await context.DetCapPropioSimpl
                            .FirstOrDefaultAsync(d => d.IdDetCapPropioSimpl == detalle.IdDetCapPropioSimpl
                                                   && d.IdEmpresa == empresaId
                                                   && d.Ano == ano);

                        if (existing != null)
                        {
                            context.DetCapPropioSimpl.Remove(existing);
                            logger.LogInformation("Deleting detalle: {Id}", detalle.IdDetCapPropioSimpl);
                        }
                    }
                    else if (detalle.IsNew || detalle.IdDetCapPropioSimpl == 0)
                    {
                        // INSERT
                        var newDetalle = new App.Data.DetCapPropioSimpl
                        {
                            IdEmpresa = empresaId,
                            Ano = ano,
                            TipoDetCPS = tipoDetCps,
                            IngresoManual = true,
                            IdCuenta = 0,
                            CodCuenta = " ",
                            Fecha = detalle.Fecha.HasValue ? DateTimeToInt(detalle.Fecha.Value) : 0,
                            Descrip = detalle.Descrip ?? string.Empty,
                            IdMovComp = 0,
                            Valor = (double)detalle.Valor
                        };

                        context.DetCapPropioSimpl.Add(newDetalle);
                        logger.LogInformation("Inserting new detalle");
                    }
                    else if (detalle.IsModified)
                    {
                        // UPDATE
                        var existing = await context.DetCapPropioSimpl
                            .FirstOrDefaultAsync(d => d.IdDetCapPropioSimpl == detalle.IdDetCapPropioSimpl
                                                   && d.IdEmpresa == empresaId
                                                   && d.Ano == ano);

                        if (existing != null)
                        {
                            existing.Fecha = detalle.Fecha.HasValue ? DateTimeToInt(detalle.Fecha.Value) : 0;
                            existing.Descrip = detalle.Descrip ?? string.Empty;
                            existing.Valor = (double)detalle.Valor;
                            logger.LogInformation("Updating detalle: {Id}", detalle.IdDetCapPropioSimpl);
                        }
                    }
                }
            }

            await context.SaveChangesAsync();
            logger.LogInformation("DetCapPropioSimpl changes saved");

            // Recargar datos actualizados
            var updatedData = await GetAllAsync(empresaId, ano, tipoDetCps, CPS_TIPOINFO_GENERAL);

            // VB6: SaveAll - Actualizar EmpresasAno con el total acumulado (GridTot)
            var empresaAno = await context.EmpresasAno
                .FirstOrDefaultAsync(e => e.idEmpresa == empresaId && e.Ano == ano);

            if (empresaAno != null)
            {
                if (tipoDetCps == CPS_OTROSAJUSTAUMENTOS)
                {
                    empresaAno.CPS_OtrosAjustesAumentos = (double)updatedData.TotalAcumulado;
                    logger.LogInformation("Updated CPS_OtrosAjustesAumentos = {Value}", updatedData.TotalAcumulado);
                }
                else if (tipoDetCps == CPS_OTROSAJUSTDISMIN)
                {
                    empresaAno.CPS_OtrosAjustesDisminuciones = (double)updatedData.TotalAcumulado;
                    logger.LogInformation("Updated CPS_OtrosAjustesDisminuciones = {Value}", updatedData.TotalAcumulado);
                }

                await context.SaveChangesAsync();
            }

            // VB6: SaveAll - Actualizar/Insertar CapPropioSimplAnual con el total del año (lRowTotAno)
            var anual = await context.CapPropioSimplAnual
                .FirstOrDefaultAsync(c => c.TipoDetCPS == tipoDetCps
                                       && c.AnoValor == ano
                                       && c.IdEmpresa == empresaId);

            if (anual != null)
            {
                anual.Valor = (double)updatedData.TotalAno;
                anual.IngresoManual = false;
                logger.LogInformation("Updated CapPropioSimplAnual for ano {Ano} = {Value}", ano, updatedData.TotalAno);
            }
            else
            {
                context.CapPropioSimplAnual.Add(new App.Data.CapPropioSimplAnual
                {
                    TipoDetCPS = tipoDetCps,
                    IngresoManual = false,
                    AnoValor = ano,
                    Valor = (double)updatedData.TotalAno,
                    IdEmpresa = empresaId
                });
                logger.LogInformation("Inserted CapPropioSimplAnual for ano {Ano} = {Value}", ano, updatedData.TotalAno);
            }

            await context.SaveChangesAsync();

            return updatedData;
        }
    }

    public async Task<bool> DeleteAsync(int empresaId, short ano, int idDetalle)
    {
        logger.LogInformation("Deleting detalle: {IdDetalle}", idDetalle);

        {
            // VB6: Bt_Del_Click - Validar que sea ingreso manual
            var detalle = await context.DetCapPropioSimpl
                .FirstOrDefaultAsync(d => d.IdDetCapPropioSimpl == idDetalle
                                       && d.IdEmpresa == empresaId
                                       && d.Ano == ano);

            if (detalle == null)
            {
                logger.LogWarning("Detalle not found: {IdDetalle}", idDetalle);
                return false;
            }

            if (detalle.IngresoManual != true)
            {
                logger.LogWarning("Cannot delete - not ingreso manual: {IdDetalle}", idDetalle);
                throw new Exception("Sólo se pueden eliminar los registros de ingreso manual.");
            }

            context.DetCapPropioSimpl.Remove(detalle);
            await context.SaveChangesAsync();
            
            logger.LogInformation("Detalle deleted successfully: {IdDetalle}", idDetalle);
            return true;
        }
    }

    public async Task<ValidationResult> ValidateAsync(CapitalSimpleMiniSaveDto dto)
    {
        await Task.CompletedTask;
        
        var result = new ValidationResult { IsValid = true };

        // VB6: valida() function
        foreach (var detalle in dto.Detalles.Where(d => !d.IsDeleted && d.IngresoManual == true))
        {
            if (!detalle.Fecha.HasValue)
            {
                result.IsValid = false;
                result.Errors.Add("Falta ingresar la fecha.");
            }

            if (detalle.Valor == 0)
            {
                result.IsValid = false;
                result.Errors.Add("Falta ingresar el valor.");
            }
        }

        return result;
    }

    public async Task<bool> CanDeleteAsync(int idDetalle)
    {
        var detalle = await context.DetCapPropioSimpl
            .FirstOrDefaultAsync(d => d.IdDetCapPropioSimpl == idDetalle);

        return detalle?.IngresoManual == true;
    }

    public async Task<CalculoTotalesDto> CalculateTotalsAsync(int empresaId, short ano, byte tipoDetCps, List<DetalleCapitalDto> detalles)
    {
        // Este método ya no se usa, pero mantengo para compatibilidad
        await Task.CompletedTask;
        
        decimal totalAno = detalles.Where(d => !d.IsDeleted).Sum(d => d.Valor);
        
        var acumuladoAnteriores = await context.CapPropioSimplAnual
            .Where(c => c.TipoDetCPS == tipoDetCps
                     && c.AnoValor < ano
                     && c.IdEmpresa == empresaId)
            .SumAsync(c => c.Valor ?? 0);

        decimal totalAcumulado = (decimal)acumuladoAnteriores + totalAno;

        return new CalculoTotalesDto
        {
            TotalAno = totalAno,
            TotalAcumulado = totalAcumulado
        };
    }

    public async Task<string> GetTituloAsync(byte tipoDetCps)
    {
        await Task.CompletedTask;
        return GetTitulo(tipoDetCps);
    }

    public async Task<byte[]> ExportToExcelAsync(int empresaId, short ano, byte tipoDetCps)
    {
        logger.LogInformation("Exporting CapitalSimpleMini to Excel");

        // VB6: Bt_CopyExcel_Click
        // TODO: Implementar exportación Excel usando EPPlus
        await Task.CompletedTask;
        return Array.Empty<byte>();
    }

    // Métodos privados auxiliares

    private string GetTitulo(byte tipoDetCps)
    {
        // VB6: Me.Caption = gTipoDetCapPropioSimpl(lTipoDetCapPropioSimpl)
        return tipoDetCps == CPS_OTROSAJUSTAUMENTOS
            ? "Otros Ajustes (Aumentos)"
            : "Otros Ajustes (Disminuciones)";
    }

    private CalculoTotalesDto CalculateTotals(int empresaId, short ano, List<AcumuladoAnualDto> acumulados, List<DetalleCapitalDto> detalles)
    {
        // VB6: CalcTot - Calcular total del año y total acumulado
        
        // Total del año actual (suma de detalles)
        decimal totalAno = detalles.Where(d => !d.IsDeleted).Sum(d => d.Valor);

        // Total acumulado (años anteriores + año actual)
        decimal totalAcumuladoAnteriores = acumulados.Sum(a => a.Valor);
        decimal totalAcumulado = totalAcumuladoAnteriores + totalAno;

        logger.LogDebug("CalculateTotals - TotalAno: {TotalAno}, AcumAnteriores: {AcumAnt}, TotalAcum: {TotalAcum}",
            totalAno, totalAcumuladoAnteriores, totalAcumulado);

        return new CalculoTotalesDto
        {
            TotalAno = totalAno,
            TotalAcumulado = totalAcumulado
        };
    }

    private static DateTime? IntToDateTime(int dateInt)
    {
        if (dateInt <= 0) return null;

        {
            // VB6: Fechas almacenadas como días desde 30/12/1899
            DateTime baseDate = new DateTime(1899, 12, 30);
            return baseDate.AddDays(dateInt);
        }
    }

    private static int DateTimeToInt(DateTime date)
    {
        // VB6: Fechas almacenadas como días desde 30/12/1899
        DateTime baseDate = new DateTime(1899, 12, 30);
        return (int)(date - baseDate).TotalDays;
    }
}
