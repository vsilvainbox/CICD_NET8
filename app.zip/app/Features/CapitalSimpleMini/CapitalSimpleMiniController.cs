using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.CapitalSimpleMini;


public class CapitalSimpleMiniController(
    ILogger<CapitalSimpleMiniController> logger,
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator) : Controller
{
    public IActionResult Index(
        int? tipoDetCps = null,
        int? tipoInforme = null)
    {
        // Obtener empresaId y ano desde sesi�n (BaseController)
        var empresaId = SessionHelper.EmpresaId;
        var ano = SessionHelper.Ano;

        if (empresaId == 0)
        {
            logger.LogWarning("No empresa selected in session, redirecting to SeleccionarEmpresa");
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        // Usar valores por defecto si no se proporcionan
        var tipoDetCpsValue = tipoDetCps ?? 1; // Default: CPS_OTROSAJUSTAUMENTOS
        var tipoInformeValue = tipoInforme ?? 0; // Default: CPS_TIPOINFO_GENERAL

        logger.LogInformation("Loading CapitalSimpleMini for empresa: {EmpresaId}, ano: {Ano}, tipo: {TipoDetCps}, informe: {TipoInforme}",
            empresaId, ano, tipoDetCpsValue, tipoInformeValue);

        // Establecer ViewData con datos de sesi�n
        
        ViewData["TipoDetCps"] = tipoDetCpsValue;
        ViewData["TipoInforme"] = tipoInformeValue;

        return View();
    }

    /// <summary>
    /// M�todo proxy para GetData (GET) - llamada desde JavaScript
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetData(int empresaId, short ano, int tipoDetCps, int tipoInforme)
    {
        logger.LogInformation("Proxy GetData: empresaId={EmpresaId}, ano={Ano}, tipoDetCps={TipoDetCps}, tipoInforme={TipoInforme}",
            empresaId, ano, tipoDetCps, tipoInforme);

        {
            var client = httpClientFactory.CreateClient("ApiClient");
            var url = linkGenerator.GetPathByAction(
                action: nameof(CapitalSimpleMiniApiController.GetData),
                controller: nameof(CapitalSimpleMiniApiController).Replace("Controller", ""),
                values: new { empresaId, ano, tipoDetCps, tipoInforme });
            var datos = await client.GetFromApiAsync<object>(url!);

            return Ok(datos);
        }
    }

    /// <summary>
    /// M�todo proxy para SaveData (POST) - llamada desde JavaScript
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> SaveData([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy SaveData called");

        {
            var client = httpClientFactory.CreateClient("ApiClient");
            var url = linkGenerator.GetPathByAction(
                action: nameof(CapitalSimpleMiniApiController.SaveData),
                controller: nameof(CapitalSimpleMiniApiController).Replace("Controller", ""));
            var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);

            return StatusCode(statusCode, content);
        }
    }
}
