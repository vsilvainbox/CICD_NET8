using Microsoft.AspNetCore.Mvc;

namespace App.Features.ConfiguracionPlanCuentas;

[ApiController]
[Route("api/[controller]/[action]")]
public class ConfiguracionPlanCuentasApiController(
    IConfiguracionPlanCuentasService service,
    ILogger<ConfiguracionPlanCuentasApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<ConfiguracionActualDto>> GetConfiguracionActual(int empresaId)
    {
        logger.LogInformation("API: GetConfiguracionActual for empresaId: {EmpresaId}", empresaId);

        {
            var config = await service.GetConfiguracionActualAsync(empresaId);

            if (config == null)
            {
                return NotFound(new { message = "Empresa no encontrada" });
            }

            return Ok(config);
        }
    }

    [HttpGet]
    public async Task<ActionResult<List<FranquiciaTributariaDto>>> GetFranquicias()
    {
        logger.LogInformation("API: GetFranquicias called");

        {
            var franquicias = await service.GetFranquiciasDisponiblesAsync();
            return Ok(franquicias);
        }
    }

    [HttpGet]
    public async Task<ActionResult<int?>> GetFranquiciaActiva(int empresaId)
    {
        logger.LogInformation("API: GetFranquiciaActiva for empresaId: {EmpresaId}", empresaId);

        {
            var franquiciaId = await service.GetFranquiciaActivaAsync(empresaId);
            return Ok(new { franquiciaId });
        }
    }

    [HttpPut]
    public async Task<ActionResult<ValidationResult>> ActualizarFranquicia(
        [FromQuery] int empresaId,
        [FromQuery] int franquiciaId)
    {
        logger.LogInformation("API: ActualizarFranquicia {FranquiciaId} for empresaId: {EmpresaId}", franquiciaId, empresaId);

        {
            var result = await service.ValidarYActualizarFranquiciaAsync(empresaId, franquiciaId);

            if (!result.IsValid)
            {
                return BadRequest(result);
            }

            return Ok(result);
        }
    }

    [HttpGet]
    public async Task<ActionResult<PlanCuentasPreviewDto>> GetPreview(
        [FromQuery] int empresaId,
        [FromQuery] int franquiciaId)
    {
        logger.LogInformation("API: GetPreview for franquiciaId: {FranquiciaId}, empresaId: {EmpresaId}", franquiciaId, empresaId);

        {
            var preview = await service.PreviewPlanCuentasAsync(empresaId, franquiciaId);
            return Ok(preview);
        }
    }

    [HttpPost]
    public async Task<ActionResult<ResultadoAplicacionDto>> Aplicar(
        [FromBody] AplicarPlanCuentasDto dto,
        [FromQuery] int userId)
    {
        logger.LogInformation("API: Aplicar for empresaId: {EmpresaId}, franquiciaId: {FranquiciaId}", dto.EmpresaId, dto.FranquiciaId);

        {
            var resultado = await service.AplicarPlanCuentasAsync(
                dto.EmpresaId,
                dto.Ano,
                dto.FranquiciaId,
                userId,
                dto.SobreescribirExistentes);

            if (!resultado.Exitoso)
            {
                return BadRequest(resultado);
            }

            return Ok(resultado);
        }
    }

    [HttpGet]
    public async Task<ActionResult<ValidacionFranquiciaDto>> ValidarAplicacion(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        [FromQuery] int franquiciaId)
    {
        logger.LogInformation("API: ValidarAplicacion for empresaId: {EmpresaId}, franquiciaId: {FranquiciaId}", empresaId, franquiciaId);

        {
            var validacion = await service.ValidarAplicacionAsync(empresaId, ano, franquiciaId);
            return Ok(validacion);
        }
    }

    [HttpGet]
    public async Task<ActionResult<List<CuentaPredefinidaDto>>> GetCuentasPredefinidas(int franquiciaId)
    {
        logger.LogInformation("API: GetCuentasPredefinidas for franquiciaId: {FranquiciaId}", franquiciaId);

        {
            var cuentas = await service.GetCuentasPredefinidasAsync(franquiciaId);
            return Ok(cuentas);
        }
    }
}
