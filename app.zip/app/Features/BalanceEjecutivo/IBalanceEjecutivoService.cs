﻿namespace App.Features.BalanceEjecutivo;

public interface IBalanceEjecutivoService
{
    Task<BalanceEjecutivoResultadoDto> GenerarBalanceAsync(BalanceEjecutivoFiltrosDto filtros);
    Task<byte[]> ExportarExcelAsync(BalanceEjecutivoFiltrosDto filtros);
    Task<bool> RegistrarLogImpresionAsync(int empresaId, short ano, DateTime fechaDesde, DateTime fechaHasta, string usuario);
}