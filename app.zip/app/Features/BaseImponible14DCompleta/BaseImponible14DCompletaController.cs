using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.BaseImponible14DCompleta;

/// <summary>
/// Controlador MVC para Base Imponible 14D Completa
/// </summary>
public class BaseImponible14DCompletaController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<BaseImponible14DCompletaController> logger) : Controller
{
    /// <summary>
    /// Vista principal de la base imponible 14D completa
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Index()
    {
        {
            logger.LogInformation("Accediendo a Base Imponible 14D Completa para empresa {EmpresaId} año {Ano}",
                SessionHelper.EmpresaId, SessionHelper.Ano);

            ViewData["EmpresaId"] = SessionHelper.EmpresaId;
            ViewData["Ano"] = SessionHelper.Ano;
            ViewData["Title"] = "Base Imponible Primera Categor�a R�gimen 14D";

            await Task.CompletedTask;
            return View();
        }
    }

    /// <summary>
    /// Vista de detalle para edici�n de valores manuales
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> EditarDetalle(int codigo, string descripcion)
    {
        {
            logger.LogInformation("Editando detalle c�digo {Codigo} para empresa {EmpresaId} año {Ano}",
                codigo, SessionHelper.EmpresaId, SessionHelper.Ano);

            ViewData["EmpresaId"] = SessionHelper.EmpresaId;
            ViewData["Ano"] = SessionHelper.Ano;
            ViewData["Codigo"] = codigo;
            ViewData["Descripcion"] = descripcion ?? string.Empty;

            await Task.CompletedTask;
            return View();
        }
    }

    /// <summary>
    /// Vista de impresi�n
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Print()
    {
        {
            logger.LogInformation("Vista de impresi�n para empresa {EmpresaId} año {Ano}",
                SessionHelper.EmpresaId, SessionHelper.Ano);

            ViewData["EmpresaId"] = SessionHelper.EmpresaId;
            ViewData["Ano"] = SessionHelper.Ano;

            await Task.CompletedTask;
            return View();
        }
    }

    /// <summary>
    /// Vista de asistente PPM (para año >= 2022)
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> AsistentePPM()
    {
        {
            if (SessionHelper.Ano < 2022)
            {
                TempData["Warning"] = "El asistente PPM est� disponible solo para años 2022 en adelante";
                return RedirectToAction("Index");
            }

            logger.LogInformation("Abriendo asistente PPM para empresa {EmpresaId} año {Ano}",
                SessionHelper.EmpresaId, SessionHelper.Ano);

            ViewData["EmpresaId"] = SessionHelper.EmpresaId;
            ViewData["Ano"] = SessionHelper.Ano;

            await Task.CompletedTask;
            return View();
        }
    }

    /// <summary>
    /// Proxy para obtener datos de base imponible
    /// GET /BaseImponible14DCompleta/GetData
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetData(int empresaId, short ano)
    {
        logger.LogInformation("BaseImponible14DCompleta: GetData proxy called");
        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(BaseImponible14DCompletaApiController.GetByEmpresaAno),
                controller: nameof(BaseImponible14DCompletaApiController).Replace("Controller", ""),
                values: new { empresaId, ano }
            );
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Proxy para obtener saldos vigentes
    /// GET /BaseImponible14DCompleta/GetSaldosVigentes
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetSaldosVigentes(int empresaId, short ano)
    {
        logger.LogInformation("BaseImponible14DCompleta: GetSaldosVigentes proxy called");
        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(BaseImponible14DCompletaApiController.GetWithNonZeroValues),
                controller: nameof(BaseImponible14DCompletaApiController).Replace("Controller", ""),
                values: new { empresaId, ano }
            );
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Proxy para actualizar item
    /// PUT /BaseImponible14DCompleta/UpdateItem
    /// </summary>
    [HttpPut]
    public async Task<IActionResult> UpdateItem([FromBody] JsonElement request)
    {
        logger.LogInformation("BaseImponible14DCompleta: UpdateItem proxy called");
        {
            var empresaId = request.GetProperty("empresaId").GetInt32();
            var ano = request.GetProperty("ano").GetInt32();
            var codigo = request.GetProperty("codigo").GetString();

            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(BaseImponible14DCompletaApiController.UpdateItemValue),
                controller: nameof(BaseImponible14DCompletaApiController).Replace("Controller", ""),
                values: new { empresaId, ano, codigo }
            );
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Put);
            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// Proxy para guardar toda la base imponible
    /// POST /BaseImponible14DCompleta/Save
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Save([FromBody] JsonElement request)
    {
        logger.LogInformation("BaseImponible14DCompleta: Save proxy called");
        {
            var empresaId = request.GetProperty("empresaId").GetInt32();
            var ano = request.GetProperty("ano").GetInt32();

            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(BaseImponible14DCompletaApiController.Save),
                controller: nameof(BaseImponible14DCompletaApiController).Replace("Controller", ""),
                values: new { empresaId, ano }
            );
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// Proxy para exportar a Excel
    /// GET /BaseImponible14DCompleta/ExportExcel
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ExportExcel(int empresaId, short ano)
    {
        logger.LogInformation("BaseImponible14DCompleta: ExportExcel proxy called");
        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(BaseImponible14DCompletaApiController.ExportToExcel),
                controller: nameof(BaseImponible14DCompletaApiController).Replace("Controller", ""),
                values: new { empresaId, ano }
            );
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }
}