using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.ConfiguracionActivoFijo;


public class ConfiguracionActivoFijoController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<ConfiguracionActivoFijoController> logger) : Controller
{
    /// <summary>
    /// Vista principal de configuraci�n de Activo Fijo
    /// </summary>
    public IActionResult Index()
    {
        ViewData["EmpresaId"] = SessionHelper.EmpresaId;
        ViewData["Ano"] = SessionHelper.Ano;
        return View();
    }

    /// <summary>
    /// Proxy: Obtener configuración de Activo Fijo
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetConfig(int empresaId, short ano)
    {
        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(ConfiguracionActivoFijoApiController.GetConfig),
                controller: nameof(ConfiguracionActivoFijoApiController).Replace("Controller", ""),
                values: new { empresaId, ano });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Proxy: Guardar configuración de Activo Fijo
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> SaveConfig([FromBody] JsonElement request)
    {
        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(ConfiguracionActivoFijoApiController.SaveConfig),
                controller: nameof(ConfiguracionActivoFijoApiController).Replace("Controller", ""));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }
}
