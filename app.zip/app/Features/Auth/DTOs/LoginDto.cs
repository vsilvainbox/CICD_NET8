using System.ComponentModel.DataAnnotations;

namespace App.Features.Auth.DTOs;

public class LoginDto
{
    [Required(ErrorMessage = "El usuario es obligatorio")]
    [StringLength(15, ErrorMessage = "El usuario no puede tener más de 15 caracteres")]
    public string Username { get; set; } = string.Empty;

    [Required(ErrorMessage = "La contraseña es obligatoria")]
    public string Password { get; set; } = string.Empty;

    public bool RememberMe { get; set; }
}
