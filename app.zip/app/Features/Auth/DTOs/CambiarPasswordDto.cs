using System.ComponentModel.DataAnnotations;

namespace App.Features.Auth.DTOs;

public class CambiarPasswordDto
{
    [Required(ErrorMessage = "La contraseña actual es obligatoria")]
    public string PasswordActual { get; set; } = string.Empty;

    [Required(ErrorMessage = "La nueva contraseña es obligatoria")]
    [StringLength(50, MinimumLength = 4, ErrorMessage = "La contraseña debe tener entre 4 y 50 caracteres")]
    public string PasswordNueva { get; set; } = string.Empty;

    [Required(ErrorMessage = "Debe confirmar la nueva contraseña")]
    [Compare("PasswordNueva", ErrorMessage = "Las contraseñas no coinciden")]
    public string PasswordConfirmacion { get; set; } = string.Empty;
}
