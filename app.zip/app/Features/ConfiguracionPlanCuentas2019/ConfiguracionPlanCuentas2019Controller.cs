﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Text.Json;
using App.Extensions;

namespace App.Features.ConfiguracionPlanCuentas2019;

[Authorize]

public class ConfiguracionPlanCuentas2019Controller(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<ConfiguracionPlanCuentas2019Controller> logger) : Controller
{
    [HttpGet]
    public IActionResult Index()
    {
        logger.LogInformation("MVC: ConfiguracionPlanCuentas2019 Index view requested");
        return View();
    }

    [HttpGet]
    public async Task<IActionResult> VistaPrevia()
    {
        logger.LogInformation("Proxy: VistaPrevia llamado");
        var client = httpClientFactory.CreateClient("ApiClient");

        var url = linkGenerator.GetPathByAction(
            action: nameof(ConfiguracionPlanCuentas2019ApiController.ObtenerVistaPrevia),
            controller: nameof(ConfiguracionPlanCuentas2019ApiController).Replace("Controller", "")
        );

        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    [HttpGet]
    public async Task<IActionResult> Validar(int empresaId, short ano)
    {
        logger.LogInformation("Proxy: Validar llamado con empresaId={EmpresaId}, ano={Ano}", empresaId, ano);
        var client = httpClientFactory.CreateClient("ApiClient");

        var url = linkGenerator.GetPathByAction(
            action: nameof(ConfiguracionPlanCuentas2019ApiController.ValidarPrerequisitos),
            controller: nameof(ConfiguracionPlanCuentas2019ApiController).Replace("Controller", ""),
            values: new { empresaId, ano }
        );

        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    [HttpPost]
    public async Task<IActionResult> Aplicar([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: Aplicar llamado");
        var client = httpClientFactory.CreateClient("ApiClient");

        var url = linkGenerator.GetPathByAction(
            action: nameof(ConfiguracionPlanCuentas2019ApiController.AplicarPlan),
            controller: nameof(ConfiguracionPlanCuentas2019ApiController).Replace("Controller", "")
        );

        var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }
}
