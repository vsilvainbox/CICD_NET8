using System.ComponentModel.DataAnnotations;

namespace App.Features.ConfiguracionInformes;

/// <summary>
/// DTO para nota en informes
/// </summary>
public class NotaDto
{
    public string? Tipo { get; set; }
    public int? IdEmpresa { get; set; }

    [MaxLength(250)]
    public string? Nota { get; set; }

    public short? Incluir { get; set; }
    public bool? IncluirInfo { get; set; }

    public bool IncluirBalances { get; set; }
    public bool IncluirLibros { get; set; }
    public bool IncluirOtrosInformes { get; set; }
}

/// <summary>
/// DTO para color por nivel
/// </summary>
public class ColorNivelDto
{
    public short Nivel { get; set; }
    public int IdEmpresa { get; set; }
    public int? Color { get; set; }
    public string? ColorHex { get; set; }
}

/// <summary>
/// DTO para membrete/pie de firma
/// </summary>
public class MembreteDto
{
    public string? TituloMembrete1 { get; set; }
    public string? TituloMembrete2 { get; set; }
    public string? Texto1 { get; set; }
    public string? Texto2 { get; set; }
    public decimal? IdEmpresa { get; set; }
}

/// <summary>
/// DTO para opción configurable
/// </summary>
public class OpcionDto
{
    public long Valor { get; set; }
    public string Descripcion { get; set; } = string.Empty;
    public bool Seleccionada { get; set; }
}

/// <summary>
/// Request completo de configuración
/// </summary>
public class ConfiguracionInformesRequest
{
    [Required]
    public int EmpresaId { get; set; }

    [Required]
    public short Ano { get; set; }

    // Notas
    public NotaDto? NotaArticulo100 { get; set; }
    public NotaDto? NotaEspecial { get; set; }

    // Colores
    public List<ColorNivelDto> Colores { get; set; } = new List<ColorNivelDto>();

    // Opciones
    public int? OpcionesBitmask { get; set; }

    // Registros por página
    public short? RegistrosPorPagina { get; set; }

    // Documentos ODF
    public string? IncluirOdfEnAnalitico { get; set; }
    public string? EstadoOdf { get; set; }

    // Membrete
    public MembreteDto? Membrete { get; set; }

    // Fecha comparativo
    public string? ActivarFechaComparativo { get; set; }
}

/// <summary>
/// Response con configuración actual
/// </summary>
public class ConfiguracionInformesResponse
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;

    // Notas
    public NotaDto? NotaArticulo100 { get; set; }
    public NotaDto? NotaEspecial { get; set; }

    // Colores
    public List<ColorNivelDto> Colores { get; set; } = new List<ColorNivelDto>();

    // Opciones disponibles
    public List<OpcionDto> OpcionesDisponibles { get; set; } = new List<OpcionDto>();
    public int? OpcionesBitmask { get; set; }

    // Registros por página
    public short? RegistrosPorPagina { get; set; }

    // Documentos ODF
    public string? IncluirOdfEnAnalitico { get; set; }
    public string? EstadoOdf { get; set; }
    public List<EstadoDocumentoDto> EstadosDocumento { get; set; } = new List<EstadoDocumentoDto>();

    // Membrete
    public MembreteDto? Membrete { get; set; }

    // Fecha comparativo
    public string? ActivarFechaComparativo { get; set; }
}

/// <summary>
/// DTO para estado de documento
/// </summary>
public class EstadoDocumentoDto
{
    public int Id { get; set; }
    public string Nombre { get; set; } = string.Empty;
}

/// <summary>
/// Request para obtener configuración
/// </summary>
public class GetConfiguracionInformesRequest
{
    [Required]
    public int EmpresaId { get; set; }

    [Required]
    public short Ano { get; set; }
}