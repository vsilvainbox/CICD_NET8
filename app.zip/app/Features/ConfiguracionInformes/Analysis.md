# Análisis: Configuración Informes

## 📋 Resumen
Formulario de configuración para personalizar la presentación y comportamiento de informes, balances y libros contables.

## 🎯 Funcionalidad VB6 Original

### FrmConfigInformes.frm
**Propósito:** Configuración general de informes y reportes del sistema

**Características principales:**

1. **Notas (Artículo 100 y Nota Especial):**
   - Texto de nota artículo 100 (hasta 250 caracteres)
   - Texto de nota especial (hasta 250 caracteres)
   - Checkboxes para incluir en:
     - Balances
     - Libros
     - Otros informes

2. **Colores por Nivel:**
   - Configurar color para cada nivel del plan de cuentas (Nivel 1-5)
   - Selector de color visual
   - Los colores se aplican en reportes y balances

3. **Opciones Generales:**
   - Actualizar automáticamente folios usados en impresión con papel foliado
   - No imprimir fecha en reportes oficiales o no oficiales
   - Lista de checkboxes con opciones bit-flag

4. **Registros por Página:**
   - Cantidad de registros por página (100-1000)
   - Solo para SQL Server (no Access)

5. **Documentos ODF:**
   - Checkbox: Incluir en Informe Analítico
   - Combo: Estado del documento
   - Configuración específica para documentos ODF

6. **Pie de Firma para Comprobantes:**
   - Título Membrete 1 + Texto 1
   - Título Membrete 2 + Texto 2
   - Validación: Si hay título debe haber texto

7. **Fechas Comparativo Periodo Anterior:**
   - Checkbox: Activar fechas periodo anterior
   - Para informes comparativos

## 📊 Tablas Involucradas

### Principales
- `Notas`: Notas para informes
  - IdNota, IdEmpresa, Tipo ('ART100', 'NOTAESP')
  - Nota (texto), Incluir (bitmask), IncluirInfo

- `Colores`: Colores por nivel
  - IdColor, IdEmpresa, Nivel (1-5), Color (long RGB)

- `Empresa`: Opciones generales
  - Id, Opciones (bitmask con flags)

- `ParamEmpresa`: Parámetros configurables
  - Tipo: 'INFANAODF', 'ESTADOODF', 'FECHACOMPA'
  - Codigo, Valor

- `Membrete`: Pie de firma comprobantes
  - IdMembrete, IdEmpresa
  - TituloMembrete1, TituloMembrete2
  - Texto1, Texto2

## 🔄 Flujo de Usuario

1. Abre formulario desde menú de configuración
2. Visualiza configuraciones actuales (Load):
   - Notas: Lee de tabla Notas
   - Colores: Lee de tabla Colores
   - Opciones: Lee bitmask de Empresa.Opciones
   - Parámetros ODF: Lee de ParamEmpresa
   - Membrete: Lee de tabla Membrete
   - Fecha comparativo: Lee de ParamEmpresa
3. Modifica valores según necesidad
4. Presiona "Aceptar":
   - Guarda notas (SaveNotas)
   - Guarda colores (SaveColores)
   - Guarda opciones (SaveOpciones)
   - Guarda parámetros ODF (SaveParametrosODF)
   - Guarda membrete (SaveMembrete)
   - Guarda fecha comparativo (SaveFechaComparativo)
   - Actualiza variables globales
5. Cierra formulario

## 🎨 Interfaz de Usuario

### Sección 1: Notas
- **Nota artículo 100:**
  - TextArea multilinea (250 chars)
  - Checkboxes: Incluir en Balances, Incluir en Libros, Incluir en otros Informes

- **Nota especial:**
  - TextArea multilinea (250 chars)
  - Checkboxes: Incluir en Balances, Incluir en Libros, Incluir en otros Informes

### Sección 2: Colores por Nivel
- 5 botones de color (uno por nivel)
- Al hacer click: Abre ColorDialog
- Muestra label con color seleccionado

### Sección 3: Opciones
- ListBox con checkboxes
- OPT_ACTUSADO: Actualizar automáticamente folios
- OPT_NOPRTFECHA: No imprimir fecha en reportes

### Sección 4: Registros por Página
- TextBox numérico (100-1000)
- Visible solo para SQL Server

### Sección 5: Documentos ODF
- Checkbox: Incluir en Informe Analítico
- ComboBox: Estado (lista de estados de documento)

### Sección 6: Pie de Firma
- 4 TextBoxes:
  - Título Membrete 1, Texto 1
  - Título Membrete 2, Texto 2

### Sección 7: Fechas Comparativo
- Checkbox: Activar fechas periodo anterior

### Botones
- **Aceptar**: Guarda todas las configuraciones
- **Cancelar**: Cierra sin guardar

## 🔌 Lógica de Negocio

1. **Notas:**
   - Bitmask para Incluir: 
     - C_INCNOTALIB = incluir en libros
     - C_INCNOTABAL = incluir en balances
   - IncluirInfo: Boolean independiente

2. **Colores:**
   - Se almacenan como Long (RGB)
   - Se crean registros si no existen

3. **Opciones:**
   - Bitmask en campo Empresa.Opciones
   - Se combinan con OR bit a bit

4. **Parámetros:**
   - Se crean con valores por defecto si no existen
   - INSERT o UPDATE según existencia

5. **Validaciones:**
   - Registros por página: 100-1000
   - Membrete: Si hay título debe haber texto

## 📝 Constantes

```vb
MAX_NIVELES = 5
C_INCNOTALIB = valor bitmask para incluir en libros
C_INCNOTABAL = valor bitmask para incluir en balances
OPT_ACTUSADO = opción actualizar folios
OPT_NOPRTFECHA = opción no imprimir fecha
MAX_ESTADODOC = cantidad de estados
```

## 🚀 Prioridad
**MEDIA** - Configuración de presentación e informes, importante para personalización
