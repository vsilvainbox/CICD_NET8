﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.ConfiguracionInformes;

/// <summary>
/// MVC Controller para configuraci�n de informes
/// </summary>
public class ConfiguracionInformesController(
    IHttpClientFactory httpClientFactory,
    ILogger<ConfiguracionInformesController> logger, LinkGenerator linkGenerator) : Controller
{
    /// <summary>
    /// Vista principal de configuraci�n de informes
    /// </summary>
    public IActionResult Index()
    {
        logger.LogInformation("Accediendo a configuraci�n de informes. EmpresaId: {EmpresaId}, año: {Ano}",
            SessionHelper.EmpresaId, SessionHelper.Ano);

        ViewData["EmpresaId"] = SessionHelper.EmpresaId;
        ViewData["Ano"] = SessionHelper.Ano;

        return View();
    }

    /// <summary>
    /// Proxy: Obtener configuración de informes
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetConfiguracion(int empresaId, short ano)
    {
        var client = httpClientFactory.CreateClient("ApiClient");
        var url = linkGenerator.GetPathByAction(
            action: nameof(ConfiguracionInformesApiController.GetConfiguracion),
            controller: nameof(ConfiguracionInformesApiController).Replace("Controller", ""),
            values: new { empresaId, ano });

        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Proxy: Guardar configuración de informes
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Guardar([FromBody] JsonElement request)
    {
        var client = httpClientFactory.CreateClient("ApiClient");
        var url = linkGenerator.GetPathByAction(
            action: nameof(ConfiguracionInformesApiController.GuardarConfiguracion),
            controller: nameof(ConfiguracionInformesApiController).Replace("Controller", ""));

        var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
        return new ContentResult
        {
            Content = content,
            ContentType = "application/json",
            StatusCode = statusCode
        };
    }
}