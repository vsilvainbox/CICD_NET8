namespace App.Features.CapitalAportado;

public class CapitalAportadoDto
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public List<SocioCapitalDto> Socios { get; set; } = new();
    public decimal TotalMontoATraspasar { get; set; }
}

public class SocioCapitalDto
{
    public int IdSocio { get; set; }
    public string? Rut { get; set; }
    public string? Nombre { get; set; }
    public decimal MontoPagado { get; set; }
    public decimal MontoIngresadoUsuario { get; set; }
    public decimal MontoATraspasar { get; set; }
}

public class UpdateSocioCapitalDto
{
    public int IdSocio { get; set; }
    public decimal MontoIngresadoUsuario { get; set; }
    public decimal MontoATraspasar { get; set; }
}

public class SaveCapitalAportadoRequestDto
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public List<UpdateSocioCapitalDto> Socios { get; set; } = new();
}
