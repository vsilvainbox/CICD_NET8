using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.CapitalSimpleAcumulado;

public class CapitalSimpleAcumuladoController(
    ILogger<CapitalSimpleAcumuladoController> logger,
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator) : Controller
{
    public IActionResult Index(int tipoDetCPS = 1)
    {
        logger.LogInformation("Cargando vista Capital Simple Acumulado");

        ViewData["EmpresaId"] = SessionHelper.EmpresaId;
        ViewData["Ano"] = SessionHelper.Ano;
        ViewData["TipoDetCPS"] = tipoDetCPS;

        return View();
    }

    [HttpGet]
    public async Task<IActionResult> Obtener(int empresaId, int anoActual, int tipoDetCPS)
    {
        logger.LogInformation("Proxy: Obtener datos para empresaId: {EmpresaId}, año: {Ano}, tipo: {Tipo}",
            empresaId, anoActual, tipoDetCPS);

        var client = httpClientFactory.CreateClient("ApiClient");
        var url = linkGenerator.GetPathByAction(
            action: nameof(CapitalSimpleAcumuladoApiController.Obtener),
            controller: nameof(CapitalSimpleAcumuladoApiController).Replace("Controller", ""),
            values: new { empresaId, anoActual, tipoDetCPS });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    [HttpPost]
    public async Task<IActionResult> Guardar([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: Guardar datos de Capital Simple Acumulado");

        var client = httpClientFactory.CreateClient("ApiClient");
        var url = linkGenerator.GetPathByAction(
            action: nameof(CapitalSimpleAcumuladoApiController.Guardar),
            controller: nameof(CapitalSimpleAcumuladoApiController).Replace("Controller", ""));
        var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }
}