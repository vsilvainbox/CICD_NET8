# Legacy Analysis: Auditoría Cuentas Definidas

## 📄 Información del Formulario VB6

**Archivo VB6:** `old/Contabilidad70/Administrador/FrmRepAudCuentasDefinidas.frm`
**Fecha Análisis:** 2025-10-02
**Analista:** IA
**Complejidad:** Media

### Propósito del Formulario
Reporte de auditoría que muestra el historial de cambios realizados en la configuración de cuentas definidas del sistema contable. Permite filtrar por rango de fechas, empresa, año y usuario para revisar qué configuraciones fueron modificadas, cuándo y por quién.

Este es un formulario de consulta y reporte (solo lectura) con capacidad de exportación e impresión.

---

## 🎨 CONTROLES UI IDENTIFICADOS

### Frame de Filtros (Frame3)
| Control VB6 | Propiedad Bound | Tipo | Validación | Propósito |
|-------------|----------------|------|------------|-----------|
| Tx_FechaOper(0) | N/A | Date TextBox | Optional, formato fecha | Fecha desde para filtrar |
| Tx_FechaOper(1) | N/A | Date TextBox | Optional, formato fecha | Fecha hasta para filtrar |
| Bt_FechaOper(0) | N/A | Button | N/A | Selector de calendario para fecha desde |
| Bt_FechaOper(1) | N/A | Button | N/A | Selector de calendario para fecha hasta |
| Cb_Empresa | Empresas | ComboBox | Optional | Filtrar por empresa específica |
| Cb_Annio | Auditoria_Empresas.Annio | ComboBox | Optional | Filtrar por año |
| Cb_Usuario | Usuarios | ComboBox | Optional | Filtrar por usuario que realizó cambios |
| Bt_Search | N/A | Button | N/A | Ejecutar búsqueda con filtros |

**Opciones de ComboBox:**
- **Cb_Empresa**: "(todos)" + lista de empresas ordenadas por NombreCorto
- **Cb_Annio**: "(todos)" + años únicos de Auditoria_Empresas ordenados
- **Cb_Usuario**: "(todos)" + lista de usuarios ordenados por Usuario

### Frame de Acciones (Frame1)
| Botón VB6 | Caption | Habilitado Si | Acción | Mapeo .NET |
|-----------|---------|---------------|--------|------------|
| Bt_Preview | (Icono) | Siempre | Vista previa impresión | ExportToPdfAsync() con vista previa |
| Bt_Print | (Icono) | Grid con datos | Imprimir reporte | ExportToPdfAsync() con impresión |
| Bt_CopyExcel | (Icono) | Siempre | Copiar a Excel | ExportToExcelAsync() |
| bt_Cerrar | "Cerrar" | Siempre | Cerrar formulario | N/A (navegación web) |

### Grilla Principal (Grid - MSFlexGrid)
| Control VB6 | Tipo | Propósito | Configuración |
|-------------|------|-----------|---------------|
| Grid | MSFlexGrid | Mostrar resultados de auditoría | 9 columnas, redimensionable, orientación landscape |

**Columnas de la grilla:**
1. **IdEmp** (oculto, ancho: 0) - ID de la empresa
2. **Rut** (ancho: 1200) - RUT de la empresa formateado
3. **Configuración** (ancho: 2000) - Tipo de configuración modificada
4. **Evento** (ancho: 800) - Tipo de evento (crear, modificar, eliminar)
5. **Cta. Asociada** (ancho: 5000) - Cuenta contable asociada
6. **Codigo** (ancho: 1000) - Código de la cuenta/configuración
7. **Descripción** (ancho: 2000) - Descripción de la cuenta/configuración
8. **Fecha** (ancho: 1800) - Fecha y hora del evento (formato: dd/mm/yyyy hh:nn)
9. **Usuario** (ancho: 1300) - Usuario que realizó el cambio

---

## 🔘 EVENTOS IDENTIFICADOS

### Eventos de Formulario
| Evento VB6 | Cuándo Ocurre | Acciones | Mapeo .NET |
|------------|---------------|----------|------------|
| Form_Load | Al abrir form | FillEmpresa(), FillAnnio(), FillUsuario(), SetUpGrid(), LoadAll() | Inicialización en controller + carga inicial de datos |
| Form_Resize | Al redimensionar | Ajustar tamaño de Grid y controles | N/A (responsive CSS) |

### Eventos de Botones
| Control.Evento | Trigger | Acción VB6 | Mapeo .NET |
|----------------|---------|------------|------------|
| Bt_Search_Click | Click buscar | Valida() + LoadAll() | GetFilteredAsync() en API |
| Bt_FechaOper_Click(Index) | Click calendario | Abrir selector de fecha | Input type="date" HTML5 |
| Bt_Preview_Click | Click vista previa | SetUpPrtGrid() + PrtFlexGrid(Frm) | ExportToPdfAsync() |
| Bt_Print_Click | Click imprimir | SetUpPrtGrid() + PrtFlexGrid(Printer) | ExportToPdfAsync() |
| Bt_CopyExcel_Click | Click copiar Excel | FGr2Clip(Grid, Caption) | ExportToExcelAsync() |
| bt_Cerrar_Click | Click cerrar | Unload Me | window.history.back() |

### Eventos de Controles
| Control.Evento | Trigger | Acción VB6 | Mapeo .NET |
|----------------|---------|------------|------------|
| Tx_FechaOper_Change(Index) | Cambio de fecha | Validar que fecha hasta >= fecha desde | Validación JavaScript |
| Tx_FechaOper_GotFocus(Index) | Focus en campo | Seleccionar todo el texto | HTML5 input behavior |
| Tx_FechaOper_KeyPress(Index) | Tecla presionada | Validar entrada de fecha | HTML5 input type="date" |
| Tx_FechaOper_LostFocus(Index) | Pierde focus | Validar formato de fecha | HTML5 input validation |

---

## 🔧 FUNCIONES Y PROCEDIMIENTOS VB6

### Funciones Privadas

```vb
' Función: LoadAll
' Propósito: Cargar datos de auditoría según filtros aplicados
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: GetFilteredAsync() en Service
Private Sub LoadAll()
    ' Query con JOINs a Empresas y Usuarios
    ' Filtrado dinámico según valores de combos y fechas
    ' Ordenado por fecha
    ' Cargar en Grid
End Sub
```

```vb
' Función: SetUpGrid
' Propósito: Configurar columnas, anchos y encabezados de la grilla
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: Configuración en vista HTML
Private Sub SetUpGrid()
    ' 9 columnas
    ' Configurar anchos
    ' Configurar encabezados
End Sub
```

```vb
' Función: SetUpPrtGrid
' Propósito: Preparar configuración para impresión (landscape)
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: Configuración de exportación PDF
Private Sub SetUpPrtGrid()
    ' Orientación: Landscape
    ' Título: "REPORTE AUDITORÍA CUENTAS DEFINIDAS"
    ' Configurar anchos para impresión
End Sub
```

```vb
' Función: FillEmpresa
' Propósito: Llenar combo de empresas
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: GetAllEmpresasAsync() en Service
Private Sub FillEmpresa()
    ' Agregar opción "(todos)" con valor -1
    ' Query: SELECT NombreCorto, idEmpresa FROM Empresas ORDER BY NombreCorto ASC
End Sub
```

```vb
' Función: FillAnnio
' Propósito: Llenar combo de años desde tabla de auditoría
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: GetDistinctYearsAsync() en Service
Private Sub FillAnnio()
    ' Agregar opción "(todos)" con valor -1
    ' Query: SELECT Annio FROM Auditoria_Empresas GROUP BY Annio ORDER BY Annio ASC
End Sub
```

```vb
' Función: FillUsuario
' Propósito: Llenar combo de usuarios
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: GetAllUsuariosAsync() en Service
Private Sub FillUsuario()
    ' Agregar opción "(todos)" con valor -1
    ' Query: SELECT Usuario, IdUsuario FROM Usuarios ORDER BY Usuario ASC
End Sub
```

```vb
' Función: Valida
' Propósito: Validar fechas antes de ejecutar búsqueda
' Parámetros: Ninguno
' Retorno: Boolean (True si válido)
' Validaciones:
'   - Ambas fechas presentes o ambas vacías
'   - Fecha desde <= Fecha hasta
'   - Año de fecha debe ser el año actual de la empresa (no años anteriores)
' Mapeo .NET: ValidateFiltersAsync() en Service
Private Function Valida() As Boolean
    ' Validar rango de fechas
    ' Validar que año sea el actual (restricción de negocio)
End Function
```

```vb
' Función: CreateWhere
' Propósito: Construir cláusula WHERE dinámica según filtros
' Parámetros: Ninguno
' Retorno: String (cláusula WHERE completa)
' Mapeo .NET: Query con Where dinámico en EF Core
Private Function CreateWhere() As String
    ' Si hay fechas: CONVERT(date, fecha, 105) BETWEEN ...
    ' Si hay año: AND ano = [año]
    ' Si hay empresa: AND a.idEmpresa = [id]
    ' Si hay usuario: AND u.IdUsuario = [id]
End Function
```

```vb
' Función: EnableFrm
' Propósito: Habilitar/deshabilitar botón de búsqueda
' Parámetros: bool As Boolean
' Retorno: Void
' Mapeo .NET: No necesario (siempre habilitado en web)
Private Sub EnableFrm(bool As Boolean)
    Bt_Search.Enabled = bool
End Sub
```

---

## 💾 ACCESO A DATOS VB6

### Query Principal: Cargar Auditoría de Cuentas Definidas

```vb
Q1 = "SELECT a.idEmpresa, e.Rut, a.Configuracion, a.evento, a.cta_asociado, a.codigo, a.descripcion, a.fecha, u.usuario "
Q1 = Q1 & " FROM Auditoria_Cuentas_Definidas a"
Q1 = Q1 & " INNER JOIN Empresas e ON e.idEmpresa=a.idEmpresa"
Q1 = Q1 & " INNER JOIN Usuarios u ON u.idUsuario=a.idUsuario"
Q1 = Q1 & Wh  ' WHERE dinámico
Q1 = Q1 & " ORDER BY a.fecha "
```

**Mapeo Entity Framework:**
```csharp
var query = _context.Auditoria_Cuentas_Definidas
    .Join(_context.Empresas,
        a => a.idEmpresa,
        e => e.IdEmpresa,
        (a, e) => new { a, e })
    .Join(_context.Usuarios,
        ae => ae.a.idUsuario,
        u => u.IdUsuario,
        (ae, u) => new { ae.a, ae.e, u });

// Aplicar filtros dinámicos
if (fechaDesde.HasValue && fechaHasta.HasValue)
{
    query = query.Where(x => 
        EF.Functions.DateFromParts(
            Convert.ToInt32(x.a.fecha.Substring(6, 4)), 
            Convert.ToInt32(x.a.fecha.Substring(3, 2)), 
            Convert.ToInt32(x.a.fecha.Substring(0, 2))
        ) >= fechaDesde.Value 
        && 
        EF.Functions.DateFromParts(...) <= fechaHasta.Value
    );
}

if (ano.HasValue)
    query = query.Where(x => x.a.ano == ano.Value);

if (idEmpresa.HasValue)
    query = query.Where(x => x.a.idEmpresa == idEmpresa.Value);

if (idUsuario.HasValue)
    query = query.Where(x => x.a.idUsuario == idUsuario.Value);

var result = await query
    .OrderBy(x => x.a.fecha)
    .Select(x => new AuditoriaCuentasDefinidasDto
    {
        IdEmpresa = x.a.idEmpresa,
        Rut = x.e.Rut,
        Configuracion = x.a.configuracion,
        Evento = x.a.evento,
        CtaAsociado = x.a.cta_asociado,
        Codigo = x.a.codigo,
        Descripcion = x.a.descripcion,
        Fecha = x.a.fecha,
        Usuario = x.u.Usuario
    })
    .ToListAsync();
```

### Query 2: Llenar Combo Empresas
```vb
Q1 = "SELECT NombreCorto, idEmpresa FROM Empresas ORDER BY NombreCorto ASC"
```

**Mapeo Entity Framework:**
```csharp
await _context.Empresas
    .OrderBy(e => e.NombreCorto)
    .Select(e => new ComboItemDto
    {
        Value = e.IdEmpresa,
        Text = e.NombreCorto
    })
    .ToListAsync();
```

### Query 3: Llenar Combo Años
```vb
Q1 = "SELECT Annio FROM Auditoria_Empresas GROUP BY Annio ORDER BY Annio ASC"
```

**Mapeo Entity Framework:**
```csharp
// Nota: Usar tabla Auditoria_Empresas
await _context.Auditoria_Empresas
    .Select(ae => ae.Annio)
    .Distinct()
    .OrderBy(y => y)
    .ToListAsync();
```

### Query 4: Llenar Combo Usuarios
```vb
Q1 = "SELECT Usuario, IdUsuario FROM Usuarios ORDER BY Usuario ASC"
```

**Mapeo Entity Framework:**
```csharp
await _context.Usuarios
    .OrderBy(u => u.Usuario)
    .Select(u => new ComboItemDto
    {
        Value = u.IdUsuario,
        Text = u.Usuario
    })
    .ToListAsync();
```

---

## ✅ VALIDACIONES Y REGLAS DE NEGOCIO

### Validaciones de Filtros
| Campo | Regla | Mensaje Error VB6 | Implementar en .NET |
|-------|-------|-------------------|---------------------|
| Fechas | Ambas presentes o ambas vacías | "Rango de fechas de operación inválido." | Validación JavaScript + Backend |
| Fechas | Fecha desde <= Fecha hasta | "Rango de fechas de operación inválido." | Comparación de fechas |
| Fecha Año | Debe ser año actual de empresa | "Solo es posible visualizar año actual." | Validación contra gEmpresa.Ano |
| Grid vacío | Al imprimir sin datos | (Sale silenciosamente) | Validación antes de exportar |

### Reglas de Negocio
1. **Filtros opcionales**: Todos los filtros son opcionales, permitiendo ver todo el historial
2. **Opción "(todos)"**: Valor -1 en combos significa "sin filtro"
3. **Año actual únicamente**: Restricción para solo ver auditoría del año activo de la empresa
4. **Sin datos**: Mostrar mensaje "No existe información para mostrar." si no hay resultados
5. **Solo lectura**: Formulario de consulta, no permite modificaciones
6. **Orientación landscape**: Impresión siempre en horizontal debido al ancho de columnas

---

## 🧮 CÁLCULOS Y FÓRMULAS

### Cálculo 1: Formateo de RUT
```vb
Grid.TextMatrix(Row, C_RUT) = FmtCID(vFld(Rs("Rut")))
```
**→ Implementar:** Helper method para formatear RUT chileno (XX.XXX.XXX-X)

### Cálculo 2: Formateo de Fecha
```vb
Grid.TextMatrix(Row, C_FECHA_EVENTO) = Format(vFld(Rs("fecha")), "dd/mm/yyyy hh:nn")
```
**→ Implementar:** Formateo de string de fecha desde formato almacenado

### Cálculo 3: Ajuste de Fecha Hasta
```vb
If Index = 0 And GetTxDate(Tx_FechaOper(1)) < GetTxDate(Tx_FechaOper(0)) Then
    F1 = DateAdd("m", 1, GetTxDate(Tx_FechaOper(0)))
    Call SetTxDate(Tx_FechaOper(1), F1)
End If
```
**→ Implementar:** JavaScript para auto-ajustar fecha hasta si es menor que fecha desde (sumar 1 mes)

---

## 🚀 NAVEGACIÓN Y FLUJO

### Flujo de Uso
```
[Inicio] → Form_Load() → Cargar combos + SetUpGrid() + LoadAll() → [Mostrar datos]
  ↓
[Usuario ajusta filtros] → Bt_Search_Click() → Valida() → LoadAll() → [Actualizar Grid]
  ↓
[Usuario exporta] → Bt_CopyExcel_Click() / Bt_Print_Click() / Bt_Preview_Click()
  ↓
[Usuario cierra] → bt_Cerrar_Click() → Unload Me
```

### Formularios Relacionados
| Desde VB6 | Formulario Destino | Parámetros | Retorno | Mapeo .NET |
|-----------|-------------------|------------|---------|------------|
| Bt_FechaOper_Click | FrmCalendar | Fecha actual | Fecha seleccionada | HTML5 input type="date" |
| Bt_Preview_Click | FrmPrintPreview | Grid data | N/A | Generar PDF |

---

## 📊 EXPORTACIONES

### Exportación a Impresión
```vb
' Orientación: Landscape (cdlLandscape)
' Título: "REPORTE AUDITORÍA CUENTAS DEFINIDAS"
' Font: Grid.FontName, Grid.FontSize
' Método: gPrtReportes.PrtFlexGrid(Printer)
```
**→ Implementar:** `ExportToPdfAsync()` con orientación landscape

### Exportación a Excel
```vb
' Método: FGr2Clip(Grid, Caption)
' Copia grilla al clipboard
```
**→ Implementar:** `ExportToExcelAsync()` usando EPPlus

---

## 🎯 MAPEO FINAL: MÉTODOS .NET DETERMINADOS

### Interface del Service
```csharp
public interface IAuditoriaCuentasDefinidasService
{
    // Consulta principal con filtros
    Task<IEnumerable<AuditoriaCuentasDefinidasDto>> GetFilteredAsync(
        int? empresaId = null,
        int? ano = null,
        int? idUsuario = null,
        DateTime? fechaDesde = null,
        DateTime? fechaHasta = null);

    // Datos para combos
    Task<IEnumerable<ComboItemDto>> GetEmpresasAsync();
    Task<IEnumerable<int>> GetDistinctYearsAsync();
    Task<IEnumerable<ComboItemDto>> GetUsuariosAsync();

    // Validaciones
    Task<ValidationResult> ValidateFiltersAsync(
        DateTime? fechaDesde,
        DateTime? fechaHasta,
        int? ano,
        int anoEmpresaActual);

    // Helpers
    string FormatRut(string rut);
    DateTime? ParseFechaFromString(string fecha);

    // Exportaciones
    Task<byte[]> ExportToExcelAsync(
        int? empresaId = null,
        int? ano = null,
        int? idUsuario = null,
        DateTime? fechaDesde = null,
        DateTime? fechaHasta = null);

    Task<byte[]> ExportToPdfAsync(
        int? empresaId = null,
        int? ano = null,
        int? idUsuario = null,
        DateTime? fechaDesde = null,
        DateTime? fechaHasta = null);
}
```

### DTOs Necesarios
```csharp
public class AuditoriaCuentasDefinidasDto
{
    public int? IdEmpresa { get; set; }
    public string Rut { get; set; }
    public string Configuracion { get; set; }
    public string Evento { get; set; }
    public string CtaAsociado { get; set; }
    public string Codigo { get; set; }
    public string Descripcion { get; set; }
    public string Fecha { get; set; }
    public string Usuario { get; set; }
}

public class ComboItemDto
{
    public int Value { get; set; }
    public string Text { get; set; }
}

public class ValidationResult
{
    public bool IsValid { get; set; }
    public string ErrorMessage { get; set; }
}
```

### Resumen de Mapeo
| Funcionalidad VB6 | Método .NET | Complejidad | Prioridad |
|-------------------|-------------|-------------|-----------|
| LoadAll() | GetFilteredAsync() | Media | Alta |
| FillEmpresa() | GetEmpresasAsync() | Baja | Alta |
| FillAnnio() | GetDistinctYearsAsync() | Baja | Alta |
| FillUsuario() | GetUsuariosAsync() | Baja | Alta |
| Valida() | ValidateFiltersAsync() | Baja | Alta |
| CreateWhere() | EF Core Where dinámico | Media | Alta |
| FmtCID() | FormatRut() | Baja | Media |
| SetUpGrid() | Configuración HTML/JavaScript | Baja | Alta |
| Bt_Preview | ExportToPdfAsync() | Alta | Media |
| Bt_Print | ExportToPdfAsync() | Alta | Media |
| Bt_CopyExcel | ExportToExcelAsync() | Alta | Media |

---

## ⚠️ NOTAS IMPORTANTES Y OBSERVACIONES

### Peculiaridades del Form VB6
- **Campo fecha como string**: La tabla almacena fecha como string, no como datetime
- **Conversión de fecha**: VB6 usa `CONVERT(date, fecha, 105)` para comparar fechas
- **Restricción de año**: Solo permite ver auditoría del año actual de la empresa
- **Orientación landscape**: Impresión siempre horizontal por ancho de columnas
- **RUT formateado**: Usa función FmtCID para formatear RUT chileno
- **Opción "(todos)"**: Valor -1 para indicar "sin filtro" en combos

### Decisiones de Diseño
- **HTML5 date input**: Sustituir selector de calendario VB6 por input type="date"
- **Responsive**: Grid debe adaptarse al ancho de pantalla
- **Exportación**: PDF y Excel con misma estructura que VB6
- **Validación**: Replicar validación de año actual de empresa
- **Formato fecha**: Mantener formato dd/mm/yyyy hh:mm como en VB6

### Entidades Relacionadas
- **Auditoria_Cuentas_Definidas**: Tabla principal de auditoría
- **Empresas**: Para obtener RUT y NombreCorto
- **Usuarios**: Para obtener nombre de usuario
- **Auditoria_Empresas**: Para obtener años disponibles

### Consideraciones Especiales
- **Fecha como string**: Necesita parsing especial en EF Core
- **Formato RUT**: Implementar helper para formato chileno XX.XXX.XXX-X
- **Sin paginación**: VB6 carga todo en memoria, considerar paginación si hay muchos registros
- **Filtros opcionales**: Todos los filtros son opcionales

---

## ✅ CHECKLIST DE COMPLETITUD DEL ANÁLISIS

- [x] Todos los controles UI documentados
- [x] Todos los botones y eventos mapeados
- [x] **TODOS los botones tienen "Mapeo .NET" definido**
- [x] Todas las funciones VB6 identificadas
- [x] Todos los queries SQL traducidos a EF Core
- [x] Todas las validaciones documentadas
- [x] Todas las reglas de negocio identificadas
- [x] Todos los cálculos documentados
- [x] Navegación y flujos mapeados
- [x] Métodos .NET determinados
- [x] Interface del Service definida
- [x] DTOs definidos
- [x] Consideraciones sobre formato de fecha como string
- [x] Helper para formateo de RUT chileno

---

**✅ ANÁLISIS COMPLETO - LISTO PARA IMPLEMENTACIÓN**
