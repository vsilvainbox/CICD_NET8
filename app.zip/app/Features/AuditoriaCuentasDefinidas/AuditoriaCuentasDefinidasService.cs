using Microsoft.EntityFrameworkCore;
using App.Data;
using App.Services;
using OfficeOpenXml;
using System.Globalization;

namespace App.Features.AuditoriaCuentasDefinidas;

/// <summary>
/// Implementación del servicio de auditoría de cuentas definidas.
/// Gestiona consultas y exportación del historial de cambios en cuentas definidas.
/// </summary>
public class AuditoriaCuentasDefinidasService(
    LpContabContext context,
    IExportService exportService,
    ILogger<AuditoriaCuentasDefinidasService> logger) : IAuditoriaCuentasDefinidasService
{
    /// <summary>
    /// Obtiene el reporte de auditoría con filtros opcionales
    /// </summary>
    public async Task<IEnumerable<AuditoriaCuentasDefinidasDto>> GetFilteredAsync(
        int? idEmpresa = null,
        int? annio = null,
        string? usuario = null,
        DateTime? fechaDesde = null,
        DateTime? fechaHasta = null)
    {
        {
            logger.LogInformation(
                "GetFilteredAsync: idEmpresa={IdEmpresa}, annio={Annio}, usuario={Usuario}, fechaDesde={FechaDesde}, fechaHasta={FechaHasta}",
                idEmpresa, annio, usuario, fechaDesde, fechaHasta);

            // Query base con joins
            var query = from audit in context.Auditoria_Cuentas_Definidas
                join emp in context.Empresas on audit.idEmpresa equals emp.IdEmpresa into empJoin
                from empresa in empJoin.DefaultIfEmpty()
                join usr in context.Usuarios on audit.idUsuario equals usr.IdUsuario into usrJoin
                from usuarioEntity in usrJoin.DefaultIfEmpty()
                select new
                {
                    audit.idEmpresa,
                    Rut = empresa.Rut,
                    audit.configuracion,
                    audit.evento,
                    audit.cta_asociado,
                    audit.codigo,
                    audit.descripcion,
                    audit.fecha,
                    Usuario = usuarioEntity.Usuario
                };

            // Aplicar filtros
            if (idEmpresa.HasValue && idEmpresa.Value > 0)
            {
                query = query.Where(x => x.idEmpresa == idEmpresa.Value);
            }

            // Filtro por año - fecha es DateTime en SQL Server
            if (annio.HasValue && annio.Value > 0)
            {
                query = query.Where(x => x.fecha.Year == annio.Value);
            }

            if (!string.IsNullOrWhiteSpace(usuario))
            {
                var usuarioLower = usuario.ToLower();
                query = query.Where(x => x.Usuario != null && x.Usuario.ToLower() == usuarioLower);
            }

            // Filtro por rango de fechas - fecha es DateTime en SQL Server
            if (fechaDesde.HasValue)
            {
                query = query.Where(x => x.fecha.Date >= fechaDesde.Value.Date);
            }

            if (fechaHasta.HasValue)
            {
                query = query.Where(x => x.fecha.Date <= fechaHasta.Value.Date);
            }

            // Ejecutar query con todos los filtros aplicados
            if (fechaDesde.HasValue || fechaHasta.HasValue)
            {
                var results = await query.ToListAsync();

                var resultDtos = results.Select(x => new AuditoriaCuentasDefinidasDto
                {
                    IdEmpresa = x.idEmpresa,
                    Rut = FormatRut(x.Rut ?? string.Empty),
                    Configuracion = x.configuracion ?? string.Empty,
                    Evento = x.evento ?? string.Empty,
                    CtaAsociado = x.cta_asociado ?? string.Empty,
                    Codigo = x.codigo ?? string.Empty,
                    Descripcion = x.descripcion ?? string.Empty,
                    Fecha = x.fecha.ToString("dd/MM/yyyy HH:mm"),
                    Usuario = x.Usuario ?? string.Empty
                }).ToList();

                logger.LogInformation("GetFilteredAsync: Retornando {Count} registros (filtrado con fechas)", resultDtos.Count);
                return resultDtos;
            }
            else
            {
                // Sin filtro de fechas, ejecutar query directamente
                var results = await query.ToListAsync();

                var resultDtos = results.Select(x => new AuditoriaCuentasDefinidasDto
                {
                    IdEmpresa = x.idEmpresa,
                    Rut = FormatRut(x.Rut ?? string.Empty),
                    Configuracion = x.configuracion ?? string.Empty,
                    Evento = x.evento ?? string.Empty,
                    CtaAsociado = x.cta_asociado ?? string.Empty,
                    Codigo = x.codigo ?? string.Empty,
                    Descripcion = x.descripcion ?? string.Empty,
                    Fecha = x.fecha.ToString("dd/MM/yyyy HH:mm"),
                    Usuario = x.Usuario ?? string.Empty
                }).ToList();

                logger.LogInformation("GetFilteredAsync: Retornando {Count} registros", resultDtos.Count);
                return resultDtos;
            }
        }
    }

    /// <summary>
    /// Obtiene la lista de empresas disponibles
    /// </summary>
    public async Task<IEnumerable<ComboItemDto>> GetEmpresasAsync()
    {
        {
            var empresas = await context.Empresas
                .OrderBy(e => e.NombreCorto)
                .Select(e => new ComboItemDto
                {
                    Value = e.IdEmpresa,
                    Text = e.NombreCorto ?? string.Empty
                })
                .ToListAsync();

            logger.LogInformation("GetEmpresasAsync: Retornando {Count} empresas", empresas.Count);
            return empresas;
        }
    }

    /// <summary>
    /// Obtiene los años disponibles en Auditoria_Empresas
    /// </summary>
    public async Task<IEnumerable<ComboItemDto>> GetDistinctYearsAsync()
    {
        {
            var years = await context.Auditoria_Empresas
                .Where(a => a.Annio.HasValue)
                .Select(a => a.Annio!.Value)
                .Distinct()
                .OrderByDescending(y => y)
                .ToListAsync();

            var result = years.Select(y => new ComboItemDto
            {
                Value = y,
                Text = y.ToString()
            }).ToList();

            logger.LogInformation("GetDistinctYearsAsync: Retornando {Count} años", result.Count);
            return result;
        }
    }

    /// <summary>
    /// Obtiene los usuarios disponibles en la tabla de auditoría
    /// </summary>
    public async Task<IEnumerable<ComboItemDto>> GetUsuariosAsync()
    {
        {
            // Obtener usuarios distintos desde la tabla Usuarios
            // filtrando por los IDs que existen en Auditoria_Cuentas_Definidas
            var idsUsuariosEnAudit = await context.Auditoria_Cuentas_Definidas
                .Where(a => a.idUsuario.HasValue)
                .Select(a => a.idUsuario!.Value)
                .Distinct()
                .ToListAsync();

            var usuarios = await context.Usuarios
                .Where(u => idsUsuariosEnAudit.Contains(u.IdUsuario))
                .OrderBy(u => u.Usuario)
                .Select(u => new ComboItemDto
                {
                    Value = u.IdUsuario,
                    Text = u.Usuario ?? string.Empty
                })
                .ToListAsync();

            logger.LogInformation("GetUsuariosAsync: Retornando {Count} usuarios", usuarios.Count);
            return usuarios;
        }
    }

    /// <summary>
    /// Valida el rango de fechas
    /// </summary>
    public Task<ValidationResult> ValidateFiltersAsync(DateTime? fechaDesde, DateTime? fechaHasta)
    {
        {
            if (fechaDesde.HasValue && fechaHasta.HasValue)
            {
                if (fechaDesde.Value > fechaHasta.Value)
                {
                    return Task.FromResult(new ValidationResult
                    {
                        IsValid = false,
                        ErrorMessage = "La fecha 'Desde' no puede ser mayor que la fecha 'Hasta'"
                    });
                }
            }

            return Task.FromResult(new ValidationResult { IsValid = true });
        }
    }

    /// <summary>
    /// Formatea un RUT chileno al formato XX.XXX.XXX-X
    /// </summary>
    public string FormatRut(string rut)
    {
        if (string.IsNullOrWhiteSpace(rut))
            return string.Empty;

        {
            // Limpiar el RUT
            rut = rut.Trim().Replace(".", "").Replace("-", "");

            if (rut.Length < 2)
                return rut;

            // Separar dígito verificador
            var dv = rut[^1..];
            var numero = rut[..^1];

            // Si el número es menor a 1000, no formatearlo
            if (numero.Length <= 3)
                return $"{numero}-{dv}";

            // Formatear con puntos de miles
            var formatted = string.Empty;
            var counter = 0;

            for (int i = numero.Length - 1; i >= 0; i--)
            {
                if (counter == 3)
                {
                    formatted = "." + formatted;
                    counter = 0;
                }
                formatted = numero[i] + formatted;
                counter++;
            }

            return $"{formatted}-{dv}";
        }
    }

    /// <summary>
    /// Exporta el reporte a Excel
    /// </summary>
    public async Task<byte[]> ExportToExcelAsync(IEnumerable<AuditoriaCuentasDefinidasDto> datos)
    {
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            using var package = new ExcelPackage();
            var worksheet = package.Workbook.Worksheets.Add("Auditoría Cuentas Definidas");

            // Encabezados
            worksheet.Cells[1, 1].Value = "Empresa";
            worksheet.Cells[1, 2].Value = "RUT";
            worksheet.Cells[1, 3].Value = "Configuración";
            worksheet.Cells[1, 4].Value = "Evento";
            worksheet.Cells[1, 5].Value = "Cta Asociado";
            worksheet.Cells[1, 6].Value = "Código";
            worksheet.Cells[1, 7].Value = "Descripción";
            worksheet.Cells[1, 8].Value = "Fecha";
            worksheet.Cells[1, 9].Value = "Usuario";

            // Estilo de encabezados
            using (var range = worksheet.Cells[1, 1, 1, 9])
            {
                range.Style.Font.Bold = true;
                range.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                range.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightGray);
            }

            // Datos
            int row = 2;
            foreach (var item in datos)
            {
                worksheet.Cells[row, 1].Value = item.IdEmpresa;
                worksheet.Cells[row, 2].Value = item.Rut;
                worksheet.Cells[row, 3].Value = item.Configuracion;
                worksheet.Cells[row, 4].Value = item.Evento;
                worksheet.Cells[row, 5].Value = item.CtaAsociado;
                worksheet.Cells[row, 6].Value = item.Codigo;
                worksheet.Cells[row, 7].Value = item.Descripcion;
                worksheet.Cells[row, 8].Value = item.Fecha;
                worksheet.Cells[row, 9].Value = item.Usuario;
                row++;
            }

            // Auto-ajustar columnas
            worksheet.Cells[worksheet.Dimension.Address].AutoFitColumns();

            logger.LogInformation("ExportToExcelAsync: Excel generado con {Count} registros", datos.Count());

            return await Task.FromResult(package.GetAsByteArray());
        }
    }

    /// <summary>
    /// Exporta el reporte a PDF usando QuestPDF
    /// Migrado desde VB6: Genera reporte profesional de auditoría de cuentas definidas
    /// </summary>
    public Task<byte[]> ExportToPdfAsync(IEnumerable<AuditoriaCuentasDefinidasDto> datos)
    {
        {
            logger.LogInformation("ExportToPdfAsync: Generando PDF con {Count} registros", datos.Count());

            // Definir columnas para el PDF
            var columns = new Dictionary<string, Func<AuditoriaCuentasDefinidasDto, string>>
            {
                { "Empresa", d => d.IdEmpresa?.ToString() ?? "" },
                { "RUT", d => d.Rut ?? "" },
                { "Configuración", d => d.Configuracion ?? "" },
                { "Evento", d => d.Evento ?? "" },
                { "Cta. Asociado", d => d.CtaAsociado ?? "" },
                { "Código", d => d.Codigo ?? "" },
                { "Descripción", d => d.Descripcion ?? "" },
                { "Fecha", d => d.Fecha ?? "" },
                { "Usuario", d => d.Usuario ?? "" }
            };

            // Usar servicio genérico de exportación
            var pdfBytes = exportService.ExportTableToPdf(
                datos,
                "AUDITORÍA DE CUENTAS DEFINIDAS",
                "Sistema Contable",
                "",
                columns
            );

            logger.LogInformation("ExportToPdfAsync: PDF generado exitosamente con {Count} registros", datos.Count());

            return Task.FromResult(pdfBytes);
        }
    }
}