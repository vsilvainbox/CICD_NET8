﻿namespace App.Features.AbrirCerrarMes;

/// <summary>
/// Interfaz de servicio para gestión de períodos contables (Abrir/Cerrar Mes)
/// Controla qué meses están abiertos para edición de comprobantes
/// </summary>
public interface IAbrirCerrarMesService
{
    /// <summary>
    /// Obtiene los estados de todos los meses (1-12) para una empresa y año
    /// Mapea a: LoadMeses() en VB6 FrmEstadoMeses.frm
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año contable</param>
    /// <returns>Lista con los 12 meses y sus estados</returns>
    Task<IEnumerable<EstadoMesDto>> GetMonthStatesAsync(int empresaId, short ano);

    /// <summary>
    /// Obtiene el último mes que tiene comprobantes registrados
    /// Mapea a: GetUltimoMesConMovs() en VB6
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año contable</param>
    /// <returns>Número del mes (1-12) o 0 si no hay movimientos</returns>
    Task<int> GetLastMonthWithMovementsAsync(int empresaId, short ano);

    /// <summary>
    /// Abre un mes para permitir edición de comprobantes
    /// Valida que solo haya un mes abierto a la vez (excepto si AbrirMesesParalelo = true)
    /// Mapea a: Bt_AbrirMes_Click() + AbrirMes() en VB6
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año contable</param>
    /// <param name="mes">Número del mes a abrir (1-12)</param>
    /// <returns>Resultado de la validación con mensaje</returns>
    Task<ValidationResult> OpenMonthAsync(int empresaId, short ano, int mes);

    /// <summary>
    /// Cierra un mes para prevenir edición de comprobantes
    /// Mapea a: Bt_CerrarMes_Click() + CerrarMes() en VB6
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año contable</param>
    /// <param name="mes">Número del mes a cerrar (1-12)</param>
    /// <returns>Resultado de la validación con mensaje</returns>
    Task<ValidationResult> CloseMonthAsync(int empresaId, short ano, int mes);

    /// <summary>
    /// Obtiene la configuración de apertura de meses paralelos
    /// Mapea a: gAbrirMesesParalelo global variable en VB6
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <returns>True si se permite abrir múltiples meses simultáneamente</returns>
    Task<bool> GetAbrirMesesParaleloAsync(int empresaId);

    /// <summary>
    /// Obtiene la configuración completa para la gestión de meses
    /// Incluye permisos y configuración de la empresa
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año contable</param>
    /// <returns>Configuración con permisos y datos de empresa</returns>
    Task<EstadoMesesConfigDto> GetConfigurationAsync(int empresaId, short ano);
}
