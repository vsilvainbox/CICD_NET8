using Microsoft.AspNetCore.Mvc;

namespace App.Features.AbrirCerrarMes;

/// <summary>
/// API Controller para gestión de períodos contables (Abrir/Cerrar Mes)
/// Migrado desde VB6 FrmEstadoMeses.frm
/// </summary>
[ApiController]
[Route("api/[controller]/[action]")]
public class AbrirCerrarMesApiController(IAbrirCerrarMesService service, ILogger<AbrirCerrarMesApiController> logger) : ControllerBase
{
    /// <summary>
    /// Obtiene los estados de todos los meses (1-12) para una empresa y año
    /// GET /api/AbrirCerrarMes/estados?empresaId=1&amp;ano=2024
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<IEnumerable<EstadoMesDto>>> Estados([FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: Estados called with empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        {
            if (empresaId <= 0)
            {
                return BadRequest(new { message = "EmpresaId es requerido y debe ser mayor a 0" });
            }

            if (ano <= 0)
            {
                return BadRequest(new { message = "año es requerido y debe ser mayor a 0" });
            }

            var monthStates = await service.GetMonthStatesAsync(empresaId, ano);
            return Ok(monthStates);
        }
    }

    /// <summary>
    /// Obtiene el último mes con movimientos (comprobantes)
    /// GET /api/AbrirCerrarMes/ultimo-mes-movimientos?empresaId=1&amp;ano=2024
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<int>> GetLastMonthWithMovements([FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: GetLastMonthWithMovements called with empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        {
            if (empresaId <= 0)
            {
                return BadRequest(new { message = "EmpresaId es requerido y debe ser mayor a 0" });
            }

            if (ano <= 0)
            {
                return BadRequest(new { message = "año es requerido y debe ser mayor a 0" });
            }

            var lastMonth = await service.GetLastMonthWithMovementsAsync(empresaId, ano);
            return Ok(lastMonth);
        }
    }

    /// <summary>
    /// Abre un mes para permitir edición de comprobantes
    /// POST /api/AbrirCerrarMes/abrir
    /// Body: { "empresaId": 1, "ano": 2024, "mes": 3 }
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<ValidationResult>> Abrir([FromBody] AbrirCerrarMesRequestDto request)
    {
        logger.LogInformation("API: Abrir called with empresaId: {EmpresaId}, año: {Ano}, mes: {Mes}",
            request.EmpresaId, request.Ano, request.Mes);

        {
            if (request.EmpresaId <= 0)
            {
                return BadRequest(new { message = "EmpresaId es requerido y debe ser mayor a 0" });
            }

            if (request.Ano <= 0)
            {
                return BadRequest(new { message = "año es requerido y debe ser mayor a 0" });
            }

            if (request.Mes < 1 || request.Mes > 12)
            {
                return BadRequest(new { message = "Mes debe estar entre 1 y 12" });
            }

            var result = await service.OpenMonthAsync(request.EmpresaId, request.Ano, request.Mes);

            if (result.Success)
            {
                return Ok(result);
            }
            else
            {
                return BadRequest(result);
            }
        }
    }

    /// <summary>
    /// Cierra un mes para prevenir edición de comprobantes
    /// POST /api/AbrirCerrarMes/cerrar
    /// Body: { "empresaId": 1, "ano": 2024, "mes": 3 }
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<ValidationResult>> Cerrar([FromBody] AbrirCerrarMesRequestDto request)
    {
        logger.LogInformation("API: Cerrar called with empresaId: {EmpresaId}, año: {Ano}, mes: {Mes}",
            request.EmpresaId, request.Ano, request.Mes);

        {
            if (request.EmpresaId <= 0)
            {
                return BadRequest(new { message = "EmpresaId es requerido y debe ser mayor a 0" });
            }

            if (request.Ano <= 0)
            {
                return BadRequest(new { message = "año es requerido y debe ser mayor a 0" });
            }

            if (request.Mes < 1 || request.Mes > 12)
            {
                return BadRequest(new { message = "Mes debe estar entre 1 y 12" });
            }

            var result = await service.CloseMonthAsync(request.EmpresaId, request.Ano, request.Mes);

            if (result.Success)
            {
                return Ok(result);
            }
            else
            {
                return BadRequest(result);
            }
        }
    }

    /// <summary>
    /// Obtiene la configuración de gestión de meses
    /// GET /api/AbrirCerrarMes/configuracion?empresaId=1&amp;ano=2024
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<EstadoMesesConfigDto>> Configuracion([FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: Configuracion called with empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        {
            if (empresaId <= 0)
            {
                return BadRequest(new { message = "EmpresaId es requerido y debe ser mayor a 0" });
            }

            if (ano <= 0)
            {
                return BadRequest(new { message = "año es requerido y debe ser mayor a 0" });
            }

            var config = await service.GetConfigurationAsync(empresaId, ano);
            return Ok(config);
        }
    }
}
