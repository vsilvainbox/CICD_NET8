using App.Data;
using Microsoft.EntityFrameworkCore;

namespace App.Features.AbrirCerrarMes;

/// <summary>
/// Servicio para gestión de períodos contables (Abrir/Cerrar Mes)
/// Migrado desde VB6 FrmEstadoMeses.frm
/// </summary>
public class AbrirCerrarMesService(LpContabContext context, ILogger<AbrirCerrarMesService> logger) : IAbrirCerrarMesService
{
    // Nombres de meses en español (índice 0 vacío para facilitar acceso 1-12)
    private static readonly string[] MonthNames = {
        "", "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
        "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
    };

    // Estados de mes (mapeo desde VB6 constants)
    private const int EM_CERRADO = 0;
    private const int EM_ABIERTO = 1;

    // Código de parámetro en tabla Param (valor numérico)
    // TODO: Verificar código correcto en base de datos Param
    private const int PARAM_MESPARALEL_CODIGO = 999; // Placeholder - verificar valor real

    /// <summary>
    /// Obtiene los estados de todos los meses (1-12)
    /// Mapea a: LoadMeses() en VB6
    /// </summary>
    public async Task<IEnumerable<EstadoMesDto>> GetMonthStatesAsync(int empresaId, short ano)
    {
        logger.LogInformation("Getting month states for empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        {
            // Obtener estados de meses desde la base de datos
            var dbMonths = await context.EstadoMes
                .Where(e => e.IdEmpresa == empresaId && e.Ano == ano)
                .ToListAsync();

            logger.LogInformation("Found {Count} month records in database", dbMonths.Count);

            // Obtener el último mes con movimientos (para mostrar flecha roja)
            var lastMonthWithMovements = await GetLastMonthWithMovementsAsync(empresaId, ano);

            // Crear lista de 12 meses (1-12)
            // Si un mes no existe en la DB, se asume CERRADO por defecto
            var allMonths = new List<EstadoMesDto>();

            for (int mes = 1; mes <= 12; mes++)
            {
                var dbMonth = dbMonths.FirstOrDefault(m => m.Mes == mes);
                int estado = dbMonth?.Estado ?? EM_CERRADO; // Default: CERRADO

                allMonths.Add(new EstadoMesDto
                {
                    Mes = mes,
                    Estado = estado,
                    EstadoTexto = estado == EM_ABIERTO ? "ABIERTO" : "CERRADO",
                    NombreMes = MonthNames[mes],
                    EsUltimoMesConMovimientos = (mes == lastMonthWithMovements)
                });
            }

            logger.LogInformation("Returning {Count} months with states", allMonths.Count);
            return allMonths;
        }
    }

    /// <summary>
    /// Obtiene el último mes que tiene comprobantes
    /// Mapea a: GetUltimoMesConMovs() en VB6
    /// </summary>
    public async Task<int> GetLastMonthWithMovementsAsync(int empresaId, short ano)
    {
        logger.LogInformation("Getting last month with movements for empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        {
            // Note: Comprobante doesn't have Mes property, need to extract from Fecha (YYYYMMDD format)
            // Fecha format: YYYYMMDD, so month is (Fecha % 10000) / 100
            var comprobantes = await context.Comprobante
                .Where(c => c.IdEmpresa == empresaId && c.Ano == ano && c.Fecha != null)
                .Select(c => c.Fecha!.Value)
                .ToListAsync();

            if (!comprobantes.Any())
            {
                logger.LogInformation("No comprobantes found for empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);
                return 0;
            }

            // Extract month from Fecha (YYYYMMDD format)
            var lastMonth = comprobantes
                .Select(fecha => (fecha % 10000) / 100)
                .Max();

            logger.LogInformation("Last month with movements: {LastMonth}", lastMonth);
            return lastMonth;
        }
    }

    /// <summary>
    /// Abre un mes para permitir edición
    /// Mapea a: Bt_AbrirMes_Click() + AbrirMes() en VB6
    /// </summary>
    public async Task<ValidationResult> OpenMonthAsync(int empresaId, short ano, int mes)
    {
        logger.LogInformation("Opening month {Mes} for empresaId: {EmpresaId}, año: {Ano}", mes, empresaId, ano);

        {
            // Validación: Mes debe estar entre 1 y 12
            if (mes < 1 || mes > 12)
            {
                return ValidationResult.Fail("El mes debe estar entre 1 y 12");
            }

            // 1. Verificar si el mes ya está abierto
            var estadoMes = await context.EstadoMes
                .FirstOrDefaultAsync(e => e.IdEmpresa == empresaId && e.Ano == ano && e.Mes == mes);

            if (estadoMes?.Estado == EM_ABIERTO)
            {
                logger.LogWarning("Month {Mes} is already open", mes);
                return ValidationResult.Fail($"El mes de {MonthNames[mes]} ya está abierto.");
            }

            // 2. Validar que solo haya un mes abierto a la vez (excepto si AbrirMesesParalelo = true)
            var abrirMesesParalelo = await GetAbrirMesesParaleloAsync(empresaId);

            if (!abrirMesesParalelo)
            {
                var openMonths = await context.EstadoMes
                    .Where(e => e.IdEmpresa == empresaId && e.Ano == ano && e.Estado == EM_ABIERTO)
                    .ToListAsync();

                if (openMonths.Any())
                {
                    var openMonth = openMonths.First();
                    var openMonthNumber = (int)openMonth.Mes!.Value;
                    logger.LogWarning("Cannot open month {Mes}: Month {OpenMonth} is already open", mes, openMonthNumber);
                    return ValidationResult.Fail($"Para abrir este mes, debe antes cerrar el mes de {MonthNames[openMonthNumber]}.");
                }
            }

            // 3. Abrir el mes (UPDATE o INSERT)
            if (estadoMes == null)
            {
                // INSERT: El mes no existe en la tabla
                estadoMes = new App.Data.EstadoMes
                {
                    IdEmpresa = empresaId,
                    Ano = ano,
                    Mes = (short)mes,
                    Estado = EM_ABIERTO,
                    FechaApertura = GetDateAsInt(DateTime.Now)
                };
                context.EstadoMes.Add(estadoMes);
                logger.LogInformation("Inserting new EstadoMes record for month {Mes}", mes);
            }
            else
            {
                // UPDATE: El mes existe pero está cerrado
                estadoMes.Estado = EM_ABIERTO;
                estadoMes.FechaApertura = GetDateAsInt(DateTime.Now);
                context.EstadoMes.Update(estadoMes);
                logger.LogInformation("Updating EstadoMes record to ABIERTO for month {Mes}", mes);
            }

            await context.SaveChangesAsync();

            logger.LogInformation("Month {Mes} opened successfully", mes);
            return ValidationResult.Ok($"El mes de {MonthNames[mes]} ha sido abierto correctamente.");
        }
    }

    /// <summary>
    /// Cierra un mes para prevenir edición
    /// Mapea a: Bt_CerrarMes_Click() + CerrarMes() en VB6
    /// </summary>
    public async Task<ValidationResult> CloseMonthAsync(int empresaId, short ano, int mes)
    {
        logger.LogInformation("Closing month {Mes} for empresaId: {EmpresaId}, año: {Ano}", mes, empresaId, ano);

        {
            // Validación: Mes debe estar entre 1 y 12
            if (mes < 1 || mes > 12)
            {
                return ValidationResult.Fail("El mes debe estar entre 1 y 12");
            }

            // 1. Verificar si el mes ya está cerrado
            var estadoMes = await context.EstadoMes
                .FirstOrDefaultAsync(e => e.IdEmpresa == empresaId && e.Ano == ano && e.Mes == mes);

            if (estadoMes?.Estado == EM_CERRADO || estadoMes == null)
            {
                logger.LogWarning("Month {Mes} is already closed or doesn't exist", mes);
                return ValidationResult.Fail($"El mes de {MonthNames[mes]} ya está cerrado.");
            }

            // 2. Cerrar el mes (UPDATE o INSERT)
            if (estadoMes == null)
            {
                // INSERT: El mes no existe en la tabla (estado por defecto es CERRADO)
                estadoMes = new App.Data.EstadoMes
                {
                    IdEmpresa = empresaId,
                    Ano = ano,
                    Mes = (short)mes,
                    Estado = EM_CERRADO,
                    FechaCierre = GetDateAsInt(DateTime.Now)
                };
                context.EstadoMes.Add(estadoMes);
                logger.LogInformation("Inserting new EstadoMes record (CERRADO) for month {Mes}", mes);
            }
            else
            {
                // UPDATE: El mes existe y está abierto
                estadoMes.Estado = EM_CERRADO;
                estadoMes.FechaCierre = GetDateAsInt(DateTime.Now);
                context.EstadoMes.Update(estadoMes);
                logger.LogInformation("Updating EstadoMes record to CERRADO for month {Mes}", mes);
            }

            await context.SaveChangesAsync();

            logger.LogInformation("Month {Mes} closed successfully", mes);
            return ValidationResult.Ok($"El mes de {MonthNames[mes]} ha sido cerrado correctamente.");
        }
    }

    /// <summary>
    /// Obtiene la configuración de apertura de meses paralelos desde tabla Param
    /// Mapea a: gAbrirMesesParalelo global variable en VB6
    /// Lee desde tabla Param con código MESPARALEL
    /// </summary>
    public async Task<bool> GetAbrirMesesParaleloAsync(int empresaId)
    {
        logger.LogInformation("Getting AbrirMesesParalelo config for empresaId: {EmpresaId}", empresaId);

        {
            // Leer desde tabla Param (código MESPARALEL)
            // Param es tabla global (sin IdEmpresa)
            var paramMesParalel = await context.Param
                .FirstOrDefaultAsync(p => p.Codigo == PARAM_MESPARALEL_CODIGO);

            if (paramMesParalel != null)
            {
                // Parsear valor: "0" = false, "1" (o cualquier otro != 0) = true
                if (int.TryParse(paramMesParalel.Valor, out int valor))
                {
                    bool permiteMesesParalelos = (valor != 0);
                    logger.LogInformation("AbrirMesesParalelo configurado desde BD: {Permite} (valor={Valor})",
                        permiteMesesParalelos, valor);
                    return permiteMesesParalelos;
                }
                else
                {
                    logger.LogWarning("Valor de MESPARALEL no es numérico: {Valor}, defaulting to false",
                        paramMesParalel.Valor);
                    return false;
                }
            }

            // No existe el parámetro - Default: false (solo un mes abierto)
            logger.LogInformation("MESPARALEL no encontrado en tabla Param para empresaId {EmpresaId}, defaulting to false",
                empresaId);
            return false;
        }
    }

    /// <summary>
    /// Obtiene la configuración completa para la gestión de meses
    /// </summary>
    public async Task<EstadoMesesConfigDto> GetConfigurationAsync(int empresaId, short ano)
    {
        logger.LogInformation("Getting configuration for empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        {
            var empresa = await context.Empresas
                .FirstOrDefaultAsync(e => e.IdEmpresa == empresaId);

            var abrirMesesParalelo = await GetAbrirMesesParaleloAsync(empresaId);

            // TODO: [PERMISSION_CHECK] Verificar privilegio PRV_ADM_EMPRESA desde sesión de usuario
            // Por ahora, retornar true para permitir funcionalidad
            var canOpenClose = true;

            return new EstadoMesesConfigDto
            {
                EmpresaId = empresaId,
                Ano = ano,
                RazonSocial = empresa?.NombreCorto ?? "N/A",
                AbrirMesesParalelo = abrirMesesParalelo,
                CanOpenClose = canOpenClose
            };
        }
    }

    /// <summary>
    /// Convierte DateTime a int en formato YYYYMMDD (estilo VB6)
    /// </summary>
    private int GetDateAsInt(DateTime date)
    {
        return date.Year * 10000 + date.Month * 100 + date.Day;
    }
}
