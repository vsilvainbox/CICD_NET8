using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.AbrirCerrarMes;

/// <summary>
/// MVC Controller para gesti�n de per�odos contables (Abrir/Cerrar Mes)
/// Migrado desde VB6 FrmEstadoMeses.frm
/// </summary>
public class AbrirCerrarMesController(
    ILogger<AbrirCerrarMesController> logger,
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator) : Controller
{
    /// <summary>
    /// Vista principal del control de per�odos contables
    /// Muestra los 12 meses del año con sus estados (ABIERTO/CERRADO)
    /// </summary>
    public IActionResult Index()
    {
        logger.LogInformation("Loading AbrirCerrarMes Index view for empresaId: {EmpresaId}, año: {Ano}", SessionHelper.EmpresaId, SessionHelper.Ano);

            

        return View();
    }

    /// <summary>
    /// Proxy para obtener configuración de la empresa y año
    /// GET /AbrirCerrarMes/Configuracion?empresaId=1&amp;ano=2024
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Configuracion(int empresaId, short ano)
    {
        logger.LogInformation("Proxy: GetConfiguration called with empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AbrirCerrarMesApiController.Configuracion),
                controller: nameof(AbrirCerrarMesApiController).Replace("Controller", ""),
                values: new { empresaId, ano }
            );

            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Proxy para obtener estados de todos los meses
    /// GET /AbrirCerrarMes/Estados?empresaId=1&amp;ano=2024
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Estados(int empresaId, short ano)
    {
        logger.LogInformation("Proxy: GetEstados called with empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AbrirCerrarMesApiController.Estados),
                controller: nameof(AbrirCerrarMesApiController).Replace("Controller", ""),
                values: new { empresaId, ano }
            );

            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Proxy para abrir un mes
    /// POST /AbrirCerrarMes/Abrir
    /// Body: { "empresaId": 1, "ano": 2024, "mes": 3 }
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Abrir([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: Abrir called");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AbrirCerrarMesApiController.Abrir),
                controller: nameof(AbrirCerrarMesApiController).Replace("Controller", "")
            );

            var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// Proxy para cerrar un mes
    /// POST /AbrirCerrarMes/Cerrar
    /// Body: { "empresaId": 1, "ano": 2024, "mes": 3 }
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Cerrar([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: Cerrar called");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AbrirCerrarMesApiController.Cerrar),
                controller: nameof(AbrirCerrarMesApiController).Replace("Controller", "")
            );

            var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }
}