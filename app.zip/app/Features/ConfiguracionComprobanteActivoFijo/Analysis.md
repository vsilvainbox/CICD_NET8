# Legacy Analysis: Configuración Comprobante Activo Fijo IFRS

## 📄 VB6: FrmConfigCompActFijo.frm
**Propósito:** Constructor de comprobante contable para operaciones de Activo Fijo IFRS

## 📋 Descripción General
Form modal que permite construir un comprobante contable combinando cuentas del plan de cuentas con valores calculados de activos fijos. Es una herramienta de configuración temporal que NO guarda en base de datos, sino que construye datos en memoria para luego crear un comprobante.

## 🎯 Caso de Uso
1. Usuario está configurando movimientos contables de activos fijos IFRS
2. Necesita crear asientos que involucren múltiples valores del activo (razonable, inicial, residual, etc.)
3. Selecciona cuenta contable del plan de cuentas
4. Marca qué valores del activo quiere incluir (checkboxes)
5. Define si va al Debe o al Haber
6. Agrega múltiples líneas al grid
7. Crea el comprobante con todas las líneas configuradas

## 🔧 Controles y Funcionalidad

### Frame "Datos Comprobante"
- **Tx_Cuenta**: TextBox read-only para mostrar cuenta seleccionada
- **Bt_Cuentas**: Botón para abrir Plan de Cuentas (FrmPlanCuentas.FSelect)

### Checkboxes de Valores (8 opciones):
1. **Ck_ValorRazonable**: Valor Razonable
2. **Ck_ValorInicial**: Valor Inicial
3. **Ck_ValorBien**: Valor del Bien
4. **Ck_ValorLibro**: Valor Libro
5. **Ck_ValorResidual**: Valor Residual
6. **Ck_ValorDepreciar**: Valor a Depreciar
7. **Ck_ValorLibroAntRevalor**: Valor Libro antes de Revalorización
8. **Ck_ValorLibroDespRevalo**: Valor Libro después de Revalorización

### Checkboxes Debe/Haber (mutuamente excluyentes):
- **Ck_Debe**: Marca la línea como Debe
- **Ck_Haber**: Marca la línea como Haber
- **Comportamiento**: Al marcar uno, se desmarca el otro automáticamente

### Botones Principales:
- **Bt_Aceptar** ("Agregar"): Agrega línea al grid con valores sumados
- **Bt_Cancelar**: Cierra el form sin guardar
- **Bt_Comprobante** ("Crear Comprobante"): Envía todas las líneas a FrmComprobante

### Grid (MSFlexGrid):
**Columnas:**
- `C_IDCUENTA (0)`: Hidden - ID de la cuenta
- `C_CUENTA (1)`: Código de cuenta
- `C_DESCRCUENTA (2)`: Descripción de cuenta
- `C_DEBE (3)`: Valor Debe (formato numérico)
- `C_HABER (4)`: Valor Haber (formato numérico)

## 📊 Flujo de Datos

### Variables de Módulo:
```vb
vIdCuenta As String          ' ID cuenta seleccionada
vCuenta As String            ' Código cuenta
vCodCuenta As String         ' Código cuenta
vDescCuenta As String        ' Descripción cuenta
vDebe As Double              ' Acumulador Debe
vHaber As Double             ' Acumulador Haber
vValorRazonable As String    ' Valores recibidos por parámetro
vValorInicial As String
vValorDelBien As String
vValorLibro As String
vValorResidual As String
vValorDeprecial As String
vValorLibroAntRevalor As String
vValorLibroDespRevalo As String
i As Integer                 ' Contador de filas
```

## 🔄 Métodos Públicos

### `FSelect(...)` - Exportar Datos
```vb
Public Sub FSelect(
    v_IdCuenta As String, 
    v_Cuenta As String, 
    v_DescCuenta As String, 
    v_Debe As Boolean, 
    v_Haber As Boolean, 
    v_ValorRazonable As Boolean, 
    v_ValorInicial As Boolean, 
    v_ValorDelBien As Boolean, 
    v_ValorLibro As Boolean, 
    v_ValorResidual As Boolean, 
    v_ValorDeprecial As Boolean, 
    v_ValorLibroAntRevalor As Boolean, 
    v_ValorLibroDespRevalo As Boolean
)
```
**Propósito**: Devolver datos de configuración (no usado en el código visible)

### `FSelect2(...)` - Inicializar Valores
```vb
Public Sub FSelect2(
    ByVal v_IdCuenta As String, 
    ByVal v_Cuenta As String, 
    ByVal v_DescCuenta As String, 
    ByVal v_ValorRazonable As String, 
    ByVal v_ValorInicial As String, 
    ByVal v_ValorDelBien As String, 
    ByVal v_ValorLibro As String, 
    ByVal v_ValorResidual As String, 
    ByVal v_ValorDeprecial As String, 
    ByVal v_ValorLibroAntRevalor As String, 
    ByVal v_ValorLibroDespRevalo As String
)
```
**Propósito**: Recibir valores calculados del activo antes de mostrar el form
**Comportamiento**: Asigna valores a variables de módulo y muestra form modal

### `FView()`
```vb
Public Sub FView()
```
**Propósito**: Mostrar form modal sin valores pre-inicializados

## ⚙️ Lógica de Negocio

### Bt_Aceptar_Click() - Agregar Línea
**Validaciones:**
1. Debe seleccionar cuenta (`Tx_Cuenta <> ""`)
2. Debe marcar Debe o Haber

**Proceso:**
1. Resetea acumuladores: `vDebe = 0`, `vHaber = 0`
2. Incrementa contador de fila: `i = i + 1`
3. Si `Ck_Debe = True`:
   - Por cada checkbox marcado:
     - Suma valor a `vDebe`
     - Desmarca checkbox
     - Deshabilita checkbox (`Enabled = False`)
   - Asigna `Grid.TextMatrix(i, C_DEBE) = Format(vDebe, NUMFMT)`
4. Si `Ck_Haber = True`:
   - Mismo proceso pero suma a `vHaber`
   - Asigna `Grid.TextMatrix(i, C_HABER) = Format(vHaber, NUMFMT)`
5. Completa columnas de cuenta:
   ```vb
   Grid.TextMatrix(i, C_CUENTA) = vCodCuenta
   Grid.TextMatrix(i, C_IDCUENTA) = vIdCuenta
   Grid.TextMatrix(i, C_DESCRCUENTA) = vDescCuenta
   ```
6. Agrega nueva fila: `Grid.rows = Grid.rows + 1`
7. Resetea controles: `Tx_Cuenta = ""`, `Ck_Debe = 0`, `Ck_Haber = 0`

**Importante**: Los checkboxes de valores se deshabilitan después de usarse para evitar reutilización.

### Bt_Comprobante_Click() - Crear Comprobante
**Proceso:**
1. Instancia `FrmComprobante`
2. Itera sobre todas las filas del grid (desde FixedRows hasta rows-2)
3. Por cada fila, llama:
   ```vb
   FrmComp.FNewCompActivo(
       i,                                  ' índice fila
       Val(Grid.Debe sin formato),         ' Debe como número
       Val(Grid.Haber sin formato),        ' Haber como número
       Grid.IdCuenta,
       Grid.Cuenta,
       Grid.DescrCuenta
   )
   ```
4. Muestra `FrmComprobante` modal
5. Libera objeto

**Conversión de Formato:**
```vb
Val(Replace(Replace(Grid.TextMatrix(i, C_DEBE), ".", ""), ",", ""))
```
Elimina separadores de miles (.) y decimales (,) antes de convertir

### Bt_Cuentas_Click() - Seleccionar Cuenta
**Proceso:**
1. Instancia `FrmPlanCuentas`
2. Llama `Frm.FSelect(IdCuenta, Codigo, Descrip, Nombre, False)`
3. Si retorna `vbOK`:
   - Obtiene clasificación: `ClasCta = GetClasCuenta(IdCuenta)`
   - Asigna a variables:
     ```vb
     vCodCuenta = Codigo
     Tx_Cuenta = Descrip
     vIdCuenta = IdCuenta
     vDescCuenta = Descrip
     ```

### Ck_Debe_Click() / Ck_Haber_Click()
**Exclusividad mutua:**
```vb
If Ck_Debe = 1 Then Ck_Haber = 0
If Ck_Haber = 1 Then Ck_Debe = 0
```

## 🔗 Integraciones

### FrmPlanCuentas.FSelect()
**Input**: Ninguno (modal selection)
**Output**: IdCuenta, Codigo, Descrip, Nombre
**Propósito**: Seleccionar cuenta contable del plan de cuentas

### FrmComprobante.FNewCompActivo()
**Input**: 
- i: índice línea
- vDebe: valor Debe
- vHaber: valor Haber
- IdCuenta: ID cuenta
- Cuenta: código cuenta
- DescrCuenta: descripción
**Propósito**: Agregar línea al comprobante en construcción

### GetClasCuenta()
**Input**: IdCuenta
**Output**: Clasificación de cuenta (Integer)
**Propósito**: Obtener clasificación contable de la cuenta (no usado visiblemente en el form)

## 📝 Notas Técnicas

### Valores como String
Los valores del activo (vValorRazonable, etc.) son declarados como `String` en VB6, pero se usan como números en las sumas. VB6 hace conversión implícita.

### Sin Persistencia
Este form NO interactúa con base de datos. Es puramente constructor temporal en memoria.

### Uso Típico
```vb
' Desde otro form:
Dim frm As FrmConfigCompActFijo
Set frm = New FrmConfigCompActFijo
Call frm.FSelect2(
    IdCuenta, Cuenta, DescCuenta,
    valorRazonable, valorInicial, valorBien,
    valorLibro, valorResidual, valorDepreciar,
    valorAntRevalor, valorDespRevalor
)
Set frm = Nothing
```

### Grid Acumulativo
El grid se llena línea por línea. Cada vez que se agrega una nueva línea:
- Los checkboxes usados se deshabilitan
- El contador `i` incrementa
- Se agrega nueva fila vacía al final

## 🎯 Migración a .NET

### Consideraciones:
1. **Estado en memoria**: Usar ViewModel en frontend para acumular líneas
2. **Checkboxes dinámicos**: Al agregar línea, deshabilitar checkboxes usados
3. **Suma de valores**: Calcular suma en frontend según checkboxes marcados
4. **Formato numérico**: Manejar formato chileno (punto miles, coma decimales)
5. **Integración comprobantes**: API endpoint para crear comprobante con líneas
6. **Plan de cuentas**: Modal/dropdown para selección de cuentas

### Entidades:
- NO usa entidades propias
- Lee de Plan de Cuentas
- Construye datos para Comprobantes

### API Endpoints Sugeridos:
- `GET /api/Cuentas/search?query=xxx` - buscar cuentas
- `POST /api/Comprobantes/crear-activo-fijo` - crear comprobante con líneas

### Frontend:
- Form con checkboxes de valores
- Grid editable/acumulativo
- Validación: cuenta seleccionada + debe/haber
- Botón "Agregar" acumula líneas
- Botón "Crear Comprobante" envía todo a API

## 📄 VB6: FrmConfigCompActFijo.frm
**Propósito:** Constructor de comprobante contable para operaciones de Activo Fijo IFRS

## 📋 Descripción General
Form modal que permite construir un comprobante contable combinando cuentas del plan de cuentas con valores calculados de activos fijos. Es una herramienta de configuración temporal que NO guarda en base de datos, sino que construye datos en memoria para luego crear un comprobante.

## 🎯 Caso de Uso
1. Usuario está configurando movimientos contables de activos fijos IFRS
2. Necesita crear asientos que involucren múltiples valores del activo (razonable, inicial, residual, etc.)
3. Selecciona cuenta contable del plan de cuentas
4. Marca qué valores del activo quiere incluir (checkboxes)
5. Define si va al Debe o al Haber
6. Agrega múltiples líneas al grid
7. Crea el comprobante con todas las líneas configuradas

## 🔧 Controles y Funcionalidad

### Frame "Datos Comprobante"
- **Tx_Cuenta**: TextBox read-only para mostrar cuenta seleccionada
- **Bt_Cuentas**: Botón para abrir Plan de Cuentas (FrmPlanCuentas.FSelect)

### Checkboxes de Valores (8 opciones):
1. **Ck_ValorRazonable**: Valor Razonable
2. **Ck_ValorInicial**: Valor Inicial
3. **Ck_ValorBien**: Valor del Bien
4. **Ck_ValorLibro**: Valor Libro
5. **Ck_ValorResidual**: Valor Residual
6. **Ck_ValorDepreciar**: Valor a Depreciar
7. **Ck_ValorLibroAntRevalor**: Valor Libro antes de Revalorización
8. **Ck_ValorLibroDespRevalo**: Valor Libro después de Revalorización

### Checkboxes Debe/Haber (mutuamente excluyentes):
- **Ck_Debe**: Marca la línea como Debe
- **Ck_Haber**: Marca la línea como Haber
- **Comportamiento**: Al marcar uno, se desmarca el otro automáticamente

### Botones Principales:
- **Bt_Aceptar** ("Agregar"): Agrega línea al grid con valores sumados
- **Bt_Cancelar**: Cierra el form sin guardar
- **Bt_Comprobante** ("Crear Comprobante"): Envía todas las líneas a FrmComprobante

### Grid (MSFlexGrid):
**Columnas:**
- `C_IDCUENTA (0)`: Hidden - ID de la cuenta
- `C_CUENTA (1)`: Código de cuenta
- `C_DESCRCUENTA (2)`: Descripción de cuenta
- `C_DEBE (3)`: Valor Debe (formato numérico)
- `C_HABER (4)`: Valor Haber (formato numérico)

## 📊 Flujo de Datos

### Variables de Módulo:
```vb
vIdCuenta As String          ' ID cuenta seleccionada
vCuenta As String            ' Código cuenta
vCodCuenta As String         ' Código cuenta
vDescCuenta As String        ' Descripción cuenta
vDebe As Double              ' Acumulador Debe
vHaber As Double             ' Acumulador Haber
vValorRazonable As String    ' Valores recibidos por parámetro
vValorInicial As String
vValorDelBien As String
vValorLibro As String
vValorResidual As String
vValorDeprecial As String
vValorLibroAntRevalor As String
vValorLibroDespRevalo As String
i As Integer                 ' Contador de filas
```

## 🔄 Métodos Públicos

### `FSelect(...)` - Exportar Datos
```vb
Public Sub FSelect(
    v_IdCuenta As String, 
    v_Cuenta As String, 
    v_DescCuenta As String, 
    v_Debe As Boolean, 
    v_Haber As Boolean, 
    v_ValorRazonable As Boolean, 
    v_ValorInicial As Boolean, 
    v_ValorDelBien As Boolean, 
    v_ValorLibro As Boolean, 
    v_ValorResidual As Boolean, 
    v_ValorDeprecial As Boolean, 
    v_ValorLibroAntRevalor As Boolean, 
    v_ValorLibroDespRevalo As Boolean
)
```
**Propósito**: Devolver datos de configuración (no usado en el código visible)

### `FSelect2(...)` - Inicializar Valores
```vb
Public Sub FSelect2(
    ByVal v_IdCuenta As String, 
    ByVal v_Cuenta As String, 
    ByVal v_DescCuenta As String, 
    ByVal v_ValorRazonable As String, 
    ByVal v_ValorInicial As String, 
    ByVal v_ValorDelBien As String, 
    ByVal v_ValorLibro As String, 
    ByVal v_ValorResidual As String, 
    ByVal v_ValorDeprecial As String, 
    ByVal v_ValorLibroAntRevalor As String, 
    ByVal v_ValorLibroDespRevalo As String
)
```
**Propósito**: Recibir valores calculados del activo antes de mostrar el form
**Comportamiento**: Asigna valores a variables de módulo y muestra form modal

### `FView()`
```vb
Public Sub FView()
```
**Propósito**: Mostrar form modal sin valores pre-inicializados

## ⚙️ Lógica de Negocio

### Bt_Aceptar_Click() - Agregar Línea
**Validaciones:**
1. Debe seleccionar cuenta (`Tx_Cuenta <> ""`)
2. Debe marcar Debe o Haber

**Proceso:**
1. Resetea acumuladores: `vDebe = 0`, `vHaber = 0`
2. Incrementa contador de fila: `i = i + 1`
3. Si `Ck_Debe = True`:
   - Por cada checkbox marcado:
     - Suma valor a `vDebe`
     - Desmarca checkbox
     - Deshabilita checkbox (`Enabled = False`)
   - Asigna `Grid.TextMatrix(i, C_DEBE) = Format(vDebe, NUMFMT)`
4. Si `Ck_Haber = True`:
   - Mismo proceso pero suma a `vHaber`
   - Asigna `Grid.TextMatrix(i, C_HABER) = Format(vHaber, NUMFMT)`
5. Completa columnas de cuenta:
   ```vb
   Grid.TextMatrix(i, C_CUENTA) = vCodCuenta
   Grid.TextMatrix(i, C_IDCUENTA) = vIdCuenta
   Grid.TextMatrix(i, C_DESCRCUENTA) = vDescCuenta
   ```
6. Agrega nueva fila: `Grid.rows = Grid.rows + 1`
7. Resetea controles: `Tx_Cuenta = ""`, `Ck_Debe = 0`, `Ck_Haber = 0`

**Importante**: Los checkboxes de valores se deshabilitan después de usarse para evitar reutilización.

### Bt_Comprobante_Click() - Crear Comprobante
**Proceso:**
1. Instancia `FrmComprobante`
2. Itera sobre todas las filas del grid (desde FixedRows hasta rows-2)
3. Por cada fila, llama:
   ```vb
   FrmComp.FNewCompActivo(
       i,                                  ' índice fila
       Val(Grid.Debe sin formato),         ' Debe como número
       Val(Grid.Haber sin formato),        ' Haber como número
       Grid.IdCuenta,
       Grid.Cuenta,
       Grid.DescrCuenta
   )
   ```
4. Muestra `FrmComprobante` modal
5. Libera objeto

**Conversión de Formato:**
```vb
Val(Replace(Replace(Grid.TextMatrix(i, C_DEBE), ".", ""), ",", ""))
```
Elimina separadores de miles (.) y decimales (,) antes de convertir

### Bt_Cuentas_Click() - Seleccionar Cuenta
**Proceso:**
1. Instancia `FrmPlanCuentas`
2. Llama `Frm.FSelect(IdCuenta, Codigo, Descrip, Nombre, False)`
3. Si retorna `vbOK`:
   - Obtiene clasificación: `ClasCta = GetClasCuenta(IdCuenta)`
   - Asigna a variables:
     ```vb
     vCodCuenta = Codigo
     Tx_Cuenta = Descrip
     vIdCuenta = IdCuenta
     vDescCuenta = Descrip
     ```

### Ck_Debe_Click() / Ck_Haber_Click()
**Exclusividad mutua:**
```vb
If Ck_Debe = 1 Then Ck_Haber = 0
If Ck_Haber = 1 Then Ck_Debe = 0
```

## 🔗 Integraciones

### FrmPlanCuentas.FSelect()
**Input**: Ninguno (modal selection)
**Output**: IdCuenta, Codigo, Descrip, Nombre
**Propósito**: Seleccionar cuenta contable del plan de cuentas

### FrmComprobante.FNewCompActivo()
**Input**: 
- i: índice línea
- vDebe: valor Debe
- vHaber: valor Haber
- IdCuenta: ID cuenta
- Cuenta: código cuenta
- DescrCuenta: descripción
**Propósito**: Agregar línea al comprobante en construcción

### GetClasCuenta()
**Input**: IdCuenta
**Output**: Clasificación de cuenta (Integer)
**Propósito**: Obtener clasificación contable de la cuenta (no usado visiblemente en el form)

## 📝 Notas Técnicas

### Valores como String
Los valores del activo (vValorRazonable, etc.) son declarados como `String` en VB6, pero se usan como números en las sumas. VB6 hace conversión implícita.

### Sin Persistencia
Este form NO interactúa con base de datos. Es puramente constructor temporal en memoria.

### Uso Típico
```vb
' Desde otro form:
Dim frm As FrmConfigCompActFijo
Set frm = New FrmConfigCompActFijo
Call frm.FSelect2(
    IdCuenta, Cuenta, DescCuenta,
    valorRazonable, valorInicial, valorBien,
    valorLibro, valorResidual, valorDepreciar,
    valorAntRevalor, valorDespRevalor
)
Set frm = Nothing
```

### Grid Acumulativo
El grid se llena línea por línea. Cada vez que se agrega una nueva línea:
- Los checkboxes usados se deshabilitan
- El contador `i` incrementa
- Se agrega nueva fila vacía al final

## 🎯 Migración a .NET

### Consideraciones:
1. **Estado en memoria**: Usar ViewModel en frontend para acumular líneas
2. **Checkboxes dinámicos**: Al agregar línea, deshabilitar checkboxes usados
3. **Suma de valores**: Calcular suma en frontend según checkboxes marcados
4. **Formato numérico**: Manejar formato chileno (punto miles, coma decimales)
5. **Integración comprobantes**: API endpoint para crear comprobante con líneas
6. **Plan de cuentas**: Modal/dropdown para selección de cuentas

### Entidades:
- NO usa entidades propias
- Lee de Plan de Cuentas
- Construye datos para Comprobantes

### API Endpoints Sugeridos:
- `GET /api/Cuentas/search?query=xxx` - buscar cuentas
- `POST /api/Comprobantes/crear-activo-fijo` - crear comprobante con líneas

### Frontend:
- Form con checkboxes de valores
- Grid editable/acumulativo
- Validación: cuenta seleccionada + debe/haber
- Botón "Agregar" acumula líneas
- Botón "Crear Comprobante" envía todo a API
