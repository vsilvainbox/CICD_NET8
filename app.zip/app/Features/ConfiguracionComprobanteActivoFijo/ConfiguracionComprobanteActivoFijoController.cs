using Microsoft.AspNetCore.Mvc;
using App.Helpers;
using App.Extensions;
using App.Features.PlanCuentas;

namespace App.Features.ConfiguracionComprobanteActivoFijo;


public class ConfiguracionComprobanteActivoFijoController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<ConfiguracionComprobanteActivoFijoController> logger) : Controller
{
    public IActionResult Index()
        {
            

            logger.LogInformation("Loading ConfiguracionComprobanteActivoFijo modal for empresaId: {EmpresaId}, ano: {Ano}", SessionHelper.EmpresaId, SessionHelper.Ano);

            return View();
        }

        /// <summary>
        /// Proxy para obtener plan de cuentas
        /// GET /ConfiguracionComprobanteActivoFijo/GetPlanCuentas
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> GetPlanCuentas(int empresaId, short ano)
        {
            logger.LogInformation("ConfiguracionComprobanteActivoFijo: GetPlanCuentas proxy called for empresaId={EmpresaId}, ano={Ano}", empresaId, ano);

            {
                var client = httpClientFactory.CreateClient("ApiClient");

                var url = linkGenerator.GetPathByAction(
                    action: nameof(PlanCuentasApiController.GetAll),
                    controller: nameof(PlanCuentasApiController).Replace("Controller", ""),
                    values: new { empresaId, ano }
                );
                var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
            }
        }
    }
