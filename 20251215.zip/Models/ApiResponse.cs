namespace App.Models;

/// <summary>
/// Estructura de respuesta API unificada
/// Todos los API Controllers deben retornar este formato
/// </summary>
public class ApiResponse
{
    public bool Success { get; set; }

    /// <summary>
    /// Tipo de error: "Validation" | "System" | null si Success=true
    /// </summary>
    public string? ErrorType { get; set; }

    /// <summary>
    /// Lista de errores de validación
    /// </summary>
    public List<string>? Errors { get; set; }

    /// <summary>
    /// Mensaje general (éxito o error)
    /// </summary>
    public string? Message { get; set; }

    /// <summary>
    /// Crea respuesta exitosa
    /// </summary>
    public static ApiResponse Ok(string? message = null) => new()
    {
        Success = true,
        Message = message
    };

    /// <summary>
    /// Crea respuesta de error de validación
    /// </summary>
    public static ApiResponse ValidationError(params string[] errors) => new()
    {
        Success = false,
        ErrorType = "Validation",
        Errors = errors.ToList()
    };

    /// <summary>
    /// Crea respuesta de error de validación desde lista
    /// </summary>
    public static ApiResponse ValidationError(List<string> errors) => new()
    {
        Success = false,
        ErrorType = "Validation",
        Errors = errors
    };
}

/// <summary>
/// Respuesta API con datos tipados
/// </summary>
public class ApiResponse<T> : ApiResponse
{
    /// <summary>
    /// Datos de respuesta
    /// </summary>
    public T? Data { get; set; }

    /// <summary>
    /// Crea respuesta exitosa con datos
    /// </summary>
    public static ApiResponse<T> Ok(T data, string? message = null) => new()
    {
        Success = true,
        Data = data,
        Message = message
    };
}
