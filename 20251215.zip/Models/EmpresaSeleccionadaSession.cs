namespace App.Models;

/// <summary>
/// Modelo para almacenar información de la empresa y año seleccionados en sesión
/// </summary>
public class EmpresaSeleccionadaSession
{
    public int IdEmpresa { get; set; }
    public string Rut { get; set; } = string.Empty;
    public string NombreCorto { get; set; } = string.Empty;
    public short Ano { get; set; }
    public int? IdPerfil { get; set; }
    public string Privilegios { get; set; } = string.Empty;
}
