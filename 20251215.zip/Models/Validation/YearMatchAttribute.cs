using System.ComponentModel.DataAnnotations;
using App.Helpers;

namespace App.Models.Validation;

/// <summary>
/// Valida que una fecha pertenezca al año contable actual de la sesión.
/// Usado para campos de fecha en documentos contables.
/// </summary>
/// <remarks>
/// Reemplaza validaciones JS como:
/// if (year !== CONFIG.ano) { Swal.fire('Advertencia', `La fecha no pertenece al año ${CONFIG.ano}`); }
/// </remarks>
[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false)]
public class YearMatchAttribute : ValidationAttribute
{
    /// <summary>
    /// Si es true, permite que el valor sea null sin error (usar [Required] para hacerlo obligatorio)
    /// </summary>
    public bool AllowNull { get; set; } = true;

    public YearMatchAttribute() : base("La fecha debe pertenecer al año contable actual")
    {
    }

    protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
    {
        if (value == null)
        {
            return AllowNull ? ValidationResult.Success : new ValidationResult("La fecha es obligatoria");
        }

        DateTime date;

        // Soportar DateTime y formatos numéricos (yyyyMMdd)
        if (value is DateTime dt)
        {
            date = dt;
        }
        else if (value is int intDate)
        {
            // Formato yyyyMMdd (ej: 20250115)
            var year = intDate / 10000;
            var month = (intDate % 10000) / 100;
            var day = intDate % 100;
            
            try
            {
                date = new DateTime(year, month, day);
            }
            catch
            {
                return new ValidationResult("Formato de fecha inválido");
            }
        }
        else if (value is long longDate)
        {
            var year = (int)(longDate / 10000);
            var month = (int)((longDate % 10000) / 100);
            var day = (int)(longDate % 100);
            
            try
            {
                date = new DateTime(year, month, day);
            }
            catch
            {
                return new ValidationResult("Formato de fecha inválido");
            }
        }
        else
        {
            return new ValidationResult("Tipo de fecha no soportado");
        }

        // Obtener año de sesión
        var sessionYear = SessionHelper.Ano;
        
        if (sessionYear <= 0)
        {
            // Si no hay año en sesión, no validar (el controller debe manejar esto)
            return ValidationResult.Success;
        }

        if (date.Year != sessionYear)
        {
            return new ValidationResult(
                ErrorMessage ?? $"La fecha debe pertenecer al año {sessionYear}");
        }

        return ValidationResult.Success;
    }
}

