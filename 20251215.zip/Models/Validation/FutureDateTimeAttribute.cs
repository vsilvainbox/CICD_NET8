using System.ComponentModel.DataAnnotations;

namespace App.Models.Validation;

/// <summary>
/// Valida que una fecha y hora sea posterior al momento actual.
/// Usado para campos como "FechaSincroniza" en sincronizaciones SII.
/// </summary>
/// <remarks>
/// Reemplaza validaciones JS como:
/// if (fechaSincroniza <= fechaActual) { Swal.fire('Fecha inválida', '...', 'info'); }
/// </remarks>
[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false)]
public class FutureDateTimeAttribute : ValidationAttribute
{
    public FutureDateTimeAttribute() : base("La fecha y hora deben ser posteriores al momento actual")
    {
    }

    protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
    {
        if (value == null)
        {
            return ValidationResult.Success; // Null es válido (usar [Required] si es obligatorio)
        }

        if (value is DateTime dateTime)
        {
            if (dateTime <= DateTime.Now)
            {
                return new ValidationResult(ErrorMessage ?? "La fecha y hora deben ser posteriores al momento actual");
            }
        }

        return ValidationResult.Success;
    }
}

