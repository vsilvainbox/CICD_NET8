using System.ComponentModel.DataAnnotations;

namespace App.Models.Validation;

/// <summary>
/// Valida que una fecha sea posterior a hoy.
/// Usado para campos como "HabilitadoHasta" en usuarios fiscalizadores.
/// </summary>
/// <remarks>
/// Reemplaza validaciones JS como:
/// if (fechaDate < today) { Swal.fire('Validación', 'Fecha inválida...', 'warning'); }
/// </remarks>
[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false)]
public class FutureDateAttribute : ValidationAttribute
{
    public bool AllowToday { get; set; } = false;

    public FutureDateAttribute() : base("La fecha debe ser posterior a hoy")
    {
    }

    protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
    {
        if (value == null)
        {
            return ValidationResult.Success; // Null es válido (usar [Required] si es obligatorio)
        }

        if (value is DateTime date)
        {
            var today = DateTime.Today;
            
            if (AllowToday)
            {
                if (date < today)
                {
                    return new ValidationResult(ErrorMessage ?? "La fecha debe ser hoy o posterior");
                }
            }
            else
            {
                if (date <= today)
                {
                    return new ValidationResult(ErrorMessage ?? "La fecha debe ser posterior a hoy");
                }
            }
        }

        return ValidationResult.Success;
    }
}

