using System.ComponentModel.DataAnnotations;

namespace App.Models.Validation;

/// <summary>
/// Valida que un valor numérico no sea cero.
/// Útil para campos como "Total" que deben ser mayor a cero.
/// </summary>
/// <remarks>
/// Reemplaza validaciones JS como:
/// if (!documento.total || documento.total <= 0) { Swal.fire('Advertencia', 'El total debe ser mayor a cero'); }
/// </remarks>
[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false)]
public class NotZeroAttribute : ValidationAttribute
{
    /// <summary>
    /// Si es true, solo valida que no sea cero (permite negativos)
    /// Si es false (default), valida que sea mayor a cero
    /// </summary>
    public bool AllowNegative { get; set; } = false;

    public NotZeroAttribute() : base("El valor debe ser mayor a cero")
    {
    }

    protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
    {
        if (value == null)
        {
            return ValidationResult.Success; // Null es válido (usar [Required] si es obligatorio)
        }

        // Convertir a decimal para comparación precisa
        decimal numericValue;

        try
        {
            numericValue = Convert.ToDecimal(value);
        }
        catch
        {
            return new ValidationResult("El valor debe ser numérico");
        }

        if (AllowNegative)
        {
            if (numericValue == 0)
            {
                return new ValidationResult(ErrorMessage ?? "El valor no puede ser cero");
            }
        }
        else
        {
            if (numericValue <= 0)
            {
                return new ValidationResult(ErrorMessage ?? "El valor debe ser mayor a cero");
            }
        }

        return ValidationResult.Success;
    }
}

