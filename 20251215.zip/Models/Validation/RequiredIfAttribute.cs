using System.ComponentModel.DataAnnotations;

namespace App.Models.Validation;

/// <summary>
/// Hace un campo requerido condicionalmente basado en el valor de otro campo.
/// Útil para validaciones como "Si TipoDoc = NC, entonces IdDocAsoc es requerido".
/// </summary>
/// <remarks>
/// Reemplaza validaciones JS condicionales como:
/// if (tipoDoc === 'NC' && !idDocAsoc) { Swal.fire('Advertencia', 'Debe seleccionar documento asociado'); }
/// </remarks>
[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = true)]
public class RequiredIfAttribute : ValidationAttribute
{
    private readonly string _dependentProperty;
    private readonly object? _targetValue;
    private readonly ComparisonType _comparisonType;

    public enum ComparisonType
    {
        Equals,
        NotEquals,
        GreaterThan,
        LessThan,
        IsNotNull,
        IsNull
    }

    /// <summary>
    /// Hace el campo requerido si el campo dependiente tiene el valor especificado
    /// </summary>
    /// <param name="dependentProperty">Nombre de la propiedad de la cual depende</param>
    /// <param name="targetValue">Valor que activa el requerimiento</param>
    /// <param name="comparisonType">Tipo de comparación (default: Equals)</param>
    public RequiredIfAttribute(string dependentProperty, object? targetValue, ComparisonType comparisonType = ComparisonType.Equals)
        : base("Este campo es obligatorio")
    {
        _dependentProperty = dependentProperty;
        _targetValue = targetValue;
        _comparisonType = comparisonType;
    }

    protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
    {
        // Obtener el valor de la propiedad dependiente
        var dependentPropertyInfo = validationContext.ObjectType.GetProperty(_dependentProperty);
        
        if (dependentPropertyInfo == null)
        {
            return new ValidationResult($"Propiedad dependiente '{_dependentProperty}' no encontrada");
        }

        var dependentValue = dependentPropertyInfo.GetValue(validationContext.ObjectInstance);

        // Evaluar si la condición se cumple
        var conditionMet = _comparisonType switch
        {
            ComparisonType.Equals => AreEqual(dependentValue, _targetValue),
            ComparisonType.NotEquals => !AreEqual(dependentValue, _targetValue),
            ComparisonType.GreaterThan => Compare(dependentValue, _targetValue) > 0,
            ComparisonType.LessThan => Compare(dependentValue, _targetValue) < 0,
            ComparisonType.IsNotNull => dependentValue != null,
            ComparisonType.IsNull => dependentValue == null,
            _ => false
        };

        // Si la condición se cumple, el campo actual es requerido
        if (conditionMet)
        {
            if (value == null || (value is string str && string.IsNullOrWhiteSpace(str)))
            {
                return new ValidationResult(ErrorMessage);
            }
        }

        return ValidationResult.Success;
    }

    private static bool AreEqual(object? value1, object? value2)
    {
        if (value1 == null && value2 == null)
            return true;
        
        if (value1 == null || value2 == null)
            return false;

        // Intentar comparación de tipos compatibles
        try
        {
            if (value1.GetType() != value2.GetType())
            {
                // Convertir value2 al tipo de value1
                var converted = Convert.ChangeType(value2, value1.GetType());
                return value1.Equals(converted);
            }
            return value1.Equals(value2);
        }
        catch
        {
            return value1.ToString() == value2.ToString();
        }
    }

    private static int Compare(object? value1, object? value2)
    {
        if (value1 == null || value2 == null)
            return 0;

        if (value1 is IComparable comparable1)
        {
            try
            {
                var converted = Convert.ChangeType(value2, value1.GetType());
                return comparable1.CompareTo(converted);
            }
            catch
            {
                return 0;
            }
        }

        return 0;
    }
}

