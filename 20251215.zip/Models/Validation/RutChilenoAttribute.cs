using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace App.Models.Validation;

/// <summary>
/// Valida el formato y dígito verificador de un RUT chileno.
/// Acepta formatos: 12345678-9, 12.345.678-9, 123456789
/// </summary>
/// <remarks>
/// Reemplaza validaciones JS como:
/// if (!/[0-9Kk\-]/.test(char)) { e.preventDefault(); }
/// Y validaciones de formato de RUT en cliente.
/// </remarks>
[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false)]
public class RutChilenoAttribute : ValidationAttribute
{
    /// <summary>
    /// Si es true, valida el dígito verificador además del formato
    /// </summary>
    public bool ValidateCheckDigit { get; set; } = true;

    /// <summary>
    /// Si es true, permite RUTs especiales como 0-0 o RUTs de prueba
    /// </summary>
    public bool AllowSpecialRuts { get; set; } = false;

    public RutChilenoAttribute() : base("Formato de RUT inválido")
    {
    }

    protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
    {
        if (value == null || string.IsNullOrWhiteSpace(value.ToString()))
        {
            return ValidationResult.Success; // Null es válido (usar [Required] si es obligatorio)
        }

        var rut = value.ToString()!;

        // Limpiar el RUT (quitar puntos y espacios)
        rut = rut.Replace(".", "").Replace(" ", "").Trim().ToUpper();

        // Validar formato básico
        if (!Regex.IsMatch(rut, @"^\d{1,8}-?[\dK]$"))
        {
            return new ValidationResult(ErrorMessage ?? "Formato de RUT inválido (ej: 12345678-9)");
        }

        // Separar número y dígito verificador
        string numero;
        string dv;

        if (rut.Contains('-'))
        {
            var parts = rut.Split('-');
            numero = parts[0];
            dv = parts[1];
        }
        else
        {
            numero = rut[..^1];
            dv = rut[^1..];
        }

        // Validar que el número tenga al menos 1 dígito
        if (string.IsNullOrEmpty(numero) || !long.TryParse(numero, out var rutNumero))
        {
            return new ValidationResult(ErrorMessage ?? "El RUT debe contener números válidos");
        }

        // RUTs especiales
        if (AllowSpecialRuts && rutNumero == 0)
        {
            return ValidationResult.Success;
        }

        // Validar rango razonable de RUT
        if (rutNumero < 1000000 || rutNumero > 99999999)
        {
            // Permitir RUTs de empresas (mayores) y personas (menores)
            // pero rechazar valores claramente inválidos
            if (rutNumero < 100000)
            {
                return new ValidationResult("El RUT parece ser muy corto");
            }
        }

        // Validar dígito verificador si está habilitado
        if (ValidateCheckDigit)
        {
            var dvCalculado = CalcularDigitoVerificador(rutNumero);
            if (dv != dvCalculado)
            {
                return new ValidationResult("El dígito verificador del RUT es incorrecto");
            }
        }

        return ValidationResult.Success;
    }

    /// <summary>
    /// Calcula el dígito verificador de un RUT usando el algoritmo módulo 11
    /// </summary>
    private static string CalcularDigitoVerificador(long rut)
    {
        var suma = 0;
        var multiplicador = 2;

        while (rut > 0)
        {
            suma += (int)(rut % 10) * multiplicador;
            rut /= 10;
            multiplicador++;
            if (multiplicador > 7)
            {
                multiplicador = 2;
            }
        }

        var resto = suma % 11;
        var digito = 11 - resto;

        return digito switch
        {
            11 => "0",
            10 => "K",
            _ => digito.ToString()
        };
    }

    /// <summary>
    /// Método estático para validar un RUT desde cualquier parte del código
    /// </summary>
    public static bool IsValidRut(string? rut, bool validateCheckDigit = true)
    {
        if (string.IsNullOrWhiteSpace(rut))
            return false;

        var attr = new RutChilenoAttribute { ValidateCheckDigit = validateCheckDigit };
        var result = attr.GetValidationResult(rut, new ValidationContext(rut));
        return result == ValidationResult.Success;
    }

    /// <summary>
    /// Formatea un RUT al formato estándar (12.345.678-9)
    /// </summary>
    public static string? FormatRut(string? rut)
    {
        if (string.IsNullOrWhiteSpace(rut))
            return rut;

        // Limpiar
        rut = rut.Replace(".", "").Replace("-", "").Replace(" ", "").Trim().ToUpper();

        if (rut.Length < 2)
            return rut;

        var numero = rut[..^1];
        var dv = rut[^1..];

        // Formatear con puntos
        if (long.TryParse(numero, out var num))
        {
            return $"{num:N0}".Replace(",", ".") + "-" + dv;
        }

        return rut;
    }
}

