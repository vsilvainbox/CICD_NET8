namespace App.Models.Auth;

/// <summary>
/// Datos completos de la sesión del usuario
/// </summary>
public class SessionData
{
    public UsuarioSession? Usuario { get; set; }
    public EmpresaSession? Empresa { get; set; }
    public bool TieneEmpresaSeleccionada => Empresa != null;
}
