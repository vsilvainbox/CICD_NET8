namespace App.Models.Auth;

/// <summary>
/// Resultado del proceso de login
/// </summary>
public class LoginResult
{
    public bool Success { get; set; }
    public string? ErrorMessage { get; set; }
    public UsuarioSession? Usuario { get; set; }

    public static LoginResult Fail(string errorMessage)
    {
        return new LoginResult
        {
            Success = false,
            ErrorMessage = errorMessage
        };
    }

    public static LoginResult Succeed(UsuarioSession usuario)
    {
        return new LoginResult
        {
            Success = true,
            Usuario = usuario
        };
    }
}
