namespace App.Models.Auth;

/// <summary>
/// Resultado de la validación de contraseña (híbrido VB6/bcrypt)
/// </summary>
public class PasswordValidationResult
{
    public bool IsValid { get; set; }
    public bool UsedModernHash { get; set; }
    public bool RequiresMigration { get; set; }
    public string? ErrorMessage { get; set; }
}
