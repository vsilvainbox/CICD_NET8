namespace App.Models.Auth;

/// <summary>
/// Información de la empresa/año seleccionado en sesión
/// Replica la estructura gEmpresa de VB6
/// </summary>
public class EmpresaSession
{
    public int IdEmpresa { get; set; }
    public string Rut { get; set; } = string.Empty;
    public string NombreCorto { get; set; } = string.Empty;
    public int Ano { get; set; }
    public DateTime? FCierre { get; set; }
    public DateTime? FApertura { get; set; }
}
