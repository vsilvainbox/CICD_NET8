namespace App.Models.Auth;

/// <summary>
/// Información del usuario en sesión
/// Replica la estructura gUsuario de VB6
/// </summary>
public class UsuarioSession
{
    public int IdUsuario { get; set; }
    public string Usuario { get; set; } = string.Empty;
    public string? NombreLargo { get; set; }
    public bool EsAdmin { get; set; }
    public int? IdPerfilActual { get; set; }
    public string? NombrePerfilActual { get; set; }
    public int PrivilegiosActuales { get; set; }
}
