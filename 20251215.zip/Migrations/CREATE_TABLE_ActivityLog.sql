-- ============================================
-- Tabla: ActivityLog
-- Propósito: Registro de actividad de usuarios en el sistema
-- Autor: Sistema de Auditoría
-- Fecha: 2025-01-24
-- ============================================

-- Verificar si la tabla ya existe
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ActivityLog]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[ActivityLog]
    (
        [IdActivity] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        [Timestamp] DATETIME NOT NULL DEFAULT GETDATE(),
        [UsuarioId] INT NULL,
        [UserName] NVARCHAR(100) NULL,
        [EmpresaId] INT NULL,
        [IpAddress] NVARCHAR(50) NULL,
        [Host] NVARCHAR(200) NULL,
        [Url] NVARCHAR(500) NOT NULL,
        [Method] NVARCHAR(10) NOT NULL,
        [StatusCode] INT NULL,
        [Duration] INT NULL,
        [RequestBody] NVARCHAR(MAX) NULL,
        [UserAgent] NVARCHAR(500) NULL
    );

    PRINT '✅ Tabla ActivityLog creada exitosamente';
END
ELSE
BEGIN
    PRINT '⚠️ La tabla ActivityLog ya existe';
END
GO

-- Crear índices para optimizar consultas
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_ActivityLog_Timestamp' AND object_id = OBJECT_ID('ActivityLog'))
BEGIN
    CREATE NONCLUSTERED INDEX [IX_ActivityLog_Timestamp]
    ON [dbo].[ActivityLog] ([Timestamp] DESC);
    PRINT '✅ Índice IX_ActivityLog_Timestamp creado';
END
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_ActivityLog_UsuarioId' AND object_id = OBJECT_ID('ActivityLog'))
BEGIN
    CREATE NONCLUSTERED INDEX [IX_ActivityLog_UsuarioId]
    ON [dbo].[ActivityLog] ([UsuarioId]);
    PRINT '✅ Índice IX_ActivityLog_UsuarioId creado';
END
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_ActivityLog_Method' AND object_id = OBJECT_ID('ActivityLog'))
BEGIN
    CREATE NONCLUSTERED INDEX [IX_ActivityLog_Method]
    ON [dbo].[ActivityLog] ([Method]);
    PRINT '✅ Índice IX_ActivityLog_Method creado';
END
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_ActivityLog_EmpresaId' AND object_id = OBJECT_ID('ActivityLog'))
BEGIN
    CREATE NONCLUSTERED INDEX [IX_ActivityLog_EmpresaId]
    ON [dbo].[ActivityLog] ([EmpresaId]);
    PRINT '✅ Índice IX_ActivityLog_EmpresaId creado';
END
GO

-- Queries útiles para consultar la actividad
PRINT '
============================================
QUERIES ÚTILES
============================================

-- Ver últimas 20 actividades
SELECT TOP 20
    IdActivity,
    Timestamp,
    UserName,
    EmpresaId,
    Method,
    Url,
    StatusCode,
    Duration
FROM ActivityLog
ORDER BY Timestamp DESC;

-- Ver actividad de un usuario específico
SELECT *
FROM ActivityLog
WHERE UsuarioId = 1  -- Reemplazar con ID del usuario
ORDER BY Timestamp DESC;

-- Ver actividad por método HTTP
SELECT Method, COUNT(*) as Total
FROM ActivityLog
GROUP BY Method
ORDER BY Total DESC;

-- Ver requests más lentos
SELECT TOP 10
    Timestamp,
    UserName,
    Method,
    Url,
    Duration,
    StatusCode
FROM ActivityLog
WHERE Duration IS NOT NULL
ORDER BY Duration DESC;

-- Ver actividad de hoy
SELECT *
FROM ActivityLog
WHERE CAST(Timestamp AS DATE) = CAST(GETDATE() AS DATE)
ORDER BY Timestamp DESC;

-- Ver errores (StatusCode 4xx y 5xx)
SELECT *
FROM ActivityLog
WHERE StatusCode >= 400
ORDER BY Timestamp DESC;

-- Estadísticas por hora
SELECT
    DATEPART(HOUR, Timestamp) as Hora,
    COUNT(*) as TotalRequests,
    AVG(Duration) as DuracionPromedio
FROM ActivityLog
WHERE CAST(Timestamp AS DATE) = CAST(GETDATE() AS DATE)
GROUP BY DATEPART(HOUR, Timestamp)
ORDER BY Hora;
';
GO

PRINT '✅ Script ejecutado completamente';
