-- Migración: Agregar columnas para bcrypt
-- Fecha: 2025-10-05
-- Descripción: Agregar columnas PasswordHash y RequiereCambioPassword para migración a bcrypt

BEGIN TRANSACTION;

  -- Verificar y agregar columna para hash bcrypt si no existe
  IF NOT EXISTS (
      SELECT 1
      FROM sys.columns
      WHERE object_id = OBJECT_ID('Usuarios')
      AND name = 'PasswordHash'
  )
BEGIN
ALTER TABLE Usuarios ADD PasswordHash NVARCHAR(255) NULL;
END

  -- Verificar y agregar columna para forzar cambio de contraseña si no existe
  IF NOT EXISTS (
      SELECT 1
      FROM sys.columns
      WHERE object_id = OBJECT_ID('Usuarios')
      AND name = 'RequiereCambioPassword'
  )
BEGIN
ALTER TABLE Usuarios ADD RequiereCambioPassword BIT NOT NULL DEFAULT 0;
END

  -- Crear índice para performance de búsquedas por PasswordHash
  IF NOT EXISTS (
      SELECT 1
      FROM sys.indexes
      WHERE object_id = OBJECT_ID('Usuarios')
      AND name = 'idx_usuarios_passwordhash'
  )
BEGIN
EXEC sp_executesql N'CREATE NONCLUSTERED INDEX idx_usuarios_passwordhash ON Usuarios(PasswordHash) WHERE PasswordHash IS NOT NULL;';
END

COMMIT TRANSACTION;