-- Tabla para registro de errores del sistema (Frontend y Backend)
-- VERSION PARA SQL SERVER
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ErrorLog]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[ErrorLog] (
        [IdError] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        [Timestamp] DATETIME2 NOT NULL DEFAULT GETDATE(),
        [Source] NVARCHAR(50) NOT NULL,                    -- 'Frontend' o 'Backend'
        [Severity] NVARCHAR(20) NOT NULL,                  -- 'Error', 'Warning', 'Critical'
        [Message] NVARCHAR(2000) NOT NULL,                 -- Mensaje del error
        [StackTrace] NVARCHAR(MAX) NULL,                   -- Stack trace completo
        [Url] NVARCHAR(500) NULL,                          -- URL donde ocurrió el error
        [UserAgent] NVARCHAR(500) NULL,                    -- User-Agent del navegador
        [UsuarioId] INT NULL,                              -- ID del usuario (si está logueado)
        [EmpresaId] INT NULL,                              -- ID de la empresa activa
        [AdditionalData] NVARCHAR(MAX) NULL,               -- JSON con datos adicionales
        [IPAddress] NVARCHAR(50) NULL,                     -- Dirección IP del cliente
        [ExceptionType] NVARCHAR(200) NULL,                -- Tipo de excepción
        [Resolved] BIT NOT NULL DEFAULT 0,                 -- 0 = No resuelto, 1 = Resuelto
        [ResolvedBy] INT NULL,                             -- ID usuario que marcó como resuelto
        [ResolvedAt] DATETIME2 NULL,                       -- Fecha de resolución
        [Notes] NVARCHAR(1000) NULL                        -- Notas sobre la resolución
    );

    -- Índices para mejorar rendimiento de consultas
    CREATE INDEX IX_ErrorLog_Timestamp ON [dbo].[ErrorLog]([Timestamp] DESC);
    CREATE INDEX IX_ErrorLog_Source ON [dbo].[ErrorLog]([Source]);
    CREATE INDEX IX_ErrorLog_Severity ON [dbo].[ErrorLog]([Severity]);
    CREATE INDEX IX_ErrorLog_Resolved ON [dbo].[ErrorLog]([Resolved]);
    CREATE INDEX IX_ErrorLog_UsuarioId ON [dbo].[ErrorLog]([UsuarioId]);
    CREATE INDEX IX_ErrorLog_EmpresaId ON [dbo].[ErrorLog]([EmpresaId]);

    -- Índice compuesto para consultas frecuentes
    CREATE INDEX IX_ErrorLog_Resolved_Timestamp ON [dbo].[ErrorLog]([Resolved], [Timestamp] DESC);

    PRINT 'Tabla ErrorLog creada exitosamente';
END
ELSE
BEGIN
    PRINT 'La tabla ErrorLog ya existe';
END
GO

