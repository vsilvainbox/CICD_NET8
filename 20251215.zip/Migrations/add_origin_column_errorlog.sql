-- Agregar columna Origin a la tabla ErrorLog
-- Esta columna almacena el origen específico del error (ej: 'CuentasController', 'MovComprobante', etc.)
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[ErrorLog]') AND name = 'Origin')
BEGIN
    ALTER TABLE [dbo].[ErrorLog] ADD [Origin] NVARCHAR(100) NOT NULL DEFAULT '';
    
    -- Índice para búsquedas por origen
    CREATE INDEX IX_ErrorLog_Origin ON [dbo].[ErrorLog]([Origin]);
    
    PRINT 'Columna Origin agregada a ErrorLog exitosamente';
END
ELSE
BEGIN
    PRINT 'La columna Origin ya existe en ErrorLog';
END
GO

