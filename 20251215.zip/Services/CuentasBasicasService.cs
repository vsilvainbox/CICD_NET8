using App.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace App.Services;

/// <summary>
/// Servicio para gestionar cuentas básicas y configuración de cuentas por defecto
/// Migrado desde VB6: LoadDefCuentasRet y funciones relacionadas
/// </summary>
public class CuentasBasicasService : ICuentasBasicasService
{
    private readonly LpContabContext context;
    private readonly ILogger<CuentasBasicasService> logger;

    // Constantes de tipos de valor para cuentas básicas (desde VB6)
    public const int LIBRETEN_BRUTO = 1;
    public const int LIBRETEN_HONORSINRET = 2;

    public CuentasBasicasService(LpContabContext context, ILogger<CuentasBasicasService> logger)
    {
        this.context = context;
        this.logger = logger;
    }

    /// <summary>
    /// Obtiene la cuenta por defecto para retenciones según el tipo
    /// Migrado desde VB6: LoadDefCuentasRet
    /// Archivo: vb6/Contabilidad70/HyperContabilidad/ImportLibComprasVentasSII.bas líneas 5290-5318
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año contable</param>
    /// <param name="tipoValor">Tipo de valor (LIBRETEN_BRUTO o LIBRETEN_HONORSINRET)</param>
    /// <param name="tipoLib">Tipo de libro (3 = Retenciones)</param>
    /// <returns>ID de la cuenta configurada o 0 si no existe</returns>
    public async Task<int> LoadDefCuentasRetAsync(int empresaId, int ano, int tipoValor, int tipoLib)
    {
        {
            // Query VB6:
            // SELECT CuentasBasicas.IdCuenta, Cuentas.Codigo, Cuentas.Nombre, Cuentas.Descripcion, TipoValor
            // FROM CuentasBasicas INNER JOIN Cuentas ON CuentasBasicas.IdCuenta = Cuentas.IdCuenta
            // WHERE TipoLib = {tipoLib} AND TipoValor = {tipoValor}
            // AND CuentasBasicas.IdEmpresa = {empresaId} AND CuentasBasicas.Ano = {ano}

            var cuentaBasica = await context.CuentasBasicas
                .Where(cb => 
                    cb.TipoLib == tipoLib && 
                    cb.TipoValor == tipoValor &&
                    cb.IdEmpresa == empresaId && 
                    cb.Ano == ano)
                .Select(cb => cb.IdCuenta)
                .FirstOrDefaultAsync();

            if (cuentaBasica == 0)
            {
                logger.LogWarning(
                    "No se encontró cuenta básica configurada: TipoLib={TipoLib}, TipoValor={TipoValor}, Empresa={EmpresaId}, Ano={Ano}",
                    tipoLib, tipoValor, empresaId, ano);
            }

            return cuentaBasica ?? 0;
        }
    }

    /// <summary>
    /// Valida que existan las cuentas básicas configuradas para retenciones
    /// Migrado desde VB6: FrmImpLibRetencionesSII.frm línea 324
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año contable</param>
    /// <returns>True si están configuradas, False si falta alguna</returns>
    public async Task<(bool IsValid, string ErrorMessage)> ValidarCuentasRetencionesAsync(int empresaId, int ano)
    {
        const int LIB_RETEN = 3;

        {
            // Validar cuenta para Bruto (Honorarios con retención)
            var cuentaBruto = await LoadDefCuentasRetAsync(empresaId, ano, LIBRETEN_BRUTO, LIB_RETEN);
            
            // Validar cuenta para Honorarios sin retención
            var cuentaHonSinRet = await LoadDefCuentasRetAsync(empresaId, ano, LIBRETEN_HONORSINRET, LIB_RETEN);

            if (cuentaBruto == 0 || cuentaHonSinRet == 0)
            {
                var mensaje = "Favor ingresar las Cuentas del Libro de Retenciones en la Configuración de Cuentas Básicas.";
                
                if (cuentaBruto == 0 && cuentaHonSinRet == 0)
                {
                    mensaje += " Faltan: Cuenta Bruto y Cuenta Honorarios sin Retención.";
                }
                else if (cuentaBruto == 0)
                {
                    mensaje += " Falta: Cuenta Bruto (Honorarios con retención).";
                }
                else
                {
                    mensaje += " Falta: Cuenta Honorarios sin Retención.";
                }

                logger.LogWarning(
                    "Validación de cuentas retenciones falló: Empresa={EmpresaId}, Ano={Ano}, CuentaBruto={CuentaBruto}, CuentaHonSinRet={CuentaHonSinRet}",
                    empresaId, ano, cuentaBruto, cuentaHonSinRet);

                return (false, mensaje);
            }

            return (true, string.Empty);
        }
    }

    /// <summary>
    /// Valida que existan las cuentas básicas configuradas para compras/ventas
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año contable</param>
    /// <param name="tipoLib">Tipo de libro (1=Compras, 2=Ventas)</param>
    /// <returns>True si están configuradas, False si falta alguna</returns>
    public async Task<(bool IsValid, string ErrorMessage)> ValidarCuentasLibroAsync(int empresaId, int ano, int tipoLib)
    {
        {
            // Obtener cuentas básicas del libro
            var cuentasLibro = await context.CuentasBasicas
                .Where(cb => 
                    cb.TipoLib == tipoLib &&
                    cb.IdEmpresa == empresaId && 
                    cb.Ano == ano)
                .ToListAsync();

            if (!cuentasLibro.Any())
            {
                var nombreLibro = tipoLib == 1 ? "Compras" : "Ventas";
                var mensaje = $"Falta definir las cuentas por omisión para el libro de {nombreLibro} " +
                             "(Afecto, Exento y Total). Configure las cuentas en Configuración >> Cuentas Básicas.";

                logger.LogWarning(
                    "No se encontraron cuentas básicas para libro: TipoLib={TipoLib}, Empresa={EmpresaId}, Ano={Ano}",
                    tipoLib, empresaId, ano);

                return (false, mensaje);
            }

            // Verificar que existan al menos las cuentas principales
            var tieneAfecto = cuentasLibro.Any(c => c.TipoValor == 1); // Afecto
            var tieneExento = cuentasLibro.Any(c => c.TipoValor == 2); // Exento
            var tieneTotal = cuentasLibro.Any(c => c.TipoValor == 3);  // Total

            if (!tieneAfecto || !tieneExento || !tieneTotal)
            {
                var nombreLibro = tipoLib == 1 ? "Compras" : "Ventas";
                var faltantes = new List<string>();
                if (!tieneAfecto) faltantes.Add("Afecto");
                if (!tieneExento) faltantes.Add("Exento");
                if (!tieneTotal) faltantes.Add("Total");

                var mensaje = $"Faltan cuentas básicas para el libro de {nombreLibro}: {string.Join(", ", faltantes)}. " +
                             "Configure las cuentas en Configuración >> Cuentas Básicas.";

                logger.LogWarning(
                    "Cuentas básicas incompletas para libro: TipoLib={TipoLib}, Faltantes={Faltantes}",
                    tipoLib, string.Join(", ", faltantes));

                return (false, mensaje);
            }

            return (true, string.Empty);
        }
    }

    /// <summary>
    /// Obtiene todas las cuentas básicas configuradas para una empresa y año
    /// </summary>
    public async Task<List<CuentaBasicaDto>> GetCuentasBasicasAsync(int empresaId, int ano)
    {
        {
            var cuentas = await context.CuentasBasicas
                .Where(cb => cb.IdEmpresa == empresaId && cb.Ano == ano)
                .Join(context.Cuentas,
                    cb => cb.IdCuenta,
                    c => c.idCuenta,
                    (cb, c) => new CuentaBasicaDto
                    {
                        IdCuenta = cb.IdCuenta ?? 0,
                        TipoLib = cb.TipoLib ?? 0,
                        TipoValor = cb.TipoValor ?? 0,
                        Codigo = c.Codigo,
                        Descripcion = c.Descripcion
                    })
                .ToListAsync();

            return cuentas;
        }
    }
}

public interface ICuentasBasicasService
{
    Task<int> LoadDefCuentasRetAsync(int empresaId, int ano, int tipoValor, int tipoLib);
    Task<(bool IsValid, string ErrorMessage)> ValidarCuentasRetencionesAsync(int empresaId, int ano);
    Task<(bool IsValid, string ErrorMessage)> ValidarCuentasLibroAsync(int empresaId, int ano, int tipoLib);
    Task<List<CuentaBasicaDto>> GetCuentasBasicasAsync(int empresaId, int ano);
}

public class CuentaBasicaDto
{
    public int IdCuenta { get; set; }
    public int TipoLib { get; set; }
    public int TipoValor { get; set; }
    public string? Codigo { get; set; }
    public string? Descripcion { get; set; }
}

