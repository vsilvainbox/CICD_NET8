using Microsoft.EntityFrameworkCore;
using App.Data;
using App.Helpers;

namespace App.Services;

/// <summary>
/// Servicio de autorización para validar acceso a empresas
/// Implementa la lógica de seguridad del VB6 (UsuarioEmpresa + Perfiles)
/// </summary>
public interface ICompanyAuthorizationService
{
    /// <summary>
    /// Valida que el usuario actual tiene acceso a la empresa especificada.
    /// Retorna true si:
    /// - El usuario es administrador (PrivAdm != 0)
    /// - El usuario tiene un registro en UsuarioEmpresa para esa empresa
    /// </summary>
    Task<bool> ValidateAccessAsync(int idEmpresa);

    /// <summary>
    /// Valida que el idEmpresa del request coincide con la empresa en sesión.
    /// Esta es la validación más estricta: solo permite acceder a la empresa seleccionada.
    /// </summary>
    bool ValidateMatchesSession(int idEmpresa);

    /// <summary>
    /// Valida acceso y retorna mensaje de error si no tiene acceso
    /// </summary>
    Task<(bool HasAccess, string? ErrorMessage)> ValidateAccessWithMessageAsync(int idEmpresa);

    /// <summary>
    /// Obtiene los privilegios del usuario para una empresa específica
    /// </summary>
    Task<int> GetPrivilegiosAsync(int idEmpresa);

    /// <summary>
    /// Verifica si el usuario tiene un privilegio específico para la empresa en sesión
    /// </summary>
    bool HasPrivilege(int privilegeValue);
}

/// <summary>
/// Implementación del servicio de autorización de empresas
/// </summary>
public class CompanyAuthorizationService(
    LpContabContext context,
    ILogger<CompanyAuthorizationService> logger) : ICompanyAuthorizationService
{
    public async Task<bool> ValidateAccessAsync(int idEmpresa)
    {
        var usuarioId = SessionHelper.UsuarioId;

        if (usuarioId == 0)
        {
            logger.LogWarning("ValidateAccess failed: No authenticated user");
            return false;
        }

        // Administradores tienen acceso a todo
        if (SessionHelper.EsAdmin)
        {
            return true;
        }

        // Verificar acceso via UsuarioEmpresa
        var tieneAcceso = await context.UsuarioEmpresa
            .AnyAsync(ue => ue.idUsuario == usuarioId && ue.idEmpresa == idEmpresa);

        if (!tieneAcceso)
        {
            logger.LogWarning(
                "Access denied: User {UsuarioId} attempted to access empresa {IdEmpresa} without authorization",
                usuarioId, idEmpresa);
        }

        return tieneAcceso;
    }

    public bool ValidateMatchesSession(int idEmpresa)
    {
        var sessionEmpresaId = SessionHelper.EmpresaId;

        if (sessionEmpresaId == 0)
        {
            logger.LogWarning("ValidateMatchesSession failed: No empresa in session");
            return false;
        }

        if (idEmpresa != sessionEmpresaId)
        {
            logger.LogWarning(
                "Session mismatch: Request for empresa {RequestedId} but session has {SessionId}. User: {UsuarioId}",
                idEmpresa, sessionEmpresaId, SessionHelper.UsuarioId);
            return false;
        }

        return true;
    }

    public async Task<(bool HasAccess, string? ErrorMessage)> ValidateAccessWithMessageAsync(int idEmpresa)
    {
        var usuarioId = SessionHelper.UsuarioId;

        if (usuarioId == 0)
        {
            return (false, "No hay usuario autenticado");
        }

        if (idEmpresa <= 0)
        {
            return (false, "ID de empresa inválido");
        }

        // Verificar que la empresa existe
        var empresaExists = await context.Empresas.AnyAsync(e => e.IdEmpresa == idEmpresa);
        if (!empresaExists)
        {
            return (false, "La empresa especificada no existe");
        }

        // Administradores tienen acceso a todo
        if (SessionHelper.EsAdmin)
        {
            return (true, null);
        }

        // Verificar acceso via UsuarioEmpresa
        var tieneAcceso = await context.UsuarioEmpresa
            .AnyAsync(ue => ue.idUsuario == usuarioId && ue.idEmpresa == idEmpresa);

        if (!tieneAcceso)
        {
            logger.LogWarning(
                "Access denied: User {UsuarioId} ({Usuario}) attempted to access empresa {IdEmpresa}",
                usuarioId, SessionHelper.UsuarioNombre, idEmpresa);
            return (false, "No tiene permisos para acceder a esta empresa");
        }

        return (true, null);
    }

    public async Task<int> GetPrivilegiosAsync(int idEmpresa)
    {
        var usuarioId = SessionHelper.UsuarioId;

        if (usuarioId == 0)
            return 0;

        // Administradores tienen todos los privilegios
        if (SessionHelper.EsAdmin)
            return int.MaxValue;

        var usuarioEmpresa = await context.UsuarioEmpresa
            .FirstOrDefaultAsync(ue => ue.idUsuario == usuarioId && ue.idEmpresa == idEmpresa);

        if (usuarioEmpresa?.idPerfil == null)
            return 0;

        var perfil = await context.Perfiles
            .FirstOrDefaultAsync(p => p.IdPerfil == usuarioEmpresa.idPerfil.Value);

        return perfil?.Privilegios ?? 0;
    }

    public bool HasPrivilege(int privilegeValue)
    {
        return SessionHelper.HasPrivilege(privilegeValue);
    }
}
