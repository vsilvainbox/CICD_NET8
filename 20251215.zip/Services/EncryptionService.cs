using System.Text;

namespace App.Services;

/// <summary>
/// Servicio de encriptación compatible con VB6 (FwEncrypt1/FwDecrypt1)
/// Migrado desde vb6/VB50/Pam.bas líneas 6182-6238
/// </summary>
public class EncryptionService : IEncryptionService
{
    /// <summary>
    /// Encripta texto usando el algoritmo FwEncrypt1 de VB6
    /// Compatible con: FwEncrypt1(text, key) del sistema legacy
    /// </summary>
    /// <param name="text">Texto a encriptar</param>
    /// <param name="key">Llave de encriptación (número entero)</param>
    /// <returns>Texto encriptado en formato hexadecimal</returns>
    public string Encrypt(string text, long key)
    {
        if (string.IsNullOrEmpty(text))
            return string.Empty;

        var result = new StringBuilder();
        var length = text.Length;
        var x = key + length * 17;

        for (var i = 0; i < length; i++)
        {
            x = x + (i + 1); // VB6 usa índices base 1

            if (i > 0)
            {
                x = x + text[i - 1];
            }

            var c = (text[i] + (int)(x % 128)) % 256;

            // Convertir a hex con padding de 2 dígitos y agregar al inicio (reverse order)
            result.Insert(0, c.ToString("X2"));
        }

        return result.ToString();
    }

    /// <summary>
    /// Desencripta texto usando el algoritmo FwDecrypt1 de VB6
    /// Compatible con: FwDecrypt1(crText, key) del sistema legacy
    /// </summary>
    /// <param name="encryptedText">Texto encriptado en formato hexadecimal</param>
    /// <param name="key">Llave de desencriptación (número entero)</param>
    /// <returns>Texto desencriptado</returns>
    public string Decrypt(string encryptedText, long key)
    {
        if (string.IsNullOrEmpty(encryptedText))
            return string.Empty;

        var length = encryptedText.Length;

        // Validar formato: debe ser par y al menos 2 caracteres
        if (length < 2 || length % 2 != 0)
            return string.Empty;

        length = length / 2;
        var result = new StringBuilder();
        var x = key + length * 17;

        for (var i = length - 1; i >= 0; i--)
        {
            x = x + (length - i);

            if (i < length - 1)
            {
                x = x + result[length - i - 2];
            }

            // Leer 2 caracteres hex desde la posición correspondiente
            var hexPair = encryptedText.Substring(i * 2, 2);
            var hexValue = Convert.ToInt32(hexPair, 16);

            var c = (hexValue + 256 - (int)(x % 128)) % 256;
            result.Append((char)c);
        }

        return result.ToString();
    }

    /// <summary>
    /// Encripta contraseña SII usando la llave estándar del sistema
    /// Compatible con encriptación de contraseñas SII en VB6 (key: 181288)
    /// </summary>
    /// <param name="password">Contraseña a encriptar</param>
    /// <returns>Contraseña encriptada</returns>
    public string EncryptSiiPassword(string password)
    {
        const long SII_PASSWORD_KEY = 181288;
        
        if (string.IsNullOrEmpty(password))
            return string.Empty;

        // Si la contraseña es corta (<=15 chars), se guarda sin encriptar en VB6
        if (password.Length <= 15)
            return password;

        return Encrypt(password, SII_PASSWORD_KEY);
    }

    /// <summary>
    /// Desencripta contraseña SII usando la llave estándar del sistema
    /// Compatible con desencriptación de contraseñas SII en VB6 (key: 181288)
    /// </summary>
    /// <param name="encryptedPassword">Contraseña encriptada</param>
    /// <returns>Contraseña desencriptada</returns>
    public string DecryptSiiPassword(string encryptedPassword)
    {
        const long SII_PASSWORD_KEY = 181288;

        if (string.IsNullOrEmpty(encryptedPassword))
            return string.Empty;

        // Si la contraseña es corta (<=15 chars), está sin encriptar
        if (encryptedPassword.Length <= 15)
            return encryptedPassword;

        return Decrypt(encryptedPassword, SII_PASSWORD_KEY);
    }

    /// <summary>
    /// Encripta contraseña de base de datos usando la llave estándar
    /// Compatible con encriptación de passwords de BD en VB6 (key: 731982)
    /// Incluye prefijo de base de datos y separador '#' como en VB6
    /// </summary>
    /// <param name="password">Contraseña a encriptar</param>
    /// <param name="databaseName">Nombre de la base de datos</param>
    /// <returns>Contraseña encriptada con formato VB6</returns>
    public string EncryptDatabasePassword(string password, string databaseName)
    {
        const long DB_PASSWORD_KEY = 731982;

        if (string.IsNullOrEmpty(password))
            return string.Empty;

        // Formato VB6: "     " & DbName & "   #" & "      password       "
        var formattedPassword = $"     {databaseName}   #      {password}       ";

        return Encrypt(formattedPassword, DB_PASSWORD_KEY);
    }

    /// <summary>
    /// Desencripta contraseña de base de datos usando la llave estándar
    /// Compatible con desencriptación de passwords de BD en VB6 (key: 731982)
    /// Extrae la contraseña después del separador '#'
    /// </summary>
    /// <param name="encryptedPassword">Contraseña encriptada</param>
    /// <returns>Contraseña desencriptada</returns>
    public string DecryptDatabasePassword(string encryptedPassword)
    {
        const long DB_PASSWORD_KEY = 731982;

        if (string.IsNullOrEmpty(encryptedPassword))
            return string.Empty;

        var decrypted = Decrypt(encryptedPassword, DB_PASSWORD_KEY);

        // Buscar el separador '#' y extraer lo que viene después
        var separatorIndex = decrypted.IndexOf('#');
        if (separatorIndex >= 0)
        {
            return decrypted.Substring(separatorIndex + 1).Trim();
        }

        return decrypted.Trim();
    }
}

/// <summary>
/// Interfaz para el servicio de encriptación
/// </summary>
public interface IEncryptionService
{
    string Encrypt(string text, long key);
    string Decrypt(string encryptedText, long key);
    string EncryptSiiPassword(string password);
    string DecryptSiiPassword(string encryptedPassword);
    string EncryptDatabasePassword(string password, string databaseName);
    string DecryptDatabasePassword(string encryptedPassword);
}

