using App.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace App.Services;

/// <summary>
/// Servicio para gestionar indicadores económicos (IPC, Factor CM, UTM, etc.)
/// Migrado desde VB6: GetFactorCM y funciones relacionadas
/// </summary>
public class IndicadoresEconomicosService : IIndicadoresEconomicosService
{
    private readonly LpContabContext context;
    private readonly ILogger<IndicadoresEconomicosService> logger;

    public IndicadoresEconomicosService(LpContabContext context, ILogger<IndicadoresEconomicosService> logger)
    {
        this.context = context;
        this.logger = logger;
    }

    /// <summary>
    /// Obtiene el Factor de Corrección Monetaria para un año/mes específico
    /// Migrado desde VB6: GetFactorCM
    /// Archivo: vb6/Contabilidad70/HyperContabilidad/HyperCont.bas líneas 10978-10996
    /// </summary>
    /// <param name="anoMes">Año y mes en formato YYYYMM (ej: 202312 para diciembre 2023)</param>
    /// <returns>Factor de corrección monetaria (fCM) o 0 si no existe</returns>
    public async Task<double> GetFactorCMAsync(int anoMes)
    {
        {
            // VB6: SELECT fCM FROM IPC WHERE AnoMes = {anoMes}
            var ipc = await context.IPC
                .Where(i => i.AnoMes == anoMes)
                .Select(i => i.fCM)
                .FirstOrDefaultAsync();

            var factor = ipc ?? 0;

            if (factor == 0)
            {
                logger.LogWarning("No se encontró Factor CM para AnoMes: {AnoMes}", anoMes);
            }

            return factor;
        }
    }

    /// <summary>
    /// Obtiene el Factor de Corrección Monetaria para una fecha específica
    /// </summary>
    /// <param name="fecha">Fecha para la cual obtener el factor</param>
    /// <returns>Factor de corrección monetaria</returns>
    public async Task<double> GetFactorCMAsync(DateTime fecha)
    {
        var anoMes = fecha.Year * 100 + fecha.Month;
        return await GetFactorCMAsync(anoMes);
    }

    /// <summary>
    /// Obtiene el Factor de Corrección Monetaria para el último día de un año
    /// Usado en cálculos tributarios de primera categoría
    /// </summary>
    /// <param name="ano">Año</param>
    /// <returns>Factor CM de diciembre del año especificado</returns>
    public async Task<double> GetFactorCMFinAnoAsync(int ano)
    {
        // Diciembre del año = año * 100 + 12
        var anoMes = ano * 100 + 12;
        return await GetFactorCMAsync(anoMes);
    }

    /// <summary>
    /// Obtiene el valor del IPC para un año/mes específico
    /// </summary>
    /// <param name="anoMes">Año y mes en formato YYYYMM</param>
    /// <returns>Datos completos del IPC o null si no existe</returns>
    public async Task<IPCDto?> GetIPCAsync(int anoMes)
    {
        {
            var ipc = await context.IPC
                .Where(i => i.AnoMes == anoMes)
                .Select(i => new IPCDto
                {
                    AnoMes = i.AnoMes,
                    PIPC = i.pIPC ?? 0,
                    VIPC = i.vIPC ?? 0,
                    FCM = i.fCM ?? 0,
                    AIPC = i.aIPC ?? 0
                })
                .FirstOrDefaultAsync();

            return ipc;
        }
    }

    /// <summary>
    /// Obtiene el valor de la UTM para una fecha específica
    /// La UTM se almacena en la tabla Monedas con idMoneda específico
    /// </summary>
    /// <param name="fecha">Fecha para la cual obtener el valor UTM</param>
    /// <returns>Valor de la UTM o 0 si no existe</returns>
    public async Task<double> GetValorUTMAsync(DateTime fecha)
    {
        {
            // En VB6, la UTM se guarda en tabla Monedas
            // Típicamente con idMoneda = 4 o similar
            // El valor se actualiza mensualmente
            
            // Buscar moneda UTM (por descripción o código conocido)
            var utm = await context.Monedas
                .Where(m => m.Descrip != null && 
                           (m.Descrip.ToUpper().Contains("UTM") || 
                            m.Simbolo == "UTM"))
                .Select(m => new { m.DecInf, m.DecVenta })
                .FirstOrDefaultAsync();

            if (utm == null)
            {
                logger.LogWarning("No se encontró moneda UTM en la tabla Monedas");
                return 0;
            }

            // DecInf típicamente contiene el valor de compra/referencia
            // DecVenta contiene el valor de venta
            // Para cálculos tributarios se usa DecInf
            double valor = utm.DecInf ?? utm.DecVenta ?? 0;

            return valor;
        }
    }

    /// <summary>
    /// Obtiene el valor de la UTM al 31 de diciembre de un año específico
    /// Usado en cálculos tributarios anuales
    /// </summary>
    /// <param name="ano">Año</param>
    /// <returns>Valor de la UTM al 31/12 del año</returns>
    public async Task<double> GetValorUTMFinAnoAsync(int ano)
    {
        var fecha = new DateTime(ano, 12, 31);
        return await GetValorUTMAsync(fecha);
    }

    /// <summary>
    /// Obtiene el Factor de Actualización Anual entre dos meses
    /// Usado para actualizar valores monetarios por inflación
    /// </summary>
    /// <param name="ano">Año</param>
    /// <param name="mesDesde">Mes origen (1-12)</param>
    /// <param name="mesHasta">Mes destino (1-12)</param>
    /// <returns>Factor de actualización o 1.0 si no existe</returns>
    public async Task<double> GetFactorActualizacionAnualAsync(int ano, int mesDesde, int mesHasta)
    {
        {
            // VB6: Tabla FactorActAnual con columnas Ano, MesRow, MesCol, Factor
            // MesRow = mes origen, MesCol = mes destino
            var factor = await context.FactorActAnual
                .Where(f => f.Ano == ano && f.MesRow == mesDesde && f.MesCol == mesHasta)
                .Select(f => f.Factor)
                .FirstOrDefaultAsync();

            var resultado = factor ?? 1.0;

            if (resultado == 1.0 && mesDesde != mesHasta)
            {
                logger.LogWarning(
                    "No se encontró Factor de Actualización para Ano: {Ano}, MesDesde: {MesDesde}, MesHasta: {MesHasta}",
                    ano, mesDesde, mesHasta);
            }

            return resultado;
        }
    }

    /// <summary>
    /// Actualiza un monto aplicando el Factor de Corrección Monetaria
    /// </summary>
    /// <param name="monto">Monto original</param>
    /// <param name="anoMes">Año/mes para el cual aplicar el factor</param>
    /// <returns>Monto actualizado</returns>
    public async Task<double> ActualizarMontoConCMAsync(double monto, int anoMes)
    {
        var factor = await GetFactorCMAsync(anoMes);
        return monto * factor;
    }

    /// <summary>
    /// Actualiza un monto aplicando el Factor de Actualización Anual
    /// </summary>
    /// <param name="monto">Monto original</param>
    /// <param name="ano">Año</param>
    /// <param name="mesDesde">Mes origen</param>
    /// <param name="mesHasta">Mes destino</param>
    /// <returns>Monto actualizado</returns>
    public async Task<double> ActualizarMontoAnualAsync(double monto, int ano, int mesDesde, int mesHasta)
    {
        var factor = await GetFactorActualizacionAnualAsync(ano, mesDesde, mesHasta);
        return monto * factor;
    }

    /// <summary>
    /// Obtiene todos los factores CM de un año específico
    /// Útil para reportes y cálculos masivos
    /// </summary>
    /// <param name="ano">Año</param>
    /// <returns>Lista de factores CM por mes</returns>
    public async Task<List<IPCDto>> GetFactoresCMAnoAsync(int ano)
    {
        {
            var anoMesInicio = ano * 100 + 1;   // Enero
            var anoMesFin = ano * 100 + 12;     // Diciembre

            var factores = await context.IPC
                .Where(i => i.AnoMes >= anoMesInicio && i.AnoMes <= anoMesFin)
                .OrderBy(i => i.AnoMes)
                .Select(i => new IPCDto
                {
                    AnoMes = i.AnoMes,
                    PIPC = i.pIPC ?? 0,
                    VIPC = i.vIPC ?? 0,
                    FCM = i.fCM ?? 0,
                    AIPC = i.aIPC ?? 0
                })
                .ToListAsync();

            return factores;
        }
    }

    /// <summary>
    /// Verifica si existen datos de IPC/CM para un año específico
    /// </summary>
    /// <param name="ano">Año a verificar</param>
    /// <returns>True si existen datos, False si no</returns>
    public async Task<bool> ExistenDatosIPCAnoAsync(int ano)
    {
        {
            var anoMesInicio = ano * 100 + 1;
            var anoMesFin = ano * 100 + 12;

            return await context.IPC
                .AnyAsync(i => i.AnoMes >= anoMesInicio && i.AnoMes <= anoMesFin);
        }
    }
}

public interface IIndicadoresEconomicosService
{
    Task<double> GetFactorCMAsync(int anoMes);
    Task<double> GetFactorCMAsync(DateTime fecha);
    Task<double> GetFactorCMFinAnoAsync(int ano);
    Task<IPCDto?> GetIPCAsync(int anoMes);
    Task<double> GetValorUTMAsync(DateTime fecha);
    Task<double> GetValorUTMFinAnoAsync(int ano);
    Task<double> GetFactorActualizacionAnualAsync(int ano, int mesDesde, int mesHasta);
    Task<double> ActualizarMontoConCMAsync(double monto, int anoMes);
    Task<double> ActualizarMontoAnualAsync(double monto, int ano, int mesDesde, int mesHasta);
    Task<List<IPCDto>> GetFactoresCMAnoAsync(int ano);
    Task<bool> ExistenDatosIPCAnoAsync(int ano);
}

public class IPCDto
{
    public int AnoMes { get; set; }
    public double PIPC { get; set; }      // Porcentaje IPC
    public double VIPC { get; set; }      // Variación IPC
    public double FCM { get; set; }       // Factor Corrección Monetaria
    public double AIPC { get; set; }      // Acumulado IPC
    
    public int Ano => AnoMes / 100;
    public int Mes => AnoMes % 100;
    public string MesNombre => ObtenerNombreMes(Mes);

    private string ObtenerNombreMes(int mes)
    {
        return mes switch
        {
            1 => "Enero",
            2 => "Febrero",
            3 => "Marzo",
            4 => "Abril",
            5 => "Mayo",
            6 => "Junio",
            7 => "Julio",
            8 => "Agosto",
            9 => "Septiembre",
            10 => "Octubre",
            11 => "Noviembre",
            12 => "Diciembre",
            _ => $"Mes {mes}"
        };
    }
}

