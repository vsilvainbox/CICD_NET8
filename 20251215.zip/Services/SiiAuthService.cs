using System.Net;

namespace App.Services;

/// <summary>
/// Servicio de autenticación y consultas al SII
/// Implementación basada en lógica VB6 de ModSII.bas
/// </summary>
public class SiiAuthService(IHttpClientFactory httpClientFactory, ILogger<SiiAuthService> logger) : ISiiAuthService
{
    private readonly IHttpClientFactory _httpClientFactory = httpClientFactory;

    // URLs del SII (basadas en VB6 WinINet.Bas líneas 579-583)
    private const string URL_SII_LOGIN = "https://zeusr.sii.cl/cgi_AUT2000/CAutInicio.cgi";
    private const string URL_SII_CARTA = "https://misiir.sii.cl/cgi_misii/CViewCarta.cgi";
    private const string URL_SII_LOGOUT = "https://zeusr.sii.cl/cgi_AUT2000/autTermino.cgi";

    /// <summary>
    /// Obtiene las sucursales desde el SII
    /// Basado en función VB6: SucursalSII
    /// </summary>
    public async Task<List<SucursalSiiDto>> ObtenerSucursalesDesdeSiiAsync(string rut, string clave)
    {
        // ══════════════════════════════════════════════════════════════════
        // CONEXIÓN AL SII DESACTIVADA - Retorna lista vacía
        // ══════════════════════════════════════════════════════════════════
        logger.LogWarning("CONEXIÓN AL SII DESACTIVADA - ObtenerSucursalesDesdeSiiAsync para RUT: {Rut}", FormatRut(rut));
        await Task.CompletedTask;
        throw new InvalidOperationException("La conexión al SII está temporalmente desactivada. Por favor, importe los datos manualmente.");

        /*
        // Código original comentado - ver abajo

        {
            var sucursales = new List<SucursalSiiDto>();
            
            // Crear HttpClient con CookieContainer para mantener sesión
            var cookieContainer = new CookieContainer();
            var handler = new HttpClientHandler
            {
                CookieContainer = cookieContainer,
                UseCookies = true,
                AllowAutoRedirect = true
            };
            
            using var client = new HttpClient(handler);
            client.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
            client.Timeout = TimeSpan.FromSeconds(30);
            
            var rutLimpio = LimpiarRut(rut);
            var dv = CalcularDV(rutLimpio);
            
            // Parámetros de login (basados en VB6)
            var loginParams = new Dictionary<string, string>
            {
                { "rut", rutLimpio },
                { "dv", dv },
                { "referencia", "https://misiir.sii.cl/cgi_misii/siihome.cgi" },
                { "rutcntr", $"{rutLimpio}-{dv}" },
                { "clave", clave }
            };
            
            var loginContent = new FormUrlEncodedContent(loginParams);
            var loginResponse = await client.PostAsync(URL_SII_LOGIN, loginContent);
            var loginResult = await loginResponse.Content.ReadAsStringAsync();
            
            logger.LogDebug("Login response status: {StatusCode}", loginResponse.StatusCode);
            logger.LogDebug("Login response length: {Length} chars", loginResult.Length);
            logger.LogDebug("Cookies after login: {Count}", cookieContainer.Count);
            
            // Log cookies for debugging
            var siiDomain = new Uri(URL_SII_LOGIN).Host;
            var cookies = cookieContainer.GetCookies(new Uri($"https://{siiDomain}"));
            foreach (Cookie cookie in cookies)
            {
                logger.LogDebug("Cookie: {Name} = {Value}", cookie.Name, cookie.Value.Substring(0, Math.Min(20, cookie.Value.Length)));
            }
            
            // Validar si el login fue exitoso
            if (loginResult.Contains("titulo") || loginResult.Contains("error", StringComparison.OrdinalIgnoreCase))
            {
                logger.LogWarning("Error en autenticación SII para RUT: {Rut}. Response preview: {Preview}", 
                    FormatRut(rut), loginResult.Substring(0, Math.Min(200, loginResult.Length)));
                throw new InvalidOperationException("Error con la información ingresada. Favor verificar su Clave SII.");
            }
            
            logger.LogInformation("Login exitoso en SII para RUT: {Rut}", FormatRut(rut));
            
            // 2. Consultar sucursales (opc=112 obtiene direcciones)
            var cartaParams = new Dictionary<string, string>
            {
                { "opc", "112" }
            };
            
            var cartaContent = new FormUrlEncodedContent(cartaParams);
            var cartaResponse = await client.PostAsync(URL_SII_CARTA, cartaContent);
            var cartaResult = await cartaResponse.Content.ReadAsStringAsync();
            
            logger.LogDebug("Carta response status: {StatusCode}", cartaResponse.StatusCode);
            logger.LogDebug("Carta response length: {Length} chars", cartaResult.Length);
            logger.LogDebug("Carta response preview: {Preview}", cartaResult.Substring(0, Math.Min(500, cartaResult.Length)));
            
            // Verificar codigoError como en VB6
            var codigoError = ExtraerValorJson(cartaResult, "codigoError");
            logger.LogDebug("codigoError extraído: '{CodigoError}'", codigoError);
            
            // Solo lanzar error si hay un código de error explícito y no es "0"
            if (!string.IsNullOrWhiteSpace(codigoError) && codigoError != "0")
            {
                var descripcionError = ExtraerValorJson(cartaResult, "descripcionError");
                logger.LogWarning("SII retornó error explícito. Código: {Codigo}, Descripción: {Desc}", codigoError, descripcionError);
                throw new InvalidOperationException($"El SII retornó un error: {descripcionError}");
            }
            
            logger.LogDebug("Verificación de codigoError OK (código: '{Codigo}')", codigoError);
            
            // 3. Parsear JSON de sucursales
            sucursales = ParsearSucursalesSii(cartaResult);
            
            logger.LogInformation("Sucursales obtenidas desde SII: {Count}", sucursales.Count);
            
            // 4. Logout del SII
            await client.PostAsync(URL_SII_LOGOUT, new StringContent(""));
            
            return sucursales;
        }
        */
    }

    /// <summary>
    /// Valida credenciales SII
    /// </summary>
    public async Task<bool> ValidarCredencialesSiiAsync(string rut, string clave)
    {
        // ══════════════════════════════════════════════════════════════════
        // VALIDACIÓN DE CREDENCIALES SII DESACTIVADA - Retorna false
        // ══════════════════════════════════════════════════════════════════
        logger.LogWarning("VALIDACIÓN DE CREDENCIALES SII DESACTIVADA para RUT: {Rut}", FormatRut(rut));
        await Task.CompletedTask;
        return false;

        // Código original comentado:
        /*
        {
            logger.LogInformation("Validando credenciales SII para RUT: {Rut}", FormatRut(rut));
            
            // Crear HttpClient con CookieContainer
            var cookieContainer = new CookieContainer();
            var handler = new HttpClientHandler
            {
                CookieContainer = cookieContainer,
                UseCookies = true,
                AllowAutoRedirect = true
            };
            
            using var client = new HttpClient(handler);
            client.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
            
            var rutLimpio = LimpiarRut(rut);
            var dv = CalcularDV(rutLimpio);
            
            var loginParams = new Dictionary<string, string>
            {
                { "rut", rutLimpio },
                { "dv", dv },
                { "referencia", "https://misiir.sii.cl/cgi_misii/siihome.cgi" },
                { "rutcntr", $"{rutLimpio}-{dv}" },
                { "clave", clave }
            };
            
            var content = new FormUrlEncodedContent(loginParams);
            var response = await client.PostAsync(URL_SII_LOGIN, content);
            var result = await response.Content.ReadAsStringAsync();
            
            var esValido = !result.Contains("titulo") && !result.Contains("error", StringComparison.OrdinalIgnoreCase);
            
            if (esValido)
            {
                // Hacer logout inmediatamente
                await client.PostAsync(URL_SII_LOGOUT, new StringContent(""));
            }
            
            logger.LogInformation("Validación SII para RUT {Rut}: {Resultado}", FormatRut(rut), esValido ? "Exitosa" : "Fallida");
            
            return esValido;
        }
        */
    }

    /// <summary>
    /// Parsea el JSON de respuesta del SII y extrae las sucursales
    /// Basado en lógica VB6 que procesa el JSON manualmente
    /// </summary>
    private List<SucursalSiiDto> ParsearSucursalesSii(string respuesta)
    {
        var sucursales = new List<SucursalSiiDto>();
        
        {
            logger.LogDebug("Iniciando parseo de sucursales SII");
            
            // Buscar el array de direcciones en el JSON
            var inicioArray = respuesta.IndexOf("\"direcciones\"", StringComparison.OrdinalIgnoreCase);
            if (inicioArray == -1)
            {
                logger.LogWarning("No se encontró el campo 'direcciones' con comillas. Buscando alternativas...");
                
                // Buscar otras variantes
                inicioArray = respuesta.IndexOf("direcciones", StringComparison.OrdinalIgnoreCase);
                if (inicioArray == -1)
                {
                    // Intentar buscar otros campos comunes en respuestas SII
                    if (respuesta.Contains("error", StringComparison.OrdinalIgnoreCase))
                    {
                        logger.LogError("Respuesta SII contiene error. Response completa: {Response}", respuesta);
                    }
                    else
                    {
                        logger.LogError("Campo 'direcciones' no encontrado. Response completa (primeros 2000 chars): {Preview}", 
                            respuesta.Substring(0, Math.Min(2000, respuesta.Length)));
                    }
                    return sucursales;
                }
                else
                {
                    logger.LogInformation("Campo 'direcciones' encontrado sin comillas en posición {Pos}", inicioArray);
                }
            }
            else
            {
                logger.LogInformation("Campo 'direcciones' encontrado con comillas en posición {Pos}", inicioArray);
            }
            
            var inicioBracket = respuesta.IndexOf('[', inicioArray);
            var finBracket = respuesta.IndexOf(']', inicioBracket);
            
            if (inicioBracket == -1 || finBracket == -1)
            {
                logger.LogWarning("Formato JSON inválido en respuesta SII. inicioBracket={IB}, finBracket={FB}", 
                    inicioBracket, finBracket);
                return sucursales;
            }
            
            var jsonArray = respuesta.Substring(inicioBracket, finBracket - inicioBracket + 1);
            logger.LogDebug("Array de direcciones extraído. Longitud: {Length} chars", jsonArray.Length);
            
            // Parsear cada objeto en el array
            var posicion = 0;
            var contadorObjetos = 0;
            while (posicion < jsonArray.Length)
            {
                var inicioObjeto = jsonArray.IndexOf('{', posicion);
                if (inicioObjeto == -1) break;
                
                var finObjeto = jsonArray.IndexOf('}', inicioObjeto);
                if (finObjeto == -1) break;
                
                contadorObjetos++;
                var objetoJson = jsonArray.Substring(inicioObjeto, finObjeto - inicioObjeto + 1);
                
                logger.LogDebug("Procesando objeto #{Numero}: {Preview}", 
                    contadorObjetos, objetoJson.Substring(0, Math.Min(100, objetoJson.Length)));
                
                // Extraer campos (código, tipo, calle, número, ciudad)
                var tipoDomicilio = ExtraerValorJson(objetoJson, "tipoDomicilioCodigo");
                
                logger.LogDebug("tipoDomicilioCodigo extraído: '{Tipo}'", tipoDomicilio);
                
                // Solo procesar Casa Matriz (1) o Sucursales (3)
                if (tipoDomicilio == "1" || tipoDomicilio == "3")
                {
                    var codigo = ExtraerValorJson(objetoJson, "codigo");
                    var calle = ExtraerValorJson(objetoJson, "calle");
                    var numero = ExtraerValorJson(objetoJson, "numero");
                    var ciudad = ExtraerValorJson(objetoJson, "ciudadNombre");
                    
                    logger.LogDebug("Sucursal válida encontrada - Codigo: {Codigo}, Tipo: {Tipo}", codigo, tipoDomicilio);
                    
                    var sucursal = new SucursalSiiDto
                    {
                        Codigo = codigo,
                        Calle = calle,
                        Numero = numero,
                        Ciudad = ciudad,
                        TipoDomicilio = int.Parse(tipoDomicilio)
                    };
                    
                    // Construir descripción como en VB6: "Calle Número, Ciudad"
                    sucursal.Descripcion = $"{sucursal.Calle} {sucursal.Numero}, {sucursal.Ciudad}".ToLower();
                    
                    sucursales.Add(sucursal);
                    
                    logger.LogDebug("Sucursal SII parseada: {Codigo} - {Descripcion}", sucursal.Codigo, sucursal.Descripcion);
                }
                else
                {
                    logger.LogDebug("Objeto ignorado, tipoDomicilioCodigo='{Tipo}' (solo se procesan 1 y 3)", tipoDomicilio);
                }
                
                posicion = finObjeto + 1;
            }
            
            logger.LogInformation("Parseo completado. Total objetos procesados: {Total}, Sucursales válidas: {Validas}", 
                contadorObjetos, sucursales.Count);
        }
        
        return sucursales;
    }

    /// <summary>
    /// Extrae un valor de un objeto JSON simple
    /// </summary>
    private string ExtraerValorJson(string json, string campo)
    {
        {
            var searchPattern = $"\"{campo}\":";
            var inicio = json.IndexOf(searchPattern, StringComparison.OrdinalIgnoreCase);
            if (inicio == -1) return string.Empty;
            
            inicio += searchPattern.Length;
            
            // Saltar espacios
            while (inicio < json.Length && (json[inicio] == ' ' || json[inicio] == '\t')) inicio++;
            
            // Si es string (comienza con ")
            if (json[inicio] == '"')
            {
                inicio++;
                var fin = json.IndexOf('"', inicio);
                return json.Substring(inicio, fin - inicio).Trim();
            }
            else // Es número o booleano
            {
                var fin = json.IndexOfAny(new[] { ',', '}' }, inicio);
                return json.Substring(inicio, fin - inicio).Trim();
            }
        }
    }

    /// <summary>
    /// Limpia el RUT dejando solo números
    /// </summary>
    private string LimpiarRut(string rut)
    {
        if (string.IsNullOrWhiteSpace(rut)) return string.Empty;
        
        var rutLimpio = new string(rut.Where(char.IsDigit).ToArray());
        
        // Si tiene DV incluido, quitarlo
        if (rut.Contains('-'))
        {
            var partes = rut.Split('-');
            rutLimpio = new string(partes[0].Where(char.IsDigit).ToArray());
        }
        
        return rutLimpio;
    }

    /// <summary>
    /// Formatea RUT para mostrar en logs (12345678-9)
    /// </summary>
    private string FormatRut(string rut)
    {
        var rutLimpio = LimpiarRut(rut);
        if (string.IsNullOrEmpty(rutLimpio)) return rut;
        
        var dv = CalcularDV(rutLimpio);
        return $"{rutLimpio}-{dv}";
    }

    /// <summary>
    /// Calcula el dígito verificador del RUT chileno
    /// Basado en algoritmo estándar módulo 11
    /// </summary>
    private string CalcularDV(string rut)
    {
        if (string.IsNullOrWhiteSpace(rut)) return "0";
        
        var rutLimpio = new string(rut.Where(char.IsDigit).ToArray());
        if (rutLimpio.Length == 0) return "0";
        
        var suma = 0;
        var multiplo = 2;
        
        // Recorrer de derecha a izquierda
        for (var i = rutLimpio.Length - 1; i >= 0; i--)
        {
            suma += int.Parse(rutLimpio[i].ToString()) * multiplo;
            multiplo = multiplo == 7 ? 2 : multiplo + 1;
        }
        
        var resto = suma % 11;
        var dv = 11 - resto;
        
        if (dv == 11) return "0";
        if (dv == 10) return "K";
        
        return dv.ToString();
    }
}
