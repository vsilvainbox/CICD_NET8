using OfficeOpenXml;
using OfficeOpenXml.Style;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;
using DrawingColor = System.Drawing.Color;
using PdfColor = QuestPDF.Infrastructure.Color;

namespace App.Services;

/// <summary>
/// Servicio genérico para exportaciones Excel y PDF
/// Reutilizable en todas las features
/// </summary>
public class ExportService : IExportService
{
    private readonly ILogger<ExportService> logger;

    public ExportService(ILogger<ExportService> logger)
    {
        this.logger = logger;
        
        // Configurar licencias
        ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
        QuestPDF.Settings.License = LicenseType.Community;
    }

    /// <summary>
    /// Crea un paquete Excel básico con encabezado de empresa
    /// </summary>
    public ExcelPackage CreateExcelPackage(string sheetName, string empresaNombre, string empresaRut, string titulo)
    {
        var package = new ExcelPackage();
        var worksheet = package.Workbook.Worksheets.Add(sheetName);

        var row = 1;

        // Encabezado empresa
        if (!string.IsNullOrEmpty(empresaNombre))
        {
            worksheet.Cells[row, 1].Value = empresaNombre;
            worksheet.Cells[row, 1].Style.Font.Bold = true;
            worksheet.Cells[row, 1].Style.Font.Size = 14;
            row++;

            if (!string.IsNullOrEmpty(empresaRut))
            {
                worksheet.Cells[row, 1].Value = $"RUT: {empresaRut}";
                row++;
            }
        }

        // Título
        if (!string.IsNullOrEmpty(titulo))
        {
            worksheet.Cells[row, 1].Value = titulo;
            worksheet.Cells[row, 1].Style.Font.Bold = true;
            worksheet.Cells[row, 1].Style.Font.Size = 12;
            row++;
        }

        row++; // Línea en blanco

        return package;
    }

    /// <summary>
    /// Aplica estilo de encabezado a un rango de celdas
    /// </summary>
    public void ApplyHeaderStyle(ExcelRange range, DrawingColor? backgroundColor = null)
    {
        range.Style.Font.Bold = true;
        range.Style.Fill.PatternType = ExcelFillStyle.Solid;
        range.Style.Fill.BackgroundColor.SetColor(backgroundColor ?? DrawingColor.FromArgb(79, 129, 189));
        range.Style.Font.Color.SetColor(DrawingColor.White);
        range.Style.Border.BorderAround(ExcelBorderStyle.Thin);
        range.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
        range.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
    }

    /// <summary>
    /// Aplica formato de moneda chilena a un rango
    /// </summary>
    public void ApplyCurrencyFormat(ExcelRange range)
    {
        range.Style.Numberformat.Format = "$ #,##0";
    }

    /// <summary>
    /// Aplica formato de número con decimales
    /// </summary>
    public void ApplyNumberFormat(ExcelRange range, int decimals = 2)
    {
        range.Style.Numberformat.Format = decimals == 0 ? "#,##0" : $"#,##0.{new string('0', decimals)}";
    }

    /// <summary>
    /// Aplica formato de fecha
    /// </summary>
    public void ApplyDateFormat(ExcelRange range)
    {
        range.Style.Numberformat.Format = "dd/mm/yyyy";
    }

    /// <summary>
    /// Ajusta automáticamente el ancho de todas las columnas
    /// </summary>
    public void AutoFitColumns(ExcelWorksheet worksheet, int fromColumn = 1, int toColumn = 10, double minWidth = 10, double maxWidth = 50)
    {
        for (var col = fromColumn; col <= toColumn; col++)
        {
            worksheet.Column(col).AutoFit(minWidth, maxWidth);
        }
    }

    /// <summary>
    /// Exporta una lista genérica a Excel con columnas configurables
    /// </summary>
    public byte[] ExportListToExcel<T>(
        IEnumerable<T> data,
        string sheetName,
        string empresaNombre,
        string empresaRut,
        string titulo,
        Dictionary<string, Func<T, object>> columns)
    {
        using var package = CreateExcelPackage(sheetName, empresaNombre, empresaRut, titulo);
        var worksheet = package.Workbook.Worksheets[0];

        var startRow = worksheet.Dimension?.End.Row ?? 1;
        startRow += 2; // Espacio después del encabezado

        // Encabezados de columnas
        var col = 1;
        foreach (var columnName in columns.Keys)
        {
            worksheet.Cells[startRow, col].Value = columnName;
            col++;
        }

        ApplyHeaderStyle(worksheet.Cells[startRow, 1, startRow, columns.Count]);

        // Datos
        var row = startRow + 1;
        foreach (var item in data)
        {
            col = 1;
            foreach (var columnFunc in columns.Values)
            {
                var value = columnFunc(item);
                worksheet.Cells[row, col].Value = value;

                // Aplicar formato según tipo
                if (value is decimal or double or float)
                {
                    ApplyNumberFormat(worksheet.Cells[row, col]);
                }
                else if (value is DateTime)
                {
                    ApplyDateFormat(worksheet.Cells[row, col]);
                }

                col++;
            }
            row++;
        }

        // Ajustar anchos
        AutoFitColumns(worksheet, 1, columns.Count);

        return package.GetAsByteArray();
    }

    /// <summary>
    /// Exporta una tabla simple a PDF usando QuestPDF
    /// </summary>
    public byte[] ExportTableToPdf<T>(
        IEnumerable<T> data,
        string titulo,
        string empresaNombre,
        string empresaRut,
        Dictionary<string, Func<T, string>> columns)
    {
        logger.LogInformation("Generating PDF export: {Titulo}", titulo);

        QuestPDF.Settings.License = LicenseType.Community;

        var document = Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Size(PageSizes.Letter);
                page.Margin(1, Unit.Centimetre);
                page.PageColor(Colors.White);
                page.DefaultTextStyle(x => x.FontSize(10));

                // Header
                page.Header().Column(column =>
                {
                    column.Item().Text(empresaNombre).FontSize(14).Bold();
                    if (!string.IsNullOrEmpty(empresaRut))
                    {
                        column.Item().Text($"RUT: {empresaRut}").FontSize(10);
                    }
                    column.Item().PaddingVertical(5);
                    column.Item().Text(titulo).FontSize(12).Bold();
                    column.Item().PaddingBottom(5);
                    column.Item().LineHorizontal(1).LineColor(Colors.Grey.Medium);
                });

                // Content
                page.Content().PaddingVertical(10).Table(table =>
                {
                    // Definir columnas
                    table.ColumnsDefinition(cols =>
                    {
                        foreach (var _ in columns.Keys)
                        {
                            cols.RelativeColumn();
                        }
                    });

                    // Encabezados
                    table.Header(header =>
                    {
                        foreach (var columnName in columns.Keys)
                        {
                            header.Cell()
                                .Border(1)
                                .BorderColor(Colors.Grey.Medium)
                                .Background(Colors.Grey.Lighten3)
                                .Padding(5)
                                .Text(columnName)
                                .Bold();
                        }
                    });

                    // Datos
                    foreach (var item in data)
                    {
                        foreach (var columnFunc in columns.Values)
                        {
                            table.Cell()
                                .Border(1)
                                .BorderColor(Colors.Grey.Lighten2)
                                .Padding(5)
                                .Text(columnFunc(item));
                        }
                    }
                });

                // Footer
                page.Footer().AlignCenter().Text(text =>
                {
                    text.Span("Página ");
                    text.CurrentPageNumber();
                    text.Span(" de ");
                    text.TotalPages();
                });
            });
        });

        return document.GeneratePdf();
    }
}

public interface IExportService
{
    ExcelPackage CreateExcelPackage(string sheetName, string empresaNombre, string empresaRut, string titulo);
    void ApplyHeaderStyle(ExcelRange range, DrawingColor? backgroundColor = null);
    void ApplyCurrencyFormat(ExcelRange range);
    void ApplyNumberFormat(ExcelRange range, int decimals = 2);
    void ApplyDateFormat(ExcelRange range);
    void AutoFitColumns(ExcelWorksheet worksheet, int fromColumn = 1, int toColumn = 10, double minWidth = 10, double maxWidth = 50);
    byte[] ExportListToExcel<T>(IEnumerable<T> data, string sheetName, string empresaNombre, string empresaRut, string titulo, Dictionary<string, Func<T, object>> columns);
    byte[] ExportTableToPdf<T>(IEnumerable<T> data, string titulo, string empresaNombre, string empresaRut, Dictionary<string, Func<T, string>> columns);
}

