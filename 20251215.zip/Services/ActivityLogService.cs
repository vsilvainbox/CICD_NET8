using App.Data;
using Microsoft.EntityFrameworkCore;

namespace App.Services;

/// <summary>
/// Interfaz para el servicio de logging de actividad de usuarios
/// </summary>
public interface IActivityLogService
{
    Task LogActivityAsync(ActivityLogDto activityDto);
    Task<IEnumerable<ActivityLog>> GetRecentActivitiesAsync(int count = 100);
    Task<IEnumerable<ActivityLog>> GetActivitiesByUserAsync(int usuarioId, int count = 100);
    Task<IEnumerable<ActivityLog>> GetActivitiesByDateRangeAsync(DateTime startDate, DateTime endDate);
}

/// <summary>
/// Servicio para registrar actividad de usuarios en la tabla ActivityLog
/// Usa un DbContext separado para evitar conflictos con el contexto principal
/// </summary>
public class ActivityLogService(
    DbContextOptions<LpContabContext> dbContextOptions,
    ILogger<ActivityLogService> logger) : IActivityLogService
{
    public async Task LogActivityAsync(ActivityLogDto activityDto)
    {
        try
        {
            var activityLog = new ActivityLog
            {
                Timestamp = DateTime.Now,
                UsuarioId = activityDto.UsuarioId,
                UserName = activityDto.UserName,
                EmpresaId = activityDto.EmpresaId,
                IpAddress = activityDto.IpAddress,
                Host = activityDto.Host,
                Url = activityDto.Url ?? "Unknown",
                Method = activityDto.Method ?? "GET",
                StatusCode = activityDto.StatusCode,
                Duration = activityDto.Duration,
                RequestBody = activityDto.RequestBody,
                UserAgent = activityDto.UserAgent
            };

            // ✅ Usar un DbContext separado para evitar conflictos
            using (var separateContext = new LpContabContext(dbContextOptions))
            {
                separateContext.ActivityLog.Add(activityLog);
                await separateContext.SaveChangesAsync();
            }

            logger.LogDebug("✅ Activity logged: {Method} {Url} by {User}",
                activityDto.Method, activityDto.Url, activityDto.UserName ?? "Anonymous");
        }
        catch (Exception ex)
        {
            // ⚠️ No fallar si el logging falla - solo registrar en consola
            logger.LogError(ex, "❌ Failed to log activity: {Method} {Url}",
                activityDto.Method, activityDto.Url);
        }
    }

    public async Task<IEnumerable<ActivityLog>> GetRecentActivitiesAsync(int count = 100)
    {
        using var context = new LpContabContext(dbContextOptions);
        return await context.ActivityLog
            .OrderByDescending(a => a.Timestamp)
            .Take(count)
            .ToListAsync();
    }

    public async Task<IEnumerable<ActivityLog>> GetActivitiesByUserAsync(int usuarioId, int count = 100)
    {
        using var context = new LpContabContext(dbContextOptions);
        return await context.ActivityLog
            .Where(a => a.UsuarioId == usuarioId)
            .OrderByDescending(a => a.Timestamp)
            .Take(count)
            .ToListAsync();
    }

    public async Task<IEnumerable<ActivityLog>> GetActivitiesByDateRangeAsync(DateTime startDate, DateTime endDate)
    {
        using var context = new LpContabContext(dbContextOptions);
        return await context.ActivityLog
            .Where(a => a.Timestamp >= startDate && a.Timestamp <= endDate)
            .OrderByDescending(a => a.Timestamp)
            .ToListAsync();
    }
}

/// <summary>
/// DTO para transferir datos de actividad al servicio
/// </summary>
public class ActivityLogDto
{
    public int? UsuarioId { get; set; }
    public string? UserName { get; set; }
    public int? EmpresaId { get; set; }
    public string? IpAddress { get; set; }
    public string? Host { get; set; }
    public string? Url { get; set; }
    public string? Method { get; set; }
    public int? StatusCode { get; set; }
    public int? Duration { get; set; }
    public string? RequestBody { get; set; }
    public string? UserAgent { get; set; }
}
