using App.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace App.Services;

/// <summary>
/// Servicio para generación automática de movimientos contables (asientos)
/// Migrado desde VB6: GenMovDocumento en múltiples formularios
/// </summary>
public class MovimientosContablesService : IMovimientosContablesService
{
    private readonly LpContabContext context;
    private readonly ILogger<MovimientosContablesService> logger;

    public MovimientosContablesService(LpContabContext context, ILogger<MovimientosContablesService> logger)
    {
        this.context = context;
        this.logger = logger;
    }

    /// <summary>
    /// Genera movimientos contables para un documento de libro
    /// Migrado desde VB6: GenMovDocumento
    /// </summary>
    /// <param name="idDoc">ID del documento</param>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año contable</param>
    /// <returns>True si se generaron correctamente</returns>
    public async Task<bool> GenerarMovimientosDocumentoAsync(int idDoc, int empresaId, int ano)
    {
        {
            logger.LogInformation(
                "Generando movimientos contables para documento IdDoc={IdDoc}, Empresa={EmpresaId}, Año={Ano}",
                idDoc, empresaId, ano);

            // 1. Obtener el documento
            var documento = await context.Documento
                .FirstOrDefaultAsync(d => 
                    d.IdDoc == idDoc && 
                    d.IdEmpresa == empresaId && 
                    d.Ano == ano);

            if (documento == null)
            {
                logger.LogWarning("Documento no encontrado: IdDoc={IdDoc}", idDoc);
                return false;
            }

            // 2. Eliminar movimientos existentes (si los hay)
            await EliminarMovimientosDocumentoAsync(idDoc, empresaId, ano);

            // 3. Generar movimientos según tipo de libro
            var resultado = documento.TipoLib switch
            {
                1 => await GenerarMovimientosComprasAsync(documento),      // Libro de Compras
                2 => await GenerarMovimientosVentasAsync(documento),       // Libro de Ventas
                3 => await GenerarMovimientosRetencionesAsync(documento),  // Libro de Retenciones
                4 => await GenerarMovimientosOtrosAsync(documento),        // Otros Documentos
                _ => false
            };

            if (resultado)
            {
                logger.LogInformation(
                    "Movimientos contables generados exitosamente para documento IdDoc={IdDoc}",
                    idDoc);
            }

            return resultado;
        }
    }

    /// <summary>
    /// Genera movimientos para documentos del Libro de Retenciones
    /// Migrado desde VB6: FrmLibRetenciones.GenMovDocumento líneas 4270-4430
    /// </summary>
    private async Task<bool> GenerarMovimientosRetencionesAsync(Documento documento)
    {
        {
            var orden = 1;
            var glosa = documento.Descrip?.Length > 50 
                ? documento.Descrip.Substring(0, 50) 
                : documento.Descrip ?? "";

            var glosaImpuesto = $"[Doc {documento.NumDoc}] {documento.RutEntidad ?? ""} {documento.NombreEntidad ?? ""}";
            glosaImpuesto = glosaImpuesto.Length > 50 
                ? glosaImpuesto.Substring(0, 50) 
                : glosaImpuesto;

            // 1. Movimiento: Bruto / Honorarios Sin Retención (DEBE)
            if ((documento.Exento ?? 0) > 0 || (documento.Afecto ?? 0) > 0)
            {
                int idTipoValLib;
                double monto;

                if ((documento.Exento ?? 0) > 0)
                {
                    // Honorarios sin retención
                    monto = documento.Exento.Value;
                    idTipoValLib = 2; // LIBRETEN_HONORSINRET
                }
                else
                {
                    // Bruto (con retención)
                    monto = documento.Afecto.Value;
                    idTipoValLib = 1; // LIBRETEN_BRUTO
                }

                await CrearMovimientoAsync(new MovDocumento
                {
                    IdDoc = documento.IdDoc,
                    IdEmpresa = documento.IdEmpresa,
                    Ano = documento.Ano,
                    Orden = (byte)orden++,
                    IdCuenta = documento.IdCuentaAfecto ?? documento.IdCuentaExento ?? 0,
                    Debe = monto,
                    Haber = 0,
                    Glosa = glosa,
                    IdTipoValLib = (short)idTipoValLib,
                    EsTotalDoc = false,
                    IdCCosto = null, // TODO: Obtener de configuración de cuenta
                    IdAreaNeg = null // TODO: Obtener de configuración de cuenta
                });
            }

            // 2. Movimiento: Impuesto Retenido (HABER)
            if ((documento.OtroImp ?? 0) > 0)
            {
                await CrearMovimientoAsync(new MovDocumento
                {
                    IdDoc = documento.IdDoc,
                    IdEmpresa = documento.IdEmpresa,
                    Ano = documento.Ano,
                    Orden = (byte)orden++,
                    IdCuenta = documento.IdCuentaOtroImp ?? 0,
                    Debe = 0,
                    Haber = documento.OtroImp.Value,
                    Glosa = glosaImpuesto,
                    IdTipoValLib = 4, // LIBRETEN_IMPUESTO
                    EsTotalDoc = false,
                    IdCCosto = null, // TODO: Obtener de configuración de cuenta
                    IdAreaNeg = null // TODO: Obtener de configuración de cuenta
                });
            }

            // 3. Movimiento: Retención 3% (HABER) - si aplica
            if ((documento.ValRet3Porc ?? 0) > 0)
            {
                await CrearMovimientoAsync(new MovDocumento
                {
                    IdDoc = documento.IdDoc,
                    IdEmpresa = documento.IdEmpresa,
                    Ano = documento.Ano,
                    Orden = (byte)orden++,
                    IdCuenta = documento.IdCuentaRet3Porc ?? 0,
                    Debe = 0,
                    Haber = documento.ValRet3Porc.Value,
                    Glosa = "Retención 3% Préstamo Solidario",
                    IdTipoValLib = 4, // LIBRETEN_IMPUESTO
                    EsTotalDoc = false,
                    IdCCosto = null, // TODO: Obtener de configuración de cuenta
                    IdAreaNeg = null // TODO: Obtener de configuración de cuenta
                });
            }

            // 4. Movimiento: Total (HABER)
            if ((documento.Total ?? 0) > 0)
            {
                await CrearMovimientoAsync(new MovDocumento
                {
                    IdDoc = documento.IdDoc,
                    IdEmpresa = documento.IdEmpresa,
                    Ano = documento.Ano,
                    Orden = (byte)orden++,
                    IdCuenta = documento.IdCuentaTotal ?? 0,
                    Debe = 0,
                    Haber = documento.Total.Value,
                    Glosa = glosa,
                    IdTipoValLib = 3, // LIBRETEN_TOTAL
                    EsTotalDoc = true, // Marca como total del documento
                    IdCCosto = null, // TODO: Obtener de configuración de cuenta
                    IdAreaNeg = null // TODO: Obtener de configuración de cuenta
                });
            }

            await context.SaveChangesAsync();
            return true;
        }
    }

    /// <summary>
    /// Genera movimientos para documentos del Libro de Compras
    /// </summary>
    private async Task<bool> GenerarMovimientosComprasAsync(Documento documento)
    {
        {
            var orden = 1;
            var glosa = documento.Descrip?.Length > 50 
                ? documento.Descrip.Substring(0, 50) 
                : documento.Descrip ?? "";

            // 1. Movimiento: Afecto (DEBE)
            if ((documento.Afecto ?? 0) > 0)
            {
                await CrearMovimientoAsync(new MovDocumento
                {
                    IdDoc = documento.IdDoc,
                    IdEmpresa = documento.IdEmpresa,
                    Ano = documento.Ano,
                    Orden = (byte)orden++,
                    IdCuenta = documento.IdCuentaAfecto ?? 0,
                    Debe = documento.Afecto.Value,
                    Haber = 0,
                    Glosa = glosa,
                    IdTipoValLib = 1, // AFECTO
                    EsTotalDoc = false,
                    IdCCosto = null, // TODO: Obtener de configuración de cuenta
                    IdAreaNeg = null // TODO: Obtener de configuración de cuenta
                });
            }

            // 2. Movimiento: Exento (DEBE)
            if ((documento.Exento ?? 0) > 0)
            {
                await CrearMovimientoAsync(new MovDocumento
                {
                    IdDoc = documento.IdDoc,
                    IdEmpresa = documento.IdEmpresa,
                    Ano = documento.Ano,
                    Orden = (byte)orden++,
                    IdCuenta = documento.IdCuentaExento ?? 0,
                    Debe = documento.Exento.Value,
                    Haber = 0,
                    Glosa = glosa,
                    IdTipoValLib = 2, // EXENTO
                    EsTotalDoc = false,
                    IdCCosto = null, // TODO: Obtener de configuración de cuenta
                    IdAreaNeg = null // TODO: Obtener de configuración de cuenta
                });
            }

            // 3. Movimiento: IVA (DEBE)
            if ((documento.IVA ?? 0) > 0)
            {
                await CrearMovimientoAsync(new MovDocumento
                {
                    IdDoc = documento.IdDoc,
                    IdEmpresa = documento.IdEmpresa,
                    Ano = documento.Ano,
                    Orden = (byte)orden++,
                    IdCuenta = documento.IdCuentaIVA ?? 0,
                    Debe = documento.IVA.Value,
                    Haber = 0,
                    Glosa = "IVA Crédito Fiscal",
                    IdTipoValLib = 4, // IVA
                    EsTotalDoc = false,
                    IdCCosto = null, // TODO: Obtener de configuración de cuenta
                    IdAreaNeg = null // TODO: Obtener de configuración de cuenta
                });
            }

            // 4. Movimiento: Otro Impuesto (DEBE)
            if ((documento.OtroImp ?? 0) > 0)
            {
                await CrearMovimientoAsync(new MovDocumento
                {
                    IdDoc = documento.IdDoc,
                    IdEmpresa = documento.IdEmpresa,
                    Ano = documento.Ano,
                    Orden = (byte)orden++,
                    IdCuenta = documento.IdCuentaOtroImp ?? 0,
                    Debe = documento.OtroImp.Value,
                    Haber = 0,
                    Glosa = "Otro Impuesto",
                    IdTipoValLib = 5, // OTRO_IMPUESTO
                    EsTotalDoc = false,
                    IdCCosto = null, // TODO: Obtener de configuración de cuenta
                    IdAreaNeg = null // TODO: Obtener de configuración de cuenta
                });
            }

            // 5. Movimiento: Total (HABER) - Cuenta por Pagar
            if ((documento.Total ?? 0) > 0)
            {
                await CrearMovimientoAsync(new MovDocumento
                {
                    IdDoc = documento.IdDoc,
                    IdEmpresa = documento.IdEmpresa,
                    Ano = documento.Ano,
                    Orden = (byte)orden++,
                    IdCuenta = documento.IdCuentaTotal ?? 0,
                    Debe = 0,
                    Haber = documento.Total.Value,
                    Glosa = glosa,
                    IdTipoValLib = 3, // TOTAL
                    EsTotalDoc = true,
                    IdCCosto = null, // TODO: Obtener de configuración de cuenta
                    IdAreaNeg = null // TODO: Obtener de configuración de cuenta
                });
            }

            await context.SaveChangesAsync();
            return true;
        }
    }

    /// <summary>
    /// Genera movimientos para documentos del Libro de Ventas
    /// </summary>
    private async Task<bool> GenerarMovimientosVentasAsync(Documento documento)
    {
        {
            var orden = 1;
            var glosa = documento.Descrip?.Length > 50 
                ? documento.Descrip.Substring(0, 50) 
                : documento.Descrip ?? "";

            // 1. Movimiento: Total (DEBE) - Cuenta por Cobrar
            if ((documento.Total ?? 0) > 0)
            {
                await CrearMovimientoAsync(new MovDocumento
                {
                    IdDoc = documento.IdDoc,
                    IdEmpresa = documento.IdEmpresa,
                    Ano = documento.Ano,
                    Orden = (byte)orden++,
                    IdCuenta = documento.IdCuentaTotal ?? 0,
                    Debe = documento.Total.Value,
                    Haber = 0,
                    Glosa = glosa,
                    IdTipoValLib = 3, // TOTAL
                    EsTotalDoc = true,
                    IdCCosto = null, // TODO: Obtener de configuración de cuenta
                    IdAreaNeg = null // TODO: Obtener de configuración de cuenta
                });
            }

            // 2. Movimiento: Afecto (HABER)
            if ((documento.Afecto ?? 0) > 0)
            {
                await CrearMovimientoAsync(new MovDocumento
                {
                    IdDoc = documento.IdDoc,
                    IdEmpresa = documento.IdEmpresa,
                    Ano = documento.Ano,
                    Orden = (byte)orden++,
                    IdCuenta = documento.IdCuentaAfecto ?? 0,
                    Debe = 0,
                    Haber = documento.Afecto.Value,
                    Glosa = glosa,
                    IdTipoValLib = 1, // AFECTO
                    EsTotalDoc = false,
                    IdCCosto = null, // TODO: Obtener de configuración de cuenta
                    IdAreaNeg = null // TODO: Obtener de configuración de cuenta
                });
            }

            // 3. Movimiento: Exento (HABER)
            if ((documento.Exento ?? 0) > 0)
            {
                await CrearMovimientoAsync(new MovDocumento
                {
                    IdDoc = documento.IdDoc,
                    IdEmpresa = documento.IdEmpresa,
                    Ano = documento.Ano,
                    Orden = (byte)orden++,
                    IdCuenta = documento.IdCuentaExento ?? 0,
                    Debe = 0,
                    Haber = documento.Exento.Value,
                    Glosa = glosa,
                    IdTipoValLib = 2, // EXENTO
                    EsTotalDoc = false,
                    IdCCosto = null, // TODO: Obtener de configuración de cuenta
                    IdAreaNeg = null // TODO: Obtener de configuración de cuenta
                });
            }

            // 4. Movimiento: IVA (HABER)
            if ((documento.IVA ?? 0) > 0)
            {
                await CrearMovimientoAsync(new MovDocumento
                {
                    IdDoc = documento.IdDoc,
                    IdEmpresa = documento.IdEmpresa,
                    Ano = documento.Ano,
                    Orden = (byte)orden++,
                    IdCuenta = documento.IdCuentaIVA ?? 0,
                    Debe = 0,
                    Haber = documento.IVA.Value,
                    Glosa = "IVA Débito Fiscal",
                    IdTipoValLib = 4, // IVA
                    EsTotalDoc = false,
                    IdCCosto = null, // TODO: Obtener de configuración de cuenta
                    IdAreaNeg = null // TODO: Obtener de configuración de cuenta
                });
            }

            // 5. Movimiento: Otro Impuesto (HABER)
            if ((documento.OtroImp ?? 0) > 0)
            {
                await CrearMovimientoAsync(new MovDocumento
                {
                    IdDoc = documento.IdDoc,
                    IdEmpresa = documento.IdEmpresa,
                    Ano = documento.Ano,
                    Orden = (byte)orden++,
                    IdCuenta = documento.IdCuentaOtroImp ?? 0,
                    Debe = 0,
                    Haber = documento.OtroImp.Value,
                    Glosa = "Otro Impuesto",
                    IdTipoValLib = 5, // OTRO_IMPUESTO
                    EsTotalDoc = false,
                    IdCCosto = null, // TODO: Obtener de configuración de cuenta
                    IdAreaNeg = null // TODO: Obtener de configuración de cuenta
                });
            }

            await context.SaveChangesAsync();
            return true;
        }
    }

    /// <summary>
    /// Genera movimientos para Otros Documentos
    /// </summary>
    private async Task<bool> GenerarMovimientosOtrosAsync(Documento documento)
    {
        {
            var orden = 1;
            var glosa = documento.Descrip?.Length > 50 
                ? documento.Descrip.Substring(0, 50) 
                : documento.Descrip ?? "";

            // Para otros documentos, generamos movimientos simples
            // Cargo (DEBE) y Abono (HABER)

            if ((documento.Afecto ?? 0) > 0) // Usar Afecto como Cargo
            {
                await CrearMovimientoAsync(new MovDocumento
                {
                    IdDoc = documento.IdDoc,
                    IdEmpresa = documento.IdEmpresa,
                    Ano = documento.Ano,
                    Orden = (byte)orden++,
                    IdCuenta = documento.IdCuentaAfecto ?? 0,
                    Debe = documento.Afecto.Value,
                    Haber = 0,
                    Glosa = glosa,
                    IdTipoValLib = 1, // CARGO
                    EsTotalDoc = false,
                    IdCCosto = null, // TODO: Obtener de configuración de cuenta
                    IdAreaNeg = null // TODO: Obtener de configuración de cuenta
                });
            }

            if ((documento.Total ?? 0) > 0) // Usar Total como Abono
            {
                await CrearMovimientoAsync(new MovDocumento
                {
                    IdDoc = documento.IdDoc,
                    IdEmpresa = documento.IdEmpresa,
                    Ano = documento.Ano,
                    Orden = (byte)orden++,
                    IdCuenta = documento.IdCuentaTotal ?? 0,
                    Debe = 0,
                    Haber = documento.Total.Value,
                    Glosa = glosa,
                    IdTipoValLib = 2, // ABONO
                    EsTotalDoc = true,
                    IdCCosto = null, // TODO: Obtener de configuración de cuenta
                    IdAreaNeg = null // TODO: Obtener de configuración de cuenta
                });
            }

            await context.SaveChangesAsync();
            return true;
        }
    }

    /// <summary>
    /// Crea un movimiento contable en la base de datos
    /// </summary>
    private async Task CrearMovimientoAsync(MovDocumento movimiento)
    {
        context.MovDocumento.Add(movimiento);
        await Task.CompletedTask; // SaveChanges se hace al final de cada método
    }

    /// <summary>
    /// Elimina todos los movimientos existentes de un documento
    /// </summary>
    public async Task<bool> EliminarMovimientosDocumentoAsync(int idDoc, int empresaId, int ano)
    {
        {
            var movimientos = await context.MovDocumento
                .Where(m => m.IdDoc == idDoc && m.IdEmpresa == empresaId && m.Ano == ano)
                .ToListAsync();

            if (movimientos.Any())
            {
                context.MovDocumento.RemoveRange(movimientos);
                await context.SaveChangesAsync();

                logger.LogInformation(
                    "Eliminados {Count} movimientos del documento IdDoc={IdDoc}",
                    movimientos.Count, idDoc);
            }

            return true;
        }
    }

    /// <summary>
    /// Valida que los movimientos de un documento estén cuadrados (Debe = Haber)
    /// </summary>
    public async Task<(bool Cuadrado, double Diferencia)> ValidarCuadraturaAsync(int idDoc, int empresaId, int ano)
    {
        {
            var movimientos = await context.MovDocumento
                .Where(m => m.IdDoc == idDoc && m.IdEmpresa == empresaId && m.Ano == ano)
                .ToListAsync();

            var totalDebe = movimientos.Sum(m => m.Debe ?? 0);
            var totalHaber = movimientos.Sum(m => m.Haber ?? 0);
            var diferencia = Math.Abs(totalDebe - totalHaber);

            var cuadrado = diferencia < 0.01; // Tolerancia de 1 centavo

            if (!cuadrado)
            {
                logger.LogWarning(
                    "Documento IdDoc={IdDoc} NO está cuadrado. Debe={Debe}, Haber={Haber}, Diferencia={Diferencia}",
                    idDoc, totalDebe, totalHaber, diferencia);
            }

            return (cuadrado, diferencia);
        }
    }
}

public interface IMovimientosContablesService
{
    Task<bool> GenerarMovimientosDocumentoAsync(int idDoc, int empresaId, int ano);
    Task<bool> EliminarMovimientosDocumentoAsync(int idDoc, int empresaId, int ano);
    Task<(bool Cuadrado, double Diferencia)> ValidarCuadraturaAsync(int idDoc, int empresaId, int ano);
}

