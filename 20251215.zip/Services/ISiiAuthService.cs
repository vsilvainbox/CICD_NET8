namespace App.Services;

/// <summary>
/// Interfaz para servicio de autenticación y consultas al SII (Servicio de Impuestos Internos)
/// Basado en funciones VB6: SucursalSII, FwPostPageSII2
/// </summary>
public interface ISiiAuthService
{
    /// <summary>
    /// Obtiene las sucursales de una empresa desde el SII
    /// Requiere autenticación con RUT y clave SII
    /// </summary>
    /// <param name="rut">RUT de la empresa (formato: 12345678-9)</param>
    /// <param name="clave">Clave SII de la empresa</param>
    /// <returns>Lista de sucursales importadas desde SII</returns>
    Task<List<SucursalSiiDto>> ObtenerSucursalesDesdeSiiAsync(string rut, string clave);

    /// <summary>
    /// Valida si la clave SII es correcta para el RUT dado
    /// </summary>
    /// <param name="rut">RUT de la empresa</param>
    /// <param name="clave">Clave SII</param>
    /// <returns>True si las credenciales son válidas</returns>
    Task<bool> ValidarCredencialesSiiAsync(string rut, string clave);
}

/// <summary>
/// DTO para sucursal obtenida desde SII
/// </summary>
public class SucursalSiiDto
{
    public string Codigo { get; set; } = string.Empty;
    public string Descripcion { get; set; } = string.Empty;
    public string? Calle { get; set; }
    public string? Numero { get; set; }
    public string? Ciudad { get; set; }
    public int TipoDomicilio { get; set; } // 1=Casa Matriz, 3=Sucursal
}
