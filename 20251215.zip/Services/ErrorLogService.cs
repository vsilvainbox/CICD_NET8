using App.Data;
using App.Exceptions;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace App.Services;

public interface IErrorLogService
{
    Task LogErrorAsync(ErrorLogDto errorDto);
    Task<IEnumerable<ErrorLog>> GetRecentErrorsAsync(int count = 100);
    Task<ErrorLog> GetErrorByIdAsync(int id);
    Task<bool> MarkAsResolvedAsync(int id, int resolvedBy, string? notes = null);
    Task<IEnumerable<ErrorLog>> GetUnresolvedErrorsAsync();
}

public class ErrorLogService(
    LpContabContext context,
    DbContextOptions<LpContabContext> dbContextOptions,
    ILogger<ErrorLogService> logger) : IErrorLogService
{
    public async Task LogErrorAsync(ErrorLogDto errorDto)
    {
        {
            logger.LogInformation("🔍 ErrorLogService.LogErrorAsync INICIADO. Message: {Message}", errorDto.Message);

            var errorLog = new ErrorLog
            {
                Timestamp = DateTime.Now,
                Source = errorDto.Source ?? "Unknown",
                Severity = errorDto.Severity ?? "Error",
                Message = errorDto.Message ?? "No message",
                StackTrace = errorDto.StackTrace,
                Url = errorDto.Url,
                UserAgent = errorDto.UserAgent,
                UsuarioId = errorDto.UsuarioId,
                EmpresaId = errorDto.EmpresaId,
                AdditionalData = errorDto.AdditionalData != null
                    ? JsonSerializer.Serialize(errorDto.AdditionalData)
                    : null,
                IPAddress = errorDto.IPAddress,
                ExceptionType = errorDto.ExceptionType,
                Origin = errorDto.Origin ?? "Backend",
                Resolved = false
            };

            logger.LogInformation("🔍 ErrorLog entity creado. Creando DbContext separado para evitar conflictos...");

            // ✅ SOLUCIÓN: Usar un DbContext separado para evitar conflictos con el contexto principal
            // que podría estar en estado inválido cuando ocurre una excepción
            using (var separateContext = new LpContabContext(dbContextOptions))
            {
                separateContext.ErrorLog.Add(errorLog);

                logger.LogInformation("🔍 Guardando cambios en BD con contexto separado (SaveChangesAsync)...");

                await separateContext.SaveChangesAsync();

                logger.LogInformation("✅ Error guardado exitosamente en BD con ID: {IdError}", errorLog.IdError);
            }
        }
    }

    public async Task<IEnumerable<ErrorLog>> GetRecentErrorsAsync(int count = 100)
    {
        return await context.ErrorLog
            .OrderByDescending(e => e.Timestamp)
            .Take(count)
            .ToListAsync();
    }

    public async Task<ErrorLog> GetErrorByIdAsync(int id)
    {
        var error = await context.ErrorLog.FindAsync(id);
        if (error == null)
        {
            throw new BusinessException("Error no encontrado");
        }
        return error;
    }

    public async Task<bool> MarkAsResolvedAsync(int id, int resolvedBy, string? notes = null)
    {
        var error = await context.ErrorLog.FindAsync(id);
        if (error == null) return false;

        error.Resolved = true;
        error.ResolvedBy = resolvedBy;
        error.ResolvedAt = DateTime.Now;
        error.Notes = notes;

        await context.SaveChangesAsync();
        return true;
    }

    public async Task<IEnumerable<ErrorLog>> GetUnresolvedErrorsAsync()
    {
        return await context.ErrorLog
            .Where(e => !e.Resolved)
            .OrderByDescending(e => e.Timestamp)
            .ToListAsync();
    }
}

public class ErrorLogDto
{
    public string? Source { get; set; }
    public string? Severity { get; set; }
    public string? Message { get; set; }
    public string? StackTrace { get; set; }
    public string? Url { get; set; }
    public string? UserAgent { get; set; }
    public int? UsuarioId { get; set; }
    public int? EmpresaId { get; set; }
    public object? AdditionalData { get; set; }
    public string? IPAddress { get; set; }
    public string? ExceptionType { get; set; }
    public string? Origin { get; set; }
}
