$(document).ready(function() {
    // Variables globales
    let resultados = [];
    let ordenActual = 'fechahora';
    let direccionOrden = 'desc';

    // Inicializar
    inicializar();

    function inicializar() {
        configurarEventos();
        configurarDatePickers();
    }

    function configurarEventos() {
        // Botones principales
        $('#btnBuscar').click(buscar);
        $('#btnExportExcel').click(exportarExcel);
        $('#btnExportPDF').click(exportarPDF);
        $('#btnImprimir').click(imprimir);
        $('#btnEstadisticas').click(mostrarEstadisticas);
        $('#btnLimpiarFiltros').click(limpiarFiltros);

        // Ordenamiento de columnas
        $('#gridSeguimiento th[data-sort]').click(function() {
            const columna = $(this).data('sort');
            ordenarPorColumna(columna);
        });

        // Selectores de fecha
        $('.btn[id^="btnFecha"]').click(function() {
            const inputId = $(this).attr('id').replace('btn', '').toLowerCase();
            mostrarDatePicker('#' + inputId);
        });
    }

    function configurarDatePickers() {
        // Configurar date pickers con rangos
        $('#fechaOperacionDesde, #fechaComprobanteDesde').change(function() {
            const desde = $(this).val();
            const hasta = $(this).attr('id').replace('Desde', 'Hasta');
            if (desde && $('#' + hasta).val() && $('#' + hasta).val() < desde) {
                const fechaHasta = new Date(desde);
                fechaHasta.setMonth(fechaHasta.getMonth() + 1);
                $('#' + hasta).val(fechaHasta.toISOString().split('T')[0]);
            }
        });
    }

    function buscar() {
        const filtros = obtenerFiltros();
        
        if (!filtros.TieneFiltrosActivos()) {
            mostrarError('Debe ingresar al menos un filtro');
            return;
        }

        mostrarCargando('Buscando seguimiento...');

        $.ajax({
            url: '/SeguimientoCambios/Search',
            type: 'POST',
            data: JSON.stringify(filtros),
            contentType: 'application/json',
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                if (response.success) {
                    resultados = response.resultados;
                    mostrarResultados(resultados);
                    $('#totalResultados').text(response.total + ' registros');
                    $('#resultadosContainer').show();
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al buscar seguimiento');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function obtenerFiltros() {
        return {
            FechaOperacionDesde: $('#fechaOperacionDesde').val() ? new Date($('#fechaOperacionDesde').val()) : null,
            FechaOperacionHasta: $('#fechaOperacionHasta').val() ? new Date($('#fechaOperacionHasta').val()) : null,
            FechaComprobanteDesde: $('#fechaComprobanteDesde').val() ? new Date($('#fechaComprobanteDesde').val()) : null,
            FechaComprobanteHasta: $('#fechaComprobanteHasta').val() ? new Date($('#fechaComprobanteHasta').val()) : null,
            IdUsuario: $('#usuario').val() ? parseInt($('#usuario').val()) : null,
            NumComp: $('#numComp').val() ? parseInt($('#numComp').val()) : null,
            TipoComprobante: $('#tipoComprobante').val() ? parseInt($('#tipoComprobante').val()) : null,
            TipoAjuste: $('#tipoAjuste').val() ? parseInt($('#tipoAjuste').val()) : null,
            Operacion: $('#operacion').val() ? parseInt($('#operacion').val()) : null,
            OrdenPor: ordenActual,
            DireccionOrden: direccionOrden.toUpperCase(),
            Pagina: 1,
            TamañoPagina: 100
        };
    }

    function mostrarResultados(datos) {
        const tbody = $('#gridBody');
        tbody.empty();

        if (datos.length === 0) {
            tbody.append('<tr><td colspan="15" class="text-center">No se encontraron registros</td></tr>');
            return;
        }

        datos.forEach(function(item) {
            const row = `
                <tr>
                    <td>${formatearFechaHora(item.fechaHora)}</td>
                    <td>${item.correlativo}</td>
                    <td>${formatearFecha(item.fecha)}</td>
                    <td><span class="badge badge-${getTipoClass(item.tipo)}">${item.tipoNombre}</span></td>
                    <td><span class="badge badge-${getEstadoClass(item.estado)}">${item.estadoNombre}</span></td>
                    <td>${item.glosa}</td>
                    <td class="text-right">${formatearNumero(item.totalDebe)}</td>
                    <td class="text-right">${formatearNumero(item.totalHaber)}</td>
                    <td>${item.usuario}</td>
                    <td>${formatearFecha(item.fechaCreacion)}</td>
                    <td><span class="badge badge-${getFormaIngresoClass(item.formaIngreso)}">${item.formaIngresoTexto}</span></td>
                    <td><span class="badge badge-${getAjusteClass(item.ajuste)}">${item.ajusteTexto}</span></td>
                    <td><span class="badge badge-${item.vigente ? 'success' : 'danger'}">${item.vigenteTexto}</span></td>
                    <td>
                        <button type="button" class="btn btn-sm btn-info" onclick="verDetalle(${item.idComp})">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button type="button" class="btn btn-sm btn-warning" onclick="verHistorial(${item.idComp})">
                            <i class="fas fa-history"></i>
                        </button>
                    </td>
                </tr>
            `;
            tbody.append(row);
        });
    }

    function ordenarPorColumna(columna) {
        if (ordenActual === columna) {
            direccionOrden = direccionOrden === 'desc' ? 'asc' : 'desc';
        } else {
            ordenActual = columna;
            direccionOrden = 'desc';
        }

        // Actualizar indicadores visuales
        $('#gridSeguimiento th[data-sort]').removeClass('sort-asc sort-desc');
        const th = $(`#gridSeguimiento th[data-sort="${columna}"]`);
        th.addClass(direccionOrden === 'asc' ? 'sort-asc' : 'sort-desc');

        // Re-buscar con nuevo ordenamiento
        buscar();
    }

    function verDetalle(idComp) {
        mostrarCargando('Cargando detalle...');

        $.ajax({
            url: `/SeguimientoCambios/GetDetalle/${idComp}`,
            type: 'GET',
            success: function(response) {
                if (response.success) {
                    mostrarDetalleComprobante(response.detalle);
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al obtener detalle del comprobante');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function mostrarDetalleComprobante(detalle) {
        const content = `
            <div class="row">
                <div class="col-md-6">
                    <h6>Información del Comprobante</h6>
                    <table class="table table-sm">
                        <tr><td><strong>ID:</strong></td><td>${detalle.idComp}</td></tr>
                        <tr><td><strong>Correlativo:</strong></td><td>${detalle.correlativo}</td></tr>
                        <tr><td><strong>Fecha:</strong></td><td>${formatearFecha(detalle.fecha)}</td></tr>
                        <tr><td><strong>Tipo:</strong></td><td>${detalle.tipo}</td></tr>
                        <tr><td><strong>Estado:</strong></td><td>${detalle.estado}</td></tr>
                        <tr><td><strong>Glosa:</strong></td><td>${detalle.glosa}</td></tr>
                        <tr><td><strong>Total Debe:</strong></td><td>${formatearNumero(detalle.totalDebe)}</td></tr>
                        <tr><td><strong>Total Haber:</strong></td><td>${formatearNumero(detalle.totalHaber)}</td></tr>
                        <tr><td><strong>Usuario:</strong></td><td>${detalle.usuario}</td></tr>
                        <tr><td><strong>Fecha Creación:</strong></td><td>${formatearFecha(detalle.fechaCreacion)}</td></tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <h6>Movimientos</h6>
                    <div class="table-responsive">
                        <table class="table table-sm table-striped">
                            <thead>
                                <tr>
                                    <th>Cuenta</th>
                                    <th>Debe</th>
                                    <th>Haber</th>
                                    <th>Glosa</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${detalle.movimientos.map(mov => `
                                    <tr>
                                        <td>${mov.cuenta} - ${mov.nombreCuenta}</td>
                                        <td class="text-right">${formatearNumero(mov.debe)}</td>
                                        <td class="text-right">${formatearNumero(mov.haber)}</td>
                                        <td>${mov.glosa}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-12">
                    <h6>Historial de Cambios</h6>
                    <div class="table-responsive">
                        <table class="table table-sm table-striped">
                            <thead>
                                <tr>
                                    <th>Fecha y Hora</th>
                                    <th>Usuario</th>
                                    <th>Operación</th>
                                    <th>Observaciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${detalle.historial.map(hist => `
                                    <tr>
                                        <td>${formatearFechaHora(hist.fechaHora)}</td>
                                        <td>${hist.usuario}</td>
                                        <td>${hist.operacion}</td>
                                        <td>${hist.observaciones}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;

        $('#detalleContent').html(content);
        $('#modalDetalle').modal('show');
    }

    function verHistorial(idComp) {
        mostrarCargando('Cargando historial...');

        $.ajax({
            url: `/SeguimientoCambios/GetHistorialCompleto/${idComp}`,
            type: 'GET',
            success: function(response) {
                if (response.success) {
                    mostrarHistorialCompleto(response.historial);
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al obtener historial completo');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function mostrarHistorialCompleto(historial) {
        const content = `
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Fecha y Hora</th>
                            <th>Usuario</th>
                            <th>Operación</th>
                            <th>Detalle</th>
                            <th>Observaciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${historial.map(hist => `
                            <tr>
                                <td>${formatearFechaHora(hist.fechaHora)}</td>
                                <td>${hist.usuario}</td>
                                <td><span class="badge badge-info">${hist.operacion}</span></td>
                                <td>${hist.detalle}</td>
                                <td>${hist.observaciones}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;

        $('#detalleContent').html(content);
        $('#modalDetalle').modal('show');
    }

    function exportarExcel() {
        const filtros = obtenerFiltros();
        
        if (!filtros.TieneFiltrosActivos()) {
            mostrarError('Debe ingresar al menos un filtro');
            return;
        }

        mostrarCargando('Exportando a Excel...');

        $.ajax({
            url: '/SeguimientoCambios/ExportExcel',
            type: 'POST',
            data: JSON.stringify(filtros),
            contentType: 'application/json',
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                if (response.success) {
                    descargarArchivo(response.data, 'SeguimientoCambios.xlsx');
                    mostrarExito('Archivo Excel exportado exitosamente');
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al exportar a Excel');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function exportarPDF() {
        const filtros = obtenerFiltros();
        
        if (!filtros.TieneFiltrosActivos()) {
            mostrarError('Debe ingresar al menos un filtro');
            return;
        }

        mostrarCargando('Exportando a PDF...');

        $.ajax({
            url: '/SeguimientoCambios/ExportPDF',
            type: 'POST',
            data: JSON.stringify(filtros),
            contentType: 'application/json',
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                if (response.success) {
                    descargarArchivo(response.data, 'SeguimientoCambios.pdf');
                    mostrarExito('Archivo PDF exportado exitosamente');
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al exportar a PDF');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function imprimir() {
        const filtros = obtenerFiltros();
        
        if (!filtros.TieneFiltrosActivos()) {
            mostrarError('Debe ingresar al menos un filtro');
            return;
        }

        mostrarCargando('Generando datos para impresión...');

        $.ajax({
            url: '/SeguimientoCambios/Print',
            type: 'POST',
            data: JSON.stringify(filtros),
            contentType: 'application/json',
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                if (response.success) {
                    imprimirDatos(response.data);
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al generar datos para impresión');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function imprimirDatos(datos) {
        const ventanaImpresion = window.open('', '_blank');
        const contenido = `
            <html>
                <head>
                    <title>${datos.titulo}</title>
                    <style>
                        body { font-family: Arial, sans-serif; font-size: 12px; }
                        table { width: 100%; border-collapse: collapse; }
                        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                        th { background-color: #f2f2f2; }
                        .text-right { text-align: right; }
                        .text-center { text-align: center; }
                    </style>
                </head>
                <body>
                    <h2>${datos.titulo}</h2>
                    <p><strong>Fecha de Generación:</strong> ${formatearFechaHora(datos.fechaGeneracion)}</p>
                    <p><strong>Total de Registros:</strong> ${datos.totalRegistros}</p>
                    <table>
                        <thead>
                            <tr>
                                <th>Fecha y Hora</th>
                                <th>Correlativo</th>
                                <th>Fecha</th>
                                <th>Tipo</th>
                                <th>Estado</th>
                                <th>Glosa</th>
                                <th>Debe</th>
                                <th>Haber</th>
                                <th>Usuario</th>
                                <th>Forma Ingreso</th>
                                <th>Ajuste</th>
                                <th>Vigente</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${datos.datos.map(item => `
                                <tr>
                                    <td>${formatearFechaHora(item.fechaHora)}</td>
                                    <td>${item.correlativo}</td>
                                    <td>${formatearFecha(item.fecha)}</td>
                                    <td>${item.tipoNombre}</td>
                                    <td>${item.estadoNombre}</td>
                                    <td>${item.glosa}</td>
                                    <td class="text-right">${formatearNumero(item.totalDebe)}</td>
                                    <td class="text-right">${formatearNumero(item.totalHaber)}</td>
                                    <td>${item.usuario}</td>
                                    <td>${item.formaIngresoTexto}</td>
                                    <td>${item.ajusteTexto}</td>
                                    <td>${item.vigenteTexto}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </body>
            </html>
        `;
        
        ventanaImpresion.document.write(contenido);
        ventanaImpresion.document.close();
        ventanaImpresion.print();
    }

    function mostrarEstadisticas() {
        const filtros = obtenerFiltros();
        
        mostrarCargando('Cargando estadísticas...');

        $.ajax({
            url: '/SeguimientoCambios/GetEstadisticas',
            type: 'GET',
            data: filtros,
            success: function(response) {
                if (response.success) {
                    mostrarEstadisticasModal(response.estadisticas);
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al obtener estadísticas');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function mostrarEstadisticasModal(estadisticas) {
        const content = `
            <div class="row">
                <div class="col-md-3">
                    <div class="card bg-primary text-white">
                        <div class="card-body text-center">
                            <h4>${estadisticas.totalRegistros}</h4>
                            <p>Total Registros</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-success text-white">
                        <div class="card-body text-center">
                            <h4>${estadisticas.totalComprobantes}</h4>
                            <p>Total Comprobantes</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-info text-white">
                        <div class="card-body text-center">
                            <h4>${estadisticas.totalUsuarios}</h4>
                            <p>Total Usuarios</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-warning text-white">
                        <div class="card-body text-center">
                            <h4>${estadisticas.totalOperaciones}</h4>
                            <p>Total Operaciones</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-md-6">
                    <div class="card bg-light">
                        <div class="card-body text-center">
                            <h5>Total Debe</h5>
                            <h3>${formatearNumero(estadisticas.totalDebe)}</h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card bg-light">
                        <div class="card-body text-center">
                            <h5>Total Haber</h5>
                            <h3>${formatearNumero(estadisticas.totalHaber)}</h3>
                        </div>
                    </div>
                </div>
            </div>
        `;

        $('#estadisticasModalContent').html(content);
        $('#modalEstadisticas').modal('show');
    }

    function limpiarFiltros() {
        $('#filtrosForm')[0].reset();
        $('#resultadosContainer').hide();
        $('#estadisticasContainer').hide();
        resultados = [];
    }

    function mostrarDatePicker(inputId) {
        // Implementar date picker personalizado si es necesario
        $(inputId).focus();
    }

    function descargarArchivo(data, nombreArchivo) {
        const blob = new Blob([data], { type: 'application/octet-stream' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = nombreArchivo;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    }

    // Funciones de utilidad
    function formatearFecha(fecha) {
        return new Date(fecha).toLocaleDateString('es-CL');
    }

    function formatearFechaHora(fecha) {
        return new Date(fecha).toLocaleString('es-CL');
    }

    function formatearNumero(numero) {
        return new Intl.NumberFormat('es-CL').format(numero);
    }

    function getTipoClass(tipo) {
        switch(tipo) {
            case 1: return 'success'; // Ingreso
            case 2: return 'danger';  // Egreso
            case 3: return 'info';    // Traspaso
            case 4: return 'warning'; // Apertura
            default: return 'secondary';
        }
    }

    function getEstadoClass(estado) {
        switch(estado) {
            case 1: return 'warning'; // Pendiente
            case 2: return 'success'; // Aprobado
            case 3: return 'danger';  // Cancelado
            case 4: return 'dark';    // Anulado
            default: return 'secondary';
        }
    }

    function getFormaIngresoClass(formaIngreso) {
        switch(formaIngreso) {
            case 1: return 'primary'; // Manual
            case 2: return 'info';    // Importado
            default: return 'secondary';
        }
    }

    function getAjusteClass(ajuste) {
        switch(ajuste) {
            case 1: return 'success'; // Creado
            case 2: return 'warning'; // Modificado
            case 3: return 'danger';  // Eliminado
            default: return 'secondary';
        }
    }

    function mostrarCargando(mensaje) {
        // Implementar indicador de carga
        console.log('Cargando: ' + mensaje);
    }

    function ocultarCargando() {
        // Ocultar indicador de carga
        console.log('Carga completada');
    }

    function mostrarError(mensaje) {
        toastr.error(mensaje);
    }

    function mostrarExito(mensaje) {
        toastr.success(mensaje);
    }

    function mostrarInfo(mensaje) {
        toastr.info(mensaje);
    }
});

