// NUEVO COMPROBANTE - JAVASCRIPT
// Funcionalidad del cliente para el formulario de comprobantes

$(document).ready(function() {
    // Variables globales
    let comprobanteId = null;
    let movimientos = [];
    let movimientoSeleccionado = null;
    let modoEdicion = false;

    // Inicialización
    init();

    function init() {
        // Obtener ID del comprobante si existe
        comprobanteId = $('#IdComp').val() || null;
        
        // Configurar eventos
        setupEventHandlers();
        
        // Cargar movimientos si existe comprobante
        if (comprobanteId) {
            cargarMovimientos();
        }
        
        // Calcular totales iniciales
        calcularTotales();
    }

    function setupEventHandlers() {
        // Botones principales del comprobante
        $('#btnGuardar').click(guardarComprobante);
        $('#btnCuadrar').click(cuadrarComprobante);
        $('#btnDuplicar').click(duplicarComprobante);
        $('#btnNuevo').click(nuevoComprobante);
        $('#btnEditar').click(editarComprobante);
        $('#btnEliminar').click(eliminarComprobante);
        $('#btnVistaPrevia').click(vistaPrevia);
        $('#btnImprimir').click(imprimir);
        $('#btnExcel').click(exportarExcel);
        $('#btnSalir').click(salir);

        // Botones de movimientos
        $('#btnAgregarMovimiento').click(agregarMovimiento);
        $('#btnEditarMovimiento').click(editarMovimiento);
        $('#btnEliminarMovimiento').click(eliminarMovimiento);
        $('#btnDuplicarMovimiento').click(duplicarMovimiento);
        $('#btnMoverArriba').click(moverMovimientoArriba);
        $('#btnMoverAbajo').click(moverMovimientoAbajo);
        $('#btnBuscarCuenta').click(buscarCuenta);
        $('#btnCalculadora').click(abrirCalculadora);

        // Modal de movimiento
        $('#btnGuardarMovimiento').click(guardarMovimiento);
        $('#btnBuscarCuentaModal').click(abrirModalBuscarCuenta);

        // Modal de búsqueda de cuentas
        $('#buscarCuentaTerm').on('input', buscarCuentas);
        $('#tablaCuentas').on('click', '.btn-seleccionar-cuenta', seleccionarCuenta);

        // Grid de movimientos
        $('#gridMovimientos').on('click', '.btn-seleccionar-movimiento', seleccionarMovimiento);
        $('#gridMovimientos').on('dblclick', 'tbody tr', editarMovimiento);

        // Validaciones en tiempo real
        $('#movimientoDebe, #movimientoHaber').on('input', validarMontosMovimiento);
        $('#comprobanteForm').on('submit', function(e) {
            e.preventDefault();
            guardarComprobante();
        });
    }

    // FUNCIONES DE COMPROBANTE

    function guardarComprobante() {
        if (!validarFormularioComprobante()) {
            return;
        }

        const formData = {
            Fecha: $('#Fecha').val(),
            Glosa: $('#Glosa').val(),
            Tipo: parseInt($('#Tipo').val()),
            Estado: parseInt($('#Estado').val()),
            Descripcion: $('#Descripcion').val(),
            Nombre: $('#Nombre').val(),
            Usuario: $('#Usuario').val()
        };

        const url = comprobanteId ? 
            `/NuevoComprobante/Update/${comprobanteId}` : 
            '/NuevoComprobante/Create';

        $.ajax({
            url: url,
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(formData),
            success: function(response) {
                if (response.success) {
                    mostrarMensaje('success', response.message);
                    
                    if (!comprobanteId) {
                        comprobanteId = response.id;
                        $('#IdComp').val(comprobanteId);
                        $('#Correlativo').val(response.correlativo);
                        actualizarBotones();
                    }
                } else {
                    mostrarMensaje('error', response.message);
                }
            },
            error: function() {
                mostrarMensaje('error', 'Error al guardar el comprobante');
            }
        });
    }

    function cuadrarComprobante() {
        if (!comprobanteId) {
            mostrarMensaje('warning', 'Debe guardar el comprobante primero');
            return;
        }

        $.ajax({
            url: `/NuevoComprobante/CuadrarComprobante/${comprobanteId}`,
            method: 'POST',
            success: function(response) {
                if (response.success) {
                    mostrarMensaje('success', response.message);
                    actualizarTotales(response.totalDebe, response.totalHaber, response.diferencia);
                } else {
                    mostrarMensaje('warning', response.message);
                    actualizarTotales(response.totalDebe, response.totalHaber, response.diferencia);
                }
            },
            error: function() {
                mostrarMensaje('error', 'Error al cuadrar el comprobante');
            }
        });
    }

    function duplicarComprobante() {
        if (!comprobanteId) {
            mostrarMensaje('warning', 'No hay comprobante para duplicar');
            return;
        }

        if (!confirm('¿Está seguro de que desea duplicar este comprobante?')) {
            return;
        }

        $.ajax({
            url: `/NuevoComprobante/Duplicate/${comprobanteId}`,
            method: 'POST',
            success: function(response) {
                if (response.success) {
                    mostrarMensaje('success', response.message);
                    // Redirigir al nuevo comprobante
                    window.location.href = `/NuevoComprobante/Edit/${response.newId}`;
                } else {
                    mostrarMensaje('error', response.message);
                }
            },
            error: function() {
                mostrarMensaje('error', 'Error al duplicar el comprobante');
            }
        });
    }

    function nuevoComprobante() {
        if (confirm('¿Está seguro de que desea crear un nuevo comprobante? Los cambios no guardados se perderán.')) {
            window.location.href = '/NuevoComprobante';
        }
    }

    function editarComprobante() {
        modoEdicion = true;
        habilitarFormulario(true);
        mostrarMensaje('info', 'Modo edición activado');
    }

    function eliminarComprobante() {
        if (!comprobanteId) {
            mostrarMensaje('warning', 'No hay comprobante para eliminar');
            return;
        }

        if (!confirm('¿Está seguro de que desea eliminar este comprobante? Esta acción no se puede deshacer.')) {
            return;
        }

        $.ajax({
            url: `/NuevoComprobante/Delete/${comprobanteId}`,
            method: 'POST',
            success: function(response) {
                if (response.success) {
                    mostrarMensaje('success', response.message);
                    window.location.href = '/NuevoComprobante';
                } else {
                    mostrarMensaje('error', response.message);
                }
            },
            error: function() {
                mostrarMensaje('error', 'Error al eliminar el comprobante');
            }
        });
    }

    function vistaPrevia() {
        if (!comprobanteId) {
            mostrarMensaje('warning', 'Debe guardar el comprobante primero');
            return;
        }

        // Abrir vista previa en nueva ventana
        window.open(`/NuevoComprobante/Preview/${comprobanteId}`, '_blank');
    }

    function imprimir() {
        if (!comprobanteId) {
            mostrarMensaje('warning', 'Debe guardar el comprobante primero');
            return;
        }

        // Abrir impresión en nueva ventana
        window.open(`/NuevoComprobante/Print/${comprobanteId}`, '_blank');
    }

    function exportarExcel() {
        if (!comprobanteId) {
            mostrarMensaje('warning', 'Debe guardar el comprobante primero');
            return;
        }

        // Descargar Excel
        window.location.href = `/NuevoComprobante/ExportExcel/${comprobanteId}`;
    }

    function salir() {
        if (confirm('¿Está seguro de que desea salir? Los cambios no guardados se perderán.')) {
            window.location.href = '/';
        }
    }

    // FUNCIONES DE MOVIMIENTOS

    function agregarMovimiento() {
        if (!comprobanteId) {
            mostrarMensaje('warning', 'Debe guardar el comprobante primero');
            return;
        }

        limpiarFormularioMovimiento();
        $('#modalMovimientoTitle').text('Agregar Movimiento');
        $('#modalMovimiento').modal('show');
    }

    function editarMovimiento() {
        if (!movimientoSeleccionado) {
            mostrarMensaje('warning', 'Debe seleccionar un movimiento');
            return;
        }

        cargarDatosMovimiento(movimientoSeleccionado);
        $('#modalMovimientoTitle').text('Editar Movimiento');
        $('#modalMovimiento').modal('show');
    }

    function eliminarMovimiento() {
        if (!movimientoSeleccionado) {
            mostrarMensaje('warning', 'Debe seleccionar un movimiento');
            return;
        }

        if (!confirm('¿Está seguro de que desea eliminar este movimiento?')) {
            return;
        }

        $.ajax({
            url: `/NuevoComprobante/DeleteMovimiento/${movimientoSeleccionado.id}`,
            method: 'POST',
            success: function(response) {
                if (response.success) {
                    mostrarMensaje('success', response.message);
                    cargarMovimientos();
                    movimientoSeleccionado = null;
                    actualizarBotonesMovimiento();
                } else {
                    mostrarMensaje('error', response.message);
                }
            },
            error: function() {
                mostrarMensaje('error', 'Error al eliminar el movimiento');
            }
        });
    }

    function duplicarMovimiento() {
        if (!movimientoSeleccionado) {
            mostrarMensaje('warning', 'Debe seleccionar un movimiento');
            return;
        }

        // Crear copia del movimiento
        const movimientoCopia = {
            IdComp: comprobanteId,
            IdCuenta: movimientoSeleccionado.idCuenta,
            Debe: movimientoSeleccionado.debe,
            Haber: movimientoSeleccionado.haber,
            Glosa: movimientoSeleccionado.glosa + ' (Copia)',
            TipoDoc: movimientoSeleccionado.tipoDoc,
            NumDoc: movimientoSeleccionado.numDoc,
            Entidad: movimientoSeleccionado.entidad,
            Detalle: movimientoSeleccionado.detalle,
            IdAreaNeg: movimientoSeleccionado.idAreaNeg,
            IdCcostos: movimientoSeleccionado.idCcostos,
            IdDoc: movimientoSeleccionado.idDoc,
            IdDocCuota: movimientoSeleccionado.idDocCuota,
            Decentraliz: movimientoSeleccionado.decentraliz,
            DePago: movimientoSeleccionado.dePago,
            AtribConcil: movimientoSeleccionado.atribConcil,
            Nota: movimientoSeleccionado.nota
        };

        $.ajax({
            url: '/NuevoComprobante/AddMovimiento',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(movimientoCopia),
            success: function(response) {
                if (response.success) {
                    mostrarMensaje('success', response.message);
                    cargarMovimientos();
                } else {
                    mostrarMensaje('error', response.message);
                }
            },
            error: function() {
                mostrarMensaje('error', 'Error al duplicar el movimiento');
            }
        });
    }

    function moverMovimientoArriba() {
        if (!movimientoSeleccionado) {
            mostrarMensaje('warning', 'Debe seleccionar un movimiento');
            return;
        }

        moverMovimiento('up');
    }

    function moverMovimientoAbajo() {
        if (!movimientoSeleccionado) {
            mostrarMensaje('warning', 'Debe seleccionar un movimiento');
            return;
        }

        moverMovimiento('down');
    }

    function moverMovimiento(direction) {
        $.ajax({
            url: `/NuevoComprobante/MoveMovimiento/${movimientoSeleccionado.id}`,
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ Direction: direction }),
            success: function(response) {
                if (response.success) {
                    mostrarMensaje('success', response.message);
                    cargarMovimientos();
                } else {
                    mostrarMensaje('error', response.message);
                }
            },
            error: function() {
                mostrarMensaje('error', 'Error al mover el movimiento');
            }
        });
    }

    function buscarCuenta() {
        abrirModalBuscarCuenta();
    }

    function abrirCalculadora() {
        // Abrir calculadora del sistema
        window.open('calc.exe', '_blank');
    }

    function guardarMovimiento() {
        if (!validarFormularioMovimiento()) {
            return;
        }

        const formData = {
            IdComp: comprobanteId,
            IdCuenta: parseInt($('#movimientoIdCuenta').val()),
            Debe: parseFloat($('#movimientoDebe').val()) || 0,
            Haber: parseFloat($('#movimientoHaber').val()) || 0,
            Glosa: $('#movimientoGlosa').val(),
            TipoDoc: $('#movimientoTipoDoc').val(),
            NumDoc: $('#movimientoNumDoc').val(),
            Entidad: $('#movimientoEntidad').val(),
            Detalle: $('#movimientoDetalle').val(),
            Nota: $('#movimientoNota').val()
        };

        const url = $('#movimientoId').val() ? 
            `/NuevoComprobante/UpdateMovimiento/${$('#movimientoId').val()}` : 
            '/NuevoComprobante/AddMovimiento';

        $.ajax({
            url: url,
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(formData),
            success: function(response) {
                if (response.success) {
                    mostrarMensaje('success', response.message);
                    $('#modalMovimiento').modal('hide');
                    cargarMovimientos();
                } else {
                    mostrarMensaje('error', response.message);
                }
            },
            error: function() {
                mostrarMensaje('error', 'Error al guardar el movimiento');
            }
        });
    }

    // FUNCIONES DE BÚSQUEDA DE CUENTAS

    function abrirModalBuscarCuenta() {
        $('#buscarCuentaTerm').val('');
        $('#cuentasResultado').html('<tr><td colspan="5" class="text-center text-muted">Ingrese un término de búsqueda</td></tr>');
        $('#modalBuscarCuenta').modal('show');
    }

    function buscarCuentas() {
        const termino = $('#buscarCuentaTerm').val().trim();
        
        if (termino.length < 2) {
            $('#cuentasResultado').html('<tr><td colspan="5" class="text-center text-muted">Ingrese al menos 2 caracteres</td></tr>');
            return;
        }

        $.ajax({
            url: '/NuevoComprobante/SearchCuentas',
            method: 'GET',
            data: { term: termino },
            success: function(response) {
                if (response.success) {
                    mostrarCuentas(response.cuentas);
                } else {
                    $('#cuentasResultado').html('<tr><td colspan="5" class="text-center text-muted">Error al buscar cuentas</td></tr>');
                }
            },
            error: function() {
                $('#cuentasResultado').html('<tr><td colspan="5" class="text-center text-muted">Error al buscar cuentas</td></tr>');
            }
        });
    }

    function mostrarCuentas(cuentas) {
        if (cuentas.length === 0) {
            $('#cuentasResultado').html('<tr><td colspan="5" class="text-center text-muted">No se encontraron cuentas</td></tr>');
            return;
        }

        let html = '';
        cuentas.forEach(function(cuenta) {
            html += `
                <tr>
                    <td>${cuenta.codigo}</td>
                    <td>${cuenta.descripcion}</td>
                    <td>${cuenta.tipo}</td>
                    <td>${cuenta.nivel}</td>
                    <td>
                        <button type="button" class="btn btn-sm btn-primary btn-seleccionar-cuenta" 
                                data-id="${cuenta.id}" data-codigo="${cuenta.codigo}" data-descripcion="${cuenta.descripcion}">
                            Seleccionar
                        </button>
                    </td>
                </tr>
            `;
        });

        $('#cuentasResultado').html(html);
    }

    function seleccionarCuenta() {
        const id = $(this).data('id');
        const codigo = $(this).data('codigo');
        const descripcion = $(this).data('descripcion');

        $('#movimientoIdCuenta').val(id);
        $('#cuentaInfo').html(`<strong>${codigo}</strong> - ${descripcion}`);
        $('#modalBuscarCuenta').modal('hide');
    }

    // FUNCIONES DE UTILIDAD

    function cargarMovimientos() {
        if (!comprobanteId) {
            return;
        }

        $.ajax({
            url: `/NuevoComprobante/GetMovimientos/${comprobanteId}`,
            method: 'GET',
            success: function(response) {
                if (response.success) {
                    movimientos = response.movimientos;
                    actualizarGridMovimientos();
                    calcularTotales();
                }
            },
            error: function() {
                mostrarMensaje('error', 'Error al cargar movimientos');
            }
        });
    }

    function actualizarGridMovimientos() {
        const tbody = $('#gridMovimientos tbody');
        
        if (movimientos.length === 0) {
            tbody.html('<tr id="no-movimientos"><td colspan="11" class="text-center text-muted"><i class="fas fa-info-circle"></i> No hay movimientos. Haga clic en "Agregar Movimiento" para comenzar.</td></tr>');
            return;
        }

        let html = '';
        movimientos.forEach(function(movimiento) {
            html += `
                <tr data-id="${movimiento.id}" data-orden="${movimiento.orden}">
                    <td>${movimiento.orden}</td>
                    <td>${movimiento.codCuenta}</td>
                    <td>${movimiento.cuenta}</td>
                    <td class="text-end">${parseFloat(movimiento.debe).toFixed(2)}</td>
                    <td class="text-end">${parseFloat(movimiento.haber).toFixed(2)}</td>
                    <td>${movimiento.glosa}</td>
                    <td>${movimiento.tipoDoc || ''}</td>
                    <td>${movimiento.numDoc || ''}</td>
                    <td>${movimiento.entidad || ''}</td>
                    <td>${movimiento.detalle || ''}</td>
                    <td>
                        <button type="button" class="btn btn-sm btn-outline-primary btn-seleccionar-movimiento" 
                                data-id="${movimiento.id}" title="Seleccionar">
                            <i class="fas fa-hand-pointer"></i>
                        </button>
                    </td>
                </tr>
            `;
        });

        tbody.html(html);
    }

    function seleccionarMovimiento() {
        const id = parseInt($(this).data('id'));
        movimientoSeleccionado = movimientos.find(m => m.id === id);
        
        // Actualizar selección visual
        $('#gridMovimientos tbody tr').removeClass('table-active');
        $(this).closest('tr').addClass('table-active');
        
        actualizarBotonesMovimiento();
    }

    function cargarDatosMovimiento(movimiento) {
        $('#movimientoId').val(movimiento.id);
        $('#movimientoIdCuenta').val(movimiento.idCuenta);
        $('#movimientoDebe').val(movimiento.debe);
        $('#movimientoHaber').val(movimiento.haber);
        $('#movimientoGlosa').val(movimiento.glosa);
        $('#movimientoTipoDoc').val(movimiento.tipoDoc || '');
        $('#movimientoNumDoc').val(movimiento.numDoc || '');
        $('#movimientoEntidad').val(movimiento.entidad || '');
        $('#movimientoDetalle').val(movimiento.detalle || '');
        $('#movimientoNota').val(movimiento.nota || '');
        
        // Cargar información de la cuenta
        cargarInformacionCuenta(movimiento.idCuenta);
    }

    function cargarInformacionCuenta(idCuenta) {
        $.ajax({
            url: `/NuevoComprobante/GetCuenta/${idCuenta}`,
            method: 'GET',
            success: function(response) {
                if (response.success) {
                    const cuenta = response.cuenta;
                    $('#cuentaInfo').html(`<strong>${cuenta.codigo}</strong> - ${cuenta.descripcion}`);
                }
            }
        });
    }

    function limpiarFormularioMovimiento() {
        $('#movimientoForm')[0].reset();
        $('#movimientoId').val('');
        $('#cuentaInfo').html('');
    }

    function validarFormularioComprobante() {
        if (!$('#Fecha').val()) {
            mostrarMensaje('error', 'La fecha es obligatoria');
            return false;
        }
        
        if (!$('#Glosa').val().trim()) {
            mostrarMensaje('error', 'La glosa es obligatoria');
            return false;
        }
        
        if (!$('#Tipo').val()) {
            mostrarMensaje('error', 'El tipo es obligatorio');
            return false;
        }
        
        return true;
    }

    function validarFormularioMovimiento() {
        if (!$('#movimientoIdCuenta').val()) {
            mostrarMensaje('error', 'La cuenta es obligatoria');
            return false;
        }
        
        if (!$('#movimientoGlosa').val().trim()) {
            mostrarMensaje('error', 'La glosa es obligatoria');
            return false;
        }
        
        const debe = parseFloat($('#movimientoDebe').val()) || 0;
        const haber = parseFloat($('#movimientoHaber').val()) || 0;
        
        if (debe === 0 && haber === 0) {
            mostrarMensaje('error', 'Debe especificar un monto en debe o haber');
            return false;
        }
        
        if (debe > 0 && haber > 0) {
            mostrarMensaje('error', 'No puede tener monto en debe y haber simultáneamente');
            return false;
        }
        
        return true;
    }

    function validarMontosMovimiento() {
        const debe = parseFloat($('#movimientoDebe').val()) || 0;
        const haber = parseFloat($('#movimientoHaber').val()) || 0;
        
        if (debe > 0 && haber > 0) {
            $('#movimientoDebe, #movimientoHaber').addClass('is-invalid');
            mostrarMensaje('warning', 'No puede tener monto en debe y haber simultáneamente');
        } else {
            $('#movimientoDebe, #movimientoHaber').removeClass('is-invalid');
        }
    }

    function calcularTotales() {
        let totalDebe = 0;
        let totalHaber = 0;
        
        movimientos.forEach(function(movimiento) {
            totalDebe += parseFloat(movimiento.debe) || 0;
            totalHaber += parseFloat(movimiento.haber) || 0;
        });
        
        actualizarTotales(totalDebe, totalHaber, totalDebe - totalHaber);
    }

    function actualizarTotales(totalDebe, totalHaber, diferencia) {
        $('#totalDebe').text(totalDebe.toFixed(2));
        $('#totalHaber').text(totalHaber.toFixed(2));
        $('#diferencia').text(diferencia.toFixed(2));
        
        // Cambiar color según el estado
        if (Math.abs(diferencia) < 0.01) {
            $('#diferencia').removeClass('text-danger text-warning').addClass('text-success');
        } else if (Math.abs(diferencia) < 100) {
            $('#diferencia').removeClass('text-danger text-success').addClass('text-warning');
        } else {
            $('#diferencia').removeClass('text-warning text-success').addClass('text-danger');
        }
    }

    function actualizarBotones() {
        const tieneComprobante = comprobanteId !== null;
        
        $('#btnDuplicar, #btnEditar, #btnEliminar, #btnVistaPrevia, #btnImprimir, #btnExcel').prop('disabled', !tieneComprobante);
        $('#btnAgregarMovimiento').prop('disabled', !tieneComprobante);
    }

    function actualizarBotonesMovimiento() {
        const tieneSeleccion = movimientoSeleccionado !== null;
        
        $('#btnEditarMovimiento, #btnEliminarMovimiento, #btnDuplicarMovimiento, #btnMoverArriba, #btnMoverAbajo').prop('disabled', !tieneSeleccion);
    }

    function habilitarFormulario(habilitar) {
        $('#comprobanteForm input, #comprobanteForm select').prop('readonly', !habilitar);
        $('#comprobanteForm input[type="date"]').prop('readonly', !habilitar);
    }

    function mostrarMensaje(tipo, mensaje) {
        // Implementar sistema de notificaciones
        const alertClass = tipo === 'error' ? 'alert-danger' : 
                          tipo === 'warning' ? 'alert-warning' : 
                          tipo === 'success' ? 'alert-success' : 'alert-info';
        
        const alertHtml = `
            <div class="alert ${alertClass} alert-dismissible fade show" role="alert">
                ${mensaje}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `;
        
        // Insertar al inicio del contenido
        $('.card-body').prepend(alertHtml);
        
        // Auto-ocultar después de 5 segundos
        setTimeout(function() {
            $('.alert').fadeOut();
        }, 5000);
    }
});

