/**
 * JavaScript para funcionalidad del formulario de documento de libro
 */

$(document).ready(function() {
    // Inicializar componentes
    inicializarComponentes();
    
    // Configurar eventos
    configurarEventos();
    
    // Cargar datos iniciales
    cargarDatosIniciales();
});

/**
 * Inicializar componentes de la interfaz
 */
function inicializarComponentes() {
    // Inicializar Select2 para combos
    $('.select2').select2({
        placeholder: 'Seleccionar...',
        allowClear: true,
        width: '100%'
    });
    
    // Inicializar DataTable para el grid de movimientos
    $('#gridMovimientos').DataTable({
        responsive: true,
        paging: false,
        searching: false,
        ordering: false,
        info: false,
        columnDefs: [
            { orderable: false, targets: [0, 15] }, // Checkbox y acciones
            { className: 'text-center', targets: [0, 1, 8, 9] },
            { className: 'text-right', targets: [6, 7, 10, 11] }
        ],
        language: {
            emptyTable: "No hay movimientos disponibles",
            zeroRecords: "No se encontraron movimientos"
        }
    });
    
    // Configurar tooltips
    $('[data-toggle="tooltip"]').tooltip();
}

/**
 * Configurar eventos de la interfaz
 */
function configurarEventos() {
    // Botones principales
    $('#btnGuardar').on('click', function() {
        guardarDocumento();
    });
    
    $('#btnCancelar').on('click', function() {
        cancelarDocumento();
    });
    
    $('#btnCuadrar').on('click', function() {
        cuadrarComprobante();
    });
    
    $('#btnSumar').on('click', function() {
        sumarMovimientos();
    });
    
    $('#btnDuplicar').on('click', function() {
        duplicarMovimiento();
    });
    
    $('#btnEliminar').on('click', function() {
        eliminarMovimiento();
    });
    
    $('#btnMoverArriba').on('click', function() {
        moverMovimientoArriba();
    });
    
    $('#btnMoverAbajo').on('click', function() {
        moverMovimientoAbajo();
    });
    
    $('#btnExportar').on('click', function() {
        exportarDocumento();
    });
    
    // Botón de agregar movimiento
    $('#btnAgregarMovimiento').on('click', function() {
        mostrarModalMovimiento();
    });
    
    // Botón de guardar movimiento
    $('#btnGuardarMovimiento').on('click', function() {
        guardarMovimiento();
    });
    
    // Validación de RUT
    $('#btnValidarRut').on('click', function() {
        validarRut();
    });
    
    $('#txRutEntidad').on('blur', function() {
        if ($(this).val().trim() !== '') {
            validarRut();
        }
    });
    
    // Selección de entidad por RUT
    $('#txRutEntidad').on('change', function() {
        if ($(this).val().trim() !== '') {
            buscarEntidadPorRut();
        }
    });
    
    // Checkbox de selección múltiple de movimientos
    $('#chkSelectAllMov').on('change', function() {
        $('input[name="chkMovimiento"]').prop('checked', $(this).is(':checked'));
        actualizarBotonesMovimientos();
    });
    
    // Eventos del grid de movimientos
    $(document).on('change', 'input[name="chkMovimiento"]', function() {
        actualizarBotonesMovimientos();
    });
    
    $(document).on('click', '.btn-editar-movimiento', function() {
        var idMovimiento = $(this).data('id-movimiento');
        editarMovimiento(idMovimiento);
    });
    
    $(document).on('click', '.btn-eliminar-movimiento', function() {
        var idMovimiento = $(this).data('id-movimiento');
        eliminarMovimiento(idMovimiento);
    });
    
    $(document).on('click', '.btn-duplicar-movimiento', function() {
        var idMovimiento = $(this).data('id-movimiento');
        duplicarMovimiento(idMovimiento);
    });
    
    $(document).on('click', '.btn-mover-arriba', function() {
        var idMovimiento = $(this).data('id-movimiento');
        moverMovimientoArriba(idMovimiento);
    });
    
    $(document).on('click', '.btn-mover-abajo', function() {
        var idMovimiento = $(this).data('id-movimiento');
        moverMovimientoAbajo(idMovimiento);
    });
    
    // Eventos de cálculo automático
    $('#movimientoDebe, #movimientoHaber, #movimientoTipoCambio').on('input', function() {
        calcularMontosBase();
    });
    
    $('#movimientoMoneda').on('change', function() {
        actualizarTipoCambio();
    });
}

/**
 * Cargar datos iniciales
 */
function cargarDatosIniciales() {
    // Cargar movimientos del documento
    cargarMovimientos();
    
    // Cargar opciones de filtros
    cargarOpcionesFiltros();
}

/**
 * Cargar movimientos del documento
 */
function cargarMovimientos() {
    var idDocumento = $('#movimientoIdDocumento').val();
    
    if (!idDocumento || idDocumento === '0') {
        mostrarMovimientos([]);
        return;
    }
    
    $.ajax({
        url: '/DocumentosLibros/GetMovimientos',
        type: 'GET',
        data: { idDocumento: idDocumento },
        success: function(response) {
            if (response.success) {
                mostrarMovimientos(response.movimientos);
                actualizarResumen(response.movimientos);
            } else {
                mostrarError(response.message || 'Error al cargar movimientos');
            }
        },
        error: function() {
            mostrarError('Error al cargar movimientos');
        }
    });
}

/**
 * Cargar opciones para los combos
 */
function cargarOpcionesFiltros() {
    $.ajax({
        url: '/DocumentosLibros/GetOpciones',
        type: 'GET',
        success: function(response) {
            if (response.success) {
                // Actualizar combos con las opciones recibidas
                actualizarCombo('#movimientoCodigoCuenta', response.opciones.cuentas);
            }
        },
        error: function() {
            mostrarError('Error al cargar opciones');
        }
    });
}

/**
 * Actualizar un combo con opciones
 */
function actualizarCombo(selector, opciones) {
    var combo = $(selector);
    combo.empty();
    combo.append('<option value="">Seleccionar...</option>');
    
    opciones.forEach(function(opcion) {
        combo.append(`<option value="${opcion.valor}">${opcion.texto}</option>`);
    });
    
    combo.trigger('change');
}

/**
 * Mostrar movimientos en el grid
 */
function mostrarMovimientos(movimientos) {
    var tbody = $('#tbodyMovimientos');
    tbody.empty();
    
    if (movimientos && movimientos.length > 0) {
        movimientos.forEach(function(movimiento) {
            var fila = crearFilaMovimiento(movimiento);
            tbody.append(fila);
        });
    } else {
        tbody.append('<tr><td colspan="16" class="text-center">No hay movimientos</td></tr>');
    }
    
    // Actualizar contador de movimientos
    $('#cantidadMovimientos').text(movimientos ? movimientos.length : 0);
}

/**
 * Crear fila para un movimiento
 */
function crearFilaMovimiento(movimiento) {
    var checkbox = `<input type="checkbox" name="chkMovimiento" value="${movimiento.idMovimiento}" class="form-check-input">`;
    var acciones = `
        <div class="btn-group btn-group-sm">
            <button type="button" class="btn btn-outline-primary btn-editar-movimiento" 
                    data-id-movimiento="${movimiento.idMovimiento}" title="Editar movimiento">
                <i class="fas fa-edit"></i>
            </button>
            <button type="button" class="btn btn-outline-danger btn-eliminar-movimiento" 
                    data-id-movimiento="${movimiento.idMovimiento}" title="Eliminar movimiento">
                <i class="fas fa-trash"></i>
            </button>
            <button type="button" class="btn btn-outline-info btn-duplicar-movimiento" 
                    data-id-movimiento="${movimiento.idMovimiento}" title="Duplicar movimiento">
                <i class="fas fa-copy"></i>
            </button>
            <button type="button" class="btn btn-outline-secondary btn-mover-arriba" 
                    data-id-movimiento="${movimiento.idMovimiento}" title="Mover hacia arriba">
                <i class="fas fa-arrow-up"></i>
            </button>
            <button type="button" class="btn btn-outline-secondary btn-mover-abajo" 
                    data-id-movimiento="${movimiento.idMovimiento}" title="Mover hacia abajo">
                <i class="fas fa-arrow-down"></i>
            </button>
        </div>
    `;
    
    return `
        <tr>
            <td>${checkbox}</td>
            <td>${movimiento.numeroLinea}</td>
            <td>${movimiento.codigoCuenta}</td>
            <td>${movimiento.nombreCuenta}</td>
            <td>${movimiento.glosa}</td>
            <td>${movimiento.centroCosto}</td>
            <td class="text-right">${formatearMoneda(movimiento.debe)}</td>
            <td class="text-right">${formatearMoneda(movimiento.haber)}</td>
            <td class="text-center">${movimiento.moneda}</td>
            <td class="text-center">${movimiento.tipoCambio.toFixed(4)}</td>
            <td class="text-right">${formatearMoneda(movimiento.debeBase)}</td>
            <td class="text-right">${formatearMoneda(movimiento.haberBase)}</td>
            <td>${formatearFecha(movimiento.fechaVencimiento)}</td>
            <td>${movimiento.numeroDocumento}</td>
            <td>${movimiento.observaciones}</td>
            <td>${acciones}</td>
        </tr>
    `;
}

/**
 * Actualizar resumen de movimientos
 */
function actualizarResumen(movimientos) {
    var totalDebe = movimientos.reduce((sum, m) => sum + (m.debe || 0), 0);
    var totalHaber = movimientos.reduce((sum, m) => sum + (m.haber || 0), 0);
    var diferencia = totalDebe - totalHaber;
    var esCuadrado = Math.abs(diferencia) < 0.01;
    
    $('#totalDebe').text(formatearMoneda(totalDebe));
    $('#totalHaber').text(formatearMoneda(totalHaber));
    $('#diferencia').text(formatearMoneda(diferencia));
    
    if (esCuadrado) {
        $('#diferencia').removeClass('text-danger').addClass('text-success');
        $('#estadoCuadre').removeClass('badge-danger').addClass('badge-success').text('Cuadrado');
    } else {
        $('#diferencia').removeClass('text-success').addClass('text-danger');
        $('#estadoCuadre').removeClass('badge-success').addClass('badge-danger').text('No Cuadrado');
    }
}

/**
 * Formatear fecha
 */
function formatearFecha(fecha) {
    if (!fecha) return '';
    var date = new Date(fecha);
    return date.toLocaleDateString('es-CL');
}

/**
 * Formatear moneda
 */
function formatearMoneda(valor) {
    if (!valor) return '$0';
    return new Intl.NumberFormat('es-CL', {
        style: 'currency',
        currency: 'CLP'
    }).format(valor);
}

/**
 * Guardar documento
 */
function guardarDocumento() {
    var documento = obtenerDatosDocumento();
    
    if (!validarDocumento(documento)) {
        return;
    }
    
    mostrarCargando(true);
    
    $.ajax({
        url: '/DocumentosLibros/Save',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(documento),
        success: function(response) {
            if (response.success) {
                mostrarExito(response.message || 'Documento guardado exitosamente');
                if (response.documento && response.documento.idDocumento) {
                    $('#movimientoIdDocumento').val(response.documento.idDocumento);
                }
            } else {
                mostrarError(response.message || 'Error al guardar documento');
            }
        },
        error: function() {
            mostrarError('Error al guardar documento');
        },
        complete: function() {
            mostrarCargando(false);
        }
    });
}

/**
 * Obtener datos del documento del formulario
 */
function obtenerDatosDocumento() {
    return {
        idDocumento: $('#movimientoIdDocumento').val() ? parseInt($('#movimientoIdDocumento').val()) : 0,
        tipoDocumento: $('#cbTipoDocumento').val(),
        numeroDocumento: $('#txNumeroDocumento').val(),
        estado: $('#cbEstado').val(),
        fecha: $('#txFecha').val(),
        fechaVencimiento: $('#txFechaVencimiento').val(),
        descripcion: $('#txDescripcion').val(),
        valorTotal: parseFloat($('#txValorTotal').val()) || 0,
        idEntidad: $('#cbEntidad').val() ? parseInt($('#cbEntidad').val()) : 0,
        rutEntidad: $('#txRutEntidad').val(),
        idSucursal: $('#cbSucursal').val() ? parseInt($('#cbSucursal').val()) : 0,
        delGiro: $('#chDelGiro').is(':checked'),
        dteDocumentoAsociado: $('#chDTEDocAsoc').is(':checked'),
        compraBienRaiz: $('#chCompraBienRaiz').is(':checked')
    };
}

/**
 * Validar documento
 */
function validarDocumento(documento) {
    var errores = [];
    
    if (!documento.tipoDocumento) {
        errores.push('El tipo de documento es requerido');
    }
    
    if (!documento.fecha) {
        errores.push('La fecha es requerida');
    }
    
    if (!documento.idSucursal) {
        errores.push('La sucursal es requerida');
    }
    
    if (errores.length > 0) {
        mostrarError('Errores de validación:\n' + errores.join('\n'));
        return false;
    }
    
    return true;
}

/**
 * Cancelar documento
 */
function cancelarDocumento() {
    if (confirm('¿Está seguro de que desea cancelar? Los cambios no guardados se perderán.')) {
        window.location.href = '/DocumentosLibros';
    }
}

/**
 * Cuadrar comprobante
 */
function cuadrarComprobante() {
    var idDocumento = $('#movimientoIdDocumento').val();
    
    if (!idDocumento || idDocumento === '0') {
        mostrarError('Debe guardar el documento antes de cuadrarlo');
        return;
    }
    
    $.ajax({
        url: '/DocumentosLibros/CuadrarComprobante',
        type: 'POST',
        data: { idDocumento: idDocumento },
        success: function(response) {
            if (response.success) {
                mostrarExito(response.message || 'Comprobante cuadrado correctamente');
                // Actualizar resumen
                cargarMovimientos();
            } else {
                mostrarError(response.message || 'Error al cuadrar comprobante');
            }
        },
        error: function() {
            mostrarError('Error al cuadrar comprobante');
        }
    });
}

/**
 * Sumar movimientos seleccionados
 */
function sumarMovimientos() {
    var seleccionados = obtenerMovimientosSeleccionados();
    
    if (seleccionados.length === 0) {
        mostrarError('Seleccione al menos un movimiento');
        return;
    }
    
    $.ajax({
        url: '/DocumentosLibros/SumarMovimientos',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(seleccionados),
        success: function(response) {
            if (response.success) {
                mostrarSumaMovimientos(response.suma);
            } else {
                mostrarError(response.message || 'Error al sumar movimientos');
            }
        },
        error: function() {
            mostrarError('Error al sumar movimientos');
        }
    });
}

/**
 * Mostrar suma de movimientos en modal
 */
function mostrarSumaMovimientos(suma) {
    var contenido = `
        <div class="row">
            <div class="col-md-6">
                <h6>Resumen General</h6>
                <table class="table table-sm">
                    <tr><td><strong>Cantidad de Movimientos:</strong></td><td class="text-right">${suma.cantidadMovimientos}</td></tr>
                    <tr><td><strong>Total Debe:</strong></td><td class="text-right">${formatearMoneda(suma.totalDebe)}</td></tr>
                    <tr><td><strong>Total Haber:</strong></td><td class="text-right">${formatearMoneda(suma.totalHaber)}</td></tr>
                    <tr><td><strong>Diferencia:</strong></td><td class="text-right">${formatearMoneda(suma.diferencia)}</td></tr>
                </table>
            </div>
            <div class="col-md-6">
                <h6>Promedios</h6>
                <table class="table table-sm">
                    <tr><td><strong>Promedio Debe:</strong></td><td class="text-right">${formatearMoneda(suma.promedioDebe)}</td></tr>
                    <tr><td><strong>Promedio Haber:</strong></td><td class="text-right">${formatearMoneda(suma.promedioHaber)}</td></tr>
                </table>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <h6>Suma por Cuenta</h6>
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>Código</th>
                                <th>Nombre</th>
                                <th class="text-right">Debe</th>
                                <th class="text-right">Haber</th>
                                <th class="text-right">Saldo</th>
                                <th class="text-center">Movimientos</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${suma.sumaPorCuenta.map(sc => `
                                <tr>
                                    <td>${sc.codigoCuenta}</td>
                                    <td>${sc.nombreCuenta}</td>
                                    <td class="text-right">${formatearMoneda(sc.totalDebe)}</td>
                                    <td class="text-right">${formatearMoneda(sc.totalHaber)}</td>
                                    <td class="text-right">${formatearMoneda(sc.saldo)}</td>
                                    <td class="text-center">${sc.cantidadMovimientos}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    `;
    
    $('#modalResumenMovimientosBody').html(contenido);
    $('#modalResumenMovimientos').modal('show');
}

/**
 * Mostrar modal de movimiento
 */
function mostrarModalMovimiento(idMovimiento = null) {
    if (idMovimiento) {
        $('#modalMovimientoTitle').text('Editar Movimiento');
        cargarDatosMovimiento(idMovimiento);
    } else {
        $('#modalMovimientoTitle').text('Agregar Movimiento');
        limpiarFormularioMovimiento();
    }
    
    $('#modalMovimiento').modal('show');
}

/**
 * Cargar datos de un movimiento para edición
 */
function cargarDatosMovimiento(idMovimiento) {
    // Implementar carga de datos del movimiento
    // Por ahora, solo limpiar el formulario
    limpiarFormularioMovimiento();
}

/**
 * Limpiar formulario de movimiento
 */
function limpiarFormularioMovimiento() {
    $('#formMovimiento')[0].reset();
    $('#movimientoId').val('');
    $('#movimientoTipoCambio').val('1.0000');
}

/**
 * Guardar movimiento
 */
function guardarMovimiento() {
    var movimiento = obtenerDatosMovimiento();
    
    if (!validarMovimiento(movimiento)) {
        return;
    }
    
    var url = movimiento.idMovimiento ? '/DocumentosLibros/UpdateMovimiento' : '/DocumentosLibros/AddMovimiento';
    
    $.ajax({
        url: url,
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(movimiento),
        success: function(response) {
            if (response.success) {
                mostrarExito(response.message || 'Movimiento guardado exitosamente');
                $('#modalMovimiento').modal('hide');
                cargarMovimientos(); // Recargar movimientos
            } else {
                mostrarError(response.message || 'Error al guardar movimiento');
            }
        },
        error: function() {
            mostrarError('Error al guardar movimiento');
        }
    });
}

/**
 * Obtener datos del movimiento del formulario
 */
function obtenerDatosMovimiento() {
    return {
        idMovimiento: $('#movimientoId').val() ? parseInt($('#movimientoId').val()) : 0,
        idDocumento: parseInt($('#movimientoIdDocumento').val()),
        codigoCuenta: $('#movimientoCodigoCuenta').val(),
        glosa: $('#movimientoGlosa').val(),
        centroCosto: $('#movimientoCentroCosto').val(),
        debe: parseFloat($('#movimientoDebe').val()) || 0,
        haber: parseFloat($('#movimientoHaber').val()) || 0,
        moneda: $('#movimientoMoneda').val(),
        tipoCambio: parseFloat($('#movimientoTipoCambio').val()) || 1,
        fechaVencimiento: $('#movimientoFechaVencimiento').val(),
        numeroDocumento: $('#movimientoNumeroDocumento').val(),
        observaciones: $('#movimientoObservaciones').val()
    };
}

/**
 * Validar movimiento
 */
function validarMovimiento(movimiento) {
    var errores = [];
    
    if (!movimiento.codigoCuenta) {
        errores.push('El código de cuenta es requerido');
    }
    
    if (!movimiento.glosa) {
        errores.push('La glosa es requerida');
    }
    
    if (movimiento.debe === 0 && movimiento.haber === 0) {
        errores.push('Debe ingresar un monto en debe o haber');
    }
    
    if (movimiento.debe > 0 && movimiento.haber > 0) {
        errores.push('No puede tener monto en debe y haber al mismo tiempo');
    }
    
    if (errores.length > 0) {
        mostrarError('Errores de validación:\n' + errores.join('\n'));
        return false;
    }
    
    return true;
}

/**
 * Calcular montos base
 */
function calcularMontosBase() {
    var debe = parseFloat($('#movimientoDebe').val()) || 0;
    var haber = parseFloat($('#movimientoHaber').val()) || 0;
    var tipoCambio = parseFloat($('#movimientoTipoCambio').val()) || 1;
    
    var debeBase = debe * tipoCambio;
    var haberBase = haber * tipoCambio;
    
    // Actualizar campos de solo lectura (si los hay)
    // $('#movimientoDebeBase').val(debeBase.toFixed(2));
    // $('#movimientoHaberBase').val(haberBase.toFixed(2));
}

/**
 * Actualizar tipo de cambio según moneda
 */
function actualizarTipoCambio() {
    var moneda = $('#movimientoMoneda').val();
    
    // Lógica para actualizar tipo de cambio según moneda
    // Por ahora, mantener en 1.0000
    if (moneda === 'CLP') {
        $('#movimientoTipoCambio').val('1.0000');
    } else {
        // Aquí se podría cargar el tipo de cambio actual
        $('#movimientoTipoCambio').val('1.0000');
    }
}

/**
 * Obtener movimientos seleccionados
 */
function obtenerMovimientosSeleccionados() {
    var seleccionados = [];
    $('input[name="chkMovimiento"]:checked').each(function() {
        seleccionados.push(parseInt($(this).val()));
    });
    return seleccionados;
}

/**
 * Actualizar botones de movimientos según selección
 */
function actualizarBotonesMovimientos() {
    var seleccionados = obtenerMovimientosSeleccionados();
    var tieneSeleccion = seleccionados.length > 0;
    var tieneSeleccionUnica = seleccionados.length === 1;
    
    $('#btnDuplicar').prop('disabled', !tieneSeleccionUnica);
    $('#btnEliminar').prop('disabled', !tieneSeleccion);
    $('#btnMoverArriba').prop('disabled', !tieneSeleccionUnica);
    $('#btnMoverAbajo').prop('disabled', !tieneSeleccionUnica);
    $('#btnSumar').prop('disabled', !tieneSeleccion);
    
    $('#cantidadSeleccionados').text(seleccionados.length);
}

/**
 * Duplicar movimiento
 */
function duplicarMovimiento(idMovimiento) {
    if (!idMovimiento) {
        var seleccionados = obtenerMovimientosSeleccionados();
        if (seleccionados.length === 0) {
            mostrarError('Seleccione al menos un movimiento');
            return;
        }
        if (seleccionados.length > 1) {
            mostrarError('Seleccione solo un movimiento');
            return;
        }
        idMovimiento = seleccionados[0];
    }
    
    $.ajax({
        url: '/DocumentosLibros/DuplicarMovimiento',
        type: 'POST',
        data: { idMovimiento: idMovimiento },
        success: function(response) {
            if (response.success) {
                mostrarExito(response.message || 'Movimiento duplicado exitosamente');
                cargarMovimientos(); // Recargar movimientos
            } else {
                mostrarError(response.message || 'Error al duplicar movimiento');
            }
        },
        error: function() {
            mostrarError('Error al duplicar movimiento');
        }
    });
}

/**
 * Eliminar movimiento
 */
function eliminarMovimiento(idMovimiento) {
    if (!idMovimiento) {
        var seleccionados = obtenerMovimientosSeleccionados();
        if (seleccionados.length === 0) {
            mostrarError('Seleccione al menos un movimiento');
            return;
        }
        if (seleccionados.length > 1) {
            mostrarError('Seleccione solo un movimiento');
            return;
        }
        idMovimiento = seleccionados[0];
    }
    
    if (confirm('¿Está seguro de que desea eliminar el movimiento seleccionado?')) {
        $.ajax({
            url: '/DocumentosLibros/DeleteMovimiento',
            type: 'POST',
            data: { idMovimiento: idMovimiento },
            success: function(response) {
                if (response.success) {
                    mostrarExito(response.message || 'Movimiento eliminado exitosamente');
                    cargarMovimientos(); // Recargar movimientos
                } else {
                    mostrarError(response.message || 'Error al eliminar movimiento');
                }
            },
            error: function() {
                mostrarError('Error al eliminar movimiento');
            }
        });
    }
}

/**
 * Mover movimiento hacia arriba
 */
function moverMovimientoArriba(idMovimiento) {
    if (!idMovimiento) {
        var seleccionados = obtenerMovimientosSeleccionados();
        if (seleccionados.length === 0) {
            mostrarError('Seleccione al menos un movimiento');
            return;
        }
        if (seleccionados.length > 1) {
            mostrarError('Seleccione solo un movimiento');
            return;
        }
        idMovimiento = seleccionados[0];
    }
    
    $.ajax({
        url: '/DocumentosLibros/MoverMovimientoArriba',
        type: 'POST',
        data: { idMovimiento: idMovimiento },
        success: function(response) {
            if (response.success) {
                mostrarExito(response.message || 'Movimiento movido hacia arriba');
                mostrarMovimientos(response.movimientos);
                actualizarResumen(response.movimientos);
            } else {
                mostrarError(response.message || 'Error al mover movimiento');
            }
        },
        error: function() {
            mostrarError('Error al mover movimiento');
        }
    });
}

/**
 * Mover movimiento hacia abajo
 */
function moverMovimientoAbajo(idMovimiento) {
    if (!idMovimiento) {
        var seleccionados = obtenerMovimientosSeleccionados();
        if (seleccionados.length === 0) {
            mostrarError('Seleccione al menos un movimiento');
            return;
        }
        if (seleccionados.length > 1) {
            mostrarError('Seleccione solo un movimiento');
            return;
        }
        idMovimiento = seleccionados[0];
    }
    
    $.ajax({
        url: '/DocumentosLibros/MoverMovimientoAbajo',
        type: 'POST',
        data: { idMovimiento: idMovimiento },
        success: function(response) {
            if (response.success) {
                mostrarExito(response.message || 'Movimiento movido hacia abajo');
                mostrarMovimientos(response.movimientos);
                actualizarResumen(response.movimientos);
            } else {
                mostrarError(response.message || 'Error al mover movimiento');
            }
        },
        error: function() {
            mostrarError('Error al mover movimiento');
        }
    });
}

/**
 * Exportar documento
 */
function exportarDocumento() {
    var idDocumento = $('#movimientoIdDocumento').val();
    
    if (!idDocumento || idDocumento === '0') {
        mostrarError('Debe guardar el documento antes de exportarlo');
        return;
    }
    
    $.ajax({
        url: '/DocumentosLibros/ExportarExcel',
        type: 'POST',
        data: { idDocumento: idDocumento },
        success: function(response) {
            if (response.success) {
                // Descargar archivo
                var blob = new Blob([response], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                var url = window.URL.createObjectURL(blob);
                var a = document.createElement('a');
                a.href = url;
                a.download = `DocumentoLibro_${idDocumento}_${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.xlsx`;
                a.click();
                window.URL.revokeObjectURL(url);
            } else {
                mostrarError(response.message || 'Error al exportar documento');
            }
        },
        error: function() {
            mostrarError('Error al exportar documento');
        }
    });
}

/**
 * Validar RUT
 */
function validarRut() {
    var rut = $('#txRutEntidad').val().trim();
    
    if (rut === '') {
        return;
    }
    
    $.ajax({
        url: '/DocumentosLibros/ValidarRut',
        type: 'POST',
        data: { rut: rut },
        success: function(response) {
            if (response.success) {
                if (response.esValido) {
                    $('#txRutEntidad').val(response.rutFormateado);
                    mostrarExito('RUT válido');
                } else {
                    mostrarError('RUT inválido');
                }
            } else {
                mostrarError(response.message || 'Error al validar RUT');
            }
        },
        error: function() {
            mostrarError('Error al validar RUT');
        }
    });
}

/**
 * Buscar entidad por RUT
 */
function buscarEntidadPorRut() {
    var rut = $('#txRutEntidad').val().trim();
    
    if (rut === '') {
        return;
    }
    
    $.ajax({
        url: '/DocumentosLibros/GetEntidadPorRut',
        type: 'GET',
        data: { rut: rut },
        success: function(response) {
            if (response.success) {
                $('#cbEntidad').val(response.entidad.idEntidad).trigger('change');
            } else {
                // No mostrar error si no se encuentra la entidad
                console.log('Entidad no encontrada para RUT:', rut);
            }
        },
        error: function() {
            console.log('Error al buscar entidad por RUT');
        }
    });
}

/**
 * Mostrar estado de carga
 */
function mostrarCargando(mostrar) {
    if (mostrar) {
        $('#btnGuardar').prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Guardando...');
    } else {
        $('#btnGuardar').prop('disabled', false).html('<i class="fas fa-save"></i> Guardar');
    }
}

/**
 * Mostrar mensaje de éxito
 */
function mostrarExito(mensaje) {
    toastr.success(mensaje);
}

/**
 * Mostrar mensaje de error
 */
function mostrarError(mensaje) {
    toastr.error(mensaje);
}

/**
 * Mostrar mensaje de información
 */
function mostrarInfo(mensaje) {
    toastr.info(mensaje);
}









