/**
 * JavaScript for Libro de Ingresos y Egresos functionality
 * Handles tabbed interface, data updates, and user interactions
 */

// Global variables
let currentTab = 'ingresos';
let selectedCell = null;
let isLoading = false;

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    initializePage();
});

/**
 * Initialize page functionality
 */
function initializePage() {
    // Set initial active tab
    cambiarTab('ingresos');
    
    // Add event listeners
    setupEventListeners();
    
    // Initialize tooltips and other UI components
    initializeUI();
}

/**
 * Setup event listeners for form controls
 */
function setupEventListeners() {
    // Month and year change events
    const selectMes = document.getElementById('selectMes');
    const inputAno = document.getElementById('inputAno');
    const checkVistaResumen = document.getElementById('checkVistaResumen');
    
    if (selectMes) {
        selectMes.addEventListener('change', onFilterChange);
    }
    
    if (inputAno) {
        inputAno.addEventListener('change', onFilterChange);
    }
    
    if (checkVistaResumen) {
        checkVistaResumen.addEventListener('change', onFilterChange);
    }
    
    // Keyboard shortcuts
    document.addEventListener('keydown', handleKeyboardShortcuts);
}

/**
 * Initialize UI components like tooltips
 */
function initializeUI() {
    // Add click handlers for table cells
    setupGridClickHandlers();
}

/**
 * Handle filter changes
 */
function onFilterChange() {
    if (!isLoading) {
        // Auto-update after a short delay to avoid excessive requests
        clearTimeout(window.filterUpdateTimeout);
        window.filterUpdateTimeout = setTimeout(actualizarDatos, 500);
    }
}

/**
 * Handle keyboard shortcuts
 */
function handleKeyboardShortcuts(event) {
    // Ctrl+R: Refresh data
    if (event.ctrlKey && event.key === 'r') {
        event.preventDefault();
        actualizarDatos();
    }
    
    // Ctrl+E: Export to Excel
    if (event.ctrlKey && event.key === 'e') {
        event.preventDefault();
        exportarExcel();
    }
    
    // Ctrl+P: Print preview
    if (event.ctrlKey && event.key === 'p') {
        event.preventDefault();
        vistaPrevia();
    }
    
    // Tab key: Switch between tabs
    if (event.key === 'Tab' && event.altKey) {
        event.preventDefault();
        const nextTab = currentTab === 'ingresos' ? 'egresos' : 'ingresos';
        cambiarTab(nextTab);
    }
}

/**
 * Setup click handlers for grid cells
 */
function setupGridClickHandlers() {
    // Add click handlers for both grids
    setupGridClickHandler('gridIngresos', 'celdaActualIngresos');
    setupGridClickHandler('gridEgresos', 'celdaActualEgresos');
}

/**
 * Setup click handler for a specific grid
 */
function setupGridClickHandler(gridId, cellDisplayId) {
    const grid = document.getElementById(gridId);
    if (!grid) return;
    
    const cells = grid.querySelectorAll('td');
    cells.forEach(cell => {
        cell.addEventListener('click', function(event) {
            // Remove previous selection
            grid.querySelectorAll('td.selected-cell').forEach(c => {
                c.classList.remove('selected-cell', 'bg-blue-100');
            });
            
            // Add selection to current cell
            cell.classList.add('selected-cell', 'bg-blue-100');
            
            // Update current cell display
            const cellDisplay = document.getElementById(cellDisplayId);
            if (cellDisplay) {
                cellDisplay.value = cell.textContent.trim();
            }
            
            selectedCell = {
                grid: gridId,
                cell: cell,
                value: cell.textContent.trim()
            };
        });
    });
}

/**
 * Change active tab
 */
function cambiarTab(tabName) {
    // Update tab buttons
    document.querySelectorAll('.tab-button').forEach(btn => {
        btn.classList.remove('border-blue-500', 'text-blue-600');
        btn.classList.add('border-transparent', 'text-gray-500');
    });
    
    const activeButton = document.querySelector(`[data-tab="${tabName}"]`);
    if (activeButton) {
        activeButton.classList.remove('border-transparent', 'text-gray-500');
        activeButton.classList.add('border-blue-500', 'text-blue-600');
    }
    
    // Update tab content
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.add('hidden');
    });
    
    const activeContent = document.getElementById(`tab-${tabName}`);
    if (activeContent) {
        activeContent.classList.remove('hidden');
    }
    
    currentTab = tabName;
    
    // Refresh grid click handlers
    setTimeout(setupGridClickHandlers, 100);
}

/**
 * Update data based on current filters
 */
async function actualizarDatos() {
    if (isLoading) return;
    
    try {
        isLoading = true;
        mostrarCargando(true);
        
        const mes = document.getElementById('selectMes').value;
        const ano = document.getElementById('inputAno').value;
        const vistaResumen = document.getElementById('checkVistaResumen').checked;
        
        // Validate inputs
        if (!mes || !ano) {
            mostrarError('Por favor seleccione un mes y año válidos');
            return;
        }
        
        if (ano < 1900 || ano > 2030) {
            mostrarError('El año debe estar entre 1900 y 2030');
            return;
        }
        
        // Update URL without page reload
        const url = new URL(window.location);
        url.searchParams.set('mes', mes);
        url.searchParams.set('ano', ano);
        url.searchParams.set('vistaResumen', vistaResumen);
        window.history.pushState({}, '', url);
        
        // Get updated data
        const response = await fetch('/api/LibroIngresosEgresos/completo?' + new URLSearchParams({
            mes: mes,
            ano: ano,
            vistaResumen: vistaResumen
        }));
        
        if (!response.ok) {
            throw new Error(`Error ${response.status}: ${response.statusText}`);
        }
        
        const data = await response.json();
        
        // Update grids
        await updateGrid('ingresos', data.ingresos);
        await updateGrid('egresos', data.egresos);
        
        // Update summary cards
        updateSummaryCards(data.resumen);
        
        // Update tab counts
        updateTabCounts(data.ingresos.entradas.length, data.egresos.entradas.length);
        
        mostrarMensaje('Datos actualizados correctamente', 'success');
        
    } catch (error) {
        console.error('Error updating data:', error);
        mostrarError('Error al actualizar los datos: ' + error.message);
    } finally {
        isLoading = false;
        mostrarCargando(false);
    }
}

/**
 * Update a specific grid with new data
 */
async function updateGrid(type, data) {
    // Grid is already updated with the data from the API call
    // Just refresh the click handlers
    setTimeout(setupGridClickHandlers, 100);
}

/**
 * Update summary cards
 */
function updateSummaryCards(resumen) {
    const totalIngresos = document.getElementById('totalIngresos');
    const totalEgresos = document.getElementById('totalEgresos');
    const flujoNeto = document.getElementById('flujoNeto');
    const totalRegistros = document.getElementById('totalRegistros');
    
    if (totalIngresos) totalIngresos.textContent = formatNumber(resumen.totalIngresos);
    if (totalEgresos) totalEgresos.textContent = formatNumber(resumen.totalEgresos);
    
    if (flujoNeto) {
        flujoNeto.textContent = formatNumber(resumen.flujoNeto);
        // Update color based on positive/negative
        flujoNeto.className = resumen.flujoNeto >= 0 ? 
            'text-lg font-medium text-green-600' : 
            'text-lg font-medium text-red-600';
    }
    
    if (totalRegistros) {
        totalRegistros.textContent = (resumen.cantidadIngresos + resumen.cantidadEgresos).toString();
    }
}

/**
 * Update tab counts
 */
function updateTabCounts(ingresosCount, egresosCount) {
    const ingresosTab = document.querySelector('[data-tab="ingresos"]');
    const egresosTab = document.querySelector('[data-tab="egresos"]');
    
    if (ingresosTab) {
        const content = ingresosTab.innerHTML;
        ingresosTab.innerHTML = content.replace(/Ingresos \(\d+\)/, `Ingresos (${ingresosCount})`);
    }
    
    if (egresosTab) {
        const content = egresosTab.innerHTML;
        egresosTab.innerHTML = content.replace(/Egresos \(\d+\)/, `Egresos (${egresosCount})`);
    }
}

/**
 * Show statistics modal
 */
async function mostrarEstadisticas() {
    try {
        mostrarCargando(true);
        
        const mes = document.getElementById('selectMes').value;
        const ano = document.getElementById('inputAno').value;
        
        const response = await fetch(`/api/LibroIngresosEgresos/estadisticas?mes=${mes}&ano=${ano}`);
        
        if (response.ok) {
            const data = await response.json();
            
            // Create modal with statistics data
            const modal = document.createElement('div');
            modal.innerHTML = `
                <div class="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
                    <div class="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-screen overflow-y-auto">
                        <div class="flex items-center justify-between p-4 border-b border-gray-200">
                            <h3 class="text-lg font-medium text-gray-900">Estadísticas del Período - ${data.periodo.nombreMes} ${data.periodo.ano}</h3>
                            <button onclick="cerrarModal()" class="text-gray-400 hover:text-gray-600">
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                                </svg>
                            </button>
                        </div>
                        <div class="p-6">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div class="bg-green-50 p-4 rounded-lg">
                                    <h4 class="font-semibold text-green-900 mb-3">Ingresos</h4>
                                    <dl class="space-y-2">
                                        <div class="flex justify-between">
                                            <dt class="text-sm text-green-700">Cantidad:</dt>
                                            <dd class="text-sm font-medium">${data.ingresos.cantidad}</dd>
                                        </div>
                                        <div class="flex justify-between">
                                            <dt class="text-sm text-green-700">Percibidos:</dt>
                                            <dd class="text-sm font-medium">$${formatNumber(data.ingresos.percibidos)}</dd>
                                        </div>
                                        <div class="flex justify-between">
                                            <dt class="text-sm text-green-700">Devengados:</dt>
                                            <dd class="text-sm font-medium">$${formatNumber(data.ingresos.devengados)}</dd>
                                        </div>
                                        <div class="flex justify-between border-t pt-2">
                                            <dt class="text-sm font-semibold text-green-900">Total:</dt>
                                            <dd class="text-sm font-bold">$${formatNumber(data.ingresos.total)}</dd>
                                        </div>
                                    </dl>
                                </div>
                                <div class="bg-red-50 p-4 rounded-lg">
                                    <h4 class="font-semibold text-red-900 mb-3">Egresos</h4>
                                    <dl class="space-y-2">
                                        <div class="flex justify-between">
                                            <dt class="text-sm text-red-700">Cantidad:</dt>
                                            <dd class="text-sm font-medium">${data.egresos.cantidad}</dd>
                                        </div>
                                        <div class="flex justify-between">
                                            <dt class="text-sm text-red-700">Pagados:</dt>
                                            <dd class="text-sm font-medium">$${formatNumber(data.egresos.pagados)}</dd>
                                        </div>
                                        <div class="flex justify-between">
                                            <dt class="text-sm text-red-700">Adeudados:</dt>
                                            <dd class="text-sm font-medium">$${formatNumber(data.egresos.adeudados)}</dd>
                                        </div>
                                        <div class="flex justify-between border-t pt-2">
                                            <dt class="text-sm font-semibold text-red-900">Total:</dt>
                                            <dd class="text-sm font-bold">$${formatNumber(data.egresos.total)}</dd>
                                        </div>
                                    </dl>
                                </div>
                                <div class="col-span-2 bg-blue-50 p-4 rounded-lg">
                                    <h4 class="font-semibold text-blue-900 mb-3">Resumen</h4>
                                    <dl class="space-y-2">
                                        <div class="flex justify-between">
                                            <dt class="text-sm text-blue-700">Flujo Percibido/Pagado:</dt>
                                            <dd class="text-sm font-medium ${data.resumen.flujoPercibidoPagado >= 0 ? 'text-green-600' : 'text-red-600'}">
                                                $${formatNumber(data.resumen.flujoPercibidoPagado)}
                                            </dd>
                                        </div>
                                        <div class="flex justify-between">
                                            <dt class="text-sm text-blue-700">Flujo Total:</dt>
                                            <dd class="text-sm font-medium ${data.resumen.flujoTotal >= 0 ? 'text-green-600' : 'text-red-600'}">
                                                $${formatNumber(data.resumen.flujoTotal)}
                                            </dd>
                                        </div>
                                        <div class="flex justify-between">
                                            <dt class="text-sm text-blue-700">% Percibido:</dt>
                                            <dd class="text-sm font-medium">${data.resumen.porcentajePercibido.toFixed(2)}%</dd>
                                        </div>
                                    </dl>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            document.body.appendChild(modal);
            window.currentModal = modal;
        } else {
            mostrarError('Error al cargar las estadísticas');
        }
    } catch (error) {
        console.error('Error loading statistics:', error);
        mostrarError('Error al cargar las estadísticas');
    } finally {
        mostrarCargando(false);
    }
}

/**
 * Close modal
 */
function cerrarModal() {
    if (window.currentModal) {
        document.body.removeChild(window.currentModal);
        window.currentModal = null;
    }
}

/**
 * Show print preview
 */
function vistaPrevia() {
    const mes = document.getElementById('selectMes').value;
    const ano = document.getElementById('inputAno').value;
    
    // For now, just print the current view
    window.print();
}

/**
 * Export to Excel
 */
async function exportarExcel() {
    try {
        mostrarCargando(true);
        
        const mes = document.getElementById('selectMes').value;
        const ano = document.getElementById('inputAno').value;
        
        const requestData = {
            Mes: parseInt(mes),
            Ano: parseInt(ano),
            IncluirIngresos: true,
            IncluirEgresos: true,
            Formato: 'Excel'
        };
        
        const response = await fetch('/api/LibroIngresosEgresos/exportar-excel', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestData)
        });
        
        if (response.ok) {
            // Trigger download
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `LibroIngresosEgresos_${mes.padStart(2, '0')}_${ano}.csv`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
            
            mostrarMensaje('Exportación completada', 'success');
        } else {
            mostrarError('Error al exportar los datos');
        }
    } catch (error) {
        console.error('Error exporting:', error);
        mostrarError('Error al exportar los datos');
    } finally {
        mostrarCargando(false);
    }
}

/**
 * Sum selected cells in grid
 */
function sumarSeleccion(gridId) {
    const grid = document.getElementById(gridId);
    if (!grid) return;
    
    const selectedCells = grid.querySelectorAll('td.selected-cell');
    let sum = 0;
    let count = 0;
    
    selectedCells.forEach(cell => {
        const value = parseFloat(cell.textContent.replace(/[^\d.-]/g, ''));
        if (!isNaN(value)) {
            sum += value;
            count++;
        }
    });
    
    if (count > 0) {
        alert(`Suma de ${count} celdas seleccionadas: ${formatNumber(sum)}`);
    } else {
        alert('No hay celdas numéricas seleccionadas');
    }
}

/**
 * Show calculator (simple implementation)
 */
function mostrarCalculadora() {
    const result = prompt('Calculadora simple - Ingrese expresión matemática:', '');
    if (result) {
        try {
            // Basic safety check
            if (/^[0-9+\-*/.() ]+$/.test(result)) {
                const calculation = eval(result);
                alert(`Resultado: ${calculation}`);
            } else {
                alert('Expresión no válida');
            }
        } catch (error) {
            alert('Error en el cálculo');
        }
    }
}

/**
 * Select table row
 */
function seleccionarFila(row) {
    const table = row.closest('table');
    
    // Remove previous selection
    table.querySelectorAll('tr.selected-row').forEach(r => {
        r.classList.remove('selected-row', 'bg-blue-50');
    });
    
    // Add selection to current row
    row.classList.add('selected-row', 'bg-blue-50');
}

/**
 * Show loading overlay
 */
function mostrarCargando(show) {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        if (show) {
            overlay.classList.remove('hidden');
        } else {
            overlay.classList.add('hidden');
        }
    }
}

/**
 * Show error message
 */
function mostrarError(message) {
    mostrarMensaje(message, 'error');
}

/**
 * Show message with type
 */
function mostrarMensaje(message, type = 'info') {
    // Create toast notification
    const toast = document.createElement('div');
    const bgColor = type === 'error' ? 'bg-red-500' : 
                   type === 'success' ? 'bg-green-500' : 
                   'bg-blue-500';
    
    toast.className = `fixed top-4 right-4 ${bgColor} text-white px-6 py-3 rounded-lg shadow-lg z-50`;
    toast.textContent = message;
    
    document.body.appendChild(toast);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        if (toast.parentNode) {
            document.body.removeChild(toast);
        }
    }, 3000);
}

/**
 * Format number with thousands separator
 */
function formatNumber(num) {
    return new Intl.NumberFormat('es-CL').format(num);
}

/**
 * Debounce function to limit API calls
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}









