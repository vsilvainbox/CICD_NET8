$(document).ready(function() {
    // Variables globales
    let comprobantes = [];
    let comprobanteSeleccionado = null;
    let ordenActual = 'nombre';
    let direccionOrden = 'asc';

    // Inicializar
    inicializar();

    function inicializar() {
        configurarEventos();
        cargarComprobantesIniciales();
    }

    function configurarEventos() {
        // Botones principales
        $('#btnBuscar').click(buscar);
        $('#btnLimpiar').click(limpiarFiltros);
        $('#btnEstadisticas').click(mostrarEstadisticas);
        $('#btnExportar').click(exportarLista);

        // Ordenamiento de columnas
        $('#gridComprobantes th[data-sort]').click(function() {
            const columna = $(this).data('sort');
            ordenarPorColumna(columna);
        });

        // Selección de filas
        $(document).on('click', '.comprobante-row', function() {
            $('.comprobante-row').removeClass('table-active');
            $(this).addClass('table-active');
        });

        // Doble clic para seleccionar
        $(document).on('dblclick', '.comprobante-row', function() {
            const idComp = $(this).data('id');
            seleccionarComprobante(idComp);
        });

        // Búsqueda en tiempo real
        $('#nombre, #glosa').on('input', function() {
            clearTimeout(window.buscarTimeout);
            window.buscarTimeout = setTimeout(buscar, 500);
        });

        // Enter en campos de búsqueda
        $('#nombre, #glosa, #usuarioCreacion').on('keypress', function(e) {
            if (e.which === 13) {
                buscar();
            }
        });
    }

    function cargarComprobantesIniciales() {
        const filtros = obtenerFiltros();
        if (filtros.Nombre || filtros.Glosa || filtros.Tipo) {
            buscar();
        }
    }

    function buscar() {
        const filtros = obtenerFiltros();
        
        mostrarCargando('Buscando comprobantes...');

        $.ajax({
            url: '/SeleccionTipo/Buscar',
            type: 'POST',
            data: JSON.stringify(filtros),
            contentType: 'application/json',
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                if (response.success) {
                    comprobantes = response.comprobantes;
                    mostrarComprobantes(comprobantes);
                    $('#totalComprobantes').text(response.total + ' comprobantes');
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al buscar comprobantes');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function obtenerFiltros() {
        return {
            Nombre: $('#nombre').val(),
            Glosa: $('#glosa').val(),
            Tipo: $('#tipo').val() ? parseInt($('#tipo').val()) : null,
            Activo: $('#activo').val() ? $('#activo').val() === 'true' : null,
            FechaCreacionDesde: $('#fechaCreacionDesde').val() ? new Date($('#fechaCreacionDesde').val()) : null,
            FechaCreacionHasta: $('#fechaCreacionHasta').val() ? new Date($('#fechaCreacionHasta').val()) : null,
            UsuarioCreacion: $('#usuarioCreacion').val(),
            OrdenPor: ordenActual,
            DireccionOrden: direccionOrden.toUpperCase(),
            Pagina: 1,
            TamañoPagina: 50
        };
    }

    function mostrarComprobantes(datos) {
        const tbody = $('#gridBody');
        tbody.empty();

        if (datos.length === 0) {
            tbody.append('<tr><td colspan="8" class="text-center">No se encontraron comprobantes</td></tr>');
            return;
        }

        datos.forEach(function(item) {
            const row = `
                <tr data-id="${item.idComp}" class="comprobante-row">
                    <td>${item.nombre}</td>
                    <td>${item.descripcion}</td>
                    <td>${item.glosa}</td>
                    <td>
                        <span class="badge badge-${getTipoClass(item.tipo)}">
                            ${item.tipoNombre}
                        </span>
                    </td>
                    <td>${formatearFecha(item.fechaCreacion)}</td>
                    <td>${item.usuarioCreacion}</td>
                    <td>
                        <span class="badge badge-${item.activo ? 'success' : 'danger'}">
                            ${item.activo ? 'Activo' : 'Inactivo'}
                        </span>
                    </td>
                    <td>
                        <button type="button" class="btn btn-sm btn-primary" onclick="seleccionarComprobante(${item.idComp})">
                            <i class="fas fa-check"></i> Seleccionar
                        </button>
                        <button type="button" class="btn btn-sm btn-info" onclick="verDetalle(${item.idComp})">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button type="button" class="btn btn-sm btn-${item.esFavorito ? 'warning' : 'outline-warning'}" onclick="toggleFavorito(${item.idComp})">
                            <i class="fas fa-star"></i>
                        </button>
                    </td>
                </tr>
            `;
            tbody.append(row);
        });
    }

    function ordenarPorColumna(columna) {
        if (ordenActual === columna) {
            direccionOrden = direccionOrden === 'asc' ? 'desc' : 'asc';
        } else {
            ordenActual = columna;
            direccionOrden = 'asc';
        }

        // Actualizar indicadores visuales
        $('#gridComprobantes th[data-sort]').removeClass('sort-asc sort-desc');
        const th = $(`#gridComprobantes th[data-sort="${columna}"]`);
        th.addClass(direccionOrden === 'asc' ? 'sort-asc' : 'sort-desc');

        // Re-buscar con nuevo ordenamiento
        buscar();
    }

    function seleccionarComprobante(idComp) {
        mostrarCargando('Seleccionando comprobante...');

        $.ajax({
            url: '/SeleccionTipo/Seleccionar',
            type: 'POST',
            data: JSON.stringify({ IdComp: idComp }),
            contentType: 'application/json',
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                if (response.success) {
                    comprobanteSeleccionado = response.resultado;
                    mostrarExito('Comprobante seleccionado exitosamente');
                    
                    // Cerrar modal si está abierto
                    $('#modalDetalle').modal('hide');
                    
                    // Notificar al formulario padre si existe
                    if (window.parent && window.parent.comprobanteSeleccionado) {
                        window.parent.comprobanteSeleccionado(comprobanteSeleccionado);
                    }
                    
                    // Cerrar ventana si es modal
                    if (window.opener) {
                        window.opener.comprobanteSeleccionado(comprobanteSeleccionado);
                        window.close();
                    }
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al seleccionar comprobante');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function verDetalle(idComp) {
        mostrarCargando('Cargando detalle...');

        $.ajax({
            url: `/SeleccionTipo/GetComprobanteTipo/${idComp}`,
            type: 'GET',
            success: function(response) {
                if (response.success) {
                    mostrarDetalleComprobante(response.comprobante);
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al obtener detalle del comprobante');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function mostrarDetalleComprobante(comprobante) {
        const content = `
            <div class="row">
                <div class="col-md-6">
                    <h6>Información General</h6>
                    <table class="table table-sm">
                        <tr><td><strong>ID:</strong></td><td>${comprobante.idComp}</td></tr>
                        <tr><td><strong>Nombre:</strong></td><td>${comprobante.nombre}</td></tr>
                        <tr><td><strong>Descripción:</strong></td><td>${comprobante.descripcion}</td></tr>
                        <tr><td><strong>Glosa:</strong></td><td>${comprobante.glosa}</td></tr>
                        <tr><td><strong>Tipo:</strong></td><td><span class="badge badge-${getTipoClass(comprobante.tipo)}">${comprobante.tipoNombre}</span></td></tr>
                        <tr><td><strong>Estado:</strong></td><td><span class="badge badge-${comprobante.activo ? 'success' : 'danger'}">${comprobante.activo ? 'Activo' : 'Inactivo'}</span></td></tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <h6>Información de Auditoría</h6>
                    <table class="table table-sm">
                        <tr><td><strong>Fecha Creación:</strong></td><td>${formatearFechaHora(comprobante.fechaCreacion)}</td></tr>
                        <tr><td><strong>Fecha Modificación:</strong></td><td>${comprobante.fechaModificacion ? formatearFechaHora(comprobante.fechaModificacion) : 'N/A'}</td></tr>
                        <tr><td><strong>Usuario Creación:</strong></td><td>${comprobante.usuarioCreacion}</td></tr>
                        <tr><td><strong>Usuario Modificación:</strong></td><td>${comprobante.usuarioModificacion || 'N/A'}</td></tr>
                        <tr><td><strong>Es Favorito:</strong></td><td>${comprobante.esFavorito ? 'Sí' : 'No'}</td></tr>
                        <tr><td><strong>Observaciones:</strong></td><td>${comprobante.observaciones || 'N/A'}</td></tr>
                    </table>
                </div>
            </div>
        `;

        $('#detalleContent').html(content);
        $('#modalDetalle').modal('show');
    }

    function toggleFavorito(idComp) {
        const esFavorito = $(`tr[data-id="${idComp}"] .btn-warning`).length > 0;
        
        mostrarCargando(esFavorito ? 'Quitando de favoritos...' : 'Agregando a favoritos...');

        const url = esFavorito ? '/SeleccionTipo/QuitarFavorito' : '/SeleccionTipo/AgregarFavorito';
        
        $.ajax({
            url: url,
            type: 'POST',
            data: JSON.stringify({ IdComp: idComp }),
            contentType: 'application/json',
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                if (response.success) {
                    mostrarExito(response.message);
                    // Actualizar botón
                    const btn = $(`tr[data-id="${idComp}"] .btn-warning, tr[data-id="${idComp}"] .btn-outline-warning`);
                    if (esFavorito) {
                        btn.removeClass('btn-warning').addClass('btn-outline-warning');
                    } else {
                        btn.removeClass('btn-outline-warning').addClass('btn-warning');
                    }
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al actualizar favoritos');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function mostrarEstadisticas() {
        mostrarCargando('Cargando estadísticas...');

        $.ajax({
            url: '/SeleccionTipo/GetEstadisticas',
            type: 'GET',
            success: function(response) {
                if (response.success) {
                    mostrarEstadisticasModal(response.estadisticas);
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al obtener estadísticas');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function mostrarEstadisticasModal(estadisticas) {
        const content = `
            <div class="row">
                <div class="col-md-3">
                    <div class="card bg-primary text-white">
                        <div class="card-body text-center">
                            <h4>${estadisticas.totalComprobantesTipo}</h4>
                            <p>Total Comprobantes</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-success text-white">
                        <div class="card-body text-center">
                            <h4>${estadisticas.comprobantesActivos}</h4>
                            <p>Activos</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-danger text-white">
                        <div class="card-body text-center">
                            <h4>${estadisticas.comprobantesInactivos}</h4>
                            <p>Inactivos</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-warning text-white">
                        <div class="card-body text-center">
                            <h4>${estadisticas.totalFavoritos}</h4>
                            <p>Favoritos</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-12">
                    <h6>Distribución por Tipo</h6>
                    <div class="table-responsive">
                        <table class="table table-sm table-striped">
                            <thead>
                                <tr>
                                    <th>Tipo</th>
                                    <th>Cantidad</th>
                                    <th>Porcentaje</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${estadisticas.porTipo.map(tipo => `
                                    <tr>
                                        <td><span class="badge badge-${getTipoClass(tipo.tipo)}">${tipo.tipoNombre}</span></td>
                                        <td>${tipo.cantidad}</td>
                                        <td>${tipo.porcentaje.toFixed(1)}%</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;

        $('#estadisticasContent').html(content);
        $('#modalEstadisticas').modal('show');
    }

    function exportarLista() {
        const filtros = obtenerFiltros();
        
        mostrarCargando('Exportando lista...');

        $.ajax({
            url: '/SeleccionTipo/ExportarLista',
            type: 'POST',
            data: JSON.stringify(filtros),
            contentType: 'application/json',
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                if (response.success) {
                    descargarArchivo(response.data, 'ComprobantesTipo.xlsx');
                    mostrarExito('Lista exportada exitosamente');
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al exportar lista');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function limpiarFiltros() {
        $('#filtrosForm')[0].reset();
        $('#totalComprobantes').text('0 comprobantes');
        $('#gridBody').empty();
        comprobantes = [];
    }

    function descargarArchivo(data, nombreArchivo) {
        const blob = new Blob([data], { type: 'application/octet-stream' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = nombreArchivo;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    }

    // Funciones de utilidad
    function formatearFecha(fecha) {
        return new Date(fecha).toLocaleDateString('es-CL');
    }

    function formatearFechaHora(fecha) {
        return new Date(fecha).toLocaleString('es-CL');
    }

    function getTipoClass(tipo) {
        switch(tipo) {
            case 1: return 'success'; // Ingreso
            case 2: return 'danger';  // Egreso
            case 3: return 'warning'; // Traspaso
            case 4: return 'info';    // Apertura
            default: return 'secondary';
        }
    }

    function mostrarCargando(mensaje) {
        // Implementar indicador de carga
        console.log('Cargando: ' + mensaje);
    }

    function ocultarCargando() {
        // Ocultar indicador de carga
        console.log('Carga completada');
    }

    function mostrarError(mensaje) {
        toastr.error(mensaje);
    }

    function mostrarExito(mensaje) {
        toastr.success(mensaje);
    }

    function mostrarInfo(mensaje) {
        toastr.info(mensaje);
    }

    // Función global para ser llamada desde el formulario padre
    window.comprobanteSeleccionado = function(comprobante) {
        console.log('Comprobante seleccionado:', comprobante);
        // Esta función será sobrescrita por el formulario padre
    };
});









