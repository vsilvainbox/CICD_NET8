/**
 * JavaScript para la funcionalidad de traspaso de OD a ODF
 */
var TraspasoODToODF = (function() {
    'use strict';

    // Variables globales
    var config = {};
    var documentos = [];
    var tratamientos = [];

    // Inicialización
    function init(options) {
        config = Object.assign({
            puedeEjecutar: false,
            tieneErrores: false,
            requiereConfirmacion: true,
            totalDocumentos: 0,
            valorTotal: 0
        }, options);

        cargarDatosIniciales();
        configurarEventos();
        actualizarResumen();
    }

    // Cargar datos iniciales
    function cargarDatosIniciales() {
        cargarDocumentos();
        cargarTratamientos();
    }

    // Cargar documentos
    function cargarDocumentos() {
        fetch('/TraspasoODToODF/GetDocumentosOD')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    documentos = data.documentos;
                    actualizarTablaDocumentos();
                }
            })
            .catch(error => {
                console.error('Error al cargar documentos:', error);
                mostrarError('Error al cargar documentos');
            });
    }

    // Cargar tratamientos
    function cargarTratamientos() {
        fetch('/TraspasoODToODF/GetTratamientos')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    tratamientos = data.tratamientos;
                    actualizarSelectTratamientos();
                }
            })
            .catch(error => {
                console.error('Error al cargar tratamientos:', error);
                mostrarError('Error al cargar tratamientos');
            });
    }

    // Configurar eventos
    function configurarEventos() {
        // Eventos de checkboxes
        document.getElementById('checkTodos')?.addEventListener('change', function() {
            toggleSeleccionTodos(this.checked);
        });

        document.querySelectorAll('.check-documento').forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                actualizarSeleccionDocumento(this);
            });
        });

        // Eventos de botones
        document.getElementById('btnSeleccionarTodo')?.addEventListener('click', function() {
            seleccionarTodos();
        });

        document.getElementById('btnDeseleccionarTodo')?.addEventListener('click', function() {
            deseleccionarTodos();
        });

        document.getElementById('btnCerrar')?.addEventListener('click', function() {
            cerrarFormulario();
        });

        document.getElementById('btnTraspasar')?.addEventListener('click', function() {
            ejecutarTraspaso();
        });

        document.getElementById('btnConfirmarTraspaso')?.addEventListener('click', function() {
            confirmarTraspaso();
        });

        // Evento del formulario
        document.getElementById('formTraspasoOD')?.addEventListener('submit', function(e) {
            e.preventDefault();
            ejecutarTraspaso();
        });

        // Evento de cambio de tratamiento
        document.getElementById('tratamiento')?.addEventListener('change', function() {
            actualizarResumen();
        });
    }

    // Actualizar tabla de documentos
    function actualizarTablaDocumentos() {
        const tbody = document.querySelector('#tablaDocumentos tbody');
        if (!tbody) return;

        tbody.innerHTML = '';

        documentos.forEach(documento => {
            const row = document.createElement('tr');
            row.setAttribute('data-documento-id', documento.idDoc);
            row.className = documento.seleccionado ? 'table-primary' : '';

            row.innerHTML = `
                <td>
                    <input type="checkbox" class="form-check-input check-documento" 
                           value="${documento.idDoc}" ${documento.seleccionado ? 'checked' : ''}>
                </td>
                <td>${documento.idDoc}</td>
                <td>${documento.numDoc}</td>
                <td>${documento.descripcion}</td>
                <td class="text-end">${documento.total.toLocaleString('es-CL', {minimumFractionDigits: 2})}</td>
                <td><span class="badge bg-secondary">${documento.estado}</span></td>
                <td>${documento.nombreEntidad || ''}</td>
            `;

            // Agregar evento al checkbox
            const checkbox = row.querySelector('.check-documento');
            checkbox.addEventListener('change', function() {
                actualizarSeleccionDocumento(this);
            });

            tbody.appendChild(row);
        });
    }

    // Actualizar select de tratamientos
    function actualizarSelectTratamientos() {
        const select = document.getElementById('tratamiento');
        if (!select) return;

        select.innerHTML = '<option value="">Seleccionar tratamiento...</option>';

        tratamientos.forEach(tratamiento => {
            const option = document.createElement('option');
            option.value = tratamiento.id;
            option.textContent = `${tratamiento.nombre} - ${tratamiento.descripcion}`;
            select.appendChild(option);
        });
    }

    // Toggle selección todos
    function toggleSeleccionTodos(seleccionar) {
        document.querySelectorAll('.check-documento').forEach(checkbox => {
            checkbox.checked = seleccionar;
            actualizarSeleccionDocumento(checkbox);
        });
    }

    // Seleccionar todos
    function seleccionarTodos() {
        document.getElementById('checkTodos').checked = true;
        toggleSeleccionTodos(true);
    }

    // Deseleccionar todos
    function deseleccionarTodos() {
        document.getElementById('checkTodos').checked = false;
        toggleSeleccionTodos(false);
    }

    // Actualizar selección de documento
    function actualizarSeleccionDocumento(checkbox) {
        const documentoId = parseInt(checkbox.value);
        const row = checkbox.closest('tr');
        
        if (checkbox.checked) {
            row.classList.add('table-primary');
        } else {
            row.classList.remove('table-primary');
        }

        // Actualizar estado en el array de documentos
        const documento = documentos.find(d => d.idDoc === documentoId);
        if (documento) {
            documento.seleccionado = checkbox.checked;
        }

        actualizarResumen();
        actualizarEstadoBotonTraspasar();
    }

    // Actualizar resumen
    function actualizarResumen() {
        const documentosSeleccionados = documentos.filter(d => d.seleccionado);
        const tratamientoSeleccionado = document.getElementById('tratamiento')?.value;
        const tratamiento = tratamientos.find(t => t.id == tratamientoSeleccionado);

        // Actualizar contadores
        document.getElementById('totalDocumentos').textContent = documentosSeleccionados.length;
        document.getElementById('valorTotal').textContent = documentosSeleccionados.reduce((sum, d) => sum + d.total, 0).toLocaleString('es-CL', {minimumFractionDigits: 2});
        document.getElementById('tratamientoSeleccionado').textContent = tratamiento ? tratamiento.nombre : 'Ninguno';

        // Actualizar estado
        const estado = obtenerEstadoTraspaso();
        document.getElementById('estadoTraspaso').textContent = estado;
        document.getElementById('estadoTraspaso').className = `text-${obtenerClaseEstado(estado)}`;
    }

    // Obtener estado del traspaso
    function obtenerEstadoTraspaso() {
        const documentosSeleccionados = documentos.filter(d => d.seleccionado);
        const tratamientoSeleccionado = document.getElementById('tratamiento')?.value;

        if (documentosSeleccionados.length === 0) {
            return 'Sin selección';
        }
        if (!tratamientoSeleccionado) {
            return 'Sin tratamiento';
        }
        return 'Listo';
    }

    // Obtener clase CSS para el estado
    function obtenerClaseEstado(estado) {
        switch (estado) {
            case 'Listo': return 'success';
            case 'Sin selección': return 'warning';
            case 'Sin tratamiento': return 'warning';
            default: return 'secondary';
        }
    }

    // Actualizar estado del botón traspasar
    function actualizarEstadoBotonTraspasar() {
        const documentosSeleccionados = documentos.filter(d => d.seleccionado);
        const tratamientoSeleccionado = document.getElementById('tratamiento')?.value;
        const puedeEjecutar = documentosSeleccionados.length > 0 && tratamientoSeleccionado && !config.tieneErrores;

        const boton = document.getElementById('btnTraspasar');
        if (boton) {
            boton.disabled = !puedeEjecutar;
        }
    }

    // Ejecutar traspaso
    function ejecutarTraspaso() {
        if (!validarTraspaso()) {
            return;
        }

        if (config.requiereConfirmacion) {
            mostrarModalConfirmacion();
        } else {
            confirmarTraspaso();
        }
    }

    // Validar traspaso
    function validarTraspaso() {
        const documentosSeleccionados = documentos.filter(d => d.seleccionado);
        const tratamientoSeleccionado = document.getElementById('tratamiento')?.value;

        if (documentosSeleccionados.length === 0) {
            mostrarError('Debe seleccionar al menos un documento');
            return false;
        }

        if (!tratamientoSeleccionado) {
            mostrarError('Debe seleccionar un tratamiento');
            return false;
        }

        return true;
    }

    // Mostrar modal de confirmación
    function mostrarModalConfirmacion() {
        const documentosSeleccionados = documentos.filter(d => d.seleccionado);
        const tratamiento = tratamientos.find(t => t.id == document.getElementById('tratamiento')?.value);
        const valorTotal = documentosSeleccionados.reduce((sum, d) => sum + d.total, 0);

        const detalles = document.getElementById('detallesTraspaso');
        if (detalles) {
            detalles.innerHTML = `
                <div class="alert alert-info">
                    <strong>Documentos a traspasar:</strong> ${documentosSeleccionados.length}<br>
                    <strong>Valor total:</strong> $${valorTotal.toLocaleString('es-CL', {minimumFractionDigits: 2})}<br>
                    <strong>Tratamiento:</strong> ${tratamiento ? tratamiento.nombre : 'No seleccionado'}
                </div>
            `;
        }

        const modal = new bootstrap.Modal(document.getElementById('modalConfirmacion'));
        modal.show();
    }

    // Confirmar traspaso
    function confirmarTraspaso() {
        const documentosSeleccionados = documentos.filter(d => d.seleccionado);
        const tratamientoSeleccionado = document.getElementById('tratamiento')?.value;
        const observaciones = document.getElementById('observaciones')?.value;

        const traspaso = {
            documentosSeleccionados: documentosSeleccionados.map(d => d.idDoc),
            tratamientoId: parseInt(tratamientoSeleccionado),
            observaciones: observaciones,
            requiereConfirmacion: config.requiereConfirmacion,
            registrarSeguimiento: true
        };

        mostrarCarga();

        fetch('/TraspasoODToODF/EjecutarTraspaso', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(traspaso)
        })
        .then(response => response.json())
        .then(data => {
            ocultarCarga();
            mostrarResultado(data);
        })
        .catch(error => {
            ocultarCarga();
            console.error('Error al ejecutar traspaso:', error);
            mostrarError('Error al ejecutar traspaso');
        });
    }

    // Mostrar resultado
    function mostrarResultado(data) {
        const contenido = document.getElementById('contenidoResultado');
        if (!contenido) return;

        let html = '';

        if (data.success) {
            html = `
                <div class="alert alert-success">
                    <h6><i class="fas fa-check-circle me-2"></i>Traspaso Exitoso</h6>
                    <p>${data.message}</p>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="text-center">
                            <h4 class="text-primary">${data.resultado.documentosProcesados}</h4>
                            <p class="text-muted mb-0">Documentos Procesados</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="text-center">
                            <h4 class="text-success">${data.resultado.documentosExitosos}</h4>
                            <p class="text-muted mb-0">Exitosos</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="text-center">
                            <h4 class="text-danger">${data.resultado.documentosConErrores}</h4>
                            <p class="text-muted mb-0">Con Errores</p>
                        </div>
                    </div>
                </div>
            `;

            if (data.resultado.errores && data.resultado.errores.length > 0) {
                html += `
                    <div class="mt-3">
                        <h6>Errores encontrados:</h6>
                        <ul class="list-unstyled">
                            ${data.resultado.errores.map(error => `<li class="text-danger">${error}</li>`).join('')}
                        </ul>
                    </div>
                `;
            }
        } else {
            html = `
                <div class="alert alert-danger">
                    <h6><i class="fas fa-exclamation-triangle me-2"></i>Error en el Traspaso</h6>
                    <p>${data.message}</p>
                </div>
            `;
        }

        contenido.innerHTML = html;

        const modal = new bootstrap.Modal(document.getElementById('modalResultado'));
        modal.show();

        // Recargar documentos después del traspaso
        if (data.success) {
            setTimeout(() => {
                cargarDocumentos();
            }, 2000);
        }
    }

    // Cerrar formulario
    function cerrarFormulario() {
        if (confirm('¿Está seguro de que desea cerrar el formulario?')) {
            window.history.back();
        }
    }

    // Mostrar carga
    function mostrarCarga() {
        const modal = new bootstrap.Modal(document.getElementById('modalCarga'));
        modal.show();
    }

    // Ocultar carga
    function ocultarCarga() {
        const modal = bootstrap.Modal.getInstance(document.getElementById('modalCarga'));
        if (modal) {
            modal.hide();
        }
    }

    // Mostrar error
    function mostrarError(mensaje) {
        // Crear alerta temporal
        const alerta = document.createElement('div');
        alerta.className = 'alert alert-danger alert-dismissible fade show position-fixed';
        alerta.style.top = '20px';
        alerta.style.right = '20px';
        alerta.style.zIndex = '9999';
        alerta.innerHTML = `
            <i class="fas fa-exclamation-triangle me-2"></i>
            ${mensaje}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(alerta);
        
        // Auto-remover después de 5 segundos
        setTimeout(() => {
            if (alerta.parentNode) {
                alerta.parentNode.removeChild(alerta);
            }
        }, 5000);
    }

    // API pública
    return {
        init: init,
        cargarDocumentos: cargarDocumentos,
        cargarTratamientos: cargarTratamientos
    };
})();









