function reporteActivoFijo() {
    return {
        // === DATOS INICIALES (se cargarán desde el modelo Razor) ===
        filtros: {
            fechaHasta: null,
            cuentaActivoFijo: null,
            areaNegocio: null,
            centroGestion: null
        },
        cuentasActivoFijo: [],
        areasNegocio: [],
        centrosGestion: [],
        opcionesVista: {
            verValorCompraHistorico: true,
            verCreditoArt33: true,
            verFechaVentaBaja: true,
            verFechaUtilizacion: true,
            verTipoDepreciacionActual: true,
            verTipoDepreciacionHistorica: false,
            verPatenteRol: false,
            verNombreProyecto: false,
            verFechaProyecto: false
        },

        reporteResultados: null,
        resumen: null,
        estadisticas: null,
        dashboard: null,
        isLoading: false,
        errorMessage: '',
        esVistaResumen: false,

        // === MÉTODOS DE ACCIÓN ===
        async generarReporte() {
            this.isLoading = true;
            this.errorMessage = '';
            this.reporteResultados = null;
            this.resumen = null;
            this.estadisticas = null;
            this.dashboard = null;

            try {
                const response = await fetch('/ReporteActivoFijo/GenerarReporte', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'RequestVerificationToken': document.querySelector('input[name="__RequestVerificationToken"]').value
                    },
                    body: JSON.stringify(this.filtros)
                });

                if (!response.ok) {
                    const errorText = await response.text();
                    throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
                }

                const data = await response.json();
                if (data.success) {
                    this.reporteResultados = data.data.html;
                    this.resumen = data.data.resumen;
                    this.estadisticas = data.data.estadisticas;
                    this.dashboard = data.data.dashboard;
                } else {
                    this.errorMessage = data.message || 'Error al generar el reporte';
                }
            } catch (error) {
                console.error('Error al generar reporte:', error);
                this.errorMessage = 'Error al generar el reporte: ' + error.message;
            } finally {
                this.isLoading = false;
            }
        },

        verActivoFijo() {
            alert('Funcionalidad de ver activo fijo en desarrollo');
        },

        verComprobante() {
            alert('Funcionalidad de ver comprobante en desarrollo');
        },

        verDocumento() {
            alert('Funcionalidad de ver documento en desarrollo');
        },

        async vistaPrevia() {
            try {
                const response = await fetch('/ReporteActivoFijo/VistaPrevia', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'RequestVerificationToken': document.querySelector('input[name="__RequestVerificationToken"]').value
                    },
                    body: JSON.stringify(this.filtros)
                });

                if (!response.ok) {
                    throw new Error('Error al generar vista previa');
                }

                const data = await response.json();
                if (data.success) {
                    // Mostrar vista previa en modal o nueva ventana
                    window.open(data.data, '_blank');
                } else {
                    alert('Error: ' + data.message);
                }
            } catch (error) {
                console.error('Error al generar vista previa:', error);
                alert('Error al generar vista previa: ' + error.message);
            }
        },

        async imprimir() {
            try {
                const response = await fetch('/ReporteActivoFijo/Imprimir', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'RequestVerificationToken': document.querySelector('input[name="__RequestVerificationToken"]').value
                    },
                    body: JSON.stringify(this.filtros)
                });

                if (!response.ok) {
                    throw new Error('Error al generar PDF');
                }

                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'ReporteActivoFijo.pdf';
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                document.body.removeChild(a);
            } catch (error) {
                console.error('Error al imprimir:', error);
                alert('Error al imprimir: ' + error.message);
            }
        },

        async exportarExcel() {
            try {
                const response = await fetch('/ReporteActivoFijo/ExportarExcel', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'RequestVerificationToken': document.querySelector('input[name="__RequestVerificationToken"]').value
                    },
                    body: JSON.stringify(this.filtros)
                });

                if (!response.ok) {
                    throw new Error('Error al generar Excel');
                }

                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'ReporteActivoFijo.xlsx';
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                document.body.removeChild(a);
            } catch (error) {
                console.error('Error al exportar Excel:', error);
                alert('Error al exportar Excel: ' + error.message);
            }
        },

        async copiarExcel() {
            try {
                const response = await fetch('/ReporteActivoFijo/CopiarExcel', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'RequestVerificationToken': document.querySelector('input[name="__RequestVerificationToken"]').value
                    },
                    body: JSON.stringify(this.filtros)
                });

                if (!response.ok) {
                    throw new Error('Error al copiar a Excel');
                }

                const data = await response.json();
                if (data.success) {
                    // Copiar datos al portapapeles
                    await navigator.clipboard.writeText(data.data);
                    alert('Datos copiados al portapapeles');
                } else {
                    alert('Error: ' + data.message);
                }
            } catch (error) {
                console.error('Error al copiar Excel:', error);
                alert('Error al copiar Excel: ' + error.message);
            }
        },

        async sumarMovimientos() {
            // Obtener IDs de movimientos seleccionados
            const idsSeleccionados = this.obtenerMovimientosSeleccionados();
            
            if (idsSeleccionados.length === 0) {
                alert('Seleccione al menos un movimiento para sumar');
                return;
            }

            try {
                const response = await fetch('/ReporteActivoFijo/SumarMovimientos', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'RequestVerificationToken': document.querySelector('input[name="__RequestVerificationToken"]').value
                    },
                    body: JSON.stringify(idsSeleccionados)
                });

                if (!response.ok) {
                    throw new Error('Error al sumar movimientos');
                }

                const data = await response.json();
                if (data.success) {
                    alert('Suma total: ' + this.formatearMoneda(data.data));
                } else {
                    alert('Error: ' + data.message);
                }
            } catch (error) {
                console.error('Error al sumar movimientos:', error);
                alert('Error al sumar movimientos: ' + error.message);
            }
        },

        async convertirMoneda() {
            const monto = prompt('Ingrese el monto a convertir:');
            if (!monto || isNaN(monto)) {
                alert('Monto inválido');
                return;
            }

            const monedaOrigen = prompt('Moneda origen (USD, EUR, CLP):', 'USD');
            const monedaDestino = prompt('Moneda destino (USD, EUR, CLP):', 'CLP');

            try {
                const response = await fetch('/ReporteActivoFijo/ConvertirMoneda', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'RequestVerificationToken': document.querySelector('input[name="__RequestVerificationToken"]').value
                    },
                    body: JSON.stringify({
                        monto: parseFloat(monto),
                        monedaOrigen: monedaOrigen,
                        monedaDestino: monedaDestino
                    })
                });

                if (!response.ok) {
                    throw new Error('Error al convertir moneda');
                }

                const data = await response.json();
                if (data.success) {
                    alert(`${this.formatearMoneda(monto)} ${monedaOrigen} = ${this.formatearMoneda(data.data)} ${monedaDestino}`);
                } else {
                    alert('Error: ' + data.message);
                }
            } catch (error) {
                console.error('Error al convertir moneda:', error);
                alert('Error al convertir moneda: ' + error.message);
            }
        },

        abrirCalculadora() {
            // Abrir calculadora del sistema
            if (navigator.platform.indexOf('Win') !== -1) {
                window.open('calc.exe', '_blank');
            } else if (navigator.platform.indexOf('Mac') !== -1) {
                window.open('Calculator.app', '_blank');
            } else {
                alert('Calculadora no disponible en este sistema');
            }
        },

        abrirCalendario() {
            // Abrir calendario del sistema
            if (navigator.platform.indexOf('Win') !== -1) {
                window.open('timedate.cpl', '_blank');
            } else {
                alert('Calendario no disponible en este sistema');
            }
        },

        async obtenerValoresIndices() {
            try {
                const response = await fetch('/ReporteActivoFijo/ObtenerValoresIndices', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'RequestVerificationToken': document.querySelector('input[name="__RequestVerificationToken"]').value
                    }
                });

                if (!response.ok) {
                    throw new Error('Error al obtener valores e índices');
                }

                const data = await response.json();
                if (data.success) {
                    // Mostrar valores e índices en modal
                    this.mostrarValoresIndices(data.data);
                } else {
                    alert('Error: ' + data.message);
                }
            } catch (error) {
                console.error('Error al obtener valores e índices:', error);
                alert('Error al obtener valores e índices: ' + error.message);
            }
        },

        async alternarVistaResumen() {
            this.esVistaResumen = !this.esVistaResumen;
            
            try {
                const response = await fetch('/ReporteActivoFijo/AlternarVistaResumen', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'RequestVerificationToken': document.querySelector('input[name="__RequestVerificationToken"]').value
                    },
                    body: JSON.stringify(this.esVistaResumen)
                });

                if (!response.ok) {
                    throw new Error('Error al alternar vista');
                }

                const data = await response.json();
                if (data.success) {
                    // Actualizar vista según el resultado
                    this.actualizarVista(data.data);
                } else {
                    alert('Error: ' + data.message);
                }
            } catch (error) {
                console.error('Error al alternar vista:', error);
                alert('Error al alternar vista: ' + error.message);
            }
        },

        // === MÉTODOS AUXILIARES ===
        obtenerMovimientosSeleccionados() {
            // Obtener IDs de movimientos seleccionados en la tabla
            const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
            return Array.from(checkboxes).map(cb => parseInt(cb.value));
        },

        formatearMoneda(valor) {
            return new Intl.NumberFormat('es-CL', {
                style: 'currency',
                currency: 'CLP'
            }).format(valor);
        },

        formatearFecha(fecha) {
            return new Date(fecha).toLocaleDateString('es-CL');
        },

        mostrarValoresIndices(valores) {
            let html = '<div class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">';
            html += '<div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">';
            html += '<div class="mt-3">';
            html += '<h3 class="text-lg font-medium text-gray-900 mb-4">Valores e Índices</h3>';
            html += '<div class="space-y-2">';
            
            valores.forEach(valor => {
                html += `<div class="flex justify-between"><span>${valor.nombre}:</span><span>${valor.valor}</span></div>`;
            });
            
            html += '</div>';
            html += '<div class="mt-4 flex justify-end">';
            html += '<button onclick="this.closest(\'.fixed\').remove()" class="px-4 py-2 bg-gray-300 text-gray-800 rounded hover:bg-gray-400">Cerrar</button>';
            html += '</div>';
            html += '</div>';
            html += '</div>';
            html += '</div>';
            
            document.body.insertAdjacentHTML('beforeend', html);
        },

        actualizarVista(datos) {
            if (this.esVistaResumen) {
                this.resumen = datos.resumen;
                this.reporteResultados = null;
            } else {
                this.reporteResultados = datos.completo;
                this.resumen = null;
            }
        }
    }
}
