$(document).ready(function() {
    // Variables globales
    let comprobantesTipo = [];
    let comprobanteSeleccionado = null;
    let accionPendiente = null;

    // Inicializar
    inicializar();

    function inicializar() {
        cargarComprobantesTipo();
        configurarEventos();
        configurarGrid();
    }

    function cargarComprobantesTipo() {
        $.ajax({
            url: '/ListarPorTipo/GetComprobantesTipo',
            type: 'GET',
            success: function(response) {
                if (response.success) {
                    comprobantesTipo = response.comprobantesTipo;
                    actualizarGrid();
                } else {
                    mostrarError('Error al cargar comprobantes tipo: ' + response.message);
                }
            },
            error: function() {
                mostrarError('Error de conexión al cargar comprobantes tipo');
            }
        });
    }

    function actualizarGrid() {
        const tbody = $('#gridComprobantesTipo tbody');
        tbody.empty();

        comprobantesTipo.forEach(function(item) {
            const fila = crearFilaComprobanteTipo(item);
            tbody.append(fila);
        });

        actualizarTotales();
    }

    function crearFilaComprobanteTipo(item) {
        const tipoClass = item.tipo === 'I' ? 'success' : item.tipo === 'E' ? 'danger' : 'info';
        const tipoTexto = item.tipo === 'I' ? 'Ingreso' : item.tipo === 'E' ? 'Egreso' : 'Traspaso';

        return `
            <tr data-id="${item.idComp}">
                <td>
                    <input type="checkbox" class="chkSelect" value="${item.idComp}">
                </td>
                <td>${item.nombre}</td>
                <td>
                    <span class="badge badge-${tipoClass}">${tipoTexto}</span>
                </td>
                <td>${item.descripcion || ''}</td>
                <td class="text-right">${formatearNumero(item.totalDebe)}</td>
                <td class="text-right">${formatearNumero(item.totalHaber)}</td>
                <td>
                    <div class="btn-group btn-group-sm">
                        <button type="button" class="btn btn-outline-primary btn-sm" onclick="verDetalle(${item.idComp})" title="Ver Detalle">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button type="button" class="btn btn-outline-success btn-sm" onclick="duplicar(${item.idComp})" title="Duplicar">
                            <i class="fas fa-copy"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }

    function actualizarTotales() {
        const totalComprobantes = comprobantesTipo.length;
        const totalDebe = comprobantesTipo.reduce((sum, item) => sum + item.totalDebe, 0);
        const totalHaber = comprobantesTipo.reduce((sum, item) => sum + item.totalHaber, 0);

        $('#totalComprobantes').text(totalComprobantes);
        $('#totalDebe').text(formatearNumero(totalDebe));
        $('#totalHaber').text(formatearNumero(totalHaber));
    }

    function configurarEventos() {
        // Botones principales
        $('#btnNuevo').click(nuevoComprobanteTipo);
        $('#btnEditar').click(editarComprobanteTipo);
        $('#btnEliminar').click(eliminarComprobanteTipo);
        $('#btnImportar').click(mostrarModalImportar);
        $('#btnRecuperar').click(recuperarComprobantesTipo);
        $('#btnImprimir').click(imprimirComprobantesTipo);
        $('#btnExportar').click(exportarComprobantesTipo);

        // Filtros
        $('#btnFiltrar').click(aplicarFiltros);
        $('#filtroNombre, #filtroTipo, #filtroEstado, #filtroFechaDesde, #filtroFechaHasta').on('keyup change', function() {
            if (event.type === 'keyup' && event.keyCode !== 13) return;
            aplicarFiltros();
        });

        // Selección
        $('#chkSelectAll').change(function() {
            $('.chkSelect').prop('checked', this.checked);
            actualizarBotones();
        });

        $(document).on('change', '.chkSelect', function() {
            actualizarBotones();
        });

        // Modal de importación
        $('#btnConfirmarImportar').click(confirmarImportar);

        // Modal de confirmación
        $('#btnConfirmarAccion').click(confirmarAccion);

        // Click en fila
        $(document).on('click', '#gridComprobantesTipo tbody tr', function(e) {
            if (!$(e.target).is('input[type="checkbox"]') && !$(e.target).is('button')) {
                $(this).find('input[type="checkbox"]').prop('checked', true).trigger('change');
            }
        });
    }

    function configurarGrid() {
        // Configurar DataTable si está disponible
        if ($.fn.DataTable) {
            $('#gridComprobantesTipo').DataTable({
                pageLength: 25,
                lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "Todos"]],
                language: {
                    url: '//cdn.datatables.net/plug-ins/1.10.24/i18n/Spanish.json'
                },
                columnDefs: [
                    { orderable: false, targets: [0, 6] }
                ],
                order: [[1, 'asc']]
            });
        }
    }

    function nuevoComprobanteTipo() {
        // Redirigir al formulario de nuevo comprobante tipo
        window.location.href = '/NuevoComprobante?esTipo=true';
    }

    function editarComprobanteTipo() {
        const seleccionados = obtenerSeleccionados();
        if (seleccionados.length === 0) {
            mostrarError('Debe seleccionar un comprobante tipo para editar');
            return;
        }
        if (seleccionados.length > 1) {
            mostrarError('Solo puede editar un comprobante tipo a la vez');
            return;
        }

        const id = seleccionados[0];
        // Redirigir al formulario de edición
        window.location.href = `/NuevoComprobante?esTipo=true&id=${id}`;
    }

    function eliminarComprobanteTipo() {
        const seleccionados = obtenerSeleccionados();
        if (seleccionados.length === 0) {
            mostrarError('Debe seleccionar al menos un comprobante tipo para eliminar');
            return;
        }

        const mensaje = seleccionados.length === 1 
            ? '¿Está seguro de eliminar este comprobante tipo?'
            : `¿Está seguro de eliminar ${seleccionados.length} comprobantes tipo?`;

        mostrarConfirmacion(mensaje, function() {
            eliminarComprobantesTipo(seleccionados);
        });
    }

    function eliminarComprobantesTipo(ids) {
        const promesas = ids.map(id => {
            return $.ajax({
                url: `/ListarPorTipo/Delete/${id}`,
                type: 'POST',
                headers: {
                    'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
                }
            });
        });

        Promise.all(promesas)
            .then(function(responses) {
                const exitosos = responses.filter(r => r.success).length;
                const fallidos = responses.length - exitosos;

                if (exitosos > 0) {
                    mostrarExito(`Se eliminaron ${exitosos} comprobante(s) tipo exitosamente`);
                    cargarComprobantesTipo();
                }
                if (fallidos > 0) {
                    mostrarError(`No se pudieron eliminar ${fallidos} comprobante(s) tipo`);
                }
            })
            .catch(function() {
                mostrarError('Error al eliminar comprobantes tipo');
            });
    }

    function mostrarModalImportar() {
        $('#modalImportar').modal('show');
    }

    function confirmarImportar() {
        const archivo = $('#archivoImportar')[0].files[0];
        if (!archivo) {
            mostrarError('Debe seleccionar un archivo');
            return;
        }

        const formData = new FormData();
        formData.append('archivo', archivo);

        $.ajax({
            url: '/ListarPorTipo/Import',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                if (response.success) {
                    mostrarExito(response.message);
                    $('#modalImportar').modal('hide');
                    cargarComprobantesTipo();
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al importar comprobantes tipo');
            }
        });
    }

    function recuperarComprobantesTipo() {
        mostrarConfirmacion(
            '¿Está seguro de recuperar los comprobantes tipo por omisión? Esta acción eliminará todos los comprobantes tipo existentes.',
            function() {
                $.ajax({
                    url: '/ListarPorTipo/Recover',
                    type: 'POST',
                    headers: {
                        'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
                    },
                    success: function(response) {
                        if (response.success) {
                            mostrarExito(response.message);
                            cargarComprobantesTipo();
                        } else {
                            mostrarError(response.message);
                        }
                    },
                    error: function() {
                        mostrarError('Error al recuperar comprobantes tipo');
                    }
                });
            }
        );
    }

    function imprimirComprobantesTipo() {
        window.open('/ListarPorTipo/Print', '_blank');
    }

    function exportarComprobantesTipo() {
        window.location.href = '/ListarPorTipo/Export';
    }

    function aplicarFiltros() {
        const filtroNombre = $('#filtroNombre').val().toLowerCase();
        const filtroTipo = $('#filtroTipo').val();
        const filtroEstado = $('#filtroEstado').val();
        const filtroFechaDesde = $('#filtroFechaDesde').val();
        const filtroFechaHasta = $('#filtroFechaHasta').val();

        let comprobantesFiltrados = comprobantesTipo;

        if (filtroNombre) {
            comprobantesFiltrados = comprobantesFiltrados.filter(c => 
                c.nombre.toLowerCase().includes(filtroNombre)
            );
        }

        if (filtroTipo) {
            comprobantesFiltrados = comprobantesFiltrados.filter(c => c.tipo === filtroTipo);
        }

        if (filtroEstado) {
            comprobantesFiltrados = comprobantesFiltrados.filter(c => c.estado === filtroEstado);
        }

        if (filtroFechaDesde) {
            const fechaDesde = new Date(filtroFechaDesde);
            comprobantesFiltrados = comprobantesFiltrados.filter(c => 
                new Date(c.fecha) >= fechaDesde
            );
        }

        if (filtroFechaHasta) {
            const fechaHasta = new Date(filtroFechaHasta);
            comprobantesFiltrados = comprobantesFiltrados.filter(c => 
                new Date(c.fecha) <= fechaHasta
            );
        }

        // Actualizar grid con datos filtrados
        const tbody = $('#gridComprobantesTipo tbody');
        tbody.empty();

        comprobantesFiltrados.forEach(function(item) {
            const fila = crearFilaComprobanteTipo(item);
            tbody.append(fila);
        });

        // Actualizar totales con datos filtrados
        const totalComprobantes = comprobantesFiltrados.length;
        const totalDebe = comprobantesFiltrados.reduce((sum, item) => sum + item.totalDebe, 0);
        const totalHaber = comprobantesFiltrados.reduce((sum, item) => sum + item.totalHaber, 0);

        $('#totalComprobantes').text(totalComprobantes);
        $('#totalDebe').text(formatearNumero(totalDebe));
        $('#totalHaber').text(formatearNumero(totalHaber));
    }

    function obtenerSeleccionados() {
        return $('.chkSelect:checked').map(function() {
            return parseInt($(this).val());
        }).get();
    }

    function actualizarBotones() {
        const seleccionados = obtenerSeleccionados();
        const tieneSeleccion = seleccionados.length > 0;
        const tieneUnaSeleccion = seleccionados.length === 1;

        $('#btnEditar').prop('disabled', !tieneUnaSeleccion);
        $('#btnEliminar').prop('disabled', !tieneSeleccion);
    }

    function mostrarConfirmacion(mensaje, callback) {
        $('#mensajeConfirmacion').text(mensaje);
        accionPendiente = callback;
        $('#modalConfirmar').modal('show');
    }

    function confirmarAccion() {
        if (accionPendiente) {
            accionPendiente();
            accionPendiente = null;
        }
        $('#modalConfirmar').modal('hide');
    }

    function mostrarError(mensaje) {
        toastr.error(mensaje);
    }

    function mostrarExito(mensaje) {
        toastr.success(mensaje);
    }

    function mostrarInfo(mensaje) {
        toastr.info(mensaje);
    }

    function formatearNumero(numero) {
        return new Intl.NumberFormat('es-CL', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }).format(numero);
    }

    // Funciones globales para uso en HTML
    window.verDetalle = function(id) {
        $.ajax({
            url: `/ListarPorTipo/GetComprobanteTipo/${id}`,
            type: 'GET',
            success: function(response) {
                if (response.success) {
                    mostrarDetalleComprobanteTipo(response.comprobanteTipo);
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al obtener detalle del comprobante tipo');
            }
        });
    };

    window.duplicar = function(id) {
        mostrarConfirmacion('¿Está seguro de duplicar este comprobante tipo?', function() {
            $.ajax({
                url: `/ListarPorTipo/Duplicate/${id}`,
                type: 'POST',
                headers: {
                    'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
                },
                success: function(response) {
                    if (response.success) {
                        mostrarExito(response.message);
                        cargarComprobantesTipo();
                    } else {
                        mostrarError(response.message);
                    }
                },
                error: function() {
                    mostrarError('Error al duplicar comprobante tipo');
                }
            });
        });
    };

    function mostrarDetalleComprobanteTipo(comprobanteTipo) {
        const contenido = `
            <div class="row">
                <div class="col-md-6">
                    <h6>Información General</h6>
                    <table class="table table-sm">
                        <tr><td><strong>Nombre:</strong></td><td>${comprobanteTipo.nombre}</td></tr>
                        <tr><td><strong>Tipo:</strong></td><td>${comprobanteTipo.tipo}</td></tr>
                        <tr><td><strong>Estado:</strong></td><td>${comprobanteTipo.estado}</td></tr>
                        <tr><td><strong>Fecha:</strong></td><td>${formatearFecha(comprobanteTipo.fecha)}</td></tr>
                        <tr><td><strong>Correlativo:</strong></td><td>${comprobanteTipo.correlativo || ''}</td></tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <h6>Totales</h6>
                    <table class="table table-sm">
                        <tr><td><strong>Total Debe:</strong></td><td class="text-right">${formatearNumero(comprobanteTipo.totalDebe)}</td></tr>
                        <tr><td><strong>Total Haber:</strong></td><td class="text-right">${formatearNumero(comprobanteTipo.totalHaber)}</td></tr>
                    </table>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <h6>Descripción</h6>
                    <p>${comprobanteTipo.descripcion || 'Sin descripción'}</p>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <h6>Glosa</h6>
                    <p>${comprobanteTipo.glosa || 'Sin glosa'}</p>
                </div>
            </div>
        `;

        $('#contenidoDetalle').html(contenido);
        $('#modalDetalle').modal('show');
    }

    function formatearFecha(fecha) {
        return new Date(fecha).toLocaleDateString('es-CL');
    }
});

