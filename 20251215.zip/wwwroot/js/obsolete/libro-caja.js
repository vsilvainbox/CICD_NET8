$(document).ready(function() {
    let gridLibroCaja;
    let datosMovimientos = [];
    let modoEdicion = false;
    let registroEditando = null;

    // Inicializar
    inicializar();

    function inicializar() {
        configurarEventos();
        configurarGrid();
        cargarDatos();
    }

    function configurarEventos() {
        // Botón listar
        $('#btnListar').click(function() {
            cargarDatos();
        });

        // Botón nuevo
        $('#btnNuevo').click(function() {
            nuevoRegistro();
        });

        // Botón opciones
        $('#btnOpciones').click(function() {
            $('#modalOpciones').modal('show');
        });

        // Botón vista previa
        $('#btnVistaPrevia').click(function() {
            mostrarVistaPrevia();
        });

        // Botón imprimir
        $('#btnImprimir').click(function() {
            imprimir();
        });

        // Botón Excel
        $('#btnExcel').click(function() {
            exportarExcel();
        });

        // Botón sumar
        $('#btnSumar').click(function() {
            sumarSeleccionados();
        });

        // Botón saldo total
        $('#btnSaldoTotal').click(function() {
            mostrarSaldoTotal();
        });

        // Botón eliminar todos
        $('#btnEliminarTodos').click(function() {
            eliminarTodos();
        });

        // Botones de importación
        $('#btnImportDocs').click(function() {
            importarDocumentos();
        });

        $('#btnImportOIngEg').click(function() {
            importarOtrosIngresos();
        });

        $('#btnImportTotalDocs').click(function() {
            importarDocumentosAnual();
        });

        $('#btnImportOIngEgAnual').click(function() {
            importarOtrosIngresosAnual();
        });

        // Cambio de filtros
        $('#mes, #ano, #tipoOper, #tipoDoc, #numDoc, #rut, #entidad, #nombre, #valor, #glosa, #incluirSaldoInicial').change(function() {
            cargarDatos();
        });

        // Aplicar opciones
        $('#btnAplicarOpciones').click(function() {
            aplicarOpciones();
            $('#modalOpciones').modal('hide');
        });
    }

    function configurarGrid() {
        gridLibroCaja = $('#gridLibroCaja').DataTable({
            processing: true,
            serverSide: false,
            data: [],
            columns: [
                { data: 'numDoc', title: 'N° Doc.', width: '120px', className: 'text-left' },
                { data: 'tipoDocNombre', title: 'Tipo Doc.', width: '100px', className: 'text-left' },
                { data: 'nombreEntidad', title: 'Entidad', width: '200px', className: 'text-left' },
                { data: 'rut', title: 'RUT', width: '100px', className: 'text-right' },
                { data: 'fechaOperacion', title: 'Fecha', width: '80px', className: 'text-center', render: formatDate },
                { data: 'afecto', title: 'Afecto', width: '100px', className: 'text-right', render: formatCurrency },
                { data: 'iva', title: 'IVA', width: '100px', className: 'text-right', render: formatCurrency },
                { data: 'exento', title: 'Exento', width: '100px', className: 'text-right', render: formatCurrency },
                { data: 'total', title: 'Total', width: '100px', className: 'text-right', render: formatCurrency },
                { data: 'pagado', title: 'Pagado', width: '100px', className: 'text-right', render: formatCurrency },
                { data: 'saldo', title: 'Saldo', width: '100px', className: 'text-right', render: formatCurrency },
                { data: 'descrip', title: 'Descripción', width: '200px', className: 'text-left' },
                { data: 'estado', title: 'Estado', width: '80px', className: 'text-center' },
                { 
                    data: null, 
                    title: 'Acciones', 
                    width: '120px', 
                    className: 'text-center',
                    orderable: false,
                    render: function(data, type, row) {
                        return `
                            <div class="btn-group" role="group">
                                <button type="button" class="btn btn-sm btn-primary" onclick="editarRegistro(${row.idLibroCaja})">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button type="button" class="btn btn-sm btn-info" onclick="verDetalle(${row.idLibroCaja})">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <button type="button" class="btn btn-sm btn-warning" onclick="duplicarRegistro(${row.idLibroCaja})">
                                    <i class="fas fa-copy"></i>
                                </button>
                                <button type="button" class="btn btn-sm btn-danger" onclick="eliminarRegistro(${row.idLibroCaja})">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        `;
                    }
                }
            ],
            order: [[4, 'asc']],
            pageLength: 25,
            lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "Todos"]],
            language: {
                url: '//cdn.datatables.net/plug-ins/1.13.7/i18n/es-ES.json'
            },
            dom: 'Bfrtip',
            buttons: [
                'copy', 'csv', 'excel', 'pdf', 'print'
            ],
            select: {
                style: 'multi',
                selector: 'td:not(:last-child)'
            }
        });
    }

    function cargarDatos() {
        const filtros = obtenerFiltros();
        
        // Mostrar loading
        mostrarLoading();

        $.ajax({
            url: '/LibroCaja/Listar',
            type: 'POST',
            data: filtros,
            success: function(response) {
                if (response.success) {
                    datosMovimientos = response.data;
                    gridLibroCaja.clear().rows.add(datosMovimientos).draw();
                    actualizarTotales();
                } else {
                    mostrarError('Error al cargar datos: ' + response.message);
                }
            },
            error: function() {
                mostrarError('Error al cargar datos');
            },
            complete: function() {
                ocultarLoading();
            }
        });
    }

    function obtenerFiltros() {
        return {
            mes: parseInt($('#mes').val()),
            ano: parseInt($('#ano').val()),
            tipoOper: $('#tipoOper').val() ? parseInt($('#tipoOper').val()) : null,
            tipoDoc: $('#tipoDoc').val() ? parseInt($('#tipoDoc').val()) : null,
            numDoc: $('#numDoc').val(),
            rut: $('#rut').val(),
            entidad: $('#entidad').val() ? parseInt($('#entidad').val()) : null,
            nombre: $('#nombre').val(),
            valor: $('#valor').val() ? parseFloat($('#valor').val()) : null,
            glosa: $('#glosa').val(),
            incluirSaldoInicial: $('#incluirSaldoInicial').is(':checked'),
            fechaDesde: new Date($('#ano').val(), $('#mes').val() - 1, 1),
            fechaHasta: new Date($('#ano').val(), $('#mes').val(), 0)
        };
    }

    function actualizarTotales() {
        const totalIngresos = datosMovimientos.filter(m => m.tipoOper === 1).reduce((sum, m) => sum + (m.total || 0), 0);
        const totalEgresos = datosMovimientos.filter(m => m.tipoOper === 2).reduce((sum, m) => sum + (m.total || 0), 0);
        const saldoNeto = totalIngresos - totalEgresos;
        const totalAfecto = datosMovimientos.reduce((sum, m) => sum + (m.afecto || 0), 0);
        const totalIVA = datosMovimientos.reduce((sum, m) => sum + (m.iva || 0), 0);
        const totalExento = datosMovimientos.reduce((sum, m) => sum + (m.exento || 0), 0);
        const totalPagado = datosMovimientos.reduce((sum, m) => sum + (m.pagado || 0), 0);

        $('#totalIngresos').text(formatCurrency(totalIngresos));
        $('#totalEgresos').text(formatCurrency(totalEgresos));
        $('#saldoNeto').text(formatCurrency(saldoNeto));
        $('#cantidadRegistros').text(datosMovimientos.length);
        $('#totalAfecto').text(formatCurrency(totalAfecto));
        $('#totalIVA').text(formatCurrency(totalIVA));
        $('#totalExento').text(formatCurrency(totalExento));
        $('#totalPagado').text(formatCurrency(totalPagado));

        // Cambiar color del saldo neto
        if (saldoNeto >= 0) {
            $('#saldoNeto').removeClass('text-danger').addClass('text-success');
        } else {
            $('#saldoNeto').removeClass('text-success').addClass('text-danger');
        }
    }

    function nuevoRegistro() {
        modoEdicion = true;
        registroEditando = null;
        // Implementar lógica para nuevo registro
        mostrarMensaje('Funcionalidad de nuevo registro en desarrollo');
    }

    function editarRegistro(id) {
        modoEdicion = true;
        registroEditando = datosMovimientos.find(m => m.idLibroCaja === id);
        // Implementar lógica para editar registro
        mostrarMensaje('Funcionalidad de edición en desarrollo');
    }

    function verDetalle(id) {
        $.ajax({
            url: '/LibroCaja/ObtenerDetalleDocumento',
            type: 'GET',
            data: { id: id },
            success: function(response) {
                if (response.success) {
                    mostrarDetalleDocumento(response.data);
                } else {
                    mostrarError('Error al obtener detalle: ' + response.message);
                }
            },
            error: function() {
                mostrarError('Error al obtener detalle');
            }
        });
    }

    function duplicarRegistro(id) {
        if (confirm('¿Está seguro de que desea duplicar este registro?')) {
            $.ajax({
                url: '/LibroCaja/Duplicar',
                type: 'POST',
                data: { id: id },
                success: function(response) {
                    if (response.success) {
                        mostrarMensaje('Registro duplicado exitosamente');
                        cargarDatos();
                    } else {
                        mostrarError('Error al duplicar: ' + response.message);
                    }
                },
                error: function() {
                    mostrarError('Error al duplicar registro');
                }
            });
        }
    }

    function eliminarRegistro(id) {
        if (confirm('¿Está seguro de que desea eliminar este registro?')) {
            $.ajax({
                url: '/LibroCaja/Eliminar',
                type: 'DELETE',
                data: { id: id },
                success: function(response) {
                    if (response.success) {
                        mostrarMensaje('Registro eliminado exitosamente');
                        cargarDatos();
                    } else {
                        mostrarError('Error al eliminar: ' + response.message);
                    }
                },
                error: function() {
                    mostrarError('Error al eliminar registro');
                }
            });
        }
    }

    function mostrarVistaPrevia() {
        const filtros = obtenerFiltros();
        
        $.ajax({
            url: '/LibroCaja/VistaPrevia',
            type: 'GET',
            data: filtros,
            success: function(response) {
                if (response.success) {
                    $('#contenidoVistaPrevia').html(generarContenidoVistaPrevia(response.data));
                    $('#modalVistaPrevia').modal('show');
                } else {
                    mostrarError('Error al generar vista previa: ' + response.message);
                }
            },
            error: function() {
                mostrarError('Error al generar vista previa');
            }
        });
    }

    function imprimir() {
        const filtros = obtenerFiltros();
        
        $.ajax({
            url: '/LibroCaja/Imprimir',
            type: 'POST',
            data: filtros,
            success: function(response) {
                if (response.success) {
                    // Implementar lógica de impresión
                    window.print();
                } else {
                    mostrarError('Error al imprimir: ' + response.message);
                }
            },
            error: function() {
                mostrarError('Error al imprimir');
            }
        });
    }

    function exportarExcel() {
        const filtros = obtenerFiltros();
        
        $.ajax({
            url: '/LibroCaja/CopiarExcel',
            type: 'POST',
            data: filtros,
            success: function(response) {
                if (response.success) {
                    // Implementar descarga de archivo Excel
                    window.open(response.data.rutaArchivo, '_blank');
                } else {
                    mostrarError('Error al exportar Excel: ' + response.message);
                }
            },
            error: function() {
                mostrarError('Error al exportar Excel');
            }
        });
    }

    function sumarSeleccionados() {
        const filasSeleccionadas = gridLibroCaja.rows({ selected: true }).data();
        const ids = filasSeleccionadas.toArray().map(item => item.idLibroCaja);

        if (ids.length === 0) {
            mostrarAdvertencia('Seleccione al menos un registro para sumar');
            return;
        }

        $.ajax({
            url: '/LibroCaja/SumarSeleccionados',
            type: 'POST',
            data: { ids: ids },
            success: function(response) {
                if (response.success) {
                    mostrarResultadoSuma(response.data);
                } else {
                    mostrarError('Error al sumar selección: ' + response.message);
                }
            },
            error: function() {
                mostrarError('Error al sumar selección');
            }
        });
    }

    function mostrarSaldoTotal() {
        const filtros = obtenerFiltros();
        
        $.ajax({
            url: '/LibroCaja/ObtenerSaldoTotal',
            type: 'GET',
            data: filtros,
            success: function(response) {
                if (response.success) {
                    mostrarResultadoSaldoTotal(response.data);
                } else {
                    mostrarError('Error al obtener saldo total: ' + response.message);
                }
            },
            error: function() {
                mostrarError('Error al obtener saldo total');
            }
        });
    }

    function eliminarTodos() {
        if (confirm('¿Está seguro de que desea eliminar TODOS los registros del período seleccionado?')) {
            const filtros = obtenerFiltros();
            
            $.ajax({
                url: '/LibroCaja/EliminarTodos',
                type: 'POST',
                data: filtros,
                success: function(response) {
                    if (response.success) {
                        mostrarMensaje('Todos los registros han sido eliminados');
                        cargarDatos();
                    } else {
                        mostrarError('Error al eliminar registros: ' + response.message);
                    }
                },
                error: function() {
                    mostrarError('Error al eliminar registros');
                }
            });
        }
    }

    function importarDocumentos() {
        const filtros = obtenerFiltros();
        
        $.ajax({
            url: '/LibroCaja/ImportarDocumentos',
            type: 'POST',
            data: filtros,
            success: function(response) {
                if (response.success) {
                    mostrarResultadoImportacion(response.data);
                    cargarDatos();
                } else {
                    mostrarError('Error al importar documentos: ' + response.message);
                }
            },
            error: function() {
                mostrarError('Error al importar documentos');
            }
        });
    }

    function importarOtrosIngresos() {
        const filtros = obtenerFiltros();
        
        $.ajax({
            url: '/LibroCaja/ImportarOtrosIngresos',
            type: 'POST',
            data: filtros,
            success: function(response) {
                if (response.success) {
                    mostrarResultadoImportacion(response.data);
                    cargarDatos();
                } else {
                    mostrarError('Error al importar otros ingresos: ' + response.message);
                }
            },
            error: function() {
                mostrarError('Error al importar otros ingresos');
            }
        });
    }

    function importarDocumentosAnual() {
        const filtros = obtenerFiltros();
        
        $.ajax({
            url: '/LibroCaja/ImportarDocumentosAnual',
            type: 'POST',
            data: filtros,
            success: function(response) {
                if (response.success) {
                    mostrarResultadoImportacion(response.data);
                    cargarDatos();
                } else {
                    mostrarError('Error al importar documentos anual: ' + response.message);
                }
            },
            error: function() {
                mostrarError('Error al importar documentos anual');
            }
        });
    }

    function importarOtrosIngresosAnual() {
        const filtros = obtenerFiltros();
        
        $.ajax({
            url: '/LibroCaja/ImportarOtrosIngresosAnual',
            type: 'POST',
            data: filtros,
            success: function(response) {
                if (response.success) {
                    mostrarResultadoImportacion(response.data);
                    cargarDatos();
                } else {
                    mostrarError('Error al importar otros ingresos anual: ' + response.message);
                }
            },
            error: function() {
                mostrarError('Error al importar otros ingresos anual');
            }
        });
    }

    function aplicarOpciones() {
        // Implementar lógica para aplicar opciones de vista
        mostrarMensaje('Opciones aplicadas');
    }

    function mostrarResultadoSuma(totales) {
        const contenido = `
            <div class="row">
                <div class="col-6">
                    <strong>Cantidad de registros:</strong>
                </div>
                <div class="col-6 text-end">
                    ${totales.cantidadRegistros}
                </div>
                <div class="col-6">
                    <strong>Total ingresos:</strong>
                </div>
                <div class="col-6 text-end">
                    ${formatCurrency(totales.totalIngresos)}
                </div>
                <div class="col-6">
                    <strong>Total egresos:</strong>
                </div>
                <div class="col-6 text-end">
                    ${formatCurrency(totales.totalEgresos)}
                </div>
                <div class="col-6">
                    <strong>Saldo neto:</strong>
                </div>
                <div class="col-6 text-end">
                    ${formatCurrency(totales.saldoNeto)}
                </div>
                <div class="col-6">
                    <strong>Promedio:</strong>
                </div>
                <div class="col-6 text-end">
                    ${formatCurrency(totales.promedioMonto)}
                </div>
            </div>
        `;
        
        $('#contenidoSuma').html(contenido);
        $('#modalSuma').modal('show');
    }

    function mostrarResultadoSaldoTotal(saldoTotal) {
        const contenido = `
            <div class="row">
                <div class="col-6">
                    <strong>Saldo inicial:</strong>
                </div>
                <div class="col-6 text-end">
                    ${formatCurrency(saldoTotal.saldoInicial)}
                </div>
                <div class="col-6">
                    <strong>Total ingresos:</strong>
                </div>
                <div class="col-6 text-end">
                    ${formatCurrency(saldoTotal.totalIngresos)}
                </div>
                <div class="col-6">
                    <strong>Total egresos:</strong>
                </div>
                <div class="col-6 text-end">
                    ${formatCurrency(saldoTotal.totalEgresos)}
                </div>
                <div class="col-6">
                    <strong>Saldo final:</strong>
                </div>
                <div class="col-6 text-end">
                    ${formatCurrency(saldoTotal.saldoFinal)}
                </div>
                <div class="col-6">
                    <strong>Cantidad movimientos:</strong>
                </div>
                <div class="col-6 text-end">
                    ${saldoTotal.cantidadMovimientos}
                </div>
            </div>
        `;
        
        $('#contenidoSaldoTotal').html(contenido);
        $('#modalSaldoTotal').modal('show');
    }

    function mostrarResultadoImportacion(resultado) {
        const contenido = `
            <div class="alert ${resultado.exito ? 'alert-success' : 'alert-danger'}">
                <h5>${resultado.mensaje}</h5>
                <p><strong>Registros procesados:</strong> ${resultado.registrosProcesados}</p>
                <p><strong>Registros insertados:</strong> ${resultado.registrosInsertados}</p>
                <p><strong>Registros actualizados:</strong> ${resultado.registrosActualizados}</p>
                <p><strong>Registros duplicados:</strong> ${resultado.registrosDuplicados}</p>
                <p><strong>Registros con errores:</strong> ${resultado.registrosConErrores}</p>
                <p><strong>Tiempo de procesamiento:</strong> ${resultado.tiempoProcesamiento}</p>
            </div>
        `;
        
        mostrarMensaje(contenido);
    }

    function mostrarDetalleDocumento(detalle) {
        const contenido = `
            <div class="card">
                <div class="card-header">
                    <h5>Detalle del Documento</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-6">
                            <strong>N° Doc:</strong> ${detalle.numDoc}
                        </div>
                        <div class="col-6">
                            <strong>Tipo Doc:</strong> ${detalle.tipoDoc}
                        </div>
                        <div class="col-6">
                            <strong>Entidad:</strong> ${detalle.entidad}
                        </div>
                        <div class="col-6">
                            <strong>RUT:</strong> ${detalle.rut}
                        </div>
                        <div class="col-6">
                            <strong>Fecha:</strong> ${formatDate(detalle.fechaOperacion)}
                        </div>
                        <div class="col-6">
                            <strong>Estado:</strong> ${detalle.estado}
                        </div>
                        <div class="col-6">
                            <strong>Total:</strong> ${formatCurrency(detalle.total)}
                        </div>
                        <div class="col-6">
                            <strong>Pagado:</strong> ${formatCurrency(detalle.pagado)}
                        </div>
                        <div class="col-6">
                            <strong>Saldo:</strong> ${formatCurrency(detalle.saldo)}
                        </div>
                        <div class="col-12">
                            <strong>Descripción:</strong> ${detalle.descripcion}
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        mostrarMensaje(contenido);
    }

    function generarContenidoVistaPrevia(datos) {
        // Implementar generación de contenido para vista previa
        return '<p>Contenido de vista previa generado</p>';
    }

    function formatCurrency(data, type, row) {
        if (type === 'display' || type === 'type') {
            return new Intl.NumberFormat('es-CL', {
                style: 'currency',
                currency: 'CLP',
                minimumFractionDigits: 0
            }).format(data || 0);
        }
        return data;
    }

    function formatDate(data, type, row) {
        if (type === 'display' || type === 'type') {
            return new Date(data).toLocaleDateString('es-CL');
        }
        return data;
    }

    function mostrarLoading() {
        // Implementar indicador de carga
        $('body').append('<div id="loading" class="loading-overlay"><div class="spinner-border" role="status"><span class="sr-only">Cargando...</span></div></div>');
    }

    function ocultarLoading() {
        $('#loading').remove();
    }

    function mostrarError(mensaje) {
        // Implementar notificación de error
        alert('Error: ' + mensaje);
    }

    function mostrarAdvertencia(mensaje) {
        // Implementar notificación de advertencia
        alert('Advertencia: ' + mensaje);
    }

    function mostrarMensaje(mensaje) {
        // Implementar notificación de mensaje
        alert(mensaje);
    }
});









