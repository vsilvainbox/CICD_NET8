/**
 * Convierte fecha yyyy-MM-dd a formato OLE serial (días desde 1899-12-30)
 * La base de datos VB6 almacena fechas en este formato
 * Ejemplo: 2024-12-01 -> 45627
 */
function fechaToOLE(fechaStr) {
    if (!fechaStr) return 0;
    const fecha = new Date(fechaStr + 'T00:00:00');
    // OLE Date: días desde 30-dic-1899
    const oleBase = new Date(1899, 11, 30);
    const diffMs = fecha - oleBase;
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    return diffDays;
}

/**
 * Convierte formato OLE serial a fecha yyyy-MM-dd
 * Ejemplo: 45627 -> 2024-12-01
 */
function oleToFecha(oleDate) {
    if (!oleDate || oleDate <= 0) return '';
    const oleBase = new Date(1899, 11, 30);
    const fecha = new Date(oleBase.getTime() + oleDate * 24 * 60 * 60 * 1000);
    return fecha.toISOString().split('T')[0];
}

const loader = `
                <div class="h-full mx-auto items-center justify-center flex py-16">
                    <div class="p-8 animate-spin inline-block size-16 border-3 border-current border-t-transparent text-blue-600 rounded-full " role="status" aria-label="loading">
                        <span class="sr-only">Loading...</span>
                    </div>
                </div>
            `;

toastr.options = {
    "closeButton": false,
    "debug": false,
    "newestOnTop": false,
    "progressBar": true,
    "positionClass": "toast-bottom-right",
    "preventDuplicates": false,
    "onclick": null,
    "showDuration": "300",
    "hideDuration": "1000",
    "timeOut": "5000",
    "extendedTimeOut": "1000",
    "showEasing": "swing",
    "hideEasing": "linear",
    "showMethod": "fadeIn",
    "hideMethod": "fadeOut",
}

function handleGet(url, target) {
    if (typeof event !== 'undefined' && event && event.preventDefault) {
        event.preventDefault();
    }
    

    target = target || 'main_div';
    if (!url) {
        console.error('No URL found in the link element.');
        return;
    }

    var container = document.getElementById(target);
    if (!container) {
        console.error('No target container found with the specified ID.');
        return;
    }

    container.innerHTML = loader;
    HSCollapse.hide('#hs-header-base-collapse');

    fetch(url).then(response =>
        response.text()).then(data => {
        container.innerHTML = data;
        $(container).find('script').each(function () {
            eval($(this).text());
        });
        window.HSStaticMethods.autoInit();
    });
}

function handlePost(formElement, target, callback) {
    event.preventDefault();
    target = target || 'main_div';

    const submitButton = $(formElement).find('button[type="submit"]');
    submitButton.prop('disabled', true);

    const form = $(formElement);
    $.validator.unobtrusive.parse(form);

    if (!form.valid()) {
        submitButton.prop('disabled', false);
        Swal.fire({
            text: 'Por favor verifique los datos del formulario',
            icon: 'error',
            showCancelButton: false,
            buttonsStyling: false,
            showClass: {popup: ''},
            hideClass: {popup: ''},
            confirmButtonText: 'Aceptar',
            customClass: {
                confirmButton: 'py-2 px-4 inline-flex items-center gap-x-2 text-sm font-semibold rounded-lg border border-transparent bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none',
            },
        });
        return false;
    }

    Swal.fire({
        text: '¿Confirma la ejecución de la operación?',
        icon: 'question',
        showCancelButton: true,
        buttonsStyling: false,
        showClass: {popup: ''},
        hideClass: {popup: ''},
        cancelButtonText: 'Cancelar',
        confirmButtonText: 'Si, confirmar operación',
        customClass: {
            confirmButton: 'py-2 px-4 inline-flex items-center gap-x-2 text-sm font-semibold rounded-lg border border-transparent bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none',
            cancelButton: 'mx-3 py-2 px-4 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-gray-200 bg-white text-gray-700 shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:pointer-events-none',
        }
    }).then(function (result) {
        if (!result.value) {
            submitButton.prop('disabled', false);
            return;
        }

        const url = form.attr('action');
        if (!url) {
            submitButton.prop('disabled', false);
            console.error('No action URL found in the form element.');
            return;
        }
        const token = $('input[name=\'__RequestVerificationToken\']').val();
        if (!token) {
            submitButton.prop('disabled', false);
            console.error('No RequestVerificationToken found in the form.');
            return;
        }

        const formData = new FormData(form[0]);

        fetch(url, {
            method: 'POST',
            headers: {
                'RequestVerificationToken': token
            },
            body: formData
        })
        .then(response => response.json())
        .then(result => {

            if (!result.ok) {
                toastr["error"](result.message);
                submitButton.prop('disabled', false);
                return;
            }

            const shouldKeepOpen = form.attr('data-keep-open') === 'true';
            if (formElement.closest('.hs-overlay') && !shouldKeepOpen) {
                window.HSOverlay.close(formElement.closest('.hs-overlay'));
            }

            if (result.returnUrl) {

                var container = document.getElementById(target);

                fetch(result.returnUrl)
                    .then(response => response.text())
                    .then(data => {
                        container.innerHTML = data;
                        $(container).find('script').each(function () {
                            eval($(this).text());
                        });
                        window.HSStaticMethods.autoInit();

                        if (typeof callback === "function") {
                            callback();
                        }
                    });
            }

            toastr["success"](result.message);
            submitButton.prop('disabled', false);
        })
        .catch(error => {
            toastr["error"](result.message);
        });
    });
}

function handleDelete(link, target) {
    event.preventDefault();

    target = target || 'main_div';

    const url = link.getAttribute('href');
    if (!url) {
        console.error('No URL found in the link element.');
        return;
    }

    Swal.fire({
        text: '¿Confirma la eliminación de datos ?',
        icon: 'warning',
        showCancelButton: true,
        buttonsStyling: false,
        showClass: {popup: ''},
        hideClass: {popup: ''},
        cancelButtonText: 'Cancelar',
        confirmButtonText: 'Si, confirmar eliminación',
        customClass: {
            confirmButton: 'py-2 px-4 inline-flex items-center gap-x-2 text-sm font-semibold rounded-lg border border-transparent text-white bg-red-500 border border-transparent rounded-lg gap-x-2 hover:bg-red-600 disabled:opacity-50 disabled:pointer-events-none',
            cancelButton: 'mx-3 py-2 px-4 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-gray-200 bg-white text-gray-700 shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:pointer-events-none',
        }
    }).then(function (result) {
        if (!result.value) {
            return;
        }

        const token = $('input[name=\'__RequestVerificationToken\']').val();
        if (!token) {
            console.error('No RequestVerificationToken found in the form.');
            return;
        }

        fetch(url, {
            method: 'POST',
            headers: {
                'RequestVerificationToken': token
            }
        })
            .then(response => response.json())
            .then(result => {
                if (result.ok) {
                    if (result.closeModal) {
                        window.HSOverlay.close(result.closeModal);
                    }

                    if (result.returnUrl) {
                        document.getElementById(target).innerHTML = loader;
                        fetch(result.returnUrl)
                            .then(response => response.text())
                            .then(data => {
                                document.getElementById(target).innerHTML = data;
                                window.HSStaticMethods.autoInit();
                            });
                    }
                    toastr.success(result.message);
                }
                if (!result.ok) {
                    toastr.error(result.message);
                }
            });
    });
}

function addRowToTable(link, tableid) {
    event.preventDefault();
    const url = link.getAttribute('href');
    if (!url) {
        console.error('No URL found in the link element.');
        return;
    }

    var table = document.getElementById(tableid);
    if (!table) {
        console.error('No table specified for adding a row.');
        return;
    }

    fetch(url, {method: 'GET'})
    .then(response => response.text())
    .then(data => {
        const lastRow = $(table).find('tbody tr:last');
        if (lastRow.length == 0) {
            $(table).find('tbody').append(data);
        } else {
            lastRow.after(data);
        }
        window.HSStaticMethods.autoInit();
    });
}

function closeModal(button) {
    const modal = $(button).closest('.hs-overlay');
    if (!modal.length) {
        return;
    }

    const contentDiv = modal.find('div[id*="_content"]');
    if (contentDiv.length) {
        contentDiv.empty();
    }

    window.HSOverlay.close('#' + modal.attr('id'));
}

function handlePostAndReload(formElement, modalId) {
    event.preventDefault();

    const submitButton = $(formElement).find('button[type="submit"]');
    submitButton.prop('disabled', true);

    const form = $(formElement);
    $.validator.unobtrusive.parse(form);

    if (!form.valid()) {
        submitButton.prop('disabled', false);
        Swal.fire({
            text: 'Por favor verifique los datos del formulario',
            icon: 'error',
            showCancelButton: false,
            buttonsStyling: false,
            showClass: {popup: ''},
            hideClass: {popup: ''},
            confirmButtonText: 'Aceptar',
            customClass: {
                confirmButton: 'py-2 px-4 inline-flex items-center gap-x-2 text-sm font-semibold rounded-lg border border-transparent bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none',
            },
        });
        return false;
    }

    Swal.fire({
        text: '¿Confirma la ejecución de la operación?',
        icon: 'question',
        showCancelButton: true,
        buttonsStyling: false,
        showClass: {popup: ''},
        hideClass: {popup: ''},
        cancelButtonText: 'Cancelar',
        confirmButtonText: 'Si, confirmar operación',
        customClass: {
            confirmButton: 'py-2 px-4 inline-flex items-center gap-x-2 text-sm font-semibold rounded-lg border border-transparent bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none',
            cancelButton: 'mx-3 py-2 px-4 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-gray-200 bg-white text-gray-700 shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:pointer-events-none',
        }
    }).then(function (result) {
        if (!result.value) {
            submitButton.prop('disabled', false);
            return;
        }

        const url = form.attr('action');
        if (!url) {
            submitButton.prop('disabled', false);
            console.error('No action URL found in the form element.');
            return;
        }
        const token = $('input[name=\'__RequestVerificationToken\']').val();
        if (!token) {
            submitButton.prop('disabled', false);
            console.error('No RequestVerificationToken found in the form.');
            return;
        }

        const formData = new FormData(form[0]);

        fetch(url, {
            method: 'POST',
            headers: {
                'RequestVerificationToken': token
            },
            body: formData
        })
        .then(response => response.json())
        .then(result => {

            if (!result.ok) {
                toastr["error"](result.message);
                submitButton.prop('disabled', false);
                return;
            }

            // Close modal
            if (modalId) {
                window.HSOverlay.close(modalId);
            }

            // Show success message
            toastr["success"](result.message);

            // Reload page to refresh the list
            window.location.reload();
        })
        .catch(error => {
            toastr["error"]("Error al procesar la solicitud");
            submitButton.prop('disabled', false);
        });
    });
}

window.generateAnidReport = async function (ev, endpoint, button) {
    if (ev && typeof ev.preventDefault === 'function') {
        ev.preventDefault();
    }

    const target = button instanceof HTMLElement ? button : null;
    if (!target) {
        console.error('No se proporcionó una referencia válida al botón');
        return false;
    }

    // Guardar contenido original y deshabilitar botón
    const originalContent = target.innerHTML;
    target.disabled = true;
    target.classList.add('cursor-wait', 'opacity-75');
    target.innerHTML = '<span class="inline-flex items-center gap-2"><span class="inline-flex h-4 w-4 animate-spin rounded-full border-2 border-white/80 border-t-transparent"></span><span>Generando...</span></span>';

    try {
        // Realizar petición al servidor
        const response = await fetch(endpoint, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        });

        if (!response.ok) {
            const statusText = response.statusText || 'Error desconocido';
            throw new Error(`No fue posible generar el reporte (HTTP ${response.status}: ${statusText})`);
        }

        const payload = await response.json();
        
        // Validar que existan datos para exportar
        const columns = payload.columns ?? payload.Columns ?? [];
        const notes = payload.notes ?? payload.Notes ?? [];
        const rows = payload.rows ?? payload.Rows ?? [];

        if (columns.length === 0 && rows.length === 0) {
            throw new Error('No hay datos disponibles para exportar');
        }

        // Actualizar estado del botón
        target.innerHTML = '<span class="inline-flex items-center gap-2"><span class="inline-flex h-4 w-4 animate-spin rounded-full border-2 border-white/80 border-t-transparent"></span><span>Descargando archivo...</span></span>';

        // Generar archivo Excel
        const sheetData = [columns, notes, ...rows];
        const worksheet = XLSX.utils.aoa_to_sheet(sheetData);

        // Agregar autofiltro a las columnas
        if (worksheet['!ref']) {
            const range = XLSX.utils.decode_range(worksheet['!ref']);
            worksheet['!autofilter'] = { ref: XLSX.utils.encode_range(range) };
        }

        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, 'Reporte');
        const fileName = payload.fileName ?? payload.FileName ?? 'Reporte_ANID.xlsx';
        
        // Descargar archivo
        XLSX.writeFile(workbook, fileName);

        if (typeof toastr !== 'undefined') {
            toastr.success('Reporte descargado correctamente');
        }
    } catch (error) {
        console.error('Error al generar reporte ANID:', error);
        if (typeof toastr !== 'undefined') {
            toastr.error(error?.message ?? 'Ocurrió un error al generar el reporte');
        }
    } finally {
        // Restaurar estado original del botón
        if (target) {
            target.disabled = false;
            target.classList.remove('cursor-wait', 'opacity-75');
            target.innerHTML = originalContent;
        }
    }

    return false;
};