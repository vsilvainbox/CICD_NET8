/**
 * NuevoComprobante - Modulo JS minimalista para UI
 * Solo contiene funciones de manipulacion de UI, la logica de negocio esta en C#
 */
const NuevoComprobante = (function() {
    'use strict';

    // Estado interno
    let _config = {};
    let _selectedRowIndex = -1;
    let _copiedValue = null;
    let _copiedField = null;

    // ========== UTILIDAD PARA MANEJO DE RESPUESTAS API ==========

    /**
     * Maneja respuestas de API, mostrando errores con SweetAlert si es necesario
     * @param {Response} response - Objeto Response de fetch
     * @param {string} errorTitle - Titulo opcional para el mensaje de error
     * @returns {Promise<object|null>} - Datos JSON o null si hubo error
     */
    async function handleApiResponse(response, errorTitle = 'Error') {
        if (!response.ok) {
            let errorMessage = 'Error en la solicitud';
            try {
                const errorData = await response.json();
                errorMessage = errorData.message || errorData.error || errorData.title || errorMessage;
            } catch (e) {
                errorMessage = `Error HTTP ${response.status}`;
            }
            Swal.fire({
                icon: 'error',
                title: errorTitle,
                text: errorMessage
            });
            return null;
        }
        try {
            return await response.json();
        } catch (e) {
            // Respuesta vacia o no JSON es OK en algunos casos
            return {};
        }
    }

    /**
     * Inicializa el modulo con la configuracion desde el servidor
     * @param {Object} config - URLs y datos de sesion
     */
    function init(config) {
        _config = config || {};
        calcularTotales();
        actualizarEstadoVacio();
        bindEventos();
    }

    // ========== MODALES ==========

    function openModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('hidden');
            // Preparar datos del modal si es necesario
            if (modalId === 'modalAutoBalance') {
                prepararModalCuadre();
            }
        }
    }

    function closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('hidden');
        }
    }

    function prepararModalCuadre() {
        const diff = calcularDiferencia();
        const diffEl = document.getElementById('BalanceDifference');
        const colEl = document.getElementById('BalanceColumn');
        if (diffEl) diffEl.textContent = formatearMoneda(Math.abs(diff));
        if (colEl) colEl.textContent = diff > 0 ? 'HABER' : 'DEBE';
    }

    // ========== MOVIMIENTOS - CRUD ==========

    function agregarMovimiento() {
        const tbody = document.getElementById('movimientosTableBody');
        const index = tbody.querySelectorAll('tr[data-index]').length;

        fetch(`${_config.urls.getMovimientoRow}?index=${index}`)
            .then(response => response.text())
            .then(html => {
                tbody.insertAdjacentHTML('beforeend', html);
                reindexarMovimientos();
                calcularTotales();
                actualizarEstadoVacio();
                // Activar validacion para nueva fila
                if ($.validator && $.validator.unobtrusive) {
                    $.validator.unobtrusive.parse('#frmComprobante');
                }
            })
            .catch(err => console.error('Error al agregar movimiento:', err));
    }

    function eliminarMovimiento() {
        if (_selectedRowIndex < 0) {
            Swal.fire({ icon: 'warning', title: 'Seleccione un movimiento', text: 'Debe seleccionar una fila para eliminar' });
            return;
        }

        Swal.fire({
            title: 'Eliminar movimiento?',
            text: 'Esta accion no se puede deshacer',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d64000',
            confirmButtonText: 'Si, eliminar'
        }).then(result => {
            if (result.isConfirmed) {
                const row = document.querySelector(`tr[data-index="${_selectedRowIndex}"]`);
                if (row) row.remove();
                _selectedRowIndex = -1;
                reindexarMovimientos();
                calcularTotales();
                actualizarEstadoVacio();
            }
        });
    }

    function duplicarMovimiento() {
        if (_selectedRowIndex < 0) {
            Swal.fire({ icon: 'warning', title: 'Seleccione un movimiento', text: 'Debe seleccionar una fila para duplicar' });
            return;
        }

        const row = document.querySelector(`tr[data-index="${_selectedRowIndex}"]`);
        if (!row) return;

        const tbody = document.getElementById('movimientosTableBody');
        const newIndex = tbody.querySelectorAll('tr[data-index]').length;

        // Clonar fila y actualizar indices
        const newRow = row.cloneNode(true);
        newRow.setAttribute('data-index', newIndex);

        // Actualizar nombres de inputs
        newRow.querySelectorAll('input, select').forEach(input => {
            const name = input.name;
            if (name) {
                input.name = name.replace(/\[\d+\]/, `[${newIndex}]`);
                input.id = input.id.replace(/_\d+__/, `_${newIndex}__`);
            }
        });

        tbody.appendChild(newRow);
        reindexarMovimientos();
        calcularTotales();
    }

    function duplicarMovimientoFila(index) {
        const row = document.querySelector(`tr[data-index="${index}"]`);
        if (!row) return;

        const tbody = document.getElementById('movimientosTableBody');
        const newIndex = tbody.querySelectorAll('tr[data-index]').length;

        // Clonar fila y actualizar indices
        const newRow = row.cloneNode(true);
        newRow.setAttribute('data-index', newIndex);

        // Actualizar nombres de inputs
        newRow.querySelectorAll('input, select').forEach(input => {
            const name = input.name;
            if (name) {
                input.name = name.replace(/\[\d+\]/, `[${newIndex}]`);
                input.id = input.id.replace(/_\d+__/, `_${newIndex}__`);
            }
        });

        // Insertar despues de la fila original
        row.parentNode.insertBefore(newRow, row.nextSibling);
        reindexarMovimientos();
        calcularTotales();
    }

    function eliminarMovimientoFila(index) {
        const row = document.querySelector(`tr[data-index="${index}"]`);
        if (!row) return;

        row.remove();

        // Ajustar indice seleccionado si es necesario
        if (_selectedRowIndex === index) {
            _selectedRowIndex = -1;
        } else if (_selectedRowIndex > index) {
            _selectedRowIndex--;
        }

        reindexarMovimientos();
        calcularTotales();
    }

    function moverArriba() {
        if (_selectedRowIndex <= 0) return;
        const tbody = document.getElementById('movimientosTableBody');
        const rows = tbody.querySelectorAll('tr[data-index]');
        if (_selectedRowIndex > 0 && rows[_selectedRowIndex]) {
            tbody.insertBefore(rows[_selectedRowIndex], rows[_selectedRowIndex - 1]);
            _selectedRowIndex--;
            reindexarMovimientos();
        }
    }

    function moverAbajo() {
        const tbody = document.getElementById('movimientosTableBody');
        const rows = tbody.querySelectorAll('tr[data-index]');
        if (_selectedRowIndex >= 0 && _selectedRowIndex < rows.length - 1) {
            tbody.insertBefore(rows[_selectedRowIndex + 1], rows[_selectedRowIndex]);
            _selectedRowIndex++;
            reindexarMovimientos();
        }
    }

    function moverArribaFila(index) {
        if (index <= 0) return;
        const tbody = document.getElementById('movimientosTableBody');
        const rows = tbody.querySelectorAll('tr[data-index]');
        if (rows[index] && rows[index - 1]) {
            tbody.insertBefore(rows[index], rows[index - 1]);
            if (_selectedRowIndex === index) _selectedRowIndex--;
            reindexarMovimientos();
        }
    }

    function moverAbajoFila(index) {
        const tbody = document.getElementById('movimientosTableBody');
        const rows = tbody.querySelectorAll('tr[data-index]');
        if (index >= 0 && index < rows.length - 1 && rows[index] && rows[index + 1]) {
            tbody.insertBefore(rows[index + 1], rows[index]);
            if (_selectedRowIndex === index) _selectedRowIndex++;
            reindexarMovimientos();
        }
    }

    function reindexarMovimientos() {
        const rows = document.querySelectorAll('#movimientosTableBody tr[data-index]');
        rows.forEach((row, idx) => {
            row.setAttribute('data-index', idx);
            // Actualizar numero de fila visual
            const numCell = row.querySelector('td:nth-child(2)');
            if (numCell) numCell.textContent = idx + 1;

            // Actualizar nombres de inputs para model binding
            row.querySelectorAll('input, select').forEach(input => {
                if (input.name) {
                    input.name = input.name.replace(/Movimientos\[\d+\]/, `Movimientos[${idx}]`);
                }
                if (input.id) {
                    input.id = input.id.replace(/Movimientos_\d+__/, `Movimientos_${idx}__`);
                }
            });
        });
    }

    // ========== SELECCION DE FILAS ==========

    function seleccionarFila(index) {
        // Deseleccionar anterior
        document.querySelectorAll('#movimientosTableBody tr').forEach(r => r.classList.remove('bg-primary-50'));

        // Seleccionar nueva
        const row = document.querySelector(`tr[data-index="${index}"]`);
        if (row) {
            row.classList.add('bg-primary-50');
            _selectedRowIndex = index;
        }
    }

    // ========== CALCULOS ==========

    function calcularTotales() {
        let totalDebe = 0;
        let totalHaber = 0;

        document.querySelectorAll('#movimientosTableBody tr[data-index]').forEach(row => {
            const debeInput = row.querySelector('input[name$=".Debe"]');
            const haberInput = row.querySelector('input[name$=".Haber"]');

            if (debeInput) totalDebe += parseFloat(debeInput.value) || 0;
            if (haberInput) totalHaber += parseFloat(haberInput.value) || 0;
        });

        document.getElementById('totalDebe').textContent = formatearMoneda(totalDebe);
        document.getElementById('totalHaber').textContent = formatearMoneda(totalHaber);

        // Estado de balance
        const diff = totalDebe - totalHaber;
        const statusEl = document.getElementById('balanceStatus');
        if (statusEl) {
            if (Math.abs(diff) < 0.01) {
                statusEl.innerHTML = '<span class="text-green-600"><i class="fas fa-check-circle mr-1"></i>Cuadrado</span>';
            } else {
                const tipo = diff > 0 ? 'Falta Haber' : 'Falta Debe';
                statusEl.innerHTML = `<span class="text-red-600"><i class="fas fa-exclamation-circle mr-1"></i>${tipo}: ${formatearMoneda(Math.abs(diff))}</span>`;
            }
        }
    }

    function calcularDiferencia() {
        let totalDebe = 0;
        let totalHaber = 0;
        document.querySelectorAll('#movimientosTableBody tr[data-index]').forEach(row => {
            const debeInput = row.querySelector('input[name$=".Debe"]');
            const haberInput = row.querySelector('input[name$=".Haber"]');
            if (debeInput) totalDebe += parseFloat(debeInput.value) || 0;
            if (haberInput) totalHaber += parseFloat(haberInput.value) || 0;
        });
        return totalDebe - totalHaber;
    }

    function formatearMoneda(valor) {
        return '$' + valor.toLocaleString('es-CL', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    // ========== COPIAR/PEGAR ==========

    function confirmarCopiarValor() {
        const field = document.getElementById('CopyFieldSelect').value;
        if (_selectedRowIndex < 0) {
            Swal.fire({ icon: 'warning', title: 'Seleccione una fila', text: 'Debe seleccionar una fila origen' });
            return;
        }

        const row = document.querySelector(`tr[data-index="${_selectedRowIndex}"]`);
        if (!row) return;

        let value = null;
        switch (field) {
            case 'debe':
                value = row.querySelector('input[name$=".Debe"]')?.value;
                break;
            case 'haber':
                value = row.querySelector('input[name$=".Haber"]')?.value;
                break;
            case 'glosa':
                value = row.querySelector('input[name$=".Glosa"]')?.value;
                break;
            case 'codigoCuenta':
                value = row.querySelector('input[name$=".CodigoCuenta"]')?.value;
                break;
        }

        _copiedValue = value;
        _copiedField = field;
        closeModal('modalCopyValue');

        Swal.fire({ icon: 'success', title: 'Valor copiado', text: `${field}: ${value}`, timer: 1500, showConfirmButton: false });
    }

    function pegarValor() {
        if (!_copiedValue || !_copiedField) {
            Swal.fire({ icon: 'warning', title: 'Nada que pegar', text: 'Primero debe copiar un valor' });
            return;
        }

        // Pegar a todas las filas
        document.querySelectorAll('#movimientosTableBody tr[data-index]').forEach(row => {
            let input = null;
            switch (_copiedField) {
                case 'debe':
                    input = row.querySelector('input[name$=".Debe"]');
                    break;
                case 'haber':
                    input = row.querySelector('input[name$=".Haber"]');
                    break;
                case 'glosa':
                    input = row.querySelector('input[name$=".Glosa"]');
                    break;
                case 'codigoCuenta':
                    input = row.querySelector('input[name$=".CodigoCuenta"]');
                    break;
            }
            if (input) input.value = _copiedValue;
        });

        calcularTotales();
        Swal.fire({ icon: 'success', title: 'Valor pegado', timer: 1000, showConfirmButton: false });
    }

    function sumarSeleccionados() {
        let suma = 0;
        document.querySelectorAll('#movimientosTableBody tr.bg-primary-50').forEach(row => {
            const debe = parseFloat(row.querySelector('input[name$=".Debe"]')?.value) || 0;
            const haber = parseFloat(row.querySelector('input[name$=".Haber"]')?.value) || 0;
            suma += debe + haber;
        });
        Swal.fire({ title: 'Suma de seleccionados', html: `<strong>${formatearMoneda(suma)}</strong>`, icon: 'info' });
    }

    // ========== NAVEGACION ==========

    function navigateFirst() {
        window.location.href = `${_config.urls.index}?nav=first`;
    }

    function navigatePrev() {
        window.location.href = `${_config.urls.index}?nav=prev&id=${_config.idComp}`;
    }

    function navigateNext() {
        window.location.href = `${_config.urls.index}?nav=next&id=${_config.idComp}`;
    }

    function navigateLast() {
        window.location.href = `${_config.urls.index}?nav=last`;
    }

    // ========== VALIDACION PRE-SUBMIT ==========

    function validarYPrepararComprobante() {
        const rows = document.querySelectorAll('#movimientosTableBody tr[data-index]');

        // Validar que haya al menos un movimiento
        if (rows.length === 0) {
            Swal.fire({ icon: 'error', title: 'Sin movimientos', text: 'Debe agregar al menos un movimiento contable' });
            return false;
        }

        // Validar que este cuadrado
        const diff = calcularDiferencia();
        if (Math.abs(diff) >= 0.01) {
            Swal.fire({ icon: 'error', title: 'Comprobante descuadrado', text: `Diferencia de ${formatearMoneda(Math.abs(diff))}. Use "Cuadrar Automatico" para balancear.` });
            return false;
        }

        // Validar campos requeridos en cada fila
        let valid = true;
        rows.forEach((row, idx) => {
            const codigoCuenta = row.querySelector('input[name$=".CodigoCuenta"]')?.value;
            const idCuenta = row.querySelector('input[name$=".IdCuenta"]')?.value;

            if (!codigoCuenta || !idCuenta) {
                valid = false;
                row.classList.add('bg-red-50');
            }
        });

        if (!valid) {
            Swal.fire({ icon: 'error', title: 'Datos incompletos', text: 'Hay movimientos sin cuenta asignada' });
            return false;
        }

        return true;
    }

    // ========== CUADRE AUTOMATICO ==========

    function cuadrarAutomatico() {
        const codigoCuenta = document.getElementById('BalanceAccountCode')?.value;
        if (!codigoCuenta) {
            Swal.fire({ icon: 'warning', title: 'Cuenta requerida', text: 'Ingrese un codigo de cuenta para el cuadre' });
            return;
        }

        const diff = calcularDiferencia();
        if (Math.abs(diff) < 0.01) {
            Swal.fire({ icon: 'info', title: 'Ya esta cuadrado', text: 'El comprobante ya esta balanceado' });
            closeModal('modalAutoBalance');
            return;
        }

        // Agregar movimiento de cuadre
        agregarMovimiento();

        // Esperar a que se agregue y luego asignar valores
        setTimeout(() => {
            const rows = document.querySelectorAll('#movimientosTableBody tr[data-index]');
            const lastRow = rows[rows.length - 1];
            if (lastRow) {
                const codigoInput = lastRow.querySelector('input[name$=".CodigoCuenta"]');
                const debeInput = lastRow.querySelector('input[name$=".Debe"]');
                const haberInput = lastRow.querySelector('input[name$=".Haber"]');

                if (codigoInput) codigoInput.value = codigoCuenta;
                if (diff > 0 && haberInput) haberInput.value = Math.abs(diff).toFixed(2);
                if (diff < 0 && debeInput) debeInput.value = Math.abs(diff).toFixed(2);

                // Disparar busqueda de cuenta
                if (codigoInput) codigoInput.dispatchEvent(new Event('change'));

                calcularTotales();
            }
            closeModal('modalAutoBalance');
        }, 300);
    }

    // ========== CONVERSION MONEDA ==========

    function convertirMoneda() {
        const monto = parseFloat(document.getElementById('ConvertAmount')?.value) || 0;
        const desde = document.getElementById('ConvertFromCurrency')?.value;
        const hasta = document.getElementById('ConvertToCurrency')?.value;

        if (monto <= 0) {
            Swal.fire({ icon: 'warning', title: 'Monto invalido', text: 'Ingrese un monto mayor a cero' });
            return;
        }

        fetch(`${_config.urls.convertirMoneda}?monto=${monto}&desde=${desde}&hasta=${hasta}`)
            .then(async response => {
                const data = await handleApiResponse(response, 'Error de conversión');
                if (data) {
                    const resultDiv = document.getElementById('ConvertResult');
                    const resultValue = document.getElementById('ConvertResultValue');
                    if (resultDiv && resultValue) {
                        resultDiv.classList.remove('hidden');
                        resultValue.textContent = formatearMoneda(data.resultado);
                    }
                }
            });
    }

    // ========== BUSQUEDA DE CUENTA ==========

    function buscarCuenta(input) {
        const codigo = input.value;
        const row = input.closest('tr');
        if (!codigo || codigo.length < 3) return;

        fetch(`${_config.urls.buscarCuenta}?codigo=${encodeURIComponent(codigo)}`)
            .then(async response => {
                const data = await handleApiResponse(response);
                if (data) {
                    if (data.encontrada) {
                        const idCuentaInput = row.querySelector('input[name$=".IdCuenta"]');
                        const nombreSpan = row.querySelector('.cuenta-nombre');

                        if (idCuentaInput) idCuentaInput.value = data.idCuenta;
                        if (nombreSpan) nombreSpan.textContent = data.nombre;

                        input.classList.remove('border-red-500');
                        input.classList.add('border-green-500');
                    } else {
                        input.classList.remove('border-green-500');
                        input.classList.add('border-red-500');

                        const nombreSpan = row.querySelector('.cuenta-nombre');
                        if (nombreSpan) nombreSpan.textContent = 'Cuenta no encontrada';
                    }
                }
            });
    }

    // ========== ACCIONES HERRAMIENTAS ==========

    function limpiarFormulario() {
        Swal.fire({
            title: 'Limpiar formulario?',
            text: 'Se perderan todos los datos no guardados',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Si, limpiar'
        }).then(result => {
            if (result.isConfirmed) {
                document.getElementById('frmComprobante')?.reset();
                document.getElementById('movimientosTableBody').innerHTML = '';
                calcularTotales();
                actualizarEstadoVacio();
            }
        });
    }

    function imprimir() {
        if (!_config.idComp) return;
        window.open(`${_config.urls.imprimir}?id=${_config.idComp}`, '_blank');
    }

    function exportarExcel() {
        if (!_config.idComp) return;
        window.location.href = `${_config.urls.exportarExcel}?id=${_config.idComp}`;
    }

    function vistaPrevia() {
        if (!_config.idComp) return;
        window.open(`${_config.urls.vistaPrevia}?id=${_config.idComp}`, '_blank');
    }

    function abrirPlanCuentas() {
        window.open(_config.urls.planCuentas, '_blank');
    }

    function abrirPlantillas() {
        window.open(_config.urls.plantillas, '_blank');
    }

    function abrirGlosas() {
        // TODO: Implementar modal de glosas frecuentes
        Swal.fire({ icon: 'info', title: 'Glosas', text: 'Funcionalidad en desarrollo' });
    }

    function nuevoDocumento() {
        if (_selectedRowIndex < 0) {
            Swal.fire({ icon: 'warning', title: 'Seleccione un movimiento', text: 'Primero seleccione el movimiento al que asociar el documento' });
            return;
        }
        nuevoDocumentoFila(_selectedRowIndex);
    }

    function quitarDocumento() {
        if (_selectedRowIndex < 0) {
            Swal.fire({ icon: 'warning', title: 'Seleccione un movimiento' });
            return;
        }

        const row = document.querySelector(`tr[data-index="${_selectedRowIndex}"]`);
        if (row) {
            const idDocInput = row.querySelector('input[name$=".IdDoc"]');
            const tipoDocSpan = row.querySelector('.tipo-doc');
            const numDocSpan = row.querySelector('.num-doc');
            const entidadSpan = row.querySelector('.entidad-nombre');

            if (idDocInput) idDocInput.value = '';
            if (tipoDocSpan) tipoDocSpan.textContent = '';
            if (numDocSpan) numDocSpan.textContent = '';
            if (entidadSpan) entidadSpan.textContent = '';
        }
    }

    function verDetalle() {
        if (_selectedRowIndex < 0) {
            Swal.fire({ icon: 'warning', title: 'Seleccione un movimiento' });
            return;
        }
        // TODO: Modal con detalle del movimiento
        Swal.fire({ icon: 'info', title: 'Detalle', text: `Movimiento #${_selectedRowIndex + 1}` });
    }

    function gestionarActivoFijo() {
        if (_selectedRowIndex < 0) {
            Swal.fire({ icon: 'warning', title: 'Seleccione un movimiento' });
            return;
        }
        window.open(`${_config.urls.activoFijo}?indexMov=${_selectedRowIndex}`, '_blank');
    }

    function marcarCentralizacion() {
        Swal.fire({ icon: 'info', title: 'Centralizacion', text: 'Funcionalidad en desarrollo' });
    }

    function generarCheque() {
        const beneficiario = document.getElementById('ChequeBeneficiario')?.value;
        if (!beneficiario) {
            Swal.fire({ icon: 'warning', title: 'Beneficiario requerido' });
            return;
        }

        const data = {
            beneficiario: beneficiario,
            numero: document.getElementById('ChequeNumero')?.value,
            banco: document.getElementById('ChequeBanco')?.value,
            cuenta: document.getElementById('ChequeCuenta')?.value
        };

        // TODO: Generar PDF de cheque
        closeModal('modalChequeConfig');
        Swal.fire({ icon: 'success', title: 'Cheque generado', text: `Beneficiario: ${beneficiario}` });
    }

    // ========== BUSQUEDAS EN MODALES ==========

    function buscarComprobante() {
        const tipo = document.getElementById('FindVoucherTipo')?.value;
        const correlativo = document.getElementById('FindVoucherCorrelativo')?.value;
        const fecha = document.getElementById('FindVoucherFecha')?.value;

        const params = new URLSearchParams();
        if (tipo) params.append('tipo', tipo);
        if (correlativo) params.append('correlativo', correlativo);
        if (fecha) params.append('fecha', fecha);

        fetch(`${_config.urls.buscarComprobante}?${params}`)
            .then(async response => {
                const data = await handleApiResponse(response);
                if (data) {
                    if (data.encontrado) {
                        closeModal('modalFindVoucher');
                        window.location.href = `${_config.urls.index}?id=${data.id}&mode=view`;
                    } else {
                        Swal.fire({ icon: 'warning', title: 'No encontrado', text: 'No se encontro ningun comprobante con esos criterios' });
                    }
                }
            });
    }

    // ========== BUSQUEDA DE DOCUMENTOS ==========

    let _searchDocSelectedDoc = null;

    function buscarDocumentos() {
        // Limpiar estado previo
        _searchDocSelectedDoc = null;
        document.getElementById('searchDocRowIndex').value = '-1';
        document.getElementById('searchDocSelectedId').value = '';
        document.getElementById('btnSeleccionarDocumento').disabled = true;
        document.getElementById('searchDocPreview').classList.add('hidden');
        document.getElementById('searchDocTableBody').innerHTML = '';
        document.getElementById('searchDocInitial').classList.remove('hidden');
        document.getElementById('searchDocLoading').classList.add('hidden');
        document.getElementById('searchDocNoResults').classList.add('hidden');

        // Limpiar filtros
        document.getElementById('searchDocTipoLib').value = '';
        document.getElementById('searchDocEstado').value = '';
        document.getElementById('searchDocNumero').value = '';
        document.getElementById('searchDocEntidad').value = '';

        // Abrir modal
        openModal('modalSearchDocument');
    }

    function ejecutarBusquedaDocumentos() {
        const tipoLib = document.getElementById('searchDocTipoLib').value;
        const estado = document.getElementById('searchDocEstado').value;
        const numDoc = document.getElementById('searchDocNumero').value;
        const entidad = document.getElementById('searchDocEntidad').value;

        // Mostrar loading
        document.getElementById('searchDocInitial').classList.add('hidden');
        document.getElementById('searchDocNoResults').classList.add('hidden');
        document.getElementById('searchDocLoading').classList.remove('hidden');
        document.getElementById('searchDocTableBody').innerHTML = '';

        // Construir URL con parámetros - empresaId es requerido
        const params = new URLSearchParams();
        params.append('empresaId', _config.empresaId);
        if (tipoLib) params.append('searchDto.TipoLib', tipoLib);
        if (estado) params.append('searchDto.Estado', estado);
        if (numDoc) params.append('searchDto.NumDoc', numDoc);
        if (entidad) params.append('searchDto.Entidad', entidad);

        fetch(`${_config.urls.searchDocuments}?${params.toString()}`)
            .then(async response => {
                document.getElementById('searchDocLoading').classList.add('hidden');
                const data = await handleApiResponse(response);
                if (data) {
                    if (!data || data.length === 0) {
                        document.getElementById('searchDocNoResults').classList.remove('hidden');
                        return;
                    }
                    renderDocumentosTable(data);
                } else {
                    document.getElementById('searchDocNoResults').classList.remove('hidden');
                }
            });
    }

    function renderDocumentosTable(documentos) {
        const tbody = document.getElementById('searchDocTableBody');
        tbody.innerHTML = '';

        const tiposLibro = { 1: 'Compra', 2: 'Venta', 3: 'Honorarios', 4: 'Boleta' };

        documentos.forEach((doc, index) => {
            const tr = document.createElement('tr');
            tr.setAttribute('data-index', index);
            tr.setAttribute('data-id', doc.idDoc);

            // Formatear fecha
            let fechaStr = '-';
            if (doc.fechaEmision) {
                const fecha = new Date(doc.fechaEmision);
                fechaStr = fecha.toLocaleDateString('es-CL');
            }

            // Formatear monto
            const monto = formatearMoneda(doc.total || 0);

            // Estado badge
            let estadoBadge = '<span class="doc-estado-badge doc-estado-pendiente">Pendiente</span>';
            if (doc.saldoDoc === 0 || doc.saldoDoc === null) {
                estadoBadge = '<span class="doc-estado-badge doc-estado-pagado">Pagado</span>';
            }

            tr.innerHTML = `
                <td class="text-gray-600">${tiposLibro[doc.tipoLib] || doc.tipoLib || '-'}</td>
                <td class="font-medium text-gray-900">${doc.numDoc || '-'}</td>
                <td class="text-gray-600">${fechaStr}</td>
                <td class="text-gray-600">${doc.nombreEntidad || doc.rutEntidad || '-'}</td>
                <td class="text-right font-mono text-gray-900">${monto}</td>
                <td class="text-center">${estadoBadge}</td>
            `;

            tr.onclick = () => seleccionarDocumentoTabla(index, doc);
            tr.ondblclick = () => {
                seleccionarDocumentoTabla(index, doc);
                seleccionarDocumento();
            };

            tbody.appendChild(tr);
        });
    }

    function seleccionarDocumentoTabla(index, doc) {
        // Quitar selección anterior
        document.querySelectorAll('#searchDocTableBody tr').forEach(tr => {
            tr.classList.remove('selected');
        });

        // Marcar nuevo seleccionado
        const row = document.querySelector(`#searchDocTableBody tr[data-index="${index}"]`);
        if (row) {
            row.classList.add('selected');
        }

        // Guardar datos
        _searchDocSelectedDoc = doc;
        document.getElementById('searchDocSelectedId').value = doc.idDoc;
        document.getElementById('btnSeleccionarDocumento').disabled = false;

        // Mostrar preview
        const preview = document.getElementById('searchDocPreview');
        const previewText = document.getElementById('searchDocPreviewText');
        previewText.textContent = `${doc.numDoc || '-'} - ${doc.nombreEntidad || doc.rutEntidad || '-'} - ${formatearMoneda(doc.total || 0)}`;
        preview.classList.remove('hidden');
    }

    function seleccionarDocumento() {
        if (!_searchDocSelectedDoc) return;

        const rowIndex = document.getElementById('searchDocRowIndex').value;

        // Asociar documento al movimiento
        asociarDocumentoAMovimiento(rowIndex, _searchDocSelectedDoc);

        // Cerrar modal
        closeModal('modalSearchDocument');
    }

    function asociarDocumentoAMovimiento(rowIndex, doc) {
        // Si rowIndex es -1, usar la fila seleccionada actual
        if (rowIndex === '-1' || rowIndex === -1) {
            const selectedRow = document.querySelector('#movimientosTableBody tr.selected');
            if (selectedRow) {
                rowIndex = selectedRow.getAttribute('data-index');
            }
        }

        if (!rowIndex || rowIndex === '-1') {
            Swal.fire({ icon: 'warning', title: 'Sin selección', text: 'Seleccione primero un movimiento' });
            return;
        }

        const row = document.querySelector(`#movimientosTableBody tr[data-index="${rowIndex}"]`);
        if (!row) return;

        // Actualizar campos ocultos
        const idDocInput = row.querySelector('input[name$=".IdDoc"]');
        const idEntidadInput = row.querySelector('input[name$=".IdEntidad"]');

        if (idDocInput) idDocInput.value = doc.idDoc;
        if (idEntidadInput) idEntidadInput.value = doc.idEntidad || '';

        // Actualizar campos visibles
        const tipoDocSpan = row.querySelector('.tipo-doc');
        const numDocSpan = row.querySelector('.num-doc');
        const entidadSpan = row.querySelector('.entidad-nombre');

        const tiposLibro = { 1: 'C', 2: 'V', 3: 'H', 4: 'B' };

        if (tipoDocSpan) tipoDocSpan.textContent = tiposLibro[doc.tipoLib] || '';
        if (numDocSpan) numDocSpan.textContent = doc.numDoc || '';
        if (entidadSpan) entidadSpan.textContent = doc.nombreEntidad || doc.rutEntidad || '';

        // Traspasar monto sugerido del documento al movimiento (solo si Debe = 0 y Haber = 0)
        // Los montos sugeridos vienen calculados desde el backend
        const debeInput = row.querySelector('input[name$=".Debe"]');
        const haberInput = row.querySelector('input[name$=".Haber"]');

        if (debeInput && haberInput) {
            const debeActual = parseFloat(debeInput.value) || 0;
            const haberActual = parseFloat(haberInput.value) || 0;

            // Solo traspasar si ambos están en 0
            if (debeActual === 0 && haberActual === 0) {
                // Usar montos sugeridos del backend
                if (doc.montoSugeridoHaber && doc.montoSugeridoHaber > 0) {
                    haberInput.value = doc.montoSugeridoHaber.toFixed(2);
                    haberInput.dispatchEvent(new Event('change', { bubbles: true }));
                } else if (doc.montoSugeridoDebe && doc.montoSugeridoDebe > 0) {
                    debeInput.value = doc.montoSugeridoDebe.toFixed(2);
                    debeInput.dispatchEvent(new Event('change', { bubbles: true }));
                }

                // Recalcular totales
                calcularTotales();
            }
        }

        Swal.fire({ icon: 'success', title: 'Documento asociado', timer: 1500, showConfirmButton: false });
    }

    function buscarDocumentosPago() {
        // TODO: Implementar busqueda para generar pago
        Swal.fire({ icon: 'info', title: 'Busqueda', text: 'Buscando documentos pendientes...' });
    }

    function guardarPlantilla() {
        const nombre = document.getElementById('TemplateName')?.value;
        if (!nombre) {
            Swal.fire({ icon: 'warning', title: 'Nombre requerido', text: 'Ingrese un nombre para la plantilla' });
            return;
        }

        fetch(_config.urls.guardarPlantilla, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nombre: nombre, idComp: _config.idComp })
        })
        .then(async response => {
            const data = await handleApiResponse(response);
            if (data && data.success) {
                closeModal('modalSaveTemplate');
                Swal.fire({ icon: 'success', title: 'Plantilla guardada', text: `Se guardo como "${nombre}"` });
            }
        });
    }

    // ========== SELECTOR DE CUENTA (MODAL CON TABLA FILTRABLE) ==========

    let _selectorCuentaData = [];          // Datos de todas las cuentas
    let _selectorCuentaFiltered = [];      // Datos filtrados
    let _selectorCuentaSelected = null;    // Cuenta seleccionada
    let _selectorSearchTimeout = null;
    let _selectorCuentaLoaded = false;

    function abrirSelectorCuenta(rowIndex) {
        // Guardar el indice de la fila para saber donde poner la cuenta seleccionada
        document.getElementById('selectorCuentaRowIndex').value = rowIndex;

        // Resetear estado de seleccion
        _selectorCuentaSelected = null;
        document.getElementById('selectorCuentaSearch').value = '';
        document.getElementById('selectorCuentaPreview').classList.add('hidden');
        document.getElementById('btnConfirmarCuenta').disabled = true;
        document.getElementById('selectorCuentaResultCount').textContent = '';

        // Mostrar modal
        openModal('modalSelectorCuenta');

        // Poner foco en el input de búsqueda
        setTimeout(() => {
            document.getElementById('selectorCuentaSearch').focus();
        }, 100);

        // Cargar datos si no estan cargados
        if (!_selectorCuentaLoaded) {
            cargarTodasLasCuentas();
        } else {
            // Si ya estan cargados, mostrar todos
            _selectorCuentaFiltered = [..._selectorCuentaData];
            renderizarTablaCuentas();
        }

        // Configurar busqueda en tiempo real
        configurarBusquedaSelectorCuenta();
    }

    async function cargarTodasLasCuentas() {
        const loading = document.getElementById('selectorCuentaLoading');
        const table = document.getElementById('selectorCuentaTable');
        const empty = document.getElementById('selectorCuentaEmpty');
        const resultCount = document.getElementById('selectorCuentaResultCount');

        // Mostrar loading
        loading.classList.remove('hidden');
        table.classList.add('hidden');
        empty.classList.add('hidden');

        try {
            const response = await fetch(`${_config.urls.getAllCuentas}?empresaId=${_config.empresaId}&ano=${_config.ano}`);

            if (!response.ok) {
                throw new Error('Error al cargar cuentas');
            }

            const data = await response.json();

            // Normalizar datos (soportar PascalCase y camelCase)
            _selectorCuentaData = data.map(item => ({
                id: item.Id ?? item.id,
                codigo: item.Codigo ?? item.codigo,
                descripcion: item.Descripcion ?? item.descripcion,
                level: item.Level ?? item.level ?? 1,
                hasChildren: item.HasChildren ?? item.hasChildren ?? false,
                isLastLevel: item.IsLastLevel ?? item.isLastLevel ?? true
            }));

            _selectorCuentaLoaded = true;
            _selectorCuentaFiltered = [..._selectorCuentaData];

            loading.classList.add('hidden');

            if (_selectorCuentaData.length === 0) {
                empty.classList.remove('hidden');
            } else {
                table.classList.remove('hidden');
                resultCount.textContent = `${_selectorCuentaData.length} cuentas`;
                renderizarTablaCuentas();
            }

        } catch (err) {
            console.error('Error cargando cuentas:', err);
            loading.classList.add('hidden');
            Swal.fire({ icon: 'error', title: 'Error', text: 'No se pudieron cargar las cuentas' });
        }
    }

    function renderizarTablaCuentas(searchTerm = '') {
        const tbody = document.getElementById('selectorCuentaTableBody');
        const table = document.getElementById('selectorCuentaTable');
        const noResults = document.getElementById('selectorCuentaNoResults');

        if (_selectorCuentaFiltered.length === 0) {
            tbody.innerHTML = '';
            table.classList.add('hidden');
            noResults.classList.remove('hidden');
            return;
        }

        table.classList.remove('hidden');
        noResults.classList.add('hidden');

        // Generar filas HTML - diseño minimalista
        let html = '';
        _selectorCuentaFiltered.forEach((cuenta, idx) => {
            const level = cuenta.level || 1;
            const nivelClass = `cuenta-nivel-${Math.min(level, 8)}`;
            const isLastLevel = cuenta.isLastLevel ? 'true' : 'false';

            // Resaltar coincidencias de busqueda
            let codigoDisplay = escapeHtml(cuenta.codigo);
            let descripcionDisplay = escapeHtml(cuenta.descripcion);

            if (searchTerm) {
                codigoDisplay = resaltarCoincidencia(cuenta.codigo, searchTerm);
                descripcionDisplay = resaltarCoincidencia(cuenta.descripcion, searchTerm);
            }

            html += `
                <tr data-cuenta-idx="${idx}"
                    data-cuenta-id="${cuenta.id}"
                    data-cuenta-codigo="${escapeHtml(cuenta.codigo)}"
                    data-cuenta-descripcion="${escapeHtml(cuenta.descripcion)}"
                    data-is-last="${isLastLevel}"
                    class="${nivelClass}"
                    onclick="NuevoComprobante.seleccionarCuentaTabla(${idx})"
                    ondblclick="NuevoComprobante.seleccionarCuentaTabla(${idx}); NuevoComprobante.confirmarSeleccionCuenta();">
                    <td>${codigoDisplay}</td>
                    <td>${descripcionDisplay}</td>
                </tr>
            `;
        });

        tbody.innerHTML = html;
    }

    function escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    function resaltarCoincidencia(text, searchTerm) {
        if (!text || !searchTerm) return escapeHtml(text);

        const escaped = escapeHtml(text);
        const searchEscaped = escapeHtml(searchTerm);
        const regex = new RegExp(`(${searchEscaped.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
        return escaped.replace(regex, '<span class="search-match">$1</span>');
    }

    function seleccionarCuentaTabla(idx) {
        // Quitar seleccion anterior
        document.querySelectorAll('#selectorCuentaTableBody tr.selected').forEach(tr => {
            tr.classList.remove('selected');
        });

        // Seleccionar nueva fila
        const row = document.querySelector(`#selectorCuentaTableBody tr[data-cuenta-idx="${idx}"]`);
        if (row) {
            row.classList.add('selected');
            _selectorCuentaSelected = _selectorCuentaFiltered[idx];
            actualizarPreviewCuenta();
        }
    }

    function configurarBusquedaSelectorCuenta() {
        const searchInput = document.getElementById('selectorCuentaSearch');

        // Remover listeners anteriores y agregar nuevo
        const newInput = searchInput.cloneNode(true);
        searchInput.parentNode.replaceChild(newInput, searchInput);

        newInput.addEventListener('input', function(e) {
            const searchTerm = e.target.value.trim();

            if (_selectorSearchTimeout) {
                clearTimeout(_selectorSearchTimeout);
            }

            // Filtrar inmediatamente para mejor UX
            _selectorSearchTimeout = setTimeout(() => {
                filtrarCuentas(searchTerm);
            }, 150);
        });
    }

    function filtrarCuentas(searchTerm) {
        const resultCount = document.getElementById('selectorCuentaResultCount');

        if (!searchTerm) {
            _selectorCuentaFiltered = [..._selectorCuentaData];
            resultCount.textContent = `${_selectorCuentaData.length} cuentas`;
        } else {
            const searchUpper = searchTerm.toUpperCase();
            _selectorCuentaFiltered = _selectorCuentaData.filter(cuenta => {
                const codigo = (cuenta.codigo || '').toUpperCase();
                const descripcion = (cuenta.descripcion || '').toUpperCase();
                return codigo.includes(searchUpper) || descripcion.includes(searchUpper);
            });
            resultCount.textContent = `${_selectorCuentaFiltered.length} de ${_selectorCuentaData.length}`;
        }

        // Limpiar seleccion al filtrar
        _selectorCuentaSelected = null;
        document.getElementById('selectorCuentaPreview').classList.add('hidden');
        document.getElementById('btnConfirmarCuenta').disabled = true;

        renderizarTablaCuentas(searchTerm);
    }

    function actualizarPreviewCuenta() {
        const preview = document.getElementById('selectorCuentaPreview');
        const previewText = document.getElementById('selectorCuentaPreviewText');
        const btnConfirmar = document.getElementById('btnConfirmarCuenta');

        if (_selectorCuentaSelected) {
            preview.classList.remove('hidden');
            previewText.textContent = `${_selectorCuentaSelected.codigo} - ${_selectorCuentaSelected.descripcion}`;
            btnConfirmar.disabled = false;
        } else {
            preview.classList.add('hidden');
            previewText.textContent = '';
            btnConfirmar.disabled = true;
        }
    }

    function confirmarSeleccionCuenta() {
        if (!_selectorCuentaSelected) {
            Swal.fire({ icon: 'warning', title: 'Seleccione una cuenta', text: 'Debe seleccionar una cuenta de la lista' });
            return;
        }

        const rowIndex = document.getElementById('selectorCuentaRowIndex').value;
        const row = document.querySelector(`tr[data-index="${rowIndex}"]`);

        if (!row) {
            Swal.fire({ icon: 'error', title: 'Error', text: 'No se encontro la fila del movimiento' });
            return;
        }

        const codigo = _selectorCuentaSelected.codigo;
        const accountId = _selectorCuentaSelected.id;
        const descripcion = _selectorCuentaSelected.descripcion;

        // Actualizar el input de codigo
        const codigoInput = row.querySelector('input[name$=".CodigoCuenta"]');
        if (codigoInput) {
            codigoInput.value = codigo;
            codigoInput.classList.remove('border-red-500');
            codigoInput.classList.add('border-green-500');
        }

        // Actualizar el hidden del IdCuenta
        const idCuentaInput = row.querySelector('input[name$=".IdCuenta"]');
        if (idCuentaInput) {
            idCuentaInput.value = accountId;
        }

        // Actualizar el nombre de la cuenta (celda nombre-cuenta o cuenta-nombre)
        const nombreCuentaCell = row.querySelector('.nombre-cuenta, .cuenta-nombre');
        if (nombreCuentaCell) {
            nombreCuentaCell.textContent = descripcion;
        }

        // Cerrar modal
        closeModal('modalSelectorCuenta');

        // Resetear estado
        _selectorCuentaSelected = null;
    }

    // ========== AUTOCOMPLETE DE CUENTAS EN INPUT ==========

    let _autocompleteTimeout = null;

    function filtrarCuentasAutocomplete(input) {
        const searchTerm = input.value.trim();
        const rowIndex = input.getAttribute('data-row-index');
        const dropdown = input.parentElement.querySelector('.cuenta-autocomplete-dropdown');

        if (_autocompleteTimeout) {
            clearTimeout(_autocompleteTimeout);
        }

        if (!searchTerm || searchTerm.length < 2) {
            dropdown.classList.add('hidden');
            return;
        }

        // Esperar 150ms antes de filtrar
        _autocompleteTimeout = setTimeout(() => {
            renderizarAutocomplete(input, searchTerm);
        }, 150);
    }

    function renderizarAutocomplete(input, searchTerm) {
        const dropdown = input.parentElement.querySelector('.cuenta-autocomplete-dropdown');

        // Si no hay datos cargados, cargarlos primero
        if (!_selectorCuentaLoaded || _selectorCuentaData.length === 0) {
            dropdown.innerHTML = '<div class="px-3 py-2 text-sm text-gray-500">Cargando cuentas...</div>';
            dropdown.classList.remove('hidden');

            // Cargar datos
            fetch(`${_config.urls.getAllCuentas}?empresaId=${_config.empresaId}&ano=${_config.ano}`)
                .then(response => response.json())
                .then(data => {
                    _selectorCuentaData = data.map(item => ({
                        id: item.Id ?? item.id,
                        codigo: item.Codigo ?? item.codigo,
                        descripcion: item.Descripcion ?? item.descripcion,
                        level: item.Level ?? item.level ?? 1,
                        hasChildren: item.HasChildren ?? item.hasChildren ?? false,
                        isLastLevel: item.IsLastLevel ?? item.isLastLevel ?? true
                    }));
                    _selectorCuentaLoaded = true;
                    mostrarResultadosAutocomplete(dropdown, searchTerm, input);
                })
                .catch(err => {
                    console.error('Error cargando cuentas:', err);
                    dropdown.innerHTML = '<div class="px-3 py-2 text-sm text-red-500">Error al cargar</div>';
                });
            return;
        }

        mostrarResultadosAutocomplete(dropdown, searchTerm, input);
    }

    function mostrarResultadosAutocomplete(dropdown, searchTerm, input) {
        const searchUpper = searchTerm.toUpperCase();

        // Filtrar cuentas que coincidan
        const matches = _selectorCuentaData.filter(cuenta => {
            const codigo = (cuenta.codigo || '').toUpperCase();
            const descripcion = (cuenta.descripcion || '').toUpperCase();
            return codigo.includes(searchUpper) || descripcion.includes(searchUpper);
        }).slice(0, 15); // Limitar a 15 resultados

        if (matches.length === 0) {
            dropdown.innerHTML = '<div class="px-3 py-2 text-sm text-gray-500">No se encontraron cuentas</div>';
            dropdown.classList.remove('hidden');
            return;
        }

        // Generar HTML
        let html = '';
        matches.forEach((cuenta, idx) => {
            const codigoHighlight = resaltarCoincidencia(cuenta.codigo, searchTerm);
            const descripcionHighlight = resaltarCoincidencia(cuenta.descripcion, searchTerm);
            const icon = cuenta.hasChildren ? 'fa-folder text-amber-500' : 'fa-file-alt text-blue-500';

            html += `
                <div class="autocomplete-item px-3 py-2 hover:bg-primary-50 cursor-pointer flex items-center gap-2 border-b border-gray-100 last:border-0"
                     data-cuenta-id="${cuenta.id}"
                     data-cuenta-codigo="${escapeHtml(cuenta.codigo)}"
                     data-cuenta-descripcion="${escapeHtml(cuenta.descripcion)}"
                     onmousedown="NuevoComprobante.seleccionarCuentaAutocomplete(this, '${input.getAttribute('data-row-index')}')">
                    <i class="fas ${icon} text-xs flex-shrink-0"></i>
                    <span class="font-mono text-sm">${codigoHighlight}</span>
                    <span class="text-gray-400 mx-1">-</span>
                    <span class="text-sm text-gray-700 truncate">${descripcionHighlight}</span>
                </div>
            `;
        });

        if (matches.length === 15) {
            html += '<div class="px-3 py-2 text-xs text-gray-400 text-center bg-gray-50">Mostrando primeros 15 resultados...</div>';
        }

        dropdown.innerHTML = html;
        dropdown.classList.remove('hidden');
    }

    function seleccionarCuentaAutocomplete(item, rowIndex) {
        const row = document.querySelector(`tr[data-index="${rowIndex}"]`);
        if (!row) return;

        const codigo = item.getAttribute('data-cuenta-codigo');
        const id = item.getAttribute('data-cuenta-id');
        const descripcion = item.getAttribute('data-cuenta-descripcion');

        // Actualizar input de codigo
        const codigoInput = row.querySelector('input[name$=".CodigoCuenta"]');
        if (codigoInput) {
            codigoInput.value = codigo;
            codigoInput.classList.remove('border-red-500');
            codigoInput.classList.add('border-green-500');
        }

        // Actualizar hidden de IdCuenta
        const idCuentaInput = row.querySelector('input[name$=".IdCuenta"]');
        if (idCuentaInput) {
            idCuentaInput.value = id;
        }

        // Actualizar nombre de cuenta
        const nombreSpan = row.querySelector('.cuenta-nombre');
        if (nombreSpan) {
            nombreSpan.textContent = descripcion;
        }

        // Ocultar dropdown
        const dropdown = row.querySelector('.cuenta-autocomplete-dropdown');
        if (dropdown) {
            dropdown.classList.add('hidden');
        }
    }

    function mostrarAutocomplete(input) {
        const searchTerm = input.value.trim();
        if (searchTerm.length >= 2) {
            renderizarAutocomplete(input, searchTerm);
        }
    }

    function ocultarAutocomplete(input) {
        const dropdown = input.parentElement.querySelector('.cuenta-autocomplete-dropdown');
        if (dropdown) {
            dropdown.classList.add('hidden');
        }
    }

    /* ========== CODIGO JSTREE COMENTADO (por si se quiere volver a usar) ==========
    let _selectorCuentaTree = null;
    let _selectorCuentaSelectedNode = null;

    function inicializarSelectorCuentaTree() {
        const treeContainer = document.getElementById('selectorCuentaTree');
        const loading = document.getElementById('selectorCuentaLoading');
        const empty = document.getElementById('selectorCuentaEmpty');

        loading.classList.remove('hidden');
        treeContainer.innerHTML = '';

        $('#selectorCuentaTree').jstree({
            'core': {
                'data': {
                    'url': function(node) {
                        if (node.id === '#') {
                            return `${_config.urls.getPlanCuentasTreeRoot}?empresaId=${_config.empresaId}&ano=${_config.ano}`;
                        } else {
                            const accountId = node.data ? node.data.accountId : (node.original ? node.original.accountId : null);
                            const level = node.data ? node.data.level : (node.original ? node.original.level : null);
                            return `${_config.urls.getPlanCuentasTreeChildren}?empresaId=${_config.empresaId}&ano=${_config.ano}&parentId=${accountId}&parentLevel=${level}`;
                        }
                    },
                    'dataType': 'json',
                    'dataFilter': function(data) {
                        const jsonData = JSON.parse(data);
                        const transformed = jsonData.map(item => {
                            const accountId = item.Id ?? item.id;
                            const codigo = item.Codigo ?? item.codigo;
                            const descripcion = item.Descripcion ?? item.descripcion;
                            const isLastLevel = item.IsLastLevel ?? item.isLastLevel;
                            return {
                                'id': `selector_node_${accountId}`,
                                'text': `${codigo} - ${descripcion}`,
                                'children': item.HasChildren ?? item.hasChildren ?? false,
                                'icon': isLastLevel ? 'jstree-file' : 'jstree-folder',
                                'data': { accountId, codigo, descripcion, level: item.Level ?? item.level, isLastLevel }
                            };
                        });
                        return JSON.stringify(transformed);
                    }
                },
                'check_callback': true,
                'themes': { 'name': 'default', 'responsive': true, 'dots': true, 'icons': true }
            },
            'plugins': ['search'],
            'search': { 'case_sensitive': false, 'show_only_matches': true }
        }).on('ready.jstree', function() {
            loading.classList.add('hidden');
            _selectorCuentaTree = $('#selectorCuentaTree').jstree(true);
        }).on('select_node.jstree', function(e, data) {
            _selectorCuentaSelectedNode = data.node;
            actualizarPreviewCuenta();
        });
    }
    ========== FIN CODIGO JSTREE COMENTADO ========== */

    // ========== MENU DROPDOWN ==========

    function toggleMenuMas() {
        const dropdown = document.getElementById('dropdownMasAcciones');
        if (dropdown) {
            dropdown.classList.toggle('hidden');
        }
    }

    // ========== DROPDOWN DE FILA ==========

    function toggleRowDropdown(index, buttonEl) {
        // Cerrar todos los otros dropdowns primero
        document.querySelectorAll('[id^="rowDropdown-"]').forEach(dd => {
            if (dd.id !== `rowDropdown-${index}`) {
                dd.classList.add('hidden');
            }
        });

        const dropdown = document.getElementById(`rowDropdown-${index}`);
        if (dropdown) {
            const isHidden = dropdown.classList.contains('hidden');

            if (isHidden && buttonEl) {
                // Posicionar el dropdown usando position fixed
                const rect = buttonEl.getBoundingClientRect();
                const dropdownHeight = 320; // Altura aproximada del dropdown
                const viewportHeight = window.innerHeight;

                // Calcular si hay espacio abajo o debe abrir hacia arriba
                const spaceBelow = viewportHeight - rect.bottom;
                const spaceAbove = rect.top;

                dropdown.style.left = (rect.right - 192) + 'px'; // 192 = w-48 (12rem)

                if (spaceBelow >= dropdownHeight || spaceBelow >= spaceAbove) {
                    // Abrir hacia abajo
                    dropdown.style.top = (rect.bottom + 4) + 'px';
                    dropdown.style.bottom = 'auto';
                } else {
                    // Abrir hacia arriba
                    dropdown.style.top = 'auto';
                    dropdown.style.bottom = (viewportHeight - rect.top + 4) + 'px';
                }
            }

            dropdown.classList.toggle('hidden');
        }
    }

    function closeRowDropdown(index) {
        const dropdown = document.getElementById(`rowDropdown-${index}`);
        if (dropdown) {
            dropdown.classList.add('hidden');
        }
    }

    // ========== ACCIONES POR FILA ==========

    function nuevoDocumentoFila(index) {
        // Guardar el índice de la fila para asociar el documento después
        document.getElementById('nuevoDocRowIndex').value = index;

        // Limpiar formulario
        document.getElementById('formNuevoDocumento').reset();
        document.getElementById('nuevoDocTipoDoc').innerHTML = '<option value="">Seleccione tipo libro primero</option>';
        document.getElementById('nuevoDocNombre').value = '';
        document.getElementById('nuevoDocIdEntidad').value = '';

        // Establecer fecha por defecto (hoy)
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('nuevoDocFecha').value = today;

        // Abrir modal
        openModal('modalNuevoDocumento');
    }

    function buscarDocumentoFila(index) {
        // Guardar el índice de fila para usarlo después
        document.getElementById('searchDocRowIndex').value = index;

        // Limpiar estado previo
        _searchDocSelectedDoc = null;
        document.getElementById('searchDocSelectedId').value = '';
        document.getElementById('btnSeleccionarDocumento').disabled = true;
        document.getElementById('searchDocPreview').classList.add('hidden');
        document.getElementById('searchDocTableBody').innerHTML = '';
        document.getElementById('searchDocInitial').classList.remove('hidden');
        document.getElementById('searchDocLoading').classList.add('hidden');
        document.getElementById('searchDocNoResults').classList.add('hidden');

        // Limpiar filtros
        document.getElementById('searchDocTipoLib').value = '';
        document.getElementById('searchDocEstado').value = '';
        document.getElementById('searchDocNumero').value = '';
        document.getElementById('searchDocEntidad').value = '';

        // Abrir modal
        openModal('modalSearchDocument');
    }

    function quitarDocumentoFila(index) {
        const row = document.querySelector(`tr[data-index="${index}"]`);
        if (row) {
            const idDocInput = row.querySelector('input[name$=".IdDoc"]');
            const idEntidadInput = row.querySelector('input[name$=".IdEntidad"]');
            const tipoDocSpan = row.querySelector('.tipo-doc');
            const numDocSpan = row.querySelector('.num-doc');
            const entidadSpan = row.querySelector('.entidad-nombre');

            if (idDocInput) idDocInput.value = '';
            if (idEntidadInput) idEntidadInput.value = '';
            if (tipoDocSpan) tipoDocSpan.textContent = '';
            if (numDocSpan) numDocSpan.textContent = '';
            if (entidadSpan) entidadSpan.textContent = '';

            Swal.fire({ icon: 'success', title: 'Documento quitado', timer: 1000, showConfirmButton: false });
        }
    }

    // ========== MODAL NUEVO DOCUMENTO ==========

    /**
     * Carga tipos de documento cuando cambia el tipo de libro
     */
    async function onNuevoDocTipoLibChange() {
        const tipoLib = document.getElementById('nuevoDocTipoLib').value;
        const tipoDocSelect = document.getElementById('nuevoDocTipoDoc');

        if (!tipoLib) {
            tipoDocSelect.innerHTML = '<option value="">Seleccione tipo libro primero</option>';
            return;
        }

        tipoDocSelect.innerHTML = '<option value="">Cargando...</option>';

        try {
            const response = await fetch(`${_config.urls.getTiposDocumento}?tipoLib=${tipoLib}&empresaId=${_config.empresaId}`);
            const data = await response.json();

            tipoDocSelect.innerHTML = '<option value="">Seleccione...</option>';
            if (Array.isArray(data)) {
                data.forEach(tipo => {
                    const option = document.createElement('option');
                    option.value = tipo.tipoDoc;
                    option.textContent = `${tipo.codigo} - ${tipo.nombre}`;
                    tipoDocSelect.appendChild(option);
                });
            }
        } catch (error) {
            console.error('Error al cargar tipos de documento:', error);
            tipoDocSelect.innerHTML = '<option value="">Error al cargar</option>';
        }
    }

    /**
     * Busca entidad cuando se pierde el foco del campo RUT
     */
    async function buscarEntidadPorRut() {
        const rut = document.getElementById('nuevoDocRut').value.trim();
        const nombreInput = document.getElementById('nuevoDocNombre');
        const idEntidadInput = document.getElementById('nuevoDocIdEntidad');

        if (!rut) {
            nombreInput.value = '';
            idEntidadInput.value = '';
            return;
        }

        try {
            const response = await fetch(`${_config.urls.buscarEntidadPorRut}?rut=${encodeURIComponent(rut)}&empresaId=${_config.empresaId}`);
            const data = await response.json();

            if (data.encontrada && data.entidad) {
                nombreInput.value = data.entidad.nombre;
                idEntidadInput.value = data.entidad.idEntidad;
            } else {
                nombreInput.value = '';
                idEntidadInput.value = '';
                // No mostrar error, podría ser una entidad nueva
            }
        } catch (error) {
            console.error('Error al buscar entidad:', error);
            nombreInput.value = '';
            idEntidadInput.value = '';
        }
    }

    /**
     * Guarda el nuevo documento y lo asocia al movimiento
     */
    async function guardarNuevoDocumento() {
        const form = document.getElementById('formNuevoDocumento');

        // Validar campos requeridos
        const tipoLib = document.getElementById('nuevoDocTipoLib').value;
        const tipoDoc = document.getElementById('nuevoDocTipoDoc').value;
        const numDoc = document.getElementById('nuevoDocNumero').value.trim();
        const fecha = document.getElementById('nuevoDocFecha').value;
        const monto = document.getElementById('nuevoDocMonto').value;

        if (!tipoLib || !tipoDoc || !numDoc || !fecha || !monto) {
            Swal.fire({
                icon: 'warning',
                title: 'Campos requeridos',
                text: 'Complete todos los campos obligatorios'
            });
            return;
        }

        const rowIndex = parseInt(document.getElementById('nuevoDocRowIndex').value);
        if (rowIndex < 0) {
            Swal.fire({ icon: 'error', title: 'Error', text: 'No se pudo determinar el movimiento' });
            return;
        }

        // Preparar datos
        const dto = {
            tipoLib: parseInt(tipoLib),
            tipoDoc: parseInt(tipoDoc),
            numDoc: numDoc,
            fechaEmision: fecha,
            idEntidad: document.getElementById('nuevoDocIdEntidad').value ? parseInt(document.getElementById('nuevoDocIdEntidad').value) : null,
            monto: parseFloat(monto),
            estado: parseInt(document.getElementById('nuevoDocEstado').value) || 1,
            observaciones: document.getElementById('nuevoDocObservaciones').value.trim() || null,
            dte: document.getElementById('nuevoDocDTE').checked
        };

        try {
            // Construir URL con query params requeridos por el backend
            const urlParams = new URLSearchParams({
                empresaId: _config.empresaId,
                ano: _config.ano,
                usuarioId: _config.usuarioId || 0
            });
            const url = `${_config.urls.crearDocumento}?${urlParams.toString()}`;

            const response = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(dto)
            });

            if (!response.ok) {
                throw new Error('Error al crear documento');
            }

            const documento = await response.json();

            // Asociar documento al movimiento
            asociarDocumentoAMovimientoNuevo(rowIndex, documento);

            // Cerrar modal y mostrar éxito
            closeModal('modalNuevoDocumento');
            Swal.fire({
                icon: 'success',
                title: 'Documento creado',
                text: `Documento ${documento.numDoc} creado y asociado correctamente`,
                timer: 2000,
                showConfirmButton: false
            });

        } catch (error) {
            console.error('Error al crear documento:', error);
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'No se pudo crear el documento'
            });
        }
    }

    /**
     * Asocia un documento recién creado al movimiento
     */
    function asociarDocumentoAMovimientoNuevo(rowIndex, doc) {
        const row = document.querySelector(`tr[data-index="${rowIndex}"]`);
        if (!row) return;

        // Actualizar campos ocultos
        const idDocInput = row.querySelector('input[name$=".IdDoc"]');
        const idEntidadInput = row.querySelector('input[name$=".IdEntidad"]');

        if (idDocInput) idDocInput.value = doc.idDoc;
        if (idEntidadInput && doc.idEntidad) idEntidadInput.value = doc.idEntidad;

        // Actualizar visualización
        const tipoDocSpan = row.querySelector('.tipo-doc');
        const numDocSpan = row.querySelector('.num-doc');
        const entidadSpan = row.querySelector('.entidad-nombre');

        // tipoDocNombre puede no venir si usamos DocumentoDto básico
        if (tipoDocSpan) tipoDocSpan.textContent = doc.tipoDocNombre || `T${doc.tipoDoc}`;
        if (numDocSpan) numDocSpan.textContent = doc.numDoc || '';
        if (entidadSpan) entidadSpan.textContent = doc.nombreEntidad || doc.entidadNombre || '';

        // Transferir monto si corresponde (si Debe y Haber están vacíos)
        const debeInput = row.querySelector('input[name$=".Debe"]');
        const haberInput = row.querySelector('input[name$=".Haber"]');

        const debe = parseFloat(debeInput?.value) || 0;
        const haber = parseFloat(haberInput?.value) || 0;

        const docTotal = doc.total || doc.saldoDoc || 0;
        if (debe === 0 && haber === 0 && docTotal > 0) {
            // El monto se asigna según el saldo (para documento nuevo, saldo = monto)
            // Si el saldo es positivo va al Haber, si es negativo va al Debe
            // Para documentos nuevos, el saldo siempre es positivo (igual al monto)
            if (haberInput) {
                haberInput.value = docTotal.toFixed(2);
            }
            calcularTotales();
        }
    }

    /**
     * Gestiona activo fijo para una fila de movimiento
     * VB6: Bt_ActivoFijo_Click() y ActivoFijo()
     * Flujo:
     * 1. Valida que haya cuenta asignada
     * 2. Valida que la cuenta sea de tipo Activo Fijo
     * 3. Si el comprobante no está guardado, advierte al usuario
     * 4. Navega a GestionActivoFijo con los parámetros correctos
     */
    async function gestionarActivoFijoFila(index) {
        const row = document.querySelector(`tr[data-index="${index}"]`);
        if (!row) return;

        // 1. Validar que hay cuenta asignada
        const idCuenta = row.querySelector('input[name$=".IdCuenta"]')?.value;
        if (!idCuenta) {
            Swal.fire({
                icon: 'warning',
                title: 'Sin cuenta',
                text: 'Primero debe asignar una cuenta al movimiento'
            });
            return;
        }

        // 2. Validar que la cuenta sea de Activo Fijo
        try {
            const response = await fetch(`${_config.urls.isCuentaActivoFijo}?idCuenta=${idCuenta}`);
            const data = await response.json();

            if (!data.isActivoFijo) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Cuenta no válida',
                    text: 'La cuenta del movimiento seleccionado no es de Activo Fijo.'
                });
                return;
            }
        } catch (error) {
            console.error('Error al validar cuenta:', error);
            Swal.fire({ icon: 'error', title: 'Error', text: 'No se pudo validar la cuenta' });
            return;
        }

        // 3. Verificar si el comprobante está guardado
        const idMov = row.querySelector('input[name$=".IdMov"]')?.value;

        if (!_config.idComp || _config.idComp === 0 || !idMov || idMov === '0') {
            const result = await Swal.fire({
                icon: 'warning',
                title: 'Comprobante no guardado',
                text: 'Para gestionar Activo Fijo, es necesario guardar primero el comprobante. ¿Desea continuar?',
                showCancelButton: true,
                confirmButtonText: 'Guardar y continuar',
                cancelButtonText: 'Cancelar'
            });

            if (!result.isConfirmed) {
                return;
            }

            // Aquí debería guardarse el comprobante primero
            // Por ahora solo mostramos un mensaje
            Swal.fire({
                icon: 'info',
                title: 'Guarde el comprobante',
                text: 'Por favor guarde el comprobante primero usando el botón Guardar y luego vuelva a intentar.'
            });
            return;
        }

        // 4. Obtener datos del movimiento para pasar a GestionActivoFijo
        const debe = row.querySelector('input[name$=".Debe"]')?.value || '0';
        const haber = row.querySelector('input[name$=".Haber"]')?.value || '0';
        const glosa = row.querySelector('input[name$=".Glosa"]')?.value || '';
        const valorNeto = parseFloat(debe) !== 0 ? debe : haber;

        // 5. Construir URL con parámetros
        // Si ya tiene activo fijo asociado, ir a editar; si no, ir a crear
        const params = new URLSearchParams({
            idComp: _config.idComp,
            idMov: idMov,
            idCuenta: idCuenta,
            valorNeto: valorNeto,
            glosa: glosa,
            fromComprobante: 'true'
        });

        // Navegar a GestionActivoFijo
        window.location.href = `${_config.urls.gestionActivoFijoCreate}?${params.toString()}`;
    }

    function verDetalleFila(index) {
        const row = document.querySelector(`tr[data-index="${index}"]`);
        if (!row) return;

        const codigoCuenta = row.querySelector('input[name$=".CodigoCuenta"]')?.value || '-';
        const nombreCuenta = row.querySelector('.cuenta-nombre')?.textContent || '-';
        const debe = row.querySelector('input[name$=".Debe"]')?.value || '0';
        const haber = row.querySelector('input[name$=".Haber"]')?.value || '0';
        const glosa = row.querySelector('input[name$=".Glosa"]')?.value || '-';
        const tipoDoc = row.querySelector('.tipo-doc')?.textContent || '-';
        const numDoc = row.querySelector('.num-doc')?.textContent || '-';
        const entidad = row.querySelector('.entidad-nombre')?.textContent || '-';

        Swal.fire({
            title: `Movimiento #${index + 1}`,
            html: `
                <div class="text-left text-sm">
                    <div class="grid grid-cols-2 gap-2 mb-3">
                        <div><strong>Cuenta:</strong></div>
                        <div>${codigoCuenta}</div>
                        <div><strong>Nombre:</strong></div>
                        <div>${nombreCuenta}</div>
                        <div><strong>Debe:</strong></div>
                        <div class="font-mono">${formatearMoneda(parseFloat(debe) || 0)}</div>
                        <div><strong>Haber:</strong></div>
                        <div class="font-mono">${formatearMoneda(parseFloat(haber) || 0)}</div>
                        <div><strong>Glosa:</strong></div>
                        <div>${glosa}</div>
                    </div>
                    <div class="border-t pt-2 mt-2">
                        <div class="grid grid-cols-2 gap-2">
                            <div><strong>Tipo Doc:</strong></div>
                            <div>${tipoDoc}</div>
                            <div><strong>N° Doc:</strong></div>
                            <div>${numDoc}</div>
                            <div><strong>Entidad:</strong></div>
                            <div>${entidad}</div>
                        </div>
                    </div>
                </div>
            `,
            icon: 'info',
            confirmButtonText: 'Cerrar'
        });
    }

    // Cerrar dropdown al hacer click fuera
    document.addEventListener('click', function(e) {
        const menu = document.getElementById('menuMasAcciones');
        const dropdown = document.getElementById('dropdownMasAcciones');
        if (menu && dropdown && !menu.contains(e.target)) {
            dropdown.classList.add('hidden');
        }

        // Cerrar dropdowns de filas si el click no es dentro de uno
        const clickedInRowDropdown = e.target.closest('[data-dropdown-row]');
        if (!clickedInRowDropdown) {
            document.querySelectorAll('[id^="rowDropdown-"]').forEach(dd => {
                dd.classList.add('hidden');
            });
        }
    });

    // ========== UTILIDADES ==========

    function actualizarEstadoVacio() {
        const tbody = document.getElementById('movimientosTableBody');
        const countEl = document.getElementById('movimientosCount');

        const rowCount = tbody ? tbody.querySelectorAll('tr[data-index]').length : 0;

        // Actualizar contador
        if (countEl) {
            countEl.textContent = `${rowCount} ${rowCount === 1 ? 'movimiento' : 'movimientos'}`;
        }
    }

    function bindEventos() {
        // Delegacion de eventos para filas dinamicas
        document.getElementById('movimientosTableBody')?.addEventListener('click', function(e) {
            const row = e.target.closest('tr[data-index]');
            if (row) {
                seleccionarFila(parseInt(row.getAttribute('data-index')));
            }
        });

        // Recalcular totales al cambiar valores
        document.getElementById('movimientosTableBody')?.addEventListener('input', function(e) {
            if (e.target.matches('input[name$=".Debe"], input[name$=".Haber"]')) {
                calcularTotales();
            }
        });

        // Busqueda de cuenta al salir del campo
        document.getElementById('movimientosTableBody')?.addEventListener('change', function(e) {
            if (e.target.matches('input[name$=".CodigoCuenta"]')) {
                buscarCuenta(e.target);
            }
        });
    }

    // API publica
    return {
        init: init,
        openModal: openModal,
        closeModal: closeModal,
        agregarMovimiento: agregarMovimiento,
        eliminarMovimiento: eliminarMovimiento,
        eliminarMovimientoFila: eliminarMovimientoFila,
        duplicarMovimiento: duplicarMovimiento,
        duplicarMovimientoFila: duplicarMovimientoFila,
        moverArriba: moverArriba,
        moverAbajo: moverAbajo,
        moverArribaFila: moverArribaFila,
        moverAbajoFila: moverAbajoFila,
        seleccionarFila: seleccionarFila,
        calcularTotales: calcularTotales,
        confirmarCopiarValor: confirmarCopiarValor,
        pegarValor: pegarValor,
        sumarSeleccionados: sumarSeleccionados,
        validarYPrepararComprobante: validarYPrepararComprobante,
        cuadrarAutomatico: cuadrarAutomatico,
        convertirMoneda: convertirMoneda,
        buscarCuenta: buscarCuenta,
        limpiarFormulario: limpiarFormulario,
        imprimir: imprimir,
        exportarExcel: exportarExcel,
        vistaPrevia: vistaPrevia,
        abrirPlanCuentas: abrirPlanCuentas,
        abrirPlantillas: abrirPlantillas,
        abrirGlosas: abrirGlosas,
        nuevoDocumento: nuevoDocumento,
        quitarDocumento: quitarDocumento,
        verDetalle: verDetalle,
        gestionarActivoFijo: gestionarActivoFijo,
        marcarCentralizacion: marcarCentralizacion,
        generarCheque: generarCheque,
        buscarComprobante: buscarComprobante,
        buscarDocumentos: buscarDocumentos,
        ejecutarBusquedaDocumentos: ejecutarBusquedaDocumentos,
        seleccionarDocumentoTabla: seleccionarDocumentoTabla,
        seleccionarDocumento: seleccionarDocumento,
        buscarDocumentosPago: buscarDocumentosPago,
        guardarPlantilla: guardarPlantilla,
        navigateFirst: navigateFirst,
        navigatePrev: navigatePrev,
        navigateNext: navigateNext,
        navigateLast: navigateLast,
        // Selector de cuenta
        abrirSelectorCuenta: abrirSelectorCuenta,
        confirmarSeleccionCuenta: confirmarSeleccionCuenta,
        seleccionarCuentaTabla: seleccionarCuentaTabla,
        // Autocomplete de cuenta
        filtrarCuentasAutocomplete: filtrarCuentasAutocomplete,
        seleccionarCuentaAutocomplete: seleccionarCuentaAutocomplete,
        mostrarAutocomplete: mostrarAutocomplete,
        ocultarAutocomplete: ocultarAutocomplete,
        // Menu dropdown
        toggleMenuMas: toggleMenuMas,
        // Dropdown de fila
        toggleRowDropdown: toggleRowDropdown,
        closeRowDropdown: closeRowDropdown,
        // Acciones por fila
        nuevoDocumentoFila: nuevoDocumentoFila,
        buscarDocumentoFila: buscarDocumentoFila,
        quitarDocumentoFila: quitarDocumentoFila,
        gestionarActivoFijoFila: gestionarActivoFijoFila,
        verDetalleFila: verDetalleFila,
        // Modal nuevo documento
        onNuevoDocTipoLibChange: onNuevoDocTipoLibChange,
        buscarEntidadPorRut: buscarEntidadPorRut,
        guardarNuevoDocumento: guardarNuevoDocumento
    };
})();
