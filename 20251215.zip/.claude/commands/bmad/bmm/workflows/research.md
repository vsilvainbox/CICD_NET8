---
description: 'Conduct comprehensive research across multiple domains using current web data and verified sources - Market, Technical, Domain and other research types.'
---

IT IS CRITICAL THAT YOU FOLLOW THIS COMMAND: LOAD the FULL @.bmad/bmm/workflows/1-analysis/research/workflow.md, READ its entire contents and follow its directions exactly!
