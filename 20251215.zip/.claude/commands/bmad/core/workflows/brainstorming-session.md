---
description: 'Facilitate interactive brainstorming sessions using diverse creative techniques and ideation methods'
---

IT IS CRITICAL THAT YOU FOLLOW THIS COMMAND: LOAD the FULL @.bmad/core/workflows/brainstorming/workflow.md, READ its entire contents and follow its directions exactly!
