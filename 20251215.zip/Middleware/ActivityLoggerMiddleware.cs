using App.Services;
using App.Extensions;
using App.Helpers;
using System.Diagnostics;
using System.Text;

namespace App.Middleware;

/// <summary>
/// Middleware que captura todas las peticiones HTTP y las registra en ActivityLog
/// ✅ Captura: Usuario, IP, URL, Method, Duration, StatusCode, RequestBody
/// ✅ Filtra URLs ruidosas (archivos estáticos, health checks, etc.)
/// </summary>
public class ActivityLoggerMiddleware(
    RequestDelegate next,
    ILogger<ActivityLoggerMiddleware> logger)
{
    // URLs que NO se deben registrar para evitar ruido
    private static readonly string[] ExcludedPaths =
    {
        "/api/DiagnosticoErrorLogApi/log-frontend",  // Ya se registra en ErrorLog
        "/Health",
        "/_framework",
        "/swagger",
        "/favicon.ico",
        "/lib/",
        "/css/",
        "/js/",
        "/images/",
        "/fonts/"
    };

    // URLs donde NO se debe capturar el RequestBody (contienen passwords/datos sensibles)
    private static readonly string[] SensitiveDataPaths =
    {
        "/Auth/Login",
        "/Auth/Register",
        "/Account/Login",
        "/Account/Register",
        "/Account/ChangePassword",
        "/Account/ResetPassword",
        "/Usuario/Create",
        "/Usuario/Edit",
        "/api/Auth",
        "/api/Usuario"
    };

    // Extensiones de archivos estáticos que no se registran
    private static readonly string[] ExcludedExtensions =
    {
        ".css", ".js", ".map", ".png", ".jpg", ".jpeg", ".gif", ".svg",
        ".ico", ".woff", ".woff2", ".ttf", ".eot"
    };

    public async Task InvokeAsync(HttpContext context, IActivityLogService activityLogService)
    {
        // ✅ FILTRO 1: Ignorar archivos estáticos y URLs excluidas
        if (ShouldIgnoreRequest(context.Request))
        {
            await next(context);
            return;
        }

        // ✅ Iniciar cronómetro para medir duración
        var stopwatch = Stopwatch.StartNew();

        // ✅ Capturar request body si es POST/PUT (pero NO si contiene datos sensibles)
        string? requestBody = null;
        if (context.Request.Method == "POST" || context.Request.Method == "PUT")
        {
            // ✅ FILTRO 2: No capturar body si la URL contiene datos sensibles (passwords)
            if (!ContainsSensitiveData(context.Request))
            {
                requestBody = await CaptureRequestBodyAsync(context.Request);
            }
            else
            {
                requestBody = "[SENSITIVE DATA - NOT LOGGED]";
            }
        }

        // ✅ Ejecutar el resto del pipeline
        await next(context);

        // ✅ Detener cronómetro
        stopwatch.Stop();

        // ✅ Capturar información de usuario y empresa desde Claims/Session
        // Usa métodos de extensión que leen correctamente desde Claims (persistente) o Session (rápida)
        int? usuarioId = null;
        int? empresaId = null;
        try
        {
            var userId = context.User.GetUsuarioId();
            usuarioId = userId > 0 ? userId : null;

            var empId = SessionHelper.EmpresaId;
            empresaId = empId > 0 ? empId : null;

            // Debug logging cuando los valores son null
            if (usuarioId == null && context.User.Identity?.IsAuthenticated == true)
            {
                logger.LogWarning("⚠️ Usuario autenticado pero UsuarioId es null. URL: {Url}, User: {User}",
                    context.Request.Path, context.User.Identity.Name);
            }
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "⚠️ Error capturando UsuarioId/EmpresaId en ActivityLogger para URL: {Url}",
                context.Request.Path);
        }

        // ✅ Registrar actividad en BD (async, no bloqueante)
        try
        {
            await activityLogService.LogActivityAsync(new ActivityLogDto
            {
                UsuarioId = usuarioId,
                UserName = context.User?.Identity?.Name,
                EmpresaId = empresaId,
                IpAddress = context.Connection.RemoteIpAddress?.ToString(),
                Host = context.Request.Host.ToString(),
                Url = $"{context.Request.Path}{context.Request.QueryString}",
                Method = context.Request.Method,
                StatusCode = context.Response.StatusCode,
                Duration = (int)stopwatch.ElapsedMilliseconds,
                RequestBody = requestBody,
                UserAgent = context.Request.Headers["User-Agent"].ToString()
            });
        }
        catch (Exception ex)
        {
            // ⚠️ Si falla el logging, no afectar el request principal
            logger.LogError(ex, "❌ Failed to log activity for {Method} {Path}",
                context.Request.Method, context.Request.Path);
        }
    }

    /// <summary>
    /// Determina si el request debe ser ignorado del logging
    /// </summary>
    private bool ShouldIgnoreRequest(HttpRequest request)
    {
        var path = request.Path.Value ?? "";

        // Ignorar archivos estáticos por extensión
        if (ExcludedExtensions.Any(ext => path.EndsWith(ext, StringComparison.OrdinalIgnoreCase)))
            return true;

        // Ignorar URLs específicas
        if (ExcludedPaths.Any(excluded => path.StartsWith(excluded, StringComparison.OrdinalIgnoreCase)))
            return true;

        return false;
    }

    /// <summary>
    /// Determina si el request contiene datos sensibles (passwords, etc.)
    /// </summary>
    private bool ContainsSensitiveData(HttpRequest request)
    {
        var path = request.Path.Value ?? "";

        // Verificar si la URL contiene rutas sensibles
        return SensitiveDataPaths.Any(sensitive =>
            path.StartsWith(sensitive, StringComparison.OrdinalIgnoreCase));
    }

    /// <summary>
    /// Captura el cuerpo del request (para POST/PUT)
    /// </summary>
    private async Task<string?> CaptureRequestBodyAsync(HttpRequest request)
    {
        try
        {
            // ✅ EnableBuffering permite leer el body múltiples veces
            request.EnableBuffering();

            // Leer el body
            using var reader = new StreamReader(
                request.Body,
                Encoding.UTF8,
                detectEncodingFromByteOrderMarks: false,
                bufferSize: 1024,
                leaveOpen: true);

            var body = await reader.ReadToEndAsync();

            // ✅ IMPORTANTE: Resetear la posición para que el siguiente middleware pueda leerlo
            request.Body.Position = 0;

            // ✅ Limitar tamaño del body guardado (máximo 4000 caracteres)
            if (body.Length > 4000)
            {
                return body.Substring(0, 4000) + "... [truncated]";
            }

            return string.IsNullOrWhiteSpace(body) ? null : body;
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "⚠️ Failed to capture request body");
            return null;
        }
    }
}

/// <summary>
/// Extension method para registrar el middleware
/// </summary>
public static class ActivityLoggerMiddlewareExtensions
{
    public static IApplicationBuilder UseActivityLogger(this IApplicationBuilder builder)
    {
        return builder.UseMiddleware<ActivityLoggerMiddleware>();
    }
}
