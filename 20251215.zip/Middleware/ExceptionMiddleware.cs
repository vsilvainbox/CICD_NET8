using Microsoft.AspNetCore.Mvc.ViewFeatures;
using App.Exceptions;
using App.Services;
using App.Extensions;

namespace App.Middleware;

/// <summary>
/// Middleware unificado de errores - Captura TODO:
/// 1. Excepciones (try/catch alrededor del pipeline)
/// 2. Respuestas HTTP con error (StatusCode >= 400) que no lanzaron excepción
/// 
/// Categorías:
/// - BusinessException: HTTP 400 (NO loguea en BD - son validaciones esperadas)
/// - NotFoundException: HTTP 404 (NO loguea en BD - son errores esperados)
/// - ConfirmationRequired: HTTP 409 (NO loguea en BD - flujo normal)
/// - Exception: HTTP 500 (SÍ loguea en BD - errores inesperados)
/// - HTTP 404/405 sin excepción: (SÍ loguea en BD solo si es ruta API - indica bug)
/// </summary>
public class ExceptionMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ExceptionMiddleware> _logger;
    private readonly IHostEnvironment _environment;

    // Rutas que NO deben loguearse (assets estáticos)
    private static readonly string[] IgnoredPaths = ["/lib", "/css", "/js", "/images", "/fonts", "/.well-known"];
    
    // Extensiones de archivos estáticos a ignorar
    private static readonly string[] IgnoredExtensions = [".js", ".css", ".map", ".ico", ".png", ".jpg", ".svg", ".woff", ".woff2"];

    public ExceptionMiddleware(
        RequestDelegate next,
        ILogger<ExceptionMiddleware> logger,
        IHostEnvironment environment)
    {
        _next = next;
        _logger = logger;
        _environment = environment;
    }

    public async Task InvokeAsync(HttpContext httpContext, IServiceProvider serviceProvider)
    {
        try
        {
            await _next(httpContext);
            
            // Después del pipeline: interceptar respuestas de error que NO lanzaron excepción
            await HandleNonExceptionErrors(httpContext, serviceProvider);
        }
        catch (ConfirmationRequiredException ex)
        {
            await HandleConfirmationRequired(httpContext, ex);
        }
        catch (NotFoundException ex)
        {
            await HandleNotFoundException(httpContext, ex);
        }
        catch (BusinessException ex)
        {
            await HandleBusinessException(httpContext, ex, serviceProvider);
        }
        catch (Exception ex)
        {
            await HandleSystemException(httpContext, ex, serviceProvider);
        }
    }

    /// <summary>
    /// Captura errores HTTP que NO lanzaron excepción (ej: 404 de routing, 405 método incorrecto)
    /// </summary>
    private async Task HandleNonExceptionErrors(HttpContext httpContext, IServiceProvider serviceProvider)
    {
        var response = httpContext.Response;
        var request = httpContext.Request;
        
        // Solo procesar errores (>= 400) que no han sido manejados y no son assets
        if (response.StatusCode < 400 || response.HasStarted || IsIgnoredPath(request.Path))
            return;

        // Loguear en consola
        _logger.LogWarning("HTTP {StatusCode}: {Method} {Path}{Query}", 
            response.StatusCode, request.Method, request.Path, request.QueryString);

        // Loguear en BD solo errores de APIs (indica un bug de desarrollo)
        if (ShouldLogToDatabase(request, response.StatusCode))
        {
            await LogHttpErrorToDatabase(httpContext, serviceProvider);
        }
    }

    private static bool IsIgnoredPath(PathString path)
    {
        var pathValue = path.Value ?? "";
        
        // Ignorar rutas de assets
        foreach (var ignoredPath in IgnoredPaths)
        {
            if (pathValue.StartsWith(ignoredPath, StringComparison.OrdinalIgnoreCase))
                return true;
        }
        
        // Ignorar archivos con extensiones de assets
        foreach (var ext in IgnoredExtensions)
        {
            if (pathValue.EndsWith(ext, StringComparison.OrdinalIgnoreCase))
                return true;
        }
        
        return false;
    }

    private static bool ShouldLogToDatabase(HttpRequest request, int statusCode)
    {
        // Solo loguear 404/405 de rutas API (indica endpoint faltante = bug)
        if (statusCode != 404 && statusCode != 405)
            return false;
            
        var path = request.Path.Value ?? "";
        return path.Contains("Api", StringComparison.OrdinalIgnoreCase);
    }

    private async Task LogHttpErrorToDatabase(HttpContext httpContext, IServiceProvider serviceProvider)
    {
        try
        {
            var errorLogService = serviceProvider.GetService<IErrorLogService>();
            if (errorLogService == null) return;

            await errorLogService.LogErrorAsync(new ErrorLogDto
            {
                Source = "HttpStatusError",
                Severity = "Warning",
                Message = $"HTTP {httpContext.Response.StatusCode}: Endpoint no encontrado o método incorrecto",
                Url = $"{httpContext.Request.Method} {httpContext.Request.Path}{httpContext.Request.QueryString}",
                ExceptionType = $"Http{httpContext.Response.StatusCode}",
                Origin = "Routing",
                EmpresaId = httpContext.User?.GetEmpresaId() > 0 ? httpContext.User.GetEmpresaId() : null,
                AdditionalData = new
                {
                    Method = httpContext.Request.Method,
                    Path = httpContext.Request.Path.ToString(),
                    QueryString = httpContext.Request.QueryString.ToString()
                }
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error al registrar HTTP error en BD");
        }
    }

    private async Task HandleNotFoundException(HttpContext httpContext, NotFoundException ex)
    {
        _logger.LogWarning("Recurso no encontrado: {Message}", ex.Message);

        if (IsAjaxRequest(httpContext.Request))
        {
            httpContext.Response.StatusCode = StatusCodes.Status404NotFound;
            httpContext.Response.ContentType = "application/json";
            await httpContext.Response.WriteAsJsonAsync(new { message = ex.Message });
        }
        else
        {
            httpContext.Response.StatusCode = StatusCodes.Status404NotFound;
            httpContext.Response.ContentType = "text/html";
            await httpContext.Response.WriteAsync($"<h1>404 - No encontrado</h1><p>{ex.Message}</p>");
        }
    }

    private async Task HandleConfirmationRequired(HttpContext httpContext, ConfirmationRequiredException ex)
    {
        _logger.LogInformation("Confirmación requerida: {Code} - {Message}", ex.Code, ex.Message);

        httpContext.Response.StatusCode = StatusCodes.Status409Conflict;
        httpContext.Response.ContentType = "application/json";
        await httpContext.Response.WriteAsJsonAsync(new
        {
            confirmationRequired = true,
            code = ex.Code,
            message = ex.Message
        });
    }

    private async Task HandleBusinessException(HttpContext httpContext, BusinessException ex, IServiceProvider serviceProvider)
    {
        _logger.LogWarning("Validación: {Message}", ex.Message);

        if (IsAjaxRequest(httpContext.Request))
        {
            httpContext.Response.StatusCode = StatusCodes.Status400BadRequest;
            httpContext.Response.ContentType = "application/json";
            await httpContext.Response.WriteAsJsonAsync(new { errors = ex.Errors });
        }
        else
        {
            var tempDataFactory = serviceProvider.GetRequiredService<ITempDataDictionaryFactory>();
            var tempData = tempDataFactory.GetTempData(httpContext);
            tempData["Errors"] = ex.Errors;
            tempData.Save();

            httpContext.Response.Redirect(GetRefererUrl(httpContext) ?? "/");
        }
    }

    private async Task HandleSystemException(HttpContext httpContext, Exception ex, IServiceProvider serviceProvider)
    {
        _logger.LogError(ex, "Error del sistema: {Message}", ex.Message);

        // Loguear en BD - estos son errores inesperados
        await LogExceptionToDatabase(httpContext, ex, serviceProvider);

        if (IsAjaxRequest(httpContext.Request))
        {
            httpContext.Response.StatusCode = StatusCodes.Status500InternalServerError;
            httpContext.Response.ContentType = "application/json";
            await httpContext.Response.WriteAsJsonAsync(new
            {
                message = "Se produjo un error inesperado. Por favor, intente nuevamente.",
                details = _environment.IsDevelopment() ? ex.Message : null
            });
        }
        else
        {
            var tempDataFactory = serviceProvider.GetRequiredService<ITempDataDictionaryFactory>();
            var tempData = tempDataFactory.GetTempData(httpContext);
            tempData["ErrorMessage"] = _environment.IsDevelopment()
                ? $"Error: {ex.Message}"
                : "Se produjo un error inesperado. Por favor, intente nuevamente.";
            tempData.Save();

            httpContext.Response.Redirect(GetRefererUrl(httpContext) ?? "/");
        }
    }

    private static bool IsAjaxRequest(HttpRequest request)
    {
        return request.Headers["X-Requested-With"] == "XMLHttpRequest" ||
               request.Headers["Accept"].ToString().Contains("application/json") ||
               request.ContentType?.Contains("application/json") == true;
    }

    private static string? GetRefererUrl(HttpContext context)
    {
        var referer = context.Request.Headers["Referer"].ToString();
        if (string.IsNullOrEmpty(referer))
            return null;

        if (Uri.TryCreate(referer, UriKind.Absolute, out var uri))
            return uri.PathAndQuery;

        return referer;
    }

    private async Task LogExceptionToDatabase(HttpContext httpContext, Exception exception, IServiceProvider serviceProvider)
    {
        try
        {
            var errorLogService = serviceProvider.GetRequiredService<IErrorLogService>();

            await errorLogService.LogErrorAsync(new ErrorLogDto
            {
                Source = httpContext.Request.Path,
                Severity = "Error",
                Message = exception.Message,
                StackTrace = exception.StackTrace,
                ExceptionType = exception.GetType().Name,
                Url = $"{httpContext.Request.Method} {httpContext.Request.Path}{httpContext.Request.QueryString}",
                EmpresaId = httpContext.User?.GetEmpresaId() > 0 ? httpContext.User.GetEmpresaId() : null,
                Origin = "Exception",
                AdditionalData = new
                {
                    QueryString = httpContext.Request.QueryString.ToString(),
                    Method = httpContext.Request.Method,
                    InnerException = exception.InnerException?.Message
                }
            });
        }
        catch (Exception logEx)
        {
            _logger.LogError(logEx, "Error al registrar excepción en BD");
        }
    }
}
