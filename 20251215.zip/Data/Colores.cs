﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Colores
{
    public short Nivel { get; set; }

    public int IdEmpresa { get; set; }

    public int? Color { get; set; }
}
