﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class EstadoMes
{
    public short? Mes { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public short? Estado { get; set; }

    public short? Impreso { get; set; }

    public int? FechaApertura { get; set; }

    public int? FechaCierre { get; set; }

    public int? FechaImpresion { get; set; }
}
