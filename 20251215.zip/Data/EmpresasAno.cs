﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class EmpresasAno
{
    public int idEmpresa { get; set; }

    public short Ano { get; set; }

    public int? FCierre { get; set; }

    public int? FApertura { get; set; }

    public int? NCompAper { get; set; }

    public int? NCompAperProx { get; set; }

    public int? IdCompAper { get; set; }

    public int? NumLastCompUnico { get; set; }

    public int? NumLastCompA { get; set; }

    public int? NumLastCompE { get; set; }

    public int? NumLastCompI { get; set; }

    public int? NumLastCompT { get; set; }

    public int? NCompAperTrib { get; set; }

    public int? IdCompAperTrib { get; set; }

    public double? RemIVAUTM { get; set; }

    public double? RemIVAUTMAnoAnt { get; set; }

    public double? SaldoLibroCaja { get; set; }

    public double? CredArt33bis { get; set; }

    public double? CPS_CapitalAportado { get; set; }

    public double? CPS_BaseImpPrimCat_14DN3 { get; set; }

    public double? CPS_BaseImpPrimCat_14DN8 { get; set; }

    public double? CPS_Participaciones { get; set; }

    public double? CPS_Disminuciones { get; set; }

    public double? CPS_GastosRechazados { get; set; }

    public double? CPS_RetirosDividendos { get; set; }

    public double? CPS_CapPropioSimplificado { get; set; }

    public double? CPS_AumentosCapital { get; set; }

    public double? CPS_GastosRechazadosNoPagan40 { get; set; }

    public double? CPS_INRPropios { get; set; }

    public double? CPS_OtrosAjustesAumentos { get; set; }

    public double? CPS_OtrosAjustesDisminuciones { get; set; }

    public double? CPS_CapPropioTrib { get; set; }

    public double? CPS_CapPropioTribAnoAnt { get; set; }

    public double? CPS_RepPerdidaArrastre { get; set; }

    public double? CPS_CapPropioSimplVarAnual { get; set; }

    public double? CPS_INRPropiosPerdidas { get; set; }

    public double? CPS_UtilidadesPerdida { get; set; }

    public double? CPS_IngresoDiferido { get; set; }

    public double? CPS_CTDImputableIPE { get; set; }

    public double? CPS_IncentivoAhorro { get; set; }

    public double? CPS_IDPCVoluntario { get; set; }

    public double? CPS_CredActFijos { get; set; }

    public double? CPS_CredParticipaciones { get; set; }
}
