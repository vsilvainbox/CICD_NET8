﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class AjustesExtLibCaja
{
    public int IdAjustesExtLibCaja { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public byte? TipoAjuste { get; set; }

    public short? IdItemAjuste { get; set; }

    public double? Valor { get; set; }
}
