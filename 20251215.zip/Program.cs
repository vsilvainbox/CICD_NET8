using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.AspNetCore.Mvc.ApplicationModels;
using App.Data;
using App.Extensions;
using App.Features.Auth.Services;
using App.Filters;
using App.Helpers;
using App.Services;
using App.Middleware;
using QuestPDF.Infrastructure;

// ========== QUESTPDF LICENSE ==========
QuestPDF.Settings.License = LicenseType.Community;

var builder = WebApplication.CreateBuilder(args);

// ========== KESTREL - TIMEOUTS PARA OPERACIONES LARGAS ==========
builder.WebHost.ConfigureKestrel(serverOptions =>
{
    serverOptions.Limits.KeepAliveTimeout = TimeSpan.FromMinutes(15);
    serverOptions.Limits.RequestHeadersTimeout = TimeSpan.FromMinutes(15);
});

// ========== DATABASE ==========
builder.Services.AddDbContext<LpContabContext>(options =>
{
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection"),
        sqlOptions =>
        {
            sqlOptions.UseQuerySplittingBehavior(QuerySplittingBehavior.SplitQuery);
            sqlOptions.UseCompatibilityLevel(120);
            sqlOptions.CommandTimeout(120); // Timeout de 120 segundos para queries pesadas
        }
    );
});

// ========== PATHBASE ==========
var pathBase = Environment.GetEnvironmentVariable("ASPNETCORE_PATHBASE") ?? "";

// ========== AUTHENTICATION ==========
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        // UsePathBase() maneja el prefijo automáticamente para redirects
        options.LoginPath = "/Auth/Login";
        options.LogoutPath = "/Auth/Logout";
        options.AccessDeniedPath = "/Auth/AccessDenied";
        options.ExpireTimeSpan = TimeSpan.FromHours(8);
        options.Cookie.HttpOnly = true;
        options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
        options.Cookie.Name = ".HyperContabilidad.Auth";
        options.Cookie.Path = string.IsNullOrEmpty(pathBase) ? "/" : pathBase;

        // options.Events.OnRedirectToLogin = context =>
        // {
        //     if (context.Request.Headers["X-Requested-With"] == "XMLHttpRequest")
        //     {
        //         context.Response.StatusCode = 401;
        //         return context.Response.WriteAsJsonAsync(new { error = "No autenticado" });
        //     }
        //     context.Response.Redirect(context.RedirectUri);
        //     return Task.CompletedTask;
        // };

        // options.Events.OnRedirectToAccessDenied = context =>
        // {
        //     if (context.Request.Headers["X-Requested-With"] == "XMLHttpRequest")
        //     {
        //         context.Response.StatusCode = 403;
        //         return context.Response.WriteAsJsonAsync(new { error = "Acceso denegado" });
        //     }
        //     context.Response.Redirect(context.RedirectUri);
        //     return Task.CompletedTask;
        // };
    });

// ========== CORE SERVICES ==========
builder.Services.AddHttpContextAccessor();
builder.Services.AddHttpClient("", client =>
{
    client.Timeout = TimeSpan.FromMinutes(5); // Timeout extendido para operaciones pesadas
});
builder.Services.AddScoped<IErrorLogService, ErrorLogService>();
builder.Services.AddScoped<ISiiAuthService, SiiAuthService>();

// ========== AUTHORIZATION ==========
// La autenticación se maneja por controlador con [Authorize]
// Los ApiControllers no requieren autenticación (serán protegidos a nivel de red/API Gateway en producción)
builder.Services.AddAuthorization();

builder.Services
    .AddControllersWithViews(options =>
    {
        // Deshabilitar Required implícito para tipos no-nullable
        options.SuppressImplicitRequiredAttributeForNonNullableReferenceTypes = true;

        // Configurar mensajes de validación en español
        options.ModelBindingMessageProvider.SetValueMustNotBeNullAccessor(_ => "Este campo es requerido.");
        options.ModelBindingMessageProvider.SetMissingBindRequiredValueAccessor(fieldName => $"El campo {fieldName} es requerido.");
        options.ModelBindingMessageProvider.SetMissingKeyOrValueAccessor(() => "Este campo es requerido.");
        options.ModelBindingMessageProvider.SetMissingRequestBodyRequiredValueAccessor(() => "El cuerpo de la solicitud es requerido.");
        options.ModelBindingMessageProvider.SetValueMustBeANumberAccessor(fieldName => $"El campo {fieldName} debe ser un número.");
        options.ModelBindingMessageProvider.SetAttemptedValueIsInvalidAccessor((value, fieldName) => $"El valor '{value}' no es válido para {fieldName}.");
        options.ModelBindingMessageProvider.SetNonPropertyAttemptedValueIsInvalidAccessor(value => $"El valor '{value}' no es válido.");
        options.ModelBindingMessageProvider.SetUnknownValueIsInvalidAccessor(fieldName => $"El valor proporcionado no es válido para {fieldName}.");
        options.ModelBindingMessageProvider.SetNonPropertyUnknownValueIsInvalidAccessor(() => "El valor proporcionado no es válido.");
        options.ModelBindingMessageProvider.SetValueIsInvalidAccessor(value => $"El valor '{value}' no es válido.");
        options.ModelBindingMessageProvider.SetNonPropertyValueMustBeANumberAccessor(() => "El campo debe ser un número.");
    })
    .ConfigureApiBehaviorOptions(options =>
    {
        // Suprimir respuesta automática de ModelState para que los controladores
        // puedan manejar la validación manualmente y devolver errores en formato array
        options.SuppressModelStateInvalidFilter = true;
    })
    .AddRazorOptions(options =>
    {
        options.ViewLocationFormats.Clear();
        options.ViewLocationFormats.Add("/Features/{1}/Views/{0}.cshtml");
        options.ViewLocationFormats.Add("/Features/Shared/{0}.cshtml");
        options.ViewLocationFormats.Add("/Features/{1}/EditorTemplates/{0}.cshtml");
        options.ViewLocationFormats.Add("/Features/Shared/EditorTemplates/{0}.cshtml");
    })
    .AddRazorRuntimeCompilation();

// ========== AUTH SERVICES ==========
builder.Services.AddScoped<IPasswordService, PasswordService>();
builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<ISessionService, SessionService>();
builder.Services.AddScoped<ICompanyAuthorizationService, CompanyAuthorizationService>();

// ========== FEATURE SERVICES (auto-registro por reflexión) ==========
builder.Services.AddFeatureServices();

// ========== SESSION ==========
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
    options.Cookie.Name = ".HyperContabilidad.Session";
    options.Cookie.Path = string.IsNullOrEmpty(pathBase) ? "/" : pathBase;
});

var app = builder.Build();

// ========== INICIALIZAR HELPERS ==========
// SessionHelper necesita HttpContextAccessor para acceder a sesión/claims desde cualquier lugar
SessionHelper.Initialize(app.Services.GetRequiredService<IHttpContextAccessor>());

if (!string.IsNullOrEmpty(pathBase))
{
    app.UsePathBase(pathBase);
}

// ========== MIDDLEWARE PIPELINE ==========
// ExceptionMiddleware captura TODO: excepciones + errores HTTP (404, 405, etc.)
app.UseMiddleware<ExceptionMiddleware>();

app.UseHsts();
app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseSession();
app.UseAuthentication();
app.UseAuthorization();

// ========== ENDPOINTS ==========
app.MapControllerRoute("default", "{controller=Home}/{action=Index}/{id?}");

app.Run();
// Make Program class accessible for integration tests
public partial class Program { }
