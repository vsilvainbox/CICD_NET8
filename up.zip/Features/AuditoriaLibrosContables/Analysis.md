# Legacy Analysis: Auditoría Libros Contables

## 📄 Información del Formulario VB6

**Archivo VB6:** `old/Contabilidad70/HyperContabilidad/FrmAuditLibContables.frm`
**Fecha Análisis:** 2025-10-02
**Analista:** IA
**Complejidad:** Media-Alta

### Propósito del Formulario
Formulario de auditoría que permite revisar todos los movimientos contables de un período específico (mes/año), mostrando un detalle completo de cada comprobante aprobado incluyendo: fecha, tipo, cuentas, entidades, documentos asociados, glosas, áreas de negocio, centros de costo, y montos de debe/haber. Permite visualizar datos opcionales mediante checkboxes, exportar a Excel, imprimir, y abrir el detalle de cada comprobante.

---

## 🎨 CONTROLES UI IDENTIFICADOS

### Textboxes (Campos de Entrada)
No hay textboxes en este formulario.

### ComboBoxes (Listas Desplegables)
| Control VB6 | Fuente Datos | Valor | Display | Evento Change |
|-------------|--------------|-------|---------|---------------|
| Cb_Mes | Hardcoded (1-12) | Índice mes | Nombre mes | Activa botón Listar |
| Cb_Ano | gEmpresa.Ano | Año empresa | Año empresa | Activa botón Listar |

### Grillas (MSFlexGrid)
| Control VB6 | Fuente Datos | Columnas | Eventos | Acciones |
|-------------|--------------|----------|---------|----------|
| Grid | Query compleja (19 columnas) | Fecha Comp, N° Comp, Tipo, Otros Ing/Egr 14TER, Cód Cuenta, Cuenta, Glosa Comp, RUT Entidad, Razón Social, TD, N° Doc, Emisión, Vencimiento, Glosa Específica, Área Negocio, Centro Gestión, Debe, Haber | Click, DblClick | DblClick=Abre detalle comprobante |

### CheckBoxes (Opciones de Vista)
| Control VB6 | Caption | Default | Acción | Persistencia |
|-------------|---------|---------|--------|--------------|
| Ch_ViewOtrosIngEgr14TER | "Ver Otros Ing. Egr.14TER" | gVarIniFile | Muestra/oculta columna Otros Ing/Egr | INI file |
| Ch_ViewCodCuenta | "Ver Cód. Cuenta Contable" | gVarIniFile | Muestra/oculta columna Código Cuenta | INI file |
| Ch_ViewAreaNeg | "Ver Áreas de Negocio" | gVarIniFile | Muestra/oculta columna Área Negocio | INI file |
| Ch_ViewCCosto | "Ver Centros de Gestión" | gVarIniFile | Muestra/oculta columna Centro Costo | INI file |
| Ch_ViewGlosaComp | "Ver Glosa Comprobante" | gVarIniFile | Muestra/oculta columna Glosa Comp | INI file |

### Botones de Acción
| Botón VB6 | Caption | Habilitado Si | Acción | Mapeo .NET |
|-----------|---------|---------------|--------|------------|
| Bt_Search | (icono lupa) | Siempre | Carga datos de auditoría según período | SearchAsync() |
| Bt_DetComp | (icono documento) | Siempre | Abre detalle del comprobante seleccionado | ViewDetailAsync() |
| Bt_Preview | (icono vista previa) | Después de listar | Vista previa impresión | PreviewAsync() |
| Bt_Print | (icono impresora) | Después de listar | Imprime reporte | PrintAsync() |
| Bt_CopyExcel | (icono Excel) | Después de listar | Copia datos a clipboard formato Excel | ExportExcelAsync() |
| Bt_Calendar | (icono calendario) | Siempre | Muestra calendario (funcionalidad auxiliar) | ShowCalendarAsync() |
| Bt_Opciones | "Opciones de Vista" | Siempre | Muestra/oculta frame opciones | ToggleOptionsAsync() |
| Bt_CerrarOpt | "X" | Siempre | Cierra frame opciones | CloseOptionsAsync() |
| Bt_Cerrar | "Cerrar" | Siempre | Cierra formulario | N/A (navegación) |

### Frames y Contenedores
| Tipo Control | Nombre | Propósito | Eventos |
|--------------|--------|-----------|---------|
| Frame | Fr_Opciones | Contiene checkboxes de opciones de vista (visible/invisible toggle) | N/A |
| Frame | Frame1 | Contiene botones de acción principales | N/A |
| Frame | Frame3 | Contiene controles de filtro (Mes, Año, Buscar) | N/A |

---

## 🔘 EVENTOS IDENTIFICADOS

### Eventos de Formulario
| Evento VB6 | Cuándo Ocurre | Acciones | Mapeo .NET |
|------------|---------------|----------|------------|
| Form_Load | Al abrir formulario | Cargar mes actual, año empresa, configurar grid, cargar preferencias INI, cargar datos, mostrar mensaje informativo | InitializeAsync(), LoadDataAsync() |
| Form_Resize | Al cambiar tamaño ventana | Ajustar tamaño y ancho del grid según ventana | N/A (CSS responsive) |

### Eventos de Botones
| Botón.Evento | Trigger | Acción VB6 | Mapeo .NET |
|--------------|---------|------------|------------|
| Bt_Search.Click | Click botón Listar | Llamar LoadAll() para cargar datos | SearchAsync() |
| Bt_DetComp.Click | Click botón Detalle | Llamar ViewDetComp() para abrir comprobante | ViewDetailAsync() |
| Bt_Preview.Click | Click Vista Previa | Configurar impresión y abrir FrmPrintPreview | PreviewAsync() |
| Bt_Print.Click | Click Imprimir | Configurar impresión y enviar a Printer | PrintAsync() |
| Bt_CopyExcel.Click | Click Copiar Excel | Llamar FGr2Clip() para copiar grid a clipboard | ExportExcelAsync() |
| Bt_Calendar.Click | Click Calendario | Abrir FrmCalendar | ShowCalendarAsync() |
| Bt_Opciones.Click | Click Opciones Vista | Toggle visibility de Fr_Opciones | ToggleOptionsAsync() |
| Bt_CerrarOpt.Click | Click X (cerrar opciones) | Ocultar Fr_Opciones | CloseOptionsAsync() |
| Bt_Cerrar.Click | Click Cerrar | Unload Me (cerrar form) | N/A (navegación) |

### Eventos de Controles
| Control.Evento | Trigger | Acción VB6 | Mapeo .NET |
|----------------|---------|------------|------------|
| Cb_Mes.Click | Selecciona mes | Habilitar botón Listar (Bt_Search.Enabled = True) | EnableSearchButton() |
| Cb_Ano.Click | Selecciona año | Habilitar botón Listar (Bt_Search.Enabled = True) | EnableSearchButton() |
| Ch_ViewOtrosIngEgr14TER.Click | Toggle checkbox | Mostrar/ocultar columna C_OTROSINGEGR, guardar preferencia INI | ToggleColumnAsync("OtrosIngEgr") |
| Ch_ViewCodCuenta.Click | Toggle checkbox | Mostrar/ocultar columna C_CODCUENTA, guardar preferencia INI | ToggleColumnAsync("CodCuenta") |
| Ch_ViewAreaNeg.Click | Toggle checkbox | Mostrar/ocultar columna C_AREANEG, guardar preferencia INI | ToggleColumnAsync("AreaNeg") |
| Ch_ViewCCosto.Click | Toggle checkbox | Mostrar/ocultar columna C_CCOSTO, guardar preferencia INI | ToggleColumnAsync("CCosto") |
| Ch_ViewGlosaComp.Click | Toggle checkbox | Mostrar/ocultar columna C_GLOSACOMP, guardar preferencia INI | ToggleColumnAsync("GlosaComp") |
| Grid.DblClick | Doble click en fila | Llamar ViewDetComp() para abrir comprobante | ViewDetailAsync() |
| Grid.Click | Click en header | (Solo detecta si es header, no hace acción) | N/A |

---

## 🔧 FUNCIONES Y PROCEDIMIENTOS VB6

### Funciones Públicas
```vb
' Función: FView
' Propósito: Mostrar formulario modal
' Parámetros: Ninguno
' Retorno: Void
' Llamado por: Otros formularios
' Mapeo .NET: Index() action en Controller
Public Sub FView()
   Me.Show vbModal
End Sub
```

### Funciones Privadas

```vb
' Función: LoadAll
' Propósito: Cargar todos los datos de auditoría según período seleccionado
' Parámetros: Ninguno
' Retorno: Void
' Query: Complejo JOIN de Comprobante, MovComprobante, Cuentas, Documento, Entidades, CentroCosto, AreaNegocio
' Filtros: Mes, Año, Estado=EC_APROBADO, TipoAjuste (FINANCIERO o AMBOS)
' Mapeo .NET: GetAllAsync(mes, año)
Private Sub LoadAll()
   ' Ejecuta query complejo
   ' Llena Grid con resultados
   ' Formatea columnas según tipo de dato
   ' Deshabilita controles después de cargar
End Sub
```

```vb
' Función: SetUpGrid
' Propósito: Configurar estructura del grid (columnas, anchos, alineaciones, títulos)
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: InitializeGrid() en JavaScript
Private Sub SetUpGrid()
   ' Define 19 columnas
   ' Establece anchos
   ' Define alineaciones
   ' Establece títulos de headers
   ' Aplica visibilidad según checkboxes
End Sub
```

```vb
' Función: ViewDetComp
' Propósito: Abrir formulario FrmComprobante en modo vista para el comprobante seleccionado
' Parámetros: Row (fila), Col (columna)
' Retorno: Void
' Validación: Verifica que IdComp no sea 0 (eliminado)
' Mapeo .NET: Redirect a /NuevoComprobante/View/{id}
Private Sub ViewDetComp(ByVal Row As Integer, ByVal Col As Integer)
   Dim IdComp As Long
   IdComp = Val(Grid.TextMatrix(Row, C_IDCOMP))
   If IdComp <> 0 Then
      ' Abrir FrmComprobante en modo vista
   End If
End Sub
```

```vb
' Función: SetUpPrtGrid
' Propósito: Configurar parámetros de impresión (orientación, títulos, encabezados, anchos columnas)
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: ConfigurePrintSettingsAsync()
Private Sub SetUpPrtGrid()
   ' Establecer orientación horizontal
   ' Definir títulos
   ' Definir encabezados (Periodo: Mes Año)
   ' Configurar anchos de columnas
End Sub
```

```vb
' Función: EnableFrm
' Propósito: Habilitar/deshabilitar botón Listar
' Parámetros: bool (Boolean)
' Retorno: Void
' Mapeo .NET: EnableButton() en JavaScript
Private Sub EnableFrm(bool As Boolean)
   Bt_Search.Enabled = bool
End Sub
```

### Lista Completa de Funciones
| Función VB6 | Tipo | Propósito | Mapeo .NET Method |
|-------------|------|-----------|-------------------|
| FView() | Public Sub | Mostrar formulario modal | Index() |
| LoadAll() | Private Sub | Cargar datos auditoría | GetAllAsync(mes, año) |
| SetUpGrid() | Private Sub | Configurar estructura grid | InitializeGrid() (JS) |
| ViewDetComp(Row, Col) | Private Sub | Abrir detalle comprobante | Redirect a NuevoComprobante/View/{id} |
| SetUpPrtGrid() | Private Sub | Configurar impresión | ConfigurePrintAsync() |
| EnableFrm(bool) | Private Sub | Habilitar/deshabilitar botón | EnableButton() (JS) |

---

## 💾 ACCESO A DATOS VB6

### Query Principal: Cargar Listado de Auditoría

```vb
' Ubicación: LoadAll()
' Tablas: Comprobante, MovComprobante, Cuentas, Documento, Entidades, CentroCosto, AreaNegocio
' Filtros: Mes, Año, IdEmpresa, Ano, Estado=EC_APROBADO, TipoAjuste
Q1 = "SELECT Comprobante.IdComp, Comprobante.Fecha, Comprobante.Correlativo, Comprobante.Tipo, Comprobante.OtrosIngEg14TER, Cuentas.Codigo "
Q1 = Q1 & ", Cuentas.Descripcion as Cuenta, Comprobante.Glosa As GlosaComp, Entidades.Rut, Entidades.Nombre, Entidades.NotValidRut, Documento.TipoLib "
Q1 = Q1 & ", Documento.TipoDoc, Documento.NumDoc "
Q1 = Q1 & ", Documento.FEmisionOri, Documento.FVenc, MovComprobante.Glosa As GlosaMov, AreaNegocio.Descripcion As AreaNeg, CentroCosto.Descripcion As CCosto "
Q1 = Q1 & ", MovComprobante.Debe, MovComprobante.Haber "
Q1 = Q1 & "  FROM (((((Comprobante INNER JOIN MovComprobante ON Comprobante.IdComp = MovComprobante.IdComp "
Q1 = Q1 & JoinEmpAno(gDbType, "Comprobante", "MovComprobante") & " )"
Q1 = Q1 & "  INNER JOIN Cuentas ON MovComprobante.IdCuenta = Cuentas.idCuenta "
Q1 = Q1 & JoinEmpAno(gDbType, "Cuentas", "MovComprobante") & " )"
Q1 = Q1 & "  LEFT JOIN Documento ON MovComprobante.IdDoc = Documento.IdDoc "
Q1 = Q1 & JoinEmpAno(gDbType, "Documento", "MovComprobante") & " )"
Q1 = Q1 & "  LEFT JOIN Entidades ON Documento.IdEntidad = Entidades.IdEntidad "
Q1 = Q1 & JoinEmpAno(gDbType, "Entidades", "Documento", True, True) & " )"
Q1 = Q1 & "  LEFT JOIN CentroCosto ON MovComprobante.idCCosto = CentroCosto.IdCCosto "
Q1 = Q1 & JoinEmpAno(gDbType, "MovComprobante", "CentroCosto", True, True) & " )"
Q1 = Q1 & "  LEFT JOIN AreaNegocio ON MovComprobante.idAreaNeg = AreaNegocio.IdAreaNegocio "
Q1 = Q1 & JoinEmpAno(gDbType, "MovComprobante", "AreaNegocio", True, True)
Q1 = Q1 & "  WHERE " & SqlMonthLng("Fecha") & " = " & CbItemData(Cb_Mes) & " AND " & SqlYearLng("Fecha") & " = " & Cb_Ano
Q1 = Q1 & "  AND Comprobante.IdEmpresa = " & gEmpresa.id & " AND Comprobante.Ano = " & gEmpresa.Ano
Q1 = Q1 & "  AND Comprobante.Estado = " & EC_APROBADO
Q1 = Q1 & "  AND (Comprobante.TipoAjuste IS NULL OR Comprobante.TipoAjuste IN (" & TAJUSTE_FINANCIERO & "," & TAJUSTE_AMBOS & "))"
Q1 = Q1 & "  ORDER BY Comprobante.Fecha, Comprobante.IdComp "

Set Rs = OpenRs(DbMain, Q1)
```

**Mapeo Entity Framework:**
```csharp
var query = await _context.Comprobante
    .Where(c => c.IdEmpresa == empresaId && c.Ano == ano)
    .Where(c => c.FechaComprobante >= fechaDesde && c.FechaComprobante <= fechaHasta)
    .Where(c => c.Estado == EstadoComprobante.Aprobado)
    .Where(c => c.TipoAjuste == null || c.TipoAjuste == TipoAjuste.Financiero || c.TipoAjuste == TipoAjuste.Ambos)
    .Include(c => c.MovComprobante)
        .ThenInclude(m => m.Cuenta)
    .Include(c => c.MovComprobante)
        .ThenInclude(m => m.Documento)
            .ThenInclude(d => d.Entidad)
    .Include(c => c.MovComprobante)
        .ThenInclude(m => m.CentroCosto)
    .Include(c => c.MovComprobante)
        .ThenInclude(m => m.AreaNegocio)
    .OrderBy(c => c.FechaComprobante)
    .ThenBy(c => c.IdComprobante)
    .ToListAsync();
```

---

## ✅ VALIDACIONES Y REGLAS DE NEGOCIO

### Validaciones de Campos
| Campo | Regla | Mensaje Error VB6 | Implementar en .NET |
|-------|-------|-------------------|---------------------|
| Cb_Mes | Obligatorio (selección) | N/A (siempre tiene valor default) | Validación frontend |
| Cb_Ano | Obligatorio (selección) | N/A (siempre tiene valor default) | Validación frontend |
| Grid selección | Verificar que haya ejecutado búsqueda | "Presione el botón Listar antes de..." | Validación frontend |

### Reglas de Negocio

1. **Solo comprobantes aprobados**: La auditoría SOLO muestra comprobantes con Estado = EC_APROBADO
   ```vb
   Q1 = Q1 & "  AND Comprobante.Estado = " & EC_APROBADO
   ```
   **→ Implementar:** Filtro WHERE en query GetAllAsync()

2. **Solo ajustes financieros o ambos**: Excluir ajustes tributarios puros
   ```vb
   Q1 = Q1 & "  AND (Comprobante.TipoAjuste IS NULL OR Comprobante.TipoAjuste IN (" & TAJUSTE_FINANCIERO & "," & TAJUSTE_AMBOS & "))"
   ```
   **→ Implementar:** Filtro WHERE en query GetAllAsync()

3. **Mes actual por defecto**: Al cargar, seleccionar mes contable actual
   ```vb
   MesActual = GetMesActual()
   If MesActual = 0 Then MesActual = 1
   ```
   **→ Implementar:** InitializeAsync() carga mes actual

4. **Advertencia informativa**: Al cargar, mostrar mensaje informativo
   ```vb
   MsgBox1 "Este reporte solo considera comprobantes en estado aprobado.", vbInformation
   ```
   **→ Implementar:** Modal informativo en Form_Load

5. **Deshabilitar botón Listar después de cargar**: Para evitar clics múltiples
   ```vb
   Call EnableFrm(False)
   ```
   **→ Implementar:** DisableButton() en JavaScript

6. **Comprobante eliminado**: Al intentar abrir detalle de comprobante eliminado
   ```vb
   If Grid.TextMatrix(Row, C_IDCOMP) = "0" Then
      MsgBox1 "Este comprobante ha sido eliminado.", vbExclamation
   End If
   ```
   **→ Implementar:** Validación en ViewDetailAsync()

---

## 🧮 CÁLCULOS Y FÓRMULAS

No hay cálculos automáticos en este formulario. Los valores de Debe/Haber vienen directamente de la base de datos.

---

## 🚀 NAVEGACIÓN Y FLUJO

### Formularios Llamados
| Desde VB6 | Formulario Destino | Parámetros | Retorno | Mapeo .NET |
|-----------|-------------------|------------|---------|------------|
| Bt_DetComp.Click | FrmComprobante.frm | IdComp, modo vista | Ninguno | Redirect a /NuevoComprobante/View/{id} |
| Bt_Preview.Click | FrmPrintPreview.frm | Grid configurado | Ninguno | Modal con vista previa |
| Bt_Calendar.Click | FrmCalendar.frm | Ninguno | Fecha seleccionada | Modal calendario (opcional) |

### Flujo de Estados del Form
```
[Inicio] → Form_Load() → [Estado: Inicial]
  ↓
[Seleccionar Mes/Año] → Habilitar botón Listar → [Estado: Listo para Buscar]
  ↓
[Bt_Search.Click] → LoadAll() → Grid lleno → [Estado: Datos Cargados]
  ↓
[Grid.DblClick] → ViewDetComp() → Abrir FrmComprobante → [Estado: Visualizando Detalle]

[Bt_Preview/Bt_Print/Bt_CopyExcel] → Operaciones sobre datos cargados → [Estado: Datos Cargados]

[Bt_Opciones.Click] → Toggle Fr_Opciones → [Estado: Opciones Visibles/Ocultas]
  ↓
[CheckBox.Click] → Mostrar/Ocultar columna + Guardar preferencia INI → [Estado: Datos Cargados]
```

---

## 📊 EXPORTACIONES E IMPORTACIONES

### Exportación a Excel (Clipboard)
```vb
' Botón: Bt_CopyExcel.Click
' Formato: Copia grid completo a clipboard con formato TAB-separated
' Función VB6: FGr2Clip(Grid, Caption & Periodo)
```
**→ Implementar:** ExportToExcelAsync() usando EPPlus

### Vista Previa de Impresión
```vb
' Botón: Bt_Preview.Click
' Formato: Abre FrmPrintPreview con grid configurado
' Orientación: Horizontal (ORIENT_HOR)
' Incluye: Títulos, Encabezados (Periodo)
```
**→ Implementar:** PreviewAsync() genera PDF para vista previa

### Impresión Directa
```vb
' Botón: Bt_Print.Click
' Formato: Envía grid a Printer con configuración
' Orientación: Horizontal
```
**→ Implementar:** PrintAsync() genera PDF para descarga/impresión

---

## 🎯 MAPEO FINAL: MÉTODOS .NET DETERMINADOS

### Interface del Service
```csharp
public interface IAuditoriaLibrosContablesService
{
    // Búsqueda Principal
    Task<IEnumerable<AuditoriaLibrosContablesDto>> GetAllAsync(int empresaId, int ano, int mes);
    
    // Utilidades
    Task<int> GetCurrentMonthAsync(int empresaId, int ano);
    
    // Exportación
    Task<byte[]> ExportToExcelAsync(int empresaId, int ano, int mes);
}
```

### Resumen de Mapeo
| Funcionalidad VB6 | Método .NET | Complejidad | Prioridad |
|-------------------|-------------|-------------|-----------|
| Form_Load cargar datos | GetAllAsync() | Alta | Alta |
| Bt_Search cargar datos | GetAllAsync() | Alta | Alta |
| Bt_DetComp abrir detalle | Redirect a /NuevoComprobante/View/{id} | Baja | Alta |
| Bt_Preview vista previa | PreviewAsync() → PDF | Media | Media |
| Bt_Print imprimir | PrintAsync() → PDF | Media | Media |
| Bt_CopyExcel exportar | ExportToExcelAsync() | Alta | Media |
| CheckBox toggle columnas | ToggleColumnAsync() | Baja | Media |
| Bt_Calendar mostrar calendario | ShowCalendarAsync() | Baja | Baja |

---

## ⚠️ NOTAS IMPORTANTES Y OBSERVACIONES

### Peculiaridades del Form VB6
- Usa MSFlexGrid con 19 columnas configurables
- Estado "aprobado" hardcoded: `EC_APROBADO` (valor fijo)
- Tipos de ajuste filtrados: `TAJUSTE_FINANCIERO`, `TAJUSTE_AMBOS`
- Preferencias guardadas en archivo INI (`gVarIniFile`)
- Grid se redimensiona dinámicamente con Form_Resize
- Comprobantes agrupados: Solo primera fila del comprobante muestra Tipo, Glosa, OtrosIngEgr
- Al cargar siempre muestra mensaje informativo sobre estado aprobado

### Decisiones de Diseño
- **Query complejo**: Usar EF Core con Include() para todas las relaciones
- **Columnas opcionales**: Implementar mediante JavaScript para mostrar/ocultar (en lugar de INI file)
- **Exportación Excel**: EPPlus para generar archivo .xlsx descargable
- **Impresión/Vista Previa**: Generar PDF en servidor usando biblioteca de reportes
- **Calendario**: Implementar componente JavaScript moderno (opcional)
- **Detalle comprobante**: Redirigir a vista existente `/NuevoComprobante/View/{id}`

### Pendientes/Limitaciones
- **Bt_Calendar**: Existe pero es funcionalidad auxiliar (selector de fecha genérico), no crítica para auditoría
  **→ MIGRAR igual**: Incluir botón con TODO [LEGACY] indicando que es funcionalidad legacy opcional
- **Archivo INI**: Preferencias de columnas visibles se guardaban en INI
  **→ Cambio de diseño**: Usar localStorage del navegador en lugar de archivo servidor
- **MSFlexGrid redimensionable**: VB6 permitía redimensionar columnas manualmente
  **→ Implementar**: Tabla HTML con columnas redimensionables vía JavaScript

---

## ✅ CHECKLIST DE COMPLETITUD DEL ANÁLISIS

- [x] Todos los controles UI documentados
- [x] Todos los botones y eventos mapeados
- [x] **TODOS los botones tienen "Mapeo .NET" definido**
- [x] **Botones con excepciones documentan razón válida** (Bt_Calendar: LEGACY opcional)
- [x] Todas las funciones VB6 identificadas
- [x] Todos los queries SQL traducidos a EF Core
- [x] Todas las validaciones documentadas
- [x] Todas las reglas de negocio identificadas
- [x] Todos los cálculos documentados (N/A - no hay cálculos)
- [x] Navegación y flujos mapeados
- [x] Métodos .NET determinados
- [x] Interface del Service definida
- [x] **Decisiones de excepción justificadas y estructuradas**

---

**✅ ANÁLISIS COMPLETO - LISTO PARA IMPLEMENTACIÓN**
