using Microsoft.EntityFrameworkCore;
using App.Data;
using OfficeOpenXml;

namespace App.Features.AuditoriaLibrosContables;

public class AuditoriaLibrosContablesService(
    LpContabContext context,
    ILogger<AuditoriaLibrosContablesService> logger) : IAuditoriaLibrosContablesService
{
    // Constantes de estado y tipo de ajuste (equivalentes a VB6)
    private const byte EC_APROBADO = 2;  // Estado Aprobado
    private const byte TAJUSTE_FINANCIERO = 1;
    private const byte TAJUSTE_AMBOS = 3;

    public async Task<IEnumerable<AuditoriaLibrosContablesDto>> GetAllAsync(int empresaId, short ano, int mes)
    {
        logger.LogInformation("Getting auditoría libros contables for empresaId: {EmpresaId}, ano: {Ano}, mes: {Mes}", empresaId, ano, mes);

        {
            // Calcular rango de fechas para el mes seleccionado
            var primerDiaMes = new DateTime(ano, mes, 1);
            var ultimoDiaMes = primerDiaMes.AddMonths(1).AddDays(-1);

            var fechaDesde = ConvertirFechaAInt(primerDiaMes);
            var fechaHasta = ConvertirFechaAInt(ultimoDiaMes);

            // Query complejo que replica el VB6
            // Usar sintaxis de método para mejor control de los JOINs
            var anoShort = ano;  // Convert int to short for database comparison
            var comprobantes = context.Comprobante
                .Where(c => c.IdEmpresa == empresaId
                            && c.Ano == anoShort
                            && c.Fecha >= fechaDesde
                            && c.Fecha <= fechaHasta
                            && c.Estado == EC_APROBADO
                            && (c.TipoAjuste == null || c.TipoAjuste == TAJUSTE_FINANCIERO || c.TipoAjuste == TAJUSTE_AMBOS));

            var query = from comp in comprobantes
                from mov in context.MovComprobante
                    .Where(m => m.IdEmpresa == comp.IdEmpresa && m.Ano == comp.Ano && m.IdComp == comp.IdComp)
                from cuenta in context.Cuentas
                    .Where(c => c.IdEmpresa == mov.IdEmpresa && c.Ano == mov.Ano && c.idCuenta == mov.IdCuenta)
                from doc in context.Documento
                    .Where(d => mov.IdDoc != null && d.IdEmpresa == mov.IdEmpresa && d.Ano == mov.Ano && d.IdDoc == mov.IdDoc.Value)
                    .DefaultIfEmpty()
                from ent in context.Entidades
                    .Where(e => doc != null && doc.IdEntidad != null && e.IdEmpresa == doc.IdEmpresa && e.IdEntidad == doc.IdEntidad.Value)
                    .DefaultIfEmpty()
                from cc in context.CentroCosto
                    .Where(c => mov.idCCosto != null && c.IdEmpresa == mov.IdEmpresa && c.IdCCosto == mov.idCCosto.Value)
                    .DefaultIfEmpty()
                from an in context.AreaNegocio
                    .Where(a => mov.idAreaNeg != null && a.IdEmpresa == mov.IdEmpresa && a.IdAreaNegocio == mov.idAreaNeg.Value)
                    .DefaultIfEmpty()
                orderby comp.Fecha, comp.IdComp
                select new AuditoriaLibrosContablesDto
                {
                    IdComp = comp.IdComp,
                    FechaComprobante = ConvertirIntAFecha(comp.Fecha),
                    Correlativo = comp.Correlativo,
                    TipoComprobante = ObtenerNombreTipoComprobante(comp.Tipo),
                    OtrosIngEg14TER = comp.OtrosIngEg14TER == true,
                    CodigoCuenta = cuenta.Codigo,
                    NombreCuenta = cuenta.Descripcion,
                    GlosaComprobante = comp.Glosa,
                    RutEntidad = ent != null ? ent.Rut : null,
                    NombreEntidad = ent != null ? ent.Nombre : null,
                    TipoDocumento = doc != null ? ObtenerDiminutivoDocumento(doc.TipoLib, doc.TipoDoc) : null,
                    NumeroDocumento = doc != null ? doc.NumDoc : null,
                    FechaEmision = ConvertirIntAFecha(doc != null ? doc.FEmisionOri : null),
                    FechaVencimiento = ConvertirIntAFecha(doc != null ? doc.FVenc : null),
                    GlosaMovimiento = mov.Glosa,
                    AreaNegocio = an != null ? an.Descripcion : null,
                    CentroCosto = cc != null ? cc.Descripcion : null,
                    Debe = mov.Debe.HasValue ? (decimal)mov.Debe.Value : 0,
                    Haber = mov.Haber.HasValue ? (decimal)mov.Haber.Value : 0
                };

            var resultado = await query.ToListAsync();
                
            logger.LogInformation("Found {Count} movimientos for auditoría libros contables", resultado.Count);
                
            return resultado;
        }
    }

    public async Task<int> GetCurrentMonthAsync(int empresaId, short ano)
    {
        logger.LogInformation("Getting current month for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            // Buscar el mes del último comprobante aprobado
            var anoShort = ano;  // Convert int to short for database comparison
            var ultimoComprobante = await context.Comprobante
                .Where(c => c.IdEmpresa == empresaId && c.Ano == anoShort && c.Estado == EC_APROBADO)
                .OrderByDescending(c => c.Fecha)
                .FirstOrDefaultAsync();

            if (ultimoComprobante?.Fecha != null)
            {
                var fecha = ConvertirIntAFecha(ultimoComprobante.Fecha);
                if (fecha.HasValue)
                {
                    logger.LogInformation("Current month found: {Month}", fecha.Value.Month);
                    return fecha.Value.Month;
                }
            }

            // Si no hay comprobantes, retornar mes 1
            logger.LogInformation("No comprobantes found, returning default month: 1");
            return 1;
        }
    }

    public async Task<byte[]> ExportToExcelAsync(int empresaId, short ano, int mes)
    {
        logger.LogInformation("Exporting auditoría libros contables to Excel for empresaId: {EmpresaId}, ano: {Ano}, mes: {Mes}", empresaId, ano, mes);

        {
            var datos = await GetAllAsync(empresaId, ano, mes);

            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            using var package = new ExcelPackage();
            var worksheet = package.Workbook.Worksheets.Add("Auditoría Libros");

            // Encabezados
            worksheet.Cells[1, 1].Value = "Fecha Comp.";
            worksheet.Cells[1, 2].Value = "N° Comp.";
            worksheet.Cells[1, 3].Value = "Tipo";
            worksheet.Cells[1, 4].Value = "Otros Ing/Egr. 14TER";
            worksheet.Cells[1, 5].Value = "Cód. Cuenta";
            worksheet.Cells[1, 6].Value = "Cuenta";
            worksheet.Cells[1, 7].Value = "Glosa Comp.";
            worksheet.Cells[1, 8].Value = "RUT Entidad";
            worksheet.Cells[1, 9].Value = "Razón Social";
            worksheet.Cells[1, 10].Value = "TD";
            worksheet.Cells[1, 11].Value = "N° Doc.";
            worksheet.Cells[1, 12].Value = "Emisión";
            worksheet.Cells[1, 13].Value = "Vencimiento";
            worksheet.Cells[1, 14].Value = "Glosa Específica";
            worksheet.Cells[1, 15].Value = "Área de Negocio";
            worksheet.Cells[1, 16].Value = "Centro de Gestión";
            worksheet.Cells[1, 17].Value = "Debe";
            worksheet.Cells[1, 18].Value = "Haber";

            // Formato encabezados
            using (var range = worksheet.Cells[1, 1, 1, 18])
            {
                range.Style.Font.Bold = true;
                range.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                range.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightGray);
            }

            // Datos
            int row = 2;
            foreach (var item in datos)
            {
                worksheet.Cells[row, 1].Value = item.FechaComprobante?.ToString("dd/MM/yyyy");
                worksheet.Cells[row, 2].Value = item.Correlativo;
                worksheet.Cells[row, 3].Value = item.TipoComprobante;
                worksheet.Cells[row, 4].Value = item.OtrosIngEg14TER == true ? "Sí" : "";
                worksheet.Cells[row, 5].Value = item.CodigoCuenta;
                worksheet.Cells[row, 6].Value = item.NombreCuenta;
                worksheet.Cells[row, 7].Value = item.GlosaComprobante;
                worksheet.Cells[row, 8].Value = item.RutEntidad;
                worksheet.Cells[row, 9].Value = item.NombreEntidad;
                worksheet.Cells[row, 10].Value = item.TipoDocumento;
                worksheet.Cells[row, 11].Value = item.NumeroDocumento;
                worksheet.Cells[row, 12].Value = item.FechaEmision?.ToString("dd/MM/yyyy");
                worksheet.Cells[row, 13].Value = item.FechaVencimiento?.ToString("dd/MM/yyyy");
                worksheet.Cells[row, 14].Value = item.GlosaMovimiento;
                worksheet.Cells[row, 15].Value = item.AreaNegocio;
                worksheet.Cells[row, 16].Value = item.CentroCosto;
                worksheet.Cells[row, 17].Value = item.Debe;
                worksheet.Cells[row, 18].Value = item.Haber;
                row++;
            }

            // Autoajustar columnas
            worksheet.Cells.AutoFitColumns();

            logger.LogInformation("Successfully exported {Count} rows to Excel", datos.Count());
                
            return package.GetAsByteArray();
        }
    }

    #region Métodos Auxiliares

    /// <summary>
    /// Convierte fecha DateTime a formato OLE/Excel (número de serie de días desde 1899-12-30)
    /// </summary>
    private static int ConvertirFechaAInt(DateTime fecha)
    {
        return (int)fecha.ToOADate();
    }

    /// <summary>
    /// Convierte fecha int OLE/Excel a DateTime
    /// </summary>
    private static DateTime? ConvertirIntAFecha(int? fechaInt)
    {
        if (!fechaInt.HasValue || fechaInt.Value == 0)
            return null;

        try
        {
            return DateTime.FromOADate(fechaInt.Value);
        }
        catch (ArgumentException)
        {
            // Fecha inválida
            return null;
        }
    }

    /// <summary>
    /// Obtiene el nombre del tipo de comprobante
    /// </summary>
    private static string ObtenerNombreTipoComprobante(byte? tipo)
    {
        if (!tipo.HasValue) return "";

        return tipo.Value switch
        {
            1 => "ING",    // Ingreso
            2 => "EGR",    // Egreso
            3 => "TRAS",   // Traspaso
            _ => tipo.ToString()
        };
    }

    /// <summary>
    /// Obtiene el diminutivo del tipo de documento
    /// </summary>
    private static string ObtenerDiminutivoDocumento(byte? tipoLib, byte? tipoDoc)
    {
        if (!tipoLib.HasValue || !tipoDoc.HasValue) return "";

        // Lógica simplificada - en producción debería usar tabla de tipos de documentos
        return tipoDoc.Value switch
        {
            1 => "FV",      // Factura Venta
            2 => "FC",      // Factura Compra
            3 => "BV",      // Boleta Venta
            4 => "NC",      // Nota Crédito
            5 => "ND",      // Nota Débito
            _ => tipoDoc.ToString()
        };
    }

    #endregion
}