using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.AuditoriaLibrosContables;

[Authorize]
public class AuditoriaLibrosContablesController(
    IHttpClientFactory httpClientFactory,
    ILogger<AuditoriaLibrosContablesController> logger,
    LinkGenerator linkGenerator) : Controller
{
    /// <summary>
    /// Muestra la vista principal de auditor�a de libros contables
    /// </summary>
    public async Task<IActionResult> Index()
    {
        logger.LogInformation("Loading AuditoriaLibrosContables index for empresaId: {EmpresaId}, ano: {Ano}", SessionHelper.EmpresaId, SessionHelper.Ano);

        {
            // Obtener mes actual de la API
            var client = httpClientFactory.CreateClient("ApiClient");
            var url = linkGenerator.GetPathByAction(
                action: nameof(AuditoriaLibrosContablesApiController.GetCurrentMonth),
                controller: nameof(AuditoriaLibrosContablesApiController).Replace("Controller", ""),
                values: new { empresaId = SessionHelper.EmpresaId, ano = SessionHelper.Ano });
            var result = await client.GetFromApiAsync<JsonElement>(url!);
            ViewData["MesActual"] = result.GetProperty("mes").GetInt32();
            logger.LogInformation("Successfully loaded current month");

            return View();
        }
    }

    [HttpGet]
    public async Task<IActionResult> GetAuditoria(int empresaId, short ano, int mes)
    {
        logger.LogInformation("Proxying GetAuditoria: empresaId={EmpresaId}, ano={Ano}, mes={Mes}", empresaId, ano, mes);

        var client = httpClientFactory.CreateClient("ApiClient");
        var url = linkGenerator.GetPathByAction(
            action: nameof(AuditoriaLibrosContablesApiController.GetAuditoria),
            controller: nameof(AuditoriaLibrosContablesApiController).Replace("Controller", ""),
            values: new { empresaId, ano, mes });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    [HttpGet]
    public async Task<IActionResult> ExportarExcel(int empresaId, short ano, int mes)
    {
        logger.LogInformation("Proxying ExportarExcel: empresaId={EmpresaId}, ano={Ano}, mes={Mes}", empresaId, ano, mes);

        {
            var client = httpClientFactory.CreateClient("ApiClient");
            var url = linkGenerator.GetPathByAction(
                action: nameof(AuditoriaLibrosContablesApiController.ExportarExcel),
                controller: nameof(AuditoriaLibrosContablesApiController).Replace("Controller", ""),
                values: new { empresaId, ano, mes });
            var (fileBytes, contentType) = await client.DownloadFileAsync(url, HttpMethod.Get, null);

            return File(fileBytes, contentType);
        }
    }
}