using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.AreasNegocio;


public class AreasNegocioController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<AreasNegocioController> logger) : Controller
{
    public async Task<IActionResult> Index()
    {
        {
            logger.LogInformation("Index: Cargando vista de áreas de negocio para empresaId={EmpresaId}", SessionHelper.EmpresaId);

            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AreasNegocioApiController.GetAll),
                controller: nameof(AreasNegocioApiController).Replace("Controller", ""),
                values: new { empresaId = SessionHelper.EmpresaId }
            );
            var areas = await client.GetFromApiAsync<List<AreasNegocioDto>>(url!);

            logger.LogInformation("Index: Áreas de negocio cargadas exitosamente. Total: {Count}", areas?.Count ?? 0);
            return View(areas ?? new List<AreasNegocioDto>());
        }
    }

    // Proxy methods for JavaScript to call (Vista ? MVC ? API pattern)

    [HttpGet]
    public async Task<IActionResult> GetById(int id)
    {
        {
            logger.LogInformation("GetById: Proxy call for id={Id}, empresaId={EmpresaId}", id, SessionHelper.EmpresaId);
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AreasNegocioApiController.GetById),
                controller: nameof(AreasNegocioApiController).Replace("Controller", ""),
                values: new { id, empresaId = SessionHelper.EmpresaId }
            );
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] AreasNegocioCreateDto dto)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        logger.LogInformation("Create: Proxy call for empresaId={EmpresaId}", SessionHelper.EmpresaId);
        var client = httpClientFactory.CreateClient("ApiClient");

        var url = linkGenerator.GetPathByAction(
            action: nameof(AreasNegocioApiController.Create),
            controller: nameof(AreasNegocioApiController).Replace("Controller", ""),
            values: new { empresaId = SessionHelper.EmpresaId }
        );

        // Convertir DTO a JsonElement para mantener compatibilidad con ProxyRequestAsync
        var jsonString = JsonSerializer.Serialize(dto);
        var jsonElement = JsonDocument.Parse(jsonString).RootElement;

        var (statusCode, content) = await client.ProxyRequestAsync(url!, jsonElement, HttpMethod.Post);
        return new ContentResult
        {
            Content = content,
            ContentType = "application/json",
            StatusCode = statusCode
        };
    }

    [HttpPut]
    public async Task<IActionResult> Update(int id, [FromBody] AreasNegocioUpdateDto dto)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        logger.LogInformation("Update: Proxy call for id={Id}, empresaId={EmpresaId}", id, SessionHelper.EmpresaId);
        var client = httpClientFactory.CreateClient("ApiClient");

        var url = linkGenerator.GetPathByAction(
            action: nameof(AreasNegocioApiController.Update),
            controller: nameof(AreasNegocioApiController).Replace("Controller", ""),
            values: new { id, empresaId = SessionHelper.EmpresaId }
        );

        // Convertir DTO a JsonElement para mantener compatibilidad con ProxyRequestAsync
        var jsonString = JsonSerializer.Serialize(dto);
        var jsonElement = JsonDocument.Parse(jsonString).RootElement;

        var (statusCode, content) = await client.ProxyRequestAsync(url!, jsonElement, HttpMethod.Put);
        return new ContentResult
        {
            Content = content,
            ContentType = "application/json",
            StatusCode = statusCode
        };
    }

    [HttpDelete]
    public async Task<IActionResult> Delete(int id)
    {
        {
            logger.LogInformation("Delete: Proxy call for id={Id}, empresaId={EmpresaId}", id, SessionHelper.EmpresaId);
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AreasNegocioApiController.Delete),
                controller: nameof(AreasNegocioApiController).Replace("Controller", ""),
                values: new { id, empresaId = SessionHelper.EmpresaId }
            );
            var (statusCode, content) = await client.ProxyRequestAsync(url!, null, HttpMethod.Delete);
            return new ContentResult
            {
                Content = content,
                ContentType = "application/json",
                StatusCode = statusCode
            };
        }
    }

    [HttpGet]
    public async Task<IActionResult> Export()
    {
        {
            logger.LogInformation("Export: Exportando áreas de negocio para empresaId={EmpresaId}", SessionHelper.EmpresaId);
            
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: "ExportToExcel",
                controller: nameof(AreasNegocioApiController).Replace("Controller", ""),
                values: new { empresaId = SessionHelper.EmpresaId }
            );

            var (fileBytes, contentType) = await client.DownloadFileAsync(url, HttpMethod.Get);
            var fileName = $"AreasNegocio_{SessionHelper.EmpresaId}_{DateTime.Now:yyyyMMdd}.xlsx";
            
            logger.LogInformation("Export: Exportación exitosa");
            return File(fileBytes, contentType, fileName);
        }
    }
}
