# Legacy Analysis: Asistente Importación Primera Categoría

## 📄 Información del Formulario VB6

**Archivo VB6:** `vb6\Contabilidad70\HyperContabilidad\FrmAsistImpPrimCat.frm`
**Fecha Análisis:** 2025-10-03
**Analista:** IA - GitHub Copilot
**Complejidad:** Alta

### Propósito del Formulario
Formulario especializado para el cálculo y gestión del Impuesto de Primera Categoría en Chile. Permite registrar y calcular automáticamente los créditos asociados (33 bis, ingreso diferido, retiros), remanentes de ejercicios anteriores actualizados según IPC, y el impuesto neto a pagar. Es una herramienta crítica para el cumplimiento tributario de empresas.

---

## 🎨 CONTROLES UI IDENTIFICADOS

### Grilla Principal (FEd2Grid)
| Control VB6 | Descripción | Características | Funcionalidad |
|-------------|-------------|-----------------|---------------|
| Grid | FlexEdGrid2.FEd2Grid | 11 columnas x filas dinámicas | Muestra ítems del cálculo IDPC con valores editables e calculados |

**Columnas de la Grilla:**
- `C_ID` (0): IdAsistImpPrimCat (oculta)
- `C_IDITEM` (1): IdItem (oculta)
- `C_CONCEPTO` (2): Descripción del ítem (ancho 5000, solo lectura)
- `C_REMEJANTNOMINAL` (3): Remanente Ejercicio Anterior Nominal (1600, editable solo rows 4 y 5)
- `C_REMEJANTACT` (4): Remanente Ejercicio Anterior Actualizado (1600, calculado)
- `C_GENERADOANO` (5): Generado en el Año (1600, editable solo rows 4 y 5)
- `C_CREDUTILIZADO` (6): Crédito Utilizado (1600, calculado)
- `C_REMEJSGTE` (7): Remanente Ejercicio Siguiente (1600, calculado)
- `C_FMT` (8): Formato fila (oculta, códigos: "B"=Bold, "L"=Line)
- `C_COLOBLIGATORIA` (9): Marca columna obligatoria (oculta)
- `C_UPD` (10): Marca actualización (oculta)

### Botones de Acción
| Botón VB6 | Caption | Icon | Acción | Mapeo .NET |
|-----------|---------|------|--------|------------|
| Bt_OK | "Aceptar" | N/A | Valida y guarda todos los cambios, cierra form | SaveAllAsync() + CloseModal |
| Bt_Cancelar | "Cancelar" | N/A | Cierra form sin guardar | CloseModal |
| Bt_DetDoc | N/A | Icon | Abre detalle según celda seleccionada | GetDetailAsync() |
| Bt_Print | N/A | Printer icon | Imprime la grilla | ExportPdfAsync() |
| Bt_Preview | N/A | Preview icon | Vista previa impresión | PreviewPrintAsync() |
| Bt_CopyExcel | N/A | Excel icon | Copia grilla al portapapeles | CopyToClipboardAsync() |
| Bt_Sum | N/A | Sigma icon | Calculadora suma simple | ShowSumCalculator() |
| Bt_Calc | N/A | Calculator icon | Abre calculadora Windows | OpenCalculator() |
| Bt_ConvMoneda | N/A | Currency icon | Conversor de monedas | ShowCurrencyConverter() |
| Bt_Calendar | N/A | Calendar icon | Calendario | ShowCalendar() |

### Otros Controles
| Tipo Control | Nombre | Propósito | Propiedades |
|--------------|--------|-----------|-------------|
| Frame | Frame2 | Contenedor de botones toolbar | Height=615, Width=13155 |

---

## 🔘 EVENTOS IDENTIFICADOS

### Eventos de Formulario
| Evento VB6 | Cuándo Ocurre | Acciones | Mapeo .NET |
|------------|---------------|----------|------------|
| Form_Load | Al abrir form | SetUpGrid() + LoadAll() | OnInitializedAsync() |

### Eventos de Botones
| Botón.Evento | Trigger | Acción VB6 | Mapeo .NET |
|---------------|---------|------------|------------|
| Bt_OK_Click | Click | valida() + SaveAll() + Unload | ValidateAndSaveAsync() |
| Bt_Cancelar_Click | Click | Unload Me | CloseModal |
| Bt_DetDoc_Click | Click | Abre detalle según IdItem y columna | OpenDetailAsync() |
| Bt_Print_Click | Click | SetUpPrtGrid() + PrtFlexGrid(Printer) | PrintAsync() |
| Bt_Preview_Click | Click | SetUpPrtGrid() + FrmPrintPreview | PreviewAsync() |
| Bt_CopyExcel_Click | Click | LP_FGr2String() + Clipboard | CopyToExcelAsync() |
| Bt_Sum_Click | Click | FrmSumSimple.FViewSum(Grid) | SumCalculatorAsync() |
| Bt_Calc_Click | Click | Calculadora() | OpenCalculator() |
| Bt_ConvMoneda_Click | Click | FrmConverMoneda.FView() | CurrencyConverter() |
| Bt_Calendar_Click | Click | FrmCalendar.SelDate() | CalendarPicker() |

### Eventos de Grilla
| Control.Evento | Trigger | Acción VB6 | Mapeo .NET |
|----------------|---------|------------|------------|
| Grid.AcceptValue | Usuario edita celda editable | Format(vFmt(Value), NUMFMT) + CalcTot() | OnCellValueChangedAsync() |
| Grid.BeforeEdit | Antes de editar celda | Determina si celda es editable | OnBeforeEditAsync() |
| Grid.DblClick | Doble click | Bt_DetDoc_Click | OnGridDoubleClick() |
| Grid.EditKeyPress | Tecla presionada en edición | KeyNum(KeyAscii) - solo números | ValidateNumericInput() |

---

## 🔧 FUNCIONES Y PROCEDIMIENTOS VB6

### Funciones Públicas

Ninguna función pública declarada explícitamente.

### Funciones Privadas

```vb
' Función: SetUpGrid
' Propósito: Configurar estructura de la grilla (columnas, anchos, alineación)
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: InitializeGridStructure() en JavaScript
Private Sub SetUpGrid()
    ' Configura 11 columnas, 12 rows iniciales
    ' Oculta columnas ID, IDITEM, FMT, COLOBLIGATORIA, UPD
    ' Ancho CONCEPTO = 5000, resto = 1600
    ' Alineación derecha para columnas numéricas
    ' BackColor = vbButtonFace
End Sub
```

```vb
' Función: LoadAll
' Propósito: Cargar datos desde BD y calcular valores
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: GetAllAsync() en Service
Private Sub LoadAll()
    ' Recorre C_MAX_ASISTIMPPRIMCAT ítems (constante global)
    ' Para cada ítem:
    '   - Obtiene concepto de gStrAsistImpPrimCat(i) (array global)
    '   - Consulta BD para obtener valores guardados
    '   - Aplica lógica específica según IdItem
    ' Lógica por IdItem:
    '   Case 1: IDPC Sobre Base Imponible
    '     - Consulta BaseImponible14Ter para TipoBaseImp=TOTALES, IdItemBaseImp=0
    '     - Calcula lIDPCBaseImp = Valor * gImpPrimCategoria
    '     - Estilo: Bold, fondo gris claro
    '   Case 2: Encabezado de columnas
    '     - Títulos de columnas: "Rem. Ejer. Ant. Nominal/Actualizado", etc.
    '     - Estilo: Bold, centrado
    '   Case 3: Crédito 33 bis
    '     - Obtiene valor de GetValAjustesELC(TAEC_AGREGADOS, 6)
    '     - Tope: 500 UTM (consulta valor UTM al 31/12)
    '     - Calcula utilizado: min(lIDPCBaseImp, GeneradoAno)
    '     - Fondo gris claro en columnas no editables
    '   Case 4: Crédito asociado a ingreso diferido
    '     - Carga RemEjAntNominal y GeneradoAno desde BD
    '     - Celdas editables: fondo blanco
    '     - lRowCredIng = Row (guarda índice)
    '   Case 5: Crédito asociado a retiros
    '     - Carga RemEjAntNominal y GeneradoAno desde BD
    '     - Celdas editables: fondo blanco
    '     - lRowCredRetiros = Row (guarda índice)
    '   Case 6: IDPC neto a pagar
    '     - lRowIDPCNetoPagar = Row
    '     - Estilo: Bold, fondo gris claro
    '   Case 7: Mayor valor enajenación
    '     - Consulta BaseImponible14Ter para TipoBaseImp=TOTALES, IdItemBaseImp=1
    '     - lMayorValorEnajenación almacenado
    '     - lRowMayorValorEnajenacion = Row
    '     - Estilo: Bold
    '   Case 8: IDPC a pagar (total)
    '     - lRowIDPCPagar = Row
    '     - Estilo: Bold, fondo gris claro
    ' Finalmente: CalcTot()
End Sub
```

```vb
' Función: CalcTot
' Propósito: Calcular todos los totales y valores derivados
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: CalculateTotalsAsync() en Service
Private Sub CalcTot()
    ' Obtiene Factor actualización: GetFactorCM(31/12/año anterior)
    ' Calcula:
    ' 1. RemEjAntAct CredIng = RemEjAntNominal * Factor
    ' 2. RemEjAntAct CredRetiros = RemEjAntNominal * Factor
    ' 3. CredUtilizado CredIng = min(IDPCBase - Cred33bis, RemEjAntAct + GeneradoAno)
    ' 4. CredUtilizado CredRetiros = min(IDPCBase - Cred33bis - CredUtilIng, RemEjAntAct + GeneradoAno)
    ' 5. RemEjSgte CredRetiros = RemEjAntAct + GeneradoAno - CredUtilizado
    ' 6. CredUtilizado NetoPagar = IDPCBase - Cred33bis - CredUtilIng - CredUtilRetiros
    ' 7. CredUtilizado MayorValor = lMayorValorEnajenación * gImpPrimCategoria
    ' 8. CredUtilizado IDPCPagar = (anterior) * gImpPrimCategoria
End Sub
```

```vb
' Función: SaveAll
' Propósito: Guardar todos los cambios en BD
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: SaveAllAsync() en Service
Private Sub SaveAll()
    ' Para cada fila con IdItem > 0:
    '   Si existe ID (C_ID <> 0):
    '     - UPDATE AsistImpPrimCat SET campos
    '   Si no existe ID:
    '     - SELECT Max(IdAsistImpPrimCat) + 1
    '     - INSERT INTO AsistImpPrimCat
    ' WHERE: IdEmpresa = gEmpresa.id AND Ano = gEmpresa.Ano
End Sub
```

```vb
' Función: valida
' Propósito: Validar datos antes de guardar
' Parámetros: Ninguno
' Retorno: Boolean
' Mapeo .NET: ValidateAsync() en Service
Private Function valida() As Boolean
    ' Actualmente siempre retorna True
    ' En .NET: implementar validaciones apropiadas
    valida = True
End Function
```

```vb
' Función: SetUpPrtGrid
' Propósito: Configurar grilla para impresión
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: ConfigurePrintLayout() en Service
Private Sub SetUpPrtGrid()
    ' Orientation: ORIENT_VER (vertical)
    ' Títulos: Caption del form
    ' ColWi: Ajusta anchos * 0.8
    ' FmtCol: C_FMT (aplica formatos bold/lines)
End Sub
```

### Lista Completa de Funciones
| Función VB6 | Tipo | Propósito | Mapeo .NET Method |
|-------------|------|-----------|-------------------|
| SetUpGrid() | Private Sub | Configurar estructura grilla | InitializeGridStructure() (JS) |
| LoadAll() | Private Sub | Cargar datos y aplicar lógica | GetAllItemsAsync() |
| CalcTot() | Private Sub | Calcular todos los totales | CalculateTotalsAsync() |
| SaveAll() | Private Sub | Guardar cambios en BD | SaveAllAsync() |
| valida() | Private Function→Boolean | Validar antes de guardar | ValidateAsync() |
| SetUpPrtGrid() | Private Sub | Configurar impresión | ConfigurePrintLayoutAsync() |

---

## 💾 ACCESO A DATOS VB6

### Query 1: Obtener Valores Guardados por Ítem
```vb
' Ubicación: LoadAll() - para cada IdItem
Q1 = "SELECT IdAsistImpPrimCat, RemEjAntNominal, GeneradoAno FROM AsistImpPrimCat "
Q1 = Q1 & " WHERE IdItem = " & Grid.TextMatrix(Row, C_IDITEM)
Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.id & " AND Ano = " & gEmpresa.Ano
Set Rs = OpenRs(DbMain, Q1)
```

**Mapeo Entity Framework:**
```csharp
await _context.AsistImpPrimCat
    .Where(a => a.IdItem == idItem 
             && a.IdEmpresa == empresaId 
             && a.Ano == ano)
    .Select(a => new {
        a.IdAsistImpPrimCat,
        a.RemEjAntNominal,
        a.GeneradoAno
    })
    .FirstOrDefaultAsync();
```

### Query 2: Obtener Base Imponible 14 Ter (IDPC)
```vb
' Ubicación: LoadAll() - Case 1
Q1 = "SELECT Valor FROM BaseImponible14Ter "
Q1 = Q1 & " WHERE TipoBaseImp = " & BASEIMP_TOTALES & " AND IdItemBaseImp = 0"
Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.id & " AND Ano = " & gEmpresa.Ano
Set Rs = OpenRs(DbMain, Q1)
```

**Mapeo Entity Framework:**
```csharp
await _context.BaseImponible14Ter
    .Where(b => b.TipoBaseImp == BASEIMP_TOTALES 
             && b.IdItemBaseImp == 0
             && b.IdEmpresa == empresaId 
             && b.Ano == ano)
    .Select(b => b.Valor)
    .FirstOrDefaultAsync();
```

### Query 3: Obtener Base Imponible Mayor Valor Enajenación
```vb
' Ubicación: LoadAll() - Case 1 (para cálculo)
Q1 = "SELECT Valor FROM BaseImponible14Ter "
Q1 = Q1 & " WHERE TipoBaseImp = " & BASEIMP_TOTALES & " AND IdItemBaseImp = 1"
Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.id & " AND Ano = " & gEmpresa.Ano
Set Rs = OpenRs(DbMain, Q1)
```

**Mapeo Entity Framework:**
```csharp
await _context.BaseImponible14Ter
    .Where(b => b.TipoBaseImp == BASEIMP_TOTALES 
             && b.IdItemBaseImp == 1
             && b.IdEmpresa == empresaId 
             && b.Ano == ano)
    .Select(b => b.Valor)
    .FirstOrDefaultAsync();
```

### Query 4: Actualizar Registro Existente
```vb
' Ubicación: SaveAll() - cuando existe ID
Q1 = "UPDATE AsistImpPrimCat SET "
Q1 = Q1 & "  RemEjAntNominal = " & vFmt(Grid.TextMatrix(Row, C_REMEJANTNOMINAL))
Q1 = Q1 & ", RemEjAntAct = " & vFmt(Grid.TextMatrix(Row, C_REMEJANTACT))
Q1 = Q1 & ", GeneradoAno = " & vFmt(Grid.TextMatrix(Row, C_GENERADOANO))
Q1 = Q1 & ", CredUtilizado = " & vFmt(Grid.TextMatrix(Row, C_CREDUTILIZADO))
Q1 = Q1 & ", RemEjSgte = " & vFmt(Grid.TextMatrix(Row, C_REMEJSGTE))
Q1 = Q1 & " WHERE IdAsistImpPrimCat = " & Grid.TextMatrix(Row, C_ID)
Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.id & " AND Ano = " & gEmpresa.Ano
Call ExecSQL(DbMain, Q1)
```

**Mapeo Entity Framework:**
```csharp
var entity = await _context.AsistImpPrimCat
    .FirstOrDefaultAsync(a => a.IdAsistImpPrimCat == id 
                           && a.IdEmpresa == empresaId 
                           && a.Ano == ano);
if (entity != null)
{
    entity.RemEjAntNominal = dto.RemEjAntNominal;
    entity.RemEjAntAct = dto.RemEjAntAct;
    entity.GeneradoAno = dto.GeneradoAno;
    entity.CredUtilizado = dto.CredUtilizado;
    entity.RemEjSgte = dto.RemEjSgte;
    await _context.SaveChangesAsync();
}
```

### Query 5: Insertar Nuevo Registro
```vb
' Ubicación: SaveAll() - cuando NO existe ID
MaxId = 0
Q1 = "SELECT Max(IdAsistImpPrimCat) FROM AsistImpPrimCat"
Q1 = Q1 & " WHERE IdEmpresa = " & gEmpresa.id & " AND Ano = " & gEmpresa.Ano
Set Rs = OpenRs(DbMain, Q1)
If Not Rs.EOF Then
    MaxId = vFld(Rs(0)) + 1
End If
Call CloseRs(Rs)

Q1 = "INSERT INTO AsistImpPrimCat (IdAsistImpPrimCat, IdItem, RemEjAntNominal, RemEjAntAct, GeneradoAno, CredUtilizado, RemEjSgte, IdEmpresa, Ano )"
Q1 = Q1 & " VALUES(" & MaxId & ", " & Grid.TextMatrix(Row, C_IDITEM)
Q1 = Q1 & ", " & vFmt(Grid.TextMatrix(Row, C_REMEJANTNOMINAL))
Q1 = Q1 & ", " & vFmt(Grid.TextMatrix(Row, C_REMEJANTACT))
Q1 = Q1 & ", " & vFmt(Grid.TextMatrix(Row, C_GENERADOANO))
Q1 = Q1 & ", " & vFmt(Grid.TextMatrix(Row, C_CREDUTILIZADO))
Q1 = Q1 & ", " & vFmt(Grid.TextMatrix(Row, C_REMEJSGTE))
Q1 = Q1 & ", " & gEmpresa.id
Q1 = Q1 & ", " & gEmpresa.Ano & ")"
Call ExecSQL(DbMain, Q1)
```

**Mapeo Entity Framework:**
```csharp
var entity = new App.Data.AsistImpPrimCat
{
    IdAsistImpPrimCat = await GetNextIdAsync(empresaId, ano),
    IdEmpresa = empresaId,
    Ano = ano,
    IdItem = dto.IdItem,
    RemEjAntNominal = dto.RemEjAntNominal,
    RemEjAntAct = dto.RemEjAntAct,
    GeneradoAno = dto.GeneradoAno,
    CredUtilizado = dto.CredUtilizado,
    RemEjSgte = dto.RemEjSgte
};
_context.AsistImpPrimCat.Add(entity);
await _context.SaveChangesAsync();
```

---

## ✅ VALIDACIONES Y REGLAS DE NEGOCIO

### Validaciones de Campos
| Campo | Regla | Implementar en .NET |
|-------|-------|---------------------|
| RemEjAntNominal | Numérico, opcional | ValidateNumericInput() |
| GeneradoAno | Numérico, opcional | ValidateNumericInput() |
| Crédito 33 bis | Máximo 500 UTM (topear) | ValidateCred33bisLimit() |
| Todos los valores | Solo editar rows 4 y 5 (IdItem 4 y 5) | EnforceEditableRows() |

### Reglas de Negocio Críticas

1. **Cálculo IDPC Base Imponible (IdItem 1)**:
   - Obtener valor de BaseImponible14Ter (TipoBaseImp=TOTALES, IdItemBaseImp=0)
   - Multiplicar por tasa gImpPrimCategoria (constante global)
   - Resultado es lIDPCBaseImp (usado en cálculos posteriores)

2. **Crédito 33 bis (IdItem 3)**:
   - Obtener valor de GetValAjustesELC(TAEC_AGREGADOS, 6)
   - Topar a máximo 500 UTM (consultar valor UTM al 31/12 del año)
   - CredUtilizado = min(lIDPCBaseImp, GeneradoAno)

3. **Actualización Remanentes Anteriores**:
   - Factor = GetFactorCM(31/12 del año anterior)
   - RemEjAntAct = RemEjAntNominal * Factor

4. **Crédito Ingreso Diferido Utilizado (IdItem 4)**:
   - Total disponible = RemEjAntAct + GeneradoAno
   - Límite superior = lIDPCBaseImp - lCred33bisUtilizado
   - CredUtilizado = min(Total disponible, Límite superior)

5. **Crédito Retiros Utilizado (IdItem 5)**:
   - Total disponible = RemEjAntAct + GeneradoAno
   - Límite superior = lIDPCBaseImp - lCred33bisUtilizado - CredUtilizadoIngDif
   - CredUtilizado = min(Total disponible, Límite superior)
   - RemEjSgte = Total disponible - CredUtilizado

6. **IDPC Neto a Pagar (IdItem 6)**:
   - CredUtilizado = lIDPCBaseImp - lCred33bisUtilizado - CredUtilIng - CredUtilRetiros

7. **Mayor Valor Enajenación (IdItem 7)**:
   - Obtener lMayorValorEnajenación de BaseImponible14Ter (IdItemBaseImp=1)
   - CredUtilizado = lMayorValorEnajenación * gImpPrimCategoria

8. **IDPC a Pagar Total (IdItem 8)**:
   - CredUtilizado = (MayorValorEnajenación) * gImpPrimCategoria

---

## 🧮 CÁLCULOS Y FÓRMULAS

### Variables Globales Usadas
- `gEmpresa.id`: ID de la empresa actual
- `gEmpresa.Ano`: Año contable actual
- `gImpPrimCategoria`: Tasa impuesto primera categoría (ej: 0.27)
- `gStrAsistImpPrimCat(i)`: Array con conceptos de cada ítem
- `C_MAX_ASISTIMPPRIMCAT`: Cantidad máxima de ítems (constante)
- `BASEIMP_TOTALES`: Constante para tipo base imponible
- `TAEC_AGREGADOS`: Constante para tipo ajuste extra contable

### Variables Locales Módulo
```vb
Dim lIDPCBaseImp As Double           ' IDPC sobre base imponible calculado
Dim lGeneradoAno As Double           ' Crédito 33 bis generado en año
Dim lCred33bisUtilizado As Double    ' Crédito 33 bis utilizado
Dim lMayorValorEnajenación As Double ' Mayor valor enajenación acciones

Dim lRowCredIng As Integer           ' Índice fila crédito ingreso diferido
Dim lRowCredRetiros As Integer       ' Índice fila crédito retiros
Dim lRowIDPCNetoPagar As Integer     ' Índice fila IDPC neto a pagar
Dim lRowIDPCPagar As Integer         ' Índice fila IDPC total a pagar
Dim lRowMayorValorEnajenacion As Integer ' Índice fila mayor valor enajenación
```

### Fórmulas Detalladas

**1. Factor de Actualización:**
```
Factor = GetFactorCM(DateSerial(gEmpresa.Ano - 1, 12, 1))
// Obtiene factor corrección monetaria para actualizar valores del año anterior
```

**2. IDPC Base Imponible:**
```
lIDPCBaseImp = BaseImponible14Ter.Valor * gImpPrimCategoria
```

**3. Crédito 33 bis:**
```
Generado = GetValAjustesELC(TAEC_AGREGADOS, 6)
TopeUTM = 500 * ValorUTM(31/12/Ano)
GeneradoTopeado = min(Generado, TopeUTM)
lCred33bisUtilizado = min(lIDPCBaseImp, GeneradoTopeado)
```

**4. Remanente Anterior Actualizado:**
```
RemEjAntAct = RemEjAntNominal * Factor
```

**5. Crédito Ingreso Diferido Utilizado:**
```
Disponible = RemEjAntAct + GeneradoAno
LimiteSuper = lIDPCBaseImp - lCred33bisUtilizado
CredUtilizado = min(Disponible, LimiteSuper)
```

**6. Crédito Retiros Utilizado:**
```
Disponible = RemEjAntAct + GeneradoAno
LimiteSuper = lIDPCBaseImp - lCred33bisUtilizado - CredUtilIngDif
CredUtilizado = min(Disponible, LimiteSuper)
RemEjSgte = Disponible - CredUtilizado
```

**7. IDPC Neto a Pagar:**
```
NetoPagar = lIDPCBaseImp - lCred33bisUtilizado - CredUtilIngDif - CredUtilRetiros
```

**8. Mayor Valor Enajenación:**
```
MayorValorCredito = lMayorValorEnajenación * gImpPrimCategoria
```

**9. IDPC Total a Pagar:**
```
TotalPagar = MayorValorCredito * gImpPrimCategoria
```

---

## 🚀 NAVEGACIÓN Y FLUJO

### Formularios Llamados
| Desde VB6 | Formulario Destino | Parámetros | Condición | Mapeo .NET |
|-----------|-------------------|------------|-----------|------------|
| Bt_DetDoc_Click | FrmBaseImponible | Ninguno | IdItem=1 o 7, Col=C_CREDUTILIZADO | Modal /BaseImponible/Index |
| Bt_DetDoc_Click | FrmAjustesExtraLibCaja | Ninguno | IdItem=3, Col=C_GENERADOANO | Modal /AjustesExtraContablesCaja/Index |
| Bt_Preview_Click | FrmPrintPreview | Grid data | Siempre | PreviewModal con iframe PDF |
| Bt_Sum_Click | FrmSumSimple | Grid | Siempre | Modal calculadora suma |
| Bt_ConvMoneda_Click | FrmConverMoneda | Ninguno | Siempre | Modal conversor monedas |
| Bt_Calendar_Click | FrmCalendar | Fecha | Siempre | Modal calendario |

### Flujo de Estados del Form
```
[Inicio] → Form_Load() → SetUpGrid() → LoadAll() → [Estado: Visualizando/Editando]
  ↓
[Usuario edita celda] → Grid_AcceptValue() → CalcTot() → [Estado: Modificado]
  ↓
[Bt_OK] → valida() → SaveAll() → Unload → [Cerrado]
  ↓
[Bt_Cancelar] → Unload → [Cerrado sin guardar]

[Grid_DblClick] → Bt_DetDoc_Click → [Abre Modal Detalle]
```

---

## 📊 EXPORTACIONES E IMPORTACIONES

### Exportación a Impresión
- **Botón**: Bt_Print_Click
- **Formato**: Impresión directa a impresora
- **Configuración**: Orientación vertical, títulos incluidos, anchos ajustados
- **Contenido**: Toda la grilla con formato (bold, líneas)

### Exportación a Excel/Portapapeles
- **Botón**: Bt_CopyExcel_Click
- **Formato**: Texto tabulado para pegar en Excel
- **Función**: LP_FGr2String(Grid, Caption)
- **Destino**: Clipboard de Windows

### Vista Previa
- **Botón**: Bt_Preview_Click
- **Formato**: Preview en pantalla antes de imprimir
- **Modal**: FrmPrintPreview

---

## 🎯 MAPEO FINAL: MÉTODOS .NET DETERMINADOS

### Interface del Service
```csharp
public interface IAsistenteImportacionPrimeraCategoriaService
{
    // Obtener Datos
    Task<IEnumerable<AsistenteImportacionPrimeraCategoriaDto>> GetAllItemsAsync(int empresaId, int ano);
    Task<AsistenteImportacionPrimeraCategoriaDto?> GetByIdAsync(int id);
    
    // Guardar (Create/Update masivo)
    Task<ValidationResult> SaveAllAsync(int empresaId, int ano, List<AsistenteImportacionPrimeraCategoriaDto> items);
    
    // Cálculos
    Task<CalculationResult> CalculateTotalsAsync(int empresaId, int ano, List<AsistenteImportacionPrimeraCategoriaDto> items);
    Task<double> GetFactorActualizacionAsync(int anoAnterior);
    Task<double> GetBaseImponibleIDPCAsync(int empresaId, int ano);
    Task<double> GetMayorValorEnajenacionAsync(int empresaId, int ano);
    Task<double> GetCredito33bisAsync(int empresaId, int ano);
    Task<double> GetValorUTMAsync(int ano);
    
    // Validaciones
    Task<ValidationResult> ValidateAsync(List<AsistenteImportacionPrimeraCategoriaDto> items);
    
    // Exportaciones
    Task<byte[]> ExportToPdfAsync(int empresaId, int ano);
    Task<string> ExportToClipboardAsync(int empresaId, int ano);
}
```

### Resumen de Mapeo
| Funcionalidad VB6 | Método .NET | Complejidad | Prioridad |
|-------------------|-------------|-------------|-----------|
| Form_Load → SetUpGrid + LoadAll | GetAllItemsAsync() | Alta | Alta |
| Bt_OK → SaveAll | SaveAllAsync() | Alta | Alta |
| Grid_AcceptValue → CalcTot | CalculateTotalsAsync() | Alta | Alta |
| LoadAll Case 1 | GetBaseImponibleIDPCAsync() | Media | Alta |
| LoadAll Case 3 | GetCredito33bisAsync() | Alta | Alta |
| CalcTot (completo) | CalculateTotalsAsync() | Alta | Alta |
| valida() | ValidateAsync() | Baja | Media |
| Bt_Print | ExportToPdfAsync() | Media | Media |
| Bt_CopyExcel | ExportToClipboardAsync() | Baja | Baja |
| Bt_DetDoc | Navigation a otras features | Baja | Media |
| Bt_Preview | ExportToPdfAsync() + Preview | Media | Media |
| Bt_Sum, Bt_Calc, Bt_Calendar | Utilidades genéricas | Baja | Baja |

---

## ⚠️ NOTAS IMPORTANTES Y OBSERVACIONES

### Peculiaridades del Form VB6
- **Dependencia de constantes globales**: `gEmpresa`, `gImpPrimCategoria`, `gStrAsistImpPrimCat`, `BASEIMP_TOTALES`, etc.
  - En .NET: pasar como parámetros o configuración
- **Array de conceptos**: `gStrAsistImpPrimCat(i)` define los conceptos de cada ítem
  - En .NET: definir enum o diccionario con conceptos
- **Grilla con formato complejo**: Celdas con estilos (bold, colores, alineación) y editabilidad selectiva
  - En .NET: usar librería de grilla JavaScript (ej: AG Grid, jqGrid) o tabla HTML con estilos dinámicos
- **Cálculos encadenados**: Modificar una celda recalcula cascada de valores
  - En .NET: implementar lógica reactiva en JavaScript o recalcular server-side

### Decisiones de Diseño
- **Grilla editable**: Usar tabla HTML con inputs en celdas editables
- **Cálculos en tiempo real**: JavaScript calcula al editar, luego persiste con SaveAll
- **Separación de lógica**: Service contiene toda la lógica de cálculo compleja
- **Modales para detalles**: Usar SweetAlert2 o modales Bootstrap para abrir detalles
- **Exports**: PDF server-side, clipboard client-side con JavaScript

### Integraciones Externas
- **GetValAjustesELC()**: Función VB6 que consulta ajustes extra contables
  - Mapeo: Llamar a service de AjustesExtraContablesCaja
- **GetFactorCM()**: Función VB6 que obtiene factor corrección monetaria
  - Mapeo: Consultar tabla de factores o API externa
- **GetValMoneda()**: Función VB6 que obtiene valor de moneda (UTM)
  - Mapeo: Consultar tabla Monedas o servicio externo

### Funcionalidades Legacy a Migrar
- **Bt_Print**: Imprimir directo a impresora → Exportar PDF e imprimir desde navegador
- **Bt_Preview**: Vista previa VB6 → Modal con iframe PDF
- **Bt_CopyExcel**: Clipboard VB6 → Clipboard API de navegador
- **Bt_Calc**: Calculadora Windows → Calculadora web o mensaje informativo
- **Bt_Calendar**: Calendario VB6 → Input type="date" o librería de calendario
- **Bt_Sum**: Suma simple VB6 → Calculadora modal JavaScript
- **Bt_ConvMoneda**: Conversor VB6 → Modal conversor web

### Botones con Excepciones Válidas
| Botón | Razón Excepción | Implementación |
|-------|----------------|----------------|
| Bt_Calc | Tecnología legacy (Calculadora Windows) | TODO: [LEGACY] [LOW] Usar calculadora web o dejar botón informativo |
| Bt_Calendar | Funcionalidad reemplazada | Implementar con input date o flatpickr |
| Bt_ConvMoneda | Depende de feature no migrada | TODO: [BLOCKED] [MEDIUM] [BLOCKED_BY: Monedas_Feature] |
| Bt_Sum | Utilidad menor | Implementar calculadora simple en modal |

### Pendientes/Incompletos en VB6
- Función `valida()` siempre retorna True → **Implementar validaciones reales** en .NET
- No hay validación de rangos o valores negativos → **Agregar** en ValidateAsync()

---

## ✅ CHECKLIST DE COMPLETITUD DEL ANÁLISIS

- [x] Todos los controles UI documentados
- [x] Todos los botones y eventos mapeados
- [x] **TODOS los botones tienen "Mapeo .NET" definido**
- [x] **Botones con excepciones documentan razón válida** (LEGACY, BLOCKED)
- [x] Todas las funciones VB6 identificadas
- [x] Todos los queries SQL traducidos a EF Core
- [x] Todas las validaciones documentadas
- [x] Todas las reglas de negocio identificadas
- [x] Todos los cálculos documentados (fórmulas detalladas)
- [x] Navegación y flujos mapeados
- [x] Métodos .NET determinados
- [x] Interface del Service definida
- [x] **Decisiones de excepción justificadas y estructuradas**

---

**✅ ANÁLISIS COMPLETO - LISTO PARA IMPLEMENTACIÓN**

Este análisis exhaustivo permite implementar la feature completa sin necesidad de consultar el código VB6 original.
