using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.AsistenteImportacionPrimeraCategoria;

public class AsistenteImportacionPrimeraCategoriaController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<AsistenteImportacionPrimeraCategoriaController> logger) : Controller
{
    public Task<IActionResult> Index()
    {
        logger.LogInformation("Loading AsistenteImportacionPrimeraCategoria Index for empresaId: {EmpresaId}, ano: {Ano}",
            SessionHelper.EmpresaId, SessionHelper.Ano);

            
        ViewData["Title"] = "Asistente de c�lculo Impuesto de Primera Categor�a";

        return Task.FromResult<IActionResult>(View());
    }

    /// <summary>
    /// MVC Proxy: Obtener datos
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetDatos(int empresaId, short ano)
    {
        logger.LogInformation("AsistenteImportacionPrimeraCategoria: GetDatos proxy called for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AsistenteImportacionPrimeraCategoriaApiController.GetDatos),
                controller: nameof(AsistenteImportacionPrimeraCategoriaApiController).Replace("Controller", ""),
                values: new { empresaId, ano }
            );
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// MVC Proxy: Calcular/Recalcular
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Calculate(int empresaId, short ano, [FromBody] JsonElement request)
    {
        logger.LogInformation("AsistenteImportacionPrimeraCategoria: Calculate proxy called for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AsistenteImportacionPrimeraCategoriaApiController.Calculate),
                controller: nameof(AsistenteImportacionPrimeraCategoriaApiController).Replace("Controller", ""),
                values: new { empresaId, ano }
            );
            var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// MVC Proxy: Guardar
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Save(int empresaId, short ano, [FromBody] JsonElement request)
    {
        logger.LogInformation("AsistenteImportacionPrimeraCategoria: Save proxy called for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AsistenteImportacionPrimeraCategoriaApiController.Save),
                controller: nameof(AsistenteImportacionPrimeraCategoriaApiController).Replace("Controller", ""),
                values: new { empresaId, ano }
            );
            var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// MVC Proxy: Exportar PDF
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ExportPdf(int empresaId, short ano)
    {
        logger.LogInformation("AsistenteImportacionPrimeraCategoria: ExportPdf proxy called for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AsistenteImportacionPrimeraCategoriaApiController.ExportPdf),
                controller: nameof(AsistenteImportacionPrimeraCategoriaApiController).Replace("Controller", ""),
                values: new { empresaId, ano }
            );
            var (fileBytes, contentType) = await client.DownloadFileAsync(url, HttpMethod.Get);
            return File(fileBytes, contentType);
        }
    }

    /// <summary>
    /// MVC Proxy: Exportar para portapapeles (Excel)
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ExportClipboard(int empresaId, short ano)
    {
        logger.LogInformation("AsistenteImportacionPrimeraCategoria: ExportClipboard proxy called for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AsistenteImportacionPrimeraCategoriaApiController.ExportClipboard),
                controller: nameof(AsistenteImportacionPrimeraCategoriaApiController).Replace("Controller", ""),
                values: new { empresaId, ano }
            );
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }
}