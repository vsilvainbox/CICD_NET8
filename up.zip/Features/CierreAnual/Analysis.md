# Legacy Analysis: Cierre Anual (Cierre de Ejercicio)

## 📄 VB6 Form Information
**File:** `vb6/Contabilidad70/HyperContabilidad/FrmCierreAnual.frm`
**Lines of Code:** 389
**Purpose:** Realiza el cierre del período contable anual. Este proceso es irreversible y cierra todos los meses del año, calcula el remanente de IVA crédito para el año siguiente, y almacena los correlativos finales de comprobantes.

## 🎯 Business Logic Overview

Este formulario ejecuta el **cierre de ejercicio anual**, un proceso crítico que:

1. **Cierra todos los meses abiertos** del año actual
2. **Calcula el remanente de IVA crédito** en UTM para traspaso al año siguiente
3. **Almacena correlativos finales** de comprobantes (según configuración)
4. **Calcula saldo final del Libro de Caja** para apertura del próximo año
5. **Traspasa configuraciones SII** de diciembre a enero del año siguiente
6. **Marca la fecha de cierre** (irreversible - no se puede deshacer)

**⚠️ ADVERTENCIA CRÍTICA:** Este proceso es **IRREVERSIBLE**. Una vez cerrado el año, no se pueden modificar datos del período.

## 🎮 Controls Identified

### Form Properties
| Property | Value | Purpose |
|----------|-------|---------|
| Caption | "Cierre Período" | Window title |
| StartUpPosition | 2 'CenterScreen | Center on screen |
| BorderStyle | 3 'Fixed Dialog | Non-resizable window |
| MaxButton | False | No maximize button |
| MinButton | False | No minimize button |

### Labels
| Control Name | Caption/Value | Purpose |
|--------------|---------------|---------|
| Label1(0) | "Cierre año" | Fixed label |
| Label1(1) | "2005" (dynamic) | Shows year to close (gEmpresa.Ano) |

### Buttons
| Control Name | Caption | Action | Permission | Mapeo .NET |
|--------------|---------|--------|------------|------------|
| Bt_CerrarAno | "Cerrar Período" | Executes annual close process | PRV_ADM_EMPRESA | ExecuteAnnualCloseAsync() |
| Bt_Cerrar | "Cancelar" | Closes form without action | None | N/A (browser navigation) |

### Progress Bar
| Control | Purpose |
|---------|---------|
| ProgressBar | Shows visual progress during close process (0-100) |

### Image
| Control | Purpose |
|---------|---------|
| Image2 | Icon/logo displayed on form |

## 🔧 Functions and Procedures

### Form_Load()
**Purpose:** Initializes form on load
**Logic:**
```vb
Label1(1) = gEmpresa.Ano                          ' Display year to close
Call EnableForm(Me, gEmpresa.FCierre = 0)         ' Disable if already closed
Call SetupPriv                                     ' Check permissions
```

**Mapeo .NET:**
- MVC Controller: Pass year and close status via ViewData
- JavaScript: Disable button if year already closed

---

### SetupPriv()
**Purpose:** Configures permissions for closing year
**Logic:**
```vb
If Not ChkPriv(PRV_ADM_EMPRESA) Then
   Call EnableForm(Me, False)    ' Disable entire form
End If
```

**Permission Required:** `PRV_ADM_EMPRESA` (Empresa Administration privilege)

**Mapeo .NET:**
- Check permissions in API controller using `[Authorize]` attribute or service layer check

---

### Bt_CerrarAno_Click() - MAIN PROCESS
**Purpose:** Executes the complete annual close process
**This is the MOST COMPLEX function - 270+ lines**

#### Step-by-Step Process:

#### **STEP 1: Validate Printed Books**
```vb
If LibAnualesImpresos(True) = False Then
   Exit Sub
End If
```
- Validates that annual books have been printed
- User must confirm or acknowledge printing requirement

**Mapeo .NET:**
```csharp
var booksValidation = await ValidateAnnualBooksPrintedAsync(empresaId, ano);
if (!booksValidation.Success)
{
    return ValidationResult.Fail(booksValidation.Message);
}
```

---

#### **STEP 2: User Confirmation**
```vb
Msg = "Recuerde que al hacer cierre anual no podrá volver a modificar datos de este año. ¿Desea continuar?"
If MsgBox1(Msg, vbQuestion Or vbYesNo Or vbDefaultButton2) <> vbYes Then
   Exit Sub
End If
```

**Mapeo .NET:**
- Show SweetAlert2 confirmation dialog in JavaScript
- Message: "Recuerde que al hacer cierre anual no podrá volver a modificar datos de este año. ¿Desea continuar?"

---

#### **STEP 3: Get Last Correlative Number (Comprobantes)**
**Purpose:** Store the last correlative number used for each type of comprobante

**Logic depends on configuration:**

**Case A: Continuous Period + Unique Correlative (TCC_CONTINUO + TCC_UNICO)**
```vb
Q1 = "SELECT Max(Correlativo) FROM Comprobante WHERE IdEmpresa = " & gEmpresa.Id & " AND Ano = " & gEmpresa.Ano
Set Rs = OpenRs(DbMain, Q1)
MaxCorr = vFld(Rs(0))
```

**Case B: Continuous Period + Correlative by Type (TCC_CONTINUO + per type)**
```vb
Q1 = "SELECT Tipo, Max(Correlativo) as LastComp FROM Comprobante "
Q1 = Q1 & " WHERE IdEmpresa = " & gEmpresa.Id & " AND Ano = " & gEmpresa.Ano & " GROUP BY Tipo"
Set Rs = OpenRs(DbMain, Q1)

Do While Rs.EOF = False
   LastComp(vFld(Rs("Tipo"))) = vFld(Rs("LastComp"))
   Rs.MoveNext
Loop
```

**Mapeo .NET:**
```csharp
// Check configuration: gPerCorrComp and gTipoCorrComp
if (perCorrComp == TCC_CONTINUO)
{
    if (tipoCorrComp == TCC_UNICO)
    {
        maxCorr = await _context.Comprobante
            .Where(c => c.IdEmpresa == empresaId && c.Ano == ano)
            .MaxAsync(c => (int?)c.Correlativo) ?? 0;
    }
    else
    {
        lastCompByType = await _context.Comprobante
            .Where(c => c.IdEmpresa == empresaId && c.Ano == ano)
            .GroupBy(c => c.Tipo)
            .Select(g => new { Tipo = g.Key, LastComp = g.Max(c => c.Correlativo) })
            .ToListAsync();
    }
}
```

---

#### **STEP 4: Close All Open Months**
```vb
Set Rs = OpenRs(DbMain, "SELECT Mes, Estado FROM EstadoMes WHERE IdEmpresa = " & gEmpresa.Id & " AND Ano = " & gEmpresa.Ano)

Do While Rs.EOF = False
   If vFld(Rs("Estado")) = EM_ABIERTO Then
      Call CerrarMes(vFld(Rs("Mes")))
   End If
   Rs.MoveNext
Loop
```

**Mapeo .NET:**
```csharp
var openMonths = await _context.EstadoMes
    .Where(e => e.IdEmpresa == empresaId && e.Ano == ano && e.Estado == EM_ABIERTO)
    .ToListAsync();

foreach (var month in openMonths)
{
    await CloseMonthAsync(empresaId, ano, month.Mes.Value);
}
```

---

#### **STEP 5: Calculate IVA Remainder (Remanente IVA Crédito)**
**⚠️ MOST COMPLEX CALCULATION** - Lines 173-309

**Purpose:** Calculate IVA credit remainder to transfer to next year

**Variables:**
- `RemIVAUTM`: IVA remainder in UTM (Unidad Tributaria Mensual)
- `TotIVACred`: Total IVA Credit
- `TotIVADeb`: Total IVA Debit
- `IVAIrrec`: IVA Irrecuperable (non-recoverable VAT)
- `IVARetParcial`: IVA Retenido Parcial (partial withholding)
- `IVARetTotal`: IVA Retenido Total (total withholding)
- `TotIEPDGen`: Total IEPD General (diesel tax)
- `TotIEPDTransp`: Total IEPD Transporte (transport diesel tax)
- `ValUTM`: UTM value
- `remMesAnt`: Flag indicating if previous month had a remainder

**Process (for each month 1-12):**
```vb
For i = 1 To 13 - 1  ' Loop through months 1-12

    ' Get IVA summary for month
    Call GetResIVA(i, Val(gEmpresa.Ano), TotIVACred, TotIVADeb, TotIEPDGen, TotIEPDTransp)

    ' Get other taxes (IVA Irrecuperable, IVA Retenido)
    Call GenResOImp(Where, ResOImp)

    ' Extract specific tax values
    For x = 0 To UBound(ResOImp)
        If ResOImp(x).TipoLib = LIB_COMPRAS And (ResOImp(x).CodValLib = LIBCOMPRAS_IVAIRREC ...) Then
            IVAIrrec = ResOImp(x).valor
        End If

        If ResOImp(x).TipoLib = LIB_VENTAS And ResOImp(x).TipoIVARetenido = IVARET_PARCIAL Then
            IVARetParcial = ResOImp(x).valor
        End If

        If ResOImp(x).TipoLib = LIB_VENTAS And ResOImp(x).TipoIVARetenido = IVARET_TOTAL Then
            IVARetTotal = ResOImp(x).valor
        End If
    Next x

    ' Adjust totals
    TotIVACred = TotIVACred - IVAIrrec
    TotIVADeb = TotIVADeb - IVARetParcial - IVARetTotal

    ' Get monthly IVA adjustment
    AjusteIvaMen = GetAjusteIVAMensual(i)

    ' Calculate net IVA for month
    vTotalRemMesAnt = TotIVADeb - (TotIVACred + TotIEPDGen + TotIEPDTransp + TotRemMesAnt + vFmt(AjusteIvaMen))

    ' Determine if there's a remainder (negative = credit)
    If vTotalRemMesAnt < 0 Then
        remMesAnt = True
    Else
        remMesAnt = False
    End If

Next i

' Convert final remainder to UTM
If ValUTM = 0 Then
    RemIVAUTM = 0
    MsgBox1 "No se encontró el valor de la UTM para calcular Remanente Crédito IVA para año siguiente.", vbExclamation
Else
    If remMesAnt = True Then
        RemIVAUTM = Format(vFmt(Format(Abs(vTotalRemMesAnt), NEGNUMFMT)) / ValUTM, DBLFMT2)
    End If
End If
```

**Mapeo .NET:**
```csharp
// This is simplified - actual implementation requires complex IVA calculation functions
double remIVAUTM = 0;
double vTotalRemMesAnt = 0;
bool remMesAnt = false;

for (int mes = 1; mes <= 12; mes++)
{
    // Get IVA summary for month
    var ivaSummary = await GetIvaSummaryAsync(empresaId, ano, mes);

    // Get other taxes
    var otherTaxes = await GetOtherTaxesAsync(empresaId, ano, mes);

    // Calculate net IVA
    double totIVACred = ivaSummary.TotalCredito - otherTaxes.IVAIrrecuperable;
    double totIVADeb = ivaSummary.TotalDebito - otherTaxes.IVARetenidoParcial - otherTaxes.IVARetenidoTotal;

    // Get monthly adjustment
    double ajusteIvaMen = await GetMonthlyIvaAdjustmentAsync(empresaId, ano, mes);

    // Calculate remainder
    vTotalRemMesAnt = totIVADeb - (totIVACred + ivaSummary.TotalIEPDGen + ivaSummary.TotalIEPDTransp + totRemMesAnt + ajusteIvaMen);

    remMesAnt = vTotalRemMesAnt < 0;
}

// Convert to UTM
double valUTM = await GetUTMValueAsync(new DateTime(ano, 12, 31));
if (valUTM > 0 && remMesAnt)
{
    remIVAUTM = Math.Abs(vTotalRemMesAnt) / valUTM;
}
```

---

#### **STEP 6: Calculate Final Libro Caja Balance**
```vb
SaldoAper = ObtenerMontoAperturaInicial(3)  ' Get opening balance

Q1 = "SELECT Sum(Ingreso) as Ingresos, Sum(Egreso) as Egresos FROM LibroCaja "
Q1 = Q1 & " WHERE IdEmpresa = " & gEmpresa.Id & " AND Ano = " & gEmpresa.Ano

Set Rs = OpenRs(DbMain, Q1)
If Not Rs.EOF Then
   SaldoLibroCaja = vFld(Rs("Ingresos")) - vFld(Rs("Egresos"))
End If
```

**Mapeo .NET:**
```csharp
var saldoAper = await GetInitialOpeningBalanceAsync(empresaId, ano, 3);

var libroCajaSummary = await _context.LibroCaja
    .Where(lc => lc.IdEmpresa == empresaId && lc.Ano == ano)
    .GroupBy(lc => 1)
    .Select(g => new
    {
        TotalIngresos = g.Sum(lc => lc.Ingreso ?? 0),
        TotalEgresos = g.Sum(lc => lc.Egreso ?? 0)
    })
    .FirstOrDefaultAsync();

double saldoLibroCaja = (libroCajaSummary?.TotalIngresos ?? 0) - (libroCajaSummary?.TotalEgresos ?? 0);
```

---

#### **STEP 7: Update EmpresasAno Table**
```vb
F1 = CLng(Int(Now))  ' Current date as integer (YYYYMMDD format)

Q1 = "UPDATE EmpresasAno SET FCierre=" & F1
Q1 = Q1 & ", NumLastCompUnico=" & MaxCorr

' Store last correlative for each type
For i = 1 To N_TIPOCOMP
   Q1 = Q1 & ", NumLastComp" & Left(gTipoComp(i), 1) & "=" & LastComp(i)
Next i

Q1 = Q1 & ", RemIVAUTM = " & Str(RemIVAUTM)
Q1 = Q1 & ", SaldoLibroCaja = " & SaldoLibroCaja

Q1 = Q1 & " WHERE idEmpresa=" & gEmpresa.Id & " AND Ano=" & gEmpresa.Ano

Call ExecSQL(DbMain, Q1)
```

**Mapeo .NET:**
```csharp
var empresaAno = await _context.EmpresasAno
    .FirstOrDefaultAsync(ea => ea.IdEmpresa == empresaId && ea.Ano == ano);

if (empresaAno != null)
{
    empresaAno.FCierre = GetDateAsInt(DateTime.Now);
    empresaAno.NumLastCompUnico = maxCorr;
    empresaAno.NumLastCompI = lastCompI;
    empresaAno.NumLastCompE = lastCompE;
    empresaAno.NumLastCompT = lastCompT;
    // ... other types
    empresaAno.RemIVAUTM = remIVAUTM;
    empresaAno.SaldoLibroCaja = saldoLibroCaja;

    _context.EmpresasAno.Update(empresaAno);
    await _context.SaveChangesAsync();
}
```

---

#### **STEP 8: Transfer SII Configurations**
```vb
Q1 = "INSERT INTO ConfiguraSincronizacionSII (IdEmpresa, Tipo_Libro, Contador, Fecha_Sincroniza, Fecha_Ejecucion, Fecha_Creacion, IdUsuario) "
Q1 = Q1 & "SELECT IdEmpresa, Tipo_Libro, Contador, DATEADD(MONTH, 1, Fecha_Sincroniza), Fecha_Ejecucion, GETDATE(), IdUsuario "
Q1 = Q1 & "FROM ConfiguraSincronizacionSII WHERE MONTH(Fecha_Sincroniza)=12 AND YEAR(Fecha_Sincroniza)=YEAR(GETDATE()) AND IdEmpresa=" & gEmpresa.Id
```

**Purpose:** Copy December SII sync configurations to January of next year

**Mapeo .NET:**
```csharp
var decemberConfigs = await _context.ConfiguraSincronizacionSII
    .Where(c => c.IdEmpresa == empresaId &&
                c.Fecha_Sincroniza.HasValue &&
                c.Fecha_Sincroniza.Value.Month == 12 &&
                c.Fecha_Sincroniza.Value.Year == DateTime.Now.Year)
    .ToListAsync();

foreach (var config in decemberConfigs)
{
    var newConfig = new App.Data.ConfiguraSincronizacionSII
    {
        IdEmpresa = config.IdEmpresa,
        Tipo_Libro = config.Tipo_Libro,
        Contador = config.Contador,
        Fecha_Sincroniza = config.Fecha_Sincroniza?.AddMonths(1),
        Fecha_Ejecucion = config.Fecha_Ejecucion,
        Fecha_Creacion = DateTime.Now,
        IdUsuario = config.IdUsuario
    };
    _context.ConfiguraSincronizacionSII.Add(newConfig);
}

await _context.SaveChangesAsync();
```

---

#### **STEP 9: Update Progress Bar and Audit**
```vb
For i = 1 To 100
   Sleep (10)
   ProgressBar.Value = i
Next i

Call SeguimientoCierreApertura(2, "Cierre Anual")
```

**Mapeo .NET:**
- Progress bar: Use JavaScript with async/await and progress callbacks
- Audit: Call audit/tracking function

---

### bt_Cerrar_Click()
**Purpose:** Closes form without action
**Logic:**
```vb
Unload Me
```

**Mapeo .NET:**
- JavaScript: `window.history.back()` or redirect to dashboard

---

## 💾 Data Access

### Database Tables Used

#### **EstadoMes** (Read/Write)
```sql
SELECT Mes, Estado FROM EstadoMes
WHERE IdEmpresa = ? AND Ano = ?
```
- Purpose: Get all months to close open ones

#### **Comprobante** (Read)
```sql
-- Case 1: Unique correlative
SELECT Max(Correlativo) FROM Comprobante
WHERE IdEmpresa = ? AND Ano = ?

-- Case 2: By type
SELECT Tipo, Max(Correlativo) as LastComp FROM Comprobante
WHERE IdEmpresa = ? AND Ano = ?
GROUP BY Tipo
```
- Purpose: Get last correlative numbers

#### **LibroCaja** (Read)
```sql
SELECT Sum(Ingreso) as Ingresos, Sum(Egreso) as Egresos
FROM LibroCaja
WHERE IdEmpresa = ? AND Ano = ?
```
- Purpose: Calculate final cash book balance

#### **EmpresasAno** (Write)
```sql
UPDATE EmpresasAno
SET FCierre = ?,
    NumLastCompUnico = ?,
    NumLastCompI = ?,
    NumLastCompE = ?,
    NumLastCompT = ?,
    RemIVAUTM = ?,
    SaldoLibroCaja = ?
WHERE IdEmpresa = ? AND Ano = ?
```
- Purpose: Store close date and summary values

#### **ConfiguraSincronizacionSII** (Read/Write)
```sql
INSERT INTO ConfiguraSincronizacionSII (...)
SELECT IdEmpresa, Tipo_Libro, Contador, DATEADD(MONTH, 1, Fecha_Sincroniza), ...
FROM ConfiguraSincronizacionSII
WHERE MONTH(Fecha_Sincroniza) = 12 AND IdEmpresa = ?
```
- Purpose: Transfer December configs to January

---

## ✅ Validations

### Pre-Close Validations

1. **Books Printed Validation**
   - **Function:** `LibAnualesImpresos(True)`
   - **Rule:** Annual books must be printed (or acknowledged)
   - **Message:** (Handled by LibAnualesImpresos function)

2. **Already Closed Check**
   - **Rule:** Cannot close if `gEmpresa.FCierre != 0`
   - **Action:** Disable entire form if already closed

3. **Permission Check**
   - **Rule:** User must have `PRV_ADM_EMPRESA` privilege
   - **Action:** Disable entire form if no permission

4. **User Confirmation**
   - **Message:** "Recuerde que al hacer cierre anual no podrá volver a modificar datos de este año. ¿Desea continuar?"
   - **Type:** Yes/No dialog with No as default

### Business Rules

1. **Irreversible Process**
   - Once closed, year cannot be reopened
   - FCierre date is permanently stored

2. **All Months Must Close**
   - System automatically closes all open months
   - No partial year close allowed

3. **UTM Validation**
   - Must have UTM value for December to calculate IVA remainder
   - Warning if UTM not found

---

## 🎨 UI/UX Behavior

### Visual Indicators

1. **Year Display**
   - Shows year to close in red color (Label1(1))
   - Static label "Cierre año"

2. **Progress Bar**
   - Shows 0-100% progress during close operation
   - Includes Sleep(10) delays for visual effect

3. **Mouse Pointer**
   - Changes to hourglass during processing
   - Returns to default when complete

### User Interactions

1. **Cerrar Período Button**
   - Disabled if year already closed
   - Disabled if no PRV_ADM_EMPRESA permission
   - Shows confirmation dialog before executing

2. **Cancelar Button**
   - Always enabled
   - Closes form without changes

---

## 🔄 Migration Strategy

### Architecture Pattern

```
User Browser (Razor View)
    ↓
JavaScript (fetch API with progress tracking)
    ↓
MVC Controller (HttpClient)
    ↓
API Controller (REST endpoints)
    ↓
Service Layer (Complex business logic)
    ↓
EF Core (ORM)
    ↓
SQLite Database (Multiple tables)
```

### Technology Stack

- **Backend:** .NET 9, ASP.NET Core MVC, Entity Framework Core 9
- **Database:** SQLite (EstadoMes, Comprobante, LibroCaja, EmpresasAno, ConfiguraSincronizacionSII)
- **Frontend:** Razor Pages, Tailwind CSS, JavaScript (ES6+), SweetAlert2
- **Icons:** Font Awesome 6.4.0

---

## 🎯 Service Methods Determined

Based on VB6 analysis, the following service methods are required:

### ICierreAnualService

```csharp
public interface ICierreAnualService
{
    /// <summary>
    /// Gets the close status and year information
    /// </summary>
    Task<CierreAnualStatusDto> GetCloseStatusAsync(int empresaId, int ano);

    /// <summary>
    /// Validates if annual books have been printed
    /// Maps to: LibAnualesImpresos() in VB6
    /// </summary>
    Task<ValidationResult> ValidateAnnualBooksPrintedAsync(int empresaId, int ano);

    /// <summary>
    /// Executes the complete annual close process
    /// Maps to: Bt_CerrarAno_Click() in VB6
    /// </summary>
    Task<CierreAnualResultDto> ExecuteAnnualCloseAsync(int empresaId, int ano, IProgress<int> progress = null);

    /// <summary>
    /// Gets last correlative numbers for comprobantes
    /// </summary>
    Task<LastCorrelativosDto> GetLastCorrelativosAsync(int empresaId, int ano);

    /// <summary>
    /// Calculates IVA remainder in UTM
    /// Complex calculation involving all months
    /// </summary>
    Task<double> CalculateIvaRemainderAsync(int empresaId, int ano);

    /// <summary>
    /// Calculates final Libro Caja balance
    /// </summary>
    Task<double> CalculateFinalLibroCajaBalanceAsync(int empresaId, int ano);

    /// <summary>
    /// Closes all open months for the year
    /// </summary>
    Task<ValidationResult> CloseAllOpenMonthsAsync(int empresaId, int ano);
}
```

---

## 📋 DTOs Required

### CierreAnualStatusDto
```csharp
public class CierreAnualStatusDto
{
    public int EmpresaId { get; set; }
    public int Ano { get; set; }
    public string NombreEmpresa { get; set; }
    public bool IsClosed { get; set; }
    public DateTime? FechaCierre { get; set; }
    public bool CanClose { get; set; }  // Based on permissions
    public string WarningMessage { get; set; }
}
```

### CierreAnualResultDto
```csharp
public class CierreAnualResultDto
{
    public bool Success { get; set; }
    public string Message { get; set; }
    public DateTime FechaCierre { get; set; }
    public double RemIVAUTM { get; set; }
    public double SaldoLibroCaja { get; set; }
    public int MonthsClosed { get; set; }
    public LastCorrelativosDto LastCorrelativos { get; set; }
}
```

### LastCorrelativosDto
```csharp
public class LastCorrelativosDto
{
    public int? NumLastCompUnico { get; set; }
    public int? NumLastCompI { get; set; }
    public int? NumLastCompE { get; set; }
    public int? NumLastCompT { get; set; }
    public int? NumLastCompO { get; set; }
    // Add other types as needed
}
```

---

## 🚀 API Endpoints Required

```
GET    /api/CierreAnual/status?empresaId={id}&ano={year}
       → Returns CierreAnualStatusDto

POST   /api/CierreAnual/execute
       Body: { empresaId, ano }
       → Returns CierreAnualResultDto
       → Supports progress tracking via SignalR (optional)

GET    /api/CierreAnual/validate-books?empresaId={id}&ano={year}
       → Returns ValidationResult

GET    /api/CierreAnual/preview?empresaId={id}&ano={year}
       → Returns preview data (correlativos, IVA, saldos) without executing
```

---

## ⚠️ Critical Migration Notes

### 1. IVA Calculation Complexity

**VB6 uses complex functions:**
- `GetResIVA()`: Get IVA summary for month
- `GenResOImp()`: Get other taxes
- `GetAjusteIVAMensual()`: Get monthly adjustments
- `GetRemIVAUTM_New()`: Calculate IVA remainder in UTM
- `GetValMoneda()`: Get UTM value

**These functions are NOT in FrmCierreAnual.frm** - they are in external modules.

**Migration Strategy:**
```csharp
// TODO: [INTEGRATION] [HIGH] Implement IVA calculation functions
// These are complex and may require separate service implementations:
// - IvaCalculationService
// - TaxCalculationService
// - MonedaService (for UTM values)

// For initial migration, implement simplified version or mark as TODO
```

### 2. Configuration Dependencies

**VB6 uses global variables:**
- `gPerCorrComp`: Period correlative configuration (TCC_CONTINUO, TCC_ANUAL)
- `gTipoCorrComp`: Type correlative configuration (TCC_UNICO, per type)
- `gTipoComp`: Array of comprobante types

**Migration:**
- Store in Config table or appsettings.json
- Pass as parameters to service methods

### 3. Progress Tracking

**VB6 uses:**
```vb
For i = 1 To 100
   Sleep (10)
   ProgressBar.Value = i
Next i
```

**.NET Approach:**
- Use `IProgress<int>` interface
- Or use SignalR for real-time updates
- Or simple loading indicator without granular progress

### 4. Audit Trail

**VB6 calls:**
```vb
Call SeguimientoCierreApertura(2, "Cierre Anual")
```

**Migration:**
- Implement audit logging in service
- Store in audit table with user, date, action

---

## 🧪 Testing Checklist

- [ ] Display correct year and close status
- [ ] Disable form if year already closed
- [ ] Validate annual books printed (or acknowledged)
- [ ] Show confirmation dialog with correct message
- [ ] Close all open months (1-12)
- [ ] Calculate last correlatives (by configuration)
- [ ] Calculate IVA remainder in UTM (complex)
- [ ] Calculate final Libro Caja balance
- [ ] Update EmpresasAno with close date and summary
- [ ] Transfer SII configurations from December to January
- [ ] Disable form after successful close
- [ ] Permission check: PRV_ADM_EMPRESA required
- [ ] Cannot close already-closed year
- [ ] Progress indication during process
- [ ] Audit trail logged

---

## 📊 Impact Analysis

### Tables Modified
- **EstadoMes** (UPDATE - close all months)
- **EmpresasAno** (UPDATE - set FCierre, correlativos, RemIVAUTM, SaldoLibroCaja)
- **ConfiguraSincronizacionSII** (INSERT - transfer December configs)

### Tables Read
- **EstadoMes** (SELECT - get open months)
- **Comprobante** (SELECT - get last correlativos)
- **LibroCaja** (SELECT - calculate balance)
- **Documento** (SELECT - for IVA calculations)
- **MovDocumento** (SELECT - for IVA calculations)
- **Monedas** (SELECT - get UTM value)

### Related Features
- **Abrir/Cerrar Mes** - Closes all months
- **Apertura** - Opposite process (opens new year)
- **Saldo de Apertura** - Uses values from close process
- **Libro Diario, Mayor, etc.** - Cannot modify after close

---

## 🔗 External Functions Referenced (Not in FrmCierreAnual.frm)

These functions are called but defined elsewhere:

1. **LibAnualesImpresos(True)** - Validates printed books
2. **CerrarMes(Mes)** - Closes a specific month
3. **GetRemIVAUTM_New()** - Calculates IVA remainder
4. **GetResIVA()** - Gets IVA summary for month
5. **GenResOImp()** - Gets other taxes
6. **GetAjusteIVAMensual()** - Gets monthly IVA adjustment
7. **GetValMoneda()** - Gets currency value (UTM)
8. **ObtenerMontoAperturaInicial()** - Gets opening balance
9. **SeguimientoCierreApertura()** - Audit logging
10. **EnableForm()** - Enables/disables form controls
11. **ChkPriv()** - Checks user privileges

**Migration Note:** These functions must be located in VB6 modules and migrated separately or implemented as service methods.

---

## 📝 Final Notes

This form executes **one of the most critical processes** in the accounting system. The cierre anual (annual close) is:

- **IRREVERSIBLE** - Cannot be undone once executed
- **COMPLEX** - Involves multiple calculations and database updates
- **CRITICAL** - Affects all subsequent years
- **REGULATED** - Must comply with Chilean tax regulations (SII)

**Migration Complexity:** **VERY HIGH**
- Complex IVA calculations requiring external functions
- Multiple database tables and transactions
- Audit and compliance requirements
- Progress tracking and user feedback

**Business Logic Complexity:** **VERY HIGH**
- IVA remainder calculation involves 12 months of data
- Multiple tax types and adjustments
- Configuration-dependent behavior

**Database Impact:** **HIGH** (multiple tables updated)

**Estimated .NET Implementation Time:** 20-30 hours (including IVA calculation functions)

---

**Analysis Completed:** 2025-10-02
**VB6 Form Lines Analyzed:** 389
**Status:** Ready for implementation (with external function dependencies noted) ✅
