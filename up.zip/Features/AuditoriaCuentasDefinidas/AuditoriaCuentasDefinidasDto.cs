namespace App.Features.AuditoriaCuentasDefinidas;

/// <summary>
/// DTO para el reporte de auditoría de cuentas definidas.
/// Muestra el historial de cambios realizados en la configuración de cuentas definidas.
/// </summary>
public class AuditoriaCuentasDefinidasDto
{
    /// <summary>
    /// ID de la empresa
    /// </summary>
    public int? IdEmpresa { get; set; }

    /// <summary>
    /// RUT de la empresa formateado (XX.XXX.XXX-X)
    /// </summary>
    public string Rut { get; set; } = string.Empty;

    /// <summary>
    /// Tipo de configuración modificada
    /// </summary>
    public string Configuracion { get; set; } = string.Empty;

    /// <summary>
    /// Tipo de evento (crear, modificar, eliminar)
    /// </summary>
    public string Evento { get; set; } = string.Empty;

    /// <summary>
    /// Cuenta contable asociada
    /// </summary>
    public string CtaAsociado { get; set; } = string.Empty;

    /// <summary>
    /// Código de la cuenta/configuración
    /// </summary>
    public string Codigo { get; set; } = string.Empty;

    /// <summary>
    /// Descripción de la cuenta/configuración
    /// </summary>
    public string Descripcion { get; set; } = string.Empty;

    /// <summary>
    /// Fecha y hora del evento (string en formato dd/mm/yyyy hh:mm)
    /// </summary>
    public string Fecha { get; set; } = string.Empty;

    /// <summary>
    /// Usuario que realizó el cambio
    /// </summary>
    public string Usuario { get; set; } = string.Empty;
}

/// <summary>
/// DTO para items de ComboBox (empresa, usuario, etc.)
/// </summary>
public class ComboItemDto
{
    /// <summary>
    /// Valor del item
    /// </summary>
    public int Value { get; set; }

    /// <summary>
    /// Texto a mostrar
    /// </summary>
    public string Text { get; set; } = string.Empty;
}

/// <summary>
/// DTO para resultado de validaciones
/// </summary>
public class ValidationResult
{
    /// <summary>
    /// Indica si la validación fue exitosa
    /// </summary>
    public bool IsValid { get; set; }

    /// <summary>
    /// Mensaje de error si la validación falló
    /// </summary>
    public string ErrorMessage { get; set; } = string.Empty;
}