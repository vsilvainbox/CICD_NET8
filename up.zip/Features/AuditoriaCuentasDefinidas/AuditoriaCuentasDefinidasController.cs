using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using App.Extensions;

namespace App.Features.AuditoriaCuentasDefinidas;

/// <summary>
/// Controller MVC para la vista de auditoría de cuentas definidas
/// </summary>
[Authorize]

public class AuditoriaCuentasDefinidasController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<AuditoriaCuentasDefinidasController> logger) : Controller
{
    /// <summary>
    /// Muestra la vista principal del reporte de auditoría
    /// </summary>
    public IActionResult Index()
    {
        logger.LogInformation("Vista AuditoriaCuentasDefinidas/Index cargada");

        // Pasar el año actual para la validación de fecha en la vista
        ViewBag.CurrentYear = DateTime.Now.Year;

        return View();
    }

    /// <summary>
    /// Método proxy: Obtiene la lista de empresas disponibles
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetEmpresas()
    {
        {
            logger.LogInformation("MVC Proxy: GetEmpresas");
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AuditoriaCuentasDefinidasApiController.GetEmpresas),
                controller: nameof(AuditoriaCuentasDefinidasApiController).Replace("Controller", ""));
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Método proxy: Obtiene la lista de años disponibles
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetYears()
    {
        {
            logger.LogInformation("MVC Proxy: GetYears");
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AuditoriaCuentasDefinidasApiController.GetYears),
                controller: nameof(AuditoriaCuentasDefinidasApiController).Replace("Controller", ""));
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Método proxy: Obtiene la lista de usuarios disponibles
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetUsuarios()
    {
        {
            logger.LogInformation("MVC Proxy: GetUsuarios");
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AuditoriaCuentasDefinidasApiController.GetUsuarios),
                controller: nameof(AuditoriaCuentasDefinidasApiController).Replace("Controller", ""));
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Método proxy: Obtiene el reporte de auditoría con filtros opcionales
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetFiltered(
        [FromQuery] int? idEmpresa = null,
        [FromQuery] int? annio = null,
        [FromQuery] string? usuario = null,
        [FromQuery] DateTime? fechaDesde = null,
        [FromQuery] DateTime? fechaHasta = null)
    {
        {
            logger.LogInformation("MVC Proxy: GetFiltered");

            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AuditoriaCuentasDefinidasApiController.GetFiltered),
                controller: nameof(AuditoriaCuentasDefinidasApiController).Replace("Controller", ""),
                values: new { idEmpresa, annio, usuario, fechaDesde, fechaHasta });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Método proxy: Exporta el reporte filtrado a Excel
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ExportExcel(
        [FromQuery] int? idEmpresa = null,
        [FromQuery] int? annio = null,
        [FromQuery] string? usuario = null,
        [FromQuery] DateTime? fechaDesde = null,
        [FromQuery] DateTime? fechaHasta = null)
    {
        {
            logger.LogInformation("MVC Proxy: ExportExcel");

            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AuditoriaCuentasDefinidasApiController.ExportExcel),
                controller: nameof(AuditoriaCuentasDefinidasApiController).Replace("Controller", ""),
                values: new { idEmpresa, annio, usuario, fechaDesde, fechaHasta });
            var (fileBytes, contentType) = await client.DownloadFileAsync(url, HttpMethod.Get, null);
            var fileName = $"AuditoriaCuentasDefinidas_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx";

            return File(fileBytes, contentType, fileName);
        }
    }
}