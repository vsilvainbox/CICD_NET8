using Microsoft.EntityFrameworkCore;
using App.Data;
using OfficeOpenXml;
using OfficeOpenXml.Style;

namespace App.Features.BaseImponible14DCompleta;

/// <summary>
/// Implementación del servicio de Base Imponible 14D Completa
/// </summary>
public class BaseImponible14DCompletaService : IBaseImponible14DCompletaService
{
    private readonly LpContabContext _context;
    private readonly ILogger<BaseImponible14DCompletaService> _logger;
    private readonly List<BaseImponibleConfig> _estructuraBase;

    public BaseImponible14DCompletaService(LpContabContext context, ILogger<BaseImponible14DCompletaService> logger)
    {
        _context = context;
        _logger = logger;
        _estructuraBase = InitEstructuraBase();
    }

    public async Task<BaseImponible14DCompletaDto> GetByEmpresaAnoAsync(int empresaId, short ano)
    {
        _logger.LogInformation("Obteniendo base imponible 14D completa para empresa {EmpresaId} año {Ano}", empresaId, ano);

        {
            var result = new BaseImponible14DCompletaDto
            {
                IdEmpresa = empresaId,
                Ano = ano
            };

            // Obtener información de la empresa
            var empresa = await _context.Empresa
                .Where(e => e.Id == empresaId)
                .Select(e => new { e.RazonSocial, e.FranqProPymeGeneral, e.FranqProPymeTransp })
                .FirstOrDefaultAsync();

            if (empresa != null)
            {
                result.NombreEmpresa = empresa.RazonSocial ?? string.Empty;
                result.ProPymeGeneral = empresa.FranqProPymeGeneral == true;
                result.ProPymeTransp = empresa.FranqProPymeTransp == true;
            }
            else
            {
                result.ProPymeGeneral = false;
                result.ProPymeTransp = false;
            }

            result.Regimen = (result.ProPymeGeneral ?? false) ? RegimenesTributarios.FTE_14DN3 :
                (result.ProPymeTransp ?? false) ? RegimenesTributarios.FTE_14DN8 : "";

            // Verificar si el período está cerrado
            result.PeriodoCerrado = await IsPeriodClosedAsync(empresaId, ano);

            // Cargar estructura jerárquica
            var items = await LoadHierarchicalDataAsync(empresaId, ano);

            // Organizar en secciones
            result.Secciones = OrganizeSections(items);

            // Calcular totales
            result.TotalIngresos = CalculateSectionTotal(result.Secciones, TipoBaseImponible14D.Ingreso);
            result.TotalEgresos = Math.Abs(CalculateSectionTotal(result.Secciones, TipoBaseImponible14D.Egreso));
            result.BaseImponible = result.TotalIngresos - result.TotalEgresos;

            _logger.LogInformation("Base imponible 14D obtenida: Ingresos={Ingresos}, Egresos={Egresos}, Base={Base}",
                result.TotalIngresos, result.TotalEgresos, result.BaseImponible);

            return result;
        }
    }

    public async Task<IEnumerable<BaseImponible14DItemDto>> GetHierarchicalStructureAsync(int empresaId, short ano)
    {
        _logger.LogInformation("Obteniendo estructura jerárquica para empresa {EmpresaId} año {Ano}", empresaId, ano);

        return await LoadHierarchicalDataAsync(empresaId, ano);
    }

    private async Task<List<BaseImponible14DItemDto>> LoadHierarchicalDataAsync(int empresaId, short ano)
    {
        var items = new List<BaseImponible14DItemDto>();

        // Obtener régimen de la empresa
        var empresa = await _context.Empresa
            .Where(e => e.Id == empresaId)
            .Select(e => new { e.FranqProPymeGeneral, e.FranqProPymeTransp })
            .FirstOrDefaultAsync();

        bool esProPymeGeneral = empresa?.FranqProPymeGeneral == true;
        bool esProPymeTransp = empresa?.FranqProPymeTransp == true;

        string regimenEmpresa = esProPymeGeneral ? RegimenesTributarios.FTE_14DN3 :
            esProPymeTransp ? RegimenesTributarios.FTE_14DN8 : "";

        // Cargar valores guardados de la BD
        var valoresGuardados = await _context.BaseImponible14D
            .Where(b => b.IdEmpresa == empresaId && b.Ano == ano)
            .ToDictionaryAsync(b => b.Codigo ?? 0, b => b);

        // Construir estructura jerárquica CON FILTROS
        foreach (var config in _estructuraBase.OrderBy(c => c.Codigo))
        {
            // FILTRAR POR RÉGIMEN
            if (!string.IsNullOrEmpty(config.Regimen) && config.Regimen != regimenEmpresa)
            {
                continue; // Saltar conceptos no aplicables al régimen
            }

            // FILTRAR POR AÑO
            if (config.AnoDesde > 0 && ano < config.AnoDesde)
            {
                continue; // Saltar conceptos no aplicables al año
            }

            // FILTRAR POR AÑO - Casos especiales (código 5300 solo antes de 2021)
            if (config.Codigo == 5300 && ano >= 2021)
            {
                continue;
            }

            // FILTRAR POR AÑO - Código 10000 no se muestra para ProPyme desde 2023
            if (config.Codigo == 10000 && ano >= 2023 && (esProPymeGeneral || esProPymeTransp))
            {
                continue;
            }

            var item = new BaseImponible14DItemDto
            {
                IdEmpresa = empresaId,
                Ano = ano,
                Tipo = config.Tipo,
                Nivel = config.Nivel,
                Codigo = config.Codigo,
                Descripcion = config.Descripcion,
                FormaIngreso = config.FormaIngreso,
                EsEditable = config.FormaIngreso == (byte)FormaIngreso14D.Manual ||
                             config.FormaIngreso == (byte)FormaIngreso14D.Ambos,
                EsSubtotal = config.Nivel <= 3,
                EsNegrita = config.Nivel <= 3,
                TieneHijos = config.Nivel < 5,
                Expandido = true
            };

            // Si es nivel 4, color azul
            if (config.Nivel == 4)
            {
                item.ColorTexto = "blue";
            }

            // Cargar valor guardado si existe
            if (valoresGuardados.TryGetValue(config.Codigo, out var valorGuardado))
            {
                item.IdBaseImponible14D = valorGuardado.IdBaseImponible14D;
                item.Valor = (decimal)(valorGuardado.Valor ?? 0);

                // Si es egreso, mostrar como negativo
                if (config.Tipo == (int)TipoBaseImponible14D.Egreso && item.Valor > 0)
                {
                    item.Valor = -item.Valor;
                }
            }
            else if (config.FormaIngreso != (int)FormaIngreso14D.Manual)
            {
                // Calcular valor automático según tipo de traspaso
                item.Valor = await CalculateAutomaticValueAsync(empresaId, ano, config);
            }

            items.Add(item);
        }

        // Recalcular totales jerárquicos
        RecalculateHierarchicalTotals(items);

        return items;
    }

    private async Task<decimal> CalculateAutomaticValueAsync(int empresaId, short ano, BaseImponibleConfig config)
    {
        decimal valor = 0;

        // FASE 3 - IMPLEMENTACIÓN COMPLETA CON CASOS ESPECIALES
        {
            // Casos especiales por código (lógica compleja específica)
            if (config.Codigo == 7400)
            {
                // Código 7400: IVA Irrecuperable saldo a pagar
                valor = await CalculateNonRecoverableVATAsync(empresaId, ano);
                    
                // Agregar ajustes si existen
                if (config.IdItemCtasAsociadasAjustes > 0)
                {
                    var ajuste = await GetELCAdjustmentsAsync(empresaId, ano, 1, config.IdItemCtasAsociadasAjustes);
                    valor += ajuste;
                }
                    
                _logger.LogInformation("Código 7400 (IVA Irrecuperable): {Valor}", valor);
                return valor;
            }

            // Lógica estándar por FormaIngreso
            switch ((FormaIngreso14D)config.FormaIngreso)
            {
                case FormaIngreso14D.Traspaso:
                    // Traspaso desde cuentas con CodF22_14Ter
                    valor = await GetAccountTotalF22Async(empresaId, ano, config.Codigo, "");
                    break;

                case FormaIngreso14D.TraspasoAjuste:
                    // Traspaso desde ajustes extra-libro (AjustesExtLibCaja)
                    valor = await GetELCAdjustmentsAsync(empresaId, ano, 1, config.IdItemCtasAsociadasAjustes);
                    break;

                case FormaIngreso14D.TraspasoLibCaja:
                    // Traspaso desde Libro de Caja
                    valor = await GetValLibroCajaAsync(empresaId, ano, config.Codigo);
                    break;

                case FormaIngreso14D.AmbosAjuste:
                    // Combinación: Traspaso desde cuentas + Ajustes
                    var valorTraspaso = await GetAccountTotalF22Async(empresaId, ano, config.Codigo, "");
                    var valorAjuste = await GetELCAdjustmentsAsync(empresaId, ano, 1, config.IdItemCtasAsociadasAjustes);
                    valor = valorTraspaso + valorAjuste;
                    break;

                case FormaIngreso14D.Manual:
                    // Ingreso manual - sin cálculo automático
                    valor = 0;
                    break;

                default:
                    _logger.LogWarning("FormaIngreso no reconocido: {FormaIngreso} para código: {Codigo}", 
                        config.FormaIngreso, config.Codigo);
                    break;
            }
        }

        return valor;
    }

    private void RecalculateHierarchicalTotals(List<BaseImponible14DItemDto> items)
    {
        // Recalcular de abajo hacia arriba (nivel 5 → 1)
        for (int nivel = 4; nivel >= 1; nivel--)
        {
            var itemsNivel = items.Where(i => i.Nivel == nivel).ToList();

            foreach (var item in itemsNivel)
            {
                if (item.EsSubtotal)
                {
                    // Sumar valores de items hijos (nivel + 1)
                    var codigoInicio = item.Codigo;
                    var codigoFin = codigoInicio + 1000; // Rango aproximado

                    item.Valor = items
                        .Where(i => i.Nivel == nivel + 1 &&
                                    i.Codigo > codigoInicio &&
                                    i.Codigo < codigoFin)
                        .Sum(i => i.Valor);
                }
            }
        }
    }

    private List<BaseImponible14DSeccionDto> OrganizeSections(List<BaseImponible14DItemDto> items)
    {
        var secciones = new List<BaseImponible14DSeccionDto>();

        // Agrupar por secciones principales (nivel 2)
        var seccionesPrincipales = items.Where(i => i.Nivel == 2).ToList();

        foreach (var secPrincipal in seccionesPrincipales)
        {
            var seccion = new BaseImponible14DSeccionDto
            {
                Nivel = secPrincipal.Nivel,
                Titulo = secPrincipal.Descripcion,
                Subtotal = secPrincipal.Valor,
                Expandida = true,
                Items = new List<BaseImponible14DItemDto>()
            };

            // Agregar items de esta sección
            var codigoInicio = secPrincipal.Codigo;
            var codigoFin = codigoInicio + 3000; // Rango de la sección

            seccion.Items = items
                .Where(i => i.Codigo >= codigoInicio && i.Codigo < codigoFin)
                .OrderBy(i => i.Codigo)
                .ToList();

            secciones.Add(seccion);
        }

        return secciones;
    }

    private decimal CalculateSectionTotal(List<BaseImponible14DSeccionDto> secciones, TipoBaseImponible14D tipo)
    {
        return secciones
            .Where(s => s.Items.Any(i => i.Tipo == (int)tipo))
            .Sum(s => s.Subtotal);
    }

    public async Task<BaseImponible14DResultDto> SaveAsync(int empresaId, short ano, BaseImponible14DSaveDto dto)
    {
        _logger.LogInformation("Guardando base imponible 14D para empresa {EmpresaId} año {Ano}", empresaId, ano);

        var result = new BaseImponible14DResultDto { Success = false };

        {
            foreach (var item in dto.ItemsActualizados)
            {
                var registro = await _context.BaseImponible14D
                    .FirstOrDefaultAsync(b => b.IdEmpresa == empresaId &&
                                              b.Ano == ano &&
                                              b.Codigo == item.Codigo);

                if (registro != null)
                {
                    registro.Valor = (double)item.Valor;
                    result.RegistrosActualizados++;
                }
                else
                {
                    var config = _estructuraBase.FirstOrDefault(c => c.Codigo == item.Codigo);
                    if (config != null)
                    {
                        registro = new App.Data.BaseImponible14D
                        {
                            IdEmpresa = empresaId,
                            Ano = ano,
                            Tipo = config.Tipo,
                            Nivel = config.Nivel,
                            Codigo = item.Codigo,
                            Fecha = 0,
                            Valor = (double)item.Valor
                        };
                        _context.BaseImponible14D.Add(registro);
                        result.RegistrosInsertados++;
                    }
                }
            }

            await _context.SaveChangesAsync();

            // Recalcular base imponible
            result.BaseImponibleCalculada = await CalculateTotalTaxBaseAsync(empresaId, ano);

            // Actualizar EmpresasAno con base imponible calculada
            // TODO: Campo BaseImponible14D no existe en EmpresasAno - pendiente migración
            /*
            var empresaAno = await _context.EmpresasAno
                .FirstOrDefaultAsync(ea => ea.idEmpresa == empresaId && ea.Ano == ano);

            if (empresaAno != null)
            {
                empresaAno.BaseImponible14D = (double?)result.BaseImponibleCalculada;
                await _context.SaveChangesAsync();
                _logger.LogInformation("EmpresasAno actualizado con BaseImponible14D: {Base}", result.BaseImponibleCalculada);
            }
            else
            {
                _logger.LogWarning("No se encontró registro en EmpresasAno para empresa {EmpresaId} año {Ano}", empresaId, ano);
            }
            */

            result.Success = true;
            result.Message = "Base imponible 14D guardada correctamente";

            _logger.LogInformation("Base imponible 14D guardada: {Actualizados} actualizados, {Insertados} insertados, Base={Base}",
                result.RegistrosActualizados, result.RegistrosInsertados, result.BaseImponibleCalculada);

            return result;
        }
    }

    public async Task<BaseImponible14DItemDto> UpdateItemValueAsync(int empresaId, short ano, short codigo, decimal valor)
    {
        _logger.LogInformation("Actualizando valor para código {Codigo}: {Valor}", codigo, valor);

        var registro = await _context.BaseImponible14D
            .FirstOrDefaultAsync(b => b.IdEmpresa == empresaId &&
                                      b.Ano == ano &&
                                      b.Codigo == codigo);

        if (registro != null)
        {
            registro.Valor = (double)valor;
        }
        else
        {
            var config = _estructuraBase.FirstOrDefault(c => c.Codigo == codigo);
            if (config != null)
            {
                registro = new App.Data.BaseImponible14D
                {
                    IdEmpresa = empresaId,
                    Ano = ano,
                    Tipo = config.Tipo,
                    Nivel = config.Nivel,
                    Codigo = codigo,
                    Fecha = 0,
                    Valor = (double)valor
                };
                _context.BaseImponible14D.Add(registro);
            }
        }

        await _context.SaveChangesAsync();

        // Actualizar valores espejo si aplica
        await UpdateMirrorValuesAsync(empresaId, ano, codigo);

        // Retornar item actualizado
        return new BaseImponible14DItemDto
        {
            IdBaseImponible14D = registro?.IdBaseImponible14D ?? 0,
            Codigo = codigo,
            Valor = valor
        };
    }

    public async Task<decimal> CalculateTotalTaxBaseAsync(int empresaId, short ano)
    {
        var items = await LoadHierarchicalDataAsync(empresaId, ano);

        // La base imponible es el valor del nivel 1 (código 1000)
        var baseImponible = items.FirstOrDefault(i => i.Nivel == 1)?.Valor ?? 0;

        return baseImponible;
    }

    public async Task RecalculateHierarchyAsync(int empresaId, short ano)
    {
        var items = await LoadHierarchicalDataAsync(empresaId, ano);
        RecalculateHierarchicalTotals(items);

        // Guardar totales recalculados
        foreach (var item in items.Where(i => i.EsSubtotal))
        {
            await UpdateItemValueAsync(empresaId, ano, item.Codigo, item.Valor);
        }
    }

    public async Task<IEnumerable<BaseImponible14DItemDto>> CalculateAutomaticValuesAsync(int empresaId, short ano)
    {
        var itemsAutomaticos = new List<BaseImponible14DItemDto>();

        foreach (var config in _estructuraBase.Where(c => c.FormaIngreso != (int)FormaIngreso14D.Manual))
        {
            var valor = await CalculateAutomaticValueAsync(empresaId, ano, config);

            itemsAutomaticos.Add(new BaseImponible14DItemDto
            {
                Codigo = config.Codigo,
                Descripcion = config.Descripcion,
                Valor = valor,
                FormaIngreso = config.FormaIngreso
            });
        }

        return itemsAutomaticos;
    }

    // Métodos de cálculo específicos (placeholders)
    public async Task<decimal> GetPerceivedPaidIncomeAsync(int empresaId, short ano, int tipoOperCaja, string regimen)
    {
        // TODO: Implementar cálculo de ingresos percibidos/pagados
        _logger.LogWarning("GetPerceivedPaidIncomeAsync no implementado completamente");
        await Task.CompletedTask;
        return 0;
    }

    public async Task<decimal> GetPreviousAccruedAsync(int empresaId, short ano, int tipoOperCaja, string regimen)
    {
        // TODO: Implementar cálculo de devengados anteriores
        _logger.LogWarning("GetPreviousAccruedAsync no implementado completamente");
        await Task.CompletedTask;
        return 0;
    }

    public async Task<decimal> GetPaidInventoryAsync(int empresaId, short ano, int tipoOperCaja, bool incluirNotas = true)
    {
        // TODO: Implementar cálculo de existencias/insumos pagados
        _logger.LogWarning("GetPaidInventoryAsync no implementado completamente");
        await Task.CompletedTask;
        return 0;
    }

    public async Task<decimal> GetPerceivedPaidPurchasesAsync(int empresaId, short ano, int tipoOperCaja, string regimen)
    {
        // TODO: Implementar cálculo de compras percibidas/pagadas
        _logger.LogWarning("GetPerceivedPaidPurchasesAsync no implementado completamente");
        await Task.CompletedTask;
        return 0;
    }

    public async Task<decimal> GetAccountTotalF22Async(int empresaId, short ano, int codigoF22, string tipo)
    {
        // FASE 2 - IMPLEMENTACIÓN COMPLETA
        // VB6: GetTotCta_CodF22_14D() - Suma DEBE - HABER de cuentas con CodF22_14Ter = codigo
        {
            var total = await (from m in _context.MovComprobante
                    join cta in _context.Cuentas on m.IdCuenta equals cta.idCuenta
                    where m.IdEmpresa == empresaId
                          && m.Ano == ano
                          && cta.CodF22_14Ter == (short?)codigoF22
                    select (m.Debe ?? 0) - (m.Haber ?? 0))
                .SumAsync();
                
            _logger.LogDebug("GetAccountTotalF22Async - Empresa: {EmpresaId}, Año: {Ano}, CódigoF22: {CodigoF22}, Total: {Total}", 
                empresaId, ano, codigoF22, total);
                
            return (decimal)total;
        }
    }

    public async Task<decimal> LoadAdjustmentValuesAsync(int empresaId, short ano, int tipoAjuste, int idItem, int tipoComp)
    {
        // TODO: Implementar carga de valores de ajustes
        _logger.LogWarning("LoadAdjustmentValuesAsync no implementado completamente");
        await Task.CompletedTask;
        return 0;
    }

    public async Task<decimal> GetELCAdjustmentsAsync(int empresaId, short ano, int tipoAjuste, int item)
    {
        // FASE 2 - IMPLEMENTACIÓN COMPLETA
        // VB6: GetValAjustesELC() - Suma valores de AjustesExtLibCaja
        {
            var total = await _context.AjustesExtLibCaja
                .Where(a => a.IdEmpresa == empresaId
                            && a.Ano == ano
                            && a.TipoAjuste == (byte?)tipoAjuste
                            && a.IdItemAjuste == item)
                .SumAsync(a => a.Valor ?? 0);
                
            _logger.LogDebug("GetELCAdjustmentsAsync - Empresa: {EmpresaId}, Año: {Ano}, TipoAjuste: {TipoAjuste}, Item: {Item}, Total: {Total}", 
                empresaId, ano, tipoAjuste, item, total);
                
            return (decimal)total;
        }
    }

    public async Task<decimal> GetValLibroCajaAsync(int empresaId, short ano, int tipoOperacion, int tipoLib = 1)
    {
        // FASE 2 - IMPLEMENTACIÓN COMPLETA
        // VB6: GetValLibroCaja() - Suma montos de LibroCaja según tipo de operación
        {
            var total = await _context.LibroCaja
                .Where(l => l.IdEmpresa == empresaId
                            && l.Ano == ano
                            && l.TipoLib == (short?)tipoLib
                            && l.TipoOper == tipoOperacion)
                .SumAsync(l => (l.Afecto ?? 0) + (l.Exento ?? 0));
                
            _logger.LogDebug("GetValLibroCajaAsync - Empresa: {EmpresaId}, Año: {Ano}, TipoOperación: {TipoOper}, TipoLib: {TipoLib}, Total: {Total}", 
                empresaId, ano, tipoOperacion, tipoLib, total);
                
            return (decimal)total;
        }
    }

    public async Task<decimal> GetCredit33BisAsync(int empresaId, short ano)
    {
        // TODO: Implementar cálculo del crédito 33 bis
        _logger.LogWarning("GetCredit33BisAsync no implementado completamente");
        await Task.CompletedTask;
        return 0;
    }

    public async Task<decimal> GetDepreciableFixedAssetsAsync(int empresaId, short ano, int tipoOperCaja)
    {
        // TODO: Implementar cálculo de activos fijos depreciables
        _logger.LogWarning("GetDepreciableFixedAssetsAsync no implementado completamente");
        await Task.CompletedTask;
        return 0;
    }

    public async Task<decimal> GetCreditNotesF22Async(int empresaId, short ano, int codigoF22, string tipo)
    {
        // TODO: Implementar obtención de notas de crédito F22
        _logger.LogWarning("GetCreditNotesF22Async no implementado completamente");
        await Task.CompletedTask;
        return 0;
    }

    public async Task<decimal> GetInventoryCreditNotesAsync(int empresaId, short ano)
    {
        // TODO: Implementar obtención de notas de crédito para existencias
        _logger.LogWarning("GetInventoryCreditNotesAsync no implementado completamente");
        await Task.CompletedTask;
        return 0;
    }

    public async Task<decimal> CalculateNonRecoverableVATAsync(int empresaId, short ano)
    {
        _logger.LogInformation("Calculando IVA Irrecuperable para empresa {EmpresaId} año {Ano}", empresaId, ano);

        {
            decimal valor = 0;

            // PASO 1: Calcular pagos con otros impuestos
            // Query VB6: SELECT sum(pagado - ((afecto) + (iva) + (exento)))
            var pagosTotales = await _context.LibroCaja
                .Join(_context.TipoDocs,
                    lc => new { TipoLib = lc.TipoLib, TipoDoc = lc.TipoDoc },
                    td => new { TipoLib = (int?)td.TipoLib, TipoDoc = (int?)td.TipoDoc },
                    (lc, td) => new { LibroCaja = lc, TipoDoc = td })
                .Where(x => x.LibroCaja.IdEmpresa == empresaId
                            && x.LibroCaja.Ano == ano
                            && x.LibroCaja.TipoLib == 1 // LIB_COMPRAS
                            && (x.TipoDoc.Diminutivo == "FAC" || x.TipoDoc.Diminutivo == "NDC" || x.TipoDoc.Diminutivo == "IMP")
                            && (x.LibroCaja.Pagado ?? 0) > 0
                            && ((x.LibroCaja.OtroImp ?? 0) > 0 || (x.LibroCaja.IVAIrrec ?? 0) > 0)
                            && x.LibroCaja.TipoOper == 2)
                .GroupBy(x => x.LibroCaja.IdDoc)
                .Select(g => new
                {
                    IdDoc = g.Key,
                    TotPagado = g.Sum(x => x.LibroCaja.Pagado ?? 0),
                    Afecto = g.Max(x => x.LibroCaja.Afecto ?? 0),
                    Exento = g.Max(x => x.LibroCaja.Exento ?? 0),
                    IVA = g.Max(x => x.LibroCaja.IVA ?? 0),
                    IVAIrrec = g.Max(x => x.LibroCaja.IVAIrrec ?? 0)
                })
                .ToListAsync();

            // Calcular diferencia pagada vs registrada (otros impuestos)
            foreach (var pago in pagosTotales)
            {
                var diferencia = pago.TotPagado - (pago.Afecto + pago.IVA + pago.Exento);
                if (diferencia > 0)
                {
                    valor += (decimal)diferencia;
                }
            }

            // PASO 2: Sumar Notas de Crédito de Compras (reversa otros impuestos)
            var notasCredito = await _context.LibroCaja
                .Join(_context.TipoDocs,
                    lc => new { TipoLib = lc.TipoLib, TipoDoc = lc.TipoDoc },
                    td => new { TipoLib = (int?)td.TipoLib, TipoDoc = (int?)td.TipoDoc },
                    (lc, td) => new { LibroCaja = lc, TipoDoc = td })
                .Where(x => x.LibroCaja.IdEmpresa == empresaId
                            && x.LibroCaja.Ano == ano
                            && x.LibroCaja.TipoLib == 1 // LIB_COMPRAS
                            && x.TipoDoc.Diminutivo == "NCC" // Nota Crédito Compras
                            && (x.LibroCaja.Pagado ?? 0) > 0
                            && ((x.LibroCaja.OtroImp ?? 0) > 0 || (x.LibroCaja.IVAIrrec ?? 0) > 0)
                            && x.LibroCaja.TipoOper == 1)
                .SumAsync(x => (x.LibroCaja.Afecto ?? 0) + (x.LibroCaja.Exento ?? 0)
                                                         + (x.LibroCaja.IVA ?? 0) + (x.LibroCaja.IVAIrrec ?? 0));

            valor += (decimal)notasCredito;

            // PASO 3: Restar movimientos contables de activos (cuentas que empiezan con 1)
            // Estos son gastos capitalizados que no deben considerarse otros impuestos
            foreach (var pago in pagosTotales)
            {
                var movimientosActivos = await _context.MovDocumento
                    .Join(_context.Documento,
                        md => md.IdDoc,
                        d => d.IdDoc,
                        (md, d) => new { MovDoc = md, Doc = d })
                    .Join(_context.Cuentas,
                        x => x.MovDoc.IdCuenta,
                        c => c.idCuenta,
                        (x, c) => new { x.MovDoc, x.Doc, Cuenta = c })
                    .Join(_context.TipoValor,
                        x => new { TipoLib = x.Doc.TipoLib, Codigo = x.MovDoc.IdTipoValLib },
                        tv => new { TipoLib = tv.TipoLib, Codigo = (short?)tv.Codigo },
                        (x, tv) => new { x.MovDoc, x.Doc, x.Cuenta, TipoValor = tv })
                    .Where(x => x.Doc.IdDoc == pago.IdDoc
                                && x.Doc.IdEmpresa == empresaId
                                && (x.MovDoc.Tasa ?? 0) > 0
                                && x.Cuenta.Codigo != null
                                && x.Cuenta.Codigo.StartsWith("1")) // Activos
                    .OrderByDescending(x => x.MovDoc.Tasa)
                    .ToListAsync();

                foreach (var mov in movimientosActivos)
                {
                    var valorMov = (mov.MovDoc.Debe ?? 0) > 0 ? mov.MovDoc.Debe ?? 0 : mov.MovDoc.Haber ?? 0;
                    valor -= (decimal)valorMov;
                }
            }

            _logger.LogInformation("IVA Irrecuperable calculado: {Valor}", valor);
            return valor;
        }
    }

    public async Task<decimal> GetPPMAdjustmentAsync(int empresaId, short ano)
    {
        // TODO: Implementar cálculo de reajuste PPM
        _logger.LogWarning("GetPPMAdjustmentAsync no implementado completamente");
        await Task.CompletedTask;
        return 0;
    }

    public async Task<decimal> GetPreviousYearLossAsync(int empresaId, short ano)
    {
        // TODO: Implementar obtención de pérdida año anterior
        _logger.LogWarning("GetPreviousYearLossAsync no implementado completamente");
        await Task.CompletedTask;
        return 0;
    }

    public async Task<IEnumerable<BaseImponible14DItemDto>> GetWithNonZeroValuesAsync(int empresaId, short ano)
    {
        var items = await LoadHierarchicalDataAsync(empresaId, ano);
        return items.Where(i => i.Valor != 0).ToList();
    }

    public async Task<IEnumerable<BaseImponible14DItemDto>> FilterByRegimeAsync(int empresaId, short ano, string regime)
    {
        var items = await LoadHierarchicalDataAsync(empresaId, ano);

        // TODO: Implementar filtro por régimen
        _logger.LogWarning("FilterByRegimeAsync no implementado completamente");

        return items;
    }

    public async Task<BaseImponible14DCompletaDto> ApplyFiltersAsync(int empresaId, short ano, BaseImponible14DFiltroDto filtro)
    {
        var result = await GetByEmpresaAnoAsync(empresaId, ano);

        if (filtro.SoloConValores)
        {
            foreach (var seccion in result.Secciones)
            {
                seccion.Items = seccion.Items.Where(i => i.Valor != 0 || i.Nivel <= 2).ToList();
            }
        }

        if (!string.IsNullOrEmpty(filtro.Regimen))
        {
            // TODO: Aplicar filtro de régimen
        }

        if (filtro.NivelMaximo.HasValue)
        {
            foreach (var seccion in result.Secciones)
            {
                seccion.Items = seccion.Items.Where(i => i.Nivel <= filtro.NivelMaximo.Value).ToList();
            }
        }

        return result;
    }

    public async Task<ValidationResult> ValidateAsync(int empresaId, short ano)
    {
        var result = new ValidationResult { IsValid = true };

        // Verificar que existe la empresa
        var empresaExiste = await _context.Empresa.AnyAsync(e => e.Id == empresaId);

        if (!empresaExiste)
        {
            result.IsValid = false;
            result.Errors.Add($"La empresa con ID {empresaId} no existe");
        }

        // Verificar año válido
        if (ano < 2000 || ano > DateTime.Now.Year + 1)
        {
            result.IsValid = false;
            result.Errors.Add($"El año {ano} no es válido");
        }

        // Verificar período no cerrado
        if (await IsPeriodClosedAsync(empresaId, ano))
        {
            result.IsValid = false;
            result.Errors.Add("El período está cerrado y no se pueden realizar modificaciones");
        }

        return result;
    }

    public async Task<bool> IsPeriodOpenAsync(int empresaId, short ano)
    {
        return !await IsPeriodClosedAsync(empresaId, ano);
    }

    private async Task<bool> IsPeriodClosedAsync(int empresaId, short ano)
    {
        // TODO: Verificar FCierre en EmpresasAno
        _logger.LogWarning("IsPeriodClosedAsync no implementado - retornando false");
        await Task.CompletedTask;
        return false;
    }

    public async Task UpdateMirrorValuesAsync(int empresaId, short ano, short codigoOrigen)
    {
        // Implementar lógica de valores espejo
        if (codigoOrigen == CodigosEspeciales14D.Codigo8100)
        {
            var valor = await GetItemValueAsync(empresaId, ano, codigoOrigen);
            await UpdateItemValueAsync(empresaId, ano, CodigosEspeciales14D.Codigo8300, Math.Abs(valor));
        }
        else if (codigoOrigen >= CodigosEspeciales14D.Codigo7400 && codigoOrigen <= CodigosEspeciales14D.Codigo7900)
        {
            // Mapear a códigos 10800-11300
            var offset = (short)(codigoOrigen - CodigosEspeciales14D.Codigo7400);
            var codigoDestino = (short)(CodigosEspeciales14D.Codigo10800 + (offset * 100));

            var valor = await GetItemValueAsync(empresaId, ano, codigoOrigen);
            await UpdateItemValueAsync(empresaId, ano, codigoDestino, Math.Abs(valor));
        }
    }

    private async Task<decimal> GetItemValueAsync(int empresaId, short ano, short codigo)
    {
        var registro = await _context.BaseImponible14D
            .Where(b => b.IdEmpresa == empresaId && b.Ano == ano && b.Codigo == codigo)
            .FirstOrDefaultAsync();

        return (decimal)(registro?.Valor ?? 0);
    }

    public async Task ClearDetailsByCodeAsync(int empresaId, short ano, int codigo)
    {
        var registros = await _context.BaseImponible14D
            .Where(b => b.IdEmpresa == empresaId && b.Ano == ano && b.Codigo == codigo)
            .ToListAsync();

        _context.BaseImponible14D.RemoveRange(registros);
        await _context.SaveChangesAsync();
    }

    public async Task<BaseImponible14DCalculoDto> GetDetailedCalculationAsync(int empresaId, short ano)
    {
        var result = new BaseImponible14DCalculoDto();

        var items = await LoadHierarchicalDataAsync(empresaId, ano);

        // Separar ingresos y egresos
        var ingresos = items.Where(i => i.Tipo == (int)TipoBaseImponible14D.Ingreso && i.Nivel == 5);
        var egresos = items.Where(i => i.Tipo == (int)TipoBaseImponible14D.Egreso && i.Nivel == 5);

        foreach (var ing in ingresos)
        {
            result.DetalleIngresos[ing.Descripcion] = ing.Valor;
        }

        foreach (var egr in egresos)
        {
            result.DetalleEgresos[egr.Descripcion] = Math.Abs(egr.Valor);
        }

        result.TotalIngresos = result.DetalleIngresos.Values.Sum();
        result.TotalEgresos = result.DetalleEgresos.Values.Sum();
        result.BaseImponible = result.TotalIngresos - result.TotalEgresos;

        // Valores especiales
        result.IVAIrrecuperable = await CalculateNonRecoverableVATAsync(empresaId, ano);
        result.PPMAjuste = await GetPPMAdjustmentAsync(empresaId, ano);
        result.PerdidaAnoAnterior = await GetPreviousYearLossAsync(empresaId, ano);

        return result;
    }

    public async Task<byte[]> ExportToExcelAsync(int empresaId, short ano)
    {
        _logger.LogInformation("Exportando base imponible 14D a Excel para empresa {EmpresaId} año {Ano}", empresaId, ano);

        {
            var data = await GetByEmpresaAnoAsync(empresaId, ano);

            using var package = new ExcelPackage();
            var worksheet = package.Workbook.Worksheets.Add("Base Imponible 14D");

            // Configurar título
            worksheet.Cells[1, 1].Value = "BASE IMPONIBLE PRIMERA CATEGORÍA RÉGIMEN 14D";
            worksheet.Cells[1, 1, 1, 3].Merge = true;
            worksheet.Cells[1, 1].Style.Font.Bold = true;
            worksheet.Cells[1, 1].Style.Font.Size = 14;
            worksheet.Cells[1, 1].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

            // Información de empresa y año
            worksheet.Cells[2, 1].Value = $"Empresa: {data.NombreEmpresa}";
            worksheet.Cells[3, 1].Value = $"Año: {ano}";
            worksheet.Cells[4, 1].Value = $"Régimen: {data.Regimen}";

            int row = 6;

            // Headers
            worksheet.Cells[row, 1].Value = "Concepto";
            worksheet.Cells[row, 2].Value = "Valor";
            worksheet.Cells[row, 3].Value = "Subtotal";
            worksheet.Cells[row, 1, row, 3].Style.Font.Bold = true;
            worksheet.Cells[row, 1, row, 3].Style.Fill.PatternType = ExcelFillStyle.Solid;
            worksheet.Cells[row, 1, row, 3].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightGray);
            row++;

            // Exportar cada sección
            foreach (var seccion in data.Secciones)
            {
                // Título de sección
                worksheet.Cells[row, 1].Value = seccion.Titulo;
                worksheet.Cells[row, 3].Value = seccion.Subtotal;
                worksheet.Cells[row, 1, row, 3].Style.Font.Bold = true;
                row++;

                // Items de la sección
                foreach (var item in seccion.Items.Where(i => i.Nivel >= 3))
                {
                    var indent = new string(' ', (item.Nivel - 3) * 4);
                    worksheet.Cells[row, 1].Value = indent + item.Descripcion;

                    if (item.EsSubtotal)
                    {
                        worksheet.Cells[row, 3].Value = item.Valor;
                        worksheet.Cells[row, 1, row, 3].Style.Font.Bold = true;
                    }
                    else
                    {
                        worksheet.Cells[row, 2].Value = item.Valor;
                    }

                    worksheet.Cells[row, 2].Style.Numberformat.Format = "#,##0.00";
                    worksheet.Cells[row, 3].Style.Numberformat.Format = "#,##0.00";

                    row++;
                }

                row++; // Línea en blanco entre secciones
            }

            // Resumen final
            row++;
            worksheet.Cells[row, 1].Value = "TOTAL INGRESOS";
            worksheet.Cells[row, 3].Value = data.TotalIngresos;
            worksheet.Cells[row, 1, row, 3].Style.Font.Bold = true;
            row++;

            worksheet.Cells[row, 1].Value = "TOTAL EGRESOS";
            worksheet.Cells[row, 3].Value = data.TotalEgresos;
            worksheet.Cells[row, 1, row, 3].Style.Font.Bold = true;
            row++;

            worksheet.Cells[row, 1].Value = "BASE IMPONIBLE";
            worksheet.Cells[row, 3].Value = data.BaseImponible;
            worksheet.Cells[row, 1, row, 3].Style.Font.Bold = true;
            worksheet.Cells[row, 1, row, 3].Style.Font.Size = 12;

            // Ajustar anchos de columna
            worksheet.Column(1).Width = 60;
            worksheet.Column(2).Width = 15;
            worksheet.Column(3).Width = 15;

            return package.GetAsByteArray();
        }
    }

    public async Task<byte[]> GeneratePrintPreviewAsync(int empresaId, short ano)
    {
        // TODO: Implementar generación de vista previa para impresión (PDF o HTML)
        _logger.LogWarning("GeneratePrintPreviewAsync no implementado completamente");

        // Por ahora, retornar el Excel
        return await ExportToExcelAsync(empresaId, ano);
    }

    /// <summary>
    /// Inicializa la estructura jerárquica completa de Base Imponible 14D
    /// Migrado desde BaseImponible14D.bas (VB6)
    /// </summary>
    private List<BaseImponibleConfig> InitEstructuraBase()
    {
        var estructura = new List<BaseImponibleConfig>();

        // Nivel 1: Base Imponible
        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 1,
            Tipo = 0,
            Codigo = 1,
            Descripcion = "Base Imponible",
            FormaIngreso = 0,
            Regimen = ""
        });

        // ==================== INGRESOS ====================

        // Nivel 2: TOTAL INGRESOS
        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 2,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 100,
            Descripcion = "Total Ingresos",
            FormaIngreso = 0,
            Regimen = ""
        });

        // Nivel 3: Ingresos Percibidos
        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 3,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 200,
            Descripcion = "Ingresos percibidos",
            FormaIngreso = 0,
            Regimen = ""
        });

        // Nivel 4: Ingresos del Giro
        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 4,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 300,
            Descripcion = "Ingresos percibidos del Giro",
            FormaIngreso = 0,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 400,
            Descripcion = "Ingresos percibidos del Giro",
            FormaIngreso = (int)FormaIngreso14D.TraspasoLibCaja,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 401,
            Descripcion = "Ingreso del Giro Devengados en ejercicios anteriores y percibidos en el ejercicio actual",
            FormaIngreso = (int)FormaIngreso14D.TraspasoLibCaja,
            Regimen = "",
            AnoDesde = 2021
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 500,
            Descripcion = "Renta de Fuente Extranjera",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        // Nivel 4: Art 20 N°1
        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 4,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 600,
            Descripcion = "Ingresos percibidos del art 20 nº 1 LIR",
            FormaIngreso = 0,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 700,
            Descripcion = "Desarrollo de una actividad agrícola",
            FormaIngreso = (int)FormaIngreso14D.AmbosAjuste,
            Regimen = "",
            IdItemCtasAsociadasAjustes = 8
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 800,
            Descripcion = "Arriendo de bienes raices agrícolas",
            FormaIngreso = (int)FormaIngreso14D.AmbosAjuste,
            Regimen = "",
            IdItemCtasAsociadasAjustes = 9
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 900,
            Descripcion = "Arriendo de bienes raices no agrícolas",
            FormaIngreso = (int)FormaIngreso14D.AmbosAjuste,
            Regimen = "",
            IdItemCtasAsociadasAjustes = 10
        });

        // Nivel 4: Capitales Mobiliarios
        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 4,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 1000,
            Descripcion = "Ingresos percibidos por la tenencia de capitales mobiliarios (distinto de dividendos)",
            FormaIngreso = 0,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 1100,
            Descripcion = "Intereses de depósitos o instrumentos financieros",
            FormaIngreso = (int)FormaIngreso14D.AmbosAjuste,
            Regimen = "",
            IdItemCtasAsociadasAjustes = 11
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 1200,
            Descripcion = "Mayor valor en el rescate de cuotas de FM o FI",
            FormaIngreso = (int)FormaIngreso14D.AmbosAjuste,
            Regimen = "",
            IdItemCtasAsociadasAjustes = 12
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 1300,
            Descripcion = "Participación en contratos de participación o cuentas de participación",
            FormaIngreso = (int)FormaIngreso14D.AmbosAjuste,
            Regimen = "",
            IdItemCtasAsociadasAjustes = 13
        });

        // Nivel 4: Retiros/Dividendos (solo 14DN8)
        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 4,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 1400,
            Descripcion = "Retiros o dividendos recibidos desde otras empresas acogidas al regimen 14A, 14B o 14D3",
            FormaIngreso = 0,
            Regimen = RegimenesTributarios.FTE_14DN8
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 1500,
            Descripcion = "Monto Liquido recibido",
            FormaIngreso = (int)FormaIngreso14D.Traspaso,
            Regimen = RegimenesTributarios.FTE_14DN8
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 1600,
            Descripcion = "Incremento por crédito IDPC",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = RegimenesTributarios.FTE_14DN8
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 1700,
            Descripcion = "Incremento por crédito IPE",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = RegimenesTributarios.FTE_14DN8
        });

        // Nivel 4: Enajenación de Inversiones
        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 4,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 1800,
            Descripcion = "Ingresos percibidos por la enajenación de inversiones",
            FormaIngreso = 0,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 1900,
            Descripcion = "Renta percibida en la enajenación de las inversiones en capitales mobiliarios",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 2000,
            Descripcion = "Renta percibida en la enajenación de contratos de asociación o cuentas en participación",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 2100,
            Descripcion = "Enajenación de Acciones",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 2200,
            Descripcion = "Enajenación de derechos sociales",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 2300,
            Descripcion = "Terrenos",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 2400,
            Descripcion = "Otros bienes que no se pueden depreciar",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        // Nivel 4: Enajenación Bienes Depreciables
        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 4,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 2500,
            Descripcion = "Ingresos percibidos por la enajenación de bienes depreciables",
            FormaIngreso = 0,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 2600,
            Descripcion = "Ingresos percibidos por la enajenación de bienes depreciables",
            FormaIngreso = (int)FormaIngreso14D.TraspasoAjuste,
            Regimen = "",
            IdItemCtasAsociadasAjustes = 14
        });

        // Nivel 4: Reajustes Percibidos
        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 4,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 2700,
            Descripcion = "Reajustes percibidos",
            FormaIngreso = 0,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 2800,
            Descripcion = "Reajuste de PPM",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 2900,
            Descripcion = "Reajuste del remanente de IVA crédito fiscal",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 3000,
            Descripcion = "Reajustes de depósitos a plazos en UF",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 3100,
            Descripcion = "Reajustes de préstamos en moneda extanjera",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        // Nivel 4: Otros Ingresos Percibidos
        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 4,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 3200,
            Descripcion = "Otros ingresos percibidos",
            FormaIngreso = 0,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 3300,
            Descripcion = "Otros ingresos percibidos",
            FormaIngreso = (int)FormaIngreso14D.Traspaso,
            Regimen = ""
        });

        // Nivel 3: Ingresos Devengados
        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 3,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 3400,
            Descripcion = "Ingresos devengados",
            FormaIngreso = 0,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 4,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 3500,
            Descripcion = "Ingresos devengados o percibidos con empresas relacionadas acogidas al régimen 14 Letra A.",
            FormaIngreso = 0,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 3600,
            Descripcion = "Ingresos devengados o percibidos con empresas relacionadas acogidas al régimen 14 Letra A.",
            FormaIngreso = (int)FormaIngreso14D.TraspasoLibCaja,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 4,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 3700,
            Descripcion = "Otros Ingresos Devengados",
            FormaIngreso = 0,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 3800,
            Descripcion = "Otros Ingresos Devengados",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        // Nivel 3: Ingresos Diferidos
        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 3,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 3900,
            Descripcion = "Ingresos diferidos",
            FormaIngreso = 0,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 4,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 4000,
            Descripcion = "Ingreso diferido según art. 14 o 15 transitorio Ley nº21.210",
            FormaIngreso = 0,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 4100,
            Descripcion = "Ingreso diferido incrementado imputado en el año",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 4,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 4200,
            Descripcion = "Ingreso diferido para empresas que ingresaron al régimen de transparencia tributaria",
            FormaIngreso = 0,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 4300,
            Descripcion = "Ingreso diferido incrementado imputado en el año",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = "",
            AnoDesde = 2021
        });

        // Nivel 3: Otros Ajustes
        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 3,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 4400,
            Descripcion = "Otros Ajustes que se agregan a la Base Imponible",
            FormaIngreso = 0,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 4,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 4500,
            Descripcion = "Otros Ajustes que se agregan a la Base Imponible",
            FormaIngreso = 0,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 4600,
            Descripcion = "Crédito art. 33 Bis LIR",
            FormaIngreso = (int)FormaIngreso14D.Traspaso,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 4700,
            Descripcion = "Crédito total disponible por IPE",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Ingreso,
            Codigo = 4800,
            Descripcion = "Otros agregados",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        // ==================== EGRESOS ====================

        // Nivel 2: TOTAL EGRESOS
        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 2,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 4900,
            Descripcion = "Total Egresos",
            FormaIngreso = 0,
            Regimen = ""
        });

        // Nivel 3: Egresos Pagados
        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 3,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 5000,
            Descripcion = "Egresos pagados",
            FormaIngreso = 0,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 4,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 5100,
            Descripcion = "Gastos pagados asociados en la adquisición de activo realizable o para la prestación de servicios",
            FormaIngreso = 0,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 5200,
            Descripcion = "Existencias, insumos y servicios del negocio, pagados",
            FormaIngreso = (int)FormaIngreso14D.TraspasoLibCaja,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 5201,
            Descripcion = "Existencias, insumos y servicios del negocio adeudados en ejercicios anteriores y pagados en el ejercicio actual",
            FormaIngreso = (int)FormaIngreso14D.TraspasoLibCaja,
            Regimen = "",
            AnoDesde = 2021
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 5300,
            Descripcion = "Servicios Pagados",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 4,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 5400,
            Descripcion = "Montos pagados por la compra de activos fijos depreciables",
            FormaIngreso = 0,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 5500,
            Descripcion = "Compra de activos fijos depreciables",
            FormaIngreso = (int)FormaIngreso14D.Traspaso,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 4,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 5600,
            Descripcion = "Montos pagados asociados a la mantención del giro",
            FormaIngreso = 0,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 5700,
            Descripcion = "Remuneraciones pagadas",
            FormaIngreso = (int)FormaIngreso14D.Traspaso,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 5800,
            Descripcion = "Honorarios pagados",
            FormaIngreso = (int)FormaIngreso14D.TraspasoAjuste,
            Regimen = "",
            IdItemCtasAsociadasAjustes = 4
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 5900,
            Descripcion = "Intereses pagados por préstamos",
            FormaIngreso = (int)FormaIngreso14D.Traspaso,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 6000,
            Descripcion = "Impuestos que no sean de la LIR",
            FormaIngreso = (int)FormaIngreso14D.Traspaso,
            Regimen = "",
            IdItemCtasAsociadasAjustes = 5
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 6100,
            Descripcion = "Arriendos pagados",
            FormaIngreso = (int)FormaIngreso14D.Traspaso,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 6200,
            Descripcion = "Gastos de Rentas de Fuente Extranjera",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 4,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 6300,
            Descripcion = "Egresos pagados por la adquisición de inversiones o activos en el año de la percepción por la enajenación",
            FormaIngreso = 0,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 6400,
            Descripcion = "Monto pagado reajustado por inversiones en capitales mobiliarios",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 6500,
            Descripcion = "Monto pagado reajustado por contratos de asociación o cuentas en participación",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 6600,
            Descripcion = "Monto pagado reajustado por adquisición de acciones",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 6700,
            Descripcion = "Monto pagado reajustado por adquisición de derechos sociales",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 6800,
            Descripcion = "Monto pagado reajustado por adquisición de terrenos",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 6900,
            Descripcion = "Monto pagado reajustado por adquisición de otros bienes que no se deprecian",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        // Gastos Art. 21 (solo 14DN3)
        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 4,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 7000,
            Descripcion = "Gastos afectos al articulo 21 LIR",
            FormaIngreso = 0,
            Regimen = RegimenesTributarios.FTE_14DN3
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 7100,
            Descripcion = "Gastos afectos al inciso 1º, del art 21 LIR",
            FormaIngreso = (int)FormaIngreso14D.TraspasoAjuste,
            Regimen = RegimenesTributarios.FTE_14DN3,
            IdItemCtasAsociadasAjustes = 6
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 7200,
            Descripcion = "Gastos afectos al inciso 3º, del art 21 LIR",
            FormaIngreso = (int)FormaIngreso14D.TraspasoAjuste,
            Regimen = RegimenesTributarios.FTE_14DN3,
            IdItemCtasAsociadasAjustes = 7
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 4,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 7300,
            Descripcion = "Gastos rechazados pagados no gravados con el art. 21 LIR",
            FormaIngreso = 0,
            Regimen = RegimenesTributarios.FTE_14DN3
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 7400,
            Descripcion = "Partidas pagadas del inciso 1º del art 21, no afectas al I.U.",
            FormaIngreso = (int)FormaIngreso14D.Traspaso,
            Regimen = RegimenesTributarios.FTE_14DN3
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 7500,
            Descripcion = "Pago de IDPC",
            FormaIngreso = (int)FormaIngreso14D.TraspasoAjuste,
            Regimen = RegimenesTributarios.FTE_14DN3,
            IdItemCtasAsociadasAjustes = 9
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 7600,
            Descripcion = "Pago de IDPC AT 2020 o anteriores que depuran REX",
            FormaIngreso = (int)FormaIngreso14D.TraspasoAjuste,
            Regimen = RegimenesTributarios.FTE_14DN3,
            IdItemCtasAsociadasAjustes = 10
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 7700,
            Descripcion = "Gastos asociados a INR",
            FormaIngreso = (int)FormaIngreso14D.TraspasoAjuste,
            Regimen = RegimenesTributarios.FTE_14DN3,
            IdItemCtasAsociadasAjustes = 11
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 7800,
            Descripcion = "Pago 30% ISFUT",
            FormaIngreso = (int)FormaIngreso14D.TraspasoAjuste,
            Regimen = RegimenesTributarios.FTE_14DN3,
            IdItemCtasAsociadasAjustes = 12
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 7900,
            Descripcion = "Otras partidas pagadas del inciso 2º del art 21, distintos de los anteriores",
            FormaIngreso = (int)FormaIngreso14D.TraspasoAjuste,
            Regimen = RegimenesTributarios.FTE_14DN3,
            IdItemCtasAsociadasAjustes = 13
        });

        // Gastos Rechazados (solo 14DN8)
        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 4,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 8000,
            Descripcion = "Gastos rechazados pagados",
            FormaIngreso = 0,
            Regimen = RegimenesTributarios.FTE_14DN8
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 8100,
            Descripcion = "Gastos pagados que no cumplen los requisitos del art 31 LIR",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = RegimenesTributarios.FTE_14DN8
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 4,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 8200,
            Descripcion = "Agregado por gastos rechazados pagados",
            FormaIngreso = 0,
            Regimen = RegimenesTributarios.FTE_14DN8
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 8300,
            Descripcion = "Gastos pagados que no cumplen los requisitos del art 31 LIR",
            FormaIngreso = (int)FormaIngreso14D.Traspaso,
            Regimen = RegimenesTributarios.FTE_14DN8
        });

        // Nivel 3: Créditos Incobrables
        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 3,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 8400,
            Descripcion = "Créditos Incobrables por ingresos que ya se reconocieron sobre base devengada",
            FormaIngreso = 0,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 4,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 8500,
            Descripcion = "Créditos incobrables castigados",
            FormaIngreso = 0,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 8600,
            Descripcion = "Créditos incobrables",
            FormaIngreso = (int)FormaIngreso14D.TraspasoAjuste,
            Regimen = "",
            IdItemCtasAsociadasAjustes = 8
        });

        // Nivel 3: Ajustes por Cambio de Régimen
        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 3,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 8700,
            Descripcion = "Ajustes en el año por cambio de régimen",
            FormaIngreso = 0,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 4,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 8800,
            Descripcion = "Ajustes en el año por cambio de régimen, al ingresar al régimen del Art. 14D",
            FormaIngreso = 0,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 8900,
            Descripcion = "Valor Neto de Activos fijos depreciables",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 9000,
            Descripcion = "Existencias del activo realizable",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 9100,
            Descripcion = "Gastos diferidos que se mantenian en el activo",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 9200,
            Descripcion = "Gasto por Pérdida Tributaria en cambio de Régimen",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        // Nivel 3: Otros Gastos
        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 3,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 9300,
            Descripcion = "Otros Gastos que se deducen de la Base Imponible",
            FormaIngreso = 0,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 4,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 9400,
            Descripcion = "Otros Gastos que se deducen de la Base Imponible",
            FormaIngreso = 0,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 9500,
            Descripcion = "Gastos adeudados asociados a ingresos devengados con empresas relacionadas del régimen 14A",
            FormaIngreso = (int)FormaIngreso14D.Traspaso,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 9600,
            Descripcion = "Pérdida del año anterior",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 9700,
            Descripcion = "Gastos por responsabilidad social",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 9800,
            Descripcion = "Gastos por inversión en investigación y desarrollo no certificados por CORFO",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = RegimenesTributarios.FTE_14DN3
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 9900,
            Descripcion = "Gastos por inversión en investigación y desarrollo certificados por CORFO",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = RegimenesTributarios.FTE_14DN3
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 10000,
            Descripcion = "Amortización de intangibles, art. 22º transitorio bis, inc. 4º, 5º y 6º Ley Nº 21.210",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 10100,
            Descripcion = "Gastos aceptados por donaciones",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = RegimenesTributarios.FTE_14DN3
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 10200,
            Descripcion = "Ingresos Exentos de IDPC",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = RegimenesTributarios.FTE_14DN3
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 10300,
            Descripcion = "Ingresos no rentas",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = RegimenesTributarios.FTE_14DN3
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 10400,
            Descripcion = "Otras deducciones a la RLI",
            FormaIngreso = (int)FormaIngreso14D.Traspaso,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 10410,
            Descripcion = "Otros Gastos",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = ""
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 10420,
            Descripcion = "Gastos por Donaciones",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = RegimenesTributarios.FTE_14DN8,
            AnoDesde = 2023
        });

        // Nivel 3: Ajustes a la Base Imponible (solo 14DN3)
        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 3,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 10500,
            Descripcion = "Ajustes a la Base Imponible",
            FormaIngreso = 0,
            Regimen = RegimenesTributarios.FTE_14DN3
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 4,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 10600,
            Descripcion = "Ajustes a la Base Imponible",
            FormaIngreso = 0,
            Regimen = RegimenesTributarios.FTE_14DN3
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 10700,
            Descripcion = "Agregado por gastos rechazados pagados",
            FormaIngreso = (int)FormaIngreso14D.Traspaso,
            Regimen = RegimenesTributarios.FTE_14DN3
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 10800,
            Descripcion = "Partidas pagadas del inciso 1º del art 21, no afectas al I.U.",
            FormaIngreso = (int)FormaIngreso14D.Traspaso,
            Regimen = RegimenesTributarios.FTE_14DN3
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 10900,
            Descripcion = "Pago de IDPC",
            FormaIngreso = (int)FormaIngreso14D.Traspaso,
            Regimen = RegimenesTributarios.FTE_14DN3
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 11000,
            Descripcion = "Pago de IDPC AT 2020 o anteriores que depuran REX",
            FormaIngreso = (int)FormaIngreso14D.Traspaso,
            Regimen = RegimenesTributarios.FTE_14DN3
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 11100,
            Descripcion = "Gastos asociados a INR",
            FormaIngreso = (int)FormaIngreso14D.Traspaso,
            Regimen = RegimenesTributarios.FTE_14DN3
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 11200,
            Descripcion = "Pago 30% ISFUT",
            FormaIngreso = (int)FormaIngreso14D.Traspaso,
            Regimen = RegimenesTributarios.FTE_14DN3
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 11300,
            Descripcion = "Otras partidas pagadas del inciso 2º del art 21, distintos de los anteriores",
            FormaIngreso = (int)FormaIngreso14D.Traspaso,
            Regimen = RegimenesTributarios.FTE_14DN3
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 4,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 11400,
            Descripcion = "Ajustes art 14 Letra E y art 14 A nº6, ambos de la LIR",
            FormaIngreso = 0,
            Regimen = RegimenesTributarios.FTE_14DN3
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 11500,
            Descripcion = "Franquicia Letra E, Art 14 LIR",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = RegimenesTributarios.FTE_14DN3
        });

        estructura.Add(new BaseImponibleConfig
        {
            Nivel = 5,
            Tipo = (int)TipoBaseImponible14D.Egreso,
            Codigo = 11600,
            Descripcion = "Deducción por pago IDPC Voluntario en años anteriores",
            FormaIngreso = (int)FormaIngreso14D.Manual,
            Regimen = RegimenesTributarios.FTE_14DN3
        });

        return estructura;
    }

    /// <summary>
    /// Obtener estructura filtrada mostrando solo items con valores != 0 (Saldos Vigentes)
    /// Migrado de VB6: SaldosVigentes (líneas 1057-1074)
    /// </summary>
    public async Task<BaseImponible14DCompletaDto> GetItemsWithBalancesAsync(int empresaId, short ano)
    {
        _logger.LogInformation("Obteniendo saldos vigentes para empresa {EmpresaId} año {Ano}", empresaId, ano);

        {
            // Primero obtener todos los datos
            var baseData = await GetByEmpresaAnoAsync(empresaId, ano);

            // Filtrar recursivamente items con valor != 0
            // VB6: For i = Grid.FixedRows To Grid.rows - 1
            //      If Val(Grid.TextMatrix(i, C_NIVEL)) > 2 Then
            //         If vFmt(Grid.TextMatrix(i, C_VALOR)) = 0 Then
            //            Grid.RowHeight(i) = 0  ' Ocultar
            if (baseData.Secciones != null)
            {
                foreach (var seccion in baseData.Secciones)
                {
                    if (seccion.Items != null)
                    {
                        seccion.Items = FilterItemsWithBalances(seccion.Items).ToList();
                    }
                }
            }

            _logger.LogInformation("Filtrado completado: saldos vigentes empresa {EmpresaId} año {Ano}", empresaId, ano);
            return baseData;
        }
    }

    /// <summary>
    /// Filtrar recursivamente items manteniendo solo los que tienen valor != 0 o sus padres
    /// </summary>
    private IEnumerable<BaseImponible14DItemDto> FilterItemsWithBalances(List<BaseImponible14DItemDto> items)
    {
        if (items == null || !items.Any())
            return Enumerable.Empty<BaseImponible14DItemDto>();

        var result = new List<BaseImponible14DItemDto>();

        foreach (var item in items)
        {
            // VB6: If Val(Grid.TextMatrix(i, C_NIVEL)) > 2 Then
            //          If vFmt(Grid.TextMatrix(i, C_VALOR)) = 0 Then
            //              Grid.RowHeight(i) = 0  ' Ocultar
                
            // Regla 1: Siempre mostrar niveles 1 y 2 (títulos y subtítulos)
            if (item.Nivel <= 2)
            {
                var filteredItem = new BaseImponible14DItemDto
                {
                    Nivel = item.Nivel,
                    Codigo = item.Codigo,
                    Descripcion = item.Descripcion,
                    Valor = item.Valor,
                    EsEditable = item.EsEditable,
                    EsSubtotal = item.EsSubtotal,
                    TieneHijos = item.TieneHijos,
                    EsNegrita = item.EsNegrita,
                    ColorTexto = item.ColorTexto
                };

                // Filtrar hijos recursivamente
                if (item.Hijos != null && item.Hijos.Any())
                {
                    filteredItem.Hijos = FilterItemsWithBalances(item.Hijos).ToList();
                    filteredItem.TieneHijos = filteredItem.Hijos.Any();
                }

                result.Add(filteredItem);
            }
            // Regla 2: Para niveles > 2, solo mostrar si valor != 0
            else if (item.Valor != 0)
            {
                var filteredItem = new BaseImponible14DItemDto
                {
                    Nivel = item.Nivel,
                    Codigo = item.Codigo,
                    Descripcion = item.Descripcion,
                    Valor = item.Valor,
                    EsEditable = item.EsEditable,
                    EsSubtotal = item.EsSubtotal,
                    TieneHijos = item.TieneHijos,
                    EsNegrita = item.EsNegrita,
                    ColorTexto = item.ColorTexto
                };

                // Filtrar hijos recursivamente
                if (item.Hijos != null && item.Hijos.Any())
                {
                    filteredItem.Hijos = FilterItemsWithBalances(item.Hijos).ToList();
                    filteredItem.TieneHijos = filteredItem.Hijos.Any();
                }

                result.Add(filteredItem);
            }
            // Regla 3: Si tiene hijos con valores, incluirlo aunque el padre tenga valor 0
            else if (item.Hijos != null && item.Hijos.Any())
            {
                var filteredChildren = FilterItemsWithBalances(item.Hijos).ToList();
                    
                if (filteredChildren.Any())
                {
                    var filteredItem = new BaseImponible14DItemDto
                    {
                        Nivel = item.Nivel,
                        Codigo = item.Codigo,
                        Descripcion = item.Descripcion,
                        Valor = item.Valor,
                        EsEditable = item.EsEditable,
                        EsSubtotal = item.EsSubtotal,
                        TieneHijos = true,
                        EsNegrita = item.EsNegrita,
                        ColorTexto = item.ColorTexto,
                        Hijos = filteredChildren
                    };

                    result.Add(filteredItem);
                }
            }
        }

        return result;
    }

    // Clase auxiliar para configuración de estructura
    private class BaseImponibleConfig
    {
        public byte Nivel { get; set; }
        public short Codigo { get; set; }
        public byte Tipo { get; set; }
        public string Descripcion { get; set; } = string.Empty;
        public byte FormaIngreso { get; set; }
        public string Regimen { get; set; } = string.Empty;
        public int AnoDesde { get; set; }
        public int IdItemCtasAsociadasAjustes { get; set; }
    }
}