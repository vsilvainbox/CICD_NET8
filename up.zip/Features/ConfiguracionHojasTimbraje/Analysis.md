# Legacy Analysis: ConfiguracionHojasTimbraje

## 📄 Información del Formulario VB6

**Archivo VB6:** `vb6\Contabilidad70\HyperContabilidad\FrmPrtFoliacion.frm`
**Fecha Análisis:** 2025-10-08
**Analista:** IA
**Complejidad:** Media

### Propósito del Formulario
Este formulario permite **imprimir hojas foliadas para timbraje físico** de documentos tributarios. Muestra el historial de folios (último impreso, último timbrado, último usado) y permite generar nuevas hojas numeradas secuencialmente con los datos de la empresa para luego ser timbradas por el SII.

**⚠️ Nota:** Esta funcionalidad es parte del proceso físico obsoleto de timbraje. En sistemas modernos, el timbraje electrónico ha reemplazado este proceso.

---

## 🎨 CONTROLES UI IDENTIFICADOS

### Textboxes (Campos de Solo Lectura)
| Control VB6 | Propiedad Bound | Tipo | Validación | Propósito |
|-------------|----------------|------|------------|-----------|
| Tx_UltImpreso | Timbraje.UltImpreso | Integer | ReadOnly | Muestra último número de folio impreso |
| Tx_FUltImpreso | Timbraje.FUltImpreso | Date | ReadOnly | Fecha del último folio impreso |
| Tx_UltTimbrado | Timbraje.UltTimbrado | Integer | ReadOnly | Último número de folio timbrado por SII |
| Tx_FUltTimbrado | Timbraje.FUltTimbrado | Date | ReadOnly | Fecha del último timbraje |
| Tx_UltUsado | Timbraje.UltUsado | Integer | ReadOnly | Último folio efectivamente usado en documento |
| Tx_FUltUsado | Timbraje.FUltUsado | Date | ReadOnly | Fecha del último uso de folio |

### Textboxes (Campos de Entrada)
| Control VB6 | Propiedad Bound | Tipo | Validación | Propósito |
|-------------|----------------|------|------------|-----------|
| Tx_Desde | N/A | Integer | Required, >UltUsado, <=Hasta | Folio inicial del rango a imprimir |
| Tx_Hasta | N/A | Integer | Required, >=Desde, >UltUsado | Folio final del rango a imprimir |

**Nota:** Tx_Desde se inicializa automáticamente como `UltImpreso + 1`

### CheckBoxes
| Control VB6 | Valor | Propósito | Default |
|-------------|-------|-----------|---------|
| Ch_Prt | Boolean | Si está marcado, actualiza registro Timbraje con nuevo UltImpreso y FUltImpreso | Checked (True) |

### Radio Buttons (Orientación Papel)
| Control VB6 | Grupo | Opciones | Default | Propósito |
|-------------|-------|----------|---------|-----------|
| Op_Orientacion | Orientación | 1=Vertical, 2=Horizontal | Vertical | Define orientación de impresión de hojas |

### Botones de Acción
| Botón VB6 | Caption | Habilitado Si | Acción | Mapeo .NET |
|-----------|---------|---------------|--------|------------|
| Bt_Print | "Imprimir" | Validaciones OK | Imprime hojas foliadas y actualiza BD si Ch_Prt=True | [LEGACY] Generar PDF de hojas foliadas |
| Bt_Mod | "Modificar..." | Siempre | Abre FrmFoliacion para editar información de folios manualmente | EditarInformacionFoliosAsync() o modal |
| Bt_Cancel | "Cerrar" | Siempre | Cierra el formulario (lRc=vbCancel) | window.history.back() o cerrar modal |

#### 🚨 REGLA CRÍTICA: TODOS LOS BOTONES MIGRADOS

**✅ Bt_Cancel**: Botón estándar de cierre, implementar como navegación.

**⚠️ Bt_Print**: Funcionalidad obsoleta pero debe migrarse.
```html
// TODO: [LEGACY] [LOW] Impresión física de hojas obsoleta en era digital
// VB6: Imprimía hojas físicas para timbrar en SII
// .NET: Generar PDF descargable con hojas foliadas (alternativa moderna)
// Alternativa: Usar window.print() con @media print o generar PDF con datos empresa
```

**✅ Bt_Mod**: Abre modal o redirige a FrmFoliacion (feature separada).
```html
// TODO: [BLOCKED] [MEDIUM] [BLOCKED_BY: InformacionFolios] Requiere migración de FrmFoliacion
// Dependencia: Feature "Información de Folios" debe estar migrada primero
```

---

## 🔘 EVENTOS IDENTIFICADOS

### Eventos de Formulario
| Evento VB6 | Cuándo Ocurre | Acciones | Mapeo .NET |
|------------|---------------|----------|------------|
| Form_Load | Al abrir form | 1. Selecciona orientación vertical por defecto<br>2. Llama LoadAll() para cargar datos<br>3. Llama SetupPriv() para validar permisos (PRV_ADM_TIMB)<br>4. Si no tiene permisos, deshabilita formulario | OnPageLoad JS + GetTimbrajeAsync() |

### Eventos de Botones
| Botón.Evento | Trigger | Acción VB6 | Mapeo .NET |
|--------------|---------|------------|------------|
| Bt_Print.Click | Usuario hace clic | 1. Valida() rangos y restricciones<br>2. PrtHojasFoliadas() imprime hojas<br>3. Si Ch_Prt=True: INSERT/UPDATE Timbraje con nuevo UltImpreso<br>4. Actualiza variable global gFoliacion<br>5. Cierra formulario | ImprimirHojasAsync() + ActualizarTimbrajeAsync() |
| Bt_Mod.Click | Usuario hace clic | 1. Crea instancia FrmFoliacion<br>2. Abre en modo modal<br>3. Si usuario acepta (FEdit=vbOK), recarga datos con LoadAll() | [BLOCKED] Abrir modal InformacionFolios |
| Bt_Cancel.Click | Usuario hace clic | 1. lRc = vbCancel<br>2. Unload Me (cierra formulario) | window.history.back() |

### Eventos de Controles
| Control.Evento | Trigger | Acción VB6 | Mapeo .NET |
|----------------|---------|------------|------------|
| Op_Orientacion.Click(Index) | Usuario selecciona orientación | lIdxOrientacion = Index (guarda selección) | Actualizar variable en JavaScript |

---

## 🔧 FUNCIONES Y PROCEDIMIENTOS VB6

### Funciones Privadas

```vb
' Función: LoadAll
' Propósito: Cargar datos de timbraje desde variable global gFoliacion
' Parámetros: Ninguno (usa global gFoliacion)
' Retorno: Void
' Detalles:
'   - Si gFoliacion.Estado = EF_EXISTE:
'     * Carga Tx_UltImpreso, Tx_FUltImpreso (formato DATEFMT)
'     * Carga Tx_UltTimbrado, Tx_FUltTimbrado
'     * Carga Tx_UltUsado, Tx_FUltUsado
'   - Inicializa Tx_Desde = UltImpreso + 1
'   - Inicializa Tx_Hasta = Tx_Desde
' Mapeo .NET: GetTimbrajeAsync(int empresaId) en Service
Private Sub LoadAll()
    If gFoliacion.Estado = EF_EXISTE Then
        Tx_UltImpreso = IIf(gFoliacion.UltImpreso <> 0, gFoliacion.UltImpreso, "")
        Tx_FUltImpreso = IIf(gFoliacion.FUltImpreso <> 0, Format(gFoliacion.FUltImpreso, DATEFMT), "")
        Tx_UltTimbrado = IIf(gFoliacion.UltTimbrado <> 0, gFoliacion.UltTimbrado, "")
        Tx_FUltTimbrado = IIf(gFoliacion.FUltTimbrado <> 0, Format(gFoliacion.FUltTimbrado, DATEFMT), "")
        Tx_UltUsado = IIf(gFoliacion.UltUsado <> 0, gFoliacion.UltUsado, "")
        Tx_FUltUsado = IIf(gFoliacion.FUltUsado <> 0, Format(gFoliacion.FUltUsado, DATEFMT), "")
    End If
    Tx_Desde = vFmt(Tx_UltImpreso) + 1
    Tx_Hasta = Tx_Desde
End Sub
```

```vb
' Función: Valida
' Propósito: Validar campos antes de imprimir hojas
' Parámetros: Ninguno (valida controles del form)
' Retorno: Boolean (True si válido)
' Validaciones:
'   1. Si Desde o Hasta <= UltTimbrado: Confirmar con usuario (puede reimprimir timbrados no usados)
'   2. Si Desde o Hasta <= UltUsado: ERROR - No puede reimprimir folios ya usados
'   3. Si Hasta = 0: ERROR - Debe ingresar folio hasta
'   4. Si Desde > Hasta: ERROR - Folio inicio no puede ser mayor al término
' Mapeo .NET: ValidarRangoFoliosAsync() en Service
Private Function Valida() As Boolean
    Valida = False

    ' Advertencia si imprime folios <= últimotimbrado (pero permite continuar)
    If vFmt(Tx_Desde) <= vFmt(Tx_UltTimbrado) Or vFmt(Tx_Hasta) <= vFmt(Tx_UltTimbrado) Then
        If MsgBox1("¡ATENCION! Usted está indicando un número de folio menor o igual a un folio ya timbrado. ¿Está seguro de continuar?", vbQuestion Or vbYesNo Or vbDefaultButton2) <> vbYes Then
            Exit Function
        End If
    End If

    ' Error crítico: no puede reimprimir folios usados
    If vFmt(Tx_Desde) <= vFmt(Tx_UltUsado) Or vFmt(Tx_Hasta) <= vFmt(Tx_UltUsado) Then
        MsgBox1 "No puede volver a imprimir folio ya usados.", vbExclamation
        Exit Function
    End If

    ' Validación campo obligatorio
    If vFmt(Tx_Hasta) = 0 Then
        MsgBox1 "Debe ingresar el folio hasta el cual desea imprimir.", vbExclamation
        Tx_Hasta.SetFocus
        Exit Function
    End If

    ' Validación lógica de rangos
    If vFmt(Tx_Desde) > vFmt(Tx_Hasta) Then
        MsgBox1 "Folio inicio no puede ser mayor al folio de término.", vbExclamation
        Tx_Hasta.SetFocus
        Exit Function
    End If

    Valida = True
End Function
```

```vb
' Función: PrtHojasFoliadas
' Propósito: Imprimir físicamente las hojas foliadas en impresora
' Parámetros: Ninguno (usa Tx_Desde, Tx_Hasta, lIdxOrientacion)
' Retorno: Void
' Detalles:
'   - Selecciona impresora con SelPrinter()
'   - Configura orientación (vertical/horizontal)
'   - Itera desde nDesde hasta nHasta
'   - Para cada folio imprime:
'     * Encabezado con "Folio: 00000001" (8 dígitos)
'     * Razón Social
'     * RUT (formateado con guión)
'     * Dirección + Comuna/Ciudad
'     * Giro
'     * Representante Legal 1 (si existe)
'     * Representante Legal 2 (si RepConjunta y existe)
'   - Usa Printer.NewPage entre hojas
' Mapeo .NET: GenerarPdfHojasAsync() o window.print() con CSS @media print
Private Sub PrtHojasFoliadas()
    ' ... configuración printer ...
    For nhojas = nDesde To nHasta
        ' Imprime folio: "Folio: 00000001"
        ' Imprime datos empresa: RazonSocial, RUT, Direccion, Giro, RepLegal
        If nhojas < nHasta Then
            Printer.NewPage
        End If
    Next nhojas
    Printer.EndDoc
End Sub
```

```vb
' Función: SetupPriv
' Propósito: Validar permisos de usuario
' Parámetros: Ninguno
' Retorno: Void
' Detalles:
'   - Verifica privilegio PRV_ADM_TIMB (administrar timbraje)
'   - Si no tiene permiso: deshabilita todo el formulario con EnableForm(Me, False)
' Mapeo .NET: Middleware de autorización en .NET (validar rol/claim)
Private Sub SetupPriv()
    If Not ChkPriv(PRV_ADM_TIMB) Then
        Call EnableForm(Me, False)
    End If
End Sub
```

### Lista Completa de Funciones
| Función VB6 | Tipo | Propósito | Mapeo .NET Method |
|-------------|------|-----------|-------------------|
| LoadAll() | Private Sub | Cargar datos timbraje | GetTimbrajeAsync(empresaId) |
| Valida() | Private Function→Boolean | Validar rangos folios | ValidarRangoFoliosAsync(desde, hasta) |
| PrtHojasFoliadas() | Private Sub | Imprimir hojas físicas | GenerarPdfHojasAsync(desde, hasta, orientacion) |
| SetupPriv() | Private Sub | Validar permisos | [MIDDLEWARE] Autorización .NET |

---

## 💾 ACCESO A DATOS VB6

### Query 1: Verificar Existencia de Timbraje
**Ubicación:** Bt_Print_Click
**Propósito:** Si no existe registro de timbraje para la empresa, crearlo antes de actualizar

```vb
' VB6: Verificación y creación
If gFoliacion.Estado = EF_NOEXISTE Then
    Q1 = "INSERT INTO Timbraje (idEmpresa) VALUES (" & gEmpresa.id & ")"
    Call ExecSQL(DbMain, Q1)
End If
```

**Mapeo Entity Framework:**
```csharp
var timbraje = await _context.Timbraje
    .FirstOrDefaultAsync(t => t.idEmpresa == empresaId);

if (timbraje == null)
{
    timbraje = new App.Data.Timbraje { idEmpresa = empresaId };
    _context.Timbraje.Add(timbraje);
    await _context.SaveChangesAsync();
}
```

### Query 2: Actualizar Último Folio Impreso
**Ubicación:** Bt_Print_Click (si Ch_Prt = True)
**Propósito:** Guardar el nuevo UltImpreso y FUltImpreso después de imprimir

```vb
' VB6: Update después de imprimir
F1 = CLng(Int(Now))  ' Fecha actual en formato entero

Q1 = "UPDATE Timbraje SET UltImpreso=" & vFmt(Tx_Hasta)
Q1 = Q1 & ", FUltImpreso=" & F1
Q1 = Q1 & " WHERE idEmpresa=" & gEmpresa.id
Call ExecSQL(DbMain, Q1)
```

**Mapeo Entity Framework:**
```csharp
var timbraje = await _context.Timbraje
    .FirstOrDefaultAsync(t => t.idEmpresa == empresaId);

if (timbraje != null)
{
    timbraje.UltImpreso = hasta;
    timbraje.FUltImpreso = ConvertToIntDate(DateTime.Now);  // YYYYMMDD format
    await _context.SaveChangesAsync();
}
```

**Entidades Utilizadas:**
- **App.Data.Timbraje** - Propiedades: `idEmpresa` (⚠️ camelCase), `UltImpreso`, `FUltImpreso`, `UltTimbrado`, `FUltTimbrado`, `UltUsado`, `FUltUsado`
- **App.Data.Empresa** - Propiedades: `Id`, `RazonSocial`, `Rut`, `RutDisp`, `Direccion`, `Ciudad`, `Comuna`, `Giro`, `RepLegal1`, `RutRepLegal1`, `RepLegal2`, `RutRepLegal2`, `RepConjunta`

**⚠️ CASE-SENSITIVITY:** `Timbraje.idEmpresa` usa camelCase (primera letra minúscula).

---

## ✅ VALIDACIONES Y REGLAS DE NEGOCIO

### Validaciones de Campos
| Campo | Regla | Mensaje Error VB6 | Implementar en .NET |
|-------|-------|-------------------|---------------------|
| Tx_Hasta | Obligatorio | "Debe ingresar el folio hasta el cual desea imprimir." | [Required] |
| Tx_Desde | Debe ser <= Tx_Hasta | "Folio inicio no puede ser mayor al folio de término." | Custom validation |
| Tx_Desde/Tx_Hasta | No puede ser <= UltUsado | "No puede volver a imprimir folio ya usados." | CheckFoliosUsadosAsync() |
| Tx_Desde/Tx_Hasta | Advertencia si <= UltTimbrado | "¡ATENCION! ...folio ya timbrado. ¿Continuar?" | Confirmación con SweetAlert |

### Reglas de Negocio
1. **No reimprimir folios usados**: Folios marcados como "usados" no pueden reimprimirse (restricción crítica)
   **→ Implementar:** Validación `ValidarRangoFoliosAsync()` retorna error si rango incluye folios usados

2. **Advertir reimprimir folios timbrados**: Permitir reimprimir folios timbrados pero no usados (con confirmación)
   **→ Implementar:** Modal de confirmación en JavaScript si rango incluye folios timbrados

3. **Inicialización automática del rango**: Tx_Desde se inicializa automáticamente como UltImpreso + 1
   **→ Implementar:** Calcular en backend: `desde = timbraje.UltImpreso + 1`

4. **Actualización condicional**: Solo actualiza BD si Ch_Prt está marcado
   **→ Implementar:** Parámetro `actualizarBD` en método `ImprimirHojasAsync()`

5. **Permisos requeridos**: Usuario debe tener privilegio PRV_ADM_TIMB para usar formulario
   **→ Implementar:** `[Authorize(Policy = "AdminTimbraje")]` en controller o middleware

---

## 🧮 CÁLCULOS Y FÓRMULAS

### Cálculo 1: Formato de Fecha YYYYMMDD
```vb
' VB6: Conversión de fecha actual a entero
F1 = CLng(Int(Now))  ' Ej: 20251008 para 8 de octubre de 2025
```
**→ Implementar:**
```csharp
public int ConvertToIntDate(DateTime date)
{
    return date.Year * 10000 + date.Month * 100 + date.Day;
}
```

### Cálculo 2: Folio Inicial Automático
```vb
' VB6: Calcular folio desde
Tx_Desde = vFmt(Tx_UltImpreso) + 1
```
**→ Implementar:**
```csharp
int folioDesde = (timbraje?.UltImpreso ?? 0) + 1;
```

### Cálculo 3: Formato Folio con Ceros a la Izquierda
```vb
' VB6: Formato "Folio: 00000001" (8 dígitos)
nFolio = "Folio: " & Right("00000000" & nhojas, 8)
```
**→ Implementar:**
```csharp
string nFolio = $"Folio: {numeroFolio:D8}";  // D8 = 8 dígitos con ceros
```

---

## 🚀 NAVEGACIÓN Y FLUJO

### Formularios Llamados
| Desde VB6 | Formulario Destino | Parámetros | Retorno | Mapeo .NET |
|-----------|-------------------|------------|---------|------------|
| Bt_Mod.Click | FrmFoliacion.frm | Ninguno | vbOK/vbCancel (FEdit) | [BLOCKED] Redirect a /InformacionFolios (cuando esté migrado) |

### Flujo de Estados del Form
```
[Inicio] → Form_Load()
  ↓
[Estado: Visualizando]
  - Muestra datos readonly (Ult impreso, timbrado, usado)
  - Tx_Desde = UltImpreso + 1
  - Usuario puede:
    * Modificar Tx_Desde, Tx_Hasta
    * Cambiar orientación papel
    * Marcar/desmarcar Ch_Prt
  ↓
[Usuario clic Bt_Print] → Valida()
  ↓ (Si válido)
[Estado: Imprimiendo]
  - PrtHojasFoliadas() genera hojas
  - Si Ch_Prt=True: UPDATE Timbraje
  - Cierra formulario
  ↓
[Fin]

[Usuario clic Bt_Mod] → Abre FrmFoliacion modal
  ↓ (Si usuario acepta cambios)
[Estado: Recargando]
  - LoadAll() refresca datos
  - Vuelve a [Estado: Visualizando]
```

---

## 📊 EXPORTACIONES E IMPORTACIONES

### Exportación (Impresión) de Hojas Foliadas

**Formato VB6:** Impresión física directa a impresora con Printer.Print

**Contenido de cada hoja:**
```
                                                    Folio: 00000001

Razón Social:    [gEmpresa.RazonSocial]
RUT:             [gEmpresa.Rut con formato XX.XXX.XXX-X]
Dirección:       [gEmpresa.Direccion, Ciudad/Comuna]
Giro:            [gEmpresa.Giro]
Rep. Legal:      [gEmpresa.RepLegal1]
RUT Rep. Legal:  [gEmpresa.RutRepLegal1 con formato]
[Si RepConjunta:]
Rep. Legal:      [gEmpresa.RepLegal2]
RUT Rep. Legal:  [gEmpresa.RutRepLegal2 con formato]
```

**→ Implementar:**
- **Opción 1 (Recomendada):** Generar PDF descargable con biblioteca como iTextSharp/QuestPDF
- **Opción 2:** Usar window.print() con CSS @media print para imprimir vista HTML

---

## 🎯 MAPEO FINAL: MÉTODOS .NET DETERMINADOS

### Interface del Service
```csharp
public interface IConfiguracionHojasTimbrajeService
{
    // Obtener información de timbraje
    Task<TimbrajeDto?> GetTimbrajeAsync(int empresaId);

    // Validar rango de folios
    Task<ValidationResult> ValidarRangoFoliosAsync(int empresaId, int desde, int hasta);

    // Actualizar último folio impreso
    Task<ValidationResult> ActualizarUltimoImpresoAsync(int empresaId, int hasta);

    // Generar datos para PDF/impresión
    Task<HojasTimbrajeDto> GenerarDatosHojasAsync(int empresaId, int desde, int hasta, string orientacion);

    // Obtener información de empresa para hojas
    Task<EmpresaTimbrajeDto?> GetEmpresaTimbrajeAsync(int empresaId);
}
```

### Resumen de Mapeo
| Funcionalidad VB6 | Método .NET | Complejidad | Prioridad |
|-------------------|-------------|-------------|-----------|
| Form_Load + LoadAll() | GetTimbrajeAsync(int empresaId) | Baja | Alta |
| Valida() | ValidarRangoFoliosAsync(desde, hasta) | Media | Alta |
| Bt_Print_Click UPDATE | ActualizarUltimoImpresoAsync(empresaId, hasta) | Baja | Alta |
| PrtHojasFoliadas() | GenerarDatosHojasAsync() o window.print() | Alta | Media |
| SetupPriv() | [MIDDLEWARE] Authorization Policy | Baja | Media |
| Bt_Mod_Click | [BLOCKED] Navegar a InformacionFolios | Baja | Baja |

---

## ⚠️ NOTAS IMPORTANTES Y OBSERVACIONES

### Peculiaridades del Form VB6
- **Variable global gFoliacion**: VB6 usa variable global cargada en memoria, .NET debe consultar BD
- **Fechas en formato entero**: FUltImpreso, FUltTimbrado, FUltUsado almacenan fechas como YYYYMMDD (ej: 20251008)
- **Permisos requeridos**: Formulario se deshabilita completamente si usuario no tiene PRV_ADM_TIMB
- **Impresión directa**: VB6 imprime directamente con Printer.Print, .NET debe generar PDF o usar window.print()
- **Confirmación reimprimir timbrados**: Permite reimprimir folios timbrados (con advertencia) pero NO usados

### Decisiones de Diseño
- **Modernizar impresión**: En lugar de Printer.Print, generar PDF descargable o usar window.print() con CSS @media print
- **Autorización**: Implementar con `[Authorize]` attribute y policies en .NET en lugar de habilitar/deshabilitar form
- **Validaciones async**: Validar en backend con queries para mayor seguridad
- **Modal vs Página**: Considerar implementar como modal en lugar de página completa (más moderno)

### Dependencias Externas
- **FrmFoliacion**: Feature bloqueada hasta que se migre "InformacionFolios"
- **Permisos**: Requiere sistema de autorización configurado (roles/claims)
- **Datos empresa**: Depende de que Empresa esté correctamente poblada en BD

### Pendientes/Incompletos en VB6
- **Bt_Mod**: Botón EXISTE y funcional → **MIGRAR**: Incluir botón con TODO [BLOCKED]
- **Impresión física obsoleta**: Funcionalidad legacy que debe migrarse pero con alternativa moderna (PDF)

---

## ✅ CHECKLIST DE COMPLETITUD DEL ANÁLISIS

- [x] Todos los controles UI documentados
- [x] Todos los botones y eventos mapeados
- [x] **TODOS los botones tienen "Mapeo .NET" definido** (Bt_Print: [LEGACY] PDF, Bt_Mod: [BLOCKED], Bt_Cancel: navegación)
- [x] **Botones con excepciones documentan razón válida** (Bt_Print: LEGACY proceso físico, Bt_Mod: BLOCKED por FrmFoliacion)
- [x] Todas las funciones VB6 identificadas
- [x] Todos los queries SQL traducidos a EF Core
- [x] Todas las validaciones documentadas
- [x] Todas las reglas de negocio identificadas
- [x] Todos los cálculos documentados
- [x] Navegación y flujos mapeados
- [x] Métodos .NET determinados
- [x] Interface del Service definida
- [x] **Decisiones de excepción justificadas y estructuradas** (Bt_Print: LEGACY, Bt_Mod: BLOCKED)
- [x] **Entidades verificadas en app/Data** (Timbraje, Empresa)
- [x] **⚠️ Case-sensitivity verificado** (Timbraje.idEmpresa usa camelCase)

---

**✅ ANÁLISIS COMPLETO - LISTO PARA IMPLEMENTACIÓN**
