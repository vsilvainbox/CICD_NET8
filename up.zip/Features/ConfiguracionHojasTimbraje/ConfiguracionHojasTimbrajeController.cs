using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.ConfiguracionHojasTimbraje;

[Authorize]

public class ConfiguracionHojasTimbrajeController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<ConfiguracionHojasTimbrajeController> logger) : Controller
{
    public Task<IActionResult> Index()
    {
        // Obtener empresaId desde la sesi�n
        var empresaId = SessionHelper.EmpresaId;

        logger.LogInformation("Loading ConfiguracionHojasTimbraje for empresaId: {EmpresaId}", empresaId);

        ViewData["EmpresaId"] = empresaId;
        return Task.FromResult<IActionResult>(View());
    }

    // M�todo proxy para obtener datos de timbraje
    [HttpGet]
    public async Task<IActionResult> GetTimbraje(int empresaId)
    {
        logger.LogInformation("MVC Proxy: GetTimbraje for empresaId: {EmpresaId}", empresaId);

        var client = httpClientFactory.CreateClient("ApiClient");
        var url = linkGenerator.GetPathByAction(
            action: nameof(ConfiguracionHojasTimbrajeApiController.GetTimbraje),
            controller: nameof(ConfiguracionHojasTimbrajeApiController).Replace("Controller", ""),
            values: new { empresaId });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    // M�todo proxy para validar rango de folios
    [HttpPost]
    public async Task<IActionResult> Validar([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: Validar rango de folios");

        var client = httpClientFactory.CreateClient("ApiClient");
        var url = linkGenerator.GetPathByAction(
            action: nameof(ConfiguracionHojasTimbrajeApiController.Validar),
            controller: nameof(ConfiguracionHojasTimbrajeApiController).Replace("Controller", ""));
        var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }

    // M�todo proxy para actualizar �ltimo impreso
    [HttpPost]
    public async Task<IActionResult> Actualizar([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: Actualizar �ltimo impreso");

        var client = httpClientFactory.CreateClient("ApiClient");
        var url = linkGenerator.GetPathByAction(
            action: nameof(ConfiguracionHojasTimbrajeApiController.Actualizar),
            controller: nameof(ConfiguracionHojasTimbrajeApiController).Replace("Controller", ""));
        var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }
}