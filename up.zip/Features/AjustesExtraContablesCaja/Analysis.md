# Legacy Analysis: Ajustes Extra-Contables Libro Caja

## 📄 VB6: FrmAjustesExtraLibCaja.frm
**Propósito:** Grid editable para ajustes extra-contables del Libro de Caja (Art. 14 ter)

### Estructura
```
Saldo Libro Caja - Ingresos
Saldo Libro Caja - Egresos
= Saldo Final Libro Caja

AGREGADOS (gAjustesExtraCont TAEC_AGREGADOS):
  - Items configurables (TIA_INGDIRECTO editable, TIA_CTASASOCIADAS calculado)
  - Calculados especiales: 33 Bis, Ingresos relacionadas, Ingresos >12 meses, Gastos adeudados
  
DEDUCCIONES (gAjustesExtraCont TAEC_DEDUCCIONES):
  - Items configurables  
  - Gastos presuntos: 0.5% ingresos brutos (Min 1 UTM, Max 15 UTM)
  - Percepciones ingresos devengados

= Base Imponible afecta a IDPC
```

### Constantes VB6
- `TAEC_AGREGADOS = 1`, `TAEC_DEDUCCIONES = 2`
- `TIA_INGDIRECTO = 1` (editable), `TIA_CTASASOCIADAS = 2` (calculado)
- `TOPERCAJA_INGRESO = 1`, `TOPERCAJA_EGRESO = 2`
- `LIB_VENTAS = 1`

### Cálculos Especiales
1. **Saldos Caja**: SUM(`LibroCaja.Pagado`) por TipoOper
2. **33 Bis**: GetVal33Bis()
3. **Ingresos Relacionadas**: SUM(`Documento.SaldoDoc`) EntRelacionada
4. **Ingresos >12M Emisión**: SUM(SaldoDoc) DateDiff >12 meses
5. **Ingresos >12M Exigible**: SUM(`DocCuotas.MontoCuota`) no pagadas >12 meses
6. **Gastos Presuntos**: (Ingresos + IngNoPercib) * 0.005, topado [1 UTM, 15 UTM]

**Entidades:** `AjustesExtLibCaja`, `LibroCaja`, `Documento`, `DocCuotas`, `Entidades`
**Config Global:** `gAjustesExtraCont` (array de configuración de items)


## 📄 VB6: FrmAjustesExtraLibCaja.frm
**Propósito:** Grid editable para ajustes extra-contables del Libro de Caja (Art. 14 ter)

### Estructura
```
Saldo Libro Caja - Ingresos
Saldo Libro Caja - Egresos
= Saldo Final Libro Caja

AGREGADOS (gAjustesExtraCont TAEC_AGREGADOS):
  - Items configurables (TIA_INGDIRECTO editable, TIA_CTASASOCIADAS calculado)
  - Calculados especiales: 33 Bis, Ingresos relacionadas, Ingresos >12 meses, Gastos adeudados
  
DEDUCCIONES (gAjustesExtraCont TAEC_DEDUCCIONES):
  - Items configurables  
  - Gastos presuntos: 0.5% ingresos brutos (Min 1 UTM, Max 15 UTM)
  - Percepciones ingresos devengados

= Base Imponible afecta a IDPC
```

### Constantes VB6
- `TAEC_AGREGADOS = 1`, `TAEC_DEDUCCIONES = 2`
- `TIA_INGDIRECTO = 1` (editable), `TIA_CTASASOCIADAS = 2` (calculado)
- `TOPERCAJA_INGRESO = 1`, `TOPERCAJA_EGRESO = 2`
- `LIB_VENTAS = 1`

### Cálculos Especiales
1. **Saldos Caja**: SUM(`LibroCaja.Pagado`) por TipoOper
2. **33 Bis**: GetVal33Bis()
3. **Ingresos Relacionadas**: SUM(`Documento.SaldoDoc`) EntRelacionada
4. **Ingresos >12M Emisión**: SUM(SaldoDoc) DateDiff >12 meses
5. **Ingresos >12M Exigible**: SUM(`DocCuotas.MontoCuota`) no pagadas >12 meses
6. **Gastos Presuntos**: (Ingresos + IngNoPercib) * 0.005, topado [1 UTM, 15 UTM]

**Entidades:** `AjustesExtLibCaja`, `LibroCaja`, `Documento`, `DocCuotas`, `Entidades`
**Config Global:** `gAjustesExtraCont` (array de configuración de items)

