﻿namespace App.Features.AjustesExtraContablesCaja;

public interface IAjustesExtraContablesCajaService
{
    Task<AjustesExtraContablesCajaDto> CalcularAjustesAsync(int empresaId, short ano);
    Task<bool> GuardarAjustesAsync(SaveAjustesDto dto);
}
