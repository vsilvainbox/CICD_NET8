using Microsoft.AspNetCore.Mvc;

namespace App.Features.ConfiguracionInformes;

/// <summary>
/// API Controller para configuración de informes
/// </summary>
[ApiController]
[Route("api/[controller]/[action]")]
public class ConfiguracionInformesApiController(
    IConfiguracionInformesService service,
    ILogger<ConfiguracionInformesApiController> logger) : ControllerBase
{
    /// <summary>
    /// Obtiene la configuración de informes
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<ConfiguracionInformesResponse>> GetConfiguracion(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        {
            var request = new GetConfiguracionInformesRequest
            {
                EmpresaId = empresaId,
                Ano = ano
            };

            var response = await service.GetConfiguracionAsync(request);
            return Ok(response);
        }
    }

    /// <summary>
    /// Guarda la configuración de informes
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<ConfiguracionInformesResponse>> GuardarConfiguracion(
        [FromBody] ConfiguracionInformesRequest request)
    {
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var response = await service.SaveConfiguracionAsync(request);
                
            if (!response.Success)
            {
                return BadRequest(response);
            }

            return Ok(response);
        }
    }

    /// <summary>
    /// Obtiene los estados de documento disponibles
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<List<EstadoDocumentoDto>>> GetEstadosDocumento()
    {
        {
            var estados = await service.GetEstadosDocumentoAsync();
            return Ok(estados);
        }
    }
}