namespace App.Features.ConfiguracionInformes;

/// <summary>
/// Interface para servicio de configuración de informes
/// </summary>
public interface IConfiguracionInformesService
{
    /// <summary>
    /// Obtiene la configuración completa de informes
    /// </summary>
    Task<ConfiguracionInformesResponse> GetConfiguracionAsync(GetConfiguracionInformesRequest request);

    /// <summary>
    /// Guarda la configuración completa de informes
    /// </summary>
    Task<ConfiguracionInformesResponse> SaveConfiguracionAsync(ConfiguracionInformesRequest request);

    /// <summary>
    /// Obtiene los estados de documento disponibles
    /// </summary>
    Task<List<EstadoDocumentoDto>> GetEstadosDocumentoAsync();
}