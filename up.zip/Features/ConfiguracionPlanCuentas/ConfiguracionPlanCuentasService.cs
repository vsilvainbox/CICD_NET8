using Microsoft.EntityFrameworkCore;
using App.Data;

namespace App.Features.ConfiguracionPlanCuentas;

/// <summary>
/// Implementación del servicio de configuración de plan de cuentas
/// </summary>
public class ConfiguracionPlanCuentasService(LpContabContext context, ILogger<ConfiguracionPlanCuentasService> logger) : IConfiguracionPlanCuentasService
{
    // ======== Configuración de Franquicia ========

    public async Task<ConfiguracionActualDto?> GetConfiguracionActualAsync(int empresaId)
    {
        logger.LogInformation("Getting configuración actual for empresaId: {EmpresaId}", empresaId);

        {
            // Nota: Empresa tiene clave compuesta (Id, Ano), usar Where en lugar de FindAsync
            var empresa = await context.Empresa
                .Where(e => e.Id == empresaId)
                .OrderByDescending(e => e.Ano)
                .FirstOrDefaultAsync();

            if (empresa == null)
            {
                logger.LogWarning("Empresa not found: {EmpresaId}", empresaId);
                return null;
            }

            var franquiciaActiva = await GetFranquiciaActivaAsync(empresaId);

            return new ConfiguracionActualDto
            {
                IdEmpresa = empresaId,
                NombreEmpresa = empresa.Rut ?? "N/A",
                FranquiciaActiva = franquiciaActiva,
                DescripcionFranquicia = franquiciaActiva.HasValue ? GetDescripcionFranquicia(franquiciaActiva.Value) : null
            };
        }
    }

    public async Task<List<FranquiciaTributariaDto>> GetFranquiciasDisponiblesAsync()
    {
        logger.LogInformation("Getting franquicias disponibles");

        return await Task.FromResult(new List<FranquiciaTributariaDto>
        {
            new() { Id = 0, Codigo = "14A_SEMI", Descripcion = "14 A Régimen Semi Integrado", Detalle = "Tributación general con crédito parcial" },
            new() { Id = 1, Codigo = "14D_N3_PYME", Descripcion = "14 D N°3 Régimen Pro Pyme General", Detalle = "Régimen simplificado para PyMEs" },
            new() { Id = 2, Codigo = "14D_N8_PYME", Descripcion = "14 D N°8 Régimen Pro Pyme Transparente", Detalle = "Régimen transparente para PyMEs pequeñas" },
            new() { Id = 3, Codigo = "RENTAS_PRES", Descripcion = "Rentas Presuntas", Detalle = "Tributación basada en presunciones" },
            new() { Id = 4, Codigo = "14B_N1", Descripcion = "14 B N°1 Renta Efectiva sin Balance", Detalle = "Renta efectiva simplificada" },
            new() { Id = 5, Codigo = "OTRO", Descripcion = "Otro", Detalle = "Otros regímenes no especificados" },
            new() { Id = 6, Codigo = "NO_SUJETO_14", Descripcion = "No sujeto art. 14 LIR", Detalle = "No afecto a impuesto de primera categoría" },
            new() { Id = 7, Codigo = "SOC_PROF_1RA", Descripcion = "Soc. Prof. 1ra. Categoría", Detalle = "Sociedad de profesionales primera categoría" },
            new() { Id = 8, Codigo = "SOC_PROF_2DA", Descripcion = "Soc. Prof. 2da. Categoría", Detalle = "Sociedad de profesionales segunda categoría" }
        });
    }

    public async Task<int?> GetFranquiciaActivaAsync(int empresaId)
    {
        logger.LogInformation("Getting franquicia activa for empresaId: {EmpresaId}", empresaId);

        {
            // Nota: Empresa tiene clave compuesta (Id, Ano), usar Where en lugar de FindAsync
            var empresa = await context.Empresa
                .Where(e => e.Id == empresaId)
                .OrderByDescending(e => e.Ano)
                .FirstOrDefaultAsync();

            if (empresa == null) return null;

            // Verificar cada franquicia (SQL Server usa bool)
            if (empresa.Franq14ASemiIntegrado == true) return 0;
            if (empresa.FranqProPymeGeneral == true) return 1;
            if (empresa.FranqProPymeTransp == true) return 2;
            if (empresa.FranqRentasPresuntas == true) return 3;
            if (empresa.FranqRentaEfectiva == true) return 4;
            if (empresa.FranqOtro == true) return 5;
            if (empresa.FranqNoSujetoArt14 == true) return 6;
            if (empresa.FranqSocProfPrimCat == true) return 7;
            if (empresa.FranqSocProfSegCat == true) return 8;

            return null; // Ninguna franquicia activa
        }
    }

    public async Task<ValidationResult> ValidarYActualizarFranquiciaAsync(int empresaId, int franquiciaId)
    {
        logger.LogInformation("Validating and updating franquicia {FranquiciaId} for empresaId: {EmpresaId}", franquiciaId, empresaId);

        {
            // Validar franquiciaId
            if (franquiciaId < 0 || franquiciaId > 8)
            {
                return ValidationResult.Failure("Franquicia no válida");
            }

            // Nota: Empresa tiene clave compuesta (Id, Ano), usar Where en lugar de FindAsync
            var empresa = await context.Empresa
                .Where(e => e.Id == empresaId)
                .OrderByDescending(e => e.Ano)
                .FirstOrDefaultAsync();

            if (empresa == null)
            {
                return ValidationResult.Failure("Empresa no encontrada");
            }

            // Resetear todas las franquicias a NULL
            empresa.Franq14ASemiIntegrado = null;
            empresa.FranqProPymeGeneral = null;
            empresa.FranqProPymeTransp = null;
            empresa.FranqRentasPresuntas = null;
            empresa.FranqRentaEfectiva = null;
            empresa.FranqOtro = null;
            empresa.FranqNoSujetoArt14 = null;
            empresa.FranqSocProfPrimCat = null;
            empresa.FranqSocProfSegCat = null;

            // Activar franquicia seleccionada (SQL Server usa bool)
            switch (franquiciaId)
            {
                case 0: empresa.Franq14ASemiIntegrado = true; break;
                case 1: empresa.FranqProPymeGeneral = true; break;
                case 2: empresa.FranqProPymeTransp = true; break;
                case 3: empresa.FranqRentasPresuntas = true; break;
                case 4: empresa.FranqRentaEfectiva = true; break;
                case 5: empresa.FranqOtro = true; break;
                case 6: empresa.FranqNoSujetoArt14 = true; break;
                case 7: empresa.FranqSocProfPrimCat = true; break;
                case 8: empresa.FranqSocProfSegCat = true; break;
            }

            await context.SaveChangesAsync();

            logger.LogInformation("Franquicia updated successfully for empresaId: {EmpresaId}", empresaId);

            return ValidationResult.Success();
        }
    }

    // ======== Plan de Cuentas Predefinido ========

    public async Task<PlanCuentasPreviewDto> PreviewPlanCuentasAsync(int empresaId, int franquiciaId)
    {
        logger.LogInformation("Generating preview for franquiciaId: {FranquiciaId}, empresaId: {EmpresaId}", franquiciaId, empresaId);

        {
            var cuentasPredefinidas = await GetCuentasPredefinidasAsync(franquiciaId);
            var franquicia = (await GetFranquiciasDisponiblesAsync()).FirstOrDefault(f => f.Id == franquiciaId);

            // Verificar cuáles ya existen
            foreach (var cuenta in cuentasPredefinidas)
            {
                cuenta.YaExiste = await CuentaExisteAsync(empresaId, (short)DateTime.Now.Year, cuenta.Codigo);
            }

            return new PlanCuentasPreviewDto
            {
                FranquiciaId = franquiciaId,
                FranquiciaDescripcion = franquicia?.Descripcion ?? "Desconocida",
                CantidadCuentas = cuentasPredefinidas.Count,
                Cuentas = cuentasPredefinidas
            };
        }
    }

    public async Task<ResultadoAplicacionDto> AplicarPlanCuentasAsync(int empresaId, short ano, int franquiciaId, int userId, bool sobreescribir = false)
    {
        logger.LogInformation("Applying plan de cuentas for franquiciaId: {FranquiciaId}, empresaId: {EmpresaId}, ano: {Ano}", franquiciaId, empresaId, ano);

        var resultado = new ResultadoAplicacionDto();

        {
            // 1. Actualizar franquicia
            var validacion = await ValidarYActualizarFranquiciaAsync(empresaId, franquiciaId);

            if (!validacion.IsValid)
            {
                resultado.Exitoso = false;
                resultado.Mensaje = validacion.ErrorMessage;
                return resultado;
            }

            // 2. Obtener cuentas predefinidas
            var cuentas = await GetCuentasPredefinidasAsync(franquiciaId);

            // 3. Crear cuentas en la BD
            foreach (var cuentaDef in cuentas)
            {
                try
                {
                    var cuentaExistente = await context.Cuentas
                        .FirstOrDefaultAsync(c => c.IdEmpresa == empresaId && c.Ano == ano && c.Codigo == cuentaDef.Codigo);

                    if (cuentaExistente != null && !sobreescribir)
                    {
                        resultado.CuentasOmitidas++;
                        continue;
                    }

                    if (cuentaExistente != null && sobreescribir)
                    {
                        // Actualizar cuenta existente
                        cuentaExistente.Nombre = cuentaDef.Descripcion;
                        cuentaExistente.Descripcion = cuentaDef.Descripcion;
                        cuentaExistente.Nivel = (byte)cuentaDef.Nivel;
                        cuentaExistente.Estado = 1; // Activa
                        cuentaExistente.Clasificacion = ObtenerClasificacion(cuentaDef.TipoCuenta);

                        resultado.CuentasActualizadas++;
                    }
                    else
                    {
                        // Crear nueva cuenta
                        var maxId = await context.Cuentas
                            .Where(c => c.IdEmpresa == empresaId && c.Ano == ano)
                            .MaxAsync(c => (int?)c.idCuenta) ?? 0;

                        var nuevaCuenta = new App.Data.Cuentas
                        {
                            IdEmpresa = empresaId,
                            Ano = ano,
                            idCuenta = maxId + 1,
                            Codigo = cuentaDef.Codigo,
                            Nombre = cuentaDef.Descripcion,
                            Descripcion = cuentaDef.Descripcion,
                            Nivel = (byte)cuentaDef.Nivel,
                            Estado = 1, // Activa
                            Clasificacion = ObtenerClasificacion(cuentaDef.TipoCuenta),
                            Debe = 0,
                            Haber = 0,
                            DebeTrib = 0,
                            HaberTrib = 0,
                            MarcaApertura = 0
                        };

                        context.Cuentas.Add(nuevaCuenta);
                        resultado.CuentasCreadas++;
                    }

                    await context.SaveChangesAsync();
                }
                catch (Exception ex)
                {
                    logger.LogError(ex, "Error creating/updating account {Codigo}", cuentaDef.Codigo);
                    resultado.Errores.Add($"Error en cuenta {cuentaDef.Codigo}: {ex.Message}");
                }
            }

            resultado.Exitoso = true;
            resultado.Mensaje = $"Plan de cuentas aplicado exitosamente";

            logger.LogInformation("Plan de cuentas applied: {Created} created, {Updated} updated, {Omitted} omitted",
                resultado.CuentasCreadas, resultado.CuentasActualizadas, resultado.CuentasOmitidas);

            return resultado;
        }
    }

    public async Task<ValidacionFranquiciaDto> ValidarAplicacionAsync(int empresaId, short ano, int franquiciaId)
    {
        logger.LogInformation("Validating aplicación for franquiciaId: {FranquiciaId}, empresaId: {EmpresaId}", franquiciaId, empresaId);

        {
            // Contar cuentas actuales
            var cuentasActuales = await context.Cuentas
                .Where(c => c.IdEmpresa == empresaId && c.Ano == ano)
                .CountAsync();

            var validacion = new ValidacionFranquiciaDto
            {
                FranquiciaId = franquiciaId,
                TieneCuentasExistentes = cuentasActuales > 0,
                CantidadCuentasActuales = cuentasActuales,
                RequiereConfirmacion = cuentasActuales > 0
            };

            if (cuentasActuales > 0)
            {
                validacion.MensajeAdvertencia = $"La empresa ya tiene {cuentasActuales} cuentas. Algunas cuentas predefinidas podrían ya existir.";
            }

            return validacion;
        }
    }

    // ======== Cuentas Predefinidas ========

    public async Task<List<CuentaPredefinidaDto>> GetCuentasPredefinidasAsync(int franquiciaId)
    {
        logger.LogInformation("Getting cuentas predefinidas for franquiciaId: {FranquiciaId}", franquiciaId);

        // TODO: Esto debería leer de una tabla auxiliar o archivo
        // Por ahora, retornamos un set básico común a todas las franquicias
        var cuentasBase = new List<CuentaPredefinidaDto>
        {
            new() { Codigo = "1", Descripcion = "ACTIVO", Nivel = 1, TipoCuenta = "Activo" },
            new() { Codigo = "11", Descripcion = "ACTIVO CIRCULANTE", Nivel = 2, TipoCuenta = "Activo" },
            new() { Codigo = "1101", Descripcion = "Caja", Nivel = 3, TipoCuenta = "Activo" },
            new() { Codigo = "1102", Descripcion = "Banco", Nivel = 3, TipoCuenta = "Activo" },
            new() { Codigo = "1103", Descripcion = "Clientes", Nivel = 3, TipoCuenta = "Activo" },
            new() { Codigo = "2", Descripcion = "PASIVO", Nivel = 1, TipoCuenta = "Pasivo" },
            new() { Codigo = "21", Descripcion = "PASIVO CIRCULANTE", Nivel = 2, TipoCuenta = "Pasivo" },
            new() { Codigo = "2101", Descripcion = "Proveedores", Nivel = 3, TipoCuenta = "Pasivo" },
            new() { Codigo = "3", Descripcion = "PATRIMONIO", Nivel = 1, TipoCuenta = "Patrimonio" },
            new() { Codigo = "31", Descripcion = "CAPITAL", Nivel = 2, TipoCuenta = "Patrimonio" },
            new() { Codigo = "3101", Descripcion = "Capital Pagado", Nivel = 3, TipoCuenta = "Patrimonio" },
            new() { Codigo = "4", Descripcion = "INGRESOS", Nivel = 1, TipoCuenta = "Resultado" },
            new() { Codigo = "41", Descripcion = "INGRESOS OPERACIONALES", Nivel = 2, TipoCuenta = "Resultado" },
            new() { Codigo = "4101", Descripcion = "Ventas", Nivel = 3, TipoCuenta = "Resultado" },
            new() { Codigo = "5", Descripcion = "COSTOS Y GASTOS", Nivel = 1, TipoCuenta = "Resultado" },
            new() { Codigo = "51", Descripcion = "COSTOS", Nivel = 2, TipoCuenta = "Resultado" },
            new() { Codigo = "5101", Descripcion = "Costo de Ventas", Nivel = 3, TipoCuenta = "Resultado" }
        };

        return await Task.FromResult(cuentasBase);
    }

    public async Task<bool> CuentaExisteAsync(int empresaId, short ano, string codigoCuenta)
    {
        {
            return await context.Cuentas
                .AnyAsync(c => c.IdEmpresa == empresaId && c.Ano == ano && c.Codigo == codigoCuenta);
        }
    }

    // ======== Métodos Auxiliares ========

    private string GetDescripcionFranquicia(int franquiciaId)
    {
        return franquiciaId switch
        {
            0 => "14 A Régimen Semi Integrado",
            1 => "14 D N°3 Régimen Pro Pyme General",
            2 => "14 D N°8 Régimen Pro Pyme Transparente",
            3 => "Rentas Presuntas",
            4 => "14 B N°1 Renta Efectiva sin Balance",
            5 => "Otro",
            6 => "No sujeto art. 14 LIR",
            7 => "Soc. Prof. 1ra. Categoría",
            8 => "Soc. Prof. 2da. Categoría",
            _ => "Desconocida"
        };
    }

    private byte ObtenerClasificacion(string? tipoCuenta)
    {
        return tipoCuenta switch
        {
            "Activo" => 1,
            "Pasivo" => 2,
            "Patrimonio" => 3,
            "Resultado" => 4,
            _ => 0
        };
    }
}
