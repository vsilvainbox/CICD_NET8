namespace App.Features.ConfiguracionPlanCuentas;

/// <summary>
/// DTO para configuraci�n actual de franquicia tributaria
/// </summary>
public class ConfiguracionActualDto
{
    public int IdEmpresa { get; set; }
    public string? NombreEmpresa { get; set; }
    public int? FranquiciaActiva { get; set; } // �ndice de la franquicia activa (0-8)
    public string? DescripcionFranquicia { get; set; }
}

/// <summary>
/// DTO para opciones de franquicias tributarias disponibles
/// </summary>
public class FranquiciaTributariaDto
{
    public int Id { get; set; }
    public string Codigo { get; set; } = string.Empty;
    public string Descripcion { get; set; } = string.Empty;
    public string? Detalle { get; set; }
}

/// <summary>
/// DTO para preview del plan de cuentas predefinido
/// </summary>
public class PlanCuentasPreviewDto
{
    public int FranquiciaId { get; set; }
    public string FranquiciaDescripcion { get; set; } = string.Empty;
    public int CantidadCuentas { get; set; }
    public List<CuentaPredefinidaDto> Cuentas { get; set; } = new();
}

/// <summary>
/// DTO para una cuenta predefinida
/// </summary>
public class CuentaPredefinidaDto
{
    public string Codigo { get; set; } = string.Empty;
    public string Descripcion { get; set; } = string.Empty;
    public int Nivel { get; set; }
    public string? TipoCuenta { get; set; } // Activo, Pasivo, Patrimonio, Resultado
    public bool YaExiste { get; set; } // Si la cuenta ya existe en el plan actual
}

/// <summary>
/// DTO para aplicar plan de cuentas predefinido
/// </summary>
public class AplicarPlanCuentasDto
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public int FranquiciaId { get; set; }
    public bool SobreescribirExistentes { get; set; } = false;
}

/// <summary>
/// DTO para resultado de aplicaci�n del plan
/// </summary>
public class ResultadoAplicacionDto
{
    public bool Exitoso { get; set; }
    public string Mensaje { get; set; } = string.Empty;
    public int CuentasCreadas { get; set; }
    public int CuentasActualizadas { get; set; }
    public int CuentasOmitidas { get; set; }
    public List<string> Errores { get; set; } = new();
}

/// <summary>
/// DTO para validaci�n de franquicia
/// </summary>
public class ValidacionFranquiciaDto
{
    public int FranquiciaId { get; set; }
    public bool TieneCuentasExistentes { get; set; }
    public int CantidadCuentasActuales { get; set; }
    public bool RequiereConfirmacion { get; set; }
    public string? MensajeAdvertencia { get; set; }
}

/// <summary>
/// DTO para resultado de validaci�n gen�rica
/// </summary>
public class ValidationResult
{
    public bool IsValid { get; set; }
    public string ErrorMessage { get; set; } = string.Empty;
    public List<string> Errors { get; set; } = new();

    public static ValidationResult Success() => new() { IsValid = true };
    public static ValidationResult Failure(string message) => new() { IsValid = false, ErrorMessage = message };
}
