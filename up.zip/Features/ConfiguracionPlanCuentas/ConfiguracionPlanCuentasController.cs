using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using App.Helpers;
using App.Extensions;

namespace App.Features.ConfiguracionPlanCuentas;

[Authorize]



public class ConfiguracionPlanCuentasController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<ConfiguracionPlanCuentasController> logger) : Controller
{
    [HttpGet]
    public Task<IActionResult> Index()
    {
        // Obtener empresaId y año desde BaseController (patr�n est�ndar del proyecto)
        ViewData["EmpresaId"] = SessionHelper.EmpresaId;
        ViewData["Ano"] = SessionHelper.Ano;

        logger.LogInformation("Loading ConfiguracionPlanCuentas for empresaId: {EmpresaId}, ano: {Ano}", 
            SessionHelper.EmpresaId, SessionHelper.Ano);

        return Task.FromResult<IActionResult>(View());
    }

    [HttpGet]
    public async Task<IActionResult> Franquicias()
    {
        logger.LogInformation("Proxy: Getting franquicias");

        {
            var client = httpClientFactory.CreateClient("ApiClient");
            var url = linkGenerator.GetPathByAction(
                action: nameof(ConfiguracionPlanCuentasApiController.GetFranquicias),
                controller: nameof(ConfiguracionPlanCuentasApiController).Replace("Controller", ""));
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    [HttpGet]
    public async Task<IActionResult> FranquiciaActiva(int empresaId)
    {
        logger.LogInformation("Proxy: Getting franquicia activa for empresaId: {EmpresaId}", empresaId);

        {
            var client = httpClientFactory.CreateClient("ApiClient");
            var url = linkGenerator.GetPathByAction(
                action: nameof(ConfiguracionPlanCuentasApiController.GetFranquiciaActiva),
                controller: nameof(ConfiguracionPlanCuentasApiController).Replace("Controller", ""),
                values: new { empresaId });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    [HttpGet]
    public async Task<IActionResult> Preview(int empresaId, int franquiciaId)
    {
        logger.LogInformation("Proxy: Getting preview for empresaId: {EmpresaId}, franquiciaId: {FranquiciaId}", empresaId, franquiciaId);

        {
            var client = httpClientFactory.CreateClient("ApiClient");
            var url = linkGenerator.GetPathByAction(
                action: nameof(ConfiguracionPlanCuentasApiController.GetPreview),
                controller: nameof(ConfiguracionPlanCuentasApiController).Replace("Controller", ""),
                values: new { empresaId, franquiciaId });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    [HttpPost]
    public async Task<IActionResult> Aplicar([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: Applying plan de cuentas configuration");
        var client = httpClientFactory.CreateClient("ApiClient");
        var url = linkGenerator.GetPathByAction(
            action: nameof(ConfiguracionPlanCuentasApiController.Aplicar),
            controller: nameof(ConfiguracionPlanCuentasApiController).Replace("Controller", ""),
            values: new { userId = HttpContext.GetCurrentUserId() });
        var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }
}
