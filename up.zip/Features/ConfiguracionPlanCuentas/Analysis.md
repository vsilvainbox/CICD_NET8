# Legacy Analysis: ConfiguracionPlanCuentas

## 📄 Información del Formulario VB6

**Archivo VB6:** `vb6\Contabilidad70\HyperContabilidad\frmConfigDefinidasPlanCuenta.frm` (y versión 2019)
**Fecha Análisis:** 2025-10-07
**Analista:** IA
**Complejidad:** Media

### Propósito del Formulario

ConfiguracionPlanCuentas permite crear automáticamente un **Plan de Cuentas Predefinido** basado en la franquicia tributaria (régimen tributario chileno) seleccionada por el usuario. Este formulario es un asistente que:
1. Permite seleccionar el régimen tributario aplicable a la empresa
2. Actualiza la configuración de franquicia en la tabla Empresa
3. Genera automáticamente las cuentas contables necesarias según la franquicia
4. Permite previsualizar el plan antes de aplicarlo

**Nota:** Existen dos versiones del formulario:
- `frmConfigDefinidasPlanCuenta.frm` - Versión completa con selección de franquicia
- `frmConfigDefinidasPlanCuenta2019.frm` - Versión simplificada (usa franquicia ya configurada)

---

## 🎨 CONTROLES UI IDENTIFICADOS

### Option Buttons (Radio Buttons) - Franquicias Tributarias

| Control VB6 | Index | Caption | Valor en BD | Propósito |
|-------------|-------|---------|-------------|-----------|
| optFranquicia(0) | 0 | "14 A Régimen Semi Integrado" | Franq14ASemiIntegrado | Régimen general de tributación |
| optFranquicia(1) | 1 | "14 D N°3 Régimen Pro Pyme General" | FranqProPymeGeneral | Régimen simplificado para PyMEs |
| optFranquicia(2) | 2 | "14 D N°8 Régimen Pro Pyme Transp." | FranqProPymeTransp | Régimen transparente para PyMEs |
| optFranquicia(3) | 3 | "Rentas Presuntas" | FranqRentasPresuntas | Tributación basada en presunciones |
| optFranquicia(4) | 4 | "14 B N°1 Renta Efectiva sin Balance" | Franq14BRentaEfectiva | Renta efectiva sin balance completo |
| optFranquicia(5) | 5 | "Otro" | FranqOtro | Otros regímenes no especificados |
| optFranquicia(6) | 6 | "No sujeto art. 14 LIR" | FranqNoSujetoArt14 | No sujeto a impuestos de primera categoría |
| optFranquicia(7) | 7 | "Soc. Prof. 1ra. Categoría" | FranqSocProf1raCateg | Sociedad de profesionales 1ra cat. |
| optFranquicia(8) | 8 | "Soc. Prof. 2da. Categoría" | FranqSocProf2daCateg | Sociedad de profesionales 2da cat. |

### Textbox (Oculto)

| Control VB6 | Propiedad Bound | Tipo | Validación | Propósito |
|-------------|-----------------|------|------------|-----------|
| txtFranquicia | Almacena franquicia seleccionada | String | Required (debe seleccionar una) | Valor temporal de franquicia |

### Botones de Acción

| Botón VB6 | Caption | Habilitado Si | Acción | Mapeo .NET |
|-----------|---------|---------------|--------|------------|
| Bt_VistaPrevia | "Vista Previa" | Franquicia seleccionada | Muestra preview del plan de cuentas sin aplicar | PreviewPlanCuentasAsync() |
| Bt_OK | "Aceptar" | Franquicia seleccionada | Actualiza franquicia en Empresa y genera plan de cuentas | AplicarPlanCuentasAsync() |
| Bt_Cancel | "Cancelar" | Siempre | Cierra formulario sin cambios | N/A (navegación) |

### Labels

| Control VB6 | Contenido | Actualización | Propósito |
|-------------|-----------|---------------|-----------|
| lblMensaje | "Procesando..." | Durante operaciones largas | Feedback visual al usuario |

#### 🚨 REGLA CRÍTICA: TODOS LOS BOTONES MIGRADOS

**✅ Estado:** Todos los 3 botones del VB6 están documentados y tienen mapeo .NET

---

## 🔘 EVENTOS IDENTIFICADOS

### Eventos de Formulario

| Evento VB6 | Cuándo Ocurre | Acciones | Mapeo .NET |
|------------|---------------|----------|------------|
| Form_Load | Al abrir form | Cargar franquicia actual de la empresa (si existe) | GetConfiguracionActualAsync() |

### Eventos de Botones

| Control.Evento | Trigger | Acción VB6 | Mapeo .NET |
|----------------|---------|------------|------------|
| Bt_VistaPrevia.Click | Click en "Vista Previa" | Valida selección, llama FrmConfig.GetPlanPreDef_Preview(0) | PreviewPlanCuentasAsync() |
| Bt_OK.Click | Click en "Aceptar" | Valida selección, actualiza Empresa, llama FrmConfig.GetPlanPreDef(0), deshabilita botón | AplicarPlanCuentasAsync() |
| Bt_Cancel.Click | Click en "Cancelar" | Cierra formulario | N/A |
| optFranquicia(i).Click | Selecciona radio button | Actualiza txtFranquicia.Text con índice seleccionado | OnFranquiciaChange() (JavaScript) |

---

## 🔧 FUNCIONES Y PROCEDIMIENTOS VB6

### Funciones Privadas

```vb
' Función: ValidaActualizaFranquicia
' Propósito: Validar que se haya seleccionado una franquicia y actualizar BD
' Parámetros: Ninguno
' Retorno: Boolean (True si válido y actualizado correctamente)
' Llamado por: Bt_OK_Click, Bt_VistaPrevia_Click
' Mapeo .NET: ValidarYActualizarFranquiciaAsync()
Private Function ValidaActualizaFranquicia() As Boolean
    Dim Franquicia As Boolean

    ' Verificar que se seleccionó una opción
    For i = 0 To optFranquicia.Count - 1
        If optFranquicia(i).Value Then
            Franquicia = True
        End If
    Next

    If Franquicia = False Then
        MsgBox "Debe seleccionar una Franquicia", vbInformation
        Exit Function
    End If

    ' Actualizar franquicia en tabla Empresa
    SQL = "UPDATE Empresa SET "
    SQL = SQL & " Franq14ASemiIntegrado=NULL"
    SQL = SQL & ",FranqProPymeGeneral=NULL"
    SQL = SQL & ",FranqProPymeTransp=NULL"
    SQL = SQL & ",FranqRentasPresuntas=NULL"
    SQL = SQL & ",Franq14BRentaEfectiva=NULL"
    SQL = SQL & ",FranqOtro=NULL"
    SQL = SQL & ",FranqNoSujetoArt14=NULL"
    SQL = SQL & ",FranqSocProf1raCateg=NULL"
    SQL = SQL & ",FranqSocProf2daCateg=NULL"
    SQL = SQL & " WHERE IdEmpresa = " & gIdEmpresa

    Execute DbMain, SQL

    ' Setear la franquicia seleccionada
    For i = 0 To optFranquicia.Count - 1
        If optFranquicia(i).Value Then
            SQL = "UPDATE Empresa SET " & GetCampoFranquicia(i) & " = -1"
            SQL = SQL & " WHERE IdEmpresa = " & gIdEmpresa
            Execute DbMain, SQL
        End If
    Next

    ValidaActualizaFranquicia = True
End Function
```

**Lógica de Negocio:**
1. Valida que se haya seleccionado una franquicia
2. Resetea TODAS las franquicias a NULL en la tabla Empresa
3. Setea la franquicia seleccionada a -1 (True en VB6)
4. La lógica de creación del plan está en FrmConfig.GetPlanPreDef

### Lista Completa de Funciones

| Función VB6 | Tipo | Propósito | Mapeo .NET Method |
|-------------|------|-----------|-------------------|
| ValidaActualizaFranquicia() | Private Function→Boolean | Validar y actualizar franquicia | ValidarYActualizarFranquiciaAsync() |
| GetCampoFranquicia(index) | Private Function→String | Obtener nombre de campo BD según índice | MapFranquiciaIndexToField() |
| FrmConfig.GetPlanPreDef(0) | External | Generar plan de cuentas predefinido | GenerarPlanCuentasPredefinidoAsync() |
| FrmConfig.GetPlanPreDef_Preview(0) | External | Preview del plan sin aplicar | PreviewPlanCuentasAsync() |

---

## 💾 ACCESO A DATOS VB6

### Query 1: Resetear Franquicias

```vb
' Ubicación: ValidaActualizaFranquicia()
' Propósito: Limpiar todas las franquicias antes de setear la seleccionada
SQL = "UPDATE Empresa SET "
SQL = SQL & " Franq14ASemiIntegrado=NULL"
SQL = SQL & ",FranqProPymeGeneral=NULL"
SQL = SQL & ",FranqProPymeTransp=NULL"
SQL = SQL & ",FranqRentasPresuntas=NULL"
SQL = SQL & ",Franq14BRentaEfectiva=NULL"
SQL = SQL & ",FranqOtro=NULL"
SQL = SQL & ",FranqNoSujetoArt14=NULL"
SQL = SQL & ",FranqSocProf1raCateg=NULL"
SQL = SQL & ",FranqSocProf2daCateg=NULL"
SQL = SQL & " WHERE IdEmpresa = " & gIdEmpresa

Execute DbMain, SQL
```

**Mapeo Entity Framework:**
```csharp
var empresa = await _context.Empresas.FindAsync(empresaId);
if (empresa != null)
{
    // Resetear todas las franquicias
    empresa.Franq14ASemiIntegrado = null;
    empresa.FranqProPymeGeneral = null;
    empresa.FranqProPymeTransp = null;
    empresa.FranqRentasPresuntas = null;
    empresa.Franq14BRentaEfectiva = null;
    empresa.FranqOtro = null;
    empresa.FranqNoSujetoArt14 = null;
    empresa.FranqSocProf1raCateg = null;
    empresa.FranqSocProf2daCateg = null;

    await _context.SaveChangesAsync();
}
```

### Query 2: Setear Franquicia Seleccionada

```vb
' Ubicación: ValidaActualizaFranquicia()
' Propósito: Activar la franquicia seleccionada
SQL = "UPDATE Empresa SET " & GetCampoFranquicia(i) & " = -1"
SQL = SQL & " WHERE IdEmpresa = " & gIdEmpresa

Execute DbMain, SQL
```

**Mapeo Entity Framework:**
```csharp
// Setear franquicia seleccionada a -1 (True en VB6)
switch(franquiciaId)
{
    case 0: empresa.Franq14ASemiIntegrado = -1; break;
    case 1: empresa.FranqProPymeGeneral = -1; break;
    case 2: empresa.FranqProPymeTransp = -1; break;
    case 3: empresa.FranqRentasPresuntas = -1; break;
    case 4: empresa.Franq14BRentaEfectiva = -1; break;
    case 5: empresa.FranqOtro = -1; break;
    case 6: empresa.FranqNoSujetoArt14 = -1; break;
    case 7: empresa.FranqSocProf1raCateg = -1; break;
    case 8: empresa.FranqSocProf2daCateg = -1; break;
}
await _context.SaveChangesAsync();
```

---

## ✅ VALIDACIONES Y REGLAS DE NEGOCIO

### Validaciones de Campos

| Campo | Regla | Mensaje Error VB6 | Implementar en .NET |
|-------|-------|-------------------|---------------------|
| Franquicia | Debe seleccionar una | "Debe seleccionar una Franquicia" | ValidationResult |

### Reglas de Negocio

1. **Solo una franquicia activa a la vez**
   - Cuando se selecciona una franquicia, todas las demás deben ser NULL
   - La seleccionada se marca con -1 (True en VB6, convertir a bool en .NET)

2. **Franquicia determina estructura del plan de cuentas**
   - Cada franquicia tiene un plan de cuentas predefinido diferente
   - El plan se genera automáticamente basándose en la franquicia

3. **Botón "Aceptar" se deshabilita después de aplicar**
   - Previene ejecución múltiple accidental
   - Usuario debe cerrar y reabrir para aplicar nuevamente

4. **Vista Previa no modifica datos**
   - Solo muestra cómo quedaría el plan
   - No persiste cambios en BD

---

## 🧮 CÁLCULOS Y FÓRMULAS

No hay cálculos en este formulario. La lógica de generación del plan está en el módulo externo FrmConfig.

---

## 🚀 NAVEGACIÓN Y FLUJO

### Formularios Llamados

| Desde VB6 | Formulario Destino | Parámetros | Retorno | Mapeo .NET |
|-----------|-------------------|------------|---------|------------|
| Bt_VistaPrevia_Click | FrmConfig.GetPlanPreDef_Preview | 0 (tipo) | Ninguno | PreviewPlanCuentasAsync() → Modal |
| Bt_OK_Click | FrmConfig.GetPlanPreDef | 0 (tipo) | Ninguno | AplicarPlanCuentasAsync() → Redirect |

### Flujo de Estados del Form

```
[Inicio] → Form_Load() → [Estado: Selección de Franquicia]
  ↓
[Seleccionar Radio Button] → optFranquicia_Click → [Estado: Franquicia Seleccionada]
  ↓
[Bt_VistaPrevia] → ValidaActualizaFranquicia() → GetPlanPreDef_Preview() → [Modal Preview]
  ↓
[Cerrar Preview] → [Estado: Selección de Franquicia]
  ↓
[Bt_OK] → ValidaActualizaFranquicia() → GetPlanPreDef() → [Estado: Plan Aplicado, Botón Deshabilitado]
  ↓
[Bt_Cancel] → Unload Me → [Cerrar Formulario]
```

---

## 📊 EXPORTACIONES E IMPORTACIONES

No aplica para este formulario.

---

## 🎯 MAPEO FINAL: MÉTODOS .NET DETERMINADOS

### Interface del Service

```csharp
public interface IConfiguracionPlanCuentasService
{
    // Configuración de Franquicia
    Task<ConfiguracionActualDto?> GetConfiguracionActualAsync(int empresaId);
    Task<List<FranquiciaTributariaDto>> GetFranquiciasDisponiblesAsync();
    Task<ValidationResult> ValidarYActualizarFranquiciaAsync(int empresaId, int franquiciaId);

    // Plan de Cuentas Predefinido
    Task<PlanCuentasPreviewDto> PreviewPlanCuentasAsync(int empresaId, int franquiciaId);
    Task<ValidationResult> AplicarPlanCuentasAsync(int empresaId, int franquiciaId, int userId);

    // Utilidades
    Task<int?> GetFranquiciaActivaAsync(int empresaId);
}
```

### Resumen de Mapeo

| Funcionalidad VB6 | Método .NET | Complejidad | Prioridad |
|-------------------|-------------|-------------|-----------|
| Form_Load cargar franquicia actual | GetConfiguracionActualAsync() | Baja | Alta |
| Listar opciones de franquicia | GetFranquiciasDisponiblesAsync() | Baja | Alta |
| ValidaActualizaFranquicia() | ValidarYActualizarFranquiciaAsync() | Media | Alta |
| Bt_VistaPrevia → GetPlanPreDef_Preview | PreviewPlanCuentasAsync() | Alta | Media |
| Bt_OK → GetPlanPreDef | AplicarPlanCuentasAsync() | Alta | Alta |
| Verificar franquicia activa | GetFranquiciaActivaAsync() | Baja | Media |

---

## ⚠️ NOTAS IMPORTANTES Y OBSERVACIONES

### Peculiaridades del Form VB6

- Usa variable global `gIdEmpresa` para identificar la empresa
- Franquicias se almacenan como -1 (True) o NULL (False) en VB6
- Existe versión 2019 simplificada que no muestra selector de franquicia
- La lógica de generación del plan está en un módulo externo (FrmConfig)

### Decisiones de Diseño

- **Conversión Boolean**: VB6 usa -1/NULL, .NET debe usar bool true/false
- **Vista Preview**: Implementar como modal con tabla de cuentas a crear
- **Plan Predefinido**: La lógica de qué cuentas crear está en módulo externo (requiere análisis adicional)
- **Deshabilitación de Botón**: Implementar con estado en JavaScript después de aplicar

### Dependencias Externas

**⚠️ IMPORTANTE:** Este formulario depende de:
- Módulo `FrmConfig` y sus métodos `GetPlanPreDef` y `GetPlanPreDef_Preview`
- Tabla de cuentas predefinidas (probablemente hardcoded o en tabla auxiliar)
- Conocimiento de reglas contables chilenas por franquicia

**Implementación Recomendada:**
1. Crear tabla auxiliar `PlanCuentasPredefinido` con cuentas por franquicia
2. Servicio que lee esa tabla y genera las cuentas
3. Para preview: retornar lista sin insertar en BD
4. Para aplicar: insertar cuentas en tabla Cuentas

---

## ✅ CHECKLIST DE COMPLETITUD DEL ANÁLISIS

- [x] Todos los controles UI documentados
- [x] Todos los botones y eventos mapeados
- [x] **TODOS los botones tienen "Mapeo .NET" definido**
- [x] Todas las funciones VB6 identificadas
- [x] Todos los queries SQL traducidos a EF Core
- [x] Todas las validaciones documentadas
- [x] Todas las reglas de negocio identificadas
- [x] Navegación y flujos mapeados
- [x] Métodos .NET determinados
- [x] Interface del Service definida
- [x] **Dependencias externas identificadas (FrmConfig)**

---

**✅ ANÁLISIS COMPLETO - LISTO PARA IMPLEMENTACIÓN**

**Nota:** La implementación completa del plan de cuentas predefinido requiere:
1. Análisis del módulo FrmConfig.GetPlanPreDef para determinar qué cuentas crear
2. Definición de estructura de cuentas por cada franquicia
3. O bien, tabla auxiliar con cuentas predefinidas por franquicia
