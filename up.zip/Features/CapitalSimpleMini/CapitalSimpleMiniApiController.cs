using Microsoft.AspNetCore.Mvc;

namespace App.Features.CapitalSimpleMini;

[ApiController]
[Route("api/[controller]/[action]")]
public class CapitalSimpleMiniApiController(
    ICapitalSimpleMiniService service,
    ILogger<CapitalSimpleMiniApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<CapitalSimpleMiniDto>> GetData(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        [FromQuery] byte tipoDetCps,
        [FromQuery] int tipoInforme = 0)
    {
        logger.LogInformation("API: GetData called for empresa: {EmpresaId}, ano: {Ano}, tipo: {TipoDetCps}",
            empresaId, ano, tipoDetCps);

        {
            var data = await service.GetAllAsync(empresaId, ano, tipoDetCps, tipoInforme);
            logger.LogInformation("API: Returning data with {Count} detalles", data.DetallesAnoActual.Count);
            return Ok(data);
        }
    }

    [HttpPost]
    public async Task<ActionResult<CapitalSimpleMiniDto>> SaveData([FromBody] CapitalSimpleMiniSaveDto dto)
    {
        logger.LogInformation("API: SaveData called for empresa: {EmpresaId}, ano: {Ano}",
            dto.EmpresaId, dto.Ano);

        {
            var result = await service.SaveAsync(dto.EmpresaId, dto.Ano, dto.TipoDetCps, dto);
            logger.LogInformation("API: Data saved successfully");
            return Ok(result);
        }
    }

    [HttpDelete]
    public async Task<ActionResult> Delete(int id, [FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: Delete called for detalle: {Id}", id);

        {
            var canDelete = await service.CanDeleteAsync(id);
            if (!canDelete)
            {
                logger.LogWarning("API: Cannot delete detalle: {Id} - not ingreso manual", id);
                return BadRequest(new { message = "Sólo se pueden eliminar los registros de ingreso manual." });
            }

            var deleted = await service.DeleteAsync(empresaId, ano, id);
            if (deleted)
            {
                logger.LogInformation("API: Detalle deleted successfully");
                return Ok(new { message = "Detalle eliminado correctamente" });
            }

            return NotFound(new { message = "Detalle no encontrado" });
        }
    }

    [HttpGet]
    public async Task<ActionResult> ExportToExcel(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        [FromQuery] byte tipoDetCps)
    {
        logger.LogInformation("API: ExportToExcel called");

        {
            var excelData = await service.ExportToExcelAsync(empresaId, ano, tipoDetCps);

            if (excelData.Length == 0)
            {
                return BadRequest(new { message = "Exportación no implementada aún" });
            }

            return File(excelData,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                $"CapitalSimpleMini_{tipoDetCps}_{ano}.xlsx");
        }
    }
}
