﻿namespace App.Features.CapitalSimpleMini;

public interface ICapitalSimpleMiniService
{
    /// <summary>
    /// Obtiene todos los datos para mostrar en la vista (acumulados + detalles)
    /// </summary>
    Task<CapitalSimpleMiniDto> GetAllAsync(int empresaId, short ano, byte tipoDetCps, int tipoInforme);

    /// <summary>
    /// Guarda los cambios realizados (INSERT/UPDATE/DELETE)
    /// </summary>
    Task<CapitalSimpleMiniDto> SaveAsync(int empresaId, short ano, byte tipoDetCps, CapitalSimpleMiniSaveDto dto);

    /// <summary>
    /// Elimina un detalle de ingreso manual
    /// </summary>
    Task<bool> DeleteAsync(int empresaId, short ano, int idDetalle);

    /// <summary>
    /// Valida los datos antes de guardar
    /// </summary>
    Task<ValidationResult> ValidateAsync(CapitalSimpleMiniSaveDto dto);

    /// <summary>
    /// Verifica si un detalle puede ser eliminado (debe ser ingreso manual)
    /// </summary>
    Task<bool> CanDeleteAsync(int idDetalle);

    /// <summary>
    /// Calcula totales (año actual y acumulado)
    /// </summary>
    Task<CalculoTotalesDto> CalculateTotalsAsync(int empresaId, short ano, byte tipoDetCps, List<DetalleCapitalDto> detalles);

    /// <summary>
    /// Obtiene el título según el tipo de detalle CPS
    /// </summary>
    Task<string> GetTituloAsync(byte tipoDetCps);

    /// <summary>
    /// Exporta los datos a Excel
    /// </summary>
    Task<byte[]> ExportToExcelAsync(int empresaId, short ano, byte tipoDetCps);
}
