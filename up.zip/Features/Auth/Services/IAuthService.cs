using App.Models.Auth;

namespace App.Features.Auth.Services;

/// <summary>
/// Servicio de autenticación de usuarios
/// Replica la funcionalidad de FrmIdUser.frm (VB6)
/// </summary>
public interface IAuthService
{
    /// <summary>
    /// Realiza el login de un usuario
    /// </summary>
    Task<LoginResult> LoginAsync(string username, string password);

    /// <summary>
    /// Cierra la sesión del usuario actual
    /// </summary>
    Task LogoutAsync();

    /// <summary>
    /// Cambia la contraseña del usuario actual
    /// </summary>
    Task<bool> CambiarPasswordAsync(int idUsuario, string oldPassword, string newPassword);

    /// <summary>
    /// Obtiene el usuario actual de la sesión
    /// </summary>
    Task<UsuarioSession?> GetUsuarioActualAsync();
}
