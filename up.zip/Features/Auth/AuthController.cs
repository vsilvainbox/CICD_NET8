using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using App.Features.Auth.Services;
using App.Features.Auth.DTOs;

namespace App.Features.Auth;

public class AuthController(
    IAuthService authService,
    ILogger<AuthController> logger) : Controller
{
    [HttpGet]
    public IActionResult Login(string? returnUrl = null)
    {
        if (User.Identity?.IsAuthenticated == true)
        {
            var url = Url.Action("Index", "SeleccionarEmpresa") ?? "/SeleccionarEmpresa";
            return LocalRedirect(url);
        }

        ViewData["ReturnUrl"] = returnUrl;
        ViewData["AppName"] = "HyperContabilidad";
        ViewData["AppVersion"] = "Versión .NET 9";
        ViewData["CompanyName"] = "Thomson Reuters";
        ViewData["LogoUrl"] = "/images/logo.png"; // Usar logo local en vez de URL externa
        ViewData["CurrentYear"] = DateTime.Now.Year;

        return View(new LoginDto());
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginDto model, string? returnUrl = null)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var result = await authService.LoginAsync(model.Username, model.Password);

        if (!result.Success)
        {
            ModelState.AddModelError(string.Empty, result.ErrorMessage ?? "Error al iniciar sesión");
            return View(model);
        }

        // Guardar mensaje de bienvenida para mostrar toast
        var nombreUsuario = result.Usuario?.NombreLargo ?? result.Usuario?.Usuario ?? "Usuario";
        TempData["SuccessTitle"] = $"¡Bienvenido, {nombreUsuario}!";
        TempData["SuccessMessage"] = "Sesión iniciada correctamente";

        // Redirigir a selección de empresa
        if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
        {
            return LocalRedirect(returnUrl);
        }

        var url = Url.Action("Index", "SeleccionarEmpresa") ?? "/SeleccionarEmpresa";
        return LocalRedirect(url);
    }

    [HttpGet]
    [HttpPost]
    public async Task<IActionResult> Logout()
    {
        var username = User.Identity?.Name ?? "Unknown";
        logger.LogInformation("User {Username} logging out", username);

        await authService.LogoutAsync();

        logger.LogInformation("User {Username} logged out successfully", username);

        // Eliminar explícitamente las cookies de autenticación y sesión
        // Usar los nombres correctos configurados en Program.cs
        var cookieOptions = new CookieOptions
        {
            Path = Request.PathBase.HasValue ? Request.PathBase.Value : "/",
            Expires = DateTimeOffset.UtcNow.AddDays(-1)
        };

        Response.Cookies.Delete(".HyperContabilidad.Auth", cookieOptions);
        Response.Cookies.Delete(".HyperContabilidad.Session", cookieOptions);
        Response.Cookies.Delete("EmpresaAnoSelection", cookieOptions);

        // FIX: Usar Url.Action para generar URL correcta con PathBase en producción
        //var loginUrl = Url.Action("Login", "Auth") ?? "/Auth/Login";
        //return LocalRedirect(loginUrl);
        return RedirectToAction("Login", "Auth");
    }

    [Authorize]
    [HttpGet]
    public IActionResult CambiarPassword()
    {
        return View(new CambiarPasswordDto());
    }

    [Authorize]
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> CambiarPassword(CambiarPasswordDto model)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var usuario = await authService.GetUsuarioActualAsync();
        if (usuario == null)
        {
            var loginUrl = Url.Action("Login") ?? "/Auth/Login";
            return LocalRedirect(loginUrl);
        }

        var success = await authService.CambiarPasswordAsync(
            usuario.IdUsuario,
            model.PasswordActual,
            model.PasswordNueva);

        if (!success)
        {
            ModelState.AddModelError(string.Empty, "La contraseña actual es incorrecta");
            return View(model);
        }

        TempData["SuccessTitle"] = "Contraseña Actualizada";
        TempData["SuccessMessage"] = "Su contraseña ha sido cambiada exitosamente";

        // Limpiar el modelo para mostrar un formulario vacío
        return View(new CambiarPasswordDto());
    }

    [HttpGet]
    public IActionResult AccessDenied()
    {
        return View();
    }
}
