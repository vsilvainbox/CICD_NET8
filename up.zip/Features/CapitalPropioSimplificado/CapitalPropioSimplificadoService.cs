using Microsoft.EntityFrameworkCore;
using App.Data;

namespace App.Features.CapitalPropioSimplificado;

public class CapitalPropioSimplificadoService(
    LpContabContext context,
    ILogger<CapitalPropioSimplificadoService> logger) : ICapitalPropioSimplificadoService
{
    public async Task<CapitalPropioSimplificadoDto> ObtenerCPSAsync(int empresaId, short ano, TipoInformeCPS tipoInforme)
    {
        logger.LogInformation("Obteniendo CPS para empresa {EmpresaId}, año {Ano}, tipo {Tipo}",
            empresaId, ano, tipoInforme);

        {
            var empresaAno = await context.EmpresasAno
                .FirstOrDefaultAsync(ea => ea.idEmpresa == empresaId && ea.Ano == ano);

            if (empresaAno == null)
            {
                logger.LogWarning("No se encontró EmpresasAno para empresa {EmpresaId}, año {Ano}", empresaId, ano);
                return new CapitalPropioSimplificadoDto
                {
                    EmpresaId = empresaId,
                    Ano = ano,
                    TipoInforme = tipoInforme
                };
            }

            var empresa = await context.Empresas.FindAsync(empresaId);
            // TODO: [LEGACY] Verificar si existen campos ProPymeGeneral y ProPymeTransp en Empresas
            var esProPymeGeneral = false; // empresa?.ProPymeGeneral == 1;
            var esProPymeTransp = false; // empresa?.ProPymeTransp == 1;

            var dto = new CapitalPropioSimplificadoDto
            {
                EmpresaId = empresaId,
                Ano = ano,
                TipoInforme = tipoInforme,
                EsProPymeGeneral = esProPymeGeneral,
                EsProPymeTransparente = esProPymeTransp,

                CapitalAportado = (decimal)(empresaAno.CPS_CapitalAportado ?? 0),
                AumentosCapital = (decimal)(empresaAno.CPS_AumentosCapital ?? 0),
                BaseImponible14DN3 = (decimal)(empresaAno.CPS_BaseImpPrimCat_14DN3 ?? 0),
                BaseImponible14DN8 = (decimal)(empresaAno.CPS_BaseImpPrimCat_14DN8 ?? 0),
                DisminucionesCapital = (decimal)(empresaAno.CPS_Disminuciones ?? 0),
                GastosRechazados = (decimal)(empresaAno.CPS_GastosRechazados ?? 0),
                RetirosDividendos = (decimal)(empresaAno.CPS_RetirosDividendos ?? 0),
                IngresoDiferido = (decimal)(empresaAno.CPS_IngresoDiferido ?? 0),
                OtrosAjustesAumentos = (decimal)(empresaAno.CPS_OtrosAjustesAumentos ?? 0),
                OtrosAjustesDisminuciones = (decimal)(empresaAno.CPS_OtrosAjustesDisminuciones ?? 0),

                INRPropios = (decimal)(empresaAno.CPS_INRPropios ?? 0),
                INRPropiosPerdidas = (decimal)(empresaAno.CPS_INRPropiosPerdidas ?? 0),
                Participaciones = (decimal)(empresaAno.CPS_Participaciones ?? 0),
                UtilidadesPerdida = (decimal)(empresaAno.CPS_UtilidadesPerdida ?? 0),
                CTDImputableIPE = (decimal)(empresaAno.CPS_CTDImputableIPE ?? 0),
                IncentivoAhorro = (decimal)(empresaAno.CPS_IncentivoAhorro ?? 0),
                IDPCVoluntario = (decimal)(empresaAno.CPS_IDPCVoluntario ?? 0),

                CredActFijos = (decimal)(empresaAno.CPS_CredActFijos ?? 0),
                CredParticipaciones = (decimal)(empresaAno.CPS_CredParticipaciones ?? 0),

                CapPropioTribAnoAnt = (decimal)(empresaAno.CPS_CapPropioTribAnoAnt ?? 0),
                RepPerdidaArrastre = (decimal)(empresaAno.CPS_RepPerdidaArrastre ?? 0)
            };

            // Si es variación anual y no hay año anterior en sistema, usar CPS_CapPropioTribAnoAnt
            if (tipoInforme == TipoInformeCPS.VariacionAnual)
            {
                var anoAnterior = await context.EmpresasAno
                    .FirstOrDefaultAsync(ea => ea.idEmpresa == empresaId && ea.Ano == ano - 1);

                if (anoAnterior != null)
                {
                    if (ano >= 2021)
                    {
                        dto.CapPropioTribAnoAnt = (decimal)(anoAnterior.CPS_CapPropioSimplificado ?? 0);
                    }
                    else
                    {
                        dto.CapPropioTribAnoAnt = (decimal)(anoAnterior.CPS_CapPropioTrib ?? 0);
                    }
                }
            }

            dto.CapitalPropioSimplificado = await CalcularTotalCPSAsync(dto);

            return dto;
        }
    }

    public async Task GuardarCPSAsync(CapitalPropioSimplificadoDto datos)
    {
        logger.LogInformation("Guardando CPS para empresa {EmpresaId}, año {Ano}", datos.EmpresaId, datos.Ano);

        {
            var empresaAno = await context.EmpresasAno
                .FirstOrDefaultAsync(ea => ea.idEmpresa == datos.EmpresaId && ea.Ano == datos.Ano);

            if (empresaAno == null)
            {
                logger.LogWarning("No se encontró EmpresasAno para guardar");
                return;
            }

            var total = await CalcularTotalCPSAsync(datos);

            if (datos.TipoInforme == TipoInformeCPS.General)
            {
                empresaAno.CPS_CapPropioSimplificado = (double)total;
            }
            else
            {
                empresaAno.CPS_CapPropioSimplVarAnual = (double)total;
            }

            if (datos.EsProPymeGeneral)
            {
                empresaAno.CPS_BaseImpPrimCat_14DN3 = (double)datos.BaseImponible14DN3;
                empresaAno.CPS_BaseImpPrimCat_14DN8 = 0;
            }
            else
            {
                empresaAno.CPS_BaseImpPrimCat_14DN3 = 0;
                empresaAno.CPS_BaseImpPrimCat_14DN8 = (double)datos.BaseImponible14DN8;
            }

            if (datos.TipoInforme == TipoInformeCPS.VariacionAnual)
            {
                empresaAno.CPS_CapPropioTribAnoAnt = (double)datos.CapPropioTribAnoAnt;
                empresaAno.CPS_RepPerdidaArrastre = (double)datos.RepPerdidaArrastre;
            }

            await context.SaveChangesAsync();

            logger.LogInformation("CPS guardado exitosamente: Total = {Total}", total);
        }
    }

    public Task<decimal> CalcularTotalCPSAsync(CapitalPropioSimplificadoDto datos)
    {
        decimal total = 0;

        // Componentes base
        total += datos.CapitalAportado;
        total += datos.AumentosCapital;
        total += datos.BaseImponible; // Ya considera si es 14DN3 o 14DN8
        total -= datos.DisminucionesCapital;
        total -= datos.GastosRechazados;
        total -= datos.RetirosDividendos;
        total -= datos.IngresoDiferido;
        total += datos.OtrosAjustesAumentos;
        total -= datos.OtrosAjustesDisminuciones;

        // Solo Pro Pyme General
        if (datos.EsProPymeGeneral)
        {
            total += datos.INRPropios;
            total -= datos.INRPropiosPerdidas;
            total += datos.Participaciones;
            total -= datos.UtilidadesPerdida;
            total += datos.IncentivoAhorro;
            total += datos.IDPCVoluntario;
                
            if (datos.Ano <= 2021)
            {
                total -= datos.CTDImputableIPE;
            }
        }

        // Solo Pro Pyme Transparente
        if (datos.EsProPymeTransparente)
        {
            total -= datos.CredActFijos;
            total -= datos.CredParticipaciones;
        }

        // Solo Variación Anual
        if (datos.TipoInforme == TipoInformeCPS.VariacionAnual)
        {
            total += datos.CapPropioTribAnoAnt;
            total += datos.RepPerdidaArrastre;
        }

        // No puede ser negativo
        if (total < 0) total = 0;

        return Task.FromResult(total);
    }
}