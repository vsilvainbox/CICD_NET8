using Microsoft.AspNetCore.Mvc;
using App.Helpers;
using System.Text.Json;
using App.Extensions;

namespace App.Features.CompraVenta;

/// <summary>
/// MVC Controller para gestión de compra/venta - NUNCA inyecta services directamente
/// Basado en FrmCompraVenta.frm del sistema VB6
/// </summary>

public class CompraVentaController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<CompraVentaController> logger) : Controller
{
    [HttpGet]
    public IActionResult Index(int? tipoLib, int? ano, int? mes)
    {
        logger.LogInformation("Loading CompraVenta index for tipoLib: {TipoLib}, año: {Ano}, mes: {Mes}",
            tipoLib, ano, mes);

        // Pasar parámetros a la vista
        ViewBag.TipoLib = tipoLib;
        ViewBag.Ano = ano ?? DateTime.Now.Year;
        ViewBag.Mes = mes ?? DateTime.Now.Month;
        ViewBag.EmpresaId = SessionHelper.EmpresaId;

        return View();
    }

    /// <summary>
    /// Crear nuevo documento de compra/venta - Redirige a GestionDocumentos
    /// GET /CompraVenta/Create?tipoLib={tipoLib}
    /// </summary>
    [HttpGet]
    public IActionResult Create(int? tipoLib)
    {
        logger.LogInformation("Redirigiendo a creación de documento con tipoLib: {TipoLib}", tipoLib);

        // Redirigir a GestionDocumentos/Create con el tipo de libro
        return RedirectToAction("Create", "GestionDocumentos", new { tipoLib = tipoLib });
    }

    /// <summary>
    /// Editar documento de compra/venta - Redirige a GestionDocumentos
    /// GET /CompraVenta/Edit/{id}
    /// </summary>
    [HttpGet]
    public IActionResult Edit(int id)
    {
        logger.LogInformation("Redirigiendo a edición de documento {IdDoc}", id);

        // Redirigir a GestionDocumentos/Edit con el ID del documento
        return RedirectToAction("Edit", "GestionDocumentos", new { idDoc = id });
    }

    /// <summary>
    /// Método proxy para obtener documentos de compra/venta
    /// GET /CompraVenta/GetDocumentos?tipoLib={tipoLib}&amp;ano={ano}&amp;mes={mes}
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetDocumentos(int tipoLib, short ano, int mes)
    {
        logger.LogInformation("Proxy: GetDocumentos - tipoLib: {TipoLib}, ano: {Ano}, mes: {Mes}", tipoLib, ano, mes);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(CompraVentaApiController.GetAll),
                controller: nameof(CompraVentaApiController).Replace("Controller", ""),
                values: new { empresaId = SessionHelper.EmpresaId, ano, tipoLib, mes }
            );
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Método proxy para eliminar documento
    /// </summary>
    [HttpDelete]
    public async Task<IActionResult> EliminarDocumento(int id)
    {
        logger.LogInformation("Proxy: EliminarDocumento - id: {Id}", id);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(CompraVentaApiController.Delete),
                controller: nameof(CompraVentaApiController).Replace("Controller", ""),
                values: new { id }
            );
            var (statusCode, content) = await client.ProxyRequestAsync(url!, null, HttpMethod.Delete);
            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// Método proxy para centralizar documentos de compra/venta
    /// POST /CompraVenta/Centralizar
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Centralizar([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: Centralizar documentos");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(CompraVentaApiController.Centralizar),
                controller: nameof(CompraVentaApiController).Replace("Controller", ""));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// Método proxy para exportar a Excel
    /// GET /CompraVenta/ExportarExcel?tipoLib={tipoLib}&amp;ano={ano}&amp;mes={mes}
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ExportarExcel(int tipoLib, short ano, int mes)
    {
        logger.LogInformation("Proxy: ExportarExcel - tipoLib: {TipoLib}, ano: {Ano}, mes: {Mes}", tipoLib, ano, mes);

        // Validar parámetros
        if (mes < 1 || mes > 12)
        {
            logger.LogWarning("Mes inválido: {Mes}. Debe estar entre 1 y 12", mes);
            return BadRequest(new { message = $"Mes inválido: {mes}. Debe estar entre 1 y 12" });
        }

        if (ano < 2000 || ano > DateTime.Now.Year + 1)
        {
            logger.LogWarning("Año inválido: {Ano}", ano);
            return BadRequest(new { message = $"Año inválido: {ano}" });
        }

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(CompraVentaApiController.Exportar),
                controller: nameof(CompraVentaApiController).Replace("Controller", ""),
                values: new { empresaId = SessionHelper.EmpresaId, ano, tipoLib, mes }
            );
            var (fileBytes, contentType) = await client.DownloadFileAsync(url, HttpMethod.Get);
            var fileName = $"LibroCompraVenta_{tipoLib}_{ano}_{mes:D2}.xlsx";
            return File(fileBytes, contentType, fileName);
        }
    }
}
