namespace App.Features.CompraVenta;

/// <summary>
/// DTO para gestión de documentos de compra/venta
/// Basado en entidad Documento de app\Data\Documento.cs
/// </summary>
public class CompraVentaDto
{
    public int IdDoc { get; set; }
    public int? IdEmpresa { get; set; }
    public short? Ano { get; set; }
    public byte? TipoLib { get; set; }
    public byte? TipoDoc { get; set; }
    public string? NumDoc { get; set; }
    public int? IdEntidad { get; set; }
    public string? RutEntidad { get; set; }
    public string? NombreEntidad { get; set; }
    public int? FEmision { get; set; }
    public int? FVenc { get; set; }
    public string? Descrip { get; set; }
    public short? Estado { get; set; }
    public double? Exento { get; set; }
    public double? Afecto { get; set; }
    public double? IVA { get; set; }
    public double? OtroImp { get; set; }
    public double? Total { get; set; }
    
    // Campos adicionales para UI
    public string? TipoDocNombre { get; set; }
    public string? TipoDocTexto { get; set; }
    public string? FechaEmisionTexto { get; set; }
    public string? TotalTexto { get; set; }
    public string? RazonSocial { get; set; }  // Alias para NombreEntidad (para JS)
    public DateTime? FEmisionDate { get; set; }  // Fecha como DateTime para JavaScript
}

public class TipoDocumentoInfo
{
    public short? Codigo { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public string TipoLibro { get; set; } = string.Empty;
    public short? TipoLib { get; set; }
}

public class MesInfo
{
    public int NumeroMes { get; set; }
    public string NombreMes { get; set; } = string.Empty;
}

/// <summary>
/// DTO para crear nuevos documentos
/// </summary>
public class CompraVentaCreateDto
{
    public int IdEmpresa { get; set; }
    public short Ano { get; set; }
    public byte TipoLib { get; set; }
    public byte TipoDoc { get; set; }
    public string NumDoc { get; set; } = string.Empty;
    public int? IdEntidad { get; set; }
    public string? RutEntidad { get; set; }
    public string? NombreEntidad { get; set; }
    public int FEmision { get; set; }
    public int? FVenc { get; set; }
    public string? Descrip { get; set; }
    public short Estado { get; set; }
    public double Exento { get; set; }
    public double Afecto { get; set; }
    public double IVA { get; set; }
    public double OtroImp { get; set; }
    public double Total { get; set; }
}

/// <summary>
/// DTO para actualizar documentos existentes
/// </summary>
public class CompraVentaUpdateDto
{
    public int IdDoc { get; set; }
    public byte TipoDoc { get; set; }
    public string NumDoc { get; set; } = string.Empty;
    public int? IdEntidad { get; set; }
    public string? RutEntidad { get; set; }
    public string? NombreEntidad { get; set; }
    public int FEmision { get; set; }
    public int? FVenc { get; set; }
    public string? Descrip { get; set; }
    public short Estado { get; set; }
    public double Exento { get; set; }
    public double Afecto { get; set; }
    public double IVA { get; set; }
    public double OtroImp { get; set; }
    public double Total { get; set; }
}
