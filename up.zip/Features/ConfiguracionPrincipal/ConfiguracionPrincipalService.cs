using Microsoft.EntityFrameworkCore;
using App.Data;

namespace App.Features.ConfiguracionPrincipal;

public class ConfiguracionPrincipalService(LpContabContext context, ILogger<ConfiguracionPrincipalService> logger) : IConfiguracionPrincipalService
{
    public async Task<ConfiguracionDto> GetConfigAsync(int? empresaId = null, short? ano = null)
    {
        logger.LogInformation("Obteniendo configuración para empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var config = new ConfiguracionDto
            {
                EmpresaId = empresaId,
                Ano = ano
            };

            // Cargar parámetros globales del sistema
            var paramsSistema = await context.Param
                .Where(p => p.Tipo == "CONFIG")
                .ToListAsync();

            foreach (var param in paramsSistema)
            {
                ApplyParamToConfig(config, param.Codigo, param.Valor);
            }

            // Si hay empresa, cargar parámetros específicos de empresa
            if (empresaId.HasValue && ano.HasValue)
            {
                var paramsEmpresa = await context.ParamEmpresa
                    .Where(p => p.IdEmpresa == empresaId && p.Ano == ano && p.Tipo == "CONFIG")
                    .ToListAsync();

                foreach (var param in paramsEmpresa)
                {
                    if (param.Codigo.HasValue && param.Codigo != 0)
                    {
                        ApplyParamToConfig(config, param.Codigo.Value, param.Valor);
                    }
                }
            }

            logger.LogInformation("Configuración obtenida exitosamente");
            return config;
        }
    }

    public async Task SaveConfigAsync(GuardarConfiguracionDto request)
    {
        logger.LogInformation("Guardando configuración para empresaId: {EmpresaId}", request.EmpresaId);

        {
            var parametros = ConvertConfigToParams(request.Configuracion);

            if (request.EmpresaId.HasValue && request.Ano.HasValue)
            {
                // Guardar en ParamEmpresa
                foreach (var param in parametros)
                {
                    var existente = await context.ParamEmpresa
                        .FirstOrDefaultAsync(p => p.IdEmpresa == request.EmpresaId
                                                  && p.Ano == request.Ano
                                                  && p.Tipo == param.Tipo
                                                  && p.Codigo == param.Codigo);

                    if (existente != null)
                    {
                        existente.Valor = param.Valor;
                    }
                    else
                    {
                        context.ParamEmpresa.Add(new App.Data.ParamEmpresa
                        {
                            IdEmpresa = request.EmpresaId,
                            Ano = request.Ano,
                            Tipo = param.Tipo,
                            Codigo = param.Codigo,
                            Valor = param.Valor
                        });
                    }
                }
            }
            else
            {
                // Guardar en Param (sistema)
                foreach (var param in parametros)
                {
                    var existente = await context.Param
                        .FirstOrDefaultAsync(p => p.Tipo == param.Tipo && p.Codigo == param.Codigo);

                    if (existente != null)
                    {
                        existente.Valor = param.Valor;
                    }
                    else
                    {
                        context.Param.Add(new App.Data.Param
                        {
                            Tipo = param.Tipo,
                            Codigo = param.Codigo,
                            Valor = param.Valor
                        });
                    }
                }
            }

            await context.SaveChangesAsync();
            logger.LogInformation("Configuración guardada exitosamente");
        }
    }

    public async Task RestoreDefaultsAsync(int? empresaId = null, short? ano = null)
    {
        logger.LogInformation("Restaurando valores por defecto para empresaId: {EmpresaId}", empresaId);

        {
            var defaultConfig = new ConfiguracionDto
            {
                MostrarCodigoCuenta = true,
                ImprimirLogo = true,
                NumeroDecimales = 2,
                UsarMonedaExtranjera = false,
                ModoLibroOficial = false,
                ImprimirFechaReportes = true,
                ImprimirNombreUsuario = false,
                FormatoFecha = "dd/MM/yyyy",
                ValidarComprobantesBalanceados = true,
                PermitirComprobantesNegativos = false,
                AutonumerarComprobantes = true
            };

            await SaveConfigAsync(new GuardarConfiguracionDto
            {
                EmpresaId = empresaId,
                Ano = ano,
                Configuracion = defaultConfig
            });

            logger.LogInformation("Valores por defecto restaurados exitosamente");
        }
    }

    public async Task<IEnumerable<ComboItemDto>> GetTiposComprobanteAsync()
    {
        logger.LogInformation("Obteniendo tipos de comprobante");

        {
            var tipos = await context.Param
                .Where(p => p.Tipo == "TIPOCOMP")
                .Select(p => new ComboItemDto
                {
                    Id = p.Codigo,
                    Codigo = p.Diminutivo ?? string.Empty,
                    Descripcion = p.Valor ?? string.Empty
                })
                .ToListAsync();

            return tipos;
        }
    }

    public async Task<IEnumerable<ComboItemDto>> GetMonedasAsync()
    {
        logger.LogInformation("Obteniendo monedas");

        {
            var monedas = await context.Monedas
                .Select(m => new ComboItemDto
                {
                    Id = m.idMoneda,
                    Codigo = m.Simbolo ?? string.Empty,
                    Descripcion = m.Descrip ?? string.Empty
                })
                .ToListAsync();

            return monedas;
        }
    }

    private void ApplyParamToConfig(ConfiguracionDto config, int codigo, string? valor)
    {
        if (string.IsNullOrEmpty(valor)) return;

        switch (codigo)
        {
            case 1:
                config.MostrarCodigoCuenta = valor == "1" || valor.ToUpper() == "TRUE";
                break;
            case 2:
                config.ImprimirLogo = valor == "1" || valor.ToUpper() == "TRUE";
                break;
            case 3:
                if (int.TryParse(valor, out var decimales))
                    config.NumeroDecimales = decimales;
                break;
            case 4:
                config.UsarMonedaExtranjera = valor == "1" || valor.ToUpper() == "TRUE";
                break;
            case 5:
                config.ModoLibroOficial = valor == "1" || valor.ToUpper() == "TRUE";
                break;
            case 6:
                if (int.TryParse(valor, out var tipoComp))
                    config.TipoComprobanteDefault = tipoComp;
                break;
            case 7:
                if (int.TryParse(valor, out var monedaId))
                    config.MonedaPrincipalId = monedaId;
                break;
            case 8:
                if (int.TryParse(valor, out var empresaId))
                    config.EmpresaDefecto = empresaId;
                break;
            case 9:
                config.ImprimirFechaReportes = valor == "1" || valor.ToUpper() == "TRUE";
                break;
            case 10:
                config.ImprimirNombreUsuario = valor == "1" || valor.ToUpper() == "TRUE";
                break;
            case 11:
                config.FormatoFecha = valor;
                break;
            case 12:
                config.ValidarComprobantesBalanceados = valor == "1" || valor.ToUpper() == "TRUE";
                break;
            case 13:
                config.PermitirComprobantesNegativos = valor == "1" || valor.ToUpper() == "TRUE";
                break;
            case 14:
                config.AutonumerarComprobantes = valor == "1" || valor.ToUpper() == "TRUE";
                break;
        }
    }

    private List<ParamData> ConvertConfigToParams(ConfiguracionDto config)
    {
        var parametros = new List<ParamData>
        {
            new("CONFIG", 1, config.MostrarCodigoCuenta ? "1" : "0"),
            new("CONFIG", 2, config.ImprimirLogo ? "1" : "0"),
            new("CONFIG", 3, $"{config.NumeroDecimales}"),
            new("CONFIG", 4, config.UsarMonedaExtranjera ? "1" : "0"),
            new("CONFIG", 5, config.ModoLibroOficial ? "1" : "0"),
            new("CONFIG", 6, config.TipoComprobanteDefault.HasValue ? $"{config.TipoComprobanteDefault.Value}" : ""),
            new("CONFIG", 7, config.MonedaPrincipalId.HasValue ? $"{config.MonedaPrincipalId.Value}" : ""),
            new("CONFIG", 8, config.EmpresaDefecto.HasValue ? $"{config.EmpresaDefecto.Value}" : ""),
            new("CONFIG", 9, config.ImprimirFechaReportes ? "1" : "0"),
            new("CONFIG", 10, config.ImprimirNombreUsuario ? "1" : "0"),
            new("CONFIG", 11, config.FormatoFecha),
            new("CONFIG", 12, config.ValidarComprobantesBalanceados ? "1" : "0"),
            new("CONFIG", 13, config.PermitirComprobantesNegativos ? "1" : "0"),
            new("CONFIG", 14, config.AutonumerarComprobantes ? "1" : "0")
        };

        return parametros;
    }

    private record ParamData(string Tipo, short Codigo, string Valor);
}