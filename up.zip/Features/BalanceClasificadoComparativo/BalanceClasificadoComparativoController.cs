using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.BalanceClasificadoComparativo;

public class BalanceClasificadoComparativoController(
    ILogger<BalanceClasificadoComparativoController> logger,
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator) : Controller
{
    /// <summary>
    /// Vista principal del Balance Clasificado Comparativo
    /// GET /BalanceClasificadoComparativo
    /// </summary>
    [HttpGet]
    public IActionResult Index(
        [FromQuery] BalanceClasificadoComparativoMode modo = BalanceClasificadoComparativoMode.BalanceClasificado)
    {
        logger.LogInformation(
            "Balance Clasificado Comparativo: Index called with empresaId: {EmpresaId}, a�o: {Ano}, modo: {Modo}",
            SessionHelper.EmpresaId,
            SessionHelper.Ano,
            modo);

        var viewModel = new BalanceClasificadoComparativoViewModel
        {
            EmpresaId = SessionHelper.EmpresaId,
            Ano = SessionHelper.Ano,
            Modo = modo,
            WindowTitle = GetWindowTitle(modo, SessionHelper.EmpresaId, SessionHelper.Ano)
        };

        return View(viewModel);
    }

    /// <summary>
    /// Vista del Balance Clasificado (Activo/Pasivo/Patrimonio)
    /// GET /BalanceClasificadoComparativo/balance
    /// </summary>
    [HttpGet]
    public IActionResult BalanceClasificado()
    {
        logger.LogInformation("Opening Balance Clasificado view");

        var viewModel = new BalanceClasificadoComparativoViewModel
        {
            EmpresaId = SessionHelper.EmpresaId,
            Ano = SessionHelper.Ano,
            Modo = BalanceClasificadoComparativoMode.BalanceClasificado,
            WindowTitle = GetWindowTitle(BalanceClasificadoComparativoMode.BalanceClasificado, SessionHelper.EmpresaId, SessionHelper.Ano)
        };

        return View("Index", viewModel);
    }

    /// <summary>
    /// Vista del Estado de Resultado Comparativo
    /// GET /BalanceClasificadoComparativo/estado-resultado
    /// </summary>
    [HttpGet]
    public IActionResult EstadoResultado()
    {
        logger.LogInformation("Opening Estado de Resultado view");

        var viewModel = new BalanceClasificadoComparativoViewModel
        {
            EmpresaId = SessionHelper.EmpresaId,
            Ano = SessionHelper.Ano,
            Modo = BalanceClasificadoComparativoMode.EstadoResultado,
            WindowTitle = GetWindowTitle(BalanceClasificadoComparativoMode.EstadoResultado, SessionHelper.EmpresaId, SessionHelper.Ano)
        };

        return View("Index", viewModel);
    }

    private string GetWindowTitle(BalanceClasificadoComparativoMode modo, int empresaId, short ano)
    {
        var tipoBalance = modo == BalanceClasificadoComparativoMode.BalanceClasificado
            ? "Balance Clasificado Comparativo"
            : "Estado de Resultado Comparativo";

        return $"{tipoBalance} - Empresa {empresaId} - A�o {ano}";
    }

    /// <summary>
    /// PROXY: Obtiene opciones de filtros (�reas de Negocio, Centros de Costo)
    /// GET /BalanceClasificadoComparativo/Opciones
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Opciones([FromQuery] int empresaId)
    {
        logger.LogInformation(
            "BalanceClasificadoComparativo: Proxy Opciones called with empresaId: {EmpresaId}",
            empresaId);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(BalanceClasificadoComparativoApiController.GetOpciones),
                controller: nameof(BalanceClasificadoComparativoApiController).Replace("Controller", ""),
                values: new { empresaId }
            );
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// PROXY: Genera el balance clasificado comparativo
    /// POST /BalanceClasificadoComparativo/Generar
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Generar([FromBody] JsonElement request)
    {
        logger.LogInformation("BalanceClasificadoComparativo: Proxy Generar called");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(BalanceClasificadoComparativoApiController.Generar),
                controller: nameof(BalanceClasificadoComparativoApiController).Replace("Controller", "")
            );
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// PROXY: Exporta el balance a Excel
    /// POST /BalanceClasificadoComparativo/ExportarExcel
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> ExportarExcel([FromBody] JsonElement request)
    {
        logger.LogInformation("BalanceClasificadoComparativo: Proxy ExportarExcel called");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(BalanceClasificadoComparativoApiController.ExportarExcel),
                controller: nameof(BalanceClasificadoComparativoApiController).Replace("Controller", "")
            );
            var (fileBytes, contentType) = await client.DownloadFileAsync(
                url,
                HttpMethod.Post,
                request);

            var fileName = $"BalanceClasificadoComparativo_{SessionHelper.EmpresaId}_{DateTime.Now:yyyyMMddHHmmss}.xlsx";
            return File(fileBytes, contentType, fileName);
        }
    }
}

/// <summary>
/// ViewModel para la vista del Balance Clasificado Comparativo
/// </summary>
public class BalanceClasificadoComparativoViewModel
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public BalanceClasificadoComparativoMode Modo { get; set; }
    public string WindowTitle { get; set; } = string.Empty;
}