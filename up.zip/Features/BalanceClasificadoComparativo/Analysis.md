# Legacy Analysis: BalanceClasificadoComparativo

## 📄 Información del Formulario VB6

**Archivo VB6:** `old/Contabilidad70/HyperContabilidad/FrmBalClasifCompar.frm`  
**Fecha Análisis:** 2025-09-30  
**Analista:** IA  
**Complejidad:** Alta

### Propósito del Formulario
Formulario de escritorio que genera el **Balance Clasificado Comparativo** y el **Estado de Resultado Clasificado Comparativo** para una empresa. Permite comparar saldos de cuentas contables entre el periodo actual y el periodo anterior con múltiples filtros (nivel de cuenta, área de negocio, centro de costo, tipo de ajuste, libro oficial) y funcionalidades avanzadas: visualización de diferencias, subtotales jerárquicos, cálculo automático del resultado del ejercicio, exportación a Excel, impresión con pie de firma, envío por correo y navegación directa al libro mayor de la cuenta seleccionada. La pantalla exige privilegios para activar el régimen de libro oficial y reutiliza el mismo formulario con distintas configuraciones (activo/pasivo vs. resultado) según la invocación (`FViewBalClasif` o `FViewEstResultClasif`).

---

## 🎨 CONTROLES UI IDENTIFICADOS

### Textboxes (Campos de Entrada)
| Control VB6 | Propiedad Bound | Tipo | Validación | Propósito |
|-------------|----------------|------|------------|-----------|
| `Tx_Desde_Ant` | Fecha (año anterior) | Fecha (Long serial) | Requerido si comparación manual. Usa `DtGotFocus/DtLostFocus`, `KeyDate`. | Fecha inicio periodo anterior para saldos comparativos. |
| `Tx_Hasta_Ant` | Fecha (año anterior) | Fecha | Igual que anterior. | Fecha fin periodo anterior. |
| `Tx_Desde_Actual` | Fecha periodo actual | Fecha | Requiere año actual `gEmpresa.Ano`. | Fecha inicio periodo actual. |
| `Tx_Hasta_Actual` | Fecha periodo actual | Fecha | Requiere año actual `gEmpresa.Ano`, no menor a inicio. | Fecha fin periodo actual. |

### ComboBoxes (Listas Desplegables)
| Control VB6 | Fuente Datos | Valor | Display | Evento Change |
|-------------|--------------|-------|---------|---------------|
| `Cb_TipoAjuste` | `gTipoAjuste()` (Financiero, Tributario) | `TAJUSTE_*` | Texto de ajuste | Filtra comprobantes según tipo de ajuste, llama `EnableFrm(True)`.
| `Cb_Nivel` | `FillNivel` usando `gNiveles` (máx 5) | Nivel entero | "Nivel X" | Cambia profundidad del informe, re-habilita `Bt_Buscar`.
| `Cb_AreaNeg` | `FillCbAreaNeg` | `IdAreaNeg` | Descripción | Filtra por área de negocio, deshabilitado cuando `Ch_LibOficial` activo. |
| `Cb_CCosto` | `FillCbCCosto` | `IdCCosto` | Descripción | Filtra por centro de costo, también bloqueado con libro oficial. |

### CheckBoxes
| Control VB6 | Propósito | Eventos | Notas |
|-------------|-----------|---------|-------|
| `Ch_LibOficial` | Limita a comprobantes APROBADOS y activa control de impresión foliado. | Click → deshabilita filtros de área/centro, re-habilita `Bt_Buscar`. | Requiere privilegio `PRV_IMP_LIBOF`, se fuerza `False` en `SetupPriv` si no hay permiso. |
| `Ch_VerSubTot` | Mostrar/ocultar totales de nivel 1 cuando clasificación ≠ activo/pasivo. | Click → `EnableFrm(True)`. | Visible sólo cuando `lBalClasif=False` (estado de resultado). |
| `Ch_VerCodCuenta` | Mostrar u ocultar columna de código de cuenta. | Click recalcula anchos. | Sincroniza ancho con `GridTot`.

### Grillas (MSFlexGrid)
| Control VB6 | Fuente Datos | Columnas | Eventos | Acciones |
|-------------|--------------|----------|---------|----------|
| `Grid` | Datos armados por `LoadAll` desde queries temporales `GenQueryPorNiveles`. | 13+ columnas (Código, Cuenta, Saldo año anterior/actual, Diferencia, Nivel, IdCuenta, Clasificación, Debe/Haber por periodo, formato). | `DblClick` (ver libro mayor), `Scroll` (sincroniza totales). | Presenta jerarquía de cuentas, oculta filas en cero, colorea niveles y subtotales. |
| `GridTot` | Totales calculados en `LoadAll` | Resumen Final | Sin eventos interactivos | Muestra totales comparativos al pie, sincronizado con scroll.

### Labels y Campos Calculados
| Control VB6 | Cálculo/Origen | Actualización |
|-------------|----------------|---------------|
| `GridTot.TextMatrix` fila 0 | Resultado final por clasificación | Actualizado al final de `LoadAll`.
| Etiquetas de rango (`Label1`, `Label2`, `Label3`) | Texto fijo | Muestran contexto de fechas. |

### Botones de Acción
| Botón VB6 | Caption | Habilitado Si | Acción VB6 | Mapeo .NET esperado |
|-----------|---------|---------------|------------|---------------------|
| `Bt_Buscar` | "&Listar" | Validaciones de fecha exitosas | Ejecuta `LoadAll` para reconstruir informe; deshabilita botón hasta cambios. | `POST /api/BalanceClasificadoComparativo/listar` con filtros; servicio genera dataset jerárquico. |
| `Bt_VerLibMayor` | icono | Fila con `IdCuenta` válido | Abre `FrmLibMayor` en modo detalle para cuenta seleccionada. | Enlace a vista Libro Mayor con querystring `idCuenta`, integrando router. |
| `Bt_CopyExcel` | icono Excel | Grid poblada (`Bt_Buscar.Enabled=False`) | Usa `LP_FGr2Clip_Membr` para copiar datos (ambos periodos) al portapapeles. | Acción front-end: exportar a Excel (generar `.xlsx` vía API). |
| `Bt_Preview` | icono vista previa | Datos listados | Configura impresión (`SetUpPrtGrid`), abre `FrmPrintPreview`, imprime con `PrtPieBalanceFirma`. | Generar PDF/Preview en web, reutilizar motor de reportes. |
| `Bt_Print` | icono impresora | Datos listados; verifica historial libro oficial | Prepara impresora, registra impresión en `LogImpreso`, actualiza folio. | Llamar servicio de impresión/registro y produce PDF para descarga. |
| `Bt_Email` | icono correo | Datos listados | Crea adjunto con `Export_SendEmail` y abre `FrmEmailAccount`. | Integración existente de correo (enviar PDF/Excel). |
| `Bt_Sum` | icono suma | Siempre | `FrmSumSimple.FViewSum(Grid)` para sumar selección. | Modal de sumatoria en web (JS). |
| `Bt_ConvMoneda` | icono moneda | Siempre | `FrmConverMoneda.FView` para convertir valores. | Modal de conversor de moneda (JS). |
| `Bt_Calc` | icono calculadora | Siempre | Llama a `Calculadora` (aplicación auxiliar). | Abrir widget calculadora (JS). |
| `Bt_Calendar` | icono calendario | Siempre | Abre `FrmCalendar` para selección rápida (sin binding directo). | UI: date picker web. |
| `Bt_Fecha(0-3)` | iconos calendario | Siempre | Permiten seleccionar fechas en textboxes correspondientes mediante `FrmCalendar`. | UI: date pickers integrados. |
| `Bt_Cerrar` | "Cerrar" | Siempre | `Unload Me`. | Navegar fuera de vista (retorno). |
| `Bt_Email`, `Bt_CopyExcel`, `Bt_VerLibMayor` etc. | | | Todos deben existir en la vista migrada según reglas. |.

### Otros Controles
| Tipo | Nombre | Propósito | Eventos |
|------|--------|-----------|---------|
| Frame | `Frame1`, `Frame2` | Agrupan toolbar y filtros | N/A |
| Form | `FrmBalClasifCompar` | Contenedor principal | Tiene eventos `Form_Load`, `Form_Resize`. |

---

## 🔘 EVENTOS IDENTIFICADOS

### Eventos de Formulario
| Evento VB6 | Cuándo | Acciones | Mapeo .NET |
|------------|--------|----------|------------|
| `Form_Load` | Al abrir formulario | Determina mes default (`GetMesActual` o último con comprobantes), inicializa fechas actuales y anteriores (incluye modo `gFechaComparativo`), inicializa combos (`FillNivel`, `FillCbAreaNeg`, `FillCbCCosto`), configura checkboxes, lee cuenta de resultado (`ReadResEje`), ejecuta `LoadAll`, aplica privilegios (`SetupPriv`). | MVC controller carga vista inicial llamando API para defaults; JS inicializa filtros; service prepara dataset inicial. |
| `Form_Resize` | Cambio tamaño ventana | Ajusta alto/ancho de grillas y totales; recalcula altura cuando `lBalClasif`. | CSS responsive; JS ajusta scroll/altura. |

### Eventos de Botones (principales)
- Ya cubiertos en tabla de botones: `Bt_Buscar_Click`, `Bt_Print_Click`, `Bt_Preview_Click`, `Bt_CopyExcel_Click`, `Bt_Email_Click`, `Bt_VerLibMayor_Click`, `Bt_Sum_Click`, `Bt_ConvMoneda_Click`, `Bt_Calc_Click`, `Bt_Calendar_Click`, `Bt_Fecha_Click`, `Bt_Cerrar_Click`.

### Eventos de Controles
| Control.Evento | Trigger | Acción VB6 | Mapeo .NET |
|----------------|---------|------------|------------|
| `Cb_Nivel_Click`, `Cb_TipoAjuste_Click`, `Cb_AreaNeg_Click`, `Cb_CCosto_Click`, `Ch_VerSubTot_Click`, `Ch_LibOficial_Click`, `Ch_VerCodCuenta_Click` | Cambio de selección | Reactivan botón Listar y aplican validaciones/UX (ej. `Ch_LibOficial` bloquea combos). | JS marca formulario como "dirty"; habilita botón de consulta; actualiza UI. |
| `Tx_*_Change` | Cambian fechas | `EnableFrm(True)` habilita nuevo cálculo. | JS habilita refresco y valida. |
| `Tx_*_GotFocus/KeyPress/LostFocus` | Interacción usuario | Aplica helpers (`DtGotFocus`, `KeyDate`, `DtLostFocus`). | Date picker / validador en front-end. |
| `Grid_DblClick` | Doble click en fila | Llama a `Bt_VerLibMayor_Click`. | Doble clic abre detalle libro mayor. |
| `Grid_Scroll` | Scroll vertical | Sincroniza `GridTot.LeftCol`. | JS sincroniza scroll cabecera/pie. |

---

## 🔧 FUNCIONES Y PROCEDIMIENTOS VB6

### Principales
- **`Bt_Buscar_Click`**: Valida fechas (desde ≤ hasta, mismo año actual), muestra mensajes y ejecuta `LoadAll` dentro de cursor hourglass.
- **`LoadAll`**: Núcleo del reporte. Pasos:
  1. Valida existencia de año anterior (`gEmpresa.TieneAnoAnt` y `HayAnoAnterior`).
  2. Construye filtros (`WhFecha`, `WhFechaAnt`, más filtros de área, centro, ajuste, libro oficial) y genera SQL con `GenQueryPorNiveles` para ambos periodos.
  3. Para Access con empresas separadas, enlaza temporalmente tablas del año anterior.
  4. Crea consultas temporales (`CreateQry`) y combina ambos periodos en un recordset con `UNION` para alinear códigos de cuenta.
  5. Itera el recordset para construir filas en `Grid`, manteniendo totales acumulados por nivel (`Total`, `TotalAnt`), formateando estilos según nivel/color, insertando subtotales por cuenta padre (`TOT_CUENTA`) y gestionando clasificación (activo/pasivo/resultado).
  6. Maneja resultado del ejercicio (`AddResEjercicio`, `ReadResEje`) sumando al patrimonio y al total de pasivo.
  7. Calcula columnas visibles: saldos (`C_VALOR`, `C_VALORANT`) como diferencias Debe/Haber, y `C_DIF` como delta entre periodos.
  8. Oculta filas sin movimiento en ambos periodos y actualiza totales globales (`GridTot`).
  9. Restaura scroll y deshabilita botón `Listar` hasta nuevos cambios (`EnableFrm(False)`).
- **`SetUpGrid`**: Configura columnas iniciales (anchos, encabezados, alineación), aplica estilos, oculta columnas auxiliares (Debe/Haber, nivel, formato) y sincroniza totals.
- **`SetUpPrtGrid`**: Configura objeto de impresión `gPrtLibros` con títulos, encabezados dinámicos (fechas, filtros), tipografías, anchos de columna y totales; desactiva fecha cuando se imprime libro oficial.
- **`AddResEjercicio`**: Inserta filas jerárquicas para la cuenta de resultado del ejercicio bajo patrimonio cuando corresponde al balance clasificado.
- **`ReadResEje`**: Obtiene cadena de cuentas ascendentes de la cuenta de resultado del ejercicio (`gCtasBas`).
- **`Bt_Print_Click`** / **`Bt_Preview_Click`**: Preparan impresión (selección de orientación/papel, `SetUpPrtGrid`, llamada a `PrtFlexGrid`), agregan pie de firma, registran log de impresión para libro oficial (`AppendLogImpreso`, `UpdateUltUsado`).
- **`Bt_CopyExcel_Click`**: Exporta grillas a portapapeles utilizando `LP_FGr2Clip_Membr`, incorporando metadatos de fechas para ambos periodos.
- **`Bt_Email_Click`**: Genera archivo a enviar mediante `Export_SendEmail` y lanza formulario de cuentas de correo (`FrmEmailAccount`).
- **`TraeFechasComprAñoAnterior`**: Cuando `gFechaComparativo = 1`, obtiene automáticamente el primer comprobante del año anterior para fijar fecha desde, y fija fecha hasta al último día de diciembre.
- **`ValidacionesFechas`**: Comprueba que los meses de los periodos anterior y actual sean consistentes en modo comparativo manual (mismos meses).
- **`SetupPriv`**: Deshabilita opción Libro Oficial si el usuario no posee privilegio `PRV_IMP_LIBOF`.
- **`EnableFrm`**: Alterna habilitación de botón `Listar` para prevenir reconsultas mientras hay datos vigentes.

### Funciones Suplementarias
| Función | Tipo | Propósito |
|---------|------|-----------|
| `FViewBalClasif` | Public Function | Configura variables globales para Balance clasificado comparativo (clasificación activo/pasivo, `lBalClasif=True`, `lCaption`), muestra formulario. |
| `FViewEstResultClasif` | Public Function | Alterna modo para Estado de resultado (clasificación resultado), sin totales en patrimonio. |
| `AddResEjercicio` | Private Sub | Inserta cuentas jerárquicas del resultado del ejercicio hasta nivel seleccionado. |
| `ReadResEje` | Private Sub | Construye arreglo `lResEje` con datos de cuenta de resultado (requiere `gCtasBas`). |
| `SetUpPrtGrid` | Private Sub | Configura motor de impresión con títulos, encabezados, fuentes, totales. |
| `Bt_VerLibMayor_Click` | Private Sub | Abre `FrmLibMayor` con fechas y cuenta actual para drill-down. |

---

## 💾 ACCESO A DATOS VB6

### Queries Identificadas
1. **Consulta principal periodo actual (`Q1`)**: Construida por `GenQueryPorNiveles`, recibe filtro `Where` con rango de fecha y filtros extra (tipo ajuste, área, centro) y bandera Libro Oficial. Selecciona:
   - Lista de cuentas hasta `Nivel` con columnas `Debe/Haber` agrupadas.
   - Uniones incrementales para padres/abuelos hasta `MAX_NIVELES`.
   - Opcionalmente columnas `Mes` y `IdDesglose` (no usadas en este formulario).

2. **Consulta periodo anterior (`QAnt`)**: Igual que `Q1` pero con rango sobre año anterior (`Ano = gEmpresa.Ano - 1`). Cuando se usan bases separadas (Access), se enlazan tablas `ComprobanteAnt`, `MovComprobanteAnt`, `CuentasAnt`.

3. **Consulta combinada `Q1` final**: Unión de ambas consultas temporales para obtener filas presentes en uno u otro periodo, alineando por `Codigo` e `IdQ`. Ejemplo simplificado:
```vb
Q1 = "SELECT Tmp.IdQ, Tmp.idCuenta, Tmp.Codigo, Tmp.Nivel, Tmp.Descripcion, Tmp.Debe, Tmp.Haber, Tmp.Clasificacion, " & _
     "TmpAnt.Debe as DebeAnt, TmpAnt.Haber as HaberAnt ..." & _
     "FROM Tmp LEFT JOIN TmpAnt ON Tmp.IdQ = TmpAnt.IdQ AND Tmp.Codigo = TmpAnt.Codigo" & _
     " UNION " & _
     "SELECT ... FROM TmpAnt LEFT JOIN Tmp ON ... WHERE Tmp.Codigo IS NULL"
```

4. **Fechas automáticas año anterior**: `SELECT TOP 1 fecha FROM comprobante ORDER BY idcomp ASC` (en base año anterior). Se usa para establecer fecha inicial cuando `gFechaComparativo=1`.

5. **Log de impresiones oficiales**: `QryLogImpreso`, `AppendLogImpreso` reciben parámetros de libro y fechas; la lógica está en otros módulos pero se invoca aquí.

### Mapeo Entity Framework esperado
- Reemplazar `GenQueryPorNiveles` con consultas EF/Core o SQL Raw que reproduzcan sumatorias jerárquicas (probablemente stored query generada en servicio C# reutilizando la lógica). Debe manejar unión de periodos y totales por nivel.
- Para Access/SQL Server, la migración se basará en base SQLite; se deben recrear sumatorias usando LINQ + recursion/CTE.

---

## ✅ VALIDACIONES Y REGLAS DE NEGOCIO

### Validaciones de Campos
| Escenario | Regla | Mensaje VB6 | Implementación .NET |
|-----------|-------|-------------|---------------------|
| Fechas periodo actual | `F1 <= F2` y ambos pertenecen a `gEmpresa.Ano`. | "Fecha de inicio es posterior..." / "La fecha ... no corresponde al periodo actual." | Validación server-side + mensajes UI. |
| Fechas comparativas manuales | Si `gFechaComparativo = 1`, obliga `ValidacionesFechas` (mismos meses). | "Fechas de Inicio ... distinta en Meses." | Validación adicional al llamar API. |
| Libro oficial | Si activo, sólo comprobantes aprobados (`EC_APROBADO=2`). | Mensaje informativo en `GenQueryPorNiveles`. | Aplicar filtro server y advertencia UI. |
| Privilegios | Usuario sin `PRV_IMP_LIBOF` no puede marcar `Ch_LibOficial`. | Se fuerza `Enabled=False`. | Consulta al sistema de permisos. |

### Reglas de Negocio
1. **Comparación por nivel**: Se deben respetar jerarquías hasta `MAX_NIVELES=5`, con totales y colores específicos por nivel (`gColores`).
2. **Resultado del ejercicio**: Al mostrar balance, se debe agregar dinámicamente la cuenta de resultado del ejercicio bajo patrimonio y ajustar totales pasivo/patrimonio.
3. **Clasificaciones**: Activo calcula saldo como Debe-Haber; Pasivo/Resultado usa Haber-Debe. Clasificación se obtiene desde `Cuentas.Clasificacion` (constantes `CLASCTA_*`).
4. **Subtotales opcionales**: `Ch_VerSubTot` permite ocultar totales de clasificación resultado cuando no se quieren subtotales.
5. **Ocultamiento de filas vacías**: Cuentas sin movimiento en ambos periodos se ocultan (`RowHeight=0`), pero deben permanecer para colapsar/expandir.
6. **Libro oficial**: Disparar registro (`AppendLogImpreso`) al imprimir si se usa papel foliado; requiere confirmación si ya fue impreso antes (`QryLogImpreso`).
7. **Filtros de contexto**: Area de negocio, centro de costo e tipo de ajuste restringen tanto periodo actual como anterior (misma cláusula `Wh`).
8. **Deshabilitar reconsulta**: Una vez ejecutado `LoadAll`, botón `Listar` queda deshabilitado hasta que se cambien filtros/fechas.

---

## 🧮 CÁLCULOS Y FORMULAS

| Cálculo | Descripción |
|---------|-------------|
| Saldos por cuenta | Para cuentas activas: `SaldoActual = Debe - Haber`; para pasivos/resultados: `SaldoActual = Haber - Debe`. Lo mismo para periodo anterior. |
| Diferencia comparativa | `Dif = SaldoActual - SaldoAnterior`.
| Resultado del ejercicio | `ResActual = TotActivo - TotPasivo`; `ResAnterior` similar. Sumado a patrimonio y totales pasivo.
| Totales por nivel | `Total(nivel)` acumula Debe/Haber y se escribe en filas TOT correspondientes.
| Totales finales | `GridTot` muestra `TOTAL` con sumatoria final (`TotalFinal`, `TotalFinalAnt`). |

---

## 🚀 NAVEGACIÓN Y FLUJO

### Formularios Llamados
| Desde | Destino | Parámetros | Retorno | Observaciones |
|-------|---------|------------|---------|---------------|
| `Bt_VerLibMayor_Click` | `FrmLibMayor` | Fechas actual, `IdCuenta`, tipo ajuste | Ventana modal | Drill-down al libro mayor. |
| `Bt_Sum_Click` | `FrmSumSimple` | Grilla actual | Modal | Suma selección. |
| `Bt_ConvMoneda_Click` | `FrmConverMoneda` | Valor (0) | Modal | Conversión manual. |
| `Bt_Email_Click` | `FrmEmailAccount` | Ruta adjunto, asunto, texto | Ventana de envío | Depende de módulo de correo. |
| `Bt_Calendar` / `Bt_Fecha` | `FrmCalendar` | Date | Actualiza textbox | Usado para seleccionar fechas. |

### Flujo General
```
Inicio → Form_Load → (default filters) → LoadAll → Grid poblada
Cambiar filtros/fechas → Bt_Buscar → Validaciones → LoadAll
Seleccionar fila → Bt_VerLibMayor → Libro mayor (detalle)
Bt_Print/Bt_Preview → Generar impresión y registrar log
Bt_CopyExcel/Bt_Email → Exportar / enviar resultados
```

---

## 📊 EXPORTACIONES, IMPRESIÓN Y CORREO

- **Exportación a Excel**: `LP_FGr2Clip_Membr(Grid, GridTot, ...)` copia a portapapeles en formato tabulado para Excel, incluyendo metadatos de rangos de fechas actuales y anteriores.
- **Envío Email**: `Export_SendEmail` genera archivo (probablemente Excel/CSV) y crea adjunto para ser enviado desde `FrmEmailAccount`.
- **Impresión**: Usa motor `gPrtLibros` para preparar `MSFlexGrid`, aplicar templates de encabezado/pie (`FolioEncabEmpresa`, `PrtPieBalanceFirma`) y controlar impresión oficial (papel foliado, logging). Mantiene bandera `lPapelFoliado` y `lInfoPreliminar`.
- **Vista previa**: `FrmPrintPreview` muestra la misma salida de impresión con `PrtFlexGrid`.

---

## 🔗 DEPENDENCIAS EXTERNAS DETECTADAS
- Variables globales: `gEmpresa`, `gNiveles`, `gColores`, `gFmtCodigoCta`, `gPrtLibros`, `gCtasBas`, `gFechaComparativo`, `gLibroOficial`, `gTipoAjuste`, `gLastNivel`.
- Módulos/funcones: `GenQueryPorNiveles`, `JoinEmpAno`, `HayAnoAnterior`, `DbGenTmpName2`, `CreateQry`, `OpenRs`, `CloseRs`, `LP_FGr2Clip_Membr`, `Export_SendEmail`, `QryLogImpreso`, `AppendLogImpreso`, `UpdateUltUsado`, `FillNivel`, `FillCbAreaNeg`, `FillCbCCosto`, `FGrSetup`, `FGrTotales`, `FGrSetRowStyle`, `FGrVRows`, `FmtCodCuenta`, `GetTxDate`, `SetTxDate`, `FirstLastMonthDay`, `DtGotFocus`, `DtLostFocus`, `KeyDate`, `MsgBox1`.
- Formularios reutilizados: `FrmLibMayor`, `FrmSumSimple`, `FrmConverMoneda`, `FrmCalendar`, `FrmEmailAccount`, `FrmPrintPreview`, `FrmPrtSetup`.

---

## 🎯 MAPEO .NET PROPUESTO

### Contratos (Inputs/Outputs)
- **Input principal**: parámetros de filtro
  - `empresaId` (int)
  - `fechaDesdeActual` / `fechaHastaActual` (DateOnly)
  - `fechaDesdeAnterior` / `fechaHastaAnterior` (DateOnly) — opcionales si modo automático
  - `nivel` (int, 2-5)
  - `tipoAjuste` (enum: Financiero/Tributario/Ambos)
  - `idAreaNeg` / `idCCosto` (nullable int)
  - `libroOficial` (bool)
  - `mostrarSubTotales` (bool)
  - `modoBalance` (enum BalanceClasificado | EstadoResultado)

- **Output**: estructura jerárquica con filas
  - Cada fila: código, descripción, nivel, clasificación, saldoActual, saldoAnterior, diferencia, debe/haber por periodo, indicadores de subtotal, formato/estilo.
  - Totales globales: `totalActual`, `totalAnterior`, `totalDiferencia`.
  - Metadatos: rangos formateados, filtros aplicados, banderas (libro oficial, info preliminar, resultado ejercicio). 

### Métodos de Servicio necesarios
```csharp
public interface IBalanceClasificadoComparativoService
{
    Task<BalanceClasificadoComparativoResultDto> GenerarAsync(BalanceClasificadoComparativoRequestDto request, CancellationToken ct = default);
    Task<byte[]> ExportarExcelAsync(BalanceClasificadoComparativoRequestDto request, CancellationToken ct = default);
    Task<PreviewDocumentoDto> GenerarPreviewAsync(BalanceClasificadoComparativoRequestDto request, CancellationToken ct = default);
    Task<RegistroImpresionDto> RegistrarImpresionOficialAsync(RegistroImpresionRequestDto request, CancellationToken ct = default);
}
```
- `GenerarAsync`: Replica `LoadAll`. Debe:
  - Validar fechas y años.
  - Construir estructura jerárquica (posiblemente CTE recursiva o procesamiento en memoria tras query agrupada).
  - Calcular resultado ejercicio si corresponde.
  - Marcar filas ocultables, totales, estilos.
- `ExportarExcelAsync`: Reutiliza resultado para generar archivo (EPPlus).
- `GenerarPreviewAsync`: Produce PDF o datos imprimibles; reutiliza `GenerarAsync` para dataset + templates.
- `RegistrarImpresionOficialAsync`: Maneja bitácora de impresiones (similar a `AppendLogImpreso`).

### API Controllers
- `BalanceClasificadoComparativoApiController`
  - `POST /api/BalanceClasificadoComparativo/listar` → `GenerarAsync`
  - `POST /api/BalanceClasificadoComparativo/exportar` → `ExportarExcelAsync`
  - `POST /api/BalanceClasificadoComparativo/preview` → `GenerarPreviewAsync`
  - `POST /api/BalanceClasificadoComparativo/registrar-impresion` → `RegistrarImpresionOficialAsync`

### MVC Controller & Vistas
- `BalanceClasificadoComparativoController.Index`: Renderiza vista con filtros y toolbar replicando VB6 (botones, checkboxes, combos, grilla con jerarquía). 
- JS front-end deberá:
  - Manejar date pickers duales, combos, checkboxes.
  - Consumir endpoints API para listar, exportar, previsualizar, registrar impresión, enviar correo.
  - Reproducir funcionalidades utilitarias (sumar selección, conversor, calculadora) con modales modernos.
  - Implementar copiar a portapapeles y generación de Excel.

### DTOs esenciales
- `BalanceClasificadoComparativoRequestDto`
- `BalanceClasificadoComparativoRowDto`
- `BalanceClasificadoComparativoResultDto`
- `BalanceClasificadoComparativoTotalesDto`
- `BalanceClasificadoComparativoPrintOptionsDto`
- `RegistroImpresionRequestDto`

### Edge Cases y Consideraciones
1. Empresas sin año anterior (`TieneAnoAnt=False`): en VB6 se aborta con mensaje. En .NET se retornará error controlado (HTTP 400) y mensaje UI.
2. Bases separadas en Access: ya no aplica en SQLite, pero la lógica para unir datos de año anterior debe considerar que los movimientos residen en misma base con `Ano` (propiedades `Comprobante.Ano`, `MovComprobante.Ano`).
3. Libro oficial: Debe consultarse tabla de logs (equivalente `LogImpreso`) antes de permitir impresión. Mantener confirmación.
4. Resultado ejercicio: Requiere conocer ID de cuenta configurada en `Configuración Inicial` (mapear a tabla `CtasBasicas`/`CtasAjustes?` en EF).
5. Colores/formatos: Definir mapping de niveles a clases Tailwind para replicate `gColores`.
6. Ocultamiento de filas: Implementar colapsado front-end (posiblemente toggles) manteniendo datos para exportación/impresión.

---

## ✅ CHECKLIST DE COMPLETITUD DEL ANÁLISIS
- [x] Controles UI documentados
- [x] Botones y eventos mapeados con acciones equivalentes
- [x] Grillas, columnas y comportamiento descritos
- [x] Funciones VB6 analizadas (`LoadAll`, impresión, exportación, utils)
- [x] Consultas SQL identificadas y descritas
- [x] Validaciones y reglas de negocio documentadas
- [x] Cálculos clave detallados
- [x] Flujo de navegación y dependencias externas listadas
- [x] Métodos .NET determinados (service, API, MVC, DTOs)
- [x] Consideraciones de edge cases y privilegios

**Resultado:** Análisis exhaustivo listo para iniciar migración completa a .NET 9.
