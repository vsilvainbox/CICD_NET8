using System.Drawing;
using System.Globalization;
using System.Text;
using App.Data;
using Microsoft.EntityFrameworkCore;

namespace App.Features.BalanceClasificadoComparativo;

public sealed class BalanceClasificadoComparativoService(LpContabContext context, ILogger<BalanceClasificadoComparativoService> logger) : IBalanceClasificadoComparativoService
{
    private const byte ClasctaActivo = 1;
    private const byte ClasctaPasivo = 2;
    private const byte ClasctaResultado = 3;
    private const byte ClasctaOrden = 4;

    public async Task<BalanceClasificadoComparativoResponseDto> GenerarAsync(BalanceClasificadoComparativoRequestDto request, CancellationToken cancellationToken = default)
    {
        logger.LogInformation("Generando Balance Clasificado Comparativo para EmpresaId {EmpresaId} (Modo {Modo})", request.EmpresaId, request.Modo);

        ValidarRequestFechas(request);

        var fechas = CalcularFechasComparativas(request);
        var estadosPermitidos = request.SoloLibroOficial ? new[] { 2 } : new[] { 2, 3 };
        var tipoAjusteFiltro = ConstruirFiltroTipoAjuste(request.TipoAjuste);

        var cuentas = await ObtenerCuentasAsync(request.EmpresaId, request.AnoActual, request.Nivel, cancellationToken);
        if (cuentas.Count == 0)
        {
            logger.LogWarning("No se encontraron cuentas para EmpresaId {EmpresaId} y Año {Ano}", request.EmpresaId, request.AnoActual);
            return new BalanceClasificadoComparativoResponseDto
            {
                Filtros = ConstruirFiltrosAplicados(request, fechas),
                Resumen = new BalanceClasificadoComparativoResumenDto()
            };
        }

        var movimientosActual = await ObtenerMovimientosAsync(
            request.EmpresaId,
            request.AnoActual,
            fechas.FechaDesdeActualInt,
            fechas.FechaHastaActualInt,
            estadosPermitidos,
            tipoAjusteFiltro,
            request.AreaNegocioId,
            request.CentroCostoId,
            cancellationToken);

        var movimientosAnterior = await ObtenerMovimientosAsync(
            request.EmpresaId,
            fechas.AnoAnterior,
            fechas.FechaDesdeAnteriorInt,
            fechas.FechaHastaAnteriorInt,
            estadosPermitidos,
            tipoAjusteFiltro,
            request.AreaNegocioId,
            request.CentroCostoId,
            cancellationToken);

        var agregados = ConstruirAgregados(cuentas);
        AplicarMovimientos(agregados, movimientosActual, movimientosAnterior);
        PropagarSaldos(agregados);

        var filas = ConstruirFilasOrdenadas(agregados, request);
        var totalesCalculados = CalcularTotales(filas);
        var totales = totalesCalculados.Totales;
        var totalAnteriorActivo = totalesCalculados.TotalActivoAnterior;

        var resultado = await ObtenerFilaResultadoEjercicioAsync(totalesCalculados, request, cuentas, cancellationToken);
        if (resultado is not null)
        {
            filas.Add(resultado.Value.Fila);
            totales.TotalPasivo += resultado.Value.ResultadoActual;
            totales.ResultadoEjercicioActual = resultado.Value.ResultadoActual;
            totales.ResultadoEjercicioAnterior = resultado.Value.ResultadoAnterior;
        }

        totales.TotalAnterior = totalAnteriorActivo;
        var coloresPorNivel = await ObtenerColoresPorNivelAsync(request.EmpresaId, cancellationToken);

        return new BalanceClasificadoComparativoResponseDto
        {
            Filas = filas,
            Totales = totales,
            Filtros = ConstruirFiltrosAplicados(request, fechas),
            Resumen = new BalanceClasificadoComparativoResumenDto
            {
                TotalActual = totales.TotalActivo,
                TotalAnterior = totalAnteriorActivo
            },
            TieneResultadoEjercicio = resultado is not null,
            ColoresPorNivel = coloresPorNivel
        };
    }

    public async Task<BalanceClasificadoComparativoExportResponseDto> ExportarAsync(BalanceClasificadoComparativoExportRequestDto request, CancellationToken cancellationToken = default)
    {
        var data = await GenerarAsync(request, cancellationToken);

        var builder = new StringBuilder();
        builder.AppendLine("Codigo;Cuenta;Nivel;SaldoAnterior;SaldoActual;Diferencia");
        foreach (var fila in data.Filas.Where(f => f.EsVisible))
        {
            builder.AppendLine(string.Join(';', new[]
            {
                CsvEscape(request.MostrarCodigoCuenta ? fila.Codigo : string.Empty),
                CsvEscape(fila.Nombre),
                fila.Nivel.ToString(CultureInfo.InvariantCulture),
                fila.SaldoAnterior.ToString("N2", CultureInfo.InvariantCulture),
                fila.SaldoActual.ToString("N2", CultureInfo.InvariantCulture),
                fila.Diferencia.ToString("N2", CultureInfo.InvariantCulture)
            }));
        }

        var content = Encoding.UTF8.GetBytes(builder.ToString());
        var fileName = string.IsNullOrWhiteSpace(request.NombreArchivo)
            ? $"BalanceClasificadoComparativo_{DateTime.UtcNow:yyyyMMddHHmmss}.csv"
            : request.NombreArchivo.EndsWith(".csv", StringComparison.OrdinalIgnoreCase)
                ? request.NombreArchivo
                : request.NombreArchivo + ".csv";

        return new BalanceClasificadoComparativoExportResponseDto
        {
            Content = content,
            FileName = fileName,
            ContentType = "text/csv"
        };
    }

    public async Task<BalanceClasificadoComparativoPreviewResponseDto> GenerarPreviewAsync(BalanceClasificadoComparativoPreviewRequestDto request, CancellationToken cancellationToken = default)
    {
        var data = await GenerarAsync(request, cancellationToken);

        var htmlBuilder = new StringBuilder();
        htmlBuilder.Append("<html><head><meta charset=\"utf-8\"/><title>Balance Clasificado Comparativo</title>");
        htmlBuilder.Append("<style>body{font-family:Arial,Helvetica,sans-serif;margin:24px;} table{border-collapse:collapse;width:100%;} th,td{border:1px solid #ddd;padding:6px;text-align:right;} th:nth-child(1),td:nth-child(1){text-align:left;} th:nth-child(2),td:nth-child(2){text-align:left;} .highlight{font-weight:bold;}</style></head><body>");
        htmlBuilder.Append("<h2>Balance Clasificado Comparativo</h2>");
        htmlBuilder.AppendFormat(CultureInfo.InvariantCulture,
            "<p><strong>Periodo Actual:</strong> {0:dd/MM/yyyy} - {1:dd/MM/yyyy}<br/><strong>Periodo Anterior:</strong> {2:dd/MM/yyyy} - {3:dd/MM/yyyy}</p>",
            data.Filtros.FechaDesdeActual,
            data.Filtros.FechaHastaActual,
            data.Filtros.FechaDesdeAnterior,
            data.Filtros.FechaHastaAnterior);
        htmlBuilder.Append("<table><thead><tr><th>Código</th><th>Cuenta</th><th>Nivel</th><th>Saldo Anterior</th><th>Saldo Actual</th><th>Diferencia</th></tr></thead><tbody>");
        foreach (var fila in data.Filas)
        {
            var cssClass = fila.EsResultadoEjercicio || fila.EsTotal || fila.EsFilaPadre ? "highlight" : string.Empty;
            if (!fila.EsVisible)
            {
                cssClass = string.IsNullOrEmpty(cssClass) ? "hidden" : cssClass + " hidden";
            }

            htmlBuilder.AppendFormat(CultureInfo.InvariantCulture,
                "<tr class=\"{0}\"><td>{1}</td><td>{2}</td><td>{3}</td><td>{4:N2}</td><td>{5:N2}</td><td>{6:N2}</td></tr>",
                cssClass,
                System.Net.WebUtility.HtmlEncode(request.MostrarCodigoCuenta ? fila.Codigo : string.Empty),
                System.Net.WebUtility.HtmlEncode(fila.Nombre),
                fila.Nivel,
                fila.SaldoAnterior,
                fila.SaldoActual,
                fila.Diferencia);
        }

        htmlBuilder.Append("</tbody></table></body></html>");

        return new BalanceClasificadoComparativoPreviewResponseDto
        {
            Content = Encoding.UTF8.GetBytes(htmlBuilder.ToString()),
            ContentType = "text/html",
            FileName = "BalanceClasificadoComparativo.html"
        };
    }

    public async Task RegistrarImpresionAsync(BalanceClasificadoComparativoRegistroImpresionRequestDto request, CancellationToken cancellationToken = default)
    {
        var fechaRegistro = DateTime.UtcNow;
        var fechaRegistroInt = ConvertToLegacyDate(fechaRegistro);
        var fechaDesdeInt = ConvertToLegacyDate(request.FechaDesde);
        var fechaHastaInt = ConvertToLegacyDate(request.FechaHasta);

        var empresaAno = await context.Empresa
            .AsNoTracking()
            .Where(e => e.Id == request.EmpresaId)
            .Select(e => e.Ano)
            .FirstOrDefaultAsync(cancellationToken);

        short? anoFinal = empresaAno;
        if (empresaAno == 0)
        {
            anoFinal = (short)request.FechaHasta.Year;
        }

        var log = new LogImpreso
        {
            IdEmpresa = request.EmpresaId,
            Ano = anoFinal,
            Fecha = fechaRegistroInt,
            FDesde = fechaDesdeInt,
            FHasta = fechaHastaInt,
            idInforme = request.LibroOficialCodigo,
            IdUsuario = request.UsuarioId,
            Comentario = request.UsuarioNombre,
            Estado = request.PapelFoliado ? (byte)1 : (byte)0
        };

        await context.LogImpreso.AddAsync(log, cancellationToken);
        await context.SaveChangesAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<BalanceClasificadoComparativoRegistroImpresionDto>> ObtenerHistorialImpresionAsync(int empresaId, int libroOficialCodigo, CancellationToken cancellationToken = default)
    {
        var logs = await context.LogImpreso
            .AsNoTracking()
            .Where(l => l.IdEmpresa == empresaId && l.idInforme == libroOficialCodigo)
            .OrderByDescending(l => l.Fecha)
            .ThenByDescending(l => l.IdLog)
            .Take(50)
            .ToListAsync(cancellationToken);

        return logs
            .Select(l => new BalanceClasificadoComparativoRegistroImpresionDto
            {
                FechaImpresion = ConvertFromLegacyDate(l.Fecha) ?? DateTime.MinValue,
                Usuario = l.Comentario ?? string.Empty,
                FechaDesde = ConvertFromLegacyDate(l.FDesde) ?? DateTime.MinValue,
                FechaHasta = ConvertFromLegacyDate(l.FHasta) ?? DateTime.MinValue,
                PapelFoliado = l.Estado.HasValue && l.Estado.Value > 0,
                LibroOficialCodigo = l.idInforme ?? 0
            })
            .ToList();
    }

    public async Task<BalanceClasificadoComparativoOpcionesDto> ObtenerOpcionesAsync(int empresaId, CancellationToken cancellationToken = default)
    {
        var maxNivelByte = await context.Cuentas
            .AsNoTracking()
            .Where(c => c.IdEmpresa == empresaId && c.Nivel.HasValue)
            .Select(c => c.Nivel.Value)
            .DefaultIfEmpty((byte)5)
            .MaxAsync(cancellationToken);

        int maxNivel = Math.Clamp((int)maxNivelByte, 2, 5);
        var cantidadOpciones = Math.Max(0, maxNivel - 1);

        var niveles = cantidadOpciones == 0
            ? new List<SimpleComboItemDto>
            {
                new() { Value = 2, Text = "Nivel 2" },
                new() { Value = 3, Text = "Nivel 3" },
                new() { Value = 4, Text = "Nivel 4" },
                new() { Value = 5, Text = "Nivel 5" }
            }
            : Enumerable.Range(2, cantidadOpciones)
                .Select(n => new SimpleComboItemDto { Value = n, Text = $"Nivel {n}" })
                .ToList();

        var tiposAjuste = Enum.GetValues<BalanceClasificadoComparativoTipoAjuste>()
            .Select(e => new SimpleComboItemDto
            {
                Value = (int)e,
                Text = e switch
                {
                    BalanceClasificadoComparativoTipoAjuste.Financiero => "Financiero",
                    BalanceClasificadoComparativoTipoAjuste.Tributario => "Tributario",
                    BalanceClasificadoComparativoTipoAjuste.Ambos => "Ambos",
                    _ => e.ToString()
                }
            })
            .ToList();

        var areasNegocio = await context.AreaNegocio
            .AsNoTracking()
            .Where(a => a.IdEmpresa == empresaId && (a.Vigente == null || a.Vigente == true))
            .OrderBy(a => a.Descripcion)
            .Select(a => new SimpleComboItemDto
            {
                Value = a.IdAreaNegocio,
                Text = a.Descripcion ?? a.Codigo ?? a.IdAreaNegocio.ToString()
            })
            .ToListAsync(cancellationToken);

        var centrosCosto = await context.CentroCosto
            .AsNoTracking()
            .Where(c => c.IdEmpresa == empresaId && (c.Vigente == null || c.Vigente == true))
            .OrderBy(c => c.Descripcion)
            .Select(c => new SimpleComboItemDto
            {
                Value = c.IdCCosto,
                Text = c.Descripcion ?? c.Codigo ?? c.IdCCosto.ToString()
            })
            .ToListAsync(cancellationToken);

        var coloresNivel = (await ObtenerColoresPorNivelAsync(empresaId, cancellationToken))
            .ToDictionary(c => (int)c.Nivel, c => c.ColorHex);

        return new BalanceClasificadoComparativoOpcionesDto
        {
            Niveles = niveles,
            TiposAjuste = tiposAjuste,
            AreasNegocio = areasNegocio,
            CentrosCosto = centrosCosto,
            ColoresNivel = coloresNivel
        };
    }

    #region Helpers

    private static void ValidarRequestFechas(BalanceClasificadoComparativoRequestDto request)
    {
        if (request.FechaDesdeActual.Date > request.FechaHastaActual.Date)
        {
            throw new ArgumentException("La fecha de inicio del periodo actual no puede ser mayor a la fecha de término.");
        }

        if (request.FechaDesdeActual.Year != request.AnoActual || request.FechaHastaActual.Year != request.AnoActual)
        {
            throw new ArgumentException("Las fechas del periodo actual deben pertenecer al año indicado.");
        }

        if (request.UsarFechasPersonalizadasAnterior)
        {
            if (request.FechaDesdeAnterior is null || request.FechaHastaAnterior is null)
            {
                throw new ArgumentException("Cuando se usan fechas personalizadas para el periodo anterior se deben enviar ambas fechas.");
            }

            if (request.FechaDesdeAnterior.Value.Date > request.FechaHastaAnterior.Value.Date)
            {
                throw new ArgumentException("La fecha de inicio del periodo anterior no puede ser mayor a la fecha de término.");
            }
        }
    }

    private static FechasComparativas CalcularFechasComparativas(BalanceClasificadoComparativoRequestDto request)
    {
        short anoAnterior = (short)(request.AnoActual - 1);

        DateTime fechaDesdeAnterior;
        DateTime fechaHastaAnterior;

        if (request.UsarFechasPersonalizadasAnterior && request.FechaDesdeAnterior.HasValue && request.FechaHastaAnterior.HasValue)
        {
            fechaDesdeAnterior = request.FechaDesdeAnterior.Value.Date;
            fechaHastaAnterior = request.FechaHastaAnterior.Value.Date;
        }
        else
        {
            fechaDesdeAnterior = AjustarFechaACalendario(request.FechaDesdeActual, anoAnterior);
            fechaHastaAnterior = AjustarFechaACalendario(request.FechaHastaActual, anoAnterior);
        }

        return new FechasComparativas(
            anoAnterior,
            request.FechaDesdeActual.Date,
            request.FechaHastaActual.Date,
            fechaDesdeAnterior,
            fechaHastaAnterior,
            ConvertToLegacyDate(request.FechaDesdeActual),
            ConvertToLegacyDate(request.FechaHastaActual),
            ConvertToLegacyDate(fechaDesdeAnterior),
            ConvertToLegacyDate(fechaHastaAnterior));
    }

    private static DateTime AjustarFechaACalendario(DateTime fechaOriginal, int nuevoAno)
    {
        var day = Math.Min(fechaOriginal.Day, DateTime.DaysInMonth(nuevoAno, fechaOriginal.Month));
        return new DateTime(nuevoAno, fechaOriginal.Month, day);
    }

    private static TipoAjusteFiltro ConstruirFiltroTipoAjuste(BalanceClasificadoComparativoTipoAjuste tipo)
    {
        return tipo switch
        {
            BalanceClasificadoComparativoTipoAjuste.Financiero => new TipoAjusteFiltro(true, new HashSet<int> { 1, 3 }),
            BalanceClasificadoComparativoTipoAjuste.Tributario => new TipoAjusteFiltro(false, new HashSet<int> { 2, 3 }),
            BalanceClasificadoComparativoTipoAjuste.Ambos => new TipoAjusteFiltro(true, new HashSet<int> { 1, 2, 3 }),
            _ => new TipoAjusteFiltro(true, new HashSet<int> { 1, 2, 3 })
        };
    }

    private async Task<List<CuentaInfo>> ObtenerCuentasAsync(int empresaId, short ano, int nivelMaximo, CancellationToken cancellationToken)
    {
        var cuentas = await context.Cuentas
            .AsNoTracking()
            .Where(c => c.IdEmpresa == empresaId && c.Ano == ano && c.Nivel.HasValue && c.Nivel.Value <= nivelMaximo)
            .Select(c => new CuentaInfo
            {
                IdCuenta = c.idCuenta,
                IdPadre = c.idPadre,
                Codigo = c.Codigo ?? string.Empty,
                Nombre = c.Descripcion ?? c.Nombre ?? string.Empty,
                Nivel = c.Nivel.Value,
                Clasificacion = c.Clasificacion ?? 0
            })
            .ToListAsync(cancellationToken);

        var hijosPorCuenta = cuentas
            .Where(c => c.IdPadre.HasValue)
            .GroupBy(c => c.IdPadre!.Value)
            .ToDictionary(g => g.Key, g => g.Select(x => x.IdCuenta).ToList());

        foreach (var cuenta in cuentas)
        {
            if (hijosPorCuenta.TryGetValue(cuenta.IdCuenta, out var hijos))
            {
                cuenta.ChildIds.AddRange(hijos);
            }
        }

        return cuentas;
    }

    private async Task<List<MovimientoAggregate>> ObtenerMovimientosAsync(
        int empresaId,
        short ano,
        int fechaDesdeInt,
        int fechaHastaInt,
        int[] estadosPermitidos,
        TipoAjusteFiltro tipoAjusteFiltro,
        int? areaNegocioId,
        int? centroCostoId,
        CancellationToken cancellationToken)
    {
        var query =
            from movimiento in context.MovComprobante.AsNoTracking()
            join comprobante in context.Comprobante.AsNoTracking()
                on new { IdEmpresa = movimiento.IdEmpresa ?? 0, Ano = movimiento.Ano ?? 0, IdComp = movimiento.IdComp ?? 0 }
                equals new { IdEmpresa = comprobante.IdEmpresa ?? 0, Ano = comprobante.Ano ?? 0, IdComp = comprobante.IdComp }
            where movimiento.IdEmpresa == empresaId
                  && movimiento.Ano == ano
                  && movimiento.IdCuenta.HasValue
                  && movimiento.IdComp.HasValue
                  && comprobante.Fecha >= fechaDesdeInt
                  && comprobante.Fecha <= fechaHastaInt
                  && estadosPermitidos.Contains(comprobante.Estado ?? 0)
                  && ((comprobante.TipoAjuste == null && tipoAjusteFiltro.IncluirNulos) || (comprobante.TipoAjuste.HasValue && tipoAjusteFiltro.Valores.Contains(comprobante.TipoAjuste.Value)))
                  && (!areaNegocioId.HasValue || movimiento.idAreaNeg == areaNegocioId)
                  && (!centroCostoId.HasValue || movimiento.idCCosto == centroCostoId)
            group movimiento by movimiento.IdCuenta!.Value
            into agrupado
            select new MovimientoAggregate
            {
                IdCuenta = agrupado.Key,
                Debe = agrupado.Sum(x => x.Debe ?? 0d),
                Haber = agrupado.Sum(x => x.Haber ?? 0d)
            };

        return await query.ToListAsync(cancellationToken);
    }

    private static Dictionary<int, CuentaAggregate> ConstruirAgregados(IEnumerable<CuentaInfo> cuentas)
    {
        return cuentas.ToDictionary(
            c => c.IdCuenta,
            c => new CuentaAggregate(c.IdCuenta, c.Codigo, c.Nombre, c.Nivel, c.Clasificacion, c.IdPadre, c.ChildIds));
    }

    private static void AplicarMovimientos(Dictionary<int, CuentaAggregate> agregados, IEnumerable<MovimientoAggregate> movimientosActual, IEnumerable<MovimientoAggregate> movimientosAnterior)
    {
        foreach (var mov in movimientosActual)
        {
            if (agregados.TryGetValue(mov.IdCuenta, out var cuenta))
            {
                cuenta.DebeActual += mov.Debe;
                cuenta.HaberActual += mov.Haber;
            }
        }

        foreach (var mov in movimientosAnterior)
        {
            if (agregados.TryGetValue(mov.IdCuenta, out var cuenta))
            {
                cuenta.DebeAnterior += mov.Debe;
                cuenta.HaberAnterior += mov.Haber;
            }
        }
    }

    private static void PropagarSaldos(Dictionary<int, CuentaAggregate> agregados)
    {
        var cuentasOrdenadas = agregados.Values
            .OrderByDescending(c => c.Nivel)
            .ToList();

        foreach (var cuenta in cuentasOrdenadas)
        {
            if (cuenta.IdPadre.HasValue && agregados.TryGetValue(cuenta.IdPadre.Value, out var padre))
            {
                padre.DebeActual += cuenta.DebeActual;
                padre.HaberActual += cuenta.HaberActual;
                padre.DebeAnterior += cuenta.DebeAnterior;
                padre.HaberAnterior += cuenta.HaberAnterior;
            }
        }
    }

    private static List<BalanceClasificadoComparativoRowDto> ConstruirFilasOrdenadas(Dictionary<int, CuentaAggregate> agregados, BalanceClasificadoComparativoRequestDto request)
    {
        var filas = new List<BalanceClasificadoComparativoRowDto>();

        foreach (var cuenta in agregados.Values.OrderBy(c => c.Codigo, StringComparer.OrdinalIgnoreCase))
        {
            var saldoActual = CalcularSaldoPorClasificacion(cuenta.Clasificacion, cuenta.DebeActual, cuenta.HaberActual);
            var saldoAnterior = CalcularSaldoPorClasificacion(cuenta.Clasificacion, cuenta.DebeAnterior, cuenta.HaberAnterior);

            var esVisible = saldoActual != 0d || saldoAnterior != 0d || cuenta.Nivel == 1;
            if (!request.MostrarSubTotales && cuenta.Clasificacion == ClasctaResultado && cuenta.Nivel == 1)
            {
                esVisible = false;
            }

            filas.Add(new BalanceClasificadoComparativoRowDto
            {
                IdCuenta = cuenta.IdCuenta,
                Codigo = cuenta.Codigo,
                Nombre = cuenta.Nombre,
                Nivel = cuenta.Nivel,
                Clasificacion = cuenta.Clasificacion,
                DebeActual = cuenta.DebeActual,
                HaberActual = cuenta.HaberActual,
                DebeAnterior = cuenta.DebeAnterior,
                HaberAnterior = cuenta.HaberAnterior,
                SaldoActual = saldoActual,
                SaldoAnterior = saldoAnterior,
                EsTotal = cuenta.Nivel == 1,
                EsResultadoEjercicio = false,
                EsVisible = esVisible,
                EsFilaPadre = cuenta.ChildIds.Count > 0,
                CodigoPadre = cuenta.IdPadre.HasValue && agregados.TryGetValue(cuenta.IdPadre.Value, out var padre)
                    ? padre.Codigo
                    : null
            });
        }

        return filas;
    }

    private static TotalesCalculados CalcularTotales(IEnumerable<BalanceClasificadoComparativoRowDto> filas)
    {
        var filasPadre = filas.Where(f => f.EsTotal).ToList();

        var totalActivoActual = filasPadre.Where(f => f.Clasificacion == ClasctaActivo).Sum(f => f.SaldoActual);
        var totalPasivoActual = filasPadre.Where(f => f.Clasificacion == ClasctaPasivo).Sum(f => f.SaldoActual);
        var totalResultadoActual = filasPadre.Where(f => f.Clasificacion == ClasctaResultado).Sum(f => f.SaldoActual);

        var totalActivoAnterior = filasPadre.Where(f => f.Clasificacion == ClasctaActivo).Sum(f => f.SaldoAnterior);
        var totalPasivoAnterior = filasPadre.Where(f => f.Clasificacion == ClasctaPasivo).Sum(f => f.SaldoAnterior);
        var totalResultadoAnterior = filasPadre.Where(f => f.Clasificacion == ClasctaResultado).Sum(f => f.SaldoAnterior);

        var totales = new BalanceClasificadoComparativoTotalesDto
        {
            TotalActivo = totalActivoActual,
            TotalPasivo = totalPasivoActual,
            TotalResultado = totalResultadoActual,
            TotalActual = totalActivoActual,
            TotalAnterior = totalActivoAnterior,
            ResultadoEjercicioActual = 0,
            ResultadoEjercicioAnterior = 0
        };

        return new TotalesCalculados(totales, totalActivoAnterior, totalPasivoAnterior, totalResultadoAnterior);
    }

    private async Task<(BalanceClasificadoComparativoRowDto Fila, double ResultadoActual, double ResultadoAnterior)?> ObtenerFilaResultadoEjercicioAsync(
        TotalesCalculados totales,
        BalanceClasificadoComparativoRequestDto request,
        IEnumerable<CuentaInfo> cuentas,
        CancellationToken cancellationToken)
    {
        var resultadoActual = totales.Totales.TotalActivo - (totales.Totales.TotalPasivo + totales.Totales.TotalResultado);
        var resultadoAnterior = totales.TotalActivoAnterior - (totales.TotalPasivoAnterior + totales.TotalResultadoAnterior);

        if (Math.Round(resultadoActual, 2) == 0d && Math.Round(resultadoAnterior, 2) == 0d)
        {
            return null;
        }

        var cuentaResultadoId = await ObtenerIdCuentaBasicaAsync(request.EmpresaId, request.AnoActual, "CTARESEJE", cancellationToken);
        CuentaInfo? cuentaResultado = null;
        if (cuentaResultadoId.HasValue)
        {
            cuentaResultado = cuentas.FirstOrDefault(c => c.IdCuenta == cuentaResultadoId.Value);
        }

        var fila = new BalanceClasificadoComparativoRowDto
        {
            IdCuenta = cuentaResultado?.IdCuenta,
            Codigo = cuentaResultado?.Codigo ?? string.Empty,
            Nombre = cuentaResultado?.Nombre ?? "Resultado del Ejercicio",
            Nivel = cuentaResultado?.Nivel ?? 1,
            Clasificacion = ClasctaPasivo,
            DebeActual = 0,
            HaberActual = 0,
            DebeAnterior = 0,
            HaberAnterior = 0,
            SaldoActual = resultadoActual,
            SaldoAnterior = resultadoAnterior,
            EsTotal = true,
            EsResultadoEjercicio = true,
            EsVisible = true,
            EsFilaPadre = false
        };

        return (fila, resultadoActual, resultadoAnterior);
    }

    private BalanceClasificadoComparativoFiltroAplicadoDto ConstruirFiltrosAplicados(BalanceClasificadoComparativoRequestDto request, FechasComparativas fechas)
    {
        return new BalanceClasificadoComparativoFiltroAplicadoDto
        {
            FechaDesdeActual = fechas.FechaDesdeActual,
            FechaHastaActual = fechas.FechaHastaActual,
            FechaDesdeAnterior = fechas.FechaDesdeAnterior,
            FechaHastaAnterior = fechas.FechaHastaAnterior,
            Nivel = request.Nivel,
            TipoAjuste = request.TipoAjuste,
            SoloLibroOficial = request.SoloLibroOficial,
            MostrarSubTotales = request.MostrarSubTotales,
            MostrarCodigoCuenta = request.MostrarCodigoCuenta,
            Modo = request.Modo
        };
    }

    private async Task<List<BalanceClasificadoComparativoNivelColorDto>> ObtenerColoresPorNivelAsync(int empresaId, CancellationToken cancellationToken)
    {
        {
            var colores = await context.Colores
                .AsNoTracking()
                .Where(c => c.IdEmpresa == empresaId)
                .Select(c => new { c.Nivel, c.Color })
                .ToListAsync(cancellationToken);

            return colores
                .Select(c => new BalanceClasificadoComparativoNivelColorDto
                {
                    Nivel = c.Nivel,
                    ColorHex = ConvertirColorWin32AHex(c.Color)
                })
                .ToList();
        }
    }

    private async Task<int?> ObtenerIdCuentaBasicaAsync(int empresaId, short ano, string tipo, CancellationToken cancellationToken)
    {
        var valor = await context.ParamEmpresa
            .AsNoTracking()
            .Where(p => p.IdEmpresa == empresaId && p.Ano == ano && p.Tipo == tipo)
            .Select(p => p.Valor)
            .FirstOrDefaultAsync(cancellationToken);

        if (valor is not null && int.TryParse(valor, NumberStyles.Integer, CultureInfo.InvariantCulture, out var idCuenta))
        {
            return idCuenta;
        }

        return null;
    }

    private static double CalcularSaldoPorClasificacion(byte? clasificacion, double debe, double haber)
    {
        return clasificacion switch
        {
            ClasctaActivo => debe - haber,
            ClasctaPasivo or ClasctaResultado or ClasctaOrden => haber - debe,
            _ => debe - haber
        };
    }

    private static int ConvertToLegacyDate(DateTime date)
    {
        return (int)((date.Date - new DateTime(1900, 1, 1)).TotalDays + 2);
    }

    private static DateTime? ConvertFromLegacyDate(int? legacy)
    {
        if (!legacy.HasValue || legacy.Value <= 0)
        {
            return null;
        }

        return new DateTime(1900, 1, 1).AddDays(legacy.Value - 2);
    }

    private static string ConvertirColorWin32AHex(int? color)
    {
        if (!color.HasValue)
        {
            return "#000000";
        }

        var win32Color = ColorTranslator.FromWin32(color.Value);
        return $"#{win32Color.R:X2}{win32Color.G:X2}{win32Color.B:X2}";
    }

    private static string CsvEscape(string value)
    {
        if (string.IsNullOrEmpty(value))
        {
            return string.Empty;
        }

        if (value.Contains('"') || value.Contains(';'))
        {
            return $"\"{value.Replace("\"", "\"\"")}\"";
        }

        return value;
    }

    private sealed record MovimientoAggregate
    {
        public int IdCuenta { get; init; }
        public double Debe { get; init; }
        public double Haber { get; init; }
    }

    private sealed class CuentaInfo
    {
        public int IdCuenta { get; init; }
        public int? IdPadre { get; init; }
        public string Codigo { get; init; } = string.Empty;
        public string Nombre { get; init; } = string.Empty;
        public byte Nivel { get; init; }
        public byte Clasificacion { get; init; }
        public List<int> ChildIds { get; } = new();
    }

    private sealed class CuentaAggregate(int idCuenta, string codigo, string nombre, byte nivel, byte clasificacion, int? idPadre, IReadOnlyCollection<int> childIds)
    {
        public int IdCuenta { get; } = idCuenta;
        public string Codigo { get; } = codigo;
        public string Nombre { get; } = nombre;
        public byte Nivel { get; } = nivel;
        public byte Clasificacion { get; } = clasificacion;
        public int? IdPadre { get; } = idPadre;
        public List<int> ChildIds { get; } = childIds.ToList();
        public double DebeActual { get; set; }
        public double HaberActual { get; set; }
        public double DebeAnterior { get; set; }
        public double HaberAnterior { get; set; }
    }

    private sealed record TipoAjusteFiltro(bool IncluirNulos, HashSet<int> Valores);

    private sealed record FechasComparativas(
        short AnoAnterior,
        DateTime FechaDesdeActual,
        DateTime FechaHastaActual,
        DateTime FechaDesdeAnterior,
        DateTime FechaHastaAnterior,
        int FechaDesdeActualInt,
        int FechaHastaActualInt,
        int FechaDesdeAnteriorInt,
        int FechaHastaAnteriorInt);

    private sealed record TotalesCalculados(
        BalanceClasificadoComparativoTotalesDto Totales,
        double TotalActivoAnterior,
        double TotalPasivoAnterior,
        double TotalResultadoAnterior);

    #endregion
}
