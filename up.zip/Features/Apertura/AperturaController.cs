﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.Apertura;

public class AperturaController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<AperturaController> logger) : Controller
{
    /// <summary>
    /// Main view for apertura (opening entry generation)
    /// </summary>
    /// <returns>Apertura view</returns>
    public IActionResult Index()
    {
        logger.LogInformation("Loading Apertura index for empresaId: {EmpresaId}, ano: {Ano}",
            SessionHelper.EmpresaId, SessionHelper.Ano);


        ViewData["Title"] = $"Apertura - año {SessionHelper.Ano}";

        // Create empty form model for Tag Helpers
        var model = new AperturaFormDto
        {
            NumCompAper = 1,
            IdCuentaResul = 0,
            IdCuentaCredIVA = 0,
            RemIVAUTM = 0
        };

        return View(model);
    }

    /// <summary>
    /// Proxy method: Get initial data for apertura form
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Init(int empresaId, short ano)
    {
        logger.LogInformation("MVC Proxy: Init - empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        var client = httpClientFactory.CreateClient("ApiClient");

        var url = linkGenerator.GetPathByAction(
            action: nameof(AperturaApiController.Init),
            controller: nameof(AperturaApiController).Replace("Controller", ""),
            values: new { empresaId, ano }
        );
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Proxy method: Get accounts by type (patrimonio or activo)
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetAccounts(int empresaId, short ano, string type)
    {
        logger.LogInformation("MVC Proxy: GetAccounts - empresaId: {EmpresaId}, ano: {Ano}, type: {Type}",
            empresaId, ano, type);

        var client = httpClientFactory.CreateClient("ApiClient");

        var url = linkGenerator.GetPathByAction(
            action: nameof(AperturaApiController.GetAccounts),
            controller: nameof(AperturaApiController).Replace("Controller", ""),
            values: new { empresaId, ano, type }
        );
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Proxy method: Execute apertura (opening entry)
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Execute([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: Execute apertura");

        var client = httpClientFactory.CreateClient("ApiClient");

        var url = linkGenerator.GetPathByAction(
            action: nameof(AperturaApiController.Execute),
            controller: nameof(AperturaApiController).Replace("Controller", "")
        );
        var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }
}