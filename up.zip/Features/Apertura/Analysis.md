# Legacy Analysis: Apertura (Comprobante de Apertura)

## 📄 VB6 Form Information
**File:** `vb6/Contabilidad70/HyperContabilidad/FrmApertura.frm` (614 lines)
**Form Name:** FrmApertura
**Caption:** "Generar Comprobante de Apertura Año"
**Purpose:** Generate the opening entry voucher for a new accounting period, carrying forward balances from the previous year, including net profit and IVA credit remainder.

---

## 🎯 Business Overview

### What is "Apertura" (Opening Entry)?
The **Apertura** process creates the **opening entry voucher** for a new fiscal year. This is the OPPOSITE of **Cierre Anual** (annual close). It:
1. Creates a special voucher (Type = TC_APERTURA = "A") with opening balances
2. Transfers the net profit/loss from previous year to a retained earnings account
3. Carries forward IVA credit remainder from previous year (in UTM units)
4. Sets up the opening balance for the new accounting period

### Critical Business Rules
- **First voucher:** Opening entry is typically voucher #1 of the new year
- **Replaces existing:** If opening entry already exists, it can be replaced
- **Two accounts required:**
  1. **Cuenta de Resultado** (Result Account): Where net profit/loss is posted (typically "Utilidad Neta Retenida")
  2. **Cuenta de Crédito IVA** (IVA Credit Account): Where IVA credit carryforward is posted
- **IVA carryforward:** If previous year exists, IVA remainder comes from `EmpresasAno.RemIVAUTM` of previous year
- **Manual input:** If no previous year, user can manually enter IVA remainder

---

## 🎮 Controls Identified

### Textboxes

| Control Name | Caption/Label | Type | Validation | Purpose |
|-------------|---------------|------|------------|---------|
| **Tx_CompAper** | "Nº de comprobante de apertura" | Numeric | Must be > 0 | Opening voucher number (usually 1) |
| **Tx_Cuenta** | "Cuenta de resultado" | Text (locked) | Must not be empty | Display selected result account description |
| **Tx_CtaCredIVA** | "Cuenta de Crédito IVA" | Text (locked) | Must not be empty | Display selected IVA credit account description |
| **Tx_RemIVAUTMAnoAnt** | "Remanente IVA año anterior UTM" | Decimal (2 decimals) | Numeric, >= 0 | IVA credit remainder from previous year in UTM units |

### Buttons

| Button Name | Caption | Icon | Action | Mapeo .NET |
|------------|---------|------|--------|------------|
| **Bt_AperturaAno** | "Generar" | None | Generate opening entry voucher | `ExecuteAperturaAsync()` |
| **Bt_Cancel** | "Cancelar" | None | Close form without saving | Close dialog |
| **Bt_Cuentas** | (Icon button) | 📋 Plan icon | Opens plan de cuentas selector for result account | Account picker modal |
| **Bt_CtaCredIVA** | (Icon button) | 📋 Plan icon | Opens plan de cuentas selector for IVA credit account | Account picker modal |

### Labels

| Label Name | Caption | Purpose |
|-----------|---------|---------|
| **Lb_Reemp** | "Se reemplazará Comprobante de Apertura ya existente." | Warning message (visible only if opening entry already exists) |

### Progress Bar

| Control | Purpose |
|---------|---------|
| **ProgressBar** | Shows progress during opening entry generation (VB6: 0-100) |

---

## 🔧 Functions and Procedures

### Public Functions (Entry Points)

#### 1. `FSelect()`
```vb
Public Function FSelect(ByVal IdEmpresa As Long, ByVal Ano As Integer,
                        NumCompAper As Long, IdCompAper As Long,
                        IdCuentaResul As Long, IdCompAperTrib As Long) As Integer
```
**Purpose:** Main entry point - Shows modal form and returns selected values
**Parameters (ByVal):**
- `IdEmpresa` - Company ID
- `Ano` - Year for opening entry

**Parameters (ByRef - Output):**
- `NumCompAper` - Opening voucher number (e.g., 1)
- `IdCompAper` - Opening voucher ID from Comprobante table
- `IdCuentaResul` - Result account ID
- `IdCompAperTrib` - Tributary opening voucher ID (if applicable)

**Returns:** `vbOK` or `vbCancel`

**Mapeo .NET:**
```csharp
Task<AperturaResultDto> GetAperturaInfoAsync(int empresaId, int ano)
// Returns DTO with all values
```

---

#### 2. `FSelectDuplicados()` (Line 230)
```vb
Public Function FSelectDuplicados(ByVal IdEmpresa As Long, ByVal Ano As Integer,
                                  NumCompAper As Long, IdCompAper As Long,
                                  IdCuentaResul As Long, IdCompAperTrib As Long) As Integer
```
**Purpose:** Same as FSelect but runs automatically without showing the form (for batch processing)
**Added:** Issue #14690904
**Difference:** Calls `Bt_AperturaAno_Click` directly without showing dialog

**Mapeo .NET:**
```csharp
Task<AperturaResultDto> ExecuteAperturaAsync(AperturaRequestDto request)
```

---

### Private Procedures

#### 3. `LoadAll()` (Line 367)
```vb
Private Sub LoadAll()
```
**Purpose:** Loads initial form data on Form_Load
**Steps:**
1. **Check existing opening entry** (lines 382-398)
   - Query: `SELECT IdCompAper, NCompAper, IdCompAperTrib, NCompAperTrib, RemIVAUTMAnoAnt FROM EmpresasAno`
   - If opening entry exists: Load existing values, show "Se reemplazará" warning
   - If not exists: Default to voucher number = 1

2. **Load saved accounts from ParamEmpresa** (lines 446-467)
   - Query: `SELECT Tipo, Valor FROM ParamEmpresa WHERE Tipo IN ('CTARESULT', 'CTACREDIVA')`
   - Types: `CTARESULT` = Result account ID, `CTACREDIVA` = IVA credit account ID

3. **Load default result account** (lines 469-497)
   - If no saved account: Try to find account with code = "2031101" and description like "*Utilidad Neta Retenida*"
   - If saved account: Load description from `Cuentas` table

4. **Load default IVA credit account** (lines 499-528)
   - If no saved account: Try to find account with code = "1010999" and description like "*Otros Impuestos por Recuperar*"
   - If saved account: Load description from `Cuentas` table

5. **Load IVA remainder** (lines 531-554)
   - **If previous year exists** (`gEmpresa.TieneAnoAnt`):
     - Query: `SELECT RemIVAUTM FROM EmpresasAno WHERE Ano = [CurrentYear - 1]`
     - Load RemIVAUTM from PREVIOUS year's close
     - Lock textbox (read-only)
   - **If no previous year:**
     - Load `RemIVAUTMAnoAnt` from current year's EmpresasAno record (if apertura was done before)
     - Allow manual input

**Mapeo .NET:**
```csharp
Task<AperturaInitDataDto> GetAperturaInitDataAsync(int empresaId, int ano)
// Returns: existing opening entry, default accounts, IVA remainder
```

---

#### 4. `valida()` (Line 340)
```vb
Private Function valida() As Boolean
```
**Purpose:** Validates form before generating opening entry
**Validations:**
1. `Tx_CompAper > 0` - Must have voucher number
2. `Tx_Cuenta <> ""` - Must select result account
3. `Tx_CtaCredIVA <> ""` - Must select IVA credit account

**Mapeo .NET:**
```csharp
ValidationResult ValidateAperturaRequest(AperturaRequestDto request)
```

---

#### 5. `SaveCuentas()` (Line 568)
```vb
Public Sub SaveCuentas()
```
**Purpose:** Saves selected accounts to ParamEmpresa and IVA remainder to EmpresasAno
**Actions:**
1. **Save result account** (lines 572-580)
   - If `lParamCtaResult = True`: UPDATE ParamEmpresa WHERE Tipo = 'CTARESULT'
   - Else: INSERT INTO ParamEmpresa (Tipo, Valor) VALUES ('CTARESULT', lidCuentaResul)

2. **Save IVA credit account** (lines 582-590)
   - If `lParamCtaCredIVA = True`: UPDATE ParamEmpresa WHERE Tipo = 'CTACREDIVA'
   - Else: INSERT INTO ParamEmpresa (Tipo, Valor) VALUES ('CTACREDIVA', lidCuentaCredIVA)

3. **Update global variable** (line 591)
   - `gCtasBas.IdCtaCredIVA = lidCuentaCredIVA`

4. **Save IVA remainder** (lines 593-597)
   - UPDATE EmpresasAno SET RemIVAUTMAnoAnt = [value] WHERE IdEmpresa AND Ano

**Mapeo .NET:**
```csharp
Task SaveAperturaConfigurationAsync(AperturaConfigDto config)
```

---

#### 6. `Bt_AperturaAno_Click()` (Line 262)
```vb
Private Sub Bt_AperturaAno_Click()
```
**Purpose:** Main action - Generate opening entry voucher
**Steps:**
1. Call `valida()` - Validate form
2. Store `lNumCompAper = Tx_CompAper`
3. Call `SaveCuentas()` - Save configuration
4. Update progress bar to 100%
5. Set `lRc = vbOK` and unload form

⚠️ **CRITICAL NOTE:** The actual voucher generation logic is NOT in this form!
The form only collects parameters. The actual voucher creation happens OUTSIDE this form, likely in the calling code that uses the returned values from `FSelect()`.

**Mapeo .NET:**
```csharp
// The calling code must create the actual voucher entry
// This form only provides: NumCompAper, IdCuentaResul, IdCuentaCredIVA, RemIVAUTM
```

---

## 💾 Data Access Patterns

### Tables Used

| Table | Purpose | Operations |
|-------|---------|-----------|
| **EmpresasAno** | Stores opening entry references and IVA remainder | SELECT, UPDATE |
| **ParamEmpresa** | Stores configured account IDs (CTARESULT, CTACREDIVA) | SELECT, INSERT, UPDATE |
| **Cuentas** | Chart of accounts - to load account descriptions | SELECT |
| **Comprobante** | Voucher header (opening entry will be created here) | Referenced (not directly manipulated in this form) |

---

### Key Queries

#### Query 1: Load Existing Opening Entry
```sql
-- VB6 (lines 382-384)
SELECT IdCompAper, NCompAper, IdCompAperTrib, NCompAperTrib, RemIVAUTMAnoAnt
FROM EmpresasAno
WHERE idEmpresa = @IdEmpresa AND Ano = @Ano
```

**EF Core Mapping:**
```csharp
var empresaAno = await _context.EmpresasAno
    .Where(ea => ea.IdEmpresa == empresaId && ea.Ano == ano)
    .Select(ea => new {
        ea.IdCompAper,
        ea.NCompAper,
        ea.IdCompAperTrib,
        ea.NCompAperTrib,
        ea.RemIVAUTMAnoAnt
    })
    .FirstOrDefaultAsync();
```

---

#### Query 2: Load IVA Remainder from Previous Year
```sql
-- VB6 (lines 535-537)
SELECT RemIVAUTM
FROM EmpresasAno
WHERE idEmpresa = @IdEmpresa AND Ano = @AnoPrevio
```

**EF Core Mapping:**
```csharp
var remIVAUTM = await _context.EmpresasAno
    .Where(ea => ea.IdEmpresa == empresaId && ea.Ano == (ano - 1))
    .Select(ea => ea.RemIVAUTM)
    .FirstOrDefaultAsync();
```

---

#### Query 3: Load Configured Accounts
```sql
-- VB6 (lines 446-447)
SELECT Tipo, Valor
FROM ParamEmpresa
WHERE Tipo IN ('CTARESULT', 'CTACREDIVA')
  AND IdEmpresa = @IdEmpresa AND Ano = @Ano
```

**EF Core Mapping:**
```csharp
var parameters = await _context.ParamEmpresa
    .Where(p => p.IdEmpresa == empresaId &&
                p.Ano == ano &&
                (p.Tipo == "CTARESULT" || p.Tipo == "CTACREDIVA"))
    .ToListAsync();

int? idCtaResult = parameters.FirstOrDefault(p => p.Tipo == "CTARESULT")?.Valor;
int? idCtaCredIVA = parameters.FirstOrDefault(p => p.Tipo == "CTACREDIVA")?.Valor;
```

---

#### Query 4: Find Default Result Account
```sql
-- VB6 (lines 472-473)
SELECT IdCuenta, Descripcion
FROM Cuentas
WHERE Codigo = '2031101'
  AND Descripcion LIKE '*Utilidad Neta Retenida*'
  AND IdEmpresa = @IdEmpresa AND Ano = @Ano
```

**EF Core Mapping:**
```csharp
var defaultResultAccount = await _context.Cuentas
    .Where(c => c.IdEmpresa == empresaId &&
                c.Ano == ano &&
                c.Codigo == "2031101" &&
                c.Descripcion.Contains("Utilidad Neta Retenida"))
    .Select(c => new { c.IdCuenta, c.Descripcion })
    .FirstOrDefaultAsync();
```

---

#### Query 5: Find Default IVA Credit Account
```sql
-- VB6 (lines 502-503)
SELECT IdCuenta, Descripcion
FROM Cuentas
WHERE Codigo = '1010999'
  AND Descripcion LIKE '*Otros Impuestos por Recuperar*'
  AND IdEmpresa = @IdEmpresa AND Ano = @Ano
```

**EF Core Mapping:**
```csharp
var defaultIVAAccount = await _context.Cuentas
    .Where(c => c.IdEmpresa == empresaId &&
                c.Ano == ano &&
                c.Codigo == "1010999" &&
                c.Descripcion.Contains("Otros Impuestos por Recuperar"))
    .Select(c => new { c.IdCuenta, c.Descripcion })
    .FirstOrDefaultAsync();
```

---

#### Query 6: Update IVA Remainder in EmpresasAno
```sql
-- VB6 (lines 594-595)
UPDATE EmpresasAno
SET RemIVAUTMAnoAnt = @RemIVAUTM
WHERE idEmpresa = @IdEmpresa AND Ano = @Ano
```

**EF Core Mapping:**
```csharp
var empresaAno = await _context.EmpresasAno
    .FirstOrDefaultAsync(ea => ea.IdEmpresa == empresaId && ea.Ano == ano);

if (empresaAno != null)
{
    empresaAno.RemIVAUTMAnoAnt = remIVAUTM;
    await _context.SaveChangesAsync();
}
```

---

#### Query 7: Save/Update Result Account in ParamEmpresa
```sql
-- VB6 (lines 573-576)
-- IF EXISTS:
UPDATE ParamEmpresa
SET Valor = @IdCuentaResul
WHERE Tipo = 'CTARESULT'
  AND IdEmpresa = @IdEmpresa AND Ano = @Ano

-- IF NOT EXISTS:
INSERT INTO ParamEmpresa (Tipo, Valor, IdEmpresa, Ano)
VALUES ('CTARESULT', @IdCuentaResul, @IdEmpresa, @Ano)
```

**EF Core Mapping:**
```csharp
var param = await _context.ParamEmpresa
    .FirstOrDefaultAsync(p => p.IdEmpresa == empresaId &&
                             p.Ano == ano &&
                             p.Tipo == "CTARESULT");

if (param != null)
{
    param.Valor = idCuentaResul;
}
else
{
    _context.ParamEmpresa.Add(new ParamEmpresa
    {
        Tipo = "CTARESULT",
        Valor = idCuentaResul,
        IdEmpresa = empresaId,
        Ano = ano
    });
}

await _context.SaveChangesAsync();
```

---

#### Query 8: Save/Update IVA Credit Account in ParamEmpresa
```sql
-- VB6 (lines 583-586)
-- IF EXISTS:
UPDATE ParamEmpresa
SET Valor = @IdCuentaCredIVA
WHERE Tipo = 'CTACREDIVA'
  AND IdEmpresa = @IdEmpresa AND Ano = @Ano

-- IF NOT EXISTS:
INSERT INTO ParamEmpresa (Tipo, Valor, IdEmpresa, Ano)
VALUES ('CTACREDIVA', @IdCuentaCredIVA, @IdEmpresa, @Ano)
```

**EF Core Mapping:**
```csharp
var param = await _context.ParamEmpresa
    .FirstOrDefaultAsync(p => p.IdEmpresa == empresaId &&
                             p.Ano == ano &&
                             p.Tipo == "CTACREDIVA");

if (param != null)
{
    param.Valor = idCuentaCredIVA;
}
else
{
    _context.ParamEmpresa.Add(new ParamEmpresa
    {
        Tipo = "CTACREDIVA",
        Valor = idCuentaCredIVA,
        IdEmpresa = empresaId,
        Ano = ano
    });
}

await _context.SaveChangesAsync();
```

---

## ✅ Validations

### Form-Level Validations (valida() function)

| Field | Validation | Error Message | Code Line |
|-------|-----------|---------------|-----------|
| **Tx_CompAper** | Must be > 0 | "Debe ingresar número de comprobante de apertura para el año {año}" | 343-346 |
| **Tx_Cuenta** | Must not be empty (Trim <> "") | "Debe seleccionar una cuenta de patrimonio para el comprobante de apertura año {año}" | 349-353 |
| **Tx_CtaCredIVA** | Must not be empty (Trim <> "") | "Debe seleccionar una cuenta de arrastre de Crédito IVA desde el año anterior." | 356-360 |

### Input Validations

| Field | Validation Method | Purpose |
|-------|------------------|---------|
| **Tx_CompAper** | `KeyNum()` (line 558) | Only numeric input |
| **Tx_RemIVAUTMAnoAnt** | `KeyDecPos()` (line 606) | Decimal with 2 decimals, positive only |

---

## 🎯 Service Methods Determined

Based on VB6 analysis, the .NET service must provide:

### 1. Initialization and Configuration

```csharp
/// <summary>
/// Gets initial data for opening entry form
/// Loads existing opening entry, default accounts, IVA remainder
/// </summary>
Task<AperturaInitDataDto> GetAperturaInitDataAsync(int empresaId, int ano);

/// <summary>
/// Gets list of accounts for account picker
/// Filters by company, year, and account type (patrimonio or activo)
/// </summary>
Task<IEnumerable<AccountDto>> GetAccountsForSelectionAsync(int empresaId, int ano, string accountType);

/// <summary>
/// Gets IVA remainder from previous year's close
/// Returns 0 if no previous year exists
/// </summary>
Task<double> GetIvaRemainderFromPreviousYearAsync(int empresaId, int ano);
```

---

### 2. Validation

```csharp
/// <summary>
/// Validates opening entry request before generation
/// - Voucher number must be > 0
/// - Result account must be selected
/// - IVA credit account must be selected
/// </summary>
ValidationResult ValidateAperturaRequest(AperturaRequestDto request);

/// <summary>
/// Checks if opening entry already exists for the year
/// </summary>
Task<bool> OpeningEntryExistsAsync(int empresaId, int ano);
```

---

### 3. Configuration Management

```csharp
/// <summary>
/// Saves selected accounts to ParamEmpresa
/// Upserts CTARESULT and CTACREDIVA parameters
/// </summary>
Task SaveAperturaAccountsAsync(int empresaId, int ano, int idCuentaResul, int idCuentaCredIVA);

/// <summary>
/// Saves IVA remainder to EmpresasAno.RemIVAUTMAnoAnt
/// Only for companies without previous year (manual input)
/// </summary>
Task SaveIvaRemainderAsync(int empresaId, int ano, double remIVAUTM);
```

---

### 4. Main Execution

```csharp
/// <summary>
/// Executes opening entry generation
/// This method only saves configuration and prepares data.
/// The actual voucher creation happens in a separate process (likely in calling code)
/// </summary>
Task<AperturaResultDto> ExecuteAperturaAsync(AperturaRequestDto request);
```

⚠️ **IMPORTANT NOTE:**
The VB6 form does NOT create the actual Comprobante (voucher) record. It only:
1. Validates inputs
2. Saves configuration (accounts, IVA remainder)
3. Returns values to calling code

The calling code is responsible for:
- Creating Comprobante record with Type = TC_APERTURA ("A")
- Creating MovComprobante records (debit/credit entries)
- Updating EmpresasAno with IdCompAper, NCompAper

**For .NET migration:**
We should either:
1. **Keep same pattern:** Return configuration, let caller create voucher
2. **Or unify:** Include voucher creation in `ExecuteAperturaAsync()` for better encapsulation

**Recommendation:** Unify into one atomic operation for better transaction control.

---

## 🔗 External Dependencies

### VB6 Constants Used

| Constant | Value (assumed) | Purpose |
|----------|-----------------|---------|
| **TC_APERTURA** | "A" | Voucher type for opening entry |
| **TAJUSTE_FINANCIERO** | 1 (assumed) | Financial adjustment type |
| **COD_CTARESULT** | "2031101" | Default code for result account |
| **DESC_CTARESULT** | "Utilidad Neta Retenida" | Default description for result account |
| **COD_CTACREDIVA** | "1010999" | Default code for IVA credit account |
| **DESC_CTACREDIVA** | "Otros Impuestos por Recuperar" | Default description for IVA credit account |
| **DBLFMT2** | "#,##0.00" (assumed) | Double format with 2 decimals |

---

### External Functions Called

| Function | Purpose | Mapeo .NET |
|----------|---------|-----------|
| `OpenRs()` | Open ADO recordset | `_context.[Table].Where().ToListAsync()` |
| `CloseRs()` | Close recordset | Dispose() (handled by EF Core) |
| `ExecSQL()` | Execute SQL command | `_context.SaveChangesAsync()` |
| `vFld()` | Safe field value extraction (handles NULL) | `?? 0` or `?? ""` |
| `vFmt()` | Format numeric value | `decimal.TryParse()` |
| `FCase()` | Format case (title case) | `CultureInfo.CurrentCulture.TextInfo.ToTitleCase()` |
| `KeyNum()` | Validate numeric key press | JavaScript: `/[0-9]/` |
| `KeyDecPos()` | Validate decimal positive key press | JavaScript: `/[0-9.]/` |
| `SetTxRO()` | Set textbox read-only | HTML: `readonly` attribute |
| `MsgBox1()` | Show message box | SweetAlert2: `Swal.fire()` |
| `EnableForm()` | Enable/disable form based on permissions | Conditional rendering |
| `ChkPriv()` | Check user privilege | Role-based authorization |
| `gEmpresa` | Global company object | Session/context variable |
| `gCtasBas` | Global basic accounts object | Application state |

---

## 🧩 Complex Business Logic

### Logic 1: Determine Opening Voucher Number

**VB6 Code (lines 408-439):**
```vb
If IdCompAper = 0 Then
   ' No opening entry exists yet
   Tx_CompAper = 1    ' Default to voucher #1
Else
   ' Opening entry already exists
   lIdCompAper = IdCompAper

   If NumCompAper = 0 Then
      ' Rare case: IdCompAper exists but NumCompAper is 0
      ' Query Comprobante table to get correlativo
      SELECT Correlativo FROM Comprobante
      WHERE IdComp = IdCompAper AND Tipo = TC_APERTURA AND TipoAjuste = TAJUSTE_FINANCIERO

      ' Update EmpresasAno with found number
      UPDATE EmpresasAno SET NCompAper = NumCompAper
   End If

   Tx_CompAper = NumCompAper
   Lb_Reemp.visible = True   ' Show "will replace" warning
End If
```

**Business Rules:**
- **New opening entry:** Default voucher number = 1
- **Existing opening entry:** Load existing voucher number, show replacement warning
- **Data integrity fix:** If IdCompAper exists but NCompAper = 0, query Comprobante and update EmpresasAno

**Mapeo .NET:**
```csharp
public async Task<int> DetermineOpeningVoucherNumberAsync(int empresaId, int ano)
{
    var empresaAno = await _context.EmpresasAno
        .FirstOrDefaultAsync(ea => ea.IdEmpresa == empresaId && ea.Ano == ano);

    if (empresaAno?.IdCompAper == null || empresaAno.IdCompAper == 0)
    {
        // No opening entry exists
        return 1; // Default
    }

    // Opening entry exists
    if (empresaAno.NCompAper == null || empresaAno.NCompAper == 0)
    {
        // Data integrity fix: Query Comprobante
        var comprobante = await _context.Comprobante
            .FirstOrDefaultAsync(c => c.IdComp == empresaAno.IdCompAper &&
                                     c.Tipo == "A" &&
                                     c.TipoAjuste == 1);

        if (comprobante != null)
        {
            empresaAno.NCompAper = comprobante.Correlativo;
            await _context.SaveChangesAsync();
            return comprobante.Correlativo ?? 1;
        }
    }

    return empresaAno.NCompAper ?? 1;
}
```

---

### Logic 2: IVA Remainder Loading Logic

**VB6 Code (lines 531-554):**
```vb
' If previous year exists, load IVA remainder from previous year's close
If gEmpresa.TieneAnoAnt Then
   SELECT RemIVAUTM FROM EmpresasAno WHERE Ano = lAno - 1
   Tx_RemIVAUTMAnoAnt = Format(RemIVAUTM, DBLFMT2)
   ' Lock textbox (read-only) - value comes from previous year close

' If no previous year, load manual input from current year (if apertura was done before)
Else
   Tx_RemIVAUTMAnoAnt = Format(RemIVAUTMAnoAnt, DBLFMT2)
   ' Allow manual input
End If
```

**Business Rules:**
- **With previous year:** IVA remainder is READ-ONLY, comes from previous year's `RemIVAUTM` (set during annual close)
- **Without previous year:** IVA remainder is EDITABLE, stored in current year's `RemIVAUTMAnoAnt` (manual input)

**Mapeo .NET:**
```csharp
public async Task<AperturaIvaRemainderDto> GetIvaRemainderConfigAsync(int empresaId, int ano)
{
    bool hasPreviousYear = await _context.EmpresasAno
        .AnyAsync(ea => ea.IdEmpresa == empresaId && ea.Ano == (ano - 1));

    if (hasPreviousYear)
    {
        // Load from previous year's close
        var previousYear = await _context.EmpresasAno
            .Where(ea => ea.IdEmpresa == empresaId && ea.Ano == (ano - 1))
            .Select(ea => ea.RemIVAUTM)
            .FirstOrDefaultAsync();

        return new AperturaIvaRemainderDto
        {
            RemIVAUTM = previousYear ?? 0,
            IsReadOnly = true,
            Source = "PreviousYearClose"
        };
    }
    else
    {
        // Load from current year's manual input (if exists)
        var currentYear = await _context.EmpresasAno
            .Where(ea => ea.IdEmpresa == empresaId && ea.Ano == ano)
            .Select(ea => ea.RemIVAUTMAnoAnt)
            .FirstOrDefaultAsync();

        return new AperturaIvaRemainderDto
        {
            RemIVAUTM = currentYear ?? 0,
            IsReadOnly = false,
            Source = "ManualInput"
        };
    }
}
```

---

### Logic 3: Account Configuration - Upsert Pattern

**VB6 Code (lines 572-590):**
```vb
' Result Account
If lParamCtaResult Then
   ' Parameter exists - UPDATE
   UPDATE ParamEmpresa SET Valor = lidCuentaResul
   WHERE Tipo = 'CTARESULT' AND IdEmpresa = gEmpresa.id AND Ano = gEmpresa.Ano
Else
   ' Parameter doesn't exist - INSERT
   INSERT INTO ParamEmpresa (Tipo, Valor, IdEmpresa, Ano)
   VALUES('CTARESULT', lidCuentaResul, gEmpresa.id, gEmpresa.Ano)
End If

' IVA Credit Account (same pattern)
If lParamCtaCredIVA Then
   UPDATE ...
Else
   INSERT ...
End If
```

**Business Rules:**
- ParamEmpresa stores configuration per company-year
- Two parameters: `CTARESULT`, `CTACREDIVA`
- Must check if parameter exists before INSERT/UPDATE

**Mapeo .NET (Using EF Core Upsert):**
```csharp
public async Task SaveAperturaAccountsAsync(int empresaId, int ano,
                                           int idCuentaResul, int idCuentaCredIVA)
{
    // Upsert Result Account
    var paramResult = await _context.ParamEmpresa
        .FirstOrDefaultAsync(p => p.IdEmpresa == empresaId &&
                                 p.Ano == ano &&
                                 p.Tipo == "CTARESULT");

    if (paramResult != null)
    {
        paramResult.Valor = idCuentaResul;
    }
    else
    {
        _context.ParamEmpresa.Add(new App.Data.ParamEmpresa
        {
            Tipo = "CTARESULT",
            Valor = idCuentaResul,
            IdEmpresa = empresaId,
            Ano = ano
        });
    }

    // Upsert IVA Credit Account (same pattern)
    var paramIVA = await _context.ParamEmpresa
        .FirstOrDefaultAsync(p => p.IdEmpresa == empresaId &&
                                 p.Ano == ano &&
                                 p.Tipo == "CTACREDIVA");

    if (paramIVA != null)
    {
        paramIVA.Valor = idCuentaCredIVA;
    }
    else
    {
        _context.ParamEmpresa.Add(new App.Data.ParamEmpresa
        {
            Tipo = "CTACREDIVA",
            Valor = idCuentaCredIVA,
            IdEmpresa = empresaId,
            Ano = ano
        });
    }

    await _context.SaveChangesAsync();

    _logger.LogInformation("Saved apertura accounts for empresaId: {EmpresaId}, ano: {Ano}",
                          empresaId, ano);
}
```

---

## 📋 DTOs Required

### 1. AperturaInitDataDto
```csharp
public class AperturaInitDataDto
{
    public int EmpresaId { get; set; }
    public int Ano { get; set; }
    public string NombreEmpresa { get; set; } = string.Empty;

    // Opening Entry Info
    public int? IdCompAper { get; set; }
    public int NumCompAper { get; set; } = 1;
    public bool OpeningEntryExists { get; set; }
    public string WarningMessage { get; set; } = string.Empty;

    // Result Account
    public int? IdCuentaResul { get; set; }
    public string DescCuentaResul { get; set; } = string.Empty;

    // IVA Credit Account
    public int? IdCuentaCredIVA { get; set; }
    public string DescCuentaCredIVA { get; set; } = string.Empty;

    // IVA Remainder
    public double RemIVAUTM { get; set; }
    public bool RemIVAReadOnly { get; set; }
    public string RemIVASource { get; set; } = string.Empty; // "PreviousYearClose" or "ManualInput"

    public bool HasPreviousYear { get; set; }
}
```

### 2. AperturaRequestDto
```csharp
public class AperturaRequestDto
{
    public int EmpresaId { get; set; }
    public int Ano { get; set; }
    public int NumCompAper { get; set; }
    public int IdCuentaResul { get; set; }
    public int IdCuentaCredIVA { get; set; }
    public double RemIVAUTM { get; set; }
}
```

### 3. AperturaResultDto
```csharp
public class AperturaResultDto
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public int NumCompAper { get; set; }
    public int? IdCompAper { get; set; }
    public int IdCuentaResul { get; set; }
    public int? IdCompAperTrib { get; set; }
}
```

### 4. AccountDto (for account picker)
```csharp
public class AccountDto
{
    public int IdCuenta { get; set; }
    public string Codigo { get; set; } = string.Empty;
    public string Descripcion { get; set; } = string.Empty;
    public string Nombre { get; set; } = string.Empty;
}
```

---

## 🚀 Migration Strategy

### Phase 1: Core Service (No UI)
1. Create `IAperturaService` interface with all methods
2. Implement `AperturaService` with business logic
3. Focus on:
   - Loading initialization data
   - Account configuration management
   - IVA remainder logic
   - Validation

### Phase 2: API Layer
1. Create `AperturaApiController`
2. Endpoints:
   - `GET /api/Apertura/init?empresaId=X&ano=Y` - Get init data
   - `GET /api/Apertura/accounts?empresaId=X&ano=Y&type=patrimonio` - Get accounts for picker
   - `POST /api/Apertura/save-config` - Save configuration
   - `POST /api/Apertura/execute` - Execute opening entry generation
   - `GET /api/Apertura/validate?empresaId=X&ano=Y` - Validate prerequisites

### Phase 3: MVC + UI
1. Create `AperturaController` (MVC)
2. Create Razor view with Tailwind CSS
3. JavaScript for:
   - Account picker modal
   - Form validation
   - Submit handling

### Phase 4: Voucher Generation Integration
⚠️ **CRITICAL DECISION:** Determine where voucher creation happens:
- **Option A:** In Apertura service (recommended for atomicity)
- **Option B:** In separate process called by external code (mimics VB6)

---

## ⚠️ Critical Notes for Migration

### 1. Voucher Creation is NOT in VB6 Form
The `FrmApertura` form does NOT create the Comprobante record. It only:
- Collects configuration (accounts, voucher number, IVA remainder)
- Saves configuration to ParamEmpresa and EmpresasAno
- Returns values via output parameters

**The calling code** (likely in the main form or a separate module) is responsible for:
- Creating `Comprobante` record with Type = "A" (TC_APERTURA)
- Creating `MovComprobante` records (debits/credits for opening balances)
- Updating `EmpresasAno` with `IdCompAper`, `NCompAper`

**For .NET:** Consider unifying this into one service method for better encapsulation.

---

### 2. Default Account Codes
The system uses hardcoded default account codes:
- **Result Account:** `2031101` - "Utilidad Neta Retenida"
- **IVA Credit Account:** `1010999` - "Otros Impuestos por Recuperar"

These may not exist in all companies. Handle gracefully if not found.

---

### 3. IVA Remainder Logic is Complex
- **With previous year:** Value comes from `EmpresasAno.RemIVAUTM` of previous year (set during annual close)
- **Without previous year:** Value is manually entered, stored in `EmpresasAno.RemIVAUTMAnoAnt` of current year
- UI must reflect read-only vs editable state

---

### 4. ParamEmpresa Upsert Pattern
Always check if parameter exists before INSERT/UPDATE:
```csharp
var param = await _context.ParamEmpresa.FirstOrDefaultAsync(...);
if (param != null) { param.Valor = newValue; }
else { _context.ParamEmpresa.Add(new ParamEmpresa { ... }); }
```

---

### 5. Progress Bar
VB6 uses simple progress bar (0-100). In .NET:
- Use `IProgress<T>` for service layer
- JavaScript progress bar in UI
- Or remove if operation is fast enough

---

### 6. Permissions
VB6 checks `PRV_ADM_EMPRESA` privilege (line 562). Implement role-based authorization in .NET.

---

### 7. Form Lock Based on FCierre
Line 329 (commented out): `Call EnableForm(Me, gEmpresa.FCierre = 0)`
Means: Disable form if year is closed. Consider implementing this in .NET.

---

## 🔍 Testing Scenarios

### Scenario 1: First Opening Entry (New Year, No Previous Year)
- Company has NO previous year
- No opening entry exists yet
- Expected:
  - NumCompAper defaults to 1
  - RemIVAUTM is editable (manual input)
  - No replacement warning

### Scenario 2: First Opening Entry (New Year, With Previous Year)
- Company HAS previous year
- No opening entry exists yet
- Previous year closed with RemIVAUTM = 5.25
- Expected:
  - NumCompAper defaults to 1
  - RemIVAUTM = 5.25 (read-only, from previous year)
  - No replacement warning

### Scenario 3: Replace Existing Opening Entry
- Opening entry already exists (IdCompAper = 123, NumCompAper = 1)
- Expected:
  - NumCompAper = 1 (loaded from existing)
  - Warning: "Se reemplazará Comprobante de Apertura ya existente"
  - On save: Update existing Comprobante (don't create new)

### Scenario 4: Data Integrity Fix
- IdCompAper = 123 exists in EmpresasAno
- BUT NCompAper = 0 (NULL or 0)
- Expected:
  - Query Comprobante table to get Correlativo
  - Update EmpresasAno.NCompAper with found value
  - Load voucher number

### Scenario 5: Default Accounts Not Found
- Default account codes don't exist in Cuentas table
- Expected:
  - Accounts remain empty
  - User must manually select accounts
  - Validation fails if not selected

### Scenario 6: Configuration Already Saved
- CTARESULT and CTACREDIVA already exist in ParamEmpresa
- Expected:
  - Load saved accounts on form load
  - UPDATE existing parameters on save (not INSERT)

---

## 📊 Summary of Key Findings

| Aspect | VB6 | .NET Migration |
|--------|-----|----------------|
| **Purpose** | Generate opening entry voucher configuration | Same |
| **Voucher Creation** | ❌ NOT done in this form (external caller) | ✅ Should unify into service |
| **Main Inputs** | Voucher number, Result account, IVA credit account, IVA remainder | Same |
| **Main Outputs** | NumCompAper, IdCuentaResul, IdCuentaCredIVA, RemIVAUTM | AperturaResultDto |
| **Configuration Storage** | ParamEmpresa (CTARESULT, CTACREDIVA), EmpresasAno (RemIVAUTMAnoAnt) | Same tables |
| **IVA Logic** | From previous year (read-only) OR manual input (editable) | Same |
| **Default Accounts** | Hardcoded codes: 2031101, 1010999 | Same |
| **Complexity** | Medium (configuration form, no voucher generation) | Medium |
| **UI Pattern** | Modal dialog with account pickers | SPA with modals |

---

**MIGRATION COMPLETE:** Ready to proceed with DTO creation, service implementation, and UI development.
