using Microsoft.AspNetCore.Mvc;

namespace App.Features.Apertura;

[ApiController]
[Route("api/[controller]/[action]")]
public class AperturaApiController(IAperturaService service, ILogger<AperturaApiController> logger) : ControllerBase
{
    /// <summary>
    /// Gets initialization data for apertura form
    /// </summary>
    /// <param name="empresaId">Company ID</param>
    /// <param name="ano">Year</param>
    /// <returns>Initialization data</returns>
    [HttpGet]
    public async Task<ActionResult<AperturaInitDataDto>> Init([FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: Init called with empresaId: {EmpresaId}, ano: {Ano}",
                              empresaId, ano);

        {
            var initData = await service.GetAperturaInitDataAsync(empresaId, ano);
            return Ok(initData);
        }
    }

    /// <summary>
    /// Gets accounts available for selection
    /// </summary>
    /// <param name="empresaId">Company ID</param>
    /// <param name="ano">Year</param>
    /// <param name="type">Account type filter: "patrimonio", "activo", or null for all</param>
    /// <returns>List of accounts</returns>
    [HttpGet]
    public async Task<ActionResult<IEnumerable<AccountDto>>> GetAccounts(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        [FromQuery] string? type = null)
    {
        logger.LogInformation("API: GetAccounts called with empresaId: {EmpresaId}, ano: {Ano}, type: {Type}",
                              empresaId, ano, type ?? "all");

        {
            var accounts = await service.GetAccountsForSelectionAsync(empresaId, ano, type);
            return Ok(accounts);
        }
    }

    /// <summary>
    /// Gets IVA remainder configuration
    /// </summary>
    /// <param name="empresaId">Company ID</param>
    /// <param name="ano">Year</param>
    /// <returns>IVA remainder configuration</returns>
    [HttpGet]
    public async Task<ActionResult<AperturaIvaRemainderDto>> GetIvaRemainder(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        logger.LogInformation("API: GetIvaRemainder called with empresaId: {EmpresaId}, ano: {Ano}",
                              empresaId, ano);

        {
            var ivaConfig = await service.GetIvaRemainderConfigAsync(empresaId, ano);
            return Ok(ivaConfig);
        }
    }

    /// <summary>
    /// Validates apertura request
    /// </summary>
    /// <param name="request">Apertura request</param>
    /// <returns>Validation result</returns>
    [HttpPost]
    public async Task<ActionResult<ValidationResult>> Validate([FromBody] AperturaRequestDto request)
    {
        logger.LogInformation("API: Validate called for empresaId: {EmpresaId}, ano: {Ano}",
                              request.EmpresaId, request.Ano);

        {
            var validationResult = await service.ValidateAperturaRequestAsync(request);
            return Ok(validationResult);
        }
    }

    /// <summary>
    /// Checks if opening entry already exists
    /// </summary>
    /// <param name="empresaId">Company ID</param>
    /// <param name="ano">Year</param>
    /// <returns>True if exists</returns>
    [HttpGet]
    public async Task<ActionResult<bool>> CheckExists([FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: CheckExists called with empresaId: {EmpresaId}, ano: {Ano}",
                              empresaId, ano);

        {
            var exists = await service.OpeningEntryExistsAsync(empresaId, ano);
            return Ok(exists);
        }
    }

    /// <summary>
    /// Executes opening entry generation
    /// </summary>
    /// <param name="request">Apertura request</param>
    /// <returns>Execution result</returns>
    [HttpPost]
    public async Task<ActionResult<AperturaResultDto>> Execute([FromBody] AperturaRequestDto request)
    {
        logger.LogInformation("API: Execute called for empresaId: {EmpresaId}, ano: {Ano}",
                              request.EmpresaId, request.Ano);

        {
            // Validate model
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var result = await service.ExecuteAperturaAsync(request);

            if (result.Success)
            {
                return Ok(result);
            }
            else
            {
                return BadRequest(result);
            }
        }
    }

    /// <summary>
    /// Gets default result account
    /// </summary>
    /// <param name="empresaId">Company ID</param>
    /// <param name="ano">Year</param>
    /// <returns>Default result account if found</returns>
    [HttpGet]
    public async Task<ActionResult<AccountDto?>> GetDefaultResultAccount(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        logger.LogInformation("API: GetDefaultResultAccount called with empresaId: {EmpresaId}, ano: {Ano}",
                              empresaId, ano);

        {
            var account = await service.GetDefaultResultAccountAsync(empresaId, ano);

            if (account != null)
            {
                return Ok(account);
            }
            else
            {
                return NotFound(new { message = "Cuenta de resultado por defecto no encontrada" });
            }
        }
    }

    /// <summary>
    /// Gets default IVA credit account
    /// </summary>
    /// <param name="empresaId">Company ID</param>
    /// <param name="ano">Year</param>
    /// <returns>Default IVA credit account if found</returns>
    [HttpGet]
    public async Task<ActionResult<AccountDto?>> GetDefaultIvaAccount(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        logger.LogInformation("API: GetDefaultIvaAccount called with empresaId: {EmpresaId}, ano: {Ano}",
                              empresaId, ano);

        {
            var account = await service.GetDefaultIvaAccountAsync(empresaId, ano);

            if (account != null)
            {
                return Ok(account);
            }
            else
            {
                return NotFound(new { message = "Cuenta de crédito IVA por defecto no encontrada" });
            }
        }
    }
}
