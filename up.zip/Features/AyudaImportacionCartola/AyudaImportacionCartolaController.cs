using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using App.Extensions;

namespace App.Features.AyudaImportacionCartola;

[Authorize]

public class AyudaImportacionCartolaController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<AyudaImportacionCartolaController> logger) : Controller
{
    /// <summary>
    /// Vista principal de ayuda para importación de cartolas bancarias
    /// </summary>
    /// <returns>Vista con información de ayuda</returns>
    public async Task<IActionResult> Index()
    {
        logger.LogInformation("Loading AyudaImportacionCartola index");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AyudaImportacionCartolaApiController.GetAyudaImportacion),
                controller: nameof(AyudaImportacionCartolaApiController).Replace("Controller", "")
            );
            var ayudaData = await client.GetFromApiAsync<AyudaImportacionCartolaDto>(url!);

            logger.LogInformation("Successfully loaded ayuda importacion cartola data");
            return View(ayudaData);
        }
    }

    /// <summary>
    /// Acción para mostrar la ayuda en modal (llamada via AJAX)
    /// </summary>
    /// <returns>Vista parcial para modal</returns>
    public async Task<IActionResult> Modal()
    {
        logger.LogInformation("Loading AyudaImportacionCartola modal");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AyudaImportacionCartolaApiController.GetAyudaImportacion),
                controller: nameof(AyudaImportacionCartolaApiController).Replace("Controller", "")
            );
            var ayudaData = await client.GetFromApiAsync<AyudaImportacionCartolaDto>(url!);

            logger.LogInformation("Successfully loaded ayuda data for modal");
            return PartialView("_Modal", ayudaData);
        }
    }

    /// <summary>
    /// Método proxy para obtener datos formateados para clipboard
    /// </summary>
    /// <returns>JSON con datos para portapapeles</returns>
    [HttpGet]
    public async Task<IActionResult> GetClipboardData()
    {
        logger.LogInformation("MVC: GetClipboardData proxy called");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AyudaImportacionCartolaApiController.GetClipboardData),
                controller: nameof(AyudaImportacionCartolaApiController).Replace("Controller", "")
            );
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }
}