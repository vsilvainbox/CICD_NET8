namespace App.Features.CapitalPropio;

/// <summary>
/// DTO para el resultado del cálculo del Capital Propio Tributario
/// </summary>
public class CapitalPropioResultDto
{
    public short Ano { get; set; }
    public decimal TotalActivos { get; set; }
    public List<DetalleLineaDto> DeduccionesActivo { get; set; } = new();
    public decimal TotalDeducciones { get; set; }
    public decimal ActivoDepurado { get; set; }
    public List<DetalleLineaDto> ValoresINTO { get; set; } = new();
    public decimal TotalValoresINTO { get; set; }
    public decimal CapitalEfectivo { get; set; }  // código 102
    public List<DetalleLineaDto> PasivoExigible { get; set; } = new();
    public decimal TotalPasivoExigible { get; set; }
    public decimal CapitalPropioTributario { get; set; }  // código 645 o 646
    public int CodigoForm22 { get; set; }  // 645 (positivo) o 646 (negativo)
    public List<string> Advertencias { get; set; } = new();
}

/// <summary>
/// DTO para una línea de detalle en el cálculo
/// </summary>
public class DetalleLineaDto
{
    public string Descripcion { get; set; } = string.Empty;
    public decimal Valor { get; set; }
}