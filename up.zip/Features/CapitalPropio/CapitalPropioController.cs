using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.CapitalPropio;

[Authorize]

public class CapitalPropioController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<CapitalPropioController> logger) : Controller
{
    public IActionResult Index()
    {
        // Obtener empresaId y ano desde la sesi�n
        var empresaId = SessionHelper.EmpresaId;
        var ano = SessionHelper.Ano;

        logger.LogInformation("Loading Capital Propio for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        ViewData["EmpresaId"] = empresaId;
        ViewData["Ano"] = ano;

        return View();
    }

    // M�todo proxy para Calculate
    [HttpGet]
    public async Task<IActionResult> Calculate(int empresaId, short ano)
    {
        logger.LogInformation("MVC Proxy: Calculate Capital Propio for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(CapitalPropioApiController.Calculate),
                controller: nameof(CapitalPropioApiController).Replace("Controller", ""),
                values: new { empresaId, ano }
            );
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // M�todo proxy para Save
    [HttpPost]
    public async Task<IActionResult> Save([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: Save Capital Propio");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(CapitalPropioApiController.Save),
                controller: nameof(CapitalPropioApiController).Replace("Controller", "")
            );
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }
}