namespace App.Features.ConfiguracionFirmaInformes;

public class FirmaDto
{
    public string? Tipo { get; set; }
    public string? RutaArchivo { get; set; }
    public string? NombreArchivo { get; set; }
    public bool Existe { get; set; }
    public bool Habilitado { get; set; }
}

public class ConfiguracionFirmaInformesDto
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public string? RutEmpresa { get; set; }
    
    public FirmaDto? FirmaContador { get; set; }
    public FirmaDto? FirmaRepLegal1 { get; set; }
    public FirmaDto? FirmaRepLegal2 { get; set; }
    
    public bool TieneContador { get; set; }
    public bool TieneRepLegal1 { get; set; }
    public bool TieneRepLegal2 { get; set; }
}

public class UploadFirmaDto
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public string? Tipo { get; set; }
    public string? Base64Image { get; set; }
    public string? FileName { get; set; }
}
