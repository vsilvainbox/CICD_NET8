using Microsoft.AspNetCore.Mvc;

namespace App.Features.ConfiguracionFirmaInformes;

[ApiController]
[Route("api/[controller]/[action]")]
public class ConfiguracionFirmaInformesApiController(
    IConfiguracionFirmaInformesService service,
    ILogger<ConfiguracionFirmaInformesApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<ConfiguracionFirmaInformesDto>> GetConfiguracion([FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: GetConfiguracion called for empresa {EmpresaId}, año {Ano}", empresaId, ano);

        {
            var config = await service.GetConfiguracionAsync(empresaId, ano);
            return Ok(config);
        }
    }

    [HttpPost]
    public async Task<ActionResult> UploadFirma([FromBody] UploadFirmaDto dto)
    {
        logger.LogInformation("API: UploadFirma called for empresa {EmpresaId}, tipo {Tipo}", dto.EmpresaId, dto.Tipo);

        {
            if (string.IsNullOrEmpty(dto.Base64Image) || string.IsNullOrEmpty(dto.Tipo))
            {
                return BadRequest(new { message = "Datos incompletos" });
            }

            var success = await service.SaveFirmaAsync(
                dto.EmpresaId, 
                dto.Ano, 
                dto.Tipo, 
                dto.Base64Image, 
                dto.FileName ?? "firma.jpg");

            if (success)
            {
                return Ok(new { message = "Firma guardada correctamente" });
            }

            return StatusCode(500, new { message = "Error al guardar firma" });
        }
    }

    [HttpDelete]
    public async Task<ActionResult> DeleteFirma([FromQuery] int empresaId, [FromQuery] short ano, [FromQuery] string tipo)
    {
        logger.LogInformation("API: DeleteFirma called for empresa {EmpresaId}, tipo {Tipo}", empresaId, tipo);

        {
            var success = await service.DeleteFirmaAsync(empresaId, ano, tipo);

            if (success)
            {
                return Ok(new { message = "Firma eliminada correctamente" });
            }

            return NotFound(new { message = "Firma no encontrada" });
        }
    }
}
