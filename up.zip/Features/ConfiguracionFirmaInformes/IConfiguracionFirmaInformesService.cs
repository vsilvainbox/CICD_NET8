﻿namespace App.Features.ConfiguracionFirmaInformes;

public interface IConfiguracionFirmaInformesService
{
    Task<ConfiguracionFirmaInformesDto> GetConfiguracionAsync(int empresaId, short ano);
    Task<bool> SaveFirmaAsync(int empresaId, short ano, string tipo, string base64Image, string fileName);
    Task<bool> DeleteFirmaAsync(int empresaId, short ano, string tipo);
}
