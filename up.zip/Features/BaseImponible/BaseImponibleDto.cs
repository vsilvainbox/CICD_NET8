namespace App.Features.BaseImponible;

/// <summary>
/// DTO principal para la Base Imponible 14 TER A
/// </summary>
public class BaseImponibleDto
{
    public int IdEmpresa { get; set; }
    public short Ano { get; set; }
    public string NombreEmpresa { get; set; } = string.Empty;
    public List<BaseImponibleSeccionDto> Secciones { get; set; } = new();
    public double TotalIngresos { get; set; }
    public double TotalEgresos { get; set; }
    public double BaseImponible { get; set; }
    public double MayorValor { get; set; }
}

/// <summary>
/// DTO para una sección de la base imponible (Ingresos, Egresos, Totales)
/// </summary>
public class BaseImponibleSeccionDto
{
    public byte TipoBaseImp { get; set; } // 1=Ingresos, 2=Egresos, 3=Totales
    public string Titulo { get; set; } = string.Empty;
    public List<BaseImponibleItemDto> Items { get; set; } = new();
    public double Subtotal { get; set; }
    public bool EsEditable { get; set; }
}

/// <summary>
/// DTO para un item individual de la base imponible
/// </summary>
public class BaseImponibleItemDto
{
    public int IdBaseImponible14Ter { get; set; }
    public byte TipoBaseImp { get; set; }
    public short IdItemBaseImp { get; set; }
    public string Concepto { get; set; } = string.Empty;
    public double Valor { get; set; }
    public bool EsCalculado { get; set; } = true;
    public bool EsEditable { get; set; } = false;
    public bool EsSubtotal { get; set; } = false;
    public string FormatoLinea { get; set; } = "";
}

/// <summary>
/// DTO para guardar cambios en la base imponible
/// </summary>
public class BaseImponibleSaveDto
{
    public double MayorValor { get; set; }
    public List<BaseImponibleItemUpdateDto> ItemsActualizados { get; set; } = new();
}

/// <summary>
/// DTO para actualizar un item específico
/// </summary>
public class BaseImponibleItemUpdateDto
{
    public byte TipoBaseImp { get; set; }
    public short IdItemBaseImp { get; set; }
    public double Valor { get; set; }
}

/// <summary>
/// DTO para resultado de guardado
/// </summary>
public class BaseImponibleResultDto
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public int RegistrosActualizados { get; set; }
    public int RegistrosInsertados { get; set; }
}

/// <summary>
/// DTO para cálculos de la base imponible
/// </summary>
public class BaseImponibleCalculoDto
{
    public double TotalIngresos { get; set; }
    public double TotalEgresos { get; set; }
    public double BaseImponible { get; set; }
    public Dictionary<string, double> DetalleIngresos { get; set; } = new();
    public Dictionary<string, double> DetalleEgresos { get; set; } = new();
}

/// <summary>
/// DTO para exportación
/// </summary>
public class BaseImponibleExportDto
{
    public string Titulo { get; set; } = "Base Imponible Primera Categoría 14 TER A)";
    public string Empresa { get; set; } = string.Empty;
    public short Ano { get; set; }
    public List<BaseImponibleExportRowDto> Filas { get; set; } = new();
}

/// <summary>
/// DTO para una fila de exportación
/// </summary>
public class BaseImponibleExportRowDto
{
    public string Concepto { get; set; } = string.Empty;
    public string Valor { get; set; } = string.Empty;
    public string Subtotal { get; set; } = string.Empty;
    public bool EsEncabezado { get; set; }
    public bool EsTotal { get; set; }
}

/// <summary>
/// Enumeración para tipos de base imponible
/// </summary>
public enum TipoBaseImponible
{
    Ingresos = 1,
    Egresos = 2,
    Totales = 3
}

/// <summary>
/// Enumeración para tipos de ajustes ELC
/// </summary>
public enum TipoAjusteELC
{
    Agregados = 1,
    Deducciones = 2
}

/// <summary>
/// Constantes de códigos F22 utilizados
/// </summary>
public static class CodigosF22
{
    public const short IngresosPercibidos = 628;
    public const short Participaciones = 629;
    public const short CostoDirecto = 630;
    public const short Remuneraciones = 631;
    public const short AdquisicionActivos = 632;
    public const short InteresesPagados = 633;
    public const short OtrosIngresos = 651;
    public const short OtrosGastos = 635;
}