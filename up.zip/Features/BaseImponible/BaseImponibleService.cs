using Microsoft.EntityFrameworkCore;
using App.Data;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace App.Features.BaseImponible;

/// <summary>
/// Implementación del servicio de Base Imponible Primera Categoría 14 TER A
/// </summary>
public class BaseImponibleService : IBaseImponibleService
{
    private readonly LpContabContext _context;
    private readonly ILogger<BaseImponibleService> _logger;

    // Definición de conceptos de ingresos
    private readonly string[] _conceptosIngresos = new[]
    {
        "Total de ingresos anuales percibidos en el ejercicio (y devengados en los casos que corresponda), a valor nominal",
        "Ingresos percibidos",
        "Ingreso diferido imputado en el ejercicio",
        "Ingresos devengados",
        "Participaciones e intereses percibidos",
        "Otros ingresos percibidos o devengados",
        "Crédito sobre activos fijos adquiridos y pagados en el ejercicio"
    };

    // Definición de conceptos de egresos
    private readonly string[] _conceptosEgresos = new[]
    {
        "Total de egresos anuales efectivamente pagados en el ejercicio, a valor nominal",
        "Costo directo de los bienes o servicios",
        "Remuneraciones",
        "Adquisición de bienes del activo realizable y fijo",
        "Intereses pagados",
        "Pérdidas de ejercicios anteriores",
        "Otros gastos deducidos de los ingresos"
    };

    // Definición de conceptos de totales
    private readonly string[] _conceptosTotales = new[]
    {
        "Base Imponible",
        "Mayor Valor"
    };

    public BaseImponibleService(LpContabContext context, ILogger<BaseImponibleService> logger)
    {
        _context = context;
        _logger = logger;
            
        // Configurar licencia de QuestPDF (Community)
        QuestPDF.Settings.License = LicenseType.Community;
    }

    public async Task<BaseImponibleDto> GetByEmpresaAnoAsync(int empresaId, short ano)
    {
        _logger.LogInformation("Obteniendo base imponible para empresa {EmpresaId} año {Ano}", empresaId, ano);

        {
            var result = new BaseImponibleDto
            {
                IdEmpresa = empresaId,
                Ano = ano,
                Secciones = new List<BaseImponibleSeccionDto>()
            };

            // Obtener nombre de empresa
            var empresa = await _context.Empresa
                .Where(e => e.Id == empresaId)
                .Select(e => e.RazonSocial)
                .FirstOrDefaultAsync();

            result.NombreEmpresa = empresa ?? string.Empty;

            // Cargar sección de ingresos
            var seccionIngresos = await LoadSeccionAsync(empresaId, ano, TipoBaseImponible.Ingresos);
            result.Secciones.Add(seccionIngresos);
            result.TotalIngresos = seccionIngresos.Subtotal;

            // Cargar sección de egresos
            var seccionEgresos = await LoadSeccionAsync(empresaId, ano, TipoBaseImponible.Egresos);
            result.Secciones.Add(seccionEgresos);
            result.TotalEgresos = seccionEgresos.Subtotal;

            // Cargar sección de totales
            var seccionTotales = await LoadSeccionAsync(empresaId, ano, TipoBaseImponible.Totales);
            result.Secciones.Add(seccionTotales);

            // Calcular base imponible
            result.BaseImponible = result.TotalIngresos - result.TotalEgresos;

            // Obtener mayor valor
            var mayorValor = seccionTotales.Items.FirstOrDefault(i => i.IdItemBaseImp == 1);
            result.MayorValor = mayorValor?.Valor ?? 0;

            _logger.LogInformation("Base imponible obtenida: Ingresos={Ingresos}, Egresos={Egresos}, Base={Base}",
                result.TotalIngresos, result.TotalEgresos, result.BaseImponible);

            return result;
        }
    }

    private async Task<BaseImponibleSeccionDto> LoadSeccionAsync(int empresaId, short ano, TipoBaseImponible tipo)
    {
        var seccion = new BaseImponibleSeccionDto
        {
            TipoBaseImp = (byte)tipo,
            Items = new List<BaseImponibleItemDto>()
        };

        // Configurar título según tipo
        switch (tipo)
        {
            case TipoBaseImponible.Ingresos:
                seccion.Titulo = "INGRESOS";
                break;
            case TipoBaseImponible.Egresos:
                seccion.Titulo = "EGRESOS";
                break;
            case TipoBaseImponible.Totales:
                seccion.Titulo = "TOTALES";
                break;
        }

        // Obtener conceptos según tipo
        string[] conceptos = tipo switch
        {
            TipoBaseImponible.Ingresos => _conceptosIngresos,
            TipoBaseImponible.Egresos => _conceptosEgresos,
            TipoBaseImponible.Totales => _conceptosTotales,
            _ => Array.Empty<string>()
        };

        // Cargar items
        for (short i = 0; i < conceptos.Length; i++)
        {
            var item = new BaseImponibleItemDto
            {
                TipoBaseImp = (byte)tipo,
                IdItemBaseImp = i,
                Concepto = conceptos[i],
                EsSubtotal = (i == 0 && tipo != TipoBaseImponible.Totales),
                EsEditable = (tipo == TipoBaseImponible.Totales && i == 1) // Solo Mayor Valor es editable
            };

            // Buscar valor guardado en BD
            var registro = await _context.BaseImponible14Ter
                .FirstOrDefaultAsync(b => b.IdEmpresa == empresaId
                                          && b.Ano == ano
                                          && b.TipoBaseImp == (byte)tipo
                                          && b.IdItemBaseImp == i);

            if (registro != null)
            {
                item.IdBaseImponible14Ter = registro.IdBaseImponible14Ter;
                item.Valor = registro.Valor ?? 0;
            }
            else if (!item.EsEditable)
            {
                // Calcular valor si no es editable
                item.Valor = await CalculateItemValueAsync(empresaId, ano, tipo, i);
            }

            seccion.Items.Add(item);
        }

        // Calcular subtotal
        if (tipo != TipoBaseImponible.Totales)
        {
            seccion.Subtotal = seccion.Items.Where(i => !i.EsSubtotal).Sum(i => i.Valor);
            // Actualizar el valor del primer item (subtotal)
            if (seccion.Items.Count > 0)
            {
                seccion.Items[0].Valor = seccion.Subtotal;
            }
        }

        return seccion;
    }

    private async Task<double> CalculateItemValueAsync(int empresaId, short ano, TipoBaseImponible tipo, short itemIndex)
    {
        double valor = 0;

        switch (tipo)
        {
            case TipoBaseImponible.Ingresos:
                valor = await CalculateIngresoItemAsync(empresaId, ano, itemIndex);
                break;
            case TipoBaseImponible.Egresos:
                valor = await CalculateEgresoItemAsync(empresaId, ano, itemIndex);
                break;
            case TipoBaseImponible.Totales:
                if (itemIndex == 0) // Base Imponible
                {
                    var ingresos = await CalculateTotalIngresosAsync(empresaId, ano);
                    var egresos = await CalculateTotalEgresosAsync(empresaId, ano);
                    valor = ingresos - egresos;
                }
                break;
        }

        return valor;
    }

    private async Task<double> CalculateIngresoItemAsync(int empresaId, short ano, short itemIndex)
    {
        double valor = 0;

        switch (itemIndex)
        {
            case 1: // Ingresos percibidos
                valor = await GetValorCuentaF22Async(empresaId, ano, CodigosF22.IngresosPercibidos, "C");
                valor -= await GetValorAjusteELCAsync(empresaId, ano, (byte)TipoAjusteELC.Deducciones, 2);
                // Restar Notas de Crédito emitidas (ventas)
                valor -= await GetValorNotasCreditoAsync(empresaId, ano, tipoLibro: 2); // Libro Ventas
                break;

            case 2: // Ingreso diferido imputado
                valor = await GetValorAjusteELCAsync(empresaId, ano, (byte)TipoAjusteELC.Agregados, 16);
                valor += await GetValorAjusteELCAsync(empresaId, ano, (byte)TipoAjusteELC.Agregados, 17);
                valor += await GetValorAjusteELCAsync(empresaId, ano, (byte)TipoAjusteELC.Agregados, 18);
                break;

            case 3: // Ingresos devengados
                valor = await GetValorAjusteELCAsync(empresaId, ano, (byte)TipoAjusteELC.Agregados, 11);
                valor += await GetValorAjusteELCAsync(empresaId, ano, (byte)TipoAjusteELC.Agregados, 12);
                valor += await GetValorAjusteELCAsync(empresaId, ano, (byte)TipoAjusteELC.Agregados, 13);
                break;

            case 4: // Participaciones e intereses
                valor = await GetValorCuentaF22Async(empresaId, ano, CodigosF22.Participaciones, "C");
                valor += await GetValorAjusteELCAsync(empresaId, ano, (byte)TipoAjusteELC.Agregados, 8);
                valor += await GetValorAjusteELCAsync(empresaId, ano, (byte)TipoAjusteELC.Agregados, 9);
                break;

            case 5: // Otros ingresos
                valor = await GetValorCuentaF22Async(empresaId, ano, CodigosF22.OtrosIngresos, "C");
                valor += await GetValorAjusteELCAsync(empresaId, ano, (byte)TipoAjusteELC.Agregados, 15);
                valor += await GetValorAjusteELCAsync(empresaId, ano, (byte)TipoAjusteELC.Agregados, 19);
                break;

            case 6: // Crédito activos fijos
                valor = await GetValorCredito33BisAsync(empresaId, ano);
                break;
        }

        return valor;
    }

    private async Task<double> CalculateEgresoItemAsync(int empresaId, short ano, short itemIndex)
    {
        double valor = 0;

        switch (itemIndex)
        {
            case 1: // Costo directo
                valor = await GetValorCuentaF22Async(empresaId, ano, CodigosF22.CostoDirecto, "D");
                valor -= await GetValorAjusteELCAsync(empresaId, ano, (byte)TipoAjusteELC.Agregados, 1);
                // Restar Notas de Crédito recibidas (compras)
                valor -= await GetValorNotasCreditoAsync(empresaId, ano, tipoLibro: 1); // Libro Compras
                break;

            case 2: // Remuneraciones
                valor = await GetValorCuentaF22Async(empresaId, ano, CodigosF22.Remuneraciones, "D");
                break;

            case 3: // Adquisición activos
                valor = await GetValorCuentaF22Async(empresaId, ano, CodigosF22.AdquisicionActivos, "D");
                valor += await GetValorAjusteELCAsync(empresaId, ano, (byte)TipoAjusteELC.Deducciones, 13);
                valor += await GetValorAjusteELCAsync(empresaId, ano, (byte)TipoAjusteELC.Deducciones, 14);
                break;

            case 4: // Intereses pagados
                valor = await GetValorCuentaF22Async(empresaId, ano, CodigosF22.InteresesPagados, "D");
                break;

            case 5: // Pérdidas anteriores
                valor = await GetValorAjusteELCAsync(empresaId, ano, (byte)TipoAjusteELC.Deducciones, 7);
                valor += await GetValorAjusteELCAsync(empresaId, ano, (byte)TipoAjusteELC.Deducciones, 16);
                break;

            case 6: // Otros gastos
                valor = await GetValorCuentaF22Async(empresaId, ano, CodigosF22.OtrosGastos, "D");
                valor += await GetValorAjusteELCAsync(empresaId, ano, (byte)TipoAjusteELC.Deducciones, 17);
                valor += await GetValorAjusteELCAsync(empresaId, ano, (byte)TipoAjusteELC.Deducciones, 5);
                valor += await GetValorAjusteELCAsync(empresaId, ano, (byte)TipoAjusteELC.Deducciones, 15);
                valor += await GetValorAjusteELCAsync(empresaId, ano, (byte)TipoAjusteELC.Deducciones, 8);
                break;
        }

        return valor;
    }

    public async Task<IEnumerable<BaseImponibleItemDto>> GetItemsAsync(int empresaId, short ano)
    {
        _logger.LogInformation("Obteniendo items de base imponible para empresa {EmpresaId} año {Ano}", empresaId, ano);

        var baseImponible = await GetByEmpresaAnoAsync(empresaId, ano);
        var items = new List<BaseImponibleItemDto>();

        foreach (var seccion in baseImponible.Secciones)
        {
            items.AddRange(seccion.Items);
        }

        return items;
    }

    public async Task<BaseImponibleResultDto> SaveAsync(int empresaId, short ano, BaseImponibleSaveDto dto)
    {
        _logger.LogInformation("Guardando base imponible para empresa {EmpresaId} año {Ano}", empresaId, ano);

        var result = new BaseImponibleResultDto { Success = false };

        {
            // Guardar Mayor Valor (tipo=3, item=1)
            await SaveItemAsync(empresaId, ano, (byte)TipoBaseImponible.Totales, 1, dto.MayorValor);
            result.RegistrosActualizados++;

            // Guardar items actualizados si hay
            foreach (var item in dto.ItemsActualizados)
            {
                await SaveItemAsync(empresaId, ano, item.TipoBaseImp, item.IdItemBaseImp, item.Valor);
                result.RegistrosActualizados++;
            }

            // Guardar valores calculados
            await RecalculateAndSaveAsync(empresaId, ano);

            await _context.SaveChangesAsync();

            result.Success = true;
            result.Message = "Base imponible guardada correctamente";

            _logger.LogInformation("Base imponible guardada: {Actualizados} actualizados, {Insertados} insertados",
                result.RegistrosActualizados, result.RegistrosInsertados);

            return result;
        }
    }

    private async Task SaveItemAsync(int empresaId, short ano, byte tipo, short item, double valor)
    {
        var registro = await _context.BaseImponible14Ter
            .FirstOrDefaultAsync(b => b.IdEmpresa == empresaId
                                      && b.Ano == ano
                                      && b.TipoBaseImp == tipo
                                      && b.IdItemBaseImp == item);

        if (registro != null)
        {
            registro.Valor = valor;
            _context.BaseImponible14Ter.Update(registro);
        }
        else
        {
            var maxId = await _context.BaseImponible14Ter
                .Where(b => b.IdEmpresa == empresaId && b.Ano == ano)
                .MaxAsync(b => (int?)b.IdBaseImponible14Ter) ?? 0;

            registro = new App.Data.BaseImponible14Ter
            {
                IdBaseImponible14Ter = maxId + 1,
                IdEmpresa = empresaId,
                Ano = ano,
                TipoBaseImp = tipo,
                IdItemBaseImp = item,
                Valor = valor
            };

            _context.BaseImponible14Ter.Add(registro);
        }
    }

    private async Task RecalculateAndSaveAsync(int empresaId, short ano)
    {
        // Recalcular y guardar todos los valores de ingresos
        for (short i = 1; i <= 6; i++)
        {
            var valor = await CalculateIngresoItemAsync(empresaId, ano, i);
            await SaveItemAsync(empresaId, ano, (byte)TipoBaseImponible.Ingresos, i, valor);
        }

        // Guardar total ingresos
        var totalIngresos = await CalculateTotalIngresosAsync(empresaId, ano);
        await SaveItemAsync(empresaId, ano, (byte)TipoBaseImponible.Ingresos, 0, totalIngresos);

        // Recalcular y guardar todos los valores de egresos
        for (short i = 1; i <= 6; i++)
        {
            var valor = await CalculateEgresoItemAsync(empresaId, ano, i);
            await SaveItemAsync(empresaId, ano, (byte)TipoBaseImponible.Egresos, i, valor);
        }

        // Guardar total egresos
        var totalEgresos = await CalculateTotalEgresosAsync(empresaId, ano);
        await SaveItemAsync(empresaId, ano, (byte)TipoBaseImponible.Egresos, 0, totalEgresos);

        // Guardar base imponible
        var baseImponible = totalIngresos - totalEgresos;
        await SaveItemAsync(empresaId, ano, (byte)TipoBaseImponible.Totales, 0, baseImponible);
    }

    public async Task<BaseImponibleCalculoDto> CalculateValuesAsync(int empresaId, short ano)
    {
        _logger.LogInformation("Calculando valores para empresa {EmpresaId} año {Ano}", empresaId, ano);

        var result = new BaseImponibleCalculoDto();

        // Calcular ingresos detallados
        for (short i = 1; i <= 6; i++)
        {
            var valor = await CalculateIngresoItemAsync(empresaId, ano, i);
            result.DetalleIngresos.Add(_conceptosIngresos[i], valor);
        }

        result.TotalIngresos = result.DetalleIngresos.Values.Sum();

        // Calcular egresos detallados
        for (short i = 1; i <= 6; i++)
        {
            var valor = await CalculateEgresoItemAsync(empresaId, ano, i);
            result.DetalleEgresos.Add(_conceptosEgresos[i], valor);
        }

        result.TotalEgresos = result.DetalleEgresos.Values.Sum();
        result.BaseImponible = result.TotalIngresos - result.TotalEgresos;

        return result;
    }

    public async Task<double> CalculateTotalIngresosAsync(int empresaId, short ano)
    {
        double total = 0;
        for (short i = 1; i <= 6; i++)
        {
            total += await CalculateIngresoItemAsync(empresaId, ano, i);
        }
        return total;
    }

    public async Task<double> CalculateTotalEgresosAsync(int empresaId, short ano)
    {
        double total = 0;
        for (short i = 1; i <= 6; i++)
        {
            total += await CalculateEgresoItemAsync(empresaId, ano, i);
        }
        return total;
    }

    public async Task<double> CalculateBaseImponibleAsync(int empresaId, short ano)
    {
        var ingresos = await CalculateTotalIngresosAsync(empresaId, ano);
        var egresos = await CalculateTotalEgresosAsync(empresaId, ano);
        return ingresos - egresos;
    }

    public async Task<double> GetValorCuentaF22Async(int empresaId, short ano, short codigoF22, string tipo)
    {
        {
            // Obtener cuentas que tienen este código F22
            var cuentasF22 = await _context.Cuentas
                .Where(c => c.IdEmpresa == empresaId
                            && c.Ano == ano
                            && c.CodF22 == codigoF22)
                .Select(c => c.idCuenta)
                .ToListAsync();

            if (!cuentasF22.Any())
            {
                _logger.LogDebug("No hay cuentas con CodF22={CodF22} para empresa {EmpresaId}, año {Ano}",
                    codigoF22, empresaId, ano);
                return 0;
            }

            double total = 0;

            // Sumar movimientos - usando IN directo en lugar de Contains para evitar OPENJSON
            // Alternativa: traer movimientos y filtrar en memoria si cuentasF22 tiene muchos elementos
            if (tipo == "D") // Debe
            {
                // Si hay pocas cuentas, usar subconsulta JOIN
                total = await (from m in _context.MovComprobante
                               join c in _context.Cuentas on new { IdEmpresa = m.IdEmpresa ?? 0, Ano = m.Ano ?? (short)0, IdCuenta = m.IdCuenta ?? 0 } equals new { IdEmpresa = c.IdEmpresa, Ano = c.Ano, IdCuenta = c.idCuenta }
                               where m.IdEmpresa == empresaId
                                     && m.Ano == ano
                                     && c.CodF22 == codigoF22
                               select m.Debe ?? 0)
                              .SumAsync();
            }
            else if (tipo == "C") // Crédito (Haber)
            {
                total = await (from m in _context.MovComprobante
                               join c in _context.Cuentas on new { IdEmpresa = m.IdEmpresa ?? 0, Ano = m.Ano ?? (short)0, IdCuenta = m.IdCuenta ?? 0 } equals new { IdEmpresa = c.IdEmpresa, Ano = c.Ano, IdCuenta = c.idCuenta }
                               where m.IdEmpresa == empresaId
                                     && m.Ano == ano
                                     && c.CodF22 == codigoF22
                               select m.Haber ?? 0)
                              .SumAsync();
            }
            else
            {
                _logger.LogWarning("Tipo inválido '{Tipo}' para GetValorCuentaF22", tipo);
            }

            _logger.LogInformation("Valor CodF22={CodF22}, Tipo={Tipo}: {Total} ({CantCuentas} cuentas)",
                codigoF22, tipo, total, cuentasF22.Count);

            return total;
        }
    }

    public async Task<double> GetValorAjusteELCAsync(int empresaId, short ano, byte tipoAjuste, short item)
    {
        var ajuste = await _context.AjustesExtLibCaja
            .FirstOrDefaultAsync(a => a.IdEmpresa == empresaId
                                      && a.Ano == ano
                                      && a.TipoAjuste == tipoAjuste
                                      && a.IdItemAjuste == item);

        return ajuste?.Valor ?? 0;
    }

    /// <summary>
    /// Obtiene el valor total de Notas de Crédito emitidas o recibidas
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año tributario</param>
    /// <param name="tipoLibro">1=Compras (NC recibidas), 2=Ventas (NC emitidas)</param>
    /// <returns>Suma de totales de NC (positivo)</returns>
    private async Task<double> GetValorNotasCreditoAsync(int empresaId, short ano, short tipoLibro)
    {
        {
            // Obtener tipos de documentos que son Notas de Crédito (EsRebaja = true)
            // Según SII Chile: Tipo 61 = NC Ventas, Tipo 56 = NC Compras
            var tiposNC = await _context.TipoDocs
                .Where(td => td.TipoLib == tipoLibro && td.EsRebaja == true)
                .Select(td => td.TipoDoc)
                .ToListAsync();

            if (!tiposNC.Any())
            {
                _logger.LogWarning("No se encontraron tipos de documentos NC para TipoLib={TipoLibro}", tipoLibro);
                return 0;
            }

            // Sumar totales de documentos NC del año
            var totalNC = await _context.Documento
                .Where(d => d.IdEmpresa == empresaId
                            && d.Ano == ano
                            && d.TipoLib == (byte)tipoLibro
                            && tiposNC.Contains(d.TipoDoc))
                .SumAsync(d => d.Total ?? 0);

            _logger.LogInformation("Valor NC para empresa {EmpresaId}, año {Ano}, libro {TipoLibro}: {Total}",
                empresaId, ano, tipoLibro, totalNC);

            // Retornar valor absoluto (las NC están en negativo en algunos sistemas)
            return Math.Abs(totalNC);
        }
    }

    public async Task<double> GetValorCredito33BisAsync(int empresaId, short ano)
    {
        {
            // El crédito del Art. 33 bis es el 4% del valor de los activos fijos adquiridos
            // en el año que tienen derecho al crédito (Cred4Porc = true)
            var totalActivos = await _context.MovActivoFijo
                .Where(af => af.IdEmpresa == empresaId
                             && af.Ano == ano
                             && af.Cred4Porc == true // Tiene derecho a crédito 4%
                             && af.TipoMovAF == 1) // 1 = Adquisición (no venta)
                .SumAsync(af => af.Neto ?? 0);

            // Calcular 4% del total
            double credito = totalActivos * 0.04;

            _logger.LogInformation("Crédito Art. 33 bis calculado para empresa {EmpresaId}, año {Ano}: " +
                                   "Total activos={TotalActivos:C}, Crédito 4%={Credito:C}",
                empresaId, ano, totalActivos, credito);

            return credito;
        }
    }

    public async Task<byte[]> ExportToExcelAsync(int empresaId, short ano)
    {
        _logger.LogInformation("Exportando base imponible a Excel para empresa {EmpresaId} año {Ano}", empresaId, ano);

        {
            var data = await GetByEmpresaAnoAsync(empresaId, ano);

            using var package = new ExcelPackage();
            var worksheet = package.Workbook.Worksheets.Add("Base Imponible");

            // Configurar título
            worksheet.Cells[1, 1].Value = "BASE IMPONIBLE PRIMERA CATEGORÍA 14 TER A)";
            worksheet.Cells[1, 1, 1, 3].Merge = true;
            worksheet.Cells[1, 1].Style.Font.Bold = true;
            worksheet.Cells[1, 1].Style.Font.Size = 14;
            worksheet.Cells[1, 1].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

            // Información de empresa y año
            worksheet.Cells[2, 1].Value = $"Empresa: {data.NombreEmpresa}";
            worksheet.Cells[3, 1].Value = $"Año: {ano}";

            int row = 5;

            // Exportar cada sección
            foreach (var seccion in data.Secciones)
            {
                // Título de sección
                worksheet.Cells[row, 1].Value = seccion.Titulo;
                worksheet.Cells[row, 1].Style.Font.Bold = true;
                worksheet.Cells[row, 1].Style.Fill.PatternType = ExcelFillStyle.Solid;
                worksheet.Cells[row, 1].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightGray);
                worksheet.Cells[row, 1, row, 3].Merge = true;
                row++;

                // Items de la sección
                foreach (var item in seccion.Items)
                {
                    worksheet.Cells[row, 1].Value = item.Concepto;

                    if (item.EsSubtotal)
                    {
                        worksheet.Cells[row, 3].Value = item.Valor;
                        worksheet.Cells[row, 1, row, 3].Style.Font.Bold = true;
                    }
                    else
                    {
                        worksheet.Cells[row, 2].Value = item.Valor;
                    }

                    worksheet.Cells[row, 2].Style.Numberformat.Format = "#,##0.00";
                    worksheet.Cells[row, 3].Style.Numberformat.Format = "#,##0.00";

                    row++;
                }

                row++; // Línea en blanco entre secciones
            }

            // Ajustar anchos de columna
            worksheet.Column(1).Width = 80;
            worksheet.Column(2).Width = 15;
            worksheet.Column(3).Width = 15;

            return package.GetAsByteArray();
        }
    }

    public async Task<byte[]> GenerateReportPdfAsync(int empresaId, short ano)
    {
        _logger.LogInformation("Generando PDF de Base Imponible para empresa {EmpresaId} año {Ano}", empresaId, ano);

        {
            var data = await GetByEmpresaAnoAsync(empresaId, ano);

            var document = Document.Create(container =>
            {
                container.Page(page =>
                {
                    page.Size(PageSizes.Letter);
                    page.Margin(2, Unit.Centimetre);
                    page.PageColor(Colors.White);
                    page.DefaultTextStyle(x => x.FontSize(10).FontFamily("Arial"));

                    page.Header()
                        .Column(column =>
                        {
                            column.Item().Text("BASE IMPONIBLE PRIMERA CATEGORÍA 14 TER A)")
                                .FontSize(14).Bold().AlignCenter();
                            column.Item().PaddingTop(5).Text($"Empresa: {data.NombreEmpresa}")
                                .FontSize(11);
                            column.Item().Text($"Año Tributario: {ano}")
                                .FontSize(11);
                            column.Item().PaddingTop(10).LineHorizontal(1);
                        });

                    page.Content()
                        .PaddingTop(10)
                        .Column(column =>
                        {
                            foreach (var seccion in data.Secciones)
                            {
                                // Título de sección
                                column.Item().PaddingTop(10)
                                    .Background(Colors.Grey.Lighten3)
                                    .Padding(5)
                                    .Text(seccion.Titulo).Bold().FontSize(12);

                                // Items de la sección
                                column.Item().Table(table =>
                                {
                                    table.ColumnsDefinition(columns =>
                                    {
                                        columns.RelativeColumn(3); // Concepto
                                        columns.RelativeColumn(1); // Valor
                                    });

                                    foreach (var item in seccion.Items)
                                    {
                                        var style = item.EsSubtotal ? TextStyle.Default.Bold() : TextStyle.Default;

                                        table.Cell().BorderBottom(0.5f)
                                            .Padding(3)
                                            .Text(item.Concepto).Style(style);

                                        table.Cell().BorderBottom(0.5f)
                                            .Padding(3)
                                            .AlignRight()
                                            .Text($"${item.Valor:N2}").Style(style);
                                    }
                                });
                            }

                            // Totales finales
                            column.Item().PaddingTop(20)
                                .Table(table =>
                                {
                                    table.ColumnsDefinition(columns =>
                                    {
                                        columns.RelativeColumn(3);
                                        columns.RelativeColumn(1);
                                    });

                                    table.Cell().Background(Colors.Grey.Lighten2)
                                        .Padding(5)
                                        .Text("BASE IMPONIBLE FINAL").Bold().FontSize(12);

                                    table.Cell().Background(Colors.Grey.Lighten2)
                                        .Padding(5)
                                        .AlignRight()
                                        .Text($"${data.BaseImponible:N2}").Bold().FontSize(12);
                                });
                        });

                    page.Footer()
                        .AlignCenter()
                        .DefaultTextStyle(x => x.FontSize(8))
                        .Text(x =>
                        {
                            x.Span("Página ");
                            x.CurrentPageNumber();
                            x.Span(" de ");
                            x.TotalPages();
                            x.Span($" - Generado el {DateTime.Now:dd/MM/yyyy HH:mm}");
                        });
                });
            });

            return document.GeneratePdf();
        }
    }

    public async Task<ValidationResult> ValidateAsync(int empresaId, short ano)
    {
        var result = new ValidationResult { IsValid = true };

        // Verificar que existe la empresa
        var empresaExiste = await _context.Empresa
            .AnyAsync(e => e.Id == empresaId);

        if (!empresaExiste)
        {
            result.IsValid = false;
            result.Errors.Add($"La empresa con ID {empresaId} no existe");
        }

        // Verificar año válido
        if (ano < 2000 || ano > DateTime.Now.Year + 1)
        {
            result.IsValid = false;
            result.Errors.Add($"El año {ano} no es válido");
        }

        return result;
    }
}