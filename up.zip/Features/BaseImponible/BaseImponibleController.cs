using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.BaseImponible;

/// <summary>
/// Controlador MVC para Base Imponible Primera Categor�a 14 TER A
/// </summary>
public class BaseImponibleController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<BaseImponibleController> logger) : Controller
{
    /// <summary>
    /// Vista principal de la base imponible
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Index()
    {
            
            
        {
            logger.LogInformation("Accediendo a Base Imponible para empresa {EmpresaId} año {Ano}",
                SessionHelper.EmpresaId, SessionHelper.Ano);

            ViewData["Title"] = "Base Imponible Primera Categor�a 14 TER A)";

            await Task.CompletedTask;
            return View();
        }
    }

    /// <summary>
    /// Vista de impresi�n de la base imponible
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Print()
    {
            
            
        {
            logger.LogInformation("Vista de impresi�n para empresa {EmpresaId} año {Ano}",
                SessionHelper.EmpresaId, SessionHelper.Ano);

            await Task.CompletedTask;
            return View();
        }
    }

    [HttpGet]
    public async Task<IActionResult> GetData(int empresaId, short ano)
    {
        logger.LogInformation("Proxying GetData: empresaId={EmpresaId}, ano={Ano}", empresaId, ano);

        var client = httpClientFactory.CreateClient("ApiClient");

        var url = linkGenerator.GetPathByAction(
            action: nameof(BaseImponibleApiController.GetByEmpresaAno),
            controller: nameof(BaseImponibleApiController).Replace("Controller", ""),
            values: new { empresaId, ano });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    [HttpPost]
    public async Task<IActionResult> SaveData(int empresaId, short ano, [FromBody] JsonElement request)
    {
        logger.LogInformation("Proxying SaveData: empresaId={EmpresaId}, ano={Ano}", empresaId, ano);

        var client = httpClientFactory.CreateClient("ApiClient");

        var url = linkGenerator.GetPathByAction(
            action: nameof(BaseImponibleApiController.Save),
            controller: nameof(BaseImponibleApiController).Replace("Controller", ""),
            values: new { empresaId, ano });
        var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }

    [HttpGet]
    public async Task<IActionResult> ExportExcel(int empresaId, short ano)
    {
        logger.LogInformation("Proxying ExportExcel: empresaId={EmpresaId}, ano={Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(BaseImponibleApiController.ExportToExcel),
                controller: nameof(BaseImponibleApiController).Replace("Controller", ""),
                values: new { empresaId, ano });
            var (fileBytes, contentType) = await client.DownloadFileAsync(url, HttpMethod.Get, null);

            return File(fileBytes, contentType);
        }
    }
}