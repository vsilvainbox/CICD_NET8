using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.AuditoriaGeneral;

public class AuditoriaGeneralController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<AuditoriaGeneralController> logger) : Controller
{
    public IActionResult Index()
    {
        // Obtener empresaId y año desde BaseController (patrón estándar del proyecto)
        ViewData["EmpresaId"] = SessionHelper.EmpresaId;
        ViewData["Ano"] = SessionHelper.Ano;

        logger.LogInformation("Loading AuditoriaGeneral Index view for empresaId: {EmpresaId}, año: {Ano}",
            SessionHelper.EmpresaId, SessionHelper.Ano);

        return View();
    }

    // Método proxy: GetOperaciones
    [HttpGet]
    public async Task<IActionResult> GetOperaciones()
    {
        logger.LogInformation("Proxy: GetOperaciones");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AuditoriaGeneralApiController.GetOperaciones),
                controller: nameof(AuditoriaGeneralApiController).Replace("Controller", ""));
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // Método proxy: GetUsuarios
    [HttpGet]
    public async Task<IActionResult> GetUsuarios()
    {
        logger.LogInformation("Proxy: GetUsuarios");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AuditoriaGeneralApiController.GetUsuarios),
                controller: nameof(AuditoriaGeneralApiController).Replace("Controller", ""));
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // Método proxy: GetTiposComprobante
    [HttpGet]
    public async Task<IActionResult> GetTiposComprobante()
    {
        logger.LogInformation("Proxy: GetTiposComprobante");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AuditoriaGeneralApiController.GetTiposComprobante),
                controller: nameof(AuditoriaGeneralApiController).Replace("Controller", ""));
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    // Método proxy: CanDeleteImported
    [HttpPost]
    public async Task<IActionResult> CanDeleteImported([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: CanDeleteImported");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AuditoriaGeneralApiController.CanDeleteImported),
                controller: nameof(AuditoriaGeneralApiController).Replace("Controller", ""));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    // Método proxy: DeleteImported
    [HttpPost]
    public async Task<IActionResult> DeleteImported([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: DeleteImported");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AuditoriaGeneralApiController.DeleteImported),
                controller: nameof(AuditoriaGeneralApiController).Replace("Controller", ""));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    // Método proxy: GetAll (con parámetros de query)
    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        logger.LogInformation("Proxy: GetAll with querystring");

        {
            var client = httpClientFactory.CreateClient("ApiClient");
            var queryString = Request.QueryString.ToString();

            var url = linkGenerator.GetPathByAction(
                action: nameof(AuditoriaGeneralApiController.GetAll),
                controller: nameof(AuditoriaGeneralApiController).Replace("Controller", ""));
            // Append query string manually since it's dynamic
            var fullUrl = url + queryString;
            var datos = await client.GetFromApiAsync<object>(fullUrl);
            return Ok(datos);
        }
    }
}