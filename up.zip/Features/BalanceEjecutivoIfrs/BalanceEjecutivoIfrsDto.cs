using System.ComponentModel.DataAnnotations;

namespace App.Features.BalanceEjecutivoIfrs;

/// <summary>
/// Request DTO para Balance Ejecutivo IFRS (formato paralelo).
/// </summary>
public class BalanceEjecutivoIfrsRequestDto
{
    [Required(ErrorMessage = "La fecha inicial es requerida")]
    public DateTime FechaDesde { get; set; }

    [Required(ErrorMessage = "La fecha final es requerida")]
    public DateTime FechaHasta { get; set; }

    public int? IdAreaNegocio { get; set; }

    public int? IdCentroCosto { get; set; }

    public bool MostrarCodigo { get; set; } = true;
}

/// <summary>
/// Response DTO para Balance Ejecutivo IFRS.
/// </summary>
public class BalanceEjecutivoIfrsResponseDto
{
    public List<BalanceEjecutivoIfrsLineaDto> Activos { get; set; } = new();
    public List<BalanceEjecutivoIfrsLineaDto> Pasivos { get; set; } = new();
    public List<BalanceEjecutivoIfrsLineaDto> Patrimonio { get; set; } = new();
    public double TotalActivos { get; set; }
    public double TotalPasivos { get; set; }
    public double TotalPatrimonio { get; set; }
    public double Diferencia { get; set; }
}

/// <summary>
/// Representa una línea en el balance ejecutivo IFRS.
/// </summary>
public class BalanceEjecutivoIfrsLineaDto
{
    public string Codigo { get; set; } = string.Empty;
    public string Descripcion { get; set; } = string.Empty;
    public double Saldo { get; set; }
    public int Nivel { get; set; }
    public bool EsTotal { get; set; }
    public int Clasificacion { get; set; }
}
