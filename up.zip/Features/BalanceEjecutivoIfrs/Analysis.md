# Balance Ejecutivo IFRS - Analysis

## Original VB6 Form: FrmBalEjecIFRS.frm

### Purpose

Generates an Executive Statement of Financial Position (Estado de Situación Financiera Ejecutivo) in IFRS format. This is a condensed balance sheet that displays Assets and Liabilities/Equity side-by-side in a two-column layout, commonly known as a parallel balance or T-format balance.

### UI Components

#### Frame1 (Top Toolbar) - Line 91

- **Bt_View** (Button): Print preview
- **Bt_Print** (Button): Print report
- **Bt_CopyExcel** (Button): Copy to Excel with company header
- **Bt_Sum** (Button): Sum selected movements
- **Bt_ConvMoneda** (Button): Currency converter
- **Bt_Calc** (Button): Calculator
- **Bt_Calendar** (Button): Calendar picker
- **Ch_VerCodCta** (CheckBox): Toggle IFRS code visibility
- **Bt_Cancel** (Button): Close form

#### Fr_Filtro (Filter Panel) - Line 16

- **Tx_Desde** (TextBox): Start date filter
- **Bt_Fecha(0)** (Button): Calendar picker for start date
- **Tx_Hasta** (TextBox): End date filter
- **Bt_Fecha(1)** (Button): Calendar picker for end date
- **Ch_SaldosVig** (CheckBox): Show only current balances (non-zero)
- **Bt_Buscar** (Button): Generate report

#### Grid (Hidden Working MSFlexGrid) - Line 83

Internal grid for data processing (12 columns):

- C_CODIGO (0): Account code (Assets)
- C_DESC (1): Account description (Assets)
- C_IDCUENTA (2): Account ID (Assets)
- C_NIVEL (3): Hierarchical level (Assets)
- C_SALDO (4): Balance (Assets)
- C_INTER (5): Intermediate separator column
- C_CODIGO_P (6): Account code (Liabilities/Equity)
- C_DESC_P (7): Account description (Liabilities/Equity)
- C_IDCUENTA_P (8): Account ID (Liabilities/Equity)
- C_NIVEL_P (9): Hierarchical level (Liabilities/Equity)
- C_SALDO_P (10): Balance (Liabilities/Equity)
- C_FMT (11): Format flag (for bold/cell formatting)

#### GridV (Visible Display MSFlexGrid) - Line 155

Displays the parallel grid (same structure as Grid).

### Key Functions and Events

#### Form_Load() - Line 397

1. Sets form caption from `gInformeIFRS(IFRS_BALEJEC)`
2. Determines current/last month with vouchers
3. Sets default date range (Jan 1 to end of current month)
4. Calls `SetUpGrid()` to configure grid layout
5. Sets "Ver Codificación" checkbox to checked
6. Automatically calls `Bt_Buscar_Click()` to load data
7. Validates chart of accounts plan (if lOper = O_VIEW)
8. Warns if accounts lack IFRS classification
9. Shows warning that only APPROVED vouchers are included

#### SetUpGrid() - Line 311

Configures grid structure:

1. Sets 12 columns (NCOLS + 1)
2. No fixed rows (FixedRows = 0)
3. Sets column widths:
   - Code columns: 1000 or 0 (based on checkbox)
   - Description columns: 4800
   - Balance columns: G_DVALWIDTH + 200
   - Intermediate separator: 300
   - Hidden columns: 0
4. Sets alignments (left for descriptions, right for balances)

#### Bt_Buscar_Click() - Line 346

1. Sets mouse pointer to hourglass
2. Calls `LoadAll()` to generate report
3. Restores mouse pointer

#### LoadAll() - Line 474

**Main report generation logic:**

1. **First Query - Assets and Liabilities:**
   - Joins IFRS_PlanIFRS with Cuentas (on CodIFRS)
   - Joins with MovComprobante and Comprobante
   - Filters by date range
   - Filters by Estado = APROBADO
   - Filters by Clasificacion IN (ACTIVO, PASIVO)
   - Filters by TipoAjuste (FINANCIERO or AMBOS)
   - Groups by IFRS account code
   - Orders by Codigo

2. **Hierarchical Processing:**
   - Tracks current level (CurNiv)
   - Maintains parent names for each level (Padre array)
   - Maintains totals for each level (Total array)
   - When level decreases, writes totals for completed levels
   - Adds blank lines between level 1 and 2 sections

3. **Balance Calculation:**
   - ACTIVO: Debe - Haber
   - PASIVO: Haber - Debe
   - Only shows balance for deepest level (IFRS_MAXNIVEL)

4. **Special Handling:**
   - Tracks row numbers for key totals (TotActivos, TotPasivos, etc.)
   - Identifies "Otras Reservas" row for later adjustment

5. **Second Query - Other Reserves (Resultado Integral):**
   - Queries IFRS accounts starting with "401" (Comprehensive Income)
   - Filters by deepest level (gLastNivelIFRS)
   - Calculates balances: Haber - Debe
   - Distributes to subcategories under "Otras Reservas"

6. **Final Adjustments:**
   - Calculates net profit/loss: TotActivos - TotPasivos - TotReservas
   - Updates "Utilidad o Pérdida Neta del Periodo" row
   - Adjusts "Ganancias (Pérdidas) Acumuladas"
   - Recalculates Total Patrimonio
   - Sets Total Pasivos = Total Activos (balancing equation)

7. **Zero Balance Filtering (if Ch_SaldosVig checked):**
   - Hides deepest level rows with zero balance
   - Hides parent rows if all children are hidden
   - Uses Grid.RowHeight = 0 to hide rows

8. **Parallel Grid Setup:**
   - Calls `SetParallelGrid_ConValCero()` or `SetParallelGrid_SinValCero()`
   - Splits Assets and Liabilities/Equity into two columns

#### SetParallelGrid_ConValCero() - Line 869

**Creates side-by-side layout with all values:**

1. **Identifies Key Rows:**
   - InitPasivo: First liability row (code starts with "2")
   - RowActCorrientes: "Total Activos Corrientes"
   - RowActNoCorrientes: "Total Activos No Corrientes"
   - RowPasCorrientes: "Total Pasivos Corrientes"
   - RowPasNoCorrientes: "Total Pasivos No Corrientes"
   - RowActTotal: "Total Activos"
   - RowPasTotal: "Total Pasivos"
   - InitPatrimonio: "Patrimonio"
   - RowTotPatrimonio: "Total Patrimonio"

2. **Calculates Row Counts:**
   - RowEndCorrientes: Max rows between Current Assets and Current Liabilities
   - RowEndTotal: Max rows between Total Assets and Total Liabilities

3. **Copies Data to GridV:**
   - Left column (C_CODIGO to C_SALDO): Assets
   - Right column (C_CODIGO_P to C_SALDO_P): Liabilities and Equity
   - Fills empty rows to align totals

4. **Formatting:**
   - Removes code from first row of each column
   - Converts first and last rows to uppercase
   - Applies bold to rows without codes or with codes ending in "00"
   - Sets C_FMT = "FCELL" for cell-specific formatting

#### SetParallelGrid_SinValCero() - Line 1078

**Creates side-by-side layout showing only non-zero balances:**

1. Similar to `SetParallelGrid_ConValCero()` but:
   - Skips rows where Grid.RowHeight = 0
   - Counts visible rows (NActCorriente, NPasCorriente)
   - Uses NEndCorriente instead of RowEndCorriente
   - Calculates RowTotalFinal dynamically based on visible rows

2. **Result:**
   - More compact display
   - Only shows accounts with movement
   - Maintains proper alignment and totals

#### Bt_CopyExcel_Click() - Line 356

1. Calls `FGr2Clip_membr()` to copy GridV to clipboard
2. Includes company header (membrete)

#### Bt_Print_Click() - Line 364

1. Calls `SetUpPrtGrid()` for print configuration
2. Sets printer orientation to Landscape
3. Calls `gPrtReportes.PrtFlexGrid(Printer)` to print
4. Restores printer orientation

#### bt_View_Click() - Line 379

1. Calls `SetUpPrtGrid()` for print configuration
2. Sets orientation to Landscape
3. Creates FrmPrintPreview instance
4. Renders preview using `gPrtReportes.PrtFlexGrid(Frm)`

#### SetUpPrtGrid() - Line 451

Configures print layout:

1. Sets Grid reference to GridV
2. Sets title: Form caption
3. Sets subtitle: Date range
4. Sets Arial font size 8
5. Copies column widths from GridV
6. Sets ColObligatoria = C_IDCUENTA (required column for printing)
7. Sets NTotLines = 0 (no separate total lines)
8. Sets FmtCol = C_FMT (format column for bold)

#### Ch_VerCodCta_Click() - Line 1588

Toggles IFRS code visibility:

1. Shows/hides C_CODIGO and C_CODIGO_P columns
2. Adjusts description and balance column widths:
   - With codes: lWDesc (4800) and lWVal
   - Without codes: lWDesc + 900 and lWVal + 400

#### Ch_SaldosVig_Click() - Line 393

Enables "Listar" button when checkbox state changes.

#### Form_Resize() - Line 1558

Responsive layout:

1. Expands GridV width to form width
2. Expands GridV height to available space
3. If filter panel hidden, moves GridV to top

### Database Queries

#### First Query - Assets and Liabilities (Line 490)

```sql
SELECT 
  IFRS_PlanIFRS.idCuenta,
  IFRS_PlanIFRS.Codigo,
  IFRS_PlanIFRS.Nivel,
  IFRS_PlanIFRS.Descripcion as Descr,
  IFRS_PlanIFRS.Clasificacion as ClasCta,
  Sum(MovComprobante.Debe) as SumDebe,
  Sum(MovComprobante.Haber) As SumHaber
FROM ((IFRS_PlanIFRS
  LEFT JOIN Cuentas ON IFRS_PlanIFRS.Codigo = Cuentas.CodIFRS)
  LEFT JOIN MovComprobante ON Cuentas.IdCuenta = MovComprobante.IdCuenta)
  LEFT JOIN Comprobante ON MovComprobante.IdComp = Comprobante.IdComp
WHERE (Comprobante.Fecha IS NULL OR Comprobante.Fecha BETWEEN ? AND ?)
  AND (Comprobante.Estado IS NULL OR Comprobante.Estado = EC_APROBADO)
  AND IFRS_PlanIFRS.Clasificacion IN (CLASCTA_ACTIVO, CLASCTA_PASIVO)
  AND (Comprobante.TipoAjuste IS NULL OR Comprobante.TipoAjuste IN (TAJUSTE_FINANCIERO, TAJUSTE_AMBOS))
  AND (Comprobante.IdEmpresa IS NULL OR Comprobante.IdEmpresa = ?)
  AND (Comprobante.Ano IS NULL OR Comprobante.Ano = ?)
  AND (Cuentas.IdEmpresa IS NULL OR Cuentas.IdEmpresa = ?)
  AND (Cuentas.Ano IS NULL OR Cuentas.Ano = ?)
GROUP BY 
  IFRS_PlanIFRS.idCuenta,
  IFRS_PlanIFRS.Codigo,
  IFRS_PlanIFRS.Nivel,
  IFRS_PlanIFRS.Descripcion,
  IFRS_PlanIFRS.Clasificacion
ORDER BY IFRS_PlanIFRS.Codigo
```

#### Second Query - Comprehensive Income (Line 760)

```sql
SELECT 
  IFRS_PlanIFRS.idCuenta,
  IFRS_PlanIFRS.Codigo,
  IFRS_PlanIFRS.Nivel,
  IFRS_PlanIFRS.Descripcion as Descr,
  IFRS_PlanIFRS.Clasificacion as ClasCta,
  Sum(MovComprobante.Debe) as SumDebe,
  Sum(MovComprobante.Haber) As SumHaber
FROM ((IFRS_PlanIFRS
  LEFT JOIN Cuentas ON IFRS_PlanIFRS.Codigo = Cuentas.CodIFRS)
  LEFT JOIN MovComprobante ON Cuentas.IdCuenta = MovComprobante.IdCuenta)
  LEFT JOIN Comprobante ON MovComprobante.IdComp = Comprobante.IdComp
WHERE IFRS_PlanIFRS.Nivel = gLastNivelIFRS
  AND Left(IFRS_PlanIFRS.Codigo, 3) = '401'
  AND (Comprobante.Fecha IS NULL OR Comprobante.Fecha BETWEEN ? AND ?)
  AND (Comprobante.Estado IS NULL OR Comprobante.Estado = EC_APROBADO)
  AND (Comprobante.TipoAjuste IS NULL OR Comprobante.TipoAjuste IN (TAJUSTE_FINANCIERO, TAJUSTE_AMBOS))
  AND (Comprobante.IdEmpresa IS NULL OR Comprobante.IdEmpresa = ?)
  AND (Comprobante.Ano IS NULL OR Comprobante.Ano = ?)
GROUP BY 
  IFRS_PlanIFRS.idCuenta,
  IFRS_PlanIFRS.Codigo,
  IFRS_PlanIFRS.Nivel,
  IFRS_PlanIFRS.Descripcion,
  IFRS_PlanIFRS.Clasificacion
ORDER BY IFRS_PlanIFRS.Codigo
```

### Business Logic

#### IFRS Classification System

- **1 = CLASCTA_ACTIVO**: Assets
- **2 = CLASCTA_PASIVO**: Liabilities and Equity

#### Parallel Grid Layout

**Left Column (Assets):**

- Activos Corrientes (Current Assets)
- Activos No Corrientes (Non-Current Assets)
- Total Activos

**Right Column (Liabilities and Equity):**

- Pasivos Corrientes (Current Liabilities)
- Pasivos No Corrientes (Non-Current Liabilities)
- Patrimonio (Equity)
- Total Pasivos (equals Total Activos)

#### Hierarchical Totaling

Uses array `Total(IFRS_MAXNIVEL)` to track running totals at each level.

#### Key Calculations

1. **Asset Balance:** Debe - Haber
2. **Liability/Equity Balance:** Haber - Debe
3. **Net Profit/Loss:** Total Assets - Total Liabilities - Other Reserves
4. **Total Equity:** Original Equity + Net Profit/Loss + Other Reserves
5. **Total Liabilities (Final):** Total Assets (balancing equation)

#### Comprehensive Income Accounts (Code 401.xx)

Distributed to "Otras Reservas" subcategories:

- Last 2 digits of account code determine subcategory
- Adds to TotReservas for equity adjustment

#### Adjustment Types Filter

Only includes vouchers with:

- `TipoAjuste IS NULL`
- `TipoAjuste = TAJUSTE_FINANCIERO`
- `TipoAjuste = TAJUSTE_AMBOS`

Excludes purely tax adjustments.

#### Validations

1. **Chart of Accounts:** Must be predefined plan (Básico, Intermedio, Avanzado, IFRS)
2. **IFRS Classification:** Warns if accounts have non-zero balance without IFRS classification
3. **Voucher State:** Only processes APPROVED vouchers

### Constants and Settings

```vb
Const C_CODIGO = 0
Const C_DESC = 1
Const C_IDCUENTA = 2
Const C_NIVEL = 3
Const C_SALDO = 4
Const C_INTER = 5
Const C_CODIGO_P = 6
Const C_DESC_P = 7
Const C_IDCUENTA_P = 8
Const C_NIVEL_P = 9
Const C_SALDO_P = 10
Const C_FMT = 11

Dim lWCodCta As Integer
Dim lWVal As Integer
Dim lWDesc As Integer
Dim lMes As Integer
```

### Helper Functions Referenced

- `GetMesActual()`: Get current active month
- `GetUltimoMesConComps()`: Get last month with vouchers
- `FirstLastMonthDay()`: Get first/last day of month
- `SetTxDate()`: Set textbox date value
- `GetTxDate()`: Extract date from textbox
- `FGrSetup()`: Setup grid formatting
- `FGrVRows()`: Recalculate visible rows
- `FGrFontBold()`: Set font bold for cell
- `FGrSetRowStyle()`: Set row style
- `FGr2Clip_membr()`: Convert grid to clipboard with company header
- `FmtCodIFRS()`: Format IFRS code
- `VFmtCodigoIFRS()`: Reverse format IFRS code
- `SaldosSinClasifIFRS()`: Check for unclassified accounts
- `Calculadora()`: Launch calculator utility
- `DtGotFocus()`, `DtLostFocus()`: Date textbox focus handlers
- `KeyDate()`: Date textbox key handler
- `JoinEmpAno()`: Build empresa/año join clause

### External Dependencies

- **gEmpresa**: Global company object
- **gInformeIFRS()**: IFRS report names array
- **gPrtReportes**: Global print library object
- **DbMain**: Main database connection
- **IFRS_BALEJEC**: Report type constant
- **IFRS_MAXNIVEL**: Maximum IFRS hierarchy levels
- **gLastNivelIFRS**: Deepest IFRS level
- **gLastNivel**: Deepest account level
- **EC_APROBADO**: Approved voucher state
- **TAJUSTE_FINANCIERO**: Financial adjustment type
- **TAJUSTE_AMBOS**: Both adjustment types
- **CLASCTA_ACTIVO**: Asset classification
- **CLASCTA_PASIVO**: Liability classification
- **NEGNUMFMT**: Negative number format
- **NUMFMT**: Standard number format
- **REP_INDENT**: Report indentation spaces
- **cdlLandscape**: Landscape orientation constant

### .NET Migration Notes

#### Entity Requirements

- **IFRS_PlanIFRS**: IFRS chart of accounts (Codigo, Nivel, Descripcion, Clasificacion)
- **Cuentas**: Company chart of accounts (CodIFRS linking field)
- **Comprobante**: Voucher header (Estado, Fecha, TipoAjuste)
- **MovComprobante**: Voucher line items (IdCuenta, Debe, Haber)
- **Empresa**: Company master data
- **ParamEmpresa**: Company parameters (PLANCTAS)

**All entities exist in `App.Data` namespace.**

#### DTO Design

**Request DTO:**

- FechaDesde: DateTime
- FechaHasta: DateTime
- VerCodigoCuenta: bool
- MostrarSaldosVigentes: bool (non-zero only)
- IncluirMembreteEmpresa: bool (for Excel export)

**Response DTO:**

- Activos: List<BalanceEjecutivoIfrsSeccionDto>
- Pasivos: List<BalanceEjecutivoIfrsSeccionDto>
- Patrimonio: List<BalanceEjecutivoIfrsSeccionDto>
- TotalActivos: decimal
- TotalPasivos: decimal
- TotalPatrimonio: decimal
- UtilidadPerdidaNeta: decimal

**BalanceEjecutivoIfrsSeccionDto:**

- IdCuenta: long?
- Codigo: string
- Descripcion: string
- Nivel: int
- Saldo: decimal
- EsTotal: bool
- EsTitulo: bool
- EsBlanco: bool
- FormatoBold: bool

#### Service Layer

`IBalanceEjecutivoIfrsService`:

- `GenerarAsync(request)`: Main report generation
- `ExportarExcelAsync(request)`: Excel export with optional header
- `ValidarPlanCuentasAsync()`: Validate chart of accounts type
- `ValidarClasificacionIfrsAsync()`: Check for unclassified accounts

**Business Logic:**

1. Query IFRS_PlanIFRS with joins to Cuentas and MovComprobante
2. Filter by date range, approved state, adjustment types
3. Calculate hierarchical balances (Assets: Debe - Haber, Liabilities: Haber - Debe)
4. Query comprehensive income accounts (401.xx)
5. Calculate net profit/loss
6. Adjust equity balances
7. Balance equation: Total Liabilities = Total Assets
8. Split into parallel sections (Assets | Liabilities/Equity)
9. Align rows for side-by-side display

**Complex Logic:**

- Hierarchical totaling with cascading
- Comprehensive income distribution
- Equity adjustments (Otras Reservas, Ganancias Acumuladas)
- Parallel grid alignment (matching row counts)
- Zero-balance filtering with parent collapse

#### API Controller

`BalanceEjecutivoIfrsApiController`:

- `POST /api/balance-ejecutivo-ifrs/generar`: Generate report
- `POST /api/balance-ejecutivo-ifrs/exportar-excel`: Export to Excel
- `GET /api/balance-ejecutivo-ifrs/validar-plan`: Validate chart type
- `GET /api/balance-ejecutivo-ifrs/validar-clasificacion`: Check IFRS classification

#### MVC Controller

`BalanceEjecutivoIfrsController`:

- `GET /balance-ejecutivo-ifrs`: Index view
- `POST /balance-ejecutivo-ifrs/generar`: Generate report (calls API)
- `POST /balance-ejecutivo-ifrs/exportar`: Excel export action

#### UI Components (Razor + JavaScript)

**Index.cshtml:**

- Date range pickers (Desde/Hasta)
- "Ver Codificación" checkbox
- "Saldos Vigentes" checkbox
- "Listar" button
- Excel export button
- Print button

**Results Display:**

- Two-column responsive table
- Left column: Assets (Activos)
- Right column: Liabilities and Equity (Pasivos y Patrimonio)
- Aligned rows with matching totals
- Hierarchical indentation
- Bold formatting for totals and titles
- Show/hide code columns based on checkbox
- Dynamic row hiding for zero balances

**JavaScript:**

- AJAX form submission
- Dynamic two-column table rendering
- Row alignment algorithm
- Column show/hide toggle
- Excel export via downloadable blob
- Print functionality

#### Validations

1. **Date Range:** FechaDesde <= FechaHasta
2. **Required Fields:** Both dates required
3. **Chart of Accounts:** Warn if not predefined plan
4. **IFRS Classification:** Warn if accounts missing classification
5. **Data Availability:** Show message if no movements in range

#### Special Considerations

1. **Parallel Layout:** Complex row alignment between Assets and Liabilities/Equity
2. **Comprehensive Income (401.xx):** Special handling for equity adjustments
3. **Net Profit/Loss Calculation:** Assets - Liabilities - Other Reserves
4. **Equity Adjustments:** Multiple cascading calculations
5. **Balancing Equation:** Total Pasivos must equal Total Activos
6. **Zero Balance Filtering:** Parent collapse logic
7. **Formatting:** Bold for titles and totals, uppercase for level 1 and final totals
8. **Number Formatting:** Chilean format (negative in parentheses)
9. **Date Format:** Chilean format (DD/MM/YYYY)
10. **IFRS Code Format:** Custom formatting functions

#### Performance Optimization

- Use EF Core AsNoTracking for read-only queries
- Consider compiled queries for frequent use
- Implement caching for IFRS plan structure
- Database-side aggregation (GROUP BY, SUM)
- Minimize roundtrips (two queries only)

#### Testing Requirements

- Unit tests for balance calculations
- Unit tests for hierarchical totaling
- Unit tests for comprehensive income distribution
- Unit tests for equity adjustments
- Unit tests for parallel grid alignment
- Integration tests for database queries
- UI tests for form validation
- Test with different chart of accounts plans
- Test with missing IFRS classifications
- Test edge cases (no movements, single section, all zero balances)

### Migration Complexity: VERY HIGH

**Reasons:**

1. Complex parallel grid layout algorithm
2. Multiple cascading equity adjustments
3. Comprehensive income account distribution
4. Hierarchical totaling with cascading
5. Two separate queries with different purposes
6. Row alignment logic for side-by-side display
7. Zero-balance filtering with parent collapse
8. Balancing equation enforcement
9. Special formatting rules (bold, uppercase, indentation)
10. IFRS-specific validations and warnings

**Estimated Effort:** 4-5 days

**Dependencies:**

- All referenced entities must exist
- IFRS configuration system must be in place
- IFRS_PlanIFRS table fully populated
- Print/export infrastructure needed
- Comprehensive understanding of IFRS balance sheet structure

### Migration Priority

**HIGH** - Core financial reporting feature for IFRS compliance. More complex than Balance Tributario IFRS due to parallel layout and equity adjustments.

