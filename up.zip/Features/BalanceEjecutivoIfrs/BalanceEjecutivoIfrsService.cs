using App.Data;
using Microsoft.EntityFrameworkCore;

namespace App.Features.BalanceEjecutivoIfrs;

/// <summary>
/// Implementación del servicio de Balance Ejecutivo IFRS.
/// Genera un balance en formato T con distribución automática de patrimonio.
/// </summary>
public class BalanceEjecutivoIfrsService(
    LpContabContext context,
    ILogger<BalanceEjecutivoIfrsService> logger) : IBalanceEjecutivoIfrsService
{
    // Constantes de clasificación IFRS
    private const int CLASCTA_ACTIVO = 1;
    private const int CLASCTA_PASIVO = 2;
    private const int TAJUSTE_FINANCIERO = 1;
    private const int TAJUSTE_AMBOS = 3;
    private const int EC_APROBADO = 1;

    public async Task<BalanceEjecutivoIfrsResponseDto> GenerarAsync(BalanceEjecutivoIfrsRequestDto request)
    {
        logger.LogInformation("Generando Balance Ejecutivo IFRS para {FechaDesde} - {FechaHasta}",
            request.FechaDesde, request.FechaHasta);

        var fechaDesdeInt = ConvertirFechaAEntero(request.FechaDesde);
        var fechaHastaInt = ConvertirFechaAEntero(request.FechaHasta);

        // 1. Obtener movimientos de Activos y Pasivos
        var movimientos = await ObtenerMovimientosIfrsAsync(
            fechaDesdeInt, fechaHastaInt, request.IdAreaNegocio, request.IdCentroCosto);

        // 2. Obtener cuentas 401.xx (Resultado Integral)
        var resultadoIntegral = await ObtenerResultadoIntegralAsync(
            fechaDesdeInt, fechaHastaInt, request.IdAreaNegocio, request.IdCentroCosto);

        // 3. Procesar jerarquía y calcular totales
        var secciones = ProcesarJerarquiaIfrs(movimientos, resultadoIntegral, request.MostrarCodigo);

        logger.LogInformation("Balance Ejecutivo IFRS generado exitosamente: {TotalActivos} activos, {TotalPasivos} pasivos+patrimonio",
            secciones.Activos.Count, secciones.Pasivos.Count + secciones.Patrimonio.Count);

        return new BalanceEjecutivoIfrsResponseDto
        {
            Activos = secciones.Activos,
            Pasivos = secciones.Pasivos,
            Patrimonio = secciones.Patrimonio,
            TotalActivos = secciones.TotalActivos,
            TotalPasivos = secciones.TotalPasivos,
            TotalPatrimonio = secciones.TotalPatrimonio,
            Diferencia = secciones.Diferencia
        };
    }

    public async Task<(bool EsValido, string? PlanActual)> ValidarPlanCuentasAsync()
    {
        {
            // Verificar que existan cuentas con código IFRS configurado
            var tieneCuentasIfrs = await context.Cuentas
                .AnyAsync(c => !string.IsNullOrEmpty(c.CodIFRS));

            if (!tieneCuentasIfrs)
            {
                return (false, null);
            }

            // Obtener nombre del plan (si existe en ParamEmpresa)
            var planActual = await context.ParamEmpresa
                .Where(p => p.Tipo == "PLAN_CUENTAS_IFRS")
                .Select(p => p.Valor)
                .FirstOrDefaultAsync();

            return (true, planActual ?? "Plan IFRS Configurado");
        }
    }

    public async Task<bool> ExistenCuentasSinClasificacionIfrsAsync(DateTime fechaHasta)
    {
        var fechaHastaInt = ConvertirFechaAEntero(fechaHasta);

        // Buscar cuentas con movimientos pero sin código IFRS
        var existenSinClasificacion = await (
            from m in context.MovComprobante
            join c in context.Comprobante on m.IdComp equals c.IdComp
            join cta in context.Cuentas on m.IdCuenta equals cta.idCuenta
            where c.Fecha <= fechaHastaInt
                && c.Estado == EC_APROBADO
                && (string.IsNullOrEmpty(cta.CodIFRS) || cta.CodIFRS == "0")
            select m.IdMov
        ).AnyAsync();

        return existenSinClasificacion;
    }

    public async Task<List<Shared.ComboItemDto>> GetAreasNegocioAsync()
    {
        logger.LogInformation("Obteniendo áreas de negocio");

        return await context.AreaNegocio
            .OrderBy(a => a.Descripcion)
            .Select(a => new Shared.ComboItemDto
            {
                Value = a.IdAreaNegocio,
                Text = a.Descripcion ?? ""
            })
            .ToListAsync();
    }

    public async Task<List<Shared.ComboItemDto>> GetCentrosCostoAsync()
    {
        logger.LogInformation("Obteniendo centros de costo");

        return await context.CentroCosto
            .OrderBy(c => c.Descripcion)
            .Select(c => new Shared.ComboItemDto
            {
                Value = c.IdCCosto,
                Text = c.Descripcion ?? ""
            })
            .ToListAsync();
    }

    #region Métodos Privados

    private async Task<List<MovimientoIfrsDto>> ObtenerMovimientosIfrsAsync(
        int fechaDesdeInt, int fechaHastaInt, int? idAreaNegocio, int? idCentroCosto)
    {
        var query = from m in context.MovComprobante
                    join c in context.Comprobante on m.IdComp equals c.IdComp
                    join cta in context.Cuentas on m.IdCuenta equals cta.idCuenta
                    where c.Fecha >= fechaDesdeInt
                        && c.Fecha <= fechaHastaInt
                        && c.Estado == EC_APROBADO
                        && (c.TipoAjuste == TAJUSTE_FINANCIERO || c.TipoAjuste == TAJUSTE_AMBOS)
                        && !string.IsNullOrEmpty(cta.CodIFRS)
                        && cta.CodIFRS != "0"
                        && (cta.CodIFRS.StartsWith("1") || cta.CodIFRS.StartsWith("2")) // Solo Activos y Pasivos
                    select new { m, cta };

        // Filtros opcionales
        if (idAreaNegocio.HasValue)
        {
            query = query.Where(x => x.m.idAreaNeg == idAreaNegocio.Value);
        }

        if (idCentroCosto.HasValue)
        {
            query = query.Where(x => x.m.idCCosto == idCentroCosto.Value);
        }

        var movimientos = await query
            .GroupBy(x => new
            {
                x.cta.idCuenta,
                CodigoIfrs = x.cta.CodIFRS,
                x.cta.Descripcion
            })
            .Select(g => new MovimientoIfrsDto
            {
                IdCuenta = g.Key.idCuenta,
                CodigoIfrs = g.Key.CodigoIfrs ?? "",
                Descripcion = g.Key.Descripcion ?? "",
                SumDebe = g.Sum(x => x.m.Debe ?? 0),
                SumHaber = g.Sum(x => x.m.Haber ?? 0)
            })
            .ToListAsync();

        return movimientos;
    }

    private async Task<List<MovimientoIfrsDto>> ObtenerResultadoIntegralAsync(
        int fechaDesdeInt, int fechaHastaInt, int? idAreaNegocio, int? idCentroCosto)
    {
        // Cuentas 401.xx del Resultado Integral
        var query = from m in context.MovComprobante
                    join c in context.Comprobante on m.IdComp equals c.IdComp
                    join cta in context.Cuentas on m.IdCuenta equals cta.idCuenta
                    where c.Fecha >= fechaDesdeInt
                        && c.Fecha <= fechaHastaInt
                        && c.Estado == EC_APROBADO
                        && (c.TipoAjuste == TAJUSTE_FINANCIERO || c.TipoAjuste == TAJUSTE_AMBOS)
                        && !string.IsNullOrEmpty(cta.CodIFRS)
                        && cta.CodIFRS.StartsWith("401")
                    select new { m, cta };

        // Filtros opcionales
        if (idAreaNegocio.HasValue)
        {
            query = query.Where(x => x.m.idAreaNeg == idAreaNegocio.Value);
        }

        if (idCentroCosto.HasValue)
        {
            query = query.Where(x => x.m.idCCosto == idCentroCosto.Value);
        }

        var resultadoIntegral = await query
            .GroupBy(x => new
            {
                x.cta.idCuenta,
                CodigoIfrs = x.cta.CodIFRS,
                x.cta.Descripcion
            })
            .Select(g => new MovimientoIfrsDto
            {
                IdCuenta = g.Key.idCuenta,
                CodigoIfrs = g.Key.CodigoIfrs ?? "",
                Descripcion = g.Key.Descripcion ?? "",
                SumDebe = g.Sum(x => x.m.Debe ?? 0),
                SumHaber = g.Sum(x => x.m.Haber ?? 0)
            })
            .ToListAsync();

        return resultadoIntegral;
    }

    private (
        List<BalanceEjecutivoIfrsLineaDto> Activos,
        List<BalanceEjecutivoIfrsLineaDto> Pasivos,
        List<BalanceEjecutivoIfrsLineaDto> Patrimonio,
        double TotalActivos,
        double TotalPasivos,
        double TotalPatrimonio,
        double Diferencia
    ) ProcesarJerarquiaIfrs(
        List<MovimientoIfrsDto> movimientos,
        List<MovimientoIfrsDto> resultadoIntegral,
        bool mostrarCodigo)
    {
        var activos = new List<BalanceEjecutivoIfrsLineaDto>();
        var pasivos = new List<BalanceEjecutivoIfrsLineaDto>();
        var patrimonio = new List<BalanceEjecutivoIfrsLineaDto>();

        // Diccionario para acumular totales por nivel
        var totalesPorCodigo = new Dictionary<string, TotalesNivel>();

        // 1. Procesar movimientos (Activos y Pasivos)
        foreach (var mov in movimientos)
        {
            var nivel = ObtenerNivelIfrs(mov.CodigoIfrs);
            var clasificacion = ObtenerClasificacionIfrs(mov.CodigoIfrs);
            
            // Calcular saldo según clasificación
            double saldo = clasificacion == CLASCTA_ACTIVO
                ? mov.SumDebe - mov.SumHaber  // Activo: Debe - Haber
                : mov.SumHaber - mov.SumDebe; // Pasivo: Haber - Debe

            // Acumular en niveles superiores
            AcumularTotalesPorNiveles(totalesPorCodigo, mov.CodigoIfrs, saldo);

            // Crear línea
            var linea = new BalanceEjecutivoIfrsLineaDto
            {
                Codigo = mostrarCodigo ? mov.CodigoIfrs : "",
                Descripcion = FormatearDescripcion(mov.Descripcion, nivel, mov.CodigoIfrs),
                Saldo = saldo,
                Nivel = nivel,
                EsTotal = mov.CodigoIfrs.EndsWith("00") || nivel <= 2,
                Clasificacion = clasificacion
            };

            // Distribuir según clasificación
            if (clasificacion == CLASCTA_ACTIVO)
            {
                activos.Add(linea);
            }
            else if (clasificacion == CLASCTA_PASIVO)
            {
                // Los pasivos se separarán posteriormente entre Pasivos reales y Patrimonio
                pasivos.Add(linea);
            }
        }

        // 2. Procesar Resultado Integral (401.xx) y agregarlo a Patrimonio
        var totReservas = 0.0;
        foreach (var res in resultadoIntegral)
        {
            var saldo = res.SumHaber - res.SumDebe;
            totReservas += saldo;

            var linea = new BalanceEjecutivoIfrsLineaDto
            {
                Codigo = mostrarCodigo ? res.CodigoIfrs : "",
                Descripcion = FormatearDescripcion(res.Descripcion, 5, res.CodigoIfrs),
                Saldo = saldo,
                Nivel = 5,
                EsTotal = false,
                Clasificacion = CLASCTA_PASIVO
            };

            patrimonio.Add(linea);
        }

        // 3. Separar Pasivos reales de Patrimonio (asumimos que códigos 2.3.xx son patrimonio)
        var pasivosReales = pasivos.Where(p => !p.Codigo.StartsWith("2.3")).ToList();
        var patrimonioBase = pasivos.Where(p => p.Codigo.StartsWith("2.3")).ToList();
        patrimonio.InsertRange(0, patrimonioBase);

        // 4. Calcular totales
        var totalActivos = activos.Where(a => a.Nivel == 1).Sum(a => a.Saldo);
        var totalPasivosReales = pasivosReales.Where(p => p.Nivel == 1 || p.Codigo.StartsWith("2.1") || p.Codigo.StartsWith("2.2")).Sum(p => p.Saldo);
        
        // 5. Ajustar Patrimonio con Utilidad/Pérdida
        var utilidadPerdida = totalActivos - totalPasivosReales - totReservas;
        
        patrimonio.Add(new BalanceEjecutivoIfrsLineaDto
        {
            Codigo = mostrarCodigo ? "2.3.99" : "",
            Descripcion = utilidadPerdida >= 0 ? "UTILIDAD DEL EJERCICIO" : "PÉRDIDA DEL EJERCICIO",
            Saldo = Math.Abs(utilidadPerdida),
            Nivel = 3,
            EsTotal = true,
            Clasificacion = CLASCTA_PASIVO
        });

        var totalPatrimonio = patrimonio.Sum(p => p.Saldo);
        var totalPasivos = totalPasivosReales + totalPatrimonio;

        // Línea de total patrimonio
        patrimonio.Insert(0, new BalanceEjecutivoIfrsLineaDto
        {
            Codigo = "",
            Descripcion = "PATRIMONIO",
            Saldo = totalPatrimonio,
            Nivel = 1,
            EsTotal = true,
            Clasificacion = CLASCTA_PASIVO
        });

        return (activos, pasivosReales, patrimonio, totalActivos, totalPasivos, totalPatrimonio, totalActivos - totalPasivos);
    }

    private void AcumularTotalesPorNiveles(
        Dictionary<string, TotalesNivel> totalesPorCodigo,
        string codigo,
        double saldo)
    {
        var nivel = ObtenerNivelIfrs(codigo);

        // Acumular en este nivel
        if (!totalesPorCodigo.ContainsKey(codigo))
        {
            totalesPorCodigo[codigo] = new TotalesNivel();
        }
        totalesPorCodigo[codigo].Saldo += saldo;

        // Acumular en niveles superiores
        for (int i = nivel - 1; i >= 1; i--)
        {
            var codigoPadre = ObtenerCodigoPadre(codigo, i);
            if (!totalesPorCodigo.ContainsKey(codigoPadre))
            {
                totalesPorCodigo[codigoPadre] = new TotalesNivel();
            }
            totalesPorCodigo[codigoPadre].Saldo += saldo;
        }
    }

    private int ObtenerNivelIfrs(string codigoIfrs)
    {
        if (string.IsNullOrEmpty(codigoIfrs)) return 0;
        return codigoIfrs.Split('.').Length;
    }

    private int ObtenerClasificacionIfrs(string codigoIfrs)
    {
        if (string.IsNullOrEmpty(codigoIfrs)) return 0;
        
        var primerDigito = codigoIfrs[0];
        return primerDigito switch
        {
            '1' => CLASCTA_ACTIVO,
            '2' => CLASCTA_PASIVO,
            _ => 0
        };
    }

    private string ObtenerCodigoPadre(string codigo, int nivelDeseado)
    {
        var partes = codigo.Split('.');
        if (partes.Length <= nivelDeseado) return codigo;
        
        return string.Join(".", partes.Take(nivelDeseado));
    }

    private string FormatearDescripcion(string descripcion, int nivel, string codigo)
    {
        if (string.IsNullOrEmpty(descripcion)) return "";

        // Niveles 1 y 2 en mayúsculas
        if (nivel <= 2)
        {
            return descripcion.ToUpperInvariant();
        }

        // Códigos que terminan en "00" en formato título
        if (codigo.EndsWith("00"))
        {
            return System.Globalization.CultureInfo.CurrentCulture.TextInfo.ToTitleCase(descripcion.ToLowerInvariant());
        }

        return descripcion;
    }

    private static int ConvertirFechaAEntero(DateTime fecha)
    {
        return (int)fecha.ToOADate();
    }

    #endregion

    #region Clases Auxiliares

    private class TotalesNivel
    {
        public double Saldo { get; set; }
    }

    private class MovimientoIfrsDto
    {
        public int IdCuenta { get; set; }
        public string CodigoIfrs { get; set; } = "";
        public string Descripcion { get; set; } = "";
        public double SumDebe { get; set; }
        public double SumHaber { get; set; }
    }

    #endregion
}
