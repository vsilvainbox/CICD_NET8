namespace App.Features.Ayuda;

/// <summary>
/// Implementación del servicio de sistema de ayuda
/// Proporciona contenido estático de ayuda basado en el formulario VB6 original
/// </summary>
public class AyudaService(ILogger<AyudaService> logger) : IAyudaService
{
    /// <summary>
    /// Obtiene el contenido de ayuda para ajustes de aumentos (14D3)
    /// Replica exactamente el contenido del Frame 1 del formulario VB6
    /// </summary>
    public async Task<AyudaContentDto> GetAjustesAumentosAsync(string contexto = "")
    {
        logger.LogInformation("Getting ajustes aumentos help content for context: {Contexto}", contexto);

        {
            var content = new AyudaContentDto
            {
                Titulo = !string.IsNullOrEmpty(contexto) ? $"Ayuda - {contexto}" : "Ejemplos de Otros Ajustes (Aumentos)",
                Descripcion = "Ejemplos de ajustes que incrementan la base imponible en declaraciones tributarias.",
                Items = new List<AyudaItemDto>
                {
                    new AyudaItemDto
                    {
                        Codigo = "14D3-001",
                        Categoria = "SOLO 14D3",
                        TipoOperacion = "+",
                        Descripcion = "Ingresos no rentas generadas por la empresa",
                        Detalle = "Ingresos que no constituyen renta según la legislación tributaria pero que deben ser considerados para efectos del formulario 14D3."
                    },
                    new AyudaItemDto
                    {
                        Codigo = "14D3-002",
                        Categoria = "SOLO 14D3",
                        TipoOperacion = "+",
                        Descripcion = "Ingresos exentos de IDPC",
                        Detalle = "Ingresos que están exentos del Impuesto de Primera Categoría pero que deben agregarse en el formulario 14D3."
                    },
                    new AyudaItemDto
                    {
                        Codigo = "14D3-003",
                        Categoria = "SOLO 14D3",
                        TipoOperacion = "+",
                        Descripcion = "Franquicia Letra E, art 14 LIR",
                        Detalle = "Beneficios tributarios contemplados en la letra E del artículo 14 de la Ley de Impuesto a la Renta que deben agregarse."
                    },
                    new AyudaItemDto
                    {
                        Codigo = "14D3-004",
                        Categoria = "SOLO 14D3",
                        TipoOperacion = "+",
                        Descripcion = "Reposición deducción por pago IDPC Voluntario en años anteriores",
                        Detalle = "Ajuste por reposición de deducciones efectuadas en ejercicios anteriores por pagos voluntarios de IDPC."
                    }
                }
            };

            logger.LogInformation("Successfully generated ajustes aumentos content with {Count} items", content.Items.Count);
            return await Task.FromResult(content);
        }
    }

    /// <summary>
    /// Obtiene el contenido de ayuda para ajustes de disminuciones (14D8)
    /// Replica exactamente el contenido del Frame 2 del formulario VB6
    /// </summary>
    public async Task<AyudaContentDto> GetAjustesDisminucionesAsync(string contexto = "")
    {
        logger.LogInformation("Getting ajustes disminuciones help content for context: {Contexto}", contexto);

        {
            var content = new AyudaContentDto
            {
                Titulo = !string.IsNullOrEmpty(contexto) ? $"Ayuda - {contexto}" : "Ejemplos de Otros Ajustes (Disminuciones)",
                Descripcion = "Ejemplos de ajustes que disminuyen la base imponible en declaraciones tributarias.",
                Items = new List<AyudaItemDto>
                {
                    new AyudaItemDto
                    {
                        Codigo = "AMBOS-001",
                        Categoria = "AMBOS",
                        TipoOperacion = "-",
                        Descripcion = "Ingreso diferido imputado en el ejercicio",
                        Detalle = "Ingresos diferidos que se imputan al ejercicio actual y que deben disminuirse tanto en 14D3 como en 14D8."
                    },
                    new AyudaItemDto
                    {
                        Codigo = "AMBOS-002",
                        Categoria = "AMBOS",
                        TipoOperacion = "-",
                        Descripcion = "Crédito total disponible por IPE",
                        Detalle = "Crédito total disponible por Impuesto Adicional que debe considerarse como disminución en ambos formularios."
                    },
                    new AyudaItemDto
                    {
                        Codigo = "14D8-001",
                        Categoria = "SOLO 14D8",
                        TipoOperacion = "-",
                        Descripcion = "Incremento asociado a retiros o dividendos recibidos",
                        Detalle = "Incrementos relacionados con retiros o dividendos recibidos que solo aplican como disminución en el formulario 14D8."
                    }
                }
            };

            logger.LogInformation("Successfully generated ajustes disminuciones content with {Count} items", content.Items.Count);
            return await Task.FromResult(content);
        }
    }

    /// <summary>
    /// Obtiene todos los tipos de ayuda disponibles
    /// </summary>
    public async Task<IEnumerable<AyudaTipoDto>> GetTiposAyudaAsync()
    {
        logger.LogInformation("Getting all available help types");

        {
            var tipos = new List<AyudaTipoDto>
            {
                new AyudaTipoDto
                {
                    Id = (int)TipoAyuda.AjustesAumentos,
                    Nombre = "Ajustes de Aumentos",
                    Descripcion = "Ejemplos de ajustes que incrementan la base imponible",
                    Icono = "fas fa-plus-circle"
                },
                new AyudaTipoDto
                {
                    Id = (int)TipoAyuda.AjustesDisminuciones,
                    Nombre = "Ajustes de Disminuciones",
                    Descripcion = "Ejemplos de ajustes que disminuyen la base imponible",
                    Icono = "fas fa-minus-circle"
                }
            };

            logger.LogInformation("Successfully retrieved {Count} help types", tipos.Count);
            return await Task.FromResult(tipos);
        }
    }

    /// <summary>
    /// Obtiene contenido de ayuda por tipo específico
    /// </summary>
    public async Task<AyudaContentDto> GetContenidoPorTipoAsync(TipoAyuda tipoAyuda, string contexto = "")
    {
        logger.LogInformation("Getting help content for type: {TipoAyuda}, context: {Contexto}", tipoAyuda, contexto);

        {
            return tipoAyuda switch
            {
                TipoAyuda.AjustesAumentos => await GetAjustesAumentosAsync(contexto),
                TipoAyuda.AjustesDisminuciones => await GetAjustesDisminucionesAsync(contexto),
                _ => throw new ArgumentException($"Tipo de ayuda no válido: {tipoAyuda}")
            };
        }
    }

    /// <summary>
    /// Verifica si un tipo de ayuda existe y está disponible
    /// </summary>
    public async Task<bool> ExisteTipoAyudaAsync(TipoAyuda tipoAyuda)
    {
        logger.LogDebug("Checking if help type exists: {TipoAyuda}", tipoAyuda);

        {
            var esValido = Enum.IsDefined(typeof(TipoAyuda), tipoAyuda);
                
            if (esValido)
            {
                logger.LogDebug("Help type {TipoAyuda} exists and is valid", tipoAyuda);
            }
            else
            {
                logger.LogWarning("Help type {TipoAyuda} does not exist or is invalid", tipoAyuda);
            }

            return await Task.FromResult(esValido);
        }
    }
}