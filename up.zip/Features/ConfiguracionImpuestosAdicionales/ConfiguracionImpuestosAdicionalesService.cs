using App.Data;
using Microsoft.EntityFrameworkCore;

namespace App.Features.ConfiguracionImpuestosAdicionales;

/// <summary>
/// Servicio para gestión de configuración de impuestos adicionales
/// </summary>
public class ConfiguracionImpuestosAdicionalesService(
    LpContabContext context,
    ILogger<ConfiguracionImpuestosAdicionalesService> logger) : IConfiguracionImpuestosAdicionalesService
{
    // Constantes de tipos de libro
    private const byte LIB_COMPRAS = 1;
    private const byte LIB_VENTAS = 2;
    private const byte LIBCOMPRAS_OTROSIMP = 15; // Código base para otros impuestos en compras
    private const byte LIBVENTAS_OTROSIMP = 15;  // Código base para otros impuestos en ventas

    /// <inheritdoc/>
    public async Task<ConfiguracionImpuestosResponse> GetConfiguracionAsync(GetConfiguracionRequest request)
    {
        {
            logger.LogInformation("Obteniendo configuración de impuestos adicionales para Empresa: {EmpresaId}, Año: {Ano}, TipoLib: {TipoLib}",
                request.EmpresaId, request.Ano, request.TipoLib);

            // Obtener tipos de valores disponibles
            var tiposValores = await GetTiposValoresDisponiblesAsync(request.TipoLib);

            // Obtener configuración existente
            var configuracionExistente = await context.ImpAdic
                .Where(i => i.IdEmpresa == request.EmpresaId
                            && i.Ano == request.Ano
                            && i.TipoLib == request.TipoLib)
                .ToListAsync();

            var impuestos = new List<ImpuestoAdicionalDto>();

            foreach (var tipoValor in tiposValores)
            {
                var configExistente = configuracionExistente
                    .FirstOrDefault(c => c.TipoValor == tipoValor.Codigo);

                var impuesto = new ImpuestoAdicionalDto
                {
                    IdImpAdic = configExistente?.IdImpAdic ?? 0,
                    IdEmpresa = request.EmpresaId,
                    Ano = request.Ano,
                    TipoLib = request.TipoLib,
                    TipoValor = tipoValor.Codigo,
                    CodigoSII = tipoValor.CodSIIDTE,
                    NombreTipoValor = string.IsNullOrWhiteSpace(tipoValor.TitCompleto)
                        ? tipoValor.Valor
                        : tipoValor.TitCompleto,
                    TipoDocAplica = tipoValor.TipoDoc,
                    TasaFija = tipoValor.Tasa.HasValue ? tipoValor.Tasa.Value : null,
                    TasaEditable = !tipoValor.Tasa.HasValue || tipoValor.Tasa.Value == 0,
                    Aplica = configExistente != null
                };

                if (configExistente != null)
                {
                    impuesto.IdCuenta = configExistente.IdCuenta;
                    impuesto.CodCuenta = configExistente.CodCuenta;
                    impuesto.Tasa = configExistente.Tasa.HasValue ? configExistente.Tasa.Value : null;
                    impuesto.EsRecuperable = configExistente.EsRecuperable == true;

                    // Obtener descripción de cuenta si existe
                    if (configExistente.IdCuenta.HasValue && configExistente.IdCuenta.Value > 0)
                    {
                        var cuenta = await context.Cuentas
                            .FirstOrDefaultAsync(c => c.idCuenta == configExistente.IdCuenta.Value
                                                      && c.IdEmpresa == request.EmpresaId
                                                      && c.Ano == request.Ano);

                        impuesto.DescripcionCuenta = cuenta?.Descripcion;
                    }
                }
                else
                {
                    // Valores por defecto desde TipoValor
                    impuesto.Tasa = tipoValor.Tasa.HasValue ? tipoValor.Tasa.Value : null;
                    impuesto.EsRecuperable = tipoValor.EsRecuperable == true;
                }

                impuestos.Add(impuesto);
            }

            return new ConfiguracionImpuestosResponse
            {
                Success = true,
                Impuestos = impuestos
            };
        }
    }

    /// <inheritdoc/>
    public async Task<ConfiguracionImpuestosResponse> SaveConfiguracionAsync(SaveConfiguracionRequest request)
    {
        using var transaction = await context.Database.BeginTransactionAsync();
        {
            logger.LogInformation("Guardando configuración de impuestos adicionales para Empresa: {EmpresaId}, Año: {Ano}",
                request.EmpresaId, request.Ano);

            foreach (var impuesto in request.Impuestos)
            {
                if (!impuesto.Aplica)
                {
                    // Si no aplica y existe en BD, eliminarlo
                    if (impuesto.IdImpAdic > 0)
                    {
                        var existente = await context.ImpAdic
                            .FirstOrDefaultAsync(i => i.IdImpAdic == impuesto.IdImpAdic
                                                      && i.IdEmpresa == request.EmpresaId
                                                      && i.Ano == request.Ano);
                        if (existente != null)
                        {
                            context.ImpAdic.Remove(existente);
                        }
                    }
                    continue;
                }

                // Validar que tenga cuenta asignada
                if (!impuesto.IdCuenta.HasValue || impuesto.IdCuenta.Value == 0)
                {
                    return new ConfiguracionImpuestosResponse
                    {
                        Success = false,
                        Message = $"El impuesto '{impuesto.NombreTipoValor}' no tiene cuenta asignada"
                    };
                }

                if (impuesto.IdImpAdic > 0)
                {
                    // Actualizar existente
                    var existente = await context.ImpAdic
                        .FirstOrDefaultAsync(i => i.IdImpAdic == impuesto.IdImpAdic
                                                  && i.IdEmpresa == request.EmpresaId
                                                  && i.Ano == request.Ano);

                    if (existente != null)
                    {
                        existente.IdCuenta = impuesto.IdCuenta;
                        existente.CodCuenta = impuesto.CodCuenta;
                        existente.Tasa = impuesto.Tasa.HasValue ? (float?)impuesto.Tasa.Value : null;
                        existente.EsRecuperable = impuesto.EsRecuperable;
                    }
                }
                else
                {
                    // Crear nuevo
                    var nuevo = new App.Data.ImpAdic
                    {
                        IdEmpresa = request.EmpresaId,
                        Ano = request.Ano,
                        TipoLib = request.TipoLib,
                        TipoValor = (short)impuesto.TipoValor,
                        IdCuenta = impuesto.IdCuenta,
                        CodCuenta = impuesto.CodCuenta,
                        Tasa = impuesto.Tasa.HasValue ? (float?)impuesto.Tasa.Value : null,
                        EsRecuperable = impuesto.EsRecuperable
                    };

                    context.ImpAdic.Add(nuevo);
                }
            }

            await context.SaveChangesAsync();
            await transaction.CommitAsync();

            logger.LogInformation("Configuración guardada exitosamente");

            return new ConfiguracionImpuestosResponse
            {
                Success = true,
                Message = "Configuración guardada exitosamente"
            };
        }
    }

    /// <inheritdoc/>
    public async Task<List<TipoValorDisponibleDto>> GetTiposValoresDisponiblesAsync(byte tipoLib)
    {
        {
            var baseImp = tipoLib == LIB_COMPRAS ? LIBCOMPRAS_OTROSIMP : LIBVENTAS_OTROSIMP;

            var tiposValores = await context.TipoValor
                .Where(tv => tv.TipoLib == tipoLib
                             && tv.Codigo > baseImp
                             && (tv.Atributo == null ||
                                 (tv.Atributo != "SINUSO" && tv.Atributo != "IVAIRREC" && tv.Atributo != "IVAACTFIJO")))
                .OrderBy(tv => tv.Orden)
                .ThenBy(tv => tv.Valor)
                .Select(tv => new TipoValorDisponibleDto
                {
                    IdTValor = tv.idTValor,
                    TipoLib = tv.TipoLib ?? 0,
                    Codigo = tv.Codigo ?? 0,
                    Valor = tv.Valor,
                    CodSIIDTE = tv.CodSIIDTE,
                    Tasa = tv.Tasa,
                    EsRecuperable = tv.EsRecuperable == true,
                    TipoDoc = tv.TipoDoc,
                    TitCompleto = tv.TitCompleto,
                    Atributo = tv.Atributo
                })
                .ToListAsync();

            return tiposValores;
        }
    }

    /// <inheritdoc/>
    public async Task<List<ImpuestoAdicionalDto>> GetImpuestosParaSeleccionAsync(SeleccionarImpuestosRequest request)
    {
        {
            var impuestosConfigurados = await context.ImpAdic
                .Where(i => i.IdEmpresa == request.EmpresaId
                            && i.Ano == request.Ano
                            && i.TipoLib == request.TipoLib
                            && i.IdCuenta.HasValue
                            && i.IdCuenta.Value > 0)
                .Join(context.TipoValor,
                    imp => new { TipoLib = (byte?)imp.TipoLib, Codigo = (byte?)imp.TipoValor },
                    tv => new { TipoLib = tv.TipoLib, Codigo = tv.Codigo },
                    (imp, tv) => new { imp, tv })
                .Where(x => x.tv.TipoDoc != null && x.tv.TipoDoc.Contains($",{request.TipoDoc},"))
                .Select(x => new ImpuestoAdicionalDto
                {
                    IdImpAdic = x.imp.IdImpAdic,
                    IdEmpresa = x.imp.IdEmpresa,
                    Ano = x.imp.Ano,
                    TipoLib = x.imp.TipoLib,
                    TipoValor = x.imp.TipoValor,
                    IdCuenta = x.imp.IdCuenta,
                    CodCuenta = x.imp.CodCuenta,
                    Tasa = x.imp.Tasa.HasValue ? x.imp.Tasa.Value : null,
                    EsRecuperable = x.imp.EsRecuperable == true,
                    CodigoSII = x.tv.CodSIIDTE,
                    NombreTipoValor = string.IsNullOrWhiteSpace(x.tv.TitCompleto) ? x.tv.Valor : x.tv.TitCompleto,
                    TipoDocAplica = x.tv.TipoDoc,
                    TasaFija = x.tv.Tasa.HasValue ? x.tv.Tasa.Value : null,
                    TasaEditable = !x.tv.Tasa.HasValue || x.tv.Tasa.Value == 0,
                    Aplica = true
                })
                .ToListAsync();

            // Obtener descripciones de cuentas
            foreach (var impuesto in impuestosConfigurados)
            {
                if (impuesto.IdCuenta.HasValue && impuesto.IdCuenta.Value > 0)
                {
                    var cuenta = await context.Cuentas
                        .FirstOrDefaultAsync(c => c.idCuenta == impuesto.IdCuenta.Value
                                                  && c.IdEmpresa == request.EmpresaId
                                                  && c.Ano == request.Ano);

                    impuesto.DescripcionCuenta = cuenta?.Descripcion;
                }
            }

            return impuestosConfigurados;
        }
    }

    /// <inheritdoc/>
    public async Task<ConfiguracionImpuestosResponse> AsignarCuentaAsync(AsignarCuentaRequest request)
    {
        {
            // Verificar que la cuenta exista y sea de último nivel
            var cuenta = await context.Cuentas
                .FirstOrDefaultAsync(c => c.idCuenta == request.IdCuenta
                                          && c.IdEmpresa == request.EmpresaId
                                          && c.Ano == request.Ano);

            if (cuenta == null)
            {
                return new ConfiguracionImpuestosResponse
                {
                    Success = false,
                    Message = "La cuenta seleccionada no existe"
                };
            }

            // Verificar si ya existe configuración
            var impuestoExistente = await context.ImpAdic
                .FirstOrDefaultAsync(i => i.IdEmpresa == request.EmpresaId
                                          && i.Ano == request.Ano
                                          && i.TipoLib == request.TipoLib
                                          && i.TipoValor == request.TipoValor);

            if (impuestoExistente != null)
            {
                // Actualizar
                impuestoExistente.IdCuenta = request.IdCuenta;
                impuestoExistente.CodCuenta = request.CodCuenta;
                impuestoExistente.Tasa = request.Tasa.HasValue ? (float?)request.Tasa.Value : null;
                impuestoExistente.EsRecuperable = request.EsRecuperable;
            }
            else
            {
                // Crear nuevo
                var nuevo = new App.Data.ImpAdic
                {
                    IdEmpresa = request.EmpresaId,
                    Ano = request.Ano,
                    TipoLib = request.TipoLib,
                    TipoValor = request.TipoValor,
                    IdCuenta = request.IdCuenta,
                    CodCuenta = request.CodCuenta,
                    Tasa = request.Tasa.HasValue ? (float?)request.Tasa.Value : null,
                    EsRecuperable = request.EsRecuperable
                };

                context.ImpAdic.Add(nuevo);
            }

            await context.SaveChangesAsync();

            return new ConfiguracionImpuestosResponse
            {
                Success = true,
                Message = "Cuenta asignada exitosamente"
            };
        }
    }

    /// <inheritdoc/>
    public async Task<ConfiguracionImpuestosResponse> EliminarImpuestoAsync(EliminarImpuestoRequest request)
    {
        {
            var impuesto = await context.ImpAdic
                .FirstOrDefaultAsync(i => i.IdImpAdic == request.IdImpAdic
                                          && i.IdEmpresa == request.EmpresaId
                                          && i.Ano == request.Ano);

            if (impuesto == null)
            {
                return new ConfiguracionImpuestosResponse
                {
                    Success = false,
                    Message = "El impuesto no existe"
                };
            }

            context.ImpAdic.Remove(impuesto);
            await context.SaveChangesAsync();

            return new ConfiguracionImpuestosResponse
            {
                Success = true,
                Message = "Impuesto eliminado exitosamente"
            };
        }
    }

    /// <inheritdoc/>
    public async Task<ConfiguracionImpuestosResponse> CopiarConfiguracionAsync(CopiarConfiguracionRequest request)
    {
        using var transaction = await context.Database.BeginTransactionAsync();
        {
            logger.LogInformation("Copiando configuración de empresa {Origen} a empresa {Destino}",
                request.EmpresaOrigenId, request.EmpresaDestinoId);

            // Obtener configuración origen
            var configuracionOrigen = await context.ImpAdic
                .Where(i => i.IdEmpresa == request.EmpresaOrigenId
                            && i.Ano == request.Ano
                            && i.TipoLib == request.TipoLib)
                .ToListAsync();

            if (!configuracionOrigen.Any())
            {
                return new ConfiguracionImpuestosResponse
                {
                    Success = false,
                    Message = "No hay configuración para copiar en la empresa origen"
                };
            }

            // Eliminar configuración existente en destino
            var configuracionDestino = await context.ImpAdic
                .Where(i => i.IdEmpresa == request.EmpresaDestinoId
                            && i.Ano == request.Ano
                            && i.TipoLib == request.TipoLib)
                .ToListAsync();

            context.ImpAdic.RemoveRange(configuracionDestino);

            // Copiar configuración
            foreach (var impuestoOrigen in configuracionOrigen)
            {
                var nuevoImpuesto = new App.Data.ImpAdic
                {
                    IdEmpresa = request.EmpresaDestinoId,
                    Ano = request.Ano,
                    TipoLib = impuestoOrigen.TipoLib,
                    TipoValor = impuestoOrigen.TipoValor,
                    IdCuenta = impuestoOrigen.IdCuenta,
                    CodCuenta = impuestoOrigen.CodCuenta,
                    Tasa = impuestoOrigen.Tasa,
                    EsRecuperable = impuestoOrigen.EsRecuperable
                };

                context.ImpAdic.Add(nuevoImpuesto);
            }

            await context.SaveChangesAsync();
            await transaction.CommitAsync();

            logger.LogInformation("Configuración copiada exitosamente");

            return new ConfiguracionImpuestosResponse
            {
                Success = true,
                Message = $"Se copiaron {configuracionOrigen.Count} impuestos exitosamente"
            };
        }
    }

    /// <inheritdoc/>
    public async Task<(bool isValid, string message)> ValidarImpuestoAsync(int empresaId, short ano, byte tipoLib, short tipoValor)
    {
        {
            var impuesto = await context.ImpAdic
                .FirstOrDefaultAsync(i => i.IdEmpresa == empresaId
                                          && i.Ano == ano
                                          && i.TipoLib == tipoLib
                                          && i.TipoValor == tipoValor);

            if (impuesto == null)
            {
                return (false, "El impuesto no está configurado");
            }

            if (!impuesto.IdCuenta.HasValue || impuesto.IdCuenta.Value == 0)
            {
                return (false, "El impuesto no tiene cuenta contable asignada");
            }

            if (!impuesto.Tasa.HasValue || impuesto.Tasa.Value < 0)
            {
                return (false, "El impuesto no tiene tasa asignada");
            }

            return (true, "Impuesto válido");
        }
    }
}