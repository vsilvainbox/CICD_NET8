using System.ComponentModel.DataAnnotations;

namespace App.Features.ConfiguracionImpuestosAdicionales;

/// <summary>
/// DTO para configuración de impuesto adicional
/// </summary>
public class ImpuestoAdicionalDto
{
    public int IdImpAdic { get; set; }
    public int? IdEmpresa { get; set; }
    public short Ano { get; set; }
    public short? TipoLib { get; set; }
    public short? TipoValor { get; set; }
    public int? IdCuenta { get; set; }
    public double? Tasa { get; set; }
    public bool EsRecuperable { get; set; }
    public string? CodCuenta { get; set; }

    // Campos adicionales desde TipoValor
    public string? CodigoSII { get; set; }
    public string? NombreTipoValor { get; set; }
    public string? TipoDocAplica { get; set; }
    public double? TasaFija { get; set; }
    public bool TasaEditable { get; set; }
    public string? DescripcionCuenta { get; set; }
    public bool Aplica { get; set; }
}

/// <summary>
/// Request para obtener configuración de impuestos adicionales
/// </summary>
public class GetConfiguracionRequest
{
    [Required]
    public int EmpresaId { get; set; }

    [Required]
    public short Ano { get; set; }

    [Required]
    public byte TipoLib { get; set; }
}

/// <summary>
/// Request para guardar configuración de impuestos adicionales
/// </summary>
public class SaveConfiguracionRequest
{
    [Required]
    public int EmpresaId { get; set; }

    [Required]
    public short Ano { get; set; }

    [Required]
    public byte TipoLib { get; set; }

    [Required]
    public List<ImpuestoAdicionalDto> Impuestos { get; set; } = new List<ImpuestoAdicionalDto>();

    public bool OcultarDescontinuados { get; set; }
}

/// <summary>
/// Response con configuración de impuestos
/// </summary>
public class ConfiguracionImpuestosResponse
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public List<ImpuestoAdicionalDto> Impuestos { get; set; } = new List<ImpuestoAdicionalDto>();
    public bool OcultarDescontinuados { get; set; }
}

/// <summary>
/// Request para seleccionar impuestos para documento
/// </summary>
public class SeleccionarImpuestosRequest
{
    [Required]
    public int EmpresaId { get; set; }

    [Required]
    public short Ano { get; set; }

    [Required]
    public byte TipoLib { get; set; }

    [Required]
    public byte TipoDoc { get; set; }
}

/// <summary>
/// Request para copiar configuración de otra empresa
/// </summary>
public class CopiarConfiguracionRequest
{
    [Required]
    public int EmpresaOrigenId { get; set; }

    [Required]
    public int EmpresaDestinoId { get; set; }

    [Required]
    public short Ano { get; set; }

    [Required]
    public byte TipoLib { get; set; }
}

/// <summary>
/// Datos de cuenta para asignar a impuesto
/// </summary>
public class AsignarCuentaRequest
{
    [Required]
    public int EmpresaId { get; set; }

    [Required]
    public short Ano { get; set; }

    [Required]
    public byte TipoLib { get; set; }

    [Required]
    public short TipoValor { get; set; }

    [Required]
    public int IdCuenta { get; set; }

    public string? CodCuenta { get; set; }
    public double? Tasa { get; set; }
    public bool EsRecuperable { get; set; }
}

/// <summary>
/// Request para eliminar configuración de impuesto
/// </summary>
public class EliminarImpuestoRequest
{
    [Required]
    public int IdImpAdic { get; set; }

    [Required]
    public int EmpresaId { get; set; }

    [Required]
    public short Ano { get; set; }
}

/// <summary>
/// Tipo de valor (impuesto) disponible
/// </summary>
public class TipoValorDisponibleDto
{
    public int IdTValor { get; set; }
    public byte TipoLib { get; set; }
    public byte Codigo { get; set; }
    public string? Valor { get; set; }
    public string? CodSIIDTE { get; set; }
    public float? Tasa { get; set; }
    public bool EsRecuperable { get; set; }
    public string? TipoDoc { get; set; }
    public string? TitCompleto { get; set; }
    public string? Atributo { get; set; }
}