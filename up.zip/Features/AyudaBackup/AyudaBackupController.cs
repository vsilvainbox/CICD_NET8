using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using App.Extensions;

namespace App.Features.AyudaBackup;

[Authorize]

public class AyudaBackupController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<AyudaBackupController> logger) : Controller
{
    /// <summary>
    /// Muestra el diálogo de ayuda para backup
    /// Replica la funcionalidad del formulario VB6 FrmHlpBackup
    /// </summary>
    /// <returns>Vista con contenido de ayuda dinámico</returns>
    public async Task<IActionResult> Index()
    {
        logger.LogInformation("Loading AyudaBackup index");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AyudaBackupApiController.GetHelpContent),
                controller: nameof(AyudaBackupApiController).Replace("Controller", "")
            );
            var helpContent = await client.GetFromApiAsync<AyudaBackupDto>(url!);

            logger.LogInformation("Successfully loaded help content for app: {AppTitle}", helpContent?.ApplicationTitle);
            return View(helpContent);
        }
    }

    /// <summary>
    /// Método proxy para obtener contenido de ayuda (llamado desde JavaScript)
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetBackupInfo()
    {
        logger.LogInformation("MVC Proxy: GetBackupInfo called");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AyudaBackupApiController.GetHelpContent),
                controller: nameof(AyudaBackupApiController).Replace("Controller", "")
            );
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Método proxy para obtener información de aplicación
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetApplicationInfo()
    {
        logger.LogInformation("MVC Proxy: GetApplicationInfo called");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AyudaBackupApiController.GetApplicationInfo),
                controller: nameof(AyudaBackupApiController).Replace("Controller", "")
            );
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Método proxy para obtener tipo de base de datos
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetDatabaseType()
    {
        logger.LogInformation("MVC Proxy: GetDatabaseType called");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AyudaBackupApiController.GetDatabaseType),
                controller: nameof(AyudaBackupApiController).Replace("Controller", "")
            );
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Método proxy para obtener fecha formateada
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetFormattedDate()
    {
        logger.LogInformation("MVC Proxy: GetFormattedDate called");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AyudaBackupApiController.GetFormattedDate),
                controller: nameof(AyudaBackupApiController).Replace("Controller", "")
            );
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }
}