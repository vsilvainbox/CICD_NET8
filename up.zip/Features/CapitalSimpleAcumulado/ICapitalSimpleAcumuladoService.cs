namespace App.Features.CapitalSimpleAcumulado;

public interface ICapitalSimpleAcumuladoService
{
    Task<CapitalSimpleAcumuladoResponseDto> ObtenerValoresAnualesAsync(int empresaId, int anoActual, byte tipoDetCPS);
    Task GuardarValoresAnualesAsync(int empresaId, byte tipoDetCPS, List<ValorAnualDto> valores);
    Task<decimal> CalcularTotalAsync(List<ValorAnualDto> valores);
}