using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.CapitalAportado;

public class CapitalAportadoController(
    ILogger<CapitalAportadoController> logger,
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator) : Controller
{
    public IActionResult Index()
    {
        logger.LogInformation("CapitalAportado index accessed");
        ViewBag.EmpresaId = SessionHelper.EmpresaId;
        ViewBag.Ano = SessionHelper.Ano;
        return View();
    }

    [HttpGet]
    public async Task<IActionResult> GetData(int empresaId, short ano)
    {
        logger.LogInformation("GetData called with empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(CapitalAportadoApiController.Get),
                controller: nameof(CapitalAportadoApiController).Replace("Controller", ""),
                values: new { empresaId, ano }
            );
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    [HttpPost]
    public async Task<IActionResult> Save([FromBody] JsonElement request)
    {
        logger.LogInformation("Save called");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(CapitalAportadoApiController.Save),
                controller: nameof(CapitalAportadoApiController).Replace("Controller", "")
            );
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }
}