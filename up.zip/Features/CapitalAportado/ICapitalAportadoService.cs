﻿namespace App.Features.CapitalAportado;

public interface ICapitalAportadoService
{
    Task<CapitalAportadoDto> GetCapitalAportadoAsync(int empresaId, short ano);
    Task<bool> SaveCapitalAportadoAsync(SaveCapitalAportadoRequestDto request);
}
