using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Text.Json;
using App.Extensions;
using App.Helpers;

namespace App.Features.CentroCostoIndividual;

/// <summary>
/// MVC Controller para gestión individual de centros de costo
/// Basado en FrmCCosto.frm del sistema VB6
/// </summary>
[Authorize]

public class CentroCostoIndividualController(
    ILogger<CentroCostoIndividualController> logger,
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator) : Controller
{
    /// <summary>
    /// Vista principal/por defecto para centro de costo individual
    /// Redirige a la creación de nuevo centro de costo
    /// </summary>
    public IActionResult Index()
    {
        logger.LogInformation("Accediendo a vista principal de centro de costo individual");
        // Redirigir a la vista de nuevo centro de costo como comportamiento por defecto
        return RedirectToAction(nameof(Nuevo));
    }

    /// <summary>
    /// Vista para crear nuevo centro de costo
    /// Mapea: FrmCCosto.FNew()
    /// </summary>
    public IActionResult Nuevo()
    {
        logger.LogInformation("Cargando vista para nuevo centro de costo");

        ViewBag.Modo = "Nuevo";
        ViewBag.Titulo = "Nuevo Centro de Gestión";
        ViewBag.SoloLectura = false;

        var dto = new CentroCostoDto
        {
            Vigente = true // Default en VB6: Ch_Vigente = 1
        };

        return View("Index", dto);
    }

    /// <summary>
    /// Vista para editar centro de costo existente
    /// Mapea: FrmCCosto.FEdit()
    /// </summary>
    public async Task<IActionResult> Editar(int id)
    {
        {
            logger.LogInformation("Cargando vista para editar centro de costo Id={Id}", id);

            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(CentroCostoIndividualApiController.GetById),
                controller: nameof(CentroCostoIndividualApiController).Replace("Controller", ""),
                values: new { id, empresaId = SessionHelper.EmpresaId }
            );

            var centroCosto = await client.GetFromApiAsync<CentroCostoDto>(url!);

            if (centroCosto == null)
            {
                logger.LogWarning("Centro de costo no encontrado: Id={Id}", id);
                return NotFound("Centro de costo no encontrado");
            }

            ViewBag.Modo = "Editar";
            ViewBag.Titulo = "Modificar Centro de Gestión";
            ViewBag.SoloLectura = false;

            return View("Index", centroCosto);
        }
    }

    /// <summary>
    /// Vista para ver centro de costo (solo lectura)
    /// Mapea: FrmCCosto.FView()
    /// </summary>
    public async Task<IActionResult> Ver(int id)
    {
        {
            logger.LogInformation("Cargando vista para ver centro de costo Id={Id}", id);

            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(CentroCostoIndividualApiController.GetById),
                controller: nameof(CentroCostoIndividualApiController).Replace("Controller", ""),
                values: new { id, empresaId = SessionHelper.EmpresaId }
            );

            var centroCosto = await client.GetFromApiAsync<CentroCostoDto>(url!);

            if (centroCosto == null)
            {
                logger.LogWarning("Centro de costo no encontrado: Id={Id}", id);
                return NotFound("Centro de costo no encontrado");
            }

            ViewBag.Modo = "Ver";
            ViewBag.Titulo = "Ver Centro de Gestión";
            ViewBag.SoloLectura = true;

            return View("Index", centroCosto);
        }
    }

    /// <summary>
    /// Método proxy: Validar código único
    /// Mapea API: GET /api/CentroCostoIndividualApi/validar-codigo
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ValidarCodigo(string codigo, int? excludeId)
    {
        logger.LogInformation("Proxy: Validar código {Codigo}, excludeId={ExcludeId}", codigo, excludeId);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(CentroCostoIndividualApiController.ValidarCodigo),
                controller: nameof(CentroCostoIndividualApiController).Replace("Controller", ""),
                values: new { codigo, empresaId = SessionHelper.EmpresaId, excludeId }
            );

            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Método proxy: Crear nuevo centro de costo
    /// Mapea API: POST /api/CentroCostoIndividual
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Crear([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: Crear centro de costo");

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(CentroCostoIndividualApiController.Create),
                controller: nameof(CentroCostoIndividualApiController).Replace("Controller", ""),
                values: new { empresaId = SessionHelper.EmpresaId }
            );

            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request,
                HttpMethod.Post);
            return new ContentResult
            {
                Content = content,
                ContentType = "application/json",
                StatusCode = statusCode
            };
        }
    }

    /// <summary>
    /// Método proxy: Actualizar centro de costo existente
    /// Mapea API: PUT /api/CentroCostoIndividualApi/{id}
    /// </summary>
    [HttpPut]
    public async Task<IActionResult> Actualizar(int id, [FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: Actualizar centro de costo Id={Id}", id);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(CentroCostoIndividualApiController.Update),
                controller: nameof(CentroCostoIndividualApiController).Replace("Controller", ""),
                values: new { id, empresaId = SessionHelper.EmpresaId }
            );

            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request,
                HttpMethod.Put);
            return new ContentResult
            {
                Content = content,
                ContentType = "application/json",
                StatusCode = statusCode
            };
        }
    }
}
