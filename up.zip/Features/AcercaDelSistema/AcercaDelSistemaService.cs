using System.Reflection;
using Microsoft.EntityFrameworkCore;
using App.Data;

namespace App.Features.AcercaDelSistema;

public class AcercaDelSistemaService(LpContabContext context, ILogger<AcercaDelSistemaService> logger) : IAcercaDelSistemaService
{
    public async Task<AcercaDelSistemaDto> GetAsync()
    {
        logger.LogInformation("Getting system information");
            
        {
            // Obtener versión del assembly
            var assembly = Assembly.GetExecutingAssembly();
            var version = assembly.GetName().Version;
            var versionString = $"{version?.Major}.{version?.Minor}.{version?.Revision}";
                
            // Obtener versión de BD desde Param (si existe)
            var dbVersion = await context.Param
                .Where(p => p.Tipo == "DBVER")
                .Select(p => p.Valor)
                .FirstOrDefaultAsync();
                
            var dto = new AcercaDelSistemaDto
            {
                Version = versionString,
                TipoBaseDatos = "SQLite",
                EsDemo = false, // Configurar según licencia real
                Empresa = "Thomson Reuters",
                Telefono = "(56 2) 2483 8600",
                Website = "https://www.thomsonreuters.cl",
                Email = "soporte.chile@thomsonreuters.com",
                NivelProducto = "Profesional", // Podría venir de configuración
                FechaVersion = assembly.GetCustomAttribute<AssemblyFileVersionAttribute>()?.Version ?? DateTime.Now.ToString("MMM d, yyyy"),
                VersionBD = dbVersion ?? "1.0"
            };
                
            logger.LogInformation("System information retrieved successfully: Version {Version}", dto.Version);
                
            return dto;
        }
    }
}