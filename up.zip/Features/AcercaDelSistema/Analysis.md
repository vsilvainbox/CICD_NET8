# Legacy Analysis: Acerca del Sistema

## 📄 Información del Formulario VB6

**Archivo VB6:** `old/Contabilidad70/HyperContabilidad/FrmAbout.frm`
**Fecha Análisis:** 2024-01-15
**Analista:** IA
**Complejidad:** Muy Baja

### Propósito del Formulario
Formulario informativo "Acerca de" que muestra información del sistema: versión, empresa desarrolladora, contactos y nivel de licencia.

---

## 🎨 CONTROLES UI IDENTIFICADOS

### Labels Informativos
| Control VB6 | Contenido | Descripción |
|-------------|-----------|-------------|
| Lb_Version | "Versión X.X.X" | Versión del software desde App.Major.Minor.Revision |
| Lb_AccessSQL | "Access" o "SQL Server" | Tipo de base de datos |
| Lb_Demo | "DEMO" | Visible solo si es versión demo |
| Lb_Tr | "Thomson Reuters" | Nombre de la empresa |
| La_Nivel | Descripción del nivel | Nivel del producto (Básico, Intermedio, etc.) |
| La_Fecha | Fecha de versión | Fecha de compilación |

### Links Clicables
| Control VB6 | Caption | URL | Mapeo .NET |
|-------------|---------|-----|------------|
| la_Link(0) | "https://www.thomsonreuters.cl" | Website | Link HTML |
| la_Link(1) | "email soporte.chile@thomsonreuters.com" | Email | mailto: link |

### Botones
| Botón VB6 | Caption | Acción | Mapeo .NET |
|-----------|---------|--------|------------|
| OK | (implícito) | Cerrar formulario | Botón Cerrar |

---

## 🔧 FUNCIONES Y PROCEDIMIENTOS VB6

```vb
Private Sub Form_Load()
    ' Carga información del sistema
    - Lee versión de BD desde Param
    - Obtiene versión del App (Major.Minor.Revision)
    - Muestra nivel de producto
    - Determina si es Demo
    - Muestra tipo de BD (Access/SQL Server)
End Sub

Private Sub la_Link_Click(Index As Integer)
    ' Abre link en navegador o cliente email
    ShellExecute(Me.hWnd, "open", Buf, "", "", SW_SHOWNORMAL)
End Sub
```

---

## 💾 ACCESO A DATOS VB6

### Query 1: Obtener Versión de BD
```vb
Q1 = "SELECT Valor FROM Param WHERE Tipo = 'DBVER'"
```

**Mapeo Entity Framework:**
```csharp
await _context.Param
    .Where(p => p.Tipo == "DBVER")
    .Select(p => p.Valor)
    .FirstOrDefaultAsync();
```

---

## 🎯 MAPEO FINAL: MÉTODOS .NET DETERMINADOS

### Service Simplificado
```csharp
public interface IAcercaDelSistemaService
{
    Task<AcercaDelSistemaDto> GetAsync();
}
```

### Datos a Mostrar
- Versión: Hardcoded en .NET (desde Assembly)
- Tipo BD: Hardcoded "SQLite"
- Demo: Configuración (puede ser hardcoded false)
- Empresa: "Thomson Reuters"
- Contactos: Hardcoded
- Nivel: Desde configuración

---

## ⚠️ NOTAS IMPORTANTES

### Decisiones de Diseño
- **Información estática**: La mayoría de datos son hardcoded en la vista
- **Sin CRUD**: Solo lectura, no hay operaciones de escritura
- **Service opcional**: Puede implementarse todo en la vista directamente
- **Versión**: Usar Assembly.GetExecutingAssembly().GetName().Version

---

**✅ ANÁLISIS COMPLETO - LISTO PARA IMPLEMENTACIÓN**

