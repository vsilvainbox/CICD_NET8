using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.AsistentePpm;

/// <summary>
/// Controller MVC para vista de Asistente de Reajuste PPM
/// </summary>
[Authorize]

public class AsistentePpmController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<AsistentePpmController> logger) : Controller
{
    /// <summary>
    /// Muestra la vista principal del Asistente de Reajuste PPM
    /// </summary>
    /// <returns>Vista Index con empresaId y año desde sesión</returns>
    public IActionResult Index()
    {
        ViewBag.EmpresaId = SessionHelper.EmpresaId;
        ViewBag.Ano = SessionHelper.Ano;
        return View();
    }

    /// <summary>
    /// Proxy: Obtiene datos de PPM Obligatorio
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetObligatorio(int empresaId, short ano)
    {
        logger.LogInformation("MVC Proxy: GetObligatorio - empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AsistentePpmApiController.GetObligatorio),
                controller: nameof(AsistentePpmApiController).Replace("Controller", ""),
                values: new { empresaId, ano }
            );
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Proxy: Obtiene datos de PPM Voluntario
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetVoluntario(int empresaId, short ano)
    {
        logger.LogInformation("MVC Proxy: GetVoluntario - empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AsistentePpmApiController.GetVoluntario),
                controller: nameof(AsistentePpmApiController).Replace("Controller", ""),
                values: new { empresaId, ano }
            );
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Proxy: Obtiene el total de traspaso
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetTotalTraspaso(int empresaId, short ano)
    {
        logger.LogInformation("MVC Proxy: GetTotalTraspaso - empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AsistentePpmApiController.GetTotalTraspaso),
                controller: nameof(AsistentePpmApiController).Replace("Controller", ""),
                values: new { empresaId, ano }
            );
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Proxy: Actualiza la configuración de PPM
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> PostConfiguracion([FromBody] JsonElement body)
    {
        logger.LogInformation("MVC Proxy: PostConfiguracion");

        {
            var client = httpClientFactory.CreateClient("ApiClient");
            var url = linkGenerator.GetPathByAction(
                action: nameof(AsistentePpmApiController.PostConfiguracion),
                controller: nameof(AsistentePpmApiController).Replace("Controller", ""));
            var (statusCode, content) = await client.ProxyRequestAsync(url!, body, HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// Proxy: Exporta a Excel
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ExportExcel(int empresaId, short ano)
    {
        logger.LogInformation("MVC Proxy: ExportExcel - empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient("ApiClient");
            var url = linkGenerator.GetPathByAction(
                action: nameof(AsistentePpmApiController.ExportExcel),
                controller: nameof(AsistentePpmApiController).Replace("Controller", ""),
                values: new { empresaId, ano });
            var (fileBytes, contentType) = await client.DownloadFileAsync(url, HttpMethod.Get, null);

            var fileName = $"ReajustePPM_{empresaId}_{ano}.xlsx";
            return File(fileBytes, contentType, fileName);
        }
    }
}
