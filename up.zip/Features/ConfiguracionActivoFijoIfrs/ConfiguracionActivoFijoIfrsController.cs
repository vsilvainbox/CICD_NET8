using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.ConfiguracionActivoFijoIfrs;

public class ConfiguracionActivoFijoIfrsController(
    IHttpClientFactory httpClientFactory,
    ILogger<ConfiguracionActivoFijoIfrsController> logger,
    LinkGenerator linkGenerator) : Controller
{
    public IActionResult Index()
    {
        logger.LogInformation("ConfiguracionActivoFijoIfrs index accessed");
        ViewBag.EmpresaId = SessionHelper.EmpresaId;
        return View();
    }

    // ===== M�TODOS PROXY PARA API =====

    [HttpGet]
    public async Task<IActionResult> GetConfig(int empresaId)
    {
        logger.LogInformation("Proxy: GetConfig - empresaId: {EmpresaId}", empresaId);

        var client = httpClientFactory.CreateClient("ApiClient");
        var url = linkGenerator.GetPathByAction(
            action: nameof(ConfiguracionActivoFijoIfrsApiController.Get),
            controller: nameof(ConfiguracionActivoFijoIfrsApiController).Replace("Controller", ""),
            values: new { empresaId });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    [HttpDelete]
    public async Task<IActionResult> DeleteGrupo(int id, int empresaId)
    {
        logger.LogInformation("Proxy: DeleteGrupo - id: {Id}, empresaId: {EmpresaId}", id, empresaId);

        var client = httpClientFactory.CreateClient("ApiClient");
        var url = linkGenerator.GetPathByAction(
            action: nameof(ConfiguracionActivoFijoIfrsApiController.DeleteGrupo),
            controller: nameof(ConfiguracionActivoFijoIfrsApiController).Replace("Controller", ""),
            values: new { idGrupo = id, empresaId });
        var (statusCode, content) = await client.ProxyRequestAsync(url!, null, HttpMethod.Delete);
        return StatusCode(statusCode, content);
    }

    [HttpPost]
    public async Task<IActionResult> CreateGrupo([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: CreateGrupo");

        var client = httpClientFactory.CreateClient("ApiClient");
        var url = linkGenerator.GetPathByAction(
            action: nameof(ConfiguracionActivoFijoIfrsApiController.CreateGrupo),
            controller: nameof(ConfiguracionActivoFijoIfrsApiController).Replace("Controller", ""));
        var (statusCode, content) = await client.ProxyRequestAsync(
            url!,
            request,
            HttpMethod.Post);
        return StatusCode(statusCode, content);
    }

    [HttpPut]
    public async Task<IActionResult> UpdateGrupo([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: UpdateGrupo");

        var client = httpClientFactory.CreateClient("ApiClient");
        var url = linkGenerator.GetPathByAction(
            action: nameof(ConfiguracionActivoFijoIfrsApiController.UpdateGrupo),
            controller: nameof(ConfiguracionActivoFijoIfrsApiController).Replace("Controller", ""));
        var (statusCode, content) = await client.ProxyRequestAsync(
            url!,
            request,
            HttpMethod.Put);
        return StatusCode(statusCode, content);
    }

    [HttpDelete]
    public async Task<IActionResult> DeleteComponente(int id, int empresaId)
    {
        logger.LogInformation("Proxy: DeleteComponente - id: {Id}, empresaId: {EmpresaId}", id, empresaId);

        var client = httpClientFactory.CreateClient("ApiClient");
        var url = linkGenerator.GetPathByAction(
            action: nameof(ConfiguracionActivoFijoIfrsApiController.DeleteComponente),
            controller: nameof(ConfiguracionActivoFijoIfrsApiController).Replace("Controller", ""),
            values: new { idComp = id, empresaId });
        var (statusCode, content) = await client.ProxyRequestAsync(url!, null, HttpMethod.Delete);
        return StatusCode(statusCode, content);
    }

    [HttpPost]
    public async Task<IActionResult> CreateComponente([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: CreateComponente");

        var client = httpClientFactory.CreateClient("ApiClient");
        var url = linkGenerator.GetPathByAction(
            action: nameof(ConfiguracionActivoFijoIfrsApiController.CreateComponente),
            controller: nameof(ConfiguracionActivoFijoIfrsApiController).Replace("Controller", ""));
        var (statusCode, content) = await client.ProxyRequestAsync(
            url!,
            request,
            HttpMethod.Post);
        return StatusCode(statusCode, content);
    }

    [HttpPut]
    public async Task<IActionResult> UpdateComponente([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: UpdateComponente");

        var client = httpClientFactory.CreateClient("ApiClient");
        var url = linkGenerator.GetPathByAction(
            action: nameof(ConfiguracionActivoFijoIfrsApiController.UpdateComponente),
            controller: nameof(ConfiguracionActivoFijoIfrsApiController).Replace("Controller", ""));
        var (statusCode, content) = await client.ProxyRequestAsync(
            url!,
            request,
            HttpMethod.Put);
        return StatusCode(statusCode, content);
    }
}