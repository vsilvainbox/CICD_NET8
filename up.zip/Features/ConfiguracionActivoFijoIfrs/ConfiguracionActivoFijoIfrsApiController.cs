using Microsoft.AspNetCore.Mvc;

namespace App.Features.ConfiguracionActivoFijoIfrs;

[ApiController]
[Route("api/[controller]/[action]")]
public class ConfiguracionActivoFijoIfrsApiController(
    IConfiguracionActivoFijoIfrsService service,
    ILogger<ConfiguracionActivoFijoIfrsApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<ConfiguracionActivoFijoIfrsDto>> Get([FromQuery] int empresaId)
    {
        logger.LogInformation("API: Get configuraciÃ³n called");

        {
            var data = await service.GetConfiguracionAsync(empresaId);
            return Ok(data);
        }
    }

    [HttpPost]
    public async Task<ActionResult<int>> CreateGrupo([FromBody] CreateGrupoDto dto)
    {
        logger.LogInformation("API: CreateGrupo called");

        {
            var idGrupo = await service.CreateGrupoAsync(dto);
            return Ok(new { idGrupo, message = "Grupo creado correctamente" });
        }
    }

    [HttpPut]
    public async Task<ActionResult> UpdateGrupo([FromBody] UpdateGrupoDto dto)
    {
        logger.LogInformation("API: UpdateGrupo called");

        {
            var success = await service.UpdateGrupoAsync(dto);
            
            if (success)
            {
                return Ok(new { message = "Grupo actualizado correctamente" });
            }

            return NotFound(new { message = "Grupo no encontrado" });
        }
    }

    [HttpDelete]
    public async Task<ActionResult> DeleteGrupo(int idGrupo, [FromQuery] int empresaId)
    {
        logger.LogInformation("API: DeleteGrupo called");

        {
            var success = await service.DeleteGrupoAsync(idGrupo, empresaId);
            
            if (success)
            {
                return Ok(new { message = "Grupo eliminado correctamente" });
            }

            return NotFound(new { message = "Grupo no encontrado" });
        }
    }

    [HttpPost]
    public async Task<ActionResult<int>> CreateComponente([FromBody] CreateComponenteDto dto)
    {
        logger.LogInformation("API: CreateComponente called");

        {
            var idComp = await service.CreateComponenteAsync(dto);
            return Ok(new { idComp, message = "Componente creado correctamente" });
        }
    }

    [HttpPut]
    public async Task<ActionResult> UpdateComponente([FromBody] UpdateComponenteDto dto)
    {
        logger.LogInformation("API: UpdateComponente called");

        {
            var success = await service.UpdateComponenteAsync(dto);
            
            if (success)
            {
                return Ok(new { message = "Componente actualizado correctamente" });
            }

            return NotFound(new { message = "Componente no encontrado" });
        }
    }

    [HttpDelete]
    public async Task<ActionResult> DeleteComponente(int idComp, [FromQuery] int empresaId)
    {
        logger.LogInformation("API: DeleteComponente called");

        {
            var success = await service.DeleteComponenteAsync(idComp, empresaId);
            
            if (success)
            {
                return Ok(new { message = "Componente eliminado correctamente" });
            }

            return NotFound(new { message = "Componente no encontrado" });
        }
    }
}
