using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Text.Json;
using App.Extensions;
using App.Helpers;
using App.Features.ListadoEmpresas;
using App.Features.AreasNegocio;
using App.Features.CentrosCosto;
using ListadoEmpresasApiController = App.Features.ListadoEmpresas.ListadoEmpresasApiController;
using AreasNegocioApiController = App.Features.AreasNegocio.AreasNegocioApiController;
using CentrosCostoApiController = App.Features.CentrosCosto.CentrosCostoApiController;

namespace App.Features.BalanceGeneral;

/// <summary>
/// Controlador MVC para Balance General de 8 Columnas
/// Solo maneja la vista, delega la lógica al API Controller
/// </summary>
[Authorize]

public class BalanceGeneralController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<BalanceGeneralController> logger) : Controller
{
    /// <summary>
    /// Vista principal del Balance General
    /// GET /BalanceGeneral
    /// </summary>
    public IActionResult Index()
    {
        logger.LogInformation("Loading Balance General Index view");
        return View();
    }

    /// <summary>
    /// Proxy para obtener empresas
    /// GET /BalanceGeneral/GetEmpresas
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetEmpresas()
    {
        logger.LogInformation("Proxy: GetEmpresas llamado");
        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(ListadoEmpresasApiController.GetAll),
                controller: nameof(ListadoEmpresasApiController).Replace("Controller", "")
            );
            var datos = await client.GetFromApiAsync<object>(url!);

            return Ok(datos);
        }
    }

    /// <summary>
    /// Proxy para obtener áreas de negocio
    /// GET /BalanceGeneral/GetAreasNegocio
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetAreasNegocio()
    {
        var empresaId = SessionHelper.EmpresaId;
        logger.LogInformation("Proxy: GetAreasNegocio llamado para empresaId={EmpresaId}", empresaId);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(AreasNegocioApiController.GetAll),
                controller: nameof(AreasNegocioApiController).Replace("Controller", ""),
                values: new { empresaId }
            );
            var datos = await client.GetFromApiAsync<object>(url!);

            return Ok(datos);
        }
    }

    /// <summary>
    /// Proxy para obtener centros de costo
    /// GET /BalanceGeneral/GetCentrosCosto
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetCentrosCosto()
    {
        var empresaId = SessionHelper.EmpresaId;
        logger.LogInformation("Proxy: GetCentrosCosto llamado para empresaId={EmpresaId}", empresaId);

        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(CentrosCostoApiController.GetAll),
                controller: nameof(CentrosCostoApiController).Replace("Controller", ""),
                values: new { empresaId }
            );
            var datos = await client.GetFromApiAsync<object>(url!);

            return Ok(datos);
        }
    }

    /// <summary>
    /// Proxy para generar balance
    /// POST /BalanceGeneral/Generate
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Generate([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: Generate llamado");
        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(BalanceGeneralApiController.Generate),
                controller: nameof(BalanceGeneralApiController).Replace("Controller", "")
            );
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);

            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// Proxy para exportar balance
    /// POST /BalanceGeneral/Export
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Export([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: Export llamado");
        {
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(BalanceGeneralApiController.Export),
                controller: nameof(BalanceGeneralApiController).Replace("Controller", "")
            );
            var (fileBytes, contentType) = await client.DownloadFileAsync(
                url,
                HttpMethod.Post,
                request);

            return File(fileBytes, contentType);
        }
    }
}