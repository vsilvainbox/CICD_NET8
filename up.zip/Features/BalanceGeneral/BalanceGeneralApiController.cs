using Microsoft.AspNetCore.Mvc;

namespace App.Features.BalanceGeneral;

[ApiController]
[Route("api/[controller]/[action]")]
public class BalanceGeneralApiController(
    IBalanceGeneralService service,
    ILogger<BalanceGeneralApiController> logger) : ControllerBase
{
    /// <summary>
    /// Genera el Balance General de 8 Columnas
    /// POST /api/balancegeneral/generate
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<BalanceGeneralResultadoDto>> Generate([FromBody] BalanceGeneralParametrosDto parametros)
    {
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var resultado = await service.GenerateBalanceAsync(parametros);
            return Ok(resultado);
        }
    }

    /// <summary>
    /// Calcula el patrimonio del balance
    /// POST /api/balancegeneral/patrimonio
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<double>> CalculatePatrimonio([FromBody] BalanceGeneralResultadoDto balance)
    {
        {
            var patrimonio = await service.CalculatePatrimonioAsync(balance);
            return Ok(new { patrimonio });
        }
    }

    /// <summary>
    /// Valida la ecuación contable del balance
    /// POST /api/balancegeneral/validate
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<bool>> ValidateEquation([FromBody] BalanceGeneralTotalesDto totales)
    {
        {
            var isValid = await service.ValidateEquationAsync(totales);
            return Ok(new { isValid });
        }
    }

    /// <summary>
    /// Exporta el balance a formato especificado
    /// POST /api/balancegeneral/export
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Export([FromBody] BalanceGeneralExportDto exportDto)
    {
        {
            var fileBytes = await service.ExportAsync(exportDto);
                
            var fileName = $"BalanceGeneral_{DateTime.Now:yyyyMMddHHmmss}";
            var contentType = exportDto.Formato.ToLower() switch
            {
                "excel" => "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "pdf" => "application/pdf",
                "csv" => "text/csv",
                _ => "application/octet-stream"
            };
                
            var extension = exportDto.Formato.ToLower() switch
            {
                "excel" => ".xlsx",
                "pdf" => ".pdf",
                "csv" => ".csv",
                _ => ".dat"
            };

            return File(fileBytes, contentType, $"{fileName}{extension}");
        }
    }

    /// <summary>
    /// Obtiene balance filtrado por nivel
    /// POST /api/balancegeneral/bynivel
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<IEnumerable<BalanceGeneralDto>>> GetByNivel([FromBody] BalanceGeneralParametrosDto parametros)
    {
        {
            var lineas = await service.GetByNivelAsync(parametros);
            return Ok(lineas);
        }
    }
}
