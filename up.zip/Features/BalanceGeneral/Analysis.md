# 📋 Análisis VB6: Balance General 8 Columnas (FrmBalTributario.frm)

## 🎯 Propósito del Formulario

**Balance General de 8 Columnas** - Reporte contable que muestra el estado financiero-tributario con 8 columnas: Débitos, Créditos, Saldo Deudor/Acreedor, Inventario Activo/Pasivo, y Resultado Pérdida/Ganancia.

---

## 📊 Componentes del Formulario VB6

### Controles Principales

| Control | Tipo | Propósito |
|---------|------|-----------|
| `Grid` | MSFlexGrid | Grid principal con cuentas y valores |
| `GridTot(0/1/2)` | MSFlexGrid | 3 grids para totales |
| `Tx_Desde` | TextBox | Fecha desde |
| `Tx_Hasta` | TextBox | Fecha hasta |
| `Cb_Nivel` | ComboBox | Nivel de cuentas a mostrar |
| `Cb_TipoAjuste` | ComboBox | Financiero/Tributario |
| `Cb_AreaNeg` | ComboBox | Filtro por área de negocio |
| `Cb_CCosto` | ComboBox | Filtro por centro de costo |
| `Ch_LibOficial` | CheckBox | Libro oficial (solo aprobados) |
| `Ch_VerCodCta` | CheckBox | Mostrar código de cuenta |
| `Bt_Buscar` | CommandButton | Generar reporte |
| `Bt_Print` | CommandButton | Imprimir |
| `Bt_Preview` | CommandButton | Vista previa |
| `Bt_CopyExcel` | CommandButton | Copiar a Excel |
| `Bt_VerLibMayor` | CommandButton | Ver libro mayor |
| `Bt_Email` | CommandButton | Enviar por correo |

### Estructura del Grid (13 columnas)

```vb
Const C_CODIGO = 0      ' Código de cuenta
Const C_CUENTA = 1      ' Nombre cuenta
Const C_DEBITOS = 2     ' Total débitos
Const C_CREDITOS = 3    ' Total créditos
Const C_DEUDOR = 4      ' Saldo deudor
Const C_ACREEDOR = 5    ' Saldo acreedor
Const C_INVACTIVO = 6   ' Inventario activo
Const C_INVPASIVO = 7   ' Inventario pasivo
Const C_PERDIDA = 8     ' Resultado pérdida
Const C_GANANCIA = 9    ' Resultado ganancia
Const C_IDCUENTA = 10   ' ID cuenta (oculta)
Const C_CLASIF = 11     ' Clasificación (oculta)
Const C_NIVEL = 12      ' Nivel (oculta)
```

---

## 🔄 Funcionalidades Principales

### 1. Carga Inicial (`Form_Load` + `LoadAll`)

**Parámetros de filtro:**
- Fecha Desde/Hasta (por defecto: 01/01/año - último día del mes actual)
- Nivel de cuentas (por defecto: 2)
- Tipo de ajuste (Financiero/Tributario)
- Área de negocio (opcional)
- Centro de costo (opcional)
- Libro oficial (solo comprobantes aprobados)

**Lógica SQL:**
```sql
SELECT 
    Cuentas.Codigo, Cuentas.Descripcion, Cuentas.Nivel,
    Cuentas.Clasificacion, Cuentas.idCuenta,
    SUM(Debe) as TotalDebe, SUM(Haber) as TotalHaber
FROM MovComprobante
INNER JOIN Comprobante ON ...
INNER JOIN Cuentas ON ...
WHERE Fecha BETWEEN @desde AND @hasta
    AND Nivel <= @nivel
    [AND TipoAjuste...]
    [AND IdAreaNeg...]
    [AND IdCCosto...]
GROUP BY Cuentas.idCuenta
ORDER BY Cuentas.Codigo
```

### 2. Generación del Balance (`LoadAll`)

**Proceso de cálculo:**

1. **Obtener movimientos por cuenta**
   - Sumar débitos y créditos por período
   - Filtrar por tipo de ajuste (financiero/tributario)
   - Aplicar filtros de área negocio y centro costo

2. **Calcular columnas:**

   **Columna Saldo:**
   ```vb
   If Debe > Creditos Then
       SaldoDeudor = Debe - Creditos
       SaldoAcreedor = 0
   Else
       SaldoDeudor = 0
       SaldoAcreedor = Creditos - Debe
   End If
   ```

   **Columna Inventario:**
   ```vb
   ' Solo para cuentas de Activo y Pasivo
   If Clasificacion = ACTIVO Then
       If SaldoDeudor > 0 Then
           Inventario Activo = SaldoDeudor
       End If
   ElseIf Clasificacion = PASIVO Then
       If SaldoAcreedor > 0 Then
           InventarioPasivo = SaldoAcreedor
       End If
   End If
   ```

   **Columna Resultado:**
   ```vb
   ' Solo para cuentas de Resultado
   If Clasificacion = RESULTADO Then
       If SaldoDeudor > 0 Then
           Perdida = SaldoDeudor
       Else
           Ganancia = SaldoAcreedor
       End If
   End If
   ```

3. **Calcular totales por nivel**
   - Totales parciales por cada nivel
   - Total general al final

4. **Calcular Patrimonio**
   ```vb
   Patrimonio = TotalInventarioActivo - TotalInventarioPasivo
   ```

### 3. Grids de Totales (GridTot 0, 1, 2)

**GridTot(0) - Totales columnas:**
- Total Débitos
- Total Créditos
- Total Saldo Deudor
- Total Saldo Acreedor
- Total Inventario Activo
- Total Inventario Pasivo
- Total Pérdida
- Total Ganancia

**GridTot(1) - Patrimonio:**
```
Patrimonio = Activos - Pasivos
```

**GridTot(2) - Verificación:**
```
Debe coincidir:
- (Activos + Pérdidas) = (Pasivos + Patrimonio + Ganancias)
```

### 4. Impresión y Exportación

**Funcionalidades:**
- `Bt_Preview_Click` - Vista previa con firmas
- `Bt_Print_Click` - Impresión en papel foliado (libro oficial)
- `Bt_CopyExcel_Click` - Copiar a Excel con membrete opcional
- `Bt_Email_Click` - Enviar por correo electrónico

**Registro de libro oficial:**
```vb
If lPapelFoliado And Ch_LibOficial Then
    Call AppendLogImpreso(LIBOF_TRIBUTARIO, 0, FDesde, FHasta)
End If
```

### 5. Navegación

**Ver Libro Mayor:**
```vb
IdCuenta = Grid.TextMatrix(Grid.Row, C_IDCUENTA)
Call FrmLibMayor.FViewChain(FDesde, FHasta, IdCuenta, TipoAjuste)
```

---

## 🔒 Reglas de Negocio Críticas

### 1. Balance de 8 Columnas
```
ESTRUCTURA:
- Débitos | Créditos
- Saldo Deudor | Saldo Acreedor  
- Inventario Activo | Inventario Pasivo
- Resultado Pérdida | Resultado Ganancia
```

### 2. Clasificación de Cuentas
```
ACTIVO (1): Va a Inventario Activo si Deudor
PASIVO (2): Va a Inventario Pasivo si Acreedor
RESULTADO (3 o más): Va a Pérdida si Deudor, Ganancia si Acreedor
```

### 3. Cálculo de Patrimonio
```
Patrimonio = Total Inventario Activo - Total Inventario Pasivo
```

### 4. Ecuación Contable
```
Activos + Pérdidas = Pasivos + Patrimonio + Ganancias
```

### 5. Tipo de Ajuste
```
FINANCIERO: Excluye comprobantes tributarios puros
TRIBUTARIO: Solo comprobantes tributarios
AMBOS: Incluye todos
```

### 6. Libro Oficial
```
- Solo comprobantes APROBADOS (no pendientes)
- Registra impresión en log
- Papel foliado
```

### 7. Niveles de Cuentas
```
- Muestra cuentas hasta el nivel seleccionado
- Agrupa totales por nivel superior
```

---

## 🗄️ Estructura de Datos

### Tablas Principales

**Cuentas:**
```sql
idCuenta        INT
Codigo          STRING
Descripcion     STRING
Nivel           INT
Clasificacion   INT (1=Activo, 2=Pasivo, 3+=Resultado)
```

**MovComprobante:**
```sql
IdMov           INT
IdComp          INT
IdCuenta        INT
Debe            DOUBLE
Haber           DOUBLE
IdAreaNeg       INT
IdCCosto        INT
```

**Comprobante:**
```sql
IdComp          INT
Fecha           INT (formato YYYYMMDD)
TipoAjuste      INT (1=Financiero, 2=Tributario, 3=Ambos)
Estado          INT (1=Pendiente, 2=Aprobado)
```

### Query Principal (Simplificado)

```sql
SELECT 
    c.Codigo,
    c.Descripcion,
    c.Nivel,
    c.Clasificacion,
    c.idCuenta,
    SUM(m.Debe) as TotalDebe,
    SUM(m.Haber) as TotalHaber
FROM Cuentas c
INNER JOIN MovComprobante m ON c.idCuenta = m.IdCuenta
INNER JOIN Comprobante comp ON m.IdComp = comp.IdComp
WHERE comp.Fecha BETWEEN @desde AND @hasta
    AND c.Nivel <= @nivel
    [Filtros adicionales]
GROUP BY c.idCuenta, c.Codigo, c.Descripcion, c.Nivel, c.Clasificacion
ORDER BY c.Codigo
```

---

## 🎨 Características de UI

### Formato de Grid

**Headers (2 filas):**
```
Fila 0: Saldo | Saldo | Inventario | Inventario | Resultado | Resultado
Fila 1: Código | Cuentas | Débitos | Créditos | Deudor | Acreedor | Activo | Pasivo | Pérdida | Ganancia
```

**Formato de números:**
- Alineación derecha
- Formato: #,##0.00
- Ancho fijo para columnas de valores

### Mostrar/Ocultar Código
```vb
Ch_VerCodCta_Click():
    If checked Then
        Grid.ColWidth(C_CODIGO) = 1200
        ValWidth = G_VALWIDTH (normal)
    Else
        Grid.ColWidth(C_CODIGO) = 0
        ValWidth = G_DVALWIDTH (doble ancho)
    End If
```

### Colores y Estilos
- Totales por nivel: Negrita
- Total general: Negrita + Color distinto
- Cuentas padre: Espaciado visual

---

## 📤 Integración con Otros Módulos

### Módulos Relacionados
1. **FrmLibMayor** - Ver detalle de cuenta
2. **FrmPrintPreview** - Vista previa
3. **FrmPrtSetup** - Configuración de impresión
4. **FrmEmailAccount** - Envío por correo

### Variables Globales Utilizadas
- `gEmpresa.Ano` - Año fiscal
- `gEmpresa.id` - ID empresa
- `gLastNivel` - Último nivel plan de cuentas
- `gTipoAjuste()` - Array de tipos de ajuste
- `gPrtLibros` - Objeto de impresión
- `LIBOF_TRIBUTARIO` - Constante libro oficial

---

## 🚀 Estrategia de Migración a ASP.NET Core

### 1. Service Layer
```csharp
IBalanceGeneralService
- GetBalanceGeneralAsync(parametros)
- CalculatePatrimonioAsync(datos)
- ExportToExcelAsync(datos)
- ValidateEquationAsync(datos)
```

### 2. DTOs
```csharp
BalanceGeneralDto
- Codigo, Descripcion, Nivel, Clasificacion
- Debitos, Creditos
- SaldoDeudor, SaldoAcreedor
- InventarioActivo, InventarioPasivo
- Perdida, Ganancia

BalanceGeneralParametrosDto
- FechaDesde, FechaHasta
- Nivel, TipoAjuste
- AreaNegocio, CentroCosto
- LibroOficial

BalanceGeneralTotalesDto
- TotalesColumnas (array)
- Patrimonio
- VerificacionEcuacion
```

### 3. API Endpoints
```
POST /api/balancegeneral/generate
GET  /api/balancegeneral/export
GET  /api/balancegeneral/print
```

### 4. Vista Razor
- Grid con 8 columnas
- Filtros en panel superior
- 3 grids de totales
- Botones de acción
- Responsive design

---

## ✅ Checklist de Migración

- [ ] Crear DTOs con propiedades exactas
- [ ] Implementar Service con lógica de cálculo
- [ ] Crear API Controller
- [ ] Crear MVC Controller
- [ ] Diseñar vista con 8 columnas
- [ ] Implementar cálculo de patrimonio
- [ ] Implementar validación de ecuación contable
- [ ] Agregar exportación a Excel
- [ ] Agregar generación de PDF
- [ ] Integrar con Libro Mayor
- [ ] Probar todos los filtros
- [ ] Testing de totales y balances

---

**Archivo VB6 Original:** `/vb6/Contabilidad70/HyperContabilidad/FrmBalTributario.frm`  
**Fecha Análisis:** 3 de octubre de 2025  
**Estado:** ✅ Análisis Completo
