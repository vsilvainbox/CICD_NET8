using System.ComponentModel.DataAnnotations;

namespace App.Features.BalanceGeneral;

/// <summary>
/// DTO para una l�nea del balance general de 8 columnas
/// </summary>
public class BalanceGeneralDto
{
    public int idCuenta { get; set; }
        
    [Display(Name = "C�digo")]
    public string? Codigo { get; set; }
        
    [Display(Name = "Cuenta")]
    public string? Descripcion { get; set; }
        
    public int? Nivel { get; set; }
        
    public int? Clasificacion { get; set; }
        
    [Display(Name = "D�bitos")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double Debitos { get; set; }
        
    [Display(Name = "Cr�ditos")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double Creditos { get; set; }
        
    [Display(Name = "Saldo Deudor")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double SaldoDeudor { get; set; }
        
    [Display(Name = "Saldo Acreedor")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double SaldoAcreedor { get; set; }
        
    [Display(Name = "Inventario Activo")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double InventarioActivo { get; set; }
        
    [Display(Name = "Inventario Pasivo")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double InventarioPasivo { get; set; }
        
    [Display(Name = "P�rdida")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double Perdida { get; set; }
        
    [Display(Name = "Ganancia")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double Ganancia { get; set; }
        
    /// <summary>
    /// Indica si es una l�nea de total
    /// </summary>
    public bool IsTotal { get; set; }
        
    /// <summary>
    /// Indica si es total general
    /// </summary>
    public bool IsTotalGeneral { get; set; }
}

/// <summary>
/// DTO para par�metros de generaci�n del balance
/// </summary>
public class BalanceGeneralParametrosDto
{
    [Required]
    public int EmpresaId { get; set; }
        
    [Required]
    public short Ano { get; set; }
        
    [Required]
    public DateTime FechaDesde { get; set; }
        
    [Required]
    public DateTime FechaHasta { get; set; }
        
    [Range(1, 10)]
    public int Nivel { get; set; } = 2;
        
    /// <summary>
    /// 1=Financiero, 2=Tributario, 0=Todos
    /// </summary>
    public int? TipoAjuste { get; set; }
        
    public int? AreaNegocio { get; set; }
        
    public int? CentroCosto { get; set; }
        
    /// <summary>
    /// Solo comprobantes aprobados
    /// </summary>
    public bool LibroOficial { get; set; }
        
    /// <summary>
    /// Mostrar c�digo de cuenta en reporte
    /// </summary>
    public bool MostrarCodigo { get; set; } = true;
}

/// <summary>
/// DTO para totales del balance
/// </summary>
public class BalanceGeneralTotalesDto
{
    [Display(Name = "Total D�bitos")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double TotalDebitos { get; set; }
        
    [Display(Name = "Total Cr�ditos")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double TotalCreditos { get; set; }
        
    [Display(Name = "Total Saldo Deudor")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double TotalSaldoDeudor { get; set; }
        
    [Display(Name = "Total Saldo Acreedor")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double TotalSaldoAcreedor { get; set; }
        
    [Display(Name = "Total Inventario Activo")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double TotalInventarioActivo { get; set; }
        
    [Display(Name = "Total Inventario Pasivo")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double TotalInventarioPasivo { get; set; }
        
    [Display(Name = "Total P�rdida")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double TotalPerdida { get; set; }
        
    [Display(Name = "Total Ganancia")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double TotalGanancia { get; set; }
        
    [Display(Name = "Patrimonio")]
    [DisplayFormat(DataFormatString = "{0:N2}")]
    public double Patrimonio { get; set; }
        
    /// <summary>
    /// Verifica ecuaci�n contable
    /// Activos + P�rdidas = Pasivos + Patrimonio + Ganancias
    /// </summary>
    public bool EcuacionBalanceada => 
        Math.Abs((TotalInventarioActivo + TotalPerdida) - 
                 (TotalInventarioPasivo + Patrimonio + TotalGanancia)) < 0.01;
}

/// <summary>
/// DTO para resultado completo del balance
/// </summary>
public class BalanceGeneralResultadoDto
{
    public List<BalanceGeneralDto> Lineas { get; set; } = new();
        
    public BalanceGeneralTotalesDto Totales { get; set; } = new();
        
    public BalanceGeneralParametrosDto Parametros { get; set; } = new();
}

/// <summary>
/// DTO para exportaci�n
/// </summary>
public class BalanceGeneralExportDto
{
    public BalanceGeneralResultadoDto Resultado { get; set; } = new();
        
    public bool IncluirMembrete { get; set; }
        
    public string Formato { get; set; } = "Excel"; // Excel, PDF, CSV
}