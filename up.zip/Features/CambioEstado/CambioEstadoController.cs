using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.CambioEstado;

public class CambioEstadoController(
    IHttpClientFactory httpClientFactory,
    ILogger<CambioEstadoController> logger,
    LinkGenerator linkGenerator) : Controller
{
    [HttpGet]
    public IActionResult Index([FromQuery] string? ids = null)
    {
        // Verificar permiso PRV_ADM_COMP para cambiar estado de comprobantes
        var hasAdmCompPermission = SessionHelper.HasPrivilege(SessionHelper.Privileges.PRV_ADM_COMP);

        ViewBag.EmpresaId = SessionHelper.EmpresaId;
        ViewBag.Ano = SessionHelper.Ano;
        ViewBag.HasAdmCompPermission = hasAdmCompPermission;

        // Crear modelo para la vista con Tag Helpers
        var model = new CambioEstadoFormDto
        {
            IdComprobantes = ids ?? string.Empty,
            NuevoEstado = 2 // Pendiente por defecto
        };

        return View(model);
    }

    /// <summary>
    /// Método que recibe el formulario con Tag Helpers
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Index(CambioEstadoFormDto formDto)
    {
        // Verificar permiso antes de permitir cambio
        if (!SessionHelper.HasPrivilege(SessionHelper.Privileges.PRV_ADM_COMP))
        {
            logger.LogWarning("User attempted to change voucher status without permission");
            ModelState.AddModelError(string.Empty, "No tiene permisos para cambiar el estado de comprobantes. Requiere permiso: Administrar Comprobantes");
            ViewBag.EmpresaId = SessionHelper.EmpresaId;
            ViewBag.Ano = SessionHelper.Ano;
            ViewBag.HasAdmCompPermission = false;
            return View(formDto);
        }

        if (!ModelState.IsValid)
        {
            ViewBag.EmpresaId = SessionHelper.EmpresaId;
            ViewBag.Ano = SessionHelper.Ano;
            ViewBag.HasAdmCompPermission = true;
            return View(formDto);
        }

        // Parsear IDs del textarea
        var ids = ParsearIds(formDto.IdComprobantes);
        if (ids.Count == 0)
        {
            ModelState.AddModelError(nameof(formDto.IdComprobantes), "Debe ingresar al menos un ID de comprobante válido");
            ViewBag.EmpresaId = SessionHelper.EmpresaId;
            ViewBag.Ano = SessionHelper.Ano;
            ViewBag.HasAdmCompPermission = true;
            return View(formDto);
        }

        // Crear request para la API
        var request = new CambioEstadoRequestDto
        {
            EmpresaId = SessionHelper.EmpresaId,
            Ano = SessionHelper.Ano,
            IdComprobantes = ids,
            NuevoEstado = formDto.NuevoEstado
        };

        logger.LogInformation("MVC: CambiarEstado called with {Count} vouchers", ids.Count);

        try
        {
            var client = httpClientFactory.CreateClient("ApiClient");
            var url = linkGenerator.GetPathByAction(
                action: nameof(CambioEstadoApiController.CambiarEstado),
                controller: nameof(CambioEstadoApiController).Replace("Controller", ""));

            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                JsonSerializer.SerializeToElement(request),
                HttpMethod.Post);

            logger.LogInformation("MVC: API response status {StatusCode}", statusCode);

            if (statusCode == 200)
            {
                var response = JsonSerializer.Deserialize<CambioEstadoResponseDto>(content);
                if (response?.Exitoso == true)
                {
                    TempData["SuccessMessage"] = response.Mensaje;
                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    ModelState.AddModelError(string.Empty, response?.Mensaje ?? "Error al cambiar el estado");
                }
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Error al comunicarse con la API");
            }
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error calling API");
            ModelState.AddModelError(string.Empty, "Error al cambiar el estado: " + ex.Message);
        }

        ViewBag.EmpresaId = SessionHelper.EmpresaId;
        ViewBag.Ano = SessionHelper.Ano;
        ViewBag.HasAdmCompPermission = true;
        return View(formDto);
    }

    /// <summary>
    /// Método proxy para cambiar estado de comprobantes (Vista → MVC → API)
    /// VB6: No verifica permisos, pero debería verificar PRV_ADM_COMP
    /// Mantener para compatibilidad con JavaScript si se necesita
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> CambiarEstado([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: CambiarEstado called");

        // Verificar permiso antes de permitir cambio
        if (!SessionHelper.HasPrivilege(SessionHelper.Privileges.PRV_ADM_COMP))
        {
            logger.LogWarning("User attempted to change voucher status without permission");
            return Json(new
            {
                exitoso = false,
                mensaje = "No tiene permisos para cambiar el estado de comprobantes. Requiere permiso: Administrar Comprobantes"
            });
        }

        {
            var client = httpClientFactory.CreateClient("ApiClient");
            var url = linkGenerator.GetPathByAction(
                action: nameof(CambioEstadoApiController.CambiarEstado),
                controller: nameof(CambioEstadoApiController).Replace("Controller", ""));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request,
                HttpMethod.Post);

            logger.LogInformation("MVC Proxy: API response status {StatusCode}", statusCode);

            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// Parsea IDs del textarea (separados por coma o línea nueva)
    /// </summary>
    private static List<int> ParsearIds(string texto)
    {
        if (string.IsNullOrWhiteSpace(texto)) return new List<int>();

        return texto.Split(new[] { '\n', ',' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(s => s.Trim())
            .Where(s => int.TryParse(s, out _))
            .Select(int.Parse)
            .ToList();
    }
}