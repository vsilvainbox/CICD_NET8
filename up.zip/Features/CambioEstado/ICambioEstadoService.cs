namespace App.Features.CambioEstado;

public interface ICambioEstadoService
{
    Task<CambioEstadoResponseDto> CambiarEstadoAsync(CambioEstadoRequestDto request, CancellationToken cancellationToken = default);
}