namespace App.Features.AbrirCerrarMes;

/// <summary>
/// DTO para el estado de un mes contable
/// Representa el estado (ABIERTO/CERRADO) de cada mes del a�o
/// </summary>
public class EstadoMesDto
{
    /// <summary>
    /// N�mero del mes (1-12)
    /// </summary>
    public int Mes { get; set; }

    /// <summary>
    /// Estado del mes: 0=CERRADO, 1=ABIERTO
    /// </summary>
    public int Estado { get; set; }

    /// <summary>
    /// Texto del estado: "ABIERTO" o "CERRADO"
    /// </summary>
    public string EstadoTexto { get; set; } = string.Empty;

    /// <summary>
    /// Nombre del mes en espa�ol (Enero, Febrero, ...)
    /// </summary>
    public string NombreMes { get; set; } = string.Empty;

    /// <summary>
    /// Indica si este es el �ltimo mes con movimientos (comprobantes)
    /// Se muestra con una flecha roja (?) en VB6
    /// </summary>
    public bool EsUltimoMesConMovimientos { get; set; }
}

/// <summary>
/// DTO para la solicitud de abrir o cerrar un mes
/// </summary>
public class AbrirCerrarMesRequestDto
{
    /// <summary>
    /// ID de la empresa
    /// </summary>
    public int EmpresaId { get; set; }

    /// <summary>
    /// A�o contable
    /// </summary>
    public short Ano { get; set; }

    /// <summary>
    /// N�mero del mes a abrir/cerrar (1-12)
    /// </summary>
    public int Mes { get; set; }
}

/// <summary>
/// DTO de resultado de validaci�n
/// Se usa para retornar �xito/error de operaciones
/// </summary>
public class ValidationResult
{
    /// <summary>
    /// Indica si la operaci�n fue exitosa
    /// </summary>
    public bool Success { get; set; }

    /// <summary>
    /// Mensaje descriptivo del resultado
    /// </summary>
    public string Message { get; set; } = string.Empty;

    /// <summary>
    /// Crea un resultado exitoso
    /// </summary>
    public static ValidationResult Ok(string message)
    {
        return new ValidationResult
        {
            Success = true,
            Message = message
        };
    }

    /// <summary>
    /// Crea un resultado de error
    /// </summary>
    public static ValidationResult Fail(string message)
    {
        return new ValidationResult
        {
            Success = false,
            Message = message
        };
    }
}

/// <summary>
/// DTO de configuraci�n para la gesti�n de meses
/// </summary>
public class EstadoMesesConfigDto
{
    /// <summary>
    /// Indica si el usuario tiene permiso para abrir/cerrar meses
    /// Basado en privilegio PRV_ADM_EMPRESA
    /// </summary>
    public bool CanOpenClose { get; set; }

    /// <summary>
    /// Indica si se permite abrir m�ltiples meses simult�neamente
    /// Equivalente a gAbrirMesesParalelo en VB6
    /// </summary>
    public bool AbrirMesesParalelo { get; set; }

    /// <summary>
    /// ID de la empresa actual
    /// </summary>
    public int EmpresaId { get; set; }

    /// <summary>
    /// A�o contable actual
    /// </summary>
    public short Ano { get; set; }

    /// <summary>
    /// Raz�n social de la empresa
    /// </summary>
    public string RazonSocial { get; set; } = string.Empty;
}
