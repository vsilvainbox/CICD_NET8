# Análisis: Actualización Glosas (FrmGlosasUpdate.frm)

## 📋 Información General

**Formulario VB6:** `FrmGlosasUpdate.frm`  
**Propósito:** Formulario modal simple para crear o editar glosas (descripciones reutilizables para comprobantes contables)  
**Tipo:** Dialog modal (Fixed Dialog, No MaxButton, No MinButton)  
**Ubicación .NET:** `\app\Features\ActualizacionGlosas`

## 🎯 Funcionalidad Principal

Este es un **formulario de edición/creación simple** que permite:
- Crear una nueva glosa (INSERT)
- Editar una glosa existente (UPDATE)
- Validar que la glosa no esté vacía
- Retornar el resultado de la operación (OK/Cancel)

Es invocado desde otros formularios mediante la función pública `FEdit()`.

## 🖼️ Estructura del UI

### Controles VB6

```
┌─────────────────────────────────────────────────────┐
│  [Icon]  Glosa:                                      │
│          ┌────────────────────────────────┐  [Aceptar]│
│          │  TextBox Multiline (250 chars) │  [Cancelar]│
│          └────────────────────────────────┘          │
└─────────────────────────────────────────────────────┘
```

**Componentes:**
1. **Image1** - Ícono decorativo (imagen)
2. **Label1** - "Glosa:"
3. **Tx_Glosa** (TextBox) - Campo de texto multiline, MaxLength=250
4. **bt_Ok** (CommandButton) - "Aceptar"
5. **bt_Cancel** (CommandButton) - "Cancelar"

### Propiedades del Formulario

- **BorderStyle:** Fixed Dialog
- **Caption:** "Glosa"
- **Size:** 9060 x 1680 twips
- **StartUpPosition:** CenterScreen
- **Modal:** vbModal
- **ShowInTaskbar:** False
- **MaxButton/MinButton:** False

## 📊 Estructura de Datos

### Entidad: Glosas

```csharp
public partial class Glosas
{
    public int idGlosa { get; set; }
    public int? IdEmpresa { get; set; }
    public string? Glosa { get; set; }
}
```

**Tabla SQL:**
- **idGlosa** (PK, INT, Identity) - ID único de la glosa
- **IdEmpresa** (INT, FK) - ID de la empresa propietaria
- **Glosa** (VARCHAR(250)) - Texto de la glosa

## 🔧 Variables de Módulo VB6

```vb
Dim lGlosa As String        ' Texto de la glosa
Dim lidGlosa As Long        ' ID de la glosa (0 para nueva)
Dim lRc As Integer          ' Código de retorno (vbOK o vbCancel)
Dim lOper As Integer        ' Operación: O_NEW (nueva) o O_EDIT (editar)
```

## 🎬 Flujo de Operación

### 1. Invocación desde Formulario Padre

```vb
Public Function FEdit(Glosa As String, idGlosa As Long, Oper As Integer) As Integer
   lOper = Oper              ' O_NEW o O_EDIT
   lidGlosa = idGlosa        ' ID de glosa (0 si es nueva)
   lGlosa = Glosa            ' Texto actual
   Me.Show vbModal           ' Mostrar modal
   
   FEdit = lRc               ' Retornar resultado
   Glosa = lGlosa            ' Retornar texto modificado (ByRef)
   idGlosa = lidGlosa        ' Retornar ID (ByRef para nueva glosa)
End Function
```

**Parámetros:**
- `Glosa As String` - Texto inicial (vacío para nueva, texto actual para editar) - **ByRef**
- `idGlosa As Long` - ID de la glosa (0 para nueva) - **ByRef**
- `Oper As Integer` - Operación (O_NEW o O_EDIT)

**Retorno:**
- `Integer` - vbOK (1) si se guardó, vbCancel (2) si se canceló
- `Glosa` - Modificado por referencia con el nuevo texto
- `idGlosa` - Modificado por referencia con el ID (importante para nuevas glosas)

### 2. Form_Load

```vb
Private Sub Form_Load()
   lRc = vbCancel           ' Por defecto: cancelar
   Tx_Glosa = lGlosa        ' Cargar texto en el TextBox
End Sub
```

### 3. Validación y Guardado (bt_OK_Click)

```vb
Private Sub bt_OK_Click()
   Dim Q1 As String
   Dim Rs As Recordset
   
   ' ============================
   ' VALIDACIÓN
   ' ============================
   If Trim(Tx_Glosa) = "" Then
      MsgBox1 "Debe ingresar una glosa", vbExclamation
      Exit Sub
   End If
   
   ' ============================
   ' OPERACIÓN: NUEVA GLOSA
   ' ============================
   If lOper = O_NEW Then
      ' Agregar nuevo registro (AdvTbAddNew genera ID automático)
      lidGlosa = AdvTbAddNew(DbMain, "Glosas", "idGlosa", "IdEmpresa", gEmpresa.id)
      
      ' Actualizar con los datos
      Q1 = "UPDATE Glosas SET"
      Q1 = Q1 & " Glosa = '" & ParaSQL(Tx_Glosa) & "'"
      Q1 = Q1 & " WHERE idGlosa=" & lidGlosa
      Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.id
      Call ExecSQL(DbMain, Q1)
   
   ' ============================
   ' OPERACIÓN: EDITAR GLOSA
   ' ============================
   Else
      Q1 = "UPDATE Glosas SET Glosa='" & ParaSQL(Tx_Glosa) & "'"
      Q1 = Q1 & " WHERE idGlosa=" & lidGlosa
      Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.id
      Call ExecSQL(DbMain, Q1)
   End If
   
   ' ============================
   ' FINALIZACIÓN
   ' ============================
   lGlosa = Tx_Glosa        ' Guardar texto para retorno ByRef
   lRc = vbOK               ' Marcar como exitoso
   Unload Me                ' Cerrar formulario
End Sub
```

### 4. Cancelación (Bt_Cancel_Click)

```vb
Private Sub Bt_Cancel_Click()
   Unload Me   ' lRc queda en vbCancel (seteado en Form_Load)
End Sub
```

## 🔍 Reglas de Negocio

### Validaciones

1. **Campo Obligatorio:**
   - La glosa NO puede estar vacía (Trim)
   - Mensaje: "Debe ingresar una glosa"
   - Tipo: vbExclamation

2. **Longitud Máxima:**
   - MaxLength del TextBox: 250 caracteres
   - Multiline: Sí (permite saltos de línea)

### Operaciones de Base de Datos

#### Crear Nueva Glosa (O_NEW)

```sql
-- Paso 1: Crear registro vacío con ID automático
-- (AdvTbAddNew genera INSERT INTO Glosas (IdEmpresa) VALUES (@IdEmpresa))

-- Paso 2: Actualizar con los datos
UPDATE Glosas 
SET Glosa = 'texto_escapado'
WHERE idGlosa = @newId 
  AND IdEmpresa = @empresaId
```

**Notas:**
- `AdvTbAddNew()` es una función helper que inserta un registro vacío y retorna el ID generado
- Se usa un UPDATE posterior para llenar los datos
- `ParaSQL()` escapa comillas simples (duplicándolas)

#### Editar Glosa Existente (O_EDIT)

```sql
UPDATE Glosas 
SET Glosa = 'texto_escapado'
WHERE idGlosa = @idGlosa 
  AND IdEmpresa = @empresaId
```

### Seguridad

- **Filtro por Empresa:** Todas las operaciones incluyen `AND IdEmpresa = gEmpresa.id`
- **SQL Injection Protection:** Se usa `ParaSQL()` para escapar comillas

## 🎨 Migración a .NET 9

### Arquitectura Propuesta

Según `plan.md`, este tipo de formulario modal simple puede seguir dos enfoques:

**Opción 1: Modal Bootstrap en la misma vista (RECOMENDADO para este caso)**
- No requiere controlador separado
- Se invoca desde JavaScript en el formulario padre
- Retorna datos mediante callback o evento

**Opción 2: Controlador y vista separados**
- MVC Controller con acción Index
- API Controller con endpoints POST/PUT
- Service para lógica de negocio

### Recomendación: Opción 1 (Modal Bootstrap)

Dado que este es un formulario extremadamente simple (1 campo + 2 botones), se recomienda implementarlo como un **componente modal reutilizable** que puede ser invocado desde cualquier vista que necesite crear/editar glosas.

### Estructura de Archivos Propuesta

```
\app\Features\ActualizacionGlosas\
├── ActualizacionGlosasDto.cs          # DTOs para request/response
├── IActualizacionGlosasService.cs     # Interfaz del servicio
├── ActualizacionGlosasService.cs      # Lógica de negocio
├── ActualizacionGlosasApiController.cs # API REST endpoints
└── _GlosaModal.cshtml                  # Partial view reutilizable
```

### DTOs Necesarios

```csharp
// Request para crear/actualizar glosa
public class GuardarGlosaRequest
{
    public int? IdGlosa { get; set; }    // null = crear, valor = editar
    public int IdEmpresa { get; set; }
    public string Glosa { get; set; } = string.Empty;
}

// Response
public class GuardarGlosaResponse
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public int IdGlosa { get; set; }     // ID generado/actualizado
    public string Glosa { get; set; } = string.Empty;
}
```

### Interfaz del Servicio

```csharp
public interface IActualizacionGlosasService
{
    Task<GuardarGlosaResponse> CrearGlosaAsync(string glosa, int empresaId);
    Task<GuardarGlosaResponse> ActualizarGlosaAsync(int idGlosa, string glosa, int empresaId);
    Task<bool> ExisteGlosaAsync(int idGlosa, int empresaId);
}
```

### API Endpoints

```
POST   /api/ActualizacionGlosas          # Crear nueva glosa
PUT    /api/ActualizacionGlosas/{id}     # Actualizar glosa existente
GET    /api/ActualizacionGlosas/{id}     # Obtener glosa por ID
```

### Partial View (_GlosaModal.cshtml)

```html
<!-- Modal Bootstrap 5 -->
<div class="modal fade" id="glosaModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Glosa</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <label for="glosaText" class="form-label">Glosa:</label>
        <textarea id="glosaText" class="form-control" rows="3" maxlength="250"></textarea>
        <div id="glosaError" class="invalid-feedback"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-primary" id="btnGuardarGlosa">Aceptar</button>
      </div>
    </div>
  </div>
</div>
```

### JavaScript para Invocación

```javascript
// Función reutilizable similar a FEdit() de VB6
function editarGlosa(idGlosa, glosaActual, callback) {
    const modal = new bootstrap.Modal(document.getElementById('glosaModal'));
    const textarea = document.getElementById('glosaText');
    const btnGuardar = document.getElementById('btnGuardarGlosa');
    
    // Configurar modal
    textarea.value = glosaActual || '';
    
    // Handler de guardado
    btnGuardar.onclick = async () => {
        const glosa = textarea.value.trim();
        
        if (!glosa) {
            Swal.fire('Error', 'Debe ingresar una glosa', 'warning');
            return;
        }
        
        const url = idGlosa 
            ? `/api/ActualizacionGlosas/${idGlosa}`
            : '/api/ActualizacionGlosas';
        
        const method = idGlosa ? 'PUT' : 'POST';
        
        const response = await fetch(url, {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                IdGlosa: idGlosa,
                IdEmpresa: empresaId,  // Desde sessionStorage
                Glosa: glosa 
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            modal.hide();
            callback(result.idGlosa, result.glosa);  // Similar a ByRef de VB6
        } else {
            Swal.fire('Error', result.message, 'error');
        }
    };
    
    modal.show();
}

// Ejemplo de uso desde formulario padre:
// editarGlosa(0, '', (idGlosa, glosa) => {
//     console.log('Nueva glosa creada:', idGlosa, glosa);
// });
```

## 📝 Notas de Implementación

### Diferencias Clave con VB6

1. **Modal vs Form.Show:**
   - VB6: `Me.Show vbModal` (bloquea thread)
   - .NET: Bootstrap Modal (asíncrono, no bloquea)

2. **ByRef Parameters:**
   - VB6: Parámetros ByRef modifican variables del caller
   - .NET: Callbacks o eventos para retornar datos

3. **Código de Retorno:**
   - VB6: Función retorna vbOK/vbCancel
   - .NET: Callback solo se ejecuta en caso de éxito

4. **Validación:**
   - VB6: MsgBox en el mismo thread
   - .NET: SweetAlert2 o validación HTML5

### Ventajas de la Migración

1. ✅ **Reutilizable:** Puede invocarse desde cualquier vista
2. ✅ **Responsive:** Bootstrap Modal se adapta a cualquier pantalla
3. ✅ **Asíncrono:** No bloquea la UI
4. ✅ **Moderno:** SweetAlert2 para alertas elegantes
5. ✅ **Validación Client-Side:** HTML5 maxlength + JavaScript
6. ✅ **API RESTful:** Separación de lógica de negocio

### Consideraciones Especiales

1. **IdEmpresa:**
   - En VB6: `gEmpresa.id` (variable global)
   - En .NET: Obtener desde `sessionStorage` o claims del usuario autenticado

2. **ParaSQL (SQL Injection):**
   - En VB6: Duplicar comillas simples
   - En .NET: Entity Framework previene automáticamente con parámetros

3. **AdvTbAddNew:**
   - En VB6: Helper que inserta registro vacío y retorna ID
   - En .NET: `context.Glosas.Add()` + `SaveChangesAsync()` genera ID automático

## 🧪 Casos de Prueba

### Caso 1: Crear Nueva Glosa
- **Input:** IdGlosa = null, Glosa = "Pago de sueldos octubre"
- **Esperado:** Registro creado, ID generado, retorno exitoso

### Caso 2: Editar Glosa Existente
- **Input:** IdGlosa = 123, Glosa = "Pago de sueldos octubre (modificado)"
- **Esperado:** Registro actualizado, retorno exitoso

### Caso 3: Validación Campo Vacío
- **Input:** Glosa = ""
- **Esperado:** Error "Debe ingresar una glosa", no guarda

### Caso 4: MaxLength
- **Input:** Glosa = 251 caracteres
- **Esperado:** TextArea limita a 250 automáticamente (HTML5)

### Caso 5: Cancelar
- **Input:** Click en Cancelar
- **Esperado:** Modal se cierra, no se ejecuta callback

## 📊 Resumen Técnico

| Aspecto | VB6 | .NET 9 |
|---------|-----|--------|
| **Tipo de UI** | Form Modal Síncrono | Bootstrap Modal Asíncrono |
| **Invocación** | `FEdit()` con ByRef | `editarGlosa()` con callback |
| **Validación** | MsgBox | SweetAlert2 + HTML5 |
| **BD Insert** | AdvTbAddNew + UPDATE | EF Core Add + SaveChanges |
| **BD Update** | SQL directo con ParaSQL | EF Core Update + SaveChanges |
| **SQL Injection** | ParaSQL (duplicar comillas) | EF Core Parámetros |
| **Retorno** | vbOK/vbCancel + ByRef | Callback con datos |
| **Empresa** | gEmpresa.id (global) | sessionStorage o Claims |

## 🎯 Conclusión

`FrmGlosasUpdate.frm` es un **formulario modal extremadamente simple** que solo maneja un campo de texto. Su migración es directa y puede implementarse como un **componente modal reutilizable** en lugar de una feature completa con MVC/API separados.

**Enfoque Recomendado:** Partial View + API endpoints mínimos para crear/actualizar.

**Complejidad:** ⭐ Baja (1/5)  
**Tiempo Estimado:** 2-3 horas  
**Archivos Necesarios:** 4 (DTO, Service, API Controller, Partial View)
