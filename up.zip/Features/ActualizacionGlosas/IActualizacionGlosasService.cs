namespace App.Features.ActualizacionGlosas;

/// <summary>
/// Servicio para gestión de glosas (crear/actualizar)
/// </summary>
public interface IActualizacionGlosasService
{
    /// <summary>
    /// Crea una nueva glosa
    /// </summary>
    /// <param name="glosa">Texto de la glosa</param>
    /// <param name="empresaId">ID de la empresa</param>
    /// <returns>Resultado con ID generado</returns>
    Task<GuardarGlosaResponse> CrearGlosaAsync(string glosa, int empresaId);
    
    /// <summary>
    /// Actualiza una glosa existente
    /// </summary>
    /// <param name="idGlosa">ID de la glosa a actualizar</param>
    /// <param name="glosa">Nuevo texto</param>
    /// <param name="empresaId">ID de la empresa</param>
    /// <returns>Resultado de la actualización</returns>
    Task<GuardarGlosaResponse> ActualizarGlosaAsync(int idGlosa, string glosa, int empresaId);
    
    /// <summary>
    /// Obtiene una glosa por su ID
    /// </summary>
    /// <param name="idGlosa">ID de la glosa</param>
    /// <param name="empresaId">ID de la empresa</param>
    /// <returns>DTO con los datos de la glosa</returns>
    Task<GlosaDto?> ObtenerGlosaAsync(int idGlosa, int empresaId);
    
    /// <summary>
    /// Verifica si existe una glosa
    /// </summary>
    /// <param name="idGlosa">ID de la glosa</param>
    /// <param name="empresaId">ID de la empresa</param>
    /// <returns>True si existe, False si no</returns>
    Task<bool> ExisteGlosaAsync(int idGlosa, int empresaId);
    
    /// <summary>
    /// Obtiene todas las glosas de una empresa
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <returns>Lista de glosas</returns>
    Task<List<GlosaDto>> GetAllAsync(int empresaId);
}
