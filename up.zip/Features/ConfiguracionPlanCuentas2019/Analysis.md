# Análisis: Configuración Plan Cuentas 2019 (frmConfigDefinidasPlanCuenta2019.frm)

## 📋 Información General

| Aspecto | Detalle |
|---------|---------|
| **Formulario VB6** | `frmConfigDefinidasPlanCuenta2019.frm` |
| **Clase Helper** | `FrmConfig.frm` (métodos `GetPlanPreDef` y `GetPlanPreDef_Preview`) |
| **Propósito** | Configurar plan de cuentas predefinido para empresas con régimen 2019 |
| **Namespace .NET** | `App.Features.ConfiguracionPlanCuentas2019` |
| **Tipo** | Asistente de configuración con vista previa |

## 🎯 Funcionalidad Principal

Este formulario es un **asistente especializado** que permite:
1. **Vista Previa** - Ver cómo quedará el plan de cuentas antes de aplicarlo
2. **Aceptar** - Aplicar el plan de cuentas predefinido "PERSONALIZADO" (Plan Avanzado 2019)
3. **Cancelar** - Cerrar sin cambios

**Diferencia clave con ConfiguracionPlanCuentas:**
- Este formulario está **especializado** para el año 2019 en adelante
- Utiliza el **Plan PERSONALIZADO** (basado en Plan Avanzado)
- Incluye configuraciones específicas para régimen tributario 2019+
- Configura automáticamente cuentas básicas, ratios financieros y ajustes RLI

## 🖼️ Controles UI

### Botones Principales

| Control | Caption | Función |
|---------|---------|---------|
| `Bt_VistaPrevia` | "Vista Previa" | Muestra preview del plan sin aplicar cambios |
| `Bt_OK` | "Aceptar" | Aplica el plan de cuentas PERSONALIZADO |
| `Bt_Cancel` | "Cancelar" | Cierra el formulario |

### Labels

| Control | Propiedad | Valor |
|---------|-----------|-------|
| `lblMensaje` | Caption | "Procesando..." |
| `lblMensaje` | Visible | False (inicialmente) |
| `lblMensaje` | ForeColor | Red (&H00FF0000&) |
| `lblMensaje` | Font.Bold | True |
| `lblMensaje` | Font.Size | 9.75 |

## ⚙️ Flujo de Procesos

### 1. Vista Previa (`Bt_VistaPrevia_Click`)

```vb
Private Sub Bt_VistaPrevia_Click()
   lblMensaje.visible = True
   DoEvents
   
   Set Frm = New FrmConfig
   Frm.GetPlanPreDef_Preview 0  ' tipo=0 siempre (PLAN_PERSONALIZADO)
   Set Frm = Nothing
   
   lblMensaje.visible = False
End Sub
```

**Proceso:**
1. Muestra label "Procesando..."
2. Instancia `FrmConfig`
3. Llama a `GetPlanPreDef_Preview(0)` - siempre usa tipo 0 (PLAN_PERSONALIZADO)
4. Oculta label

### 2. Aceptar (`Bt_OK_Click`)

```vb
Private Sub Bt_OK_Click()
   lblMensaje.visible = True
   DoEvents
   
   Set Frm = New FrmConfig
   Frm.GetPlanPreDef 0  ' tipo=0 = PLAN_PERSONALIZADO
   Set Frm = Nothing
   
   bt_Ok.Enabled = False
   lblMensaje.visible = False
End Sub
```

**Proceso:**
1. Muestra label "Procesando..."
2. Instancia `FrmConfig`
3. Llama a `GetPlanPreDef(0)` - tipo 0 = PLAN_PERSONALIZADO
4. Deshabilita botón OK (previene doble clic)
5. Oculta label

## 🔍 Análisis Detallado: GetPlanPreDef (Método Principal)

### Parámetros
- `tipo As Integer`: Tipo de plan a aplicar
  - `0` = PLAN_PERSONALIZADO (usado por este formulario)
  - `PLAN_BASICO` = Plan Básico
  - `PLAN_INTERMEDIO` = Plan Intermedio
  - `PLAN_AVANZADO` = Plan Avanzado
  - `PLAN_IFRS` = Plan IFRS

### Validaciones Críticas

#### 1. Verificar Comprobantes Existentes
```sql
SELECT Comprobante.IdComp, Tipo 
FROM Comprobante 
INNER JOIN MovComprobante ON Comprobante.IdComp = MovComprobante.IdComp
WHERE Comprobante.IdEmpresa = {empresaId} AND Comprobante.Ano = {ano}
```

**Si existen:** Mensaje de error y EXIT SUB
- "No es posible cambiar el plan de la empresa, hay comprobantes ya ingresados."

#### 2. Verificar Documentos con Cuentas Asociadas
```sql
SELECT IdMovDoc 
FROM MovDocumento 
WHERE IdCuenta <> 0 
  AND IdEmpresa = {empresaId} 
  AND Ano = {ano}
```

**Si existen:** Mensaje de error y EXIT SUB
- "No es posible cambiar el plan de la empresa, hay documentos ya ingresados que hacen referencia a cuentas de este plan."

#### 3. Verificar Plan de Cuentas Existente
```sql
SELECT Count(*) as Cant 
FROM Cuentas
WHERE IdEmpresa = {empresaId} AND Ano = {ano}
```

**Si Cant > 0:** Confirmación de usuario
- "Al importar un Plan de Cuentas perderá el Plan de Cuentas actual. ¿Desea continuar?"
- Si No → EXIT SUB

### Proceso de Importación (tipo = 0 = PLAN_PERSONALIZADO)

#### Paso 1: Eliminar Cuentas Actuales
```sql
-- Eliminar Cuentas Básicas
DELETE FROM CuentasBasicas 
WHERE idEmpresa={empresaId} AND Ano={ano}

-- Eliminar Cuentas Razón
DELETE FROM CuentasRazon 
WHERE idEmpresa={empresaId}

-- Eliminar Cuentas Ajustes Extras (RLI)
DELETE FROM CtasAjustesExContRLI 
WHERE idEmpresa={empresaId} AND Ano={ano}

-- Eliminar Cuentas Ajustes Art. 14D LIR
DELETE FROM CtasAjustesExCont 
WHERE idEmpresa={empresaId} AND Ano={ano}

-- Eliminar todas las Cuentas
DELETE FROM Cuentas 
WHERE IdEmpresa={empresaId} AND Ano={ano}
```

#### Paso 2: Copiar Plan desde PlanAvanzado
```sql
INSERT INTO Cuentas 
  (IdPadre, Codigo, Nombre, Descripcion, CodFECU, Nivel, Estado, 
   Clasificacion, Debe, Haber, MarcaApertura, TipoCapPropio, CodF22,
   Atrib1, Atrib2, ... Atrib10,
   CodIFRS_EstRes, CodIFRS_EstFin, CodIFRS, TipoPartida, CodCtaPlanSII,
   IdEmpresa, Ano, TipoPlan)
SELECT 
  IdPadre, Codigo, Nombre, Descripcion, CodFECU, Nivel, Estado, 
  Clasificacion, Debe, Haber, MarcaApertura, TipoCapPropio, CodF22,
  Atrib1, Atrib2, ... Atrib10,
  CodIFRS_EstRes, CodIFRS_EstFin, CodIFRS, TipoPartida, CodCtaPlanSII,
  {empresaId} as IdEmpresa, {ano} as Ano, 'Personalizado' as TipoPlan
FROM PlanAvanzado
```

#### Paso 3: Guardar Tipo de Plan en ParamEmpresa
```sql
-- Si existe
UPDATE ParamEmpresa 
SET Valor = 'PERSONALIZADO' 
WHERE Tipo = 'PLANCTAS' 
  AND IdEmpresa = {empresaId} 
  AND Ano = {ano}

-- Si no existe
INSERT INTO ParamEmpresa (Tipo, Codigo, Valor, IdEmpresa, Ano) 
VALUES('PLANCTAS', 0, 'PERSONALIZADO', {empresaId}, {ano})
```

#### Paso 4: Ajustar Niveles del Plan
```sql
UPDATE ParamEmpresa SET Valor=1 WHERE Tipo='DIGNIV1' ...
UPDATE ParamEmpresa SET Valor=2 WHERE Tipo='DIGNIV2' ...
UPDATE ParamEmpresa SET Valor=2 WHERE Tipo='DIGNIV3' ...
UPDATE ParamEmpresa SET Valor=2 WHERE Tipo='DIGNIV4' ...
UPDATE ParamEmpresa SET Valor=0 WHERE Tipo='DIGNIV5' ...
UPDATE ParamEmpresa SET Valor=4 WHERE Tipo='NIVELES' ...
```

#### Paso 5: Llamar ConfigNiveles (Función Helper)

#### Paso 6: Actualizar Comprobantes Tipo

#### Paso 7: Setear Cuentas Básicas Predefinidas
```vb
Call SetCtasBasDef("PERSONALIZADO")
```

#### Paso 8: Configuraciones Específicas para PLAN_PERSONALIZADO

##### 8.1 Asignar Cuentas Básicas de Libros
```vb
'Compras
Call asignacionCtasBas_Libros(1, 1, "1010801")  ' Libro 1, Tipo 1
Call asignacionCtasBas_Libros(1, 2, "1010802")  ' Libro 1, Tipo 2
Call asignacionCtasBas_Libros(1, 3, "2010601")  ' Libro 1, Tipo 3

'Ventas
Call asignacionCtasBas_Libros(2, 1, "3010101")  ' Libro 2, Tipo 1
Call asignacionCtasBas_Libros(2, 2, "3010102")  ' Libro 2, Tipo 2
Call asignacionCtasBas_Libros(2, 3, "1010401")  ' Libro 2, Tipo 3

'Retenciones
Call asignacionCtasBas_Libros(3, 1, "3010662")  ' Libro 3, Tipo 1
Call asignacionCtasBas_Libros(3, 2, "3010608")  ' Libro 3, Tipo 2
Call asignacionCtasBas_Libros(3, 2, "3010609")  ' Libro 3, Tipo 2
```

##### 8.2 Agregar Cuentas Razón Generales
```vb
Call AgregaCtasRazonGeneral
```

##### 8.3 Configuraciones para Año >= 2020 (CRÍTICO)

Si `gEmpresa.Ano >= 2020`:

**a) Agregar Cuentas Ajustes Extras**
```vb
If ValidaFranquiciaTributaria(1) Then
   Call AgregaCtasAjustesExtrasGeneral
End If
```

**b) Configuración Cuentas Ajustes Art. 14D LIR**
```vb
If ValidaFranquiciaTributaria(2) Then
   Call AgregaCtasAjustes14DLIRGeneral
End If
```

**c) Actualizar Atributos Básicos**
```vb
' Marcar cuenta con atrib1=1
Call ActualizaAtributosBasicos("atrib1=1", "1010104")

' Marcar cuentas con atrib3=1 (array de códigos)
cuentas = Array(1020000, 1020100, 1020101, 1020102, 1020200, 1020201, 
                1020202, 1020203, 1020299, 1020300, 1020301, 1020302, 
                1020303, 1020304, 1020305, 1020306, 1020307, 1020399, 
                1020400, 1020401)
For i = 0 To UBound(cuentas)
    Call ActualizaAtributosBasicos("atrib3=1", cuentas(i))
Next
```

**d) Actualizar Datos de Cuentas (Clasificación y TipoCapPropio)**
```vb
' Clasificacion=2, TipoCapPropio=0, Padre=2016100
cuentas = Array(2011207, 2011208)
For i = 0 To UBound(cuentas)
    Call ActualizaDatosCuenta(2, 0, "2016100", 4, cuentas(i))
Next

' Clasificacion=3, TipoCapPropio=16, Padre=3010300
cuentas = Array(3010646, 3010647, 3010648, 3010649, 3010650, 3010651, 
                3010652, 3010653, 3010654, 3010656, 3010657, 3010658, 
                3010659, 3010661, 3010662)
For i = 0 To UBound(cuentas)
    Call ActualizaDatosCuenta(3, 16, "3010300", 0, cuentas(i))
Next

' Casos especiales
Call ActualizaDatosCuenta(3, 14, "3010300", 0, 3010655)
Call ActualizaDatosCuenta(3, 6, "3010300", 0, 3010660)

' Clasificacion=3, TipoCapPropio=3
cuentas = Array(3020307, 3020308)
For i = 0 To UBound(cuentas)
    Call ActualizaDatosCuenta(3, 3, "3010300", 0, cuentas(i))
Next

' Clasificacion=3, TipoCapPropio=4
cuentas = Array(3020304, 3020305, 3020306, 3020309, 3020310)
For i = 0 To UBound(cuentas)
    Call ActualizaDatosCuenta(3, 4, "3010300", 0, cuentas(i))
Next
```

#### Paso 9: Abrir Formulario de Código IFRS (Solo si no es PERSONALIZADO)
```vb
' NOTA: Como tipo=PERSONALIZADO, este paso NO se ejecuta
If plan <> "PERSONALIZADO" Then
    Me.MousePointer = vbHourglass
    Set FrmIFRS = New FrmConfigCodIFRS
    FrmIFRS.Show vbModal
    Set FrmIFRS = Nothing
    Me.MousePointer = vbDefault
End If
```

#### Paso 10: Mensaje Final
```
"Estimado,
Se ha efectuado el proceso de Definición de Cuentas Básicas, Ratios, 
Financieros y Ajustes según Régimen Tributario seleccionado.

Si necesita hacer otro ajuste, puede ingresar a la pantalla respectiva 
que necesita configurar."
```

## 📊 Tablas de Base de Datos Involucradas

| Tabla | Operación | Propósito |
|-------|-----------|-----------|
| `Cuentas` | DELETE + INSERT | Plan de cuentas principal |
| `CuentasBasicas` | DELETE + INSERT | Cuentas para libros (compras, ventas, retenciones) |
| `CuentasRazon` | DELETE + INSERT | Cuentas para ratios financieros |
| `CtasAjustesExContRLI` | DELETE + INSERT | Cuentas ajustes extras contables RLI |
| `CtasAjustesExCont` | DELETE + INSERT | Cuentas ajustes Art. 14D LIR |
| `ParamEmpresa` | UPDATE/INSERT | Tipo de plan y niveles |
| `PlanAvanzado` | SELECT | Fuente del plan PERSONALIZADO |
| `Comprobante` | SELECT | Validación (no debe haber comprobantes) |
| `MovComprobante` | SELECT | Validación (no debe haber movimientos) |
| `MovDocumento` | SELECT | Validación (no debe haber docs con cuentas) |

## 🎨 Diseño de Migración .NET

### Arquitectura Propuesta

```
ConfiguracionPlanCuentas2019Controller (MVC)
    ↓ HttpClient
ConfiguracionPlanCuentas2019ApiController (API REST)
    ↓ DI
IConfiguracionPlanCuentas2019Service
    ↓ Implementa
ConfiguracionPlanCuentas2019Service
    ↓ Usa
LpContabContext (EF Core)
```

### DTOs Requeridos

```csharp
// ConfiguracionPlanCuentas2019Dto.cs
public class ValidacionPrerequisitosResult
{
    public bool PuedeAplicar { get; set; }
    public string? MensajeError { get; set; }
    public bool ExistePlanActual { get; set; }
    public int CantidadCuentasActuales { get; set; }
}

public class AplicarPlanRequest
{
    public int EmpresaId { get; set; }
    public int Ano { get; set; }
    public bool ConfirmarSobreescritura { get; set; }
}

public class AplicarPlanResponse
{
    public bool Success { get; set; }
    public string Message { get; set; }
    public int CuentasCreadas { get; set; }
}

public class PreviewPlanResult
{
    public List<CuentaPreviewDto> Cuentas { get; set; }
    public int TotalCuentas { get; set; }
}

public class CuentaPreviewDto
{
    public string Codigo { get; set; }
    public string Nombre { get; set; }
    public int Nivel { get; set; }
    public string Clasificacion { get; set; }
}
```

### Service Interface

```csharp
public interface IConfiguracionPlanCuentas2019Service
{
    // Validaciones
    Task<ValidacionPrerequisitosResult> ValidarPrerequisitosAsync(int empresaId, int ano);
    
    // Vista Previa
    Task<PreviewPlanResult> ObtenerVistaPreviaAsync();
    
    // Aplicar Plan
    Task<AplicarPlanResponse> AplicarPlanPersonalizadoAsync(int empresaId, int ano, bool confirmarSobreescritura);
    
    // Helpers privados (implementados en service)
    // - EliminarCuentasActualesAsync
    // - CopiarPlanDesdeAvanzadoAsync
    // - GuardarTipoPlanAsync
    // - AjustarNivelesAsync
    // - SetearCuentasBasicasAsync
    // - AsignarCuentasLibrosAsync
    // - AgregarCuentasRazonAsync
    // - ConfigurarAjustes2020Async (si ano >= 2020)
}
```

## 🔑 Puntos Críticos para Migración

### 1. Validaciones Estrictas
- ✅ NO permitir si existen comprobantes con movimientos
- ✅ NO permitir si existen documentos con cuentas asociadas
- ✅ Pedir confirmación si ya existe plan de cuentas

### 2. Transacciones
- ⚠️ TODO el proceso debe ser **TRANSACCIONAL**
- Si falla cualquier paso, hacer ROLLBACK completo
- VB6 no usa transacciones explícitas (problema!)

### 3. Plan PERSONALIZADO
- Siempre usa `tipo = 0` (PLAN_PERSONALIZADO)
- Fuente: tabla `PlanAvanzado`
- TipoPlan = "Personalizado" en Cuentas

### 4. Configuraciones Año >= 2020
- ⚠️ Lógica CRÍTICA condicional por año
- Validar franquicia tributaria antes de agregar ajustes
- Arrays de códigos de cuentas hardcodeados

### 5. Helpers Requeridos
- `ValidaFranquiciaTributaria(tipo)` - Ver implementación VB6
- `AgregaCtasAjustesExtrasGeneral` - Insertar cuentas ajustes
- `AgregaCtasAjustes14DLIRGeneral` - Insertar ajustes Art. 14D
- `ActualizaAtributosBasicos(campo, codigo)` - UPDATE Cuentas
- `ActualizaDatosCuenta(clasif, tipoCapProp, padre, nivel, codigo)` - UPDATE Cuentas

## 📝 Notas de Implementación

### Diferencias con ConfiguracionPlanCuentas
1. **Especializado para 2019+**: Solo aplica plan PERSONALIZADO
2. **Sin selector de tipo**: No hay combo para elegir plan
3. **Vista previa integrada**: Botón dedicado para preview
4. **Configuración automática**: Aplica todas las configuraciones 2019+ automáticamente
5. **Sin diálogo IFRS**: No muestra formulario de códigos IFRS

### UI Sugerida
- **Vista Previa**: Modal con tabla de cuentas del plan a aplicar
- **Botón Aceptar**: Con confirmación SweetAlert2 si existe plan actual
- **Indicador de progreso**: Spinner mientras procesa
- **Mensaje final**: SweetAlert2 con resumen de operación

### Testing Crítico
- ✅ Probar con empresa SIN plan de cuentas
- ✅ Probar con empresa CON plan de cuentas (debe pedir confirmación)
- ✅ Probar con empresa con comprobantes (debe bloquear)
- ✅ Probar con empresa con documentos con cuentas (debe bloquear)
- ✅ Verificar que año >= 2020 ejecuta configuraciones adicionales
- ✅ Verificar que año < 2020 NO ejecuta configuraciones adicionales

## 🚀 Resumen de Migración

| Aspecto | VB6 | .NET 9 |
|---------|-----|--------|
| **UI** | Form con 3 botones | View Razor con Tailwind CSS |
| **Lógica** | FrmConfig.GetPlanPreDef | ConfiguracionPlanCuentas2019Service |
| **DB Access** | ADO Recordset | EF Core |
| **Transacciones** | ❌ No explícitas | ✅ `using transaction` |
| **Validaciones** | VB6 MsgBox | SweetAlert2 + API validations |
| **Preview** | Modal VB6 | JSON response → Tabla dinámica |
| **Progreso** | Label "Procesando..." | Spinner + async operations |

## ⚠️ Advertencias

1. **NO modificar lógica de validación**: Replicar exactamente las reglas VB6
2. **Arrays hardcodeados**: Mantener los mismos códigos de cuentas en loops
3. **Condicional año 2020**: Es crítico para configuraciones específicas
4. **Plan PERSONALIZADO**: Siempre tipo=0, no permitir otros tipos
5. **Transaccionalidad**: Implementar con `BeginTransaction` en EF Core

---

**Análisis completado** ✅  
**Listo para implementación siguiendo plan.md estrictamente**
