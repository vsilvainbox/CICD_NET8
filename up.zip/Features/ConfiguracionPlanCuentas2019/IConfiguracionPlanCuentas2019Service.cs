﻿namespace App.Features.ConfiguracionPlanCuentas2019;

/// <summary>
/// Servicio para configuración de plan de cuentas 2019
/// Aplica el plan PERSONALIZADO basado en Plan Avanzado
/// </summary>
public interface IConfiguracionPlanCuentas2019Service
{
    /// <summary>
    /// Valida prerequisitos para aplicar el plan de cuentas
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año del plan</param>
    /// <returns>Resultado de validación</returns>
    Task<ValidacionPrerequisitosResult> ValidarPrerequisitosAsync(int empresaId, short ano);
    
    /// <summary>
    /// Obtiene vista previa del plan de cuentas a aplicar
    /// </summary>
    /// <returns>Lista de cuentas del plan PERSONALIZADO</returns>
    Task<PreviewPlanResult> ObtenerVistaPreviaAsync();
    
    /// <summary>
    /// Aplica el plan de cuentas PERSONALIZADO a la empresa
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año del plan</param>
    /// <param name="confirmarSobreescritura">Confirma sobreescribir plan existente</param>
    /// <returns>Resultado de la operación</returns>
    Task<AplicarPlanResponse> AplicarPlanPersonalizadoAsync(int empresaId, short ano, bool confirmarSobreescritura);
}
