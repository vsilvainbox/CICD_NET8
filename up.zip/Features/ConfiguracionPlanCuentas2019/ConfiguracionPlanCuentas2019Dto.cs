namespace App.Features.ConfiguracionPlanCuentas2019;

/// <summary>
/// Resultado de validación de prerequisitos para aplicar plan
/// </summary>
public class ValidacionPrerequisitosResult
{
    /// <summary>
    /// Indica si es posible aplicar el plan de cuentas
    /// </summary>
    public bool PuedeAplicar { get; set; }
    
    /// <summary>
    /// Mensaje de error si no se puede aplicar
    /// </summary>
    public string? MensajeError { get; set; }
    
    /// <summary>
    /// Indica si ya existe un plan de cuentas
    /// </summary>
    public bool ExistePlanActual { get; set; }
    
    /// <summary>
    /// Cantidad de cuentas en el plan actual
    /// </summary>
    public int CantidadCuentasActuales { get; set; }
    
    /// <summary>
    /// Indica si existen comprobantes ingresados
    /// </summary>
    public bool ExistenComprobantes { get; set; }
    
    /// <summary>
    /// Indica si existen documentos con cuentas asociadas
    /// </summary>
    public bool ExistenDocumentos { get; set; }
}

/// <summary>
/// Request para aplicar el plan de cuentas
/// </summary>
public class AplicarPlanRequest
{
    /// <summary>
    /// ID de la empresa
    /// </summary>
    public int EmpresaId { get; set; }
    
    /// <summary>
    /// Año del plan
    /// </summary>
    public short Ano { get; set; }
    
    /// <summary>
    /// Confirmar sobreescritura del plan actual
    /// </summary>
    public bool ConfirmarSobreescritura { get; set; }
}

/// <summary>
/// Response de aplicación del plan
/// </summary>
public class AplicarPlanResponse
{
    /// <summary>
    /// Indica si la operación fue exitosa
    /// </summary>
    public bool Success { get; set; }
    
    /// <summary>
    /// Mensaje descriptivo del resultado
    /// </summary>
    public string Message { get; set; } = string.Empty;
    
    /// <summary>
    /// Cantidad de cuentas creadas
    /// </summary>
    public int CuentasCreadas { get; set; }
    
    /// <summary>
    /// Indica si se requiere configuración adicional
    /// </summary>
    public bool RequiereConfiguracionAdicional { get; set; }
}

/// <summary>
/// Resultado de vista previa del plan
/// </summary>
public class PreviewPlanResult
{
    /// <summary>
    /// Lista de cuentas del plan
    /// </summary>
    public List<CuentaPreviewDto> Cuentas { get; set; } = new();
    
    /// <summary>
    /// Total de cuentas en el plan
    /// </summary>
    public int TotalCuentas { get; set; }
    
    /// <summary>
    /// Nombre del plan
    /// </summary>
    public string NombrePlan { get; set; } = "PERSONALIZADO";
}

/// <summary>
/// DTO para vista previa de una cuenta
/// </summary>
public class CuentaPreviewDto
{
    /// <summary>
    /// Código de la cuenta
    /// </summary>
    public string Codigo { get; set; } = string.Empty;
    
    /// <summary>
    /// Nombre de la cuenta
    /// </summary>
    public string Nombre { get; set; } = string.Empty;
    
    /// <summary>
    /// Nivel de la cuenta
    /// </summary>
    public byte Nivel { get; set; }
    
    /// <summary>
    /// Clasificación de la cuenta
    /// </summary>
    public string Clasificacion { get; set; } = string.Empty;
    
    /// <summary>
    /// Código del padre
    /// </summary>
    public string? CodigoPadre { get; set; }
}

/// <summary>
/// Configuración de cuenta básica para libros
/// </summary>
public class CuentaBasicaLibroConfig
{
    public byte Libro { get; set; }
    public byte Tipo { get; set; }
    public string CodigoCuenta { get; set; } = string.Empty;
}

/// <summary>
/// Configuración de atributo básico
/// </summary>
public class AtributoBasicoConfig
{
    public string Campo { get; set; } = string.Empty;
    public string CodigoCuenta { get; set; } = string.Empty;
}

/// <summary>
/// Configuración de datos de cuenta
/// </summary>
public class DatosCuentaConfig
{
    public byte Clasificacion { get; set; }
    public byte TipoCapPropio { get; set; }
    public string CodigoPadre { get; set; } = string.Empty;
    public byte Nivel { get; set; }
    public string CodigoCuenta { get; set; } = string.Empty;
}
