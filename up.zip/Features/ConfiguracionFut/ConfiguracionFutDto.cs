namespace App.Features.ConfiguracionFut;

public class ConfiguracionFutDto
{
    public int TipoContribuyente { get; set; }
    public string? NombreTipoContribuyente { get; set; }
    public bool HrFutDisponible { get; set; }
    public string? MensajeEstado { get; set; }
}
