using Microsoft.AspNetCore.Mvc;
using App.Helpers;
using App.Extensions;

namespace App.Features.ConfiguracionFut;


public class ConfiguracionFutController(
    IHttpClientFactory httpClientFactory,
    ILogger<ConfiguracionFutController> logger, LinkGenerator linkGenerator) : Controller
{
    public async Task<IActionResult> Index()
    {
        logger.LogInformation("Loading ConfiguracionFut index for empresaId: {EmpresaId}", SessionHelper.EmpresaId);

        {
            var client = httpClientFactory.CreateClient("ApiClient");
            var url = linkGenerator.GetPathByAction(
                action: nameof(ConfiguracionFutApiController.GetConfiguracion),
                controller: nameof(ConfiguracionFutApiController).Replace("Controller", ""),
                values: new { empresaId = SessionHelper.EmpresaId });
            var config = await client.GetFromApiAsync<ConfiguracionFutDto>(url!);

            return View(config);
        }
    }
}
