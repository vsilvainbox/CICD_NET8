using Microsoft.AspNetCore.Mvc;

namespace App.Features.BalanceEjecutivo;

[ApiController]
[Route("api/[controller]/[action]")]
public class BalanceEjecutivoApiController(IBalanceEjecutivoService service, ILogger<BalanceEjecutivoApiController> logger) : ControllerBase
{
    [HttpPost]
    public async Task<ActionResult<BalanceEjecutivoResultadoDto>> GenerarBalance([FromBody] BalanceEjecutivoFiltrosDto filtros)
    {
        logger.LogInformation("API: GenerarBalance called for empresa {EmpresaId}", filtros.EmpresaId);

        {
            var resultado = await service.GenerarBalanceAsync(filtros);
            logger.LogInformation("API: Balance generado exitosamente");
            return Ok(resultado);
        }
    }

    [HttpPost]
    public async Task<IActionResult> ExportarExcel([FromBody] BalanceEjecutivoFiltrosDto filtros)
    {
        logger.LogInformation("API: ExportarExcel called for empresa {EmpresaId}", filtros.EmpresaId);

        {
            var excelBytes = await service.ExportarExcelAsync(filtros);
                
            // ⭐ Registrar log si es Libro Oficial (migrado de VB6: B_Imprimir_Click)
            if (filtros.LibroOficial)
            {
                var usuario = User?.Identity?.Name ?? "Sistema";
                await service.RegistrarLogImpresionAsync(
                    filtros.EmpresaId, 
                    filtros.Ano, 
                    filtros.FechaDesde, 
                    filtros.FechaHasta, 
                    usuario);
                logger.LogInformation("API: Log de impresión registrado para Libro Oficial");
            }
                
            logger.LogInformation("API: Excel generado exitosamente");
                
            var fileName = $"BalanceEjecutivo_{filtros.FechaDesde:yyyyMMdd}_{filtros.FechaHasta:yyyyMMdd}.xlsx";
            return File(excelBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
        }
    }
}

