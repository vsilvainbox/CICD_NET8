﻿namespace App.Features.ConfiguracionActivoFijo;

/// <summary>
/// Interfaz para el servicio de configuración de Activo Fijo
/// </summary>
public interface IConfiguracionActivoFijoService
{
    /// <summary>
    /// Obtiene la configuración actual de Activo Fijo
    /// </summary>
    Task<ConfiguracionActivoFijoDto> GetConfiguracionAsync(int empresaId, short ano);

    /// <summary>
    /// Guarda la configuración de Activo Fijo
    /// </summary>
    Task SaveConfiguracionAsync(SaveConfiguracionActivoFijoDto dto);
}

