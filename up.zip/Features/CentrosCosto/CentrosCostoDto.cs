using System.ComponentModel.DataAnnotations;

namespace App.Features.CentrosCosto;

/// <summary>
/// DTO principal para listar y mostrar centros de costo
/// </summary>
public class CentrosCostoDto
{
    public int IdCCosto { get; set; }
    public int? IdEmpresa { get; set; }
    public string? Codigo { get; set; }
    public string? Descripcion { get; set; }
    public bool? Vigente { get; set; }
    
    // Propiedades calculadas para UI
    public bool IsVigente => Vigente == true;
    public string VigenteTexto => IsVigente ? "Activo" : "Inactivo";
}

/// <summary>
/// DTO para crear nuevo centro de costo
/// </summary>
public class CentrosCostoCreateDto
{
    [Required(ErrorMessage = "El código es obligatorio")]
    [MaxLength(15, ErrorMessage = "El código no puede exceder 15 caracteres")]
    public string Codigo { get; set; } = string.Empty;

    [MaxLength(50, ErrorMessage = "La descripción no puede exceder 50 caracteres")]
    public string? Descripcion { get; set; }

    public bool? Vigente { get; set; } = true;
}

/// <summary>
/// DTO para actualizar centro de costo existente
/// </summary>
public class CentrosCostoUpdateDto
{
    [Required(ErrorMessage = "El código es obligatorio")]
    [MaxLength(15, ErrorMessage = "El código no puede exceder 15 caracteres")]
    public string Codigo { get; set; } = string.Empty;

    [MaxLength(50, ErrorMessage = "La descripción no puede exceder 50 caracteres")]
    public string? Descripcion { get; set; }

    public bool? Vigente { get; set; } = true;
}

/// <summary>
/// DTO para formulario modal (Create/Update) con validaciones completas
/// Usado con Tag Helpers para validación client-side automática
/// </summary>
public class CentrosCostoFormDto
{
    /// <summary>
    /// ID del centro de costo (0 = nuevo, >0 = edición)
    /// </summary>
    public int IdCCosto { get; set; }

    /// <summary>
    /// Código del centro de costo - Requerido, máximo 15 caracteres
    /// </summary>
    [Required(ErrorMessage = "El código es obligatorio")]
    [StringLength(15, ErrorMessage = "El código no puede exceder 15 caracteres")]
    [Display(Name = "Código")]
    public string Codigo { get; set; } = string.Empty;

    /// <summary>
    /// Descripción del centro de costo - Requerido, máximo 50 caracteres
    /// </summary>
    [Required(ErrorMessage = "La descripción es obligatoria")]
    [StringLength(50, ErrorMessage = "La descripción no puede exceder 50 caracteres")]
    [Display(Name = "Descripción")]
    public string Descripcion { get; set; } = string.Empty;

    /// <summary>
    /// Indica si el centro está vigente/activo
    /// </summary>
    [Display(Name = "Centro vigente")]
    public bool Vigente { get; set; } = true;
}

/// <summary>
/// DTO para resultado de validación
/// </summary>
public class ValidationResult
{
    public bool IsValid { get; set; }
    public string? ErrorMessage { get; set; }
}

