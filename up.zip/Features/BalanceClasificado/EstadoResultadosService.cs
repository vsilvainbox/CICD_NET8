using App.Data;
using Microsoft.EntityFrameworkCore;

namespace App.Features.BalanceClasificado;

/// <summary>
/// Servicio para generar estado de resultados por función
/// </summary>
public class EstadoResultadosService(LpContabContext context, ILogger<EstadoResultadosService> logger) : IEstadoResultadosService
{
    public async Task<EstadoResultadosResponse> GenerarEstadoResultadosAsync(EstadoResultadosRequest request)
    {
        {
            logger.LogInformation("Generando estado de resultados para empresa {EmpresaId}, año {Ano}", 
                request.EmpresaId, request.Ano);

            // Validar filtros
            var validation = await ValidarFiltrosAsync(request);
            if (!validation.IsValid)
            {
                throw new InvalidOperationException($"Filtros inválidos: {string.Join(", ", validation.Errors)}");
            }

            // Obtener funciones de clasificación
            var funciones = await ObtenerFuncionesAsync();
                
            // Obtener cuentas de resultados (cuentas de ingresos y gastos)
            var cuentasResultados = await ObtenerCuentasResultadosAsync(request);
                
            // Generar filas del estado de resultados
            var filas = new List<EstadoResultadosFila>();
            var totales = new EstadoResultadosTotales();

            // Agrupar cuentas por función
            foreach (var funcion in funciones.OrderBy(f => f.Orden))
            {
                // Agregar línea de función
                var filaFuncion = new EstadoResultadosFila
                {
                    Nivel = 0,
                    NombreCuenta = funcion.Nombre,
                    Funcion = funcion.Nombre,
                    TipoLinea = funcion.TipoLinea,
                    EsGrupo = true,
                    EsVisible = true
                };
                filas.Add(filaFuncion);

                // Obtener cuentas de esta función
                var cuentasFuncion = cuentasResultados
                    .Where(c => EsCuentaDeFuncion(c.Codigo, funcion))
                    .ToList();

                double totalFuncion = 0;

                foreach (var cuenta in cuentasFuncion)
                {
                    var saldo = await CalcularSaldoCuentaAsync(request, cuenta.IdCuenta);
                    var saldoAnterior = request.MostrarComparativo
                        ? await CalcularSaldoCuentaAnteriorAsync(request, cuenta.IdCuenta)
                        : 0;

                    var fila = new EstadoResultadosFila
                    {
                        Nivel = cuenta.Nivel,
                        CodigoCuenta = cuenta.Codigo,
                        NombreCuenta = cuenta.Descripcion,
                        Funcion = funcion.Nombre,
                        MontoActual = saldo,
                        MontoAnterior = saldoAnterior,
                        Variacion = saldo - saldoAnterior,
                        VariacionPorcentaje = saldoAnterior != 0 ? ((saldo - saldoAnterior) / Math.Abs(saldoAnterior)) * 100 : 0,
                        TipoLinea = funcion.TipoLinea,
                        IdCuenta = cuenta.IdCuenta,
                        EsVisible = true
                    };

                    filas.Add(fila);
                    totalFuncion += saldo;
                }

                // Agregar subtotal de función
                if (request.VerSubTotales && cuentasFuncion.Any())
                {
                    var filaSubtotal = new EstadoResultadosFila
                    {
                        Nivel = 0,
                        NombreCuenta = $"Total {funcion.Nombre}",
                        MontoActual = totalFuncion,
                        Funcion = funcion.Nombre,
                        TipoLinea = funcion.TipoLinea,
                        EsSubTotal = true,
                        EsVisible = true
                    };
                    filas.Add(filaSubtotal);
                }

                // Acumular en totales
                ActualizarTotales(totales, funcion.TipoLinea, funcion.Nombre, totalFuncion);
            }

            // Calcular resultados intermedios
            CalcularResultadosIntermedios(totales, filas, request.VerSubTotales);

            var response = new EstadoResultadosResponse
            {
                Filas = filas,
                Totales = totales,
                Filtros = new EstadoResultadosFiltros
                {
                    FechaDesde = request.FechaDesde,
                    FechaHasta = request.FechaHasta,
                    Nivel = request.Nivel,
                    TipoAjuste = request.TipoAjuste,
                    SoloLibroOficial = request.SoloLibroOficial,
                    VerSubTotales = request.VerSubTotales,
                    VerCodigoCuenta = request.VerCodigoCuenta,
                    MostrarComparativo = request.MostrarComparativo
                }
            };

            logger.LogInformation("Estado de resultados generado exitosamente con {Count} filas", filas.Count);
            return response;
        }
    }

    public async Task<List<FuncionCuenta>> ObtenerFuncionesAsync()
    {
        // Funciones estándar según IFRS
        return await Task.FromResult(new List<FuncionCuenta>
        {
            new FuncionCuenta { IdFuncion = 1, Nombre = "Ingresos de Actividades Ordinarias", Orden = 1, TipoLinea = "Ingreso", RangoCuentasDesde = "41", RangoCuentasHasta = "4199" },
            new FuncionCuenta { IdFuncion = 2, Nombre = "Costo de Ventas", Orden = 2, TipoLinea = "Costo", RangoCuentasDesde = "51", RangoCuentasHasta = "5199" },
            new FuncionCuenta { IdFuncion = 3, Nombre = "Gastos de Administración", Orden = 3, TipoLinea = "Gasto", RangoCuentasDesde = "52", RangoCuentasHasta = "5299" },
            new FuncionCuenta { IdFuncion = 4, Nombre = "Gastos de Ventas y Distribución", Orden = 4, TipoLinea = "Gasto", RangoCuentasDesde = "53", RangoCuentasHasta = "5399" },
            new FuncionCuenta { IdFuncion = 5, Nombre = "Otros Ingresos por Función", Orden = 5, TipoLinea = "Ingreso", RangoCuentasDesde = "42", RangoCuentasHasta = "4299" },
            new FuncionCuenta { IdFuncion = 6, Nombre = "Otros Gastos por Función", Orden = 6, TipoLinea = "Gasto", RangoCuentasDesde = "54", RangoCuentasHasta = "5499" },
            new FuncionCuenta { IdFuncion = 7, Nombre = "Ingresos Financieros", Orden = 7, TipoLinea = "Ingreso", RangoCuentasDesde = "43", RangoCuentasHasta = "4399" },
            new FuncionCuenta { IdFuncion = 8, Nombre = "Gastos Financieros", Orden = 8, TipoLinea = "Gasto", RangoCuentasDesde = "55", RangoCuentasHasta = "5599" },
            new FuncionCuenta { IdFuncion = 9, Nombre = "Impuesto a las Ganancias", Orden = 9, TipoLinea = "Gasto", RangoCuentasDesde = "59", RangoCuentasHasta = "5999" }
        });
    }

    public async Task<byte[]> ExportarEstadoResultadosAsync(EstadoResultadosExportRequest request)
    {
        {
            logger.LogInformation("Exportando estado de resultados a {Formato}", request.Formato);

            // Generar el estado de resultados
            var estadoRequest = new EstadoResultadosRequest
            {
                EmpresaId = request.EmpresaId,
                Ano = request.Ano,
                FechaDesde = request.FechaDesde,
                FechaHasta = request.FechaHasta,
                Nivel = request.Nivel,
                TipoAjuste = request.TipoAjuste,
                AreaNegocioId = request.AreaNegocioId,
                CentroCostoId = request.CentroCostoId,
                SoloLibroOficial = request.SoloLibroOficial,
                VerSubTotales = request.VerSubTotales,
                VerCodigoCuenta = request.VerCodigoCuenta,
                MostrarComparativo = request.MostrarComparativo
            };

            var estado = await GenerarEstadoResultadosAsync(estadoRequest);

            // Por ahora, retornar array vacío - implementar exportación real más adelante
            logger.LogWarning("Exportación de estado de resultados no implementada completamente");
            return Array.Empty<byte>();
        }
    }

    public async Task<AnalisisEstadoResultados> ObtenerAnalisisAsync(EstadoResultadosRequest request)
    {
        {
            logger.LogInformation("Generando análisis de estado de resultados");

            var estado = await GenerarEstadoResultadosAsync(request);
            var analisis = new AnalisisEstadoResultados();

            // Análisis Vertical (% sobre ingresos)
            if (estado.Totales.TotalIngresos != 0)
            {
                analisis.AnalisisVertical = new List<AnalisisVerticalItem>
                {
                    new AnalisisVerticalItem { Concepto = "Ingresos", Monto = estado.Totales.TotalIngresos, Porcentaje = 100 },
                    new AnalisisVerticalItem { Concepto = "Costos de Venta", Monto = estado.Totales.TotalCostosVenta, Porcentaje = (estado.Totales.TotalCostosVenta / estado.Totales.TotalIngresos) * 100 },
                    new AnalisisVerticalItem { Concepto = "Utilidad Bruta", Monto = estado.Totales.UtilidadBruta, Porcentaje = (estado.Totales.UtilidadBruta / estado.Totales.TotalIngresos) * 100 },
                    new AnalisisVerticalItem { Concepto = "Gastos Administración", Monto = estado.Totales.TotalGastosAdministracion, Porcentaje = (estado.Totales.TotalGastosAdministracion / estado.Totales.TotalIngresos) * 100 },
                    new AnalisisVerticalItem { Concepto = "Gastos Ventas", Monto = estado.Totales.TotalGastosVentas, Porcentaje = (estado.Totales.TotalGastosVentas / estado.Totales.TotalIngresos) * 100 },
                    new AnalisisVerticalItem { Concepto = "Utilidad Operacional", Monto = estado.Totales.UtilidadOperacional, Porcentaje = (estado.Totales.UtilidadOperacional / estado.Totales.TotalIngresos) * 100 },
                    new AnalisisVerticalItem { Concepto = "Resultado Neto", Monto = estado.Totales.ResultadoNeto, Porcentaje = (estado.Totales.ResultadoNeto / estado.Totales.TotalIngresos) * 100 }
                };
            }

            // Ratios Financieros
            analisis.Ratios = new RatiosFinancieros
            {
                MargenBruto = estado.Totales.MargenBruto,
                MargenOperacional = estado.Totales.MargenOperacional,
                MargenNeto = estado.Totales.MargenNeto,
                EBITDA = estado.Totales.UtilidadOperacional, // Simplificado
                MargenEBITDA = estado.Totales.TotalIngresos != 0 ? (estado.Totales.UtilidadOperacional / estado.Totales.TotalIngresos) * 100 : 0
            };

            return analisis;
        }
    }

    public async Task<EstadoResultadosGraficos> ObtenerGraficosAsync(EstadoResultadosRequest request)
    {
        {
            logger.LogInformation("Generando gráficos de estado de resultados");

            var estado = await GenerarEstadoResultadosAsync(request);
            var graficos = new EstadoResultadosGraficos();

            // Ingresos por función
            var ingresosPorFuncion = estado.Filas
                .Where(f => f.TipoLinea == "Ingreso" && f.EsSubTotal)
                .Select(f => new GraficoDataPoint
                {
                    Etiqueta = f.NombreCuenta,
                    Valor = f.MontoActual,
                    Color = "#10b981"
                })
                .ToList();
            graficos.IngresosPorFuncion = ingresosPorFuncion;

            // Gastos por función
            var gastosPorFuncion = estado.Filas
                .Where(f => (f.TipoLinea == "Gasto" || f.TipoLinea == "Costo") && f.EsSubTotal)
                .Select(f => new GraficoDataPoint
                {
                    Etiqueta = f.NombreCuenta,
                    Valor = Math.Abs(f.MontoActual),
                    Color = "#ef4444"
                })
                .ToList();
            graficos.GastosPorFuncion = gastosPorFuncion;

            return graficos;
        }
    }

    public async Task<(bool IsValid, List<string> Errors)> ValidarFiltrosAsync(EstadoResultadosRequest request)
    {
        var errors = new List<string>();

        if (request.FechaDesde > request.FechaHasta)
        {
            errors.Add("La fecha desde no puede ser mayor que la fecha hasta");
        }

        if (request.EmpresaId <= 0)
        {
            errors.Add("Debe especificar una empresa válida");
        }

        if (request.Ano <= 0)
        {
            errors.Add("Debe especificar un año válido");
        }

        // Verificar que la empresa existe
        var empresaExiste = await context.Empresa
            .AnyAsync(e => e.Id == request.EmpresaId && e.Ano == request.Ano);

        if (!empresaExiste)
        {
            errors.Add($"No se encontró la empresa {request.EmpresaId} para el año {request.Ano}");
        }

        return (errors.Count == 0, errors);
    }

    #region Métodos Privados

    private async Task<List<CuentaInfo>> ObtenerCuentasResultadosAsync(EstadoResultadosRequest request)
    {
        var query = context.Cuentas
            .Where(c => c.IdEmpresa == request.EmpresaId && c.Ano == request.Ano);

        // Filtrar solo cuentas de resultado (ingresos y gastos - códigos que empiezan con 4 o 5)
        query = query.Where(c => c.Codigo.StartsWith("4") || c.Codigo.StartsWith("5"));

        if (request.Nivel.HasValue)
        {
            query = query.Where(c => c.Nivel <= request.Nivel.Value);
        }

        var cuentas = await query
            .Select(c => new CuentaInfo
            {
                IdCuenta = c.idCuenta,
                Codigo = c.Codigo ?? string.Empty,
                Descripcion = c.Descripcion ?? string.Empty,
                Nivel = c.Nivel ?? 0
            })
            .OrderBy(c => c.Codigo)
            .ToListAsync();

        return cuentas;
    }

    private async Task<double> CalcularSaldoCuentaAsync(EstadoResultadosRequest request, int idCuenta)
    {
        var fechaDesdeInt = ConvertirFechaAInt(request.FechaDesde);
        var fechaHastaInt = ConvertirFechaAInt(request.FechaHasta);

        var query = from m in context.MovComprobante
            join comp in context.Comprobante on m.IdComp equals comp.IdComp
            where m.IdCuenta == idCuenta
                  && m.IdEmpresa == request.EmpresaId
                  && m.Ano == request.Ano
                  && comp.Fecha >= fechaDesdeInt
                  && comp.Fecha <= fechaHastaInt
            select m;

        if (request.SoloLibroOficial)
        {
            query = from m in query
                join comp in context.Comprobante on m.IdComp equals comp.IdComp
                where comp.Estado == 2 // 2 = Aprobado
                    select m;
        }

        if (request.TipoAjuste.HasValue)
        {
            query = from m in query
                join comp in context.Comprobante on m.IdComp equals comp.IdComp
                where comp.TipoAjuste == request.TipoAjuste.Value
                select m;
        }

        if (request.AreaNegocioId.HasValue)
        {
            query = query.Where(m => m.idAreaNeg == request.AreaNegocioId.Value);
        }

        if (request.CentroCostoId.HasValue)
        {
            query = query.Where(m => m.idCCosto == request.CentroCostoId.Value);
        }

        var movimientos = await query
            .GroupBy(m => m.IdCuenta)
            .Select(g => new
            {
                TotalDebe = g.Sum(m => m.Debe ?? 0),
                TotalHaber = g.Sum(m => m.Haber ?? 0)
            })
            .FirstOrDefaultAsync();

        if (movimientos == null)
            return 0;

        // Para cuentas de resultado, el saldo es Haber - Debe (ingresos positivos, gastos negativos)
        return movimientos.TotalHaber - movimientos.TotalDebe;
    }

    private async Task<double> CalcularSaldoCuentaAnteriorAsync(EstadoResultadosRequest request, int idCuenta)
    {
        // Calcular el mismo período del año anterior
        var fechaDesdeAnterior = request.FechaDesde.AddYears(-1);
        var fechaHastaAnterior = request.FechaHasta.AddYears(-1);
        short anoAnterior = request.Ano;
        anoAnterior--;

        var requestAnterior = new EstadoResultadosRequest
        {
            EmpresaId = request.EmpresaId,
            Ano = anoAnterior,
            FechaDesde = fechaDesdeAnterior,
            FechaHasta = fechaHastaAnterior,
            TipoAjuste = request.TipoAjuste,
            AreaNegocioId = request.AreaNegocioId,
            CentroCostoId = request.CentroCostoId,
            SoloLibroOficial = request.SoloLibroOficial
        };

        return await CalcularSaldoCuentaAsync(requestAnterior, idCuenta);
    }

    private bool EsCuentaDeFuncion(string codigoCuenta, FuncionCuenta funcion)
    {
        // Verificar si el código de cuenta está en el rango de la función
        return string.Compare(codigoCuenta, funcion.RangoCuentasDesde, StringComparison.Ordinal) >= 0
               && string.Compare(codigoCuenta, funcion.RangoCuentasHasta, StringComparison.Ordinal) <= 0;
    }

    private int ConvertirFechaAInt(DateTime fecha)
    {
        // Convierte DateTime a formato int OLE/Excel
        return (int)fecha.ToOADate();
    }

    private void ActualizarTotales(EstadoResultadosTotales totales, string tipoLinea, string nombreFuncion, double monto)
    {
        switch (nombreFuncion)
        {
            case "Ingresos de Actividades Ordinarias":
                totales.TotalIngresos = monto;
                break;
            case "Costo de Ventas":
                totales.TotalCostosVenta = Math.Abs(monto);
                break;
            case "Gastos de Administración":
                totales.TotalGastosAdministracion = Math.Abs(monto);
                break;
            case "Gastos de Ventas y Distribución":
                totales.TotalGastosVentas = Math.Abs(monto);
                break;
            case "Otros Ingresos por Función":
                totales.TotalIngresosNoOperacionales += monto;
                break;
            case "Otros Gastos por Función":
                totales.TotalGastosNoOperacionales += Math.Abs(monto);
                break;
            case "Ingresos Financieros":
                totales.TotalIngresosNoOperacionales += monto;
                break;
            case "Gastos Financieros":
                totales.TotalGastosFinancieros = Math.Abs(monto);
                break;
            case "Impuesto a las Ganancias":
                totales.ImpuestoRenta = Math.Abs(monto);
                break;
        }
    }

    private void CalcularResultadosIntermedios(EstadoResultadosTotales totales, List<EstadoResultadosFila> filas, bool verSubtotales)
    {
        // Utilidad Bruta = Ingresos - Costo de Ventas
        totales.UtilidadBruta = totales.TotalIngresos - totales.TotalCostosVenta;

        // Utilidad Operacional = Utilidad Bruta - Gastos Operacionales
        totales.UtilidadOperacional = totales.UtilidadBruta - totales.TotalGastosAdministracion - totales.TotalGastosVentas;

        // Resultado antes de impuesto
        totales.ResultadoAntesImpuesto = totales.UtilidadOperacional 
                                         + totales.TotalIngresosNoOperacionales 
                                         - totales.TotalGastosNoOperacionales 
                                         - totales.TotalGastosFinancieros;

        // Resultado Neto
        totales.ResultadoNeto = totales.ResultadoAntesImpuesto - totales.ImpuestoRenta;

        if (verSubtotales)
        {
            // Agregar líneas de totales intermedios
            filas.Add(new EstadoResultadosFila
            {
                NombreCuenta = "UTILIDAD BRUTA",
                MontoActual = totales.UtilidadBruta,
                TipoLinea = "Resultado",
                EsTotal = true,
                EsVisible = true
            });

            filas.Add(new EstadoResultadosFila
            {
                NombreCuenta = "UTILIDAD OPERACIONAL",
                MontoActual = totales.UtilidadOperacional,
                TipoLinea = "Resultado",
                EsTotal = true,
                EsVisible = true
            });

            filas.Add(new EstadoResultadosFila
            {
                NombreCuenta = "RESULTADO ANTES DE IMPUESTO",
                MontoActual = totales.ResultadoAntesImpuesto,
                TipoLinea = "Resultado",
                EsTotal = true,
                EsVisible = true
            });

            filas.Add(new EstadoResultadosFila
            {
                NombreCuenta = "RESULTADO NETO",
                MontoActual = totales.ResultadoNeto,
                TipoLinea = "Resultado",
                EsTotal = true,
                EsVisible = true
            });
        }
    }

    #endregion

    // Clase auxiliar
    private class CuentaInfo
    {
        public int IdCuenta { get; set; }
        public string Codigo { get; set; } = string.Empty;
        public string Descripcion { get; set; } = string.Empty;
        public byte Nivel { get; set; }
    }
}