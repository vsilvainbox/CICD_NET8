using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.BalanceClasificado;

/// <summary>
/// MVC Controller para Balance Clasificado
/// </summary>
public class BalanceClasificadoController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<BalanceClasificadoController> logger) : Controller
{
    /// <summary>
    /// Vista principal del balance clasificado
    /// </summary>
    public async Task<IActionResult> Index()
    {
        // Cargar opciones de filtros
        var httpClient = httpClientFactory.CreateClient("ApiClient");

        var url = linkGenerator.GetPathByAction(
            action: nameof(BalanceClasificadoApiController.GetOpcionesFiltros),
            controller: nameof(BalanceClasificadoApiController).Replace("Controller", ""),
            values: new { empresaId = SessionHelper.EmpresaId, ano = SessionHelper.Ano });
        var opcionesResponse = await httpClient.GetFromApiAsync<BalanceClasificadoOpciones>(url!);

        ViewBag.OpcionesFiltros = opcionesResponse ?? new BalanceClasificadoOpciones();

        // Crear modelo con valores por defecto
        var model = new BalanceClasificadoRequest
        {
            IdEmpresa = SessionHelper.EmpresaId,
            Ano = SessionHelper.Ano,
            FechaDesde = new DateTime(SessionHelper.Ano, 1, 1),
            FechaCorte = new DateTime(SessionHelper.Ano, 12, 31),
            NivelDetalle = 5,
            LibroOficial = false,
            VerSubTotales = true,
            VerCodigoCuenta = false
        };

        return View(model);
    }

    /// <summary>
    /// Vista de exportaci�n
    /// </summary>
    public IActionResult Exportar()
    {
        return View();
    }

    /// <summary>
    /// Vista de estad�sticas
    /// </summary>
    public IActionResult Estadisticas()
    {
        return View();
    }

    #region API Proxy Methods

    /// <summary>
    /// Proxy: Genera el balance clasificado
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Generar([FromBody] JsonElement request)
    {
        {
            logger.LogInformation("Proxy: Generar balance clasificado");
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(BalanceClasificadoApiController.GenerarBalance),
                controller: nameof(BalanceClasificadoApiController).Replace("Controller", ""));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// Proxy: Obtiene vista previa del balance
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> VistaPrevia([FromBody] JsonElement request)
    {
        {
            logger.LogInformation("Proxy: Vista previa balance clasificado");
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(BalanceClasificadoApiController.GetVistaPrevia),
                controller: nameof(BalanceClasificadoApiController).Replace("Controller", ""));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// Proxy: Exporta el balance a Excel
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> ExportarBalance([FromBody] JsonElement request)
    {
        {
            logger.LogInformation("Proxy: Exportar balance clasificado");
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(BalanceClasificadoApiController.ExportarBalance),
                controller: nameof(BalanceClasificadoApiController).Replace("Controller", ""));
            var (fileBytes, contentType) = await client.DownloadFileAsync(
                url,
                HttpMethod.Post,
                request);
            return File(fileBytes, contentType);
        }
    }

    /// <summary>
    /// Proxy: Calcula suma de movimientos seleccionados
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> SumaMovimientos([FromBody] JsonElement request)
    {
        {
            logger.LogInformation("Proxy: Suma movimientos");
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(BalanceClasificadoApiController.CalcularSumaMovimientos),
                controller: nameof(BalanceClasificadoApiController).Replace("Controller", ""));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// Proxy: Obtiene estadísticas del balance
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> ObtenerEstadisticas([FromBody] JsonElement request)
    {
        {
            logger.LogInformation("Proxy: Obtener estadísticas balance");
            var client = httpClientFactory.CreateClient("ApiClient");

            var url = linkGenerator.GetPathByAction(
                action: nameof(BalanceClasificadoApiController.GetEstadisticas),
                controller: nameof(BalanceClasificadoApiController).Replace("Controller", ""));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    #endregion
}