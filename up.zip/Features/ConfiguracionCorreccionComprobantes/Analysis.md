# Análisis Exhaustivo: Configuración Corrección Comprobantes (FrmConfigCorrComp.frm)

**Fecha de Análisis:** 2025-10-03  
**Archivo VB6 Fuente:** `FrmConfigCorrComp.frm`  
**Propósito:** Migrar funcionalidad de configuración de parámetros de comprobantes contables

---

## 1. DESCRIPCIÓN GENERAL

### Funcionalidad Principal
Formulario de configuración que permite establecer parámetros globales para el manejo de comprobantes contables en la empresa. Incluye configuración de correlativos, estados predeterminados, opciones de impresión y fechas de centralización.

### Tipo de Interfaz
- **Tipo:** Formulario modal de configuración (Dialog)
- **Modo:** Edición de parámetros de empresa
- **Retorno:** vbOK o vbCancel

### Características VB6
- BorderStyle: Fixed Dialog (no redimensionable)
- MaxButton/MinButton: False
- ShowInTaskbar: False
- StartUpPosition: CenterOwner
- Dimensiones: 12885 x 6360 twips

---

## 2. CONTROLES DE INTERFAZ

### 2.1 Frame: Correlativo Comprobantes (Fr_CorrComp)
**Ubicación:** Left: 1080, Top: 180, Width: 4935, Height: 3675

#### Sub-Frame: Tipo (Fr_TipoComp)
- **Op_TipoCorr(2):** "Por tipo de comprobante (Ingreso, Egreso o Traspaso)"
  - Constante VB6: `TCC_TIPOCOMP = 2`
  - TabIndex: 0
  
- **Op_TipoCorr(1):** "Único (independiente del tipo de comprobante)"
  - Constante VB6: `TCC_UNICO = 1`
  - TabIndex: 1

#### Sub-Frame: Periodo (Frame4)
- **Op_PerCorr(1):** "Mensual"
  - Constante VB6: `TCC_MENSUAL = 1`
  - TabIndex: 2
  
- **Op_PerCorr(2):** "Anual"
  - Constante VB6: `TCC_ANUAL = 2`
  - TabIndex: 3

- **Op_PerCorr(3):** "Continuo (no se reinicia con cada período)"
  - Constante VB6: `TCC_CONTINUO = 3`
  - Visible: False (funcionalidad oculta)

#### Advertencia (Label1)
- Texto: "La renumeración con ingreso de un correlativo inicial sólo es válida para PERIODO ANUAL"
- Color: Rojo (&H00FF0000)

**Regla de Negocio:**
- Frame deshabilitado si existen comprobantes (excepto apertura)
- No se permite cambiar correlativo si ya hay comprobantes ingresados
- Query validación: `SELECT IdComp FROM Comprobante WHERE Tipo <> TC_APERTURA`

### 2.2 Frame: Opciones (Fr_OpComp)
**Ubicación:** Left: 6240, Top: 180, Width: 4935, Height: 1455

#### Checkboxes
1. **Ch_CompAprobado** (TabIndex: 6)
   - Texto: "Todo comprobante queda Aprobado al momento de crearlo"
   - ParamEmpresa.Tipo: 'ESTADOCOMP'
   - Valores: `EC_APROBADO = 2` o `EC_PENDIENTE = 1`
   - Tooltip: "Si no marca esta opción, los comprobantes toman el estado Pendiente"

2. **Ch_AbrirMesesParalelo** (TabIndex: 7)
   - Texto: "Se permite abrir más de un mes en paralelo"
   - ParamEmpresa.Tipo: 'MESPARALEL'
   - Valores: True/False (booleano)
   - Habilitado condicionalmente según período de correlativo

3. **Ch_CompAnuladoLibDiario** (TabIndex: 8)
   - Texto: "Se muestran los comprobantes anulados en el Libro Diario"
   - ParamEmpresa.Tipo: 'VERCOMPANU'
   - Valores: True/False (booleano)

### 2.3 Frame: Impresión de Comprobante (Frame6)
**Ubicación:** Left: 6240, Top: 1800, Width: 4935, Height: 2055

#### Checkbox Principal
- **Ch_TituloTipoComp** (TabIndex: 9)
  - Texto: "Incluir Tipo de Comprobante en el Título"
  - ParamEmpresa.Tipo: 'TITTIPCOMP'
  - Valores: True/False

#### Sub-Frame: Contenido Columna Detalle Movimiento (Frame5)
**OptionButtons:** Op_PrtMovDet(1..4)

1. **Op_PrtMovDet(1):** "Descripción" (TabIndex: 10)
   - Constante: `PRTMOV_DESC = 1`
   
2. **Op_PrtMovDet(2):** "Entidad" (TabIndex: 11)
   - Constante: `PRTMOV_ENTIDAD = 2`
   
3. **Op_PrtMovDet(3):** "Centro de Gestión" (TabIndex: 12)
   - Constante: `PRTMOV_CCOSTO = 3`
   
4. **Op_PrtMovDet(4):** "Área de Negocio" (TabIndex: 13)
   - Constante: `PRTMOV_AREANEG = 4`

**ParamEmpresa.Tipo:** 'PRTMOVDET'  
**Constante:** `MAX_PRTMOV = 4`

### 2.4 Frame: Impresión Resumida (Frame1)
**Ubicación:** Left: 1080, Top: 4020, Width: 4935, Height: 1935

#### Controles
- **Ch_ImpResCent** (TabIndex: 4)
  - Texto: "Todo nuevo comprobante de centralización queda con la"
  - Label complementario: "opción 'Imprimir Resumido' automáticamente seleccionada."
  - ParamEmpresa.Tipo: 'IMPRESCENT'
  - Visible solo si `gFunciones.ComprobanteResumido = True`

- **Bt_MarcarRes** (TabIndex: 5)
  - Caption: "Aplicar a los comprobantes ya existentes"
  - Acción: UPDATE masivo a comprobantes de centralización existentes

**Query de Actualización (Bt_MarcarRes_Click):**
```vb
sFrom = " Comprobante INNER JOIN MovComprobante ON Comprobante.IdComp = MovComprobante.IdComp "
sSet = " Comprobante.ImpResumido = 1 "
sWhere = " WHERE MovComprobante.DeCentraliz <> 0"
sWhere = sWhere & " AND Comprobante.IdEmpresa = " & gEmpresa.id & " AND Comprobante.Ano = " & gEmpresa.Ano
```

**Auditoria:**
```vb
Call SeguimientoComprobantes(0, gEmpresa.id, gEmpresa.Ano, "FrmConfigCorrComp.Bt_MarcarRes_Click", "", 1, sWhere, gUsuario.IdUsuario, 1, 2)
```

### 2.5 Frame: Fecha Comprobante Centralización (Frame2)
**Ubicación:** Left: 6240, Top: 4020, Width: 4935, Height: 1935

#### OptionButtons: Op_DtCompCent(1..3)

1. **Op_DtCompCent(1):** "Mantener configuración predefinida por el sistema" (TabIndex: 14)
   - Constante: `DTCOMPCENT_CURRDEF = 1`
   - Comportamiento: Usa fecha actual del sistema

2. **Op_DtCompCent(2):** "Asignar último día del mes a la fecha de los comprobantes" (TabIndex: 15)
   - Constante: `DTCOMPCENT_LASTDAY = 2`
   - Comportamiento: Fecha = último día del mes

3. **Op_DtCompCent(3):** "Asignar día [__] del mes a la fecha de los comprobantes" (TabIndex: 16)
   - Constante: `DTCOMPCENT_DEFDAY = 3`
   - TextBox asociado: **Tx_DayDtCompCent** (TabIndex: 17)
     - MaxLength: 2
     - Validación: Debe ser <= 30
     - KeyPress: Solo números positivos (`Call KeyNumPos(KeyAscii)`)
     - Change event: Selecciona automáticamente Op_DtCompCent(3)

**ParamEmpresa.Tipo:** 
- 'DTCOMPCENT' → Opción seleccionada (1, 2 o 3)
- 'DYCOMPCENT' → Día específico del mes (cuando opción = 3)

**Labels:**
- Label6: "de centralización"
- Label5(1): " " (espacio para alineación)

### 2.6 Botones de Acción
- **Bt_Ok** (TabIndex: 18)
  - Caption: "Aceptar"
  - Ubicación: Top: 300
  - Acción: Validar y guardar

- **Bt_Cancel** (TabIndex: 19)
  - Caption: "Cancelar"
  - Cancel: True
  - Ubicación: Top: 660
  - Acción: Cerrar sin guardar

### 2.7 Otros Elementos
- **Picture1:** Ícono decorativo (615 x 675 twips)
  - BorderStyle: None
  - AutoSize: True

---

## 3. VARIABLES GLOBALES UTILIZADAS

### Variables de Configuración (módulo HyperCont.bas)

#### Correlativos
```vb
Public Const TCC_UNICO = 1
Public Const TCC_TIPOCOMP = 2
Public Const TCC_MENSUAL = 1
Public Const TCC_ANUAL = 2
Public Const TCC_CONTINUO = 3

Global gTipoCorrComp As Integer    ' Tipo de correlativo actual
Global gPerCorrComp As Integer     ' Período de correlativo actual
```

#### Estados de Comprobante
```vb
' Constantes (HyperComun.bas):
Public Const EC_PENDIENTE = 1
Public Const EC_APROBADO = 2
Public Const EC_ANULADO = 3
Public Const TC_APERTURA = 1

Global gEstadoNewComp As Integer   ' Estado inicial de nuevos comprobantes
```

#### Opciones de Visualización e Impresión
```vb
Global gCompAnuladoLibDiario As Integer       ' Mostrar comprobantes anulados
Global gAbrirMesesParalelo As Boolean         ' Permitir meses paralelos
Global gImpResCent As Boolean                 ' Imprimir resumido centralización
Global gTituloTipoComp As Boolean             ' Incluir tipo en título impresión
```

#### Opciones de Impresión Detalle
```vb
Public Const PRTMOV_DESC = 1          ' Imprimir Descripción
Public Const PRTMOV_ENTIDAD = 2       ' Imprimir Entidad
Public Const PRTMOV_CCOSTO = 3        ' Imprimir Centro Costo
Public Const PRTMOV_AREANEG = 4       ' Imprimir Área Negocio
Public Const MAX_PRTMOV = PRTMOV_AREANEG

Public gPrtMovDetOpt As Integer       ' Opción seleccionada
```

#### Fecha Centralización
```vb
Public Const DTCOMPCENT_CURRDEF = 1   ' Mantener predefinida
Public Const DTCOMPCENT_LASTDAY = 2   ' Último día del mes
Public Const DTCOMPCENT_DEFDAY = 3    ' Día específico

Global gDtCompCent As Integer         ' Opción fecha centralización
Global gDayDtCompCent As Integer      ' Día específico (si aplica)
```

#### Empresa Actual
```vb
' gEmpresa.id        → IdEmpresa actual
' gEmpresa.Ano       → Año fiscal actual
' gEmpresa.FCierre   → Fecha de cierre (0 si no cerrado)
```

#### Funcionalidades
```vb
' gFunciones.ComprobanteResumido → Boolean (indica si funcionalidad disponible)
```

---

## 4. EVENTOS Y LÓGICA DE NEGOCIO

### 4.1 Form_Load()

#### Secuencia de Inicialización
1. **Habilitar/Deshabilitar formulario:**
   ```vb
   Call EnableForm(Me, gEmpresa.FCierre = 0)
   ```
   - Si empresa cerrada (FCierre <> 0), deshabilitar todo

2. **Configurar opción predeterminada:**
   ```vb
   Op_DtCompCent(DTCOMPCENT_CURRDEF) = 1
   ```

3. **Cargar configuración actual:**
   ```vb
   Call LoadAll
   ```

4. **Verificar privilegios:**
   ```vb
   Call SetupPriv
   ```
   - Requiere privilegio: `PRV_CFG_EMP`

5. **Ocultar funcionalidad Imprimir Resumido (si no disponible):**
   ```vb
   If Not gFunciones.ComprobanteResumido Then
      Ch_ImpResCent.visible = False
      Ch_ImpResCent.Enabled = False
      Lb_ImpRes.visible = False
      Fr_OpComp.Height = Fr_OpComp.Height - 500
      Me.Height = Me.Height - 500
   End If
   ```

6. **Deshabilitar correlativo si hay comprobantes:**
   ```vb
   Q1 = "SELECT IdComp FROM Comprobante WHERE Tipo <> " & TC_APERTURA
   Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.id & " AND Ano = " & gEmpresa.Ano
   Set Rs = OpenRs(DbMain, Q1)
   
   If Rs.EOF = False Then    ' Hay al menos un comprobante
      Fr_CorrComp.Enabled = False
   End If
   ```

### 4.2 LoadAll()

Carga configuración actual desde variables globales:

```vb
' TIPO CORRELATIVO
If gTipoCorrComp > 0 Then
   lIndexTipoCorr = gTipoCorrComp
Else
   lIndexTipoCorr = TCC_UNICO
End If
Op_TipoCorr(lIndexTipoCorr).Value = True

' PERIODO CORRELATIVO
If gPerCorrComp > 0 Then
   lIndexPerCorr = gPerCorrComp
Else
   lIndexPerCorr = TCC_ANUAL
End If
Op_PerCorr(lIndexPerCorr).Value = True

' ESTADO COMPROBANTE
Ch_CompAprobado = Abs(gEstadoNewComp = EC_APROBADO)

' COMPROBANTES ANULADOS EN LIBRO DIARIO
Ch_CompAnuladoLibDiario = Abs(gCompAnuladoLibDiario)

' ABRIR MESES EN PARALELO
If Ch_AbrirMesesParalelo.Enabled = True Then
   Ch_AbrirMesesParalelo = Abs(gAbrirMesesParalelo)
End If

' OPCIÓN IMPRESIÓN DETALLE
If gPrtMovDetOpt > 0 And gPrtMovDetOpt <= MAX_PRTMOV Then
   Op_PrtMovDet(gPrtMovDetOpt) = True
Else
   Op_PrtMovDet(PRTMOV_DESC) = True
End If

' IMPRIMIR RESUMIDO CENTRALIZACIÓN
If Ch_ImpResCent.Enabled = True Then
   Ch_ImpResCent = Abs(gImpResCent)
End If

' FECHA COMPROBANTE CENTRALIZACIÓN
If gDtCompCent > 0 Then
   Op_DtCompCent(gDtCompCent) = 1
End If
If gDayDtCompCent > 0 Then
   Tx_DayDtCompCent = gDayDtCompCent
End If

' INCLUIR TIPO EN TÍTULO
Ch_TituloTipoComp = Abs(gTituloTipoComp)
```

### 4.3 Bt_OK_Click()

#### Secuencia:
1. **Validar:**
   ```vb
   If Not valida() Then
      Exit Sub
   End If
   ```

2. **Guardar todo:**
   ```vb
   Call SaveAll
   ```

3. **Retornar OK:**
   ```vb
   lRc = vbOK
   Unload Me
   ```

### 4.4 valida() As Boolean

#### Validaciones:

1. **Validar cambio de correlativo:**
   ```vb
   If (gTipoCorrComp > 0 Or gPerCorrComp > 0) And _
      (gTipoCorrComp <> lIndexTipoCorr Or gPerCorrComp <> lIndexPerCorr) Then
      
      Q1 = "SELECT IdComp FROM Comprobante WHERE Tipo <> " & TC_APERTURA
      Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.id & " AND Ano = " & gEmpresa.Ano
      Set Rs = OpenRs(DbMain, Q1)
      
      If Rs.EOF = False Then
         MsgBox1 "No es posible cambiar el tipo de correlativo de los comprobantes, hay comprobantes ya ingresados.", vbExclamation + vbOKOnly
         valida = False
         Exit Function
      End If
   End If
   ```

2. **Validar día del mes:**
   ```vb
   If Val(Tx_DayDtCompCent) > 30 Then
      MsgBox1 "Día del mes asignado para fecha de comprobante de centralización inválido. Debe ser menor o igual a 30.", vbExclamation
      valida = False
      Exit Function
   End If
   ```

### 4.5 SaveAll()

Guarda TODOS los parámetros en la tabla `ParamEmpresa`:

#### Estructura de Guardado:
Para cada parámetro:
1. Verificar si cambió valor respecto a variable global
2. Intentar SELECT para ver si existe registro
3. Si existe: UPDATE
4. Si no existe: INSERT
5. Actualizar variable global

#### Parámetros Guardados:

##### 1. TIPO CORRELATIVO (TCORRCOMP)
```vb
Q1 = "SELECT Valor FROM ParamEmpresa WHERE Tipo = 'TCORRCOMP'"
Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.id & " AND Ano = " & gEmpresa.Ano

If gTipoCorrComp <> lIndexTipoCorr Then
   ' UPDATE o INSERT
   Q1 = "UPDATE ParamEmpresa SET Codigo = 0, Valor = '" & lIndexTipoCorr & "' WHERE Tipo = 'TCORRCOMP'"
   ' ... o INSERT INTO ...
End If

gTipoCorrComp = lIndexTipoCorr
```

##### 2. PERIODO CORRELATIVO (PCORRCOMP)
```vb
If gPerCorrComp <> lIndexPerCorr Then
   Q1 = "UPDATE ParamEmpresa SET Codigo = 0, Valor = '" & lIndexPerCorr & "' WHERE Tipo = 'PCORRCOMP'"
   ' ... o INSERT
End If

gPerCorrComp = lIndexPerCorr
```

##### 3. ESTADO COMPROBANTE (ESTADOCOMP)
```vb
If Ch_CompAprobado <> Abs(gEstadoNewComp = EC_APROBADO) Then
   Estado = EC_PENDIENTE
   If Ch_CompAprobado <> 0 Then
      Estado = EC_APROBADO
   End If
   
   ' UPDATE o INSERT
   gEstadoNewComp = Estado
End If
```

##### 4. MESES PARALELOS (MESPARALEL)
```vb
If Ch_AbrirMesesParalelo <> Abs(gAbrirMesesParalelo = True) Then
   AbrirMesesParalelo = False
   If Ch_AbrirMesesParalelo <> 0 Then
      AbrirMesesParalelo = True
   End If
   
   ' UPDATE o INSERT
   gAbrirMesesParalelo = AbrirMesesParalelo
End If
```

##### 5. COMPROBANTES ANULADOS EN LIBRO DIARIO (VERCOMPANU)
```vb
If Ch_CompAnuladoLibDiario <> Abs(gCompAnuladoLibDiario = True) Then
   CompAnuladoLibDiario = False
   If Ch_CompAnuladoLibDiario <> 0 Then
      CompAnuladoLibDiario = True
   End If
   
   ' UPDATE o INSERT
   gCompAnuladoLibDiario = CompAnuladoLibDiario
End If
```

##### 6. OPCIÓN IMPRESIÓN DETALLE (PRTMOVDET)
```vb
For i = 1 To MAX_PRTMOV
   If Op_PrtMovDet(i) <> 0 Then
      NewOpt = i
      Exit For
   End If
Next i

If NewOpt <> gPrtMovDetOpt Then
   ' UPDATE o INSERT
   gPrtMovDetOpt = NewOpt
End If
```

##### 7. IMPRIMIR RESUMIDO CENTRALIZACIÓN (IMPRESCENT)
```vb
If Ch_ImpResCent <> Abs(gImpResCent = True) Then
   ImpRes = False
   If Ch_ImpResCent <> 0 Then
      ImpRes = True
   End If
   
   ' UPDATE o INSERT
   gImpResCent = ImpRes
End If
```

##### 8. FECHA COMPROBANTE CENTRALIZACIÓN (DTCOMPCENT y DYCOMPCENT)
```vb
If Op_DtCompCent(DTCOMPCENT_CURRDEF) <> 0 Then
   DtCompCent = DTCOMPCENT_CURRDEF
ElseIf Op_DtCompCent(DTCOMPCENT_LASTDAY) <> 0 Then
   DtCompCent = DTCOMPCENT_LASTDAY
Else
   DtCompCent = DTCOMPCENT_DEFDAY
End If

If DtCompCent <> gDtCompCent Or gDayDtCompCent <> vFmt(Tx_DayDtCompCent) Then
   ' UPDATE o INSERT (dos registros: DTCOMPCENT y DYCOMPCENT)
   gDtCompCent = DtCompCent
   gDayDtCompCent = vFmt(Tx_DayDtCompCent)
End If
```

##### 9. INCLUIR TIPO EN TÍTULO (TITTIPCOMP)
```vb
If Ch_TituloTipoComp <> Abs(gTituloTipoComp = True) Then
   TitTipoComp = False
   If Ch_TituloTipoComp <> 0 Then
      TitTipoComp = True
   End If
   
   ' UPDATE o INSERT
   gTituloTipoComp = TitTipoComp
End If
```

### 4.6 Bt_MarcarRes_Click()

Marca TODOS los comprobantes de centralización existentes con ImpResumido = 1:

```vb
Me.MousePointer = vbHourglass

Tbl = "Comprobante"
sFrom = " Comprobante INNER JOIN MovComprobante ON Comprobante.IdComp = MovComprobante.IdComp "
sFrom = sFrom & JoinEmpAno(gDbType, "Comprobante", "MovComprobante")
sSet = " Comprobante.ImpResumido = 1 "
sWhere = " WHERE MovComprobante.DeCentraliz <> 0"
sWhere = sWhere & " AND Comprobante.IdEmpresa = " & gEmpresa.id & " AND Ano = " & gEmpresa.Ano

Call UpdateSQL(DbMain, Tbl, sSet, sFrom, sWhere)

' Auditoría
Call SeguimientoComprobantes(0, gEmpresa.id, gEmpresa.Ano, _
   "FrmConfigCorrComp.Bt_MarcarRes_Click", "", 1, sWhere, _
   gUsuario.IdUsuario, 1, 2)

Me.MousePointer = vbDefault

MsgBox1 "Todos los comprobantes de centralización han quedado con la opción 'Imprimir Resumido' seleccionada.", vbInformation
```

### 4.7 Otros Eventos

#### Op_PerCorr_Click(Index As Integer)
```vb
lIndexPerCorr = Index

' Habilitar/Deshabilitar meses paralelos
Ch_AbrirMesesParalelo.Enabled = True
```

#### Op_TipoCorr_Click(Index As Integer)
```vb
lIndexTipoCorr = Index
```

#### Tx_DayDtCompCent_Change()
```vb
Op_DtCompCent(DTCOMPCENT_DEFDAY) = 1  ' Auto-seleccionar opción 3
```

#### Tx_DayDtCompCent_KeyPress(KeyAscii As Integer)
```vb
Call KeyNumPos(KeyAscii)  ' Solo números positivos
```

#### Bt_Cancel_Click()
```vb
lRc = vbCancel
Unload Me
```

### 4.8 SetupPriv()

Verifica privilegios de usuario:

```vb
If Not ChkPriv(PRV_CFG_EMP) Then
   Call EnableForm(Me, False)  ' Deshabilitar todo el formulario
End If
```

**Privilegio requerido:** `PRV_CFG_EMP` (Configuración de Empresa)

---

## 5. ESTRUCTURA DE DATOS

### 5.1 Tabla: ParamEmpresa

#### Campos:
- **IdEmpresa** (int) - FK a Empresa
- **Ano** (int) - Año fiscal
- **Tipo** (string) - Tipo de parámetro
- **Codigo** (int) - Código auxiliar (generalmente 0)
- **Valor** (string) - Valor del parámetro
- **ValorOld** (string) - Valor anterior (opcional)

#### Tipos de Parámetros (Constantes de string):

| Tipo | Descripción | Valores Posibles | Campo Relacionado |
|------|-------------|------------------|-------------------|
| TCORRCOMP | Tipo correlativo comprobante | "1" (Único), "2" (Por tipo) | gTipoCorrComp |
| PCORRCOMP | Período correlativo | "1" (Mensual), "2" (Anual), "3" (Continuo) | gPerCorrComp |
| ESTADOCOMP | Estado inicial comprobante | "1" (Pendiente), "2" (Aprobado) | gEstadoNewComp |
| MESPARALEL | Permitir meses paralelos | "0" (False), "1" (True) | gAbrirMesesParalelo |
| VERCOMPANU | Ver comprobantes anulados | "0" (False), "1" (True) | gCompAnuladoLibDiario |
| PRTMOVDET | Opción impresión detalle | "1".."4" (DESC/ENT/CC/AN) | gPrtMovDetOpt |
| IMPRESCENT | Imprimir resumido centralizac. | "0" (False), "1" (True) | gImpResCent |
| DTCOMPCENT | Fecha comprobante centraliz. | "1".."3" (Predefinida/Último/Día específico) | gDtCompCent |
| DYCOMPCENT | Día específico centralización | "1".."30" (número) | gDayDtCompCent |
| TITTIPCOMP | Incluir tipo en título | "0" (False), "1" (True) | gTituloTipoComp |

#### Queries de Ejemplo:

**SELECT (verificar existencia):**
```sql
SELECT Valor 
FROM ParamEmpresa 
WHERE Tipo = 'TCORRCOMP' 
  AND IdEmpresa = @IdEmpresa 
  AND Ano = @Ano
```

**UPDATE:**
```sql
UPDATE ParamEmpresa 
SET Codigo = 0, Valor = '@Valor' 
WHERE Tipo = '@Tipo' 
  AND IdEmpresa = @IdEmpresa 
  AND Ano = @Ano
```

**INSERT:**
```sql
INSERT INTO ParamEmpresa (Tipo, Codigo, Valor, IdEmpresa, Ano) 
VALUES ('@Tipo', 0, '@Valor', @IdEmpresa, @Ano)
```

### 5.2 Tabla: Comprobante

Campos utilizados en validaciones:
- **IdComp** (int, PK)
- **Tipo** (int) - Tipo comprobante (1=Apertura, 2=Ingreso, 3=Egreso, 4=Traspaso)
- **Estado** (int) - Estado (1=Pendiente, 2=Aprobado, 3=Anulado)
- **ImpResumido** (bit/int) - Flag impresión resumida
- **IdEmpresa** (int)
- **Ano** (int)

### 5.3 Tabla: MovComprobante

Campos utilizados:
- **IdComp** (int, FK a Comprobante)
- **DeCentraliz** (int/bit) - Flag de centralización (!= 0 si es de centralización)
- **IdEmpresa** (int)
- **Ano** (int)

---

## 6. CONSTANTES Y ENUMERACIONES

### 6.1 Correlativo - Tipo

```csharp
public const int TCC_UNICO = 1;      // Único correlativo
public const int TCC_TIPOCOMP = 2;   // Por tipo de comprobante
```

### 6.2 Correlativo - Período

```csharp
public const int TCC_MENSUAL = 1;    // Reinicia cada mes
public const int TCC_ANUAL = 2;      // Reinicia cada año
public const int TCC_CONTINUO = 3;   // Nunca reinicia (oculto en UI)
```

### 6.3 Estado Comprobante

```csharp
public const int EC_PENDIENTE = 1;   // Requiere aprobación
public const int EC_APROBADO = 2;    // Aprobado automáticamente
public const int EC_ANULADO = 3;     // Anulado
```

### 6.4 Tipo Comprobante

```csharp
public const int TC_APERTURA = 1;    // Comprobante de apertura
public const int TC_INGRESO = 2;     // Ingreso
public const int TC_EGRESO = 3;      // Egreso
public const int TC_TRASPASO = 4;    // Traspaso
```

### 6.5 Opción Impresión Detalle Movimiento

```csharp
public const int PRTMOV_DESC = 1;       // Descripción
public const int PRTMOV_ENTIDAD = 2;    // Entidad
public const int PRTMOV_CCOSTO = 3;     // Centro de Costo
public const int PRTMOV_AREANEG = 4;    // Área de Negocio
public const int MAX_PRTMOV = 4;
```

### 6.6 Fecha Comprobante Centralización

```csharp
public const int DTCOMPCENT_CURRDEF = 1;   // Mantener predefinida
public const int DTCOMPCENT_LASTDAY = 2;   // Último día del mes
public const int DTCOMPCENT_DEFDAY = 3;    // Día específico del mes
```

---

## 7. VALIDACIONES Y REGLAS DE NEGOCIO

### 7.1 Restricciones de Modificación

#### No se permite cambiar correlativo si:
- Existe configuración previa (gTipoCorrComp > 0 OR gPerCorrComp > 0)
- Los valores son diferentes a los actuales
- Existen comprobantes (excepto apertura) en el año

**Query de verificación:**
```sql
SELECT IdComp 
FROM Comprobante 
WHERE Tipo <> 1  -- TC_APERTURA
  AND IdEmpresa = @IdEmpresa 
  AND Ano = @Ano
```

**Mensaje de error:**
> "No es posible cambiar el tipo de correlativo de los comprobantes, hay comprobantes ya ingresados."

### 7.2 Validación de Día del Mes

- Campo: `Tx_DayDtCompCent`
- Restricción: `Valor <= 30`
- Razón: Compatibilidad con todos los meses (febrero tiene mínimo 28/29 días)

**Mensaje de error:**
> "Día del mes asignado para fecha de comprobante de centralización inválido. Debe ser menor o igual a 30."

### 7.3 Habilitación Condicional

#### Frame Correlativo (Fr_CorrComp)
- **Deshabilitado si:** Existen comprobantes (excepto apertura)
- **Motivo:** Evitar inconsistencias en numeración existente

#### Checkbox Meses Paralelos (Ch_AbrirMesesParalelo)
- **Habilitado siempre** (código comentado sugería restricción por período mensual)
- **Lógica en Op_PerCorr_Click:** `Ch_AbrirMesesParalelo.Enabled = True`

#### Frame Impresión Resumida (Frame1)
- **Visible solo si:** `gFunciones.ComprobanteResumido = True`
- **Si no visible:** 
  - Ocultar Ch_ImpResCent y Lb_ImpRes
  - Reducir altura de Fr_OpComp y formulario (-500 twips)

### 7.4 Privilegios

**Privilegio requerido:** `PRV_CFG_EMP` (Configuración de Empresa)

**Comportamiento si no tiene privilegio:**
- Todo el formulario se deshabilita (`Call EnableForm(Me, False)`)
- Usuario puede ver pero no editar

**Verificación adicional:**
- Si `gEmpresa.FCierre <> 0`: Formulario deshabilitado (empresa cerrada)

---

## 8. FLUJO DE DATOS

### 8.1 Carga Inicial (LoadAll)

```
Variables Globales → Interfaz de Usuario
  gTipoCorrComp → Op_TipoCorr(1..2)
  gPerCorrComp → Op_PerCorr(1..3)
  gEstadoNewComp → Ch_CompAprobado
  gAbrirMesesParalelo → Ch_AbrirMesesParalelo
  gCompAnuladoLibDiario → Ch_CompAnuladoLibDiario
  gPrtMovDetOpt → Op_PrtMovDet(1..4)
  gImpResCent → Ch_ImpResCent
  gDtCompCent → Op_DtCompCent(1..3)
  gDayDtCompCent → Tx_DayDtCompCent
  gTituloTipoComp → Ch_TituloTipoComp
```

### 8.2 Guardado (SaveAll)

```
Interfaz → Variables Locales → Base de Datos → Variables Globales

Para cada parámetro:
1. Capturar valor de controles UI
2. Comparar con variable global actual
3. Si cambió:
   a. Verificar si existe registro en ParamEmpresa (SELECT)
   b. Si existe: UPDATE
   c. Si no existe: INSERT
   d. Actualizar variable global
```

### 8.3 Estructura UPDATE/INSERT

**Patrón genérico:**
```vb
' 1. SELECT para verificar existencia
Q1 = "SELECT Valor FROM ParamEmpresa WHERE Tipo = '@Tipo' AND IdEmpresa = @Id AND Ano = @Ano"
Set Rs = OpenRs(DbMain, Q1)

' 2. Si cambió valor
If valorUI <> valorGlobal Then
   
   ' 3a. UPDATE si existe
   If Rs.EOF = False Then
      Call ExecSQL(DbMain, "UPDATE ParamEmpresa SET Codigo = 0, Valor = '@Valor' WHERE Tipo = '@Tipo' AND IdEmpresa = @Id AND Ano = @Ano")
   
   ' 3b. INSERT si no existe
   Else
      Call ExecSQL(DbMain, "INSERT INTO ParamEmpresa (Tipo, Codigo, Valor, IdEmpresa, Ano) VALUES ('@Tipo', 0, '@Valor', @Id, @Ano)")
   End If
   
   ' 4. Actualizar variable global
   valorGlobal = valorUI
End If

Call CloseRs(Rs)
```

---

## 9. MENSAJES AL USUARIO

### 9.1 Mensajes de Información

| Mensaje | Contexto | Tipo |
|---------|----------|------|
| "Todos los comprobantes de centralización han quedado con la opción 'Imprimir Resumido' seleccionada." | Después de Bt_MarcarRes_Click | vbInformation |

### 9.2 Mensajes de Error/Advertencia

| Mensaje | Contexto | Tipo | Acción |
|---------|----------|------|--------|
| "No es posible cambiar el tipo de correlativo de los comprobantes, hay comprobantes ya ingresados." | Validación cambio correlativo con comprobantes existentes | vbExclamation | Bloquea guardado |
| "Día del mes asignado para fecha de comprobante de centralización inválido. Debe ser menor o igual a 30." | Validación Tx_DayDtCompCent > 30 | vbExclamation | Bloquea guardado |

### 9.3 Tooltips

| Control | Tooltip |
|---------|---------|
| Ch_CompAprobado | "Si no marca esta opción, los comprobantes toman el estado Pendiente y deben ser aprobados manualmente." |
| Ch_AbrirMesesParalelo | "Si no marca esta opción, los comprobantes toman el estado Pendiente y deben ser aprobados manualmente." |
| Ch_CompAnuladoLibDiario | "Si no marca esta opción, los comprobantes toman el estado Pendiente y deben ser aprobados manualmente." |

**Nota:** Los tooltips en VB6 son idénticos (probablemente error de copiar/pegar). En .NET debemos mejorar textos descriptivos.

---

## 10. DEPENDENCIAS Y REFERENCIAS

### 10.1 Módulos VB6 Referenciados

- **HyperCont.bas:** Constantes y variables globales de configuración
- **HyperComun.bas:** Constantes de estados y tipos de comprobante
- **HyperContFca.bas:** Funciones de inicialización (gEstadoComp, gTipoComp arrays)

### 10.2 Funciones VB6 Utilizadas

- `EnableForm(Form, Boolean)` - Habilitar/deshabilitar formulario completo
- `OpenRs(DbMain, SQL)` - Abrir recordset
- `CloseRs(Rs)` - Cerrar recordset
- `ExecSQL(DbMain, SQL)` - Ejecutar comando SQL
- `UpdateSQL(DbMain, Tbl, sSet, sFrom, sWhere)` - UPDATE con FROM/JOIN
- `JoinEmpAno(gDbType, Tbl1, Tbl2)` - Genera JOIN con IdEmpresa/Ano
- `MsgBox1(Texto, Tipo)` - Mensaje personalizado
- `ChkPriv(Privilegio)` - Verifica privilegio de usuario
- `KeyNumPos(KeyAscii)` - Validación teclas (solo números positivos)
- `vFmt(Valor)` - Formateo de valor numérico
- `SeguimientoComprobantes(...)` - Auditoría de operaciones sobre comprobantes

### 10.3 Variables Globales Requeridas

```vb
' Base de datos
DbMain As Database

' Empresa actual
gEmpresa.id As Integer
gEmpresa.Ano As Integer
gEmpresa.FCierre As Long

' Usuario
gUsuario.IdUsuario As Integer

' Funcionalidades
gFunciones.ComprobanteResumido As Boolean

' Tipo de BD
gDbType As Integer
```

---

## 11. CONSIDERACIONES DE MIGRACIÓN A .NET

### 11.1 Cambios de Arquitectura

#### De VB6 a .NET 9:
- **Formulario Modal** → MVC View con Modal Dialog (Bootstrap/Tailwind)
- **Variables Globales** → Session/Cache + Parámetros en consultas
- **Recordset** → Entity Framework Core queries con async/await
- **ExecSQL** → DbContext.SaveChanges()
- **MsgBox1** → SweetAlert2 en frontend

### 11.2 Persistencia de Configuración

**VB6:**
- Variables globales cargadas al inicio de aplicación
- Guardado sincrónico en ParamEmpresa
- Actualización inmediata de variables globales

**.NET:**
- Configuración en caché de aplicación (IMemoryCache o similar)
- Servicios de configuración inyectados (IConfiguracionEmpresaService)
- Guardado asíncrono con async/await
- Invalidación de caché después de actualizar

### 11.3 Validaciones

**VB6:**
- Validación en cliente (formulario)
- Mensajes modales bloqueantes

**.NET:**
- Validación en servidor (Data Annotations + FluentValidation)
- Validación adicional en cliente con JavaScript
- Mensajes no bloqueantes (toasts, alerts)

### 11.4 Privilegios

**VB6:**
- Función global `ChkPriv(PRV_CFG_EMP)`
- Deshabilita formulario completo si no tiene privilegio

**.NET:**
- Attribute `[Authorize(Policy = "ConfiguracionEmpresa")]`
- Deshabilitar controles en vista o negar acceso completo

### 11.5 Auditoría

**VB6:**
```vb
Call SeguimientoComprobantes(0, gEmpresa.id, gEmpresa.Ano, _
   "FrmConfigCorrComp.Bt_MarcarRes_Click", "", 1, sWhere, _
   gUsuario.IdUsuario, 1, 2)
```

**.NET:**
- Sistema de auditoría centralizado
- Logging con ILogger<T>
- Rastreo de cambios en ParamEmpresa (tracking manual o EF Change Tracking)

### 11.6 Estructura de DTOs Sugerida

```csharp
// Request DTO
public class ActualizarConfiguracionComprobantesDto
{
    public int EmpresaId { get; set; }
    public int Ano { get; set; }
    
    // Correlativos
    public int TipoCorrelativo { get; set; }
    public int PeriodoCorrelativo { get; set; }
    
    // Opciones
    public bool ComprobanteAprobadoAutomaticamente { get; set; }
    public bool PermitirAbrirMesesParalelo { get; set; }
    public bool MostrarComprobantesAnuladosEnLibroDiario { get; set; }
    
    // Impresión
    public int OpcionImpresionDetalleMovimiento { get; set; }
    public bool ImprimirResumidoCentralizacion { get; set; }
    public bool IncluirTipoComprobanteEnTitulo { get; set; }
    
    // Fecha centralización
    public int OpcionFechaCentralizacion { get; set; }
    public int? DiaEspecificoCentralizacion { get; set; }
}

// Response DTO
public class ConfiguracionComprobantesDto
{
    public int EmpresaId { get; set; }
    public int Ano { get; set; }
    
    // Valores actuales
    public int TipoCorrelativo { get; set; }
    public int PeriodoCorrelativo { get; set; }
    public bool ComprobanteAprobadoAutomaticamente { get; set; }
    public bool PermitirAbrirMesesParalelo { get; set; }
    public bool MostrarComprobantesAnuladosEnLibroDiario { get; set; }
    public int OpcionImpresionDetalleMovimiento { get; set; }
    public bool ImprimirResumidoCentralizacion { get; set; }
    public bool IncluirTipoComprobanteEnTitulo { get; set; }
    public int OpcionFechaCentralizacion { get; set; }
    public int? DiaEspecificoCentralizacion { get; set; }
    
    // Estado
    public bool PermiteModificarCorrelativo { get; set; }
    public bool FuncionalidadComprobantesResumidosDisponible { get; set; }
}

// Response para actualización masiva
public class ActualizarResumidoCentralizacionResultDto
{
    public int ComprobantesActualizados { get; set; }
    public bool Exito { get; set; }
    public string? Mensaje { get; set; }
}
```

### 11.7 Endpoints API Sugeridos

```csharp
GET    /api/ConfiguracionComprobantes?empresaId={id}&ano={ano}
POST   /api/ConfiguracionComprobantes
POST   /api/ConfiguracionComprobantes/aplicar-resumido-centralizacion
```

---

## 12. CASOS DE USO

### 12.1 Configuración Inicial (Primera Vez)

**Precondición:** No existen parámetros en ParamEmpresa para la empresa/año

**Flujo:**
1. Usuario abre formulario
2. Sistema muestra valores predeterminados:
   - Tipo correlativo: Único
   - Período: Anual
   - Estado: Pendiente
   - Fecha centralización: Predefinida
   - Opción impresión detalle: Descripción
3. Usuario selecciona opciones deseadas
4. Usuario hace clic en "Aceptar"
5. Sistema valida
6. Sistema inserta registros en ParamEmpresa
7. Sistema actualiza variables globales
8. Sistema cierra formulario

### 12.2 Modificación de Configuración Existente

**Precondición:** Ya existen parámetros configurados

**Flujo:**
1. Usuario abre formulario
2. Sistema carga valores desde variables globales
3. Sistema verifica si hay comprobantes:
   - Si hay comprobantes: Deshabilita frame de correlativos
   - Si no hay: Permite modificar
4. Usuario cambia opciones
5. Usuario hace clic en "Aceptar"
6. Sistema valida:
   - Si intenta cambiar correlativo con comprobantes: Muestra error y bloquea
   - Si día > 30: Muestra error y bloquea
7. Sistema actualiza registros en ParamEmpresa (UPDATE)
8. Sistema actualiza variables globales
9. Sistema cierra formulario

### 12.3 Aplicar Imprimir Resumido a Existentes

**Precondición:** Existen comprobantes de centralización

**Flujo:**
1. Usuario activa checkbox "Imprimir Resumido Centralización"
2. Usuario hace clic en "Aplicar a los comprobantes ya existentes"
3. Sistema muestra cursor de espera
4. Sistema ejecuta UPDATE masivo:
   ```sql
   UPDATE Comprobante 
   SET ImpResumido = 1
   FROM Comprobante 
   INNER JOIN MovComprobante ON Comprobante.IdComp = MovComprobante.IdComp
   WHERE MovComprobante.DeCentraliz <> 0
     AND Comprobante.IdEmpresa = @IdEmpresa 
     AND Comprobante.Ano = @Ano
   ```
5. Sistema registra auditoría (SeguimientoComprobantes)
6. Sistema muestra mensaje: "Todos los comprobantes de centralización han quedado con la opción 'Imprimir Resumido' seleccionada."
7. Sistema restaura cursor normal

### 12.4 Usuario Sin Privilegios

**Precondición:** Usuario no tiene privilegio PRV_CFG_EMP

**Flujo:**
1. Usuario abre formulario
2. Sistema verifica privilegios en Form_Load → SetupPriv
3. Sistema deshabilita todo el formulario (`EnableForm(Me, False)`)
4. Usuario puede ver configuración pero no modificar
5. Botones "Aceptar" y botón de aplicar resumido deshabilitados
6. Usuario debe cerrar con "Cancelar" o [X]

### 12.5 Empresa Cerrada

**Precondición:** gEmpresa.FCierre <> 0

**Flujo:**
1. Usuario abre formulario
2. Sistema verifica en Form_Load: `EnableForm(Me, gEmpresa.FCierre = 0)`
3. Si FCierre <> 0: Deshabilita formulario completo
4. Usuario puede ver pero no modificar
5. Usuario cierra formulario

---

## 13. ESCENARIOS DE PRUEBA

### 13.1 Pruebas Funcionales

| # | Escenario | Entrada | Resultado Esperado |
|---|-----------|---------|-------------------|
| 1 | Configuración inicial sin comprobantes | Seleccionar opciones y guardar | INSERT en ParamEmpresa, variables globales actualizadas |
| 2 | Modificar opciones sin cambiar correlativos | Cambiar checkboxes, guardar | UPDATE en ParamEmpresa |
| 3 | Intentar cambiar correlativo con comprobantes | Cambiar radio buttons de correlativo | Error: "No es posible cambiar..." |
| 4 | Día centralización > 30 | Ingresar 31 en Tx_DayDtCompCent | Error: "Día del mes... inválido" |
| 5 | Día centralización válido (1-30) | Ingresar 15 | Guardado exitoso con DYCOMPCENT = 15 |
| 6 | Aplicar resumido a centralizaciones existentes | Click en Bt_MarcarRes | UPDATE masivo, mensaje confirmación |
| 7 | Usuario sin privilegio PRV_CFG_EMP | Abrir formulario | Todo deshabilitado, solo lectura |
| 8 | Empresa cerrada (FCierre <> 0) | Abrir formulario | Todo deshabilitado |
| 9 | Funcionalidad ComprobanteResumido = False | Abrir formulario | Frame Impresión Resumida oculto |
| 10 | Cambiar opción impresión detalle | Seleccionar "Entidad" | PRTMOVDET = 2 guardado |

### 13.2 Pruebas de Validación

| Campo | Validación | Input Inválido | Comportamiento |
|-------|-----------|----------------|----------------|
| Tx_DayDtCompCent | <= 30 | 31, 32, 100 | Error, bloquea guardado |
| Tx_DayDtCompCent | Solo números | "abc", "1a" | KeyPress bloquea caracteres no numéricos |
| Tx_DayDtCompCent | MaxLength 2 | "123" | Solo acepta 2 caracteres |

### 13.3 Pruebas de Integración

| # | Escenario | Dependencias | Verificación |
|---|-----------|--------------|--------------|
| 1 | Guardado en BD | ParamEmpresa tabla | SELECT verifica valores guardados |
| 2 | Actualización variables globales | gTipoCorrComp, etc. | Variables reflejan cambios |
| 3 | UPDATE masivo resumido | Comprobante + MovComprobante | ImpResumido = 1 en registros correctos |
| 4 | Auditoría de cambios | SeguimientoComprobantes | Registro de auditoría creado |

---

## 14. NOTAS ADICIONALES

### 14.1 Comportamiento No Implementado

- **Op_PerCorr(3) - TCC_CONTINUO:** Radio button oculto (Visible = False)
  - Funcionalidad de correlativo continuo existe en constantes pero no se expone en UI
  
### 14.2 Inconsistencias VB6

- **Tooltips idénticos:** Los 3 checkboxes de "Opciones" tienen el mismo tooltip (probablemente error de copiar/pegar)
- **Label5(1):** Label vacío usado solo para espaciado (mal uso de controles)
- **Código comentado:** Lógica de habilitar/deshabilitar meses paralelos estaba comentada

### 14.3 Mejoras Sugeridas para .NET

1. **Tooltips descriptivos:** Mejorar textos de ayuda para cada opción
2. **Validación en tiempo real:** Indicar errores antes de hacer clic en "Aceptar"
3. **Confirmación de cambios:** Pedir confirmación si cambios afectan comprobantes existentes
4. **Historial de cambios:** Mostrar quién y cuándo cambió configuración
5. **Valores por defecto inteligentes:** Sugerir configuración según tipo de empresa
6. **Ayuda contextual:** Links a documentación de cada opción
7. **Preview de impacto:** Mostrar cuántos comprobantes se verían afectados por cambios

### 14.4 Consideraciones de Performance

- **UPDATE masivo (Bt_MarcarRes):** Puede afectar muchos registros
  - Considerar paginación o procesamiento asíncrono en .NET
  - Mostrar barra de progreso si toma tiempo
  
- **Validación de comprobantes existentes:** Query puede ser costoso
  - Agregar índice en (IdEmpresa, Ano, Tipo)
  - Usar COUNT(*) en lugar de SELECT IdComp si solo necesitamos saber si existen

### 14.5 Seguridad

- **Privilegio requerido:** PRV_CFG_EMP
- **Auditoría:** Solo en UPDATE masivo de ImpResumido
  - Considerar auditar TODOS los cambios de configuración en .NET
  
- **Validación servidor:** Todas las validaciones deben repetirse en backend
- **SQL Injection:** VB6 usa concatenación de strings
  - .NET debe usar parámetros en todas las consultas

---

## 15. RESUMEN EJECUTIVO

### Complejidad: **MEDIA-ALTA**

**Motivos:**
- 10 parámetros diferentes a gestionar
- Lógica condicional de habilitación
- Validaciones cruzadas con datos existentes
- UPDATE masivo con auditoría
- Múltiples interacciones entre controles

### Líneas de Código VB6: ~450 líneas

### Componentes .NET Requeridos:
1. **DTOs:** 3 (Configuración, Actualizar, ResultadoResumido)
2. **Interface de Servicio:** IConfiguracionComprobantesService
3. **Servicio:** ConfiguracionComprobantesService
4. **Controlador API:** ConfiguracionComprobantesApiController
5. **Controlador MVC:** ConfiguracionComprobantesController
6. **Vista Razor:** Index.cshtml
7. **JavaScript:** lógica de interacción cliente

### Estimación de Esfuerzo: **6-8 horas**

**Desglose:**
- Análisis: 1 hora ✅ (completado)
- DTOs y constantes: 0.5 hora
- Servicio con lógica de negocio: 2 horas
- Controladores API/MVC: 1 hora
- Vista con Tailwind CSS: 2 horas
- Validaciones y pruebas: 1.5 horas

---

## 16. CHECKLIST DE IMPLEMENTACIÓN

- [ ] Crear constantes de configuración
- [ ] Crear DTOs (ConfiguracionComprobantesDto, ActualizarConfiguracionComprobantesDto, ActualizarResumidoCentralizacionResultDto)
- [ ] Crear IConfiguracionComprobantesService con 3 métodos principales
- [ ] Implementar ConfiguracionComprobantesService
  - [ ] GetConfiguracionAsync
  - [ ] ActualizarConfiguracionAsync
  - [ ] AplicarResumidoCentralizacionAsync
- [ ] Crear ConfiguracionComprobantesApiController con 3 endpoints
- [ ] Crear ConfiguracionComprobantesController (MVC)
- [ ] Crear vista Index.cshtml con Tailwind CSS
  - [ ] Frame correlativos (tipo y período)
  - [ ] Frame opciones (3 checkboxes)
  - [ ] Frame impresión (título + detalle movimiento)
  - [ ] Frame impresión resumida (checkbox + botón aplicar)
  - [ ] Frame fecha centralización (3 opciones + textbox día)
  - [ ] Botones Aceptar/Cancelar
- [ ] Implementar JavaScript para interacciones
  - [ ] Habilitar/deshabilitar controles según reglas
  - [ ] Validación cliente (día <= 30)
  - [ ] Confirmaciones con SweetAlert2
- [ ] Agregar validaciones servidor
  - [ ] Data Annotations en DTOs
  - [ ] Validación comprobantes existentes
  - [ ] Validación día del mes
- [ ] Implementar auditoría de cambios
- [ ] Agregar logging con ILogger
- [ ] Registrar servicio en ServiceCollectionExtensions
- [ ] Actualizar _Layout.cshtml con link de navegación
- [ ] Actualizar features.md
- [ ] Probar todos los casos de uso
- [ ] Compilar y verificar cero errores

---

**FIN DEL ANÁLISIS**
