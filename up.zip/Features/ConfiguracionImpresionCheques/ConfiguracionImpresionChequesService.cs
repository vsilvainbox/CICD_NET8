using Microsoft.EntityFrameworkCore;
using App.Data;

namespace App.Features.ConfiguracionImpresionCheques;

/// <summary>
/// Implementación del servicio para gestionar configuración de impresión de cheques
/// </summary>
public class ConfiguracionImpresionChequesService(
    LpContabContext context,
    ILogger<ConfiguracionImpresionChequesService> logger) : IConfiguracionImpresionChequesService
{
    private const string TipoParam = "Cheques";

    /// <inheritdoc />
    public async Task<ConfiguracionChequesDto> GetAsync(int tipoPapel)
    {
        {
            logger.LogInformation("Obteniendo configuración de cheques para tipo papel {TipoPapel}", tipoPapel);

            // Obtener todos los parámetros de cheques
            var parametros = await context.Param
                .AsNoTracking()
                .Where(p => p.Tipo == TipoParam)
                .ToListAsync();

            var dto = new ConfiguracionChequesDto
            {
                TipoPapel = tipoPapel
            };

            // Determinar códigos según tipo de papel
            int baseCode = tipoPapel == 1 ? 10 : 110; // 10 para Carta, 110 para Continuo

            // Cargar valores desde parámetros
            dto.BordeSuperior = GetIntParam(parametros, baseCode + 0);
            dto.BordeIzquierdo = GetIntParam(parametros, baseCode + 1);
            dto.BajarValorDigitos = GetIntParam(parametros, baseCode + 2);
            dto.MoverValorDigitos = GetIntParam(parametros, baseCode + 3);
            dto.BajarFecha = GetIntParam(parametros, baseCode + 4);
            dto.MoverFecha = GetIntParam(parametros, baseCode + 5);
            dto.Omitir2DigitosAno = GetBoolParam(parametros, baseCode + 6);
            dto.MoverAno = GetIntParam(parametros, baseCode + 7);
            dto.BajarOrdenDe = GetIntParam(parametros, baseCode + 8);
            dto.MoverOrdenDe = GetIntParam(parametros, baseCode + 9);
            dto.BorrarALaOrden = GetBoolParam(parametros, baseCode + 10);
            dto.BorrarAlPortador = GetBoolParam(parametros, baseCode + 11);

            logger.LogInformation("Configuración de cheques obtenida: TipoPapel={TipoPapel}, BordeSup={BordeSup}, BordeIzq={BordeIzq}",
                dto.TipoPapel, dto.BordeSuperior, dto.BordeIzquierdo);

            return dto;
        }
    }

    /// <inheritdoc />
    public async Task<bool> SaveAsync(ConfiguracionChequesUpdateDto dto)
    {
        {
            logger.LogInformation("Guardando configuración de cheques para tipo papel {TipoPapel}", dto.TipoPapel);

            // Guardar tipo de papel actual
            await SaveParamAsync(ConfiguracionChequesCodigosParam.TipoPapel, dto.TipoPapel.ToString());

            // Determinar códigos según tipo de papel
            int baseCode = dto.TipoPapel == 1 ? 10 : 110;

            // Guardar todos los parámetros
            await SaveParamAsync(baseCode + 0, dto.BordeSuperior?.ToString() ?? "0");
            await SaveParamAsync(baseCode + 1, dto.BordeIzquierdo?.ToString() ?? "0");
            await SaveParamAsync(baseCode + 2, dto.BajarValorDigitos?.ToString() ?? "0");
            await SaveParamAsync(baseCode + 3, dto.MoverValorDigitos?.ToString() ?? "0");
            await SaveParamAsync(baseCode + 4, dto.BajarFecha?.ToString() ?? "0");
            await SaveParamAsync(baseCode + 5, dto.MoverFecha?.ToString() ?? "0");
            await SaveParamAsync(baseCode + 6, dto.Omitir2DigitosAno ? "1" : "0");
            await SaveParamAsync(baseCode + 7, dto.MoverAno?.ToString() ?? "0");
            await SaveParamAsync(baseCode + 8, dto.BajarOrdenDe?.ToString() ?? "0");
            await SaveParamAsync(baseCode + 9, dto.MoverOrdenDe?.ToString() ?? "0");
            await SaveParamAsync(baseCode + 10, dto.BorrarALaOrden ? "1" : "0");
            await SaveParamAsync(baseCode + 11, dto.BorrarAlPortador ? "1" : "0");

            await context.SaveChangesAsync();
            logger.LogInformation("Configuración de cheques guardada exitosamente");

            return true;
        }
    }

    /// <inheritdoc />
    public async Task<int> GetTipoPapelActualAsync()
    {
        {
            logger.LogInformation("Obteniendo tipo de papel actual");

            var param = await context.Param
                .AsNoTracking()
                .FirstOrDefaultAsync(p => p.Tipo == TipoParam && p.Codigo == ConfiguracionChequesCodigosParam.TipoPapel);

            var tipoPapel = param?.Valor != null ? int.Parse(param.Valor) : 1; // Default: Hoja Carta

            logger.LogInformation("Tipo de papel actual: {TipoPapel}", tipoPapel);

            return tipoPapel;
        }
    }

    /// <inheritdoc />
    public async Task<bool> SetTipoPapelActualAsync(int tipoPapel)
    {
        {
            logger.LogInformation("Estableciendo tipo de papel actual: {TipoPapel}", tipoPapel);

            await SaveParamAsync(ConfiguracionChequesCodigosParam.TipoPapel, tipoPapel.ToString());
            await context.SaveChangesAsync();

            logger.LogInformation("Tipo de papel actualizado exitosamente");

            return true;
        }
    }

    #region Helper Methods

    /// <summary>
    /// Obtiene un parámetro entero de la lista
    /// </summary>
    private int? GetIntParam(List<Param> parametros, int codigo)
    {
        var param = parametros.FirstOrDefault(p => p.Codigo == codigo);
        if (param?.Valor == null) return null;

        if (int.TryParse(param.Valor, out var valor))
            return valor;

        return null;
    }

    /// <summary>
    /// Obtiene un parámetro booleano de la lista
    /// </summary>
    private bool GetBoolParam(List<Param> parametros, int codigo)
    {
        var param = parametros.FirstOrDefault(p => p.Codigo == codigo);
        return param?.Valor == "1";
    }

    /// <summary>
    /// Guarda o actualiza un parámetro
    /// </summary>
    private async Task SaveParamAsync(int codigo, string valor)
    {
        var param = await context.Param
            .FirstOrDefaultAsync(p => p.Tipo == TipoParam && p.Codigo == codigo);

        if (param != null)
        {
            param.Valor = valor;
        }
        else
        {
            context.Param.Add(new Param
            {
                Tipo = TipoParam,
                Codigo = codigo,
                Valor = valor
            });
        }
    }

    #endregion
}
