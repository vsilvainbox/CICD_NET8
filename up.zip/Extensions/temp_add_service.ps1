$filePath = "ServiceCollectionExtensions.cs"
$content = Get-Content $filePath

$newLines = @(
    "",
    "        // REGISTRAR: Servicios concretos de EstadoSituacionFinancieraIfrs",
    "        // Compartido entre EstadoSituacionFinancieraIfrs y EstadoResultadoIfrs",
    "        services.AddScoped<App.Features.EstadoSituacionFinancieraIfrs.IEstadoSituacionFinancieraIfrsService, App.Features.EstadoSituacionFinancieraIfrs.EstadoSituacionFinancieraIfrsService>();"
)

$lineIndex = -1
for($i = 0; $i -lt $content.Count; $i++) {
    if($content[$i] -match 'return services;' -and $i -gt 170) {
        $lineIndex = $i
        break
    }
}

if($lineIndex -gt 0) {
    $newContent = $content[0..($lineIndex-1)] + $newLines + $content[$lineIndex..($content.Count-1)]
    $newContent | Set-Content $filePath -Encoding UTF8
    Write-Host "Service registered successfully at line $lineIndex"
} else {
    Write-Host "Could not find insertion point"
}
