using System.Text.Json;

namespace App.Extensions;

/// <summary>
/// Extension methods para HttpClient que garantizan manejo correcto de errores
/// y construcción robusta de URLs con PathBase
/// </summary>
public static class HttpClientExtensions
{
    /// <summary>
    /// GET con deserialización automática y manejo de errores
    /// PathBaseHandler se encarga de agregar el PathBase automáticamente
    /// </summary>
    public static async Task<T> GetFromApiAsync<T>(this HttpClient client, string requestUri)
    {
        // Crear HttpRequestMessage manualmente para que pase por el handler pipeline
        // Esto permite que PathBaseHandler convierta URIs relativas en absolutas
        var request = new HttpRequestMessage(HttpMethod.Get, requestUri);
        var response = await client.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException(
                $"API returned {response.StatusCode}: {errorContent}",
                null,
                response.StatusCode
            );
        }

        var content = await response.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<T>(content, new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        }) ?? throw new InvalidOperationException("Deserialización devolvió null");
    }

    /// <summary>
    /// POST con deserialización automática y manejo de errores
    /// </summary>
    public static async Task<TResponse> PostToApiAsync<TRequest, TResponse>(
        this HttpClient client,
        string requestUri,
        TRequest data)
    {
        var json = JsonSerializer.Serialize(data);
        var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

        var request = new HttpRequestMessage(HttpMethod.Post, requestUri) { Content = content };
        var response = await client.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException(
                $"API returned {response.StatusCode}: {errorContent}",
                null,
                response.StatusCode
            );
        }

        var responseContent = await response.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<TResponse>(responseContent, new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        }) ?? throw new InvalidOperationException("Deserialización devolvió null");
    }

    /// <summary>
    /// POST sin respuesta (para endpoints que devuelven 204 No Content)
    /// </summary>
    public static async Task PostToApiAsync<TRequest>(
        this HttpClient client,
        string requestUri,
        TRequest data)
    {
        var json = JsonSerializer.Serialize(data);
        var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

        var request = new HttpRequestMessage(HttpMethod.Post, requestUri) { Content = content };
        var response = await client.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException(
                $"API returned {response.StatusCode}: {errorContent}",
                null,
                response.StatusCode
            );
        }
    }

    /// <summary>
    /// PUT con deserialización automática y manejo de errores
    /// </summary>
    public static async Task<TResponse> PutToApiAsync<TRequest, TResponse>(
        this HttpClient client,
        string requestUri,
        TRequest data)
    {
        var json = JsonSerializer.Serialize(data);
        var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

        var request = new HttpRequestMessage(HttpMethod.Put, requestUri) { Content = content };
        var response = await client.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException(
                $"API returned {response.StatusCode}: {errorContent}",
                null,
                response.StatusCode
            );
        }

        var responseContent = await response.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<TResponse>(responseContent, new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        }) ?? throw new InvalidOperationException("Deserialización devolvió null");
    }

    /// <summary>
    /// DELETE con manejo de errores
    /// </summary>
    public static async Task DeleteFromApiAsync(this HttpClient client, string requestUri)
    {
        var request = new HttpRequestMessage(HttpMethod.Delete, requestUri);
        var response = await client.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException(
                $"API returned {response.StatusCode}: {errorContent}",
                null,
                response.StatusCode
            );
        }
    }

    /// <summary>
    /// Método proxy - reenvía la respuesta tal cual (para JavaScript)
    /// Útil cuando el frontend necesita manejar el status code
    /// </summary>
    public static async Task<(int StatusCode, string Content)> ProxyRequestAsync(
        this HttpClient client,
        string requestUri,
        object? data = null,
        HttpMethod? method = null)
    {
        method ??= HttpMethod.Get;

        var request = new HttpRequestMessage(method, requestUri);

        if (data != null && (method == HttpMethod.Post || method == HttpMethod.Put))
        {
            var json = JsonSerializer.Serialize(data);
            request.Content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
        }

        var response = await client.SendAsync(request);
        var content = await response.Content.ReadAsStringAsync();

        return ((int)response.StatusCode, content);
    }

    /// <summary>
    /// Sobrecarga específica para JsonElement - reenvía la respuesta tal cual
    /// </summary>
    public static async Task<(int StatusCode, string Content)> ProxyRequestAsync(
        this HttpClient client,
        string requestUri,
        System.Text.Json.JsonElement data,
        HttpMethod? method = null)
    {
        method ??= HttpMethod.Get;

        var request = new HttpRequestMessage(method, requestUri);

        if (method == HttpMethod.Post || method == HttpMethod.Put)
        {
            // JsonElement ya está en formato JSON, usarlo directamente
            var json = data.GetRawText();
            request.Content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
        }

        var response = await client.SendAsync(request);
        var content = await response.Content.ReadAsStringAsync();

        return ((int)response.StatusCode, content);
    }

    /// <summary>
    /// Descarga de archivos (Excel, PDF, etc.)
    /// </summary>
    public static async Task<(byte[] FileBytes, string ContentType)> DownloadFileAsync(
        this HttpClient client,
        string requestUri,
        HttpMethod method,
        object? data = null)
    {
        var request = new HttpRequestMessage(method, requestUri);

        if (data != null && (method == HttpMethod.Post || method == HttpMethod.Put))
        {
            var json = JsonSerializer.Serialize(data);
            request.Content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
        }

        var response = await client.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException(
                $"API returned {response.StatusCode}: {errorContent}",
                null,
                response.StatusCode
            );
        }

        var fileBytes = await response.Content.ReadAsByteArrayAsync();
        var contentType = response.Content.Headers.ContentType?.ToString()
            ?? "application/octet-stream";

        return (fileBytes, contentType);
    }
}
