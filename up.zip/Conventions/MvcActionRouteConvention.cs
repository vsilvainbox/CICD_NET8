using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApplicationModels;

namespace App.Conventions;

/// <summary>
/// Convención automática para rutas de MVC Controllers
/// Agrega automáticamente el nombre de la acción a la ruta para evitar AmbiguousMatchException
///
/// Problema: MVC Controllers con [Route("[controller]")] y múltiples acciones con el mismo
/// HTTP verb sin rutas explícitas causan ambigüedad.
///
/// Solución: Esta convención detecta acciones sin ruta explícita y les agrega automáticamente
/// el nombre de la acción, convirtiendo:
///   [HttpGet] public IActionResult GetData() → /Controller/GetData
///   [HttpGet] public IActionResult Index() → /Controller/Index (y /Controller/)
/// </summary>
public class MvcActionRouteConvention : IActionModelConvention
{
    public void Apply(ActionModel action)
    {
        var controller = action.Controller;

        // ✅ Solo aplicar a MVC Controllers (NO API Controllers)
        // API Controllers tienen [ApiController] attribute
        if (controller.Attributes.Any(a => a is ApiControllerAttribute))
            return;

        // ✅ Solo aplicar a controladores que usan attribute routing
        // (tienen [Route] a nivel de controlador)
        var hasControllerRoute = controller.Selectors.Any(s => s.AttributeRouteModel != null);
        if (!hasControllerRoute)
            return; // Usa conventional routing, no necesita esta convención

        // ✅ Verificar si la acción ya tiene una ruta explícita
        var hasExplicitRoute = action.Selectors.Any(s =>
            s.AttributeRouteModel != null &&
            !string.IsNullOrEmpty(s.AttributeRouteModel.Template));

        if (hasExplicitRoute)
            return; // Ya tiene ruta explícita, no tocar

        // ✅ Agregar ruta con el nombre de la acción para cada selector
        foreach (var selector in action.Selectors)
        {
            // Determinar el template de ruta basado en el nombre de la acción
            string routeTemplate;

            if (action.ActionName == "Index")
            {
                // Index debe responder tanto a /Controller como a /Controller/Index
                // Esto se maneja creando dos selectores
                routeTemplate = "Index";
            }
            else
            {
                // Otras acciones: usar el nombre de la acción
                routeTemplate = action.ActionName;
            }

            // Si el selector ya tiene AttributeRouteModel (heredado del controller), combinarlo
            if (selector.AttributeRouteModel != null)
            {
                // Combinar la ruta del controller con la ruta de la acción
                selector.AttributeRouteModel = AttributeRouteModel.CombineAttributeRouteModel(
                    controller.Selectors[0].AttributeRouteModel,
                    new AttributeRouteModel { Template = routeTemplate });
            }
            else
            {
                // Crear nuevo AttributeRouteModel con template combinado
                selector.AttributeRouteModel = new AttributeRouteModel
                {
                    Template = routeTemplate
                };
            }
        }

        // ✅ Para Index, agregar selector adicional que responda a ruta vacía ("")
        if (action.ActionName == "Index")
        {
            // Verificar si ya existe un selector con ruta vacía
            var hasEmptyRouteSelector = action.Selectors.Any(s =>
                s.AttributeRouteModel?.Template == "" ||
                s.AttributeRouteModel?.Template == null);

            if (!hasEmptyRouteSelector)
            {
                // Clonar el primer selector y cambiar la ruta a vacía
                var emptyRouteSelector = new SelectorModel(action.Selectors[0])
                {
                    AttributeRouteModel = AttributeRouteModel.CombineAttributeRouteModel(
                        controller.Selectors[0].AttributeRouteModel,
                        new AttributeRouteModel { Template = "" })
                };
                action.Selectors.Add(emptyRouteSelector);
            }
        }

        //Console.WriteLine($"🔧 MVC Action Route: {controller.ControllerName}.{action.ActionName} → {action.Selectors[0].AttributeRouteModel?.Template}");
    }
}
