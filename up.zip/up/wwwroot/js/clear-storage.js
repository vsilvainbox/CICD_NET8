// Script temporal para limpiar localStorage
// Ejecutar en la consola del navegador: localStorage.clear(); location.reload();

console.log('🧹 Limpiando localStorage...');
console.log('Valores actuales:', { ...localStorage });

// Limpiar localStorage
localStorage.clear();

console.log('✅ localStorage limpiado');
console.log('🔄 Recargando página...');

// Recargar la página
location.reload(true);

