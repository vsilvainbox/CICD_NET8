// DetalleBaseImponible14D - Módulo JavaScript
var DetalleBaseImponible14D = (function() {
    'use strict';

    // Variables privadas
    var elementos = {
        formFiltros: null,
        btnGenerar: null,
        btnExportarExcel: null,
        btnExportarPdf: null,
        resultadosContainer: null,
        loadingContainer: null,
        tablaDetalles: null,
        detallesBody: null,
        sinDatos: null,
        totalItems: null,
        resumenContainer: null
    };

    var datos = {
        detalleActual: null,
        filtrosActuales: {}
    };

    // Función de inicialización
    function init() {
        initElementos();
        initEventos();
        validarFormulario();
    }

    // Inicializar referencias a elementos DOM
    function initElementos() {
        elementos.formFiltros = document.getElementById('formFiltros');
        elementos.btnGenerar = document.getElementById('btnGenerar');
        elementos.btnExportarExcel = document.getElementById('btnExportarExcel');
        elementos.btnExportarPdf = document.getElementById('btnExportarPdf');
        elementos.resultadosContainer = document.getElementById('resultadosContainer');
        elementos.loadingContainer = document.getElementById('loadingContainer');
        elementos.tablaDetalles = document.getElementById('tablaDetalles');
        elementos.detallesBody = document.getElementById('detallesBody');
        elementos.sinDatos = document.getElementById('sinDatos');
        elementos.totalItems = document.getElementById('totalItems');
        elementos.resumenContainer = document.getElementById('resumenContainer');
    }

    // Inicializar eventos
    function initEventos() {
        // Botón generar
        if (elementos.btnGenerar) {
            elementos.btnGenerar.addEventListener('click', generarDetalle);
        }

        // Botones de exportación
        if (elementos.btnExportarExcel) {
            elementos.btnExportarExcel.addEventListener('click', exportarExcel);
        }

        if (elementos.btnExportarPdf) {
            elementos.btnExportarPdf.addEventListener('click', exportarPdf);
        }

        // Validación de formulario en tiempo real
        if (elementos.formFiltros) {
            var inputs = elementos.formFiltros.querySelectorAll('select, input');
            inputs.forEach(function(input) {
                input.addEventListener('change', validarFormulario);
            });
        }
    }

    // Validar formulario y habilitar/deshabilitar botones
    function validarFormulario() {
        var idEmpresa = document.getElementById('idEmpresa')?.value;
        var ano = document.getElementById('ano')?.value;
        var fechaInicio = document.getElementById('fechaInicio')?.value;
        var fechaFin = document.getElementById('fechaFin')?.value;

        var esValido = idEmpresa && ano && fechaInicio && fechaFin;

        if (elementos.btnGenerar) {
            elementos.btnGenerar.disabled = !esValido;
            elementos.btnGenerar.classList.toggle('opacity-50', !esValido);
            elementos.btnGenerar.classList.toggle('cursor-not-allowed', !esValido);
        }
    }

    // Generar detalle de base imponible 14D
    function generarDetalle() {
        if (!validarDatos()) {
            return;
        }

        var filtros = obtenerFiltros();
        datos.filtrosActuales = filtros;

        mostrarLoading(true);
        ocultarResultados();

        // Realizar petición AJAX
        fetch('/api/DetalleBaseImponible14D/GenerarDetalle', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify(filtros)
        })
        .then(function(response) {
            if (!response.ok) {
                throw new Error('Error en la respuesta del servidor: ' + response.status);
            }
            return response.json();
        })
        .then(function(data) {
            mostrarLoading(false);
            
            if (data.mensajeError) {
                mostrarError(data.mensajeError);
                return;
            }

            datos.detalleActual = data;
            mostrarResultados(data);
            habilitarExportacion(true);
        })
        .catch(function(error) {
            mostrarLoading(false);
            console.error('Error al generar detalle:', error);
            mostrarError('Error al generar el detalle de base imponible 14D. Por favor, intente nuevamente.');
        });
    }

    // Obtener filtros del formulario
    function obtenerFiltros() {
        return {
            IdEmpresa: parseInt(document.getElementById('idEmpresa')?.value) || 0,
            Ano: parseInt(document.getElementById('ano')?.value) || 0,
            FechaInicio: document.getElementById('fechaInicio')?.value || '',
            FechaFin: document.getElementById('fechaFin')?.value || '',
            TipoReporte: document.getElementById('tipoReporte')?.value || '',
            CuentaDesde: document.getElementById('cuentaDesde')?.value || '',
            CuentaHasta: document.getElementById('cuentaHasta')?.value || '',
            IncluirAjustes: document.getElementById('incluirAjustes')?.checked || false,
            MostrarCuentasCero: document.getElementById('mostrarCuentasCero')?.checked || false
        };
    }

    // Validar datos antes de enviar
    function validarDatos() {
        var idEmpresa = document.getElementById('idEmpresa')?.value;
        var ano = document.getElementById('ano')?.value;
        var fechaInicio = document.getElementById('fechaInicio')?.value;
        var fechaFin = document.getElementById('fechaFin')?.value;

        if (!idEmpresa) {
            mostrarError('Debe seleccionar una empresa.');
            return false;
        }

        if (!ano) {
            mostrarError('Debe seleccionar un año/ejercicio.');
            return false;
        }

        if (!fechaInicio || !fechaFin) {
            mostrarError('Debe especificar el rango de fechas.');
            return false;
        }

        if (new Date(fechaInicio) > new Date(fechaFin)) {
            mostrarError('La fecha de inicio no puede ser mayor a la fecha fin.');
            return false;
        }

        return true;
    }

    // Mostrar resultados
    function mostrarResultados(data) {
        if (!data || !data.detalleItems) {
            mostrarSinDatos();
            return;
        }

        // Actualizar resumen
        actualizarResumen(data.resumen);

        // Actualizar total de items
        if (elementos.totalItems) {
            elementos.totalItems.textContent = data.detalleItems.length;
        }

        // Llenar tabla
        llenarTablaDetalles(data.detalleItems);

        // Mostrar contenedor de resultados
        if (elementos.resultadosContainer) {
            elementos.resultadosContainer.style.display = 'block';
        }

        if (elementos.sinDatos) {
            elementos.sinDatos.style.display = 'none';
        }
    }

    // Actualizar resumen financiero
    function actualizarResumen(resumen) {
        if (!resumen) return;

        document.getElementById('totalBaseImponible').textContent = formatearMoneda(resumen.totalBaseImponible || 0);
        document.getElementById('totalAjustes').textContent = formatearMoneda(resumen.totalAjustes || 0);
        document.getElementById('totalFinal').textContent = formatearMoneda(resumen.totalFinal || 0);
        document.getElementById('totalDebe').textContent = formatearMoneda(resumen.totalMovimientosDebe || 0);
        document.getElementById('totalHaber').textContent = formatearMoneda(resumen.totalMovimientosHaber || 0);
    }

    // Llenar tabla de detalles
    function llenarTablaDetalles(items) {
        if (!elementos.detallesBody || !items) return;

        elementos.detallesBody.innerHTML = '';

        items.forEach(function(item) {
            var fila = document.createElement('tr');
            fila.className = 'hover:bg-gray-50';
            
            fila.innerHTML = `
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escapeHtml(item.tipoMovimiento || '')}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escapeHtml(item.codigoCuenta || '')}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escapeHtml(item.nombreCuenta || '')}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escapeHtml(item.descripcion || '')}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right">${formatearMoneda(item.montoDebe || 0)}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right">${formatearMoneda(item.montoHaber || 0)}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right font-semibold">${formatearMoneda(item.montoImpacto14D || 0)}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${formatearFecha(item.fechaMovimiento)}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${escapeHtml(item.numeroDocumento || '')}</td>
            `;
            
            elementos.detallesBody.appendChild(fila);
        });
    }

    // Mostrar mensaje sin datos
    function mostrarSinDatos() {
        if (elementos.resultadosContainer) {
            elementos.resultadosContainer.style.display = 'block';
        }

        if (elementos.sinDatos) {
            elementos.sinDatos.style.display = 'block';
        }

        if (elementos.tablaDetalles) {
            elementos.tablaDetalles.style.display = 'none';
        }

        if (elementos.totalItems) {
            elementos.totalItems.textContent = '0';
        }
    }

    // Ocultar resultados
    function ocultarResultados() {
        if (elementos.resultadosContainer) {
            elementos.resultadosContainer.style.display = 'none';
        }
        habilitarExportacion(false);
    }

    // Mostrar/ocultar loading
    function mostrarLoading(mostrar) {
        if (elementos.loadingContainer) {
            elementos.loadingContainer.style.display = mostrar ? 'block' : 'none';
        }
    }

    // Habilitar/deshabilitar botones de exportación
    function habilitarExportacion(habilitar) {
        var botones = [elementos.btnExportarExcel, elementos.btnExportarPdf];
        
        botones.forEach(function(boton) {
            if (boton) {
                boton.disabled = !habilitar;
                boton.classList.toggle('opacity-50', !habilitar);
                boton.classList.toggle('cursor-not-allowed', !habilitar);
            }
        });
    }

    // Exportar a Excel
    function exportarExcel() {
        if (!datos.detalleActual) {
            mostrarError('No hay datos para exportar.');
            return;
        }

        var filtros = datos.filtrosActuales;
        var params = new URLSearchParams();
        
        Object.keys(filtros).forEach(function(key) {
            if (filtros[key] !== null && filtros[key] !== undefined && filtros[key] !== '') {
                params.append(key, filtros[key]);
            }
        });

        window.location.href = '/api/DetalleBaseImponible14D/ExportarExcel?' + params.toString();
    }

    // Exportar a PDF
    function exportarPdf() {
        if (!datos.detalleActual) {
            mostrarError('No hay datos para exportar.');
            return;
        }

        var filtros = datos.filtrosActuales;
        var params = new URLSearchParams();
        
        Object.keys(filtros).forEach(function(key) {
            if (filtros[key] !== null && filtros[key] !== undefined && filtros[key] !== '') {
                params.append(key, filtros[key]);
            }
        });

        window.open('/api/DetalleBaseImponible14D/ExportarPdf?' + params.toString(), '_blank');
    }

    // Funciones de utilidad
    function formatearMoneda(valor) {
        if (valor === null || valor === undefined) return '$0';
        return new Intl.NumberFormat('es-CL', { 
            style: 'currency', 
            currency: 'CLP',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(valor);
    }

    function formatearFecha(fecha) {
        if (!fecha) return '';
        return new Date(fecha).toLocaleDateString('es-CL');
    }

    function escapeHtml(texto) {
        if (!texto) return '';
        var div = document.createElement('div');
        div.textContent = texto;
        return div.innerHTML;
    }

    function mostrarError(mensaje) {
        alert('Error: ' + mensaje);
    }

    // API pública
    return {
        init: init,
        generarDetalle: generarDetalle,
        exportarExcel: exportarExcel,
        exportarPdf: exportarPdf
    };
})();
