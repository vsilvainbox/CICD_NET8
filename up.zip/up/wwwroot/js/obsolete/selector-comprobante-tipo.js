/**
 * Selector de Comprobante Tipo - Componente Reutilizable
 * Permite seleccionar un comprobante tipo desde un modal
 */

class SelectorComprobanteTipo {
    constructor() {
        this.modal = null;
        this.callback = null;
        this.resultados = [];
        this.ordenActual = 'nombre';
        this.direccionOrden = 'asc';
    }

    /**
     * Abre el selector modal
     * @param {Function} callback - Función que se ejecuta cuando se selecciona un elemento
     */
    abrir(callback) {
        this.callback = callback;
        this.cargarModal();
    }

    /**
     * Carga el modal desde el servidor
     */
    async cargarModal() {
        try {
            const response = await fetch('/SelectorComprobanteTipo');
            const html = await response.text();
            
            // Crear elemento temporal para parsear el HTML
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = html;
            
            // Obtener el modal
            this.modal = tempDiv.querySelector('#selectorModal');
            
            if (this.modal) {
                // Agregar al body
                document.body.appendChild(this.modal);
                
                // Mostrar modal
                this.modal.classList.remove('hidden');
                
                // Configurar eventos
                this.configurarEventos();
                
                // Cargar resultados iniciales
                this.buscar();
            }
        } catch (error) {
            console.error('Error al cargar el selector:', error);
            alert('Error al cargar el selector de comprobante tipo');
        }
    }

    /**
     * Configura los eventos del modal
     */
    configurarEventos() {
        // Botón cerrar
        const btnCerrar = this.modal.querySelector('button[onclick="cerrarSelector()"]');
        if (btnCerrar) {
            btnCerrar.onclick = () => this.cerrar();
        }

        // Botón buscar
        const btnBuscar = this.modal.querySelector('button[onclick="buscar()"]');
        if (btnBuscar) {
            btnBuscar.onclick = () => this.buscar();
        }

        // Botón limpiar
        const btnLimpiar = this.modal.querySelector('button[onclick="limpiarFiltros()"]');
        if (btnLimpiar) {
            btnLimpiar.onclick = () => this.limpiarFiltros();
        }

        // Cerrar al hacer clic fuera del modal
        this.modal.addEventListener('click', (e) => {
            if (e.target === this.modal) {
                this.cerrar();
            }
        });

        // Buscar al presionar Enter
        const filtroNombre = this.modal.querySelector('#filtroNombre');
        const filtroGlosa = this.modal.querySelector('#filtroGlosa');
        
        if (filtroNombre) {
            filtroNombre.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') this.buscar();
            });
        }
        
        if (filtroGlosa) {
            filtroGlosa.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') this.buscar();
            });
        }
    }

    /**
     * Cierra el selector
     */
    cerrar() {
        if (this.modal) {
            this.modal.remove();
            this.modal = null;
        }
        this.callback = null;
    }

    /**
     * Busca comprobantes tipo
     */
    async buscar() {
        const request = {
            idEmpresa: 1, // Valor por defecto, debería obtenerse de la sesión
            nombre: this.modal.querySelector('#filtroNombre').value,
            glosa: this.modal.querySelector('#filtroGlosa').value,
            tipo: this.modal.querySelector('#filtroTipo').value ? parseInt(this.modal.querySelector('#filtroTipo').value) : null
        };

        // Mostrar loading
        this.mostrarLoading(true);

        try {
            const response = await fetch('/SelectorComprobanteTipo/buscar', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(request)
            });

            const data = await response.json();
            
            this.mostrarLoading(false);
            
            if (data.success) {
                this.resultados = data.data;
                this.mostrarResultados();
            } else {
                alert('Error: ' + data.message);
            }
        } catch (error) {
            this.mostrarLoading(false);
            console.error('Error:', error);
            alert('Error al realizar la búsqueda');
        }
    }

    /**
     * Muestra/oculta el indicador de carga
     */
    mostrarLoading(mostrar) {
        const loading = this.modal.querySelector('#loadingIndicator');
        const noResults = this.modal.querySelector('#noResults');
        const resultsContainer = this.modal.querySelector('#resultsContainer');

        if (mostrar) {
            loading.classList.remove('hidden');
            noResults.classList.add('hidden');
            resultsContainer.classList.add('hidden');
        } else {
            loading.classList.add('hidden');
        }
    }

    /**
     * Muestra los resultados en la tabla
     */
    mostrarResultados() {
        const tbody = this.modal.querySelector('#resultsTableBody');
        const noResults = this.modal.querySelector('#noResults');
        const resultsContainer = this.modal.querySelector('#resultsContainer');

        if (this.resultados.length === 0) {
            noResults.classList.remove('hidden');
            resultsContainer.classList.add('hidden');
            return;
        }

        noResults.classList.add('hidden');
        resultsContainer.classList.remove('hidden');

        tbody.innerHTML = this.resultados.map(item => `
            <tr class="hover:bg-gray-50 cursor-pointer" onclick="selectorComprobanteTipo.seleccionar(${item.idComp}, '${this.escapeHtml(item.nombre)}', '${this.escapeHtml(item.descripcion)}', ${item.tipo || 'null'}, '${this.escapeHtml(item.tipoDescripcion)}')">
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    ${this.escapeHtml(item.nombre)}
                </td>
                <td class="px-6 py-4 text-sm text-gray-900">
                    ${this.escapeHtml(item.descripcion)}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                        ${this.escapeHtml(item.tipoDescripcion)}
                    </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right">
                    ${item.totalDebe ? this.formatearMoneda(item.totalDebe) : '-'}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right">
                    ${item.totalHaber ? this.formatearMoneda(item.totalHaber) : '-'}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button onclick="event.stopPropagation(); selectorComprobanteTipo.seleccionar(${item.idComp}, '${this.escapeHtml(item.nombre)}', '${this.escapeHtml(item.descripcion)}', ${item.tipo || 'null'}, '${this.escapeHtml(item.tipoDescripcion)}')" 
                            class="text-primary-600 hover:text-primary-900">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                        </svg>
                    </button>
                </td>
            </tr>
        `).join('');
    }

    /**
     * Selecciona un comprobante tipo
     */
    seleccionar(idComp, nombre, descripcion, tipo, tipoDescripcion) {
        if (this.callback) {
            this.callback({
                idComp: idComp,
                nombre: nombre,
                descripcion: descripcion,
                tipo: tipo,
                tipoDescripcion: tipoDescripcion
            });
        }
        this.cerrar();
    }

    /**
     * Limpia los filtros
     */
    limpiarFiltros() {
        this.modal.querySelector('#filtroNombre').value = '';
        this.modal.querySelector('#filtroGlosa').value = '';
        this.modal.querySelector('#filtroTipo').value = '';
    }

    /**
     * Ordena los resultados por una columna
     */
    ordenarPor(campo) {
        if (this.ordenActual === campo) {
            this.direccionOrden = this.direccionOrden === 'asc' ? 'desc' : 'asc';
        } else {
            this.ordenActual = campo;
            this.direccionOrden = 'asc';
        }
        
        this.resultados.sort((a, b) => {
            let valorA = a[campo];
            let valorB = b[campo];
            
            if (valorA === null || valorA === undefined) valorA = '';
            if (valorB === null || valorB === undefined) valorB = '';
            
            if (typeof valorA === 'string') {
                valorA = valorA.toLowerCase();
                valorB = valorB.toLowerCase();
            }
            
            if (this.direccionOrden === 'asc') {
                return valorA > valorB ? 1 : -1;
            } else {
                return valorA < valorB ? 1 : -1;
            }
        });
        
        this.mostrarResultados();
    }

    /**
     * Formatea un valor como moneda
     */
    formatearMoneda(valor) {
        if (!valor) return '-';
        return new Intl.NumberFormat('es-CL', {
            style: 'currency',
            currency: 'CLP'
        }).format(valor);
    }

    /**
     * Escapa HTML para prevenir XSS
     */
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Crear instancia global
window.selectorComprobanteTipo = new SelectorComprobanteTipo();

// Función de conveniencia para usar desde HTML
window.abrirSelectorComprobanteTipo = function(callback) {
    window.selectorComprobanteTipo.abrir(callback);
};


