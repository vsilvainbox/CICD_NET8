/**
 * JavaScript para funcionalidad de gestión de documentos de libros
 */

$(document).ready(function() {
    // Inicializar componentes
    inicializarComponentes();
    
    // Configurar eventos
    configurarEventos();
    
    // Cargar datos iniciales
    cargarDatosIniciales();
});

/**
 * Inicializar componentes de la interfaz
 */
function inicializarComponentes() {
    // Inicializar Select2 para combos
    $('.select2').select2({
        placeholder: 'Seleccionar...',
        allowClear: true,
        width: '100%'
    });
    
    // Inicializar DataTable para el grid
    $('#gridDocumentos').DataTable({
        responsive: true,
        paging: false,
        searching: false,
        ordering: false,
        info: false,
        columnDefs: [
            { orderable: false, targets: [0, 12] }, // Checkbox y acciones
            { className: 'text-center', targets: [0, 1, 4, 5, 6] },
            { className: 'text-right', targets: [10] }
        ],
        language: {
            emptyTable: "No hay datos disponibles",
            zeroRecords: "No se encontraron registros que coincidan con los criterios de búsqueda"
        }
    });
    
    // Configurar tooltips
    $('[data-toggle="tooltip"]').tooltip();
}

/**
 * Configurar eventos de la interfaz
 */
function configurarEventos() {
    // Botón de búsqueda
    $('#btnBuscar').on('click', function() {
        buscarDocumentos();
    });
    
    // Botón de limpiar filtros
    $('#btnLimpiar').on('click', function() {
        limpiarFiltros();
    });
    
    // Enter en campos de filtro
    $('#filtrosForm input, #filtrosForm select').on('keypress', function(e) {
        if (e.which === 13) {
            buscarDocumentos();
        }
    });
    
    // Validación de RUT
    $('#btnValidarRut').on('click', function() {
        validarRut();
    });
    
    $('#txRutEntidad').on('blur', function() {
        if ($(this).val().trim() !== '') {
            validarRut();
        }
    });
    
    // Selección de entidad por RUT
    $('#txRutEntidad').on('change', function() {
        if ($(this).val().trim() !== '') {
            buscarEntidadPorRut();
        }
    });
    
    // Checkbox de selección múltiple
    $('#chkSelectAll').on('change', function() {
        $('input[name="chkDocumento"]').prop('checked', $(this).is(':checked'));
        actualizarBotonesAccion();
    });
    
    // Botones de acción
    $('#btnEditar').on('click', function() {
        editarDocumento();
    });
    
    $('#btnEliminar').on('click', function() {
        eliminarDocumento();
    });
    
    $('#btnExportar').on('click', function() {
        exportarDocumento();
    });
    
    $('#btnImprimir').on('click', function() {
        imprimirDocumento();
    });
    
    $('#btnRefrescar').on('click', function() {
        buscarDocumentos();
    });
    
    // Eventos del grid
    $(document).on('change', 'input[name="chkDocumento"]', function() {
        actualizarBotonesAccion();
    });
    
    $(document).on('click', '.btn-ver-documento', function() {
        var idDocumento = $(this).data('id-documento');
        verDocumento(idDocumento);
    });
    
    $(document).on('click', '.btn-editar-documento', function() {
        var idDocumento = $(this).data('id-documento');
        editarDocumento(idDocumento);
    });
    
    $(document).on('click', '.btn-eliminar-documento', function() {
        var idDocumento = $(this).data('id-documento');
        eliminarDocumento(idDocumento);
    });
}

/**
 * Cargar datos iniciales
 */
function cargarDatosIniciales() {
    // Cargar opciones de filtros
    cargarOpcionesFiltros();
    
    // Ejecutar búsqueda inicial
    buscarDocumentos();
}

/**
 * Cargar opciones para los combos de filtros
 */
function cargarOpcionesFiltros() {
    $.ajax({
        url: '/DocumentosLibros/GetOpciones',
        type: 'GET',
        success: function(response) {
            if (response.success) {
                // Actualizar combos con las opciones recibidas
                actualizarCombo('#cbTipoDocumento', response.opciones.tiposDocumento);
                actualizarCombo('#cbSucursal', response.opciones.sucursales);
            }
        },
        error: function() {
            mostrarError('Error al cargar opciones de filtros');
        }
    });
}

/**
 * Actualizar un combo con opciones
 */
function actualizarCombo(selector, opciones) {
    var combo = $(selector);
    combo.empty();
    combo.append('<option value="">Seleccionar...</option>');
    
    opciones.forEach(function(opcion) {
        combo.append(`<option value="${opcion.valor}">${opcion.texto}</option>`);
    });
    
    combo.trigger('change');
}

/**
 * Buscar documentos según los filtros
 */
function buscarDocumentos() {
    var filtros = obtenerFiltros();
    
    mostrarCargando(true);
    
    $.ajax({
        url: '/DocumentosLibros/Buscar',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(filtros),
        success: function(response) {
            if (response.success) {
                mostrarDocumentos(response.documentos);
                actualizarPaginacion(response);
            } else {
                mostrarError(response.message || 'Error al buscar documentos');
            }
        },
        error: function() {
            mostrarError('Error al buscar documentos');
        },
        complete: function() {
            mostrarCargando(false);
        }
    });
}

/**
 * Obtener filtros del formulario
 */
function obtenerFiltros() {
    return {
        tipoDocumento: $('#cbTipoDocumento').val() || null,
        numeroDocumento: $('#txNumeroDocumento').val() || null,
        estado: $('#cbEstado').val() || null,
        fechaDesde: $('#txFechaDesde').val() || null,
        fechaHasta: $('#txFechaHasta').val() || null,
        rutEntidad: $('#txRutEntidad').val() || null,
        descripcion: $('#txDescripcion').val() || null,
        idSucursal: $('#cbSucursal').val() ? parseInt($('#cbSucursal').val()) : null,
        paginaActual: 1,
        registrosPorPagina: 50
    };
}

/**
 * Mostrar documentos en el grid
 */
function mostrarDocumentos(documentos) {
    var tbody = $('#tbodyDocumentos');
    tbody.empty();
    
    if (documentos && documentos.length > 0) {
        documentos.forEach(function(documento) {
            var fila = crearFilaDocumento(documento);
            tbody.append(fila);
        });
    } else {
        tbody.append('<tr><td colspan="13" class="text-center">No se encontraron documentos</td></tr>');
    }
    
    // Actualizar contador de registros
    $('#totalRegistros').text(documentos ? documentos.length : 0);
}

/**
 * Crear fila para un documento
 */
function crearFilaDocumento(documento) {
    var checkbox = `<input type="checkbox" name="chkDocumento" value="${documento.idDocumento}" class="form-check-input">`;
    var acciones = `
        <div class="btn-group btn-group-sm">
            <button type="button" class="btn btn-outline-primary btn-ver-documento" 
                    data-id-documento="${documento.idDocumento}" title="Ver documento">
                <i class="fas fa-eye"></i>
            </button>
            <button type="button" class="btn btn-outline-info btn-editar-documento" 
                    data-id-documento="${documento.idDocumento}" title="Editar documento">
                <i class="fas fa-edit"></i>
            </button>
            <button type="button" class="btn btn-outline-danger btn-eliminar-documento" 
                    data-id-documento="${documento.idDocumento}" title="Eliminar documento">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `;
    
    return `
        <tr>
            <td>${checkbox}</td>
            <td>${documento.idDocumento}</td>
            <td>${documento.tipoDocumento}</td>
            <td>${documento.numeroDocumento}</td>
            <td><span class="badge badge-${obtenerClaseEstado(documento.estado)}">${documento.estado}</span></td>
            <td>${formatearFecha(documento.fecha)}</td>
            <td>${formatearFecha(documento.fechaVencimiento)}</td>
            <td>${documento.nombreEntidad}</td>
            <td>${documento.rutEntidad}</td>
            <td>${documento.descripcion}</td>
            <td class="text-right">${formatearMoneda(documento.valorTotal)}</td>
            <td>${documento.nombreSucursal}</td>
            <td>${acciones}</td>
        </tr>
    `;
}

/**
 * Obtener clase CSS para el estado
 */
function obtenerClaseEstado(estado) {
    switch (estado.toLowerCase()) {
        case 'activo':
            return 'success';
        case 'borrador':
            return 'warning';
        case 'cancelado':
            return 'danger';
        default:
            return 'secondary';
    }
}

/**
 * Formatear fecha
 */
function formatearFecha(fecha) {
    if (!fecha) return '';
    var date = new Date(fecha);
    return date.toLocaleDateString('es-CL');
}

/**
 * Formatear moneda
 */
function formatearMoneda(valor) {
    if (!valor) return '$0';
    return new Intl.NumberFormat('es-CL', {
        style: 'currency',
        currency: 'CLP'
    }).format(valor);
}

/**
 * Actualizar paginación
 */
function actualizarPaginacion(response) {
    // Implementar lógica de paginación si es necesaria
    $('#registrosInicio').text(response.paginaActual * response.registrosPorPagina - response.registrosPorPagina + 1);
    $('#registrosFin').text(Math.min(response.paginaActual * response.registrosPorPagina, response.totalRegistros));
    $('#totalRegistrosPaginacion').text(response.totalRegistros);
}

/**
 * Limpiar filtros
 */
function limpiarFiltros() {
    $('#filtrosForm')[0].reset();
    $('.select2').val(null).trigger('change');
    buscarDocumentos();
}

/**
 * Validar RUT
 */
function validarRut() {
    var rut = $('#txRutEntidad').val().trim();
    
    if (rut === '') {
        return;
    }
    
    $.ajax({
        url: '/DocumentosLibros/ValidarRut',
        type: 'POST',
        data: { rut: rut },
        success: function(response) {
            if (response.success) {
                if (response.esValido) {
                    $('#txRutEntidad').val(response.rutFormateado);
                    mostrarExito('RUT válido');
                } else {
                    mostrarError('RUT inválido');
                }
            } else {
                mostrarError(response.message || 'Error al validar RUT');
            }
        },
        error: function() {
            mostrarError('Error al validar RUT');
        }
    });
}

/**
 * Buscar entidad por RUT
 */
function buscarEntidadPorRut() {
    var rut = $('#txRutEntidad').val().trim();
    
    if (rut === '') {
        return;
    }
    
    $.ajax({
        url: '/DocumentosLibros/GetEntidadPorRut',
        type: 'GET',
        data: { rut: rut },
        success: function(response) {
            if (response.success) {
                $('#cbEntidad').val(response.entidad.idEntidad).trigger('change');
            } else {
                // No mostrar error si no se encuentra la entidad
                console.log('Entidad no encontrada para RUT:', rut);
            }
        },
        error: function() {
            console.log('Error al buscar entidad por RUT');
        }
    });
}

/**
 * Ver documento
 */
function verDocumento(idDocumento) {
    if (!idDocumento) {
        var seleccionados = obtenerDocumentosSeleccionados();
        if (seleccionados.length === 0) {
            mostrarError('Seleccione al menos un documento');
            return;
        }
        if (seleccionados.length > 1) {
            mostrarError('Seleccione solo un documento');
            return;
        }
        idDocumento = seleccionados[0];
    }
    
    // Redirigir a la vista de edición
    window.location.href = `/DocumentosLibros/Edit/${idDocumento}`;
}

/**
 * Editar documento
 */
function editarDocumento(idDocumento) {
    if (!idDocumento) {
        var seleccionados = obtenerDocumentosSeleccionados();
        if (seleccionados.length === 0) {
            mostrarError('Seleccione al menos un documento');
            return;
        }
        if (seleccionados.length > 1) {
            mostrarError('Seleccione solo un documento');
            return;
        }
        idDocumento = seleccionados[0];
    }
    
    // Redirigir a la vista de edición
    window.location.href = `/DocumentosLibros/Edit/${idDocumento}`;
}

/**
 * Eliminar documento
 */
function eliminarDocumento(idDocumento) {
    if (!idDocumento) {
        var seleccionados = obtenerDocumentosSeleccionados();
        if (seleccionados.length === 0) {
            mostrarError('Seleccione al menos un documento');
            return;
        }
        if (seleccionados.length > 1) {
            mostrarError('Seleccione solo un documento');
            return;
        }
        idDocumento = seleccionados[0];
    }
    
    // Mostrar modal de confirmación
    $('#modalConfirmarEliminacion').modal('show');
    
    // Configurar botón de confirmación
    $('#btnConfirmarEliminacion').off('click').on('click', function() {
        confirmarEliminacion(idDocumento);
    });
}

/**
 * Confirmar eliminación de documento
 */
function confirmarEliminacion(idDocumento) {
    $.ajax({
        url: '/DocumentosLibros/Delete',
        type: 'POST',
        data: { id: idDocumento },
        success: function(response) {
            if (response.success) {
                mostrarExito(response.message || 'Documento eliminado exitosamente');
                $('#modalConfirmarEliminacion').modal('hide');
                buscarDocumentos(); // Refrescar la lista
            } else {
                mostrarError(response.message || 'Error al eliminar documento');
            }
        },
        error: function() {
            mostrarError('Error al eliminar documento');
        }
    });
}

/**
 * Exportar documento
 */
function exportarDocumento() {
    var seleccionados = obtenerDocumentosSeleccionados();
    
    if (seleccionados.length === 0) {
        mostrarError('Seleccione al menos un documento');
        return;
    }
    
    if (seleccionados.length > 1) {
        mostrarError('Seleccione solo un documento');
        return;
    }
    
    var idDocumento = seleccionados[0];
    
    $.ajax({
        url: '/DocumentosLibros/ExportarExcel',
        type: 'POST',
        data: { idDocumento: idDocumento },
        success: function(response) {
            if (response.success) {
                // Descargar archivo
                var blob = new Blob([response], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                var url = window.URL.createObjectURL(blob);
                var a = document.createElement('a');
                a.href = url;
                a.download = `DocumentoLibro_${idDocumento}_${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.xlsx`;
                a.click();
                window.URL.revokeObjectURL(url);
            } else {
                mostrarError(response.message || 'Error al exportar documento');
            }
        },
        error: function() {
            mostrarError('Error al exportar documento');
        }
    });
}

/**
 * Imprimir documento
 */
function imprimirDocumento() {
    // Implementar funcionalidad de impresión
    mostrarInfo('Funcionalidad de impresión en desarrollo');
}

/**
 * Obtener documentos seleccionados
 */
function obtenerDocumentosSeleccionados() {
    var seleccionados = [];
    $('input[name="chkDocumento"]:checked').each(function() {
        seleccionados.push(parseInt($(this).val()));
    });
    return seleccionados;
}

/**
 * Actualizar botones de acción según selección
 */
function actualizarBotonesAccion() {
    var seleccionados = obtenerDocumentosSeleccionados();
    var tieneSeleccion = seleccionados.length > 0;
    var tieneSeleccionUnica = seleccionados.length === 1;
    
    $('#btnEditar').prop('disabled', !tieneSeleccionUnica);
    $('#btnEliminar').prop('disabled', !tieneSeleccionUnica);
    $('#btnExportar').prop('disabled', !tieneSeleccionUnica);
    $('#btnImprimir').prop('disabled', !tieneSeleccionUnica);
}

/**
 * Mostrar estado de carga
 */
function mostrarCargando(mostrar) {
    if (mostrar) {
        $('#btnBuscar').prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Buscando...');
    } else {
        $('#btnBuscar').prop('disabled', false).html('<i class="fas fa-search"></i> Buscar');
    }
}

/**
 * Mostrar mensaje de éxito
 */
function mostrarExito(mensaje) {
    toastr.success(mensaje);
}

/**
 * Mostrar mensaje de error
 */
function mostrarError(mensaje) {
    toastr.error(mensaje);
}

/**
 * Mostrar mensaje de información
 */
function mostrarInfo(mensaje) {
    toastr.info(mensaje);
}









