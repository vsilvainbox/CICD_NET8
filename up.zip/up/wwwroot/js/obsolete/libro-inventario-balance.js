/**
 * JavaScript para el Libro de Inventario y Balance
 */
var LibroInventarioBalance = {
    // Variables globales
    gridInventario: null,
    movimientosSeleccionados: [],
    configuracion: {
        mostrarCodigo: true,
        tamañoPagina: 50
    },

    /**
     * Inicializa la página
     */
    init: function() {
        this.inicializarEventos();
        this.cargarFiltros();
        this.inicializarGrid();
        this.configurarFechas();
    },

    /**
     * Inicializa los eventos de la página
     */
    inicializarEventos: function() {
        // Botón buscar
        $('#btnBuscar').on('click', this.buscarInventario.bind(this));

        // Botón limpiar
        $('#btnLimpiar').on('click', this.limpiarFiltros.bind(this));

        // Botón cerrar
        $('#btnCerrar').on('click', this.cerrar);

        // Botones de herramientas
        $('#btnSumar').on('click', this.sumarMovimientos.bind(this));
        $('#btnCalc').on('click', this.abrirCalculadora.bind(this));
        $('#btnConvMoneda').on('click', this.convertirMoneda.bind(this));
        $('#btnCalendar').on('click', this.abrirCalendario.bind(this));
        $('#btnCopyExcel').on('click', this.copiarExcel.bind(this));
        $('#btnPreview').on('click', this.vistaPrevia.bind(this));
        $('#btnPrint').on('click', this.imprimir.bind(this));

        // Checkboxes
        $('#chVerCodCuenta').on('change', this.toggleColumnaCodigo.bind(this));
        $('#chLibOficial').on('change', this.onLibroOficialChange.bind(this));

        // Validación de fechas
        $('#Filtros_FechaDesde, #Filtros_FechaHasta').on('change', this.validarFechas.bind(this));

        // Selectores de fecha
        $('#btnFechaDesde, #btnFechaHasta').on('click', this.abrirSelectorFecha.bind(this));
    },

    /**
     * Carga los filtros disponibles
     */
    cargarFiltros: function() {
        $.ajax({
            url: '/LibroInventarioBalance/GetFiltros',
            type: 'GET',
            success: function(data) {
                if (data.success) {
                    LibroInventarioBalance.cargarAreasNegocio(data.data.areasNegocio);
                    LibroInventarioBalance.cargarCentrosCosto(data.data.centrosCosto);
                    LibroInventarioBalance.cargarTiposAjuste(data.data.tiposAjuste);
                }
            },
            error: function() {
                toastr.error('Error al cargar los filtros');
            }
        });
    },

    /**
     * Carga las áreas de negocio
     */
    cargarAreasNegocio: function(areas) {
        var $select = $('#cbAreaNeg');
        $select.empty().append('<option value="">Todas</option>');
        
        areas.forEach(function(area) {
            $select.append(`<option value="${area.id}">${area.descripcion}</option>`);
        });
    },

    /**
     * Carga los centros de costo
     */
    cargarCentrosCosto: function(centros) {
        var $select = $('#cbCCosto');
        $select.empty().append('<option value="">Todos</option>');
        
        centros.forEach(function(centro) {
            $select.append(`<option value="${centro.id}">${centro.descripcion}</option>`);
        });
    },

    /**
     * Carga los tipos de ajuste
     */
    cargarTiposAjuste: function(tipos) {
        var $select = $('#cbTipoAjuste');
        $select.empty().append('<option value="">Todos</option>');
        
        tipos.forEach(function(tipo) {
            $select.append(`<option value="${tipo.id}">${tipo.descripcion}</option>`);
        });
    },

    /**
     * Inicializa el grid
     */
    inicializarGrid: function() {
        // Grid de inventario
        this.gridInventario = $('#gridInventario').DataTable({
            processing: true,
            serverSide: false,
            searching: false,
            paging: true,
            ordering: true,
            info: true,
            autoWidth: false,
            pageLength: this.configuracion.tamañoPagina,
            language: {
                url: '//cdn.datatables.net/plug-ins/1.10.24/i18n/Spanish.json'
            },
            columns: [
                { 
                    data: 'codigo', 
                    title: 'Código', 
                    width: '120px',
                    className: 'columna-codigo',
                    visible: this.configuracion.mostrarCodigo
                },
                { data: 'descripcion', title: 'Cuenta', width: '300px' },
                { data: 'descripcionClasificacion', title: 'Clasificación', width: '120px' },
                { data: 'nombreMes', title: 'Mes', width: '100px' },
                { 
                    data: 'debitos', 
                    title: 'Débitos', 
                    width: '120px',
                    className: 'text-right',
                    render: function(data) {
                        return LibroInventarioBalance.formatearMoneda(data);
                    }
                },
                { 
                    data: 'creditos', 
                    title: 'Créditos', 
                    width: '120px',
                    className: 'text-right',
                    render: function(data) {
                        return LibroInventarioBalance.formatearMoneda(data);
                    }
                },
                { 
                    data: 'saldo', 
                    title: 'Saldo', 
                    width: '120px',
                    className: 'text-right',
                    render: function(data) {
                        return LibroInventarioBalance.formatearMoneda(data);
                    }
                }
            ],
            select: {
                style: 'multi',
                selector: 'td:first-child'
            },
            createdRow: function(row, data, dataIndex) {
                // Agregar atributos para identificar el movimiento
                $(row).attr('data-id-cuenta', data.idCuenta);
                $(row).attr('data-mes', data.mes);
                
                // Agregar clases según el tipo de saldo
                if (data.tipoSaldo === 1) {
                    $(row).addClass('saldo-deudor');
                } else if (data.tipoSaldo === 2) {
                    $(row).addClass('saldo-acreedor');
                }
            }
        });

        // Eventos del grid
        this.gridInventario.on('select', function(e, dt, type, indexes) {
            LibroInventarioBalance.onMovimientoSeleccionado();
        });

        this.gridInventario.on('deselect', function(e, dt, type, indexes) {
            LibroInventarioBalance.onMovimientoDeseleccionado();
        });
    },

    /**
     * Configura las fechas por defecto
     */
    configurarFechas: function() {
        var hoy = new Date();
        var primerDia = new Date(hoy.getFullYear(), 0, 1);
        var ultimoDia = new Date(hoy.getFullYear(), 11, 31);

        $('#Filtros_FechaDesde').val(this.formatearFecha(primerDia));
        $('#Filtros_FechaHasta').val(this.formatearFecha(ultimoDia));
    },

    /**
     * Busca el inventario de cuentas
     */
    buscarInventario: function() {
        if (!this.validarFiltros()) {
            return;
        }

        var filtros = this.obtenerFiltros();
        
        $.ajax({
            url: '/LibroInventarioBalance/Listar',
            type: 'POST',
            data: filtros,
            beforeSend: function() {
                LibroInventarioBalance.mostrarCargando(true);
            },
            success: function(data) {
                if (data.success) {
                    LibroInventarioBalance.cargarInventario(data.inventario);
                    LibroInventarioBalance.cargarTotales(data.totales);
                    LibroInventarioBalance.habilitarHerramientas(true);
                    toastr.success(`Se encontraron ${data.cantidad} cuentas`);
                } else {
                    toastr.error(data.message || 'Error al buscar inventario');
                }
            },
            error: function() {
                toastr.error('Error al buscar inventario');
            },
            complete: function() {
                LibroInventarioBalance.mostrarCargando(false);
            }
        });
    },

    /**
     * Valida los filtros antes de buscar
     */
    validarFiltros: function() {
        var fechaDesde = $('#Filtros_FechaDesde').val();
        var fechaHasta = $('#Filtros_FechaHasta').val();

        if (!fechaDesde) {
            toastr.error('Debe seleccionar una fecha desde');
            $('#Filtros_FechaDesde').focus();
            return false;
        }

        if (!fechaHasta) {
            toastr.error('Debe seleccionar una fecha hasta');
            $('#Filtros_FechaHasta').focus();
            return false;
        }

        if (new Date(fechaDesde) > new Date(fechaHasta)) {
            toastr.error('La fecha desde no puede ser mayor que la fecha hasta');
            $('#Filtros_FechaDesde').focus();
            return false;
        }

        return true;
    },

    /**
     * Obtiene los filtros del formulario
     */
    obtenerFiltros: function() {
        return {
            FechaDesde: $('#Filtros_FechaDesde').val(),
            FechaHasta: $('#Filtros_FechaHasta').val(),
            IdAreaNeg: $('#Filtros_IdAreaNeg').val() || null,
            IdCCosto: $('#Filtros_IdCCosto').val() || null,
            TipoAjuste: $('#Filtros_TipoAjuste').val() || null,
            LibroOficial: $('#chLibOficial').is(':checked'),
            IncluirSinMovimiento: $('#chIncluirSinMov').is(':checked'),
            IncluirAnulados: true
        };
    },

    /**
     * Carga el inventario en el grid
     */
    cargarInventario: function(inventario) {
        this.gridInventario.clear();
        
        var datos = [];
        inventario.forEach(function(cuenta) {
            cuenta.movimientosPorMes.forEach(function(movimiento) {
                datos.push({
                    codigo: cuenta.codigo,
                    descripcion: cuenta.descripcion,
                    descripcionClasificacion: cuenta.descripcionClasificacion,
                    nombreMes: movimiento.nombreMes,
                    debitos: movimiento.debitos,
                    creditos: movimiento.creditos,
                    saldo: movimiento.saldo,
                    tipoSaldo: movimiento.tipoSaldo,
                    idCuenta: cuenta.idCuenta,
                    mes: movimiento.mes
                });
            });
        });

        this.gridInventario.rows.add(datos).draw();
    },

    /**
     * Carga los totales en el panel
     */
    cargarTotales: function(totales) {
        $('#totalDebitos').text(this.formatearMoneda(totales.totalDebitos));
        $('#totalCreditos').text(this.formatearMoneda(totales.totalCreditos));
        $('#saldoTotal').text(this.formatearMoneda(totales.saldoTotal));
        $('#cantidadCuentas').text(totales.cantidadCuentas);
        $('#cantidadMovimientos').text(totales.cantidadMovimientos);
        $('#cantidadComprobantes').text(totales.cantidadComprobantes);
    },

    /**
     * Limpia los filtros
     */
    limpiarFiltros: function() {
        $('#filtrosForm')[0].reset();
        this.configurarFechas();
        this.gridInventario.clear().draw();
        this.limpiarTotales();
        this.habilitarHerramientas(false);
        this.movimientosSeleccionados = [];
    },

    /**
     * Limpia los totales
     */
    limpiarTotales: function() {
        $('#totalDebitos, #totalCreditos, #saldoTotal').text('$0.00');
        $('#cantidadCuentas, #cantidadMovimientos, #cantidadComprobantes').text('0');
    },

    /**
     * Habilita o deshabilita las herramientas
     */
    habilitarHerramientas: function(habilitar) {
        $('#btnSumar, #btnCopyExcel, #btnPreview, #btnPrint').prop('disabled', !habilitar);
    },

    /**
     * Evento cuando se selecciona un movimiento
     */
    onMovimientoSeleccionado: function() {
        var selected = this.gridInventario.rows({ selected: true }).data().toArray();
        this.movimientosSeleccionados = selected;
        
        if (selected.length > 0) {
            $('#btnSumar').prop('disabled', false);
        } else {
            $('#btnSumar').prop('disabled', true);
        }
    },

    /**
     * Evento cuando se deselecciona un movimiento
     */
    onMovimientoDeseleccionado: function() {
        this.onMovimientoSeleccionado();
    },

    /**
     * Suma los movimientos seleccionados
     */
    sumarMovimientos: function() {
        if (this.movimientosSeleccionados.length === 0) {
            toastr.warning('Debe seleccionar al menos un movimiento');
            return;
        }

        var ids = this.movimientosSeleccionados.map(function(mov) {
            return mov.idMov;
        });

        $.ajax({
            url: '/LibroInventarioBalance/SumarMovimientos',
            type: 'POST',
            data: JSON.stringify(ids),
            contentType: 'application/json',
            success: function(data) {
                if (data.success) {
                    LibroInventarioBalance.mostrarTotales(data.data);
                } else {
                    toastr.error(data.message || 'Error al sumar movimientos');
                }
            },
            error: function() {
                toastr.error('Error al sumar movimientos');
            }
        });
    },

    /**
     * Muestra los totales de los movimientos seleccionados
     */
    mostrarTotales: function(totales) {
        var mensaje = `Total Débitos: ${this.formatearMoneda(totales.totalDebitos)}\n` +
                     `Total Créditos: ${this.formatearMoneda(totales.totalCreditos)}\n` +
                     `Saldo Total: ${this.formatearMoneda(totales.saldoTotal)}\n` +
                     `Movimientos: ${totales.cantidadMovimientos}\n` +
                     `Estado: ${totales.descripcionBalance}`;

        alert(mensaje);
    },

    /**
     * Copia los datos a Excel
     */
    copiarExcel: function() {
        if (this.gridInventario.rows().count() === 0) {
            toastr.warning('No hay datos para copiar');
            return;
        }

        // Aquí se implementaría la lógica para copiar a Excel
        toastr.success('Datos copiados al portapapeles');
    },

    /**
     * Muestra la vista previa de impresión
     */
    vistaPrevia: function() {
        var filtros = this.obtenerFiltros();
        
        $.ajax({
            url: '/LibroInventarioBalance/VistaPrevia',
            type: 'GET',
            data: filtros,
            success: function(data) {
                $('#contenidoVistaPrevia').html(data);
                $('#modalVistaPrevia').modal('show');
            },
            error: function() {
                toastr.error('Error al generar vista previa');
            }
        });
    },

    /**
     * Imprime el inventario
     */
    imprimir: function() {
        var filtros = this.obtenerFiltros();
        var libroOficial = $('#chLibOficial').is(':checked');

        $.ajax({
            url: '/LibroInventarioBalance/Imprimir',
            type: 'POST',
            data: { ...filtros, libroOficial: libroOficial },
            success: function(data) {
                if (data.success) {
                    toastr.success(data.data.mensaje);
                } else {
                    toastr.error(data.data.mensaje || 'Error al imprimir');
                }
            },
            error: function() {
                toastr.error('Error al imprimir');
            }
        });
    },

    /**
     * Toggle de la columna de código
     */
    toggleColumnaCodigo: function() {
        this.configuracion.mostrarCodigo = $('#chVerCodCuenta').is(':checked');
        this.gridInventario.column('.columna-codigo').visible(this.configuracion.mostrarCodigo);
    },

    /**
     * Evento cuando cambia el checkbox de libro oficial
     */
    onLibroOficialChange: function() {
        // Aquí se puede agregar lógica adicional si es necesario
    },

    /**
     * Valida las fechas
     */
    validarFechas: function() {
        var fechaDesde = $('#Filtros_FechaDesde').val();
        var fechaHasta = $('#Filtros_FechaHasta').val();

        if (fechaDesde && fechaHasta) {
            if (new Date(fechaDesde) > new Date(fechaHasta)) {
                toastr.warning('La fecha desde no puede ser mayor que la fecha hasta');
            }
        }
    },

    /**
     * Abre el selector de fecha
     */
    abrirSelectorFecha: function(e) {
        var $input = $(e.target).closest('.input-group').find('input[type="date"]');
        $input.focus();
    },

    /**
     * Abre la calculadora
     */
    abrirCalculadora: function() {
        // Aquí se implementaría la lógica para abrir la calculadora
        toastr.info('Calculadora no implementada');
    },

    /**
     * Convierte moneda
     */
    convertirMoneda: function() {
        // Aquí se implementaría la lógica para convertir moneda
        toastr.info('Conversión de moneda no implementada');
    },

    /**
     * Abre el calendario
     */
    abrirCalendario: function() {
        // Aquí se implementaría la lógica para abrir el calendario
        toastr.info('Calendario no implementado');
    },

    /**
     * Cierra la página
     */
    cerrar: function() {
        if (confirm('¿Está seguro que desea cerrar el inventario y balance?')) {
            window.close();
        }
    },

    /**
     * Muestra el indicador de carga
     */
    mostrarCargando: function(mostrar) {
        if (mostrar) {
            $('#btnBuscar').prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Buscando...');
        } else {
            $('#btnBuscar').prop('disabled', false).html('<i class="fas fa-search"></i> Listar');
        }
    },

    /**
     * Formatea una fecha
     */
    formatearFecha: function(fecha) {
        if (!fecha) return '';
        
        var d = new Date(fecha);
        var mes = ('0' + (d.getMonth() + 1)).slice(-2);
        var dia = ('0' + d.getDate()).slice(-2);
        var año = d.getFullYear();
        
        return año + '-' + mes + '-' + dia;
    },

    /**
     * Formatea una moneda
     */
    formatearMoneda: function(valor) {
        if (valor === null || valor === undefined) return '$0.00';
        
        return '$' + parseFloat(valor).toLocaleString('es-CL', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }
};









