/**
 * JavaScript para el Libro de Retenciones y Honorarios
 */
var LibroRetenciones = {
    // Variables globales
    gridDocumentos: null,
    documentosSeleccionados: [],
    configuracion: {
        mostrarSucursal: true,
        mostrarDTE: true,
        aplicarRet3Porc: false,
        libroOficial: false,
        tamañoPagina: 50
    },

    /**
     * Inicializa la página
     */
    init: function() {
        this.inicializarEventos();
        this.cargarFiltros();
        this.inicializarGrid();
        this.configurarFechas();
    },

    /**
     * Inicializa los eventos de la página
     */
    inicializarEventos: function() {
        // Botón buscar
        $('#btnBuscar').on('click', this.buscarDocumentos.bind(this));

        // Botón limpiar
        $('#btnLimpiar').on('click', this.limpiarFiltros.bind(this));

        // Botón cerrar
        $('#btnCerrar').on('click', this.cerrar);

        // Botones de edición
        $('#btnNuevoDoc').on('click', this.abrirModalNuevoDocumento.bind(this));
        $('#btnSeleccionarEntidad').on('click', this.seleccionarEntidad.bind(this));
        $('#btnTipoDoc').on('click', this.seleccionarTipoDoc.bind(this));
        $('#btnCopiar').on('click', this.copiarDocumento.bind(this));
        $('#btnPegar').on('click', this.pegarDocumento.bind(this));
        $('#btnDuplicar').on('click', this.duplicarDocumento.bind(this));
        $('#btnAnular').on('click', this.anularDocumento.bind(this));
        $('#btnEliminar').on('click', this.eliminarDocumento.bind(this));

        // Botones de procesamiento
        $('#btnCentralizar').on('click', this.centralizarDocumentos.bind(this));
        $('#btnCentralizarFull').on('click', this.centralizarCompleto.bind(this));
        $('#btnImportar').on('click', this.importarDocumentos.bind(this));
        $('#btnAyudaImport').on('click', this.mostrarAyudaImportacion.bind(this));
        $('#btnEliminarTodos').on('click', this.eliminarTodosPendientes.bind(this));

        // Botones de reportes
        $('#btnResumen').on('click', this.generarResumen.bind(this));
        $('#btnVistaPrevia').on('click', this.vistaPrevia.bind(this));
        $('#btnImprimir').on('click', this.imprimir.bind(this));
        $('#btnCopiarExcel').on('click', this.copiarExcel.bind(this));

        // Botones de navegación
        $('#btnAnterior').on('click', this.paginaAnterior.bind(this));
        $('#btnSiguiente').on('click', this.paginaSiguiente.bind(this));

        // Checkboxes de opciones
        $('#chVerSucursal').on('change', this.toggleColumnaSucursal.bind(this));
        $('#chVerDTE').on('change', this.toggleColumnaDTE.bind(this));
        $('#chAplicarRet3Porc').on('change', this.toggleRet3Porc.bind(this));
        $('#chLibOficial').on('change', this.toggleLibroOficial.bind(this));

        // Checkbox seleccionar todos
        $('#chkSeleccionarTodos').on('change', this.seleccionarTodos.bind(this));

        // Modal nuevo documento
        $('#btnGuardarDocumento').on('click', this.guardarDocumento.bind(this));

        // Validación de fechas
        $('#fechaDesde, #fechaHasta').on('change', this.validarFechas.bind(this));
    },

    /**
     * Carga los filtros disponibles
     */
    cargarFiltros: function() {
        $.ajax({
            url: '/LibroRetenciones/GetFiltros',
            type: 'GET',
            success: function(data) {
                if (data.success) {
                    LibroRetenciones.cargarEntidades(data.data.entidades);
                    LibroRetenciones.cargarSucursales(data.data.sucursales);
                    LibroRetenciones.cargarTiposDocumento(data.data.tiposDocumento);
                    LibroRetenciones.cargarEstados(data.data.estados);
                    LibroRetenciones.cargarMeses(data.data.meses);
                    LibroRetenciones.cargarAnos(data.data.anos);
                }
            },
            error: function() {
                toastr.error('Error al cargar los filtros');
            }
        });
    },

    /**
     * Carga las entidades
     */
    cargarEntidades: function(entidades) {
        var $select = $('#cbEntidad');
        $select.empty().append('<option value="">Todas</option>');
        
        entidades.forEach(function(entidad) {
            $select.append(`<option value="${entidad.id}">${entidad.nombre}</option>`);
        });
    },

    /**
     * Carga las sucursales
     */
    cargarSucursales: function(sucursales) {
        var $select = $('#cbSucursal');
        $select.empty().append('<option value="">Todas</option>');
        
        sucursales.forEach(function(sucursal) {
            $select.append(`<option value="${sucursal.id}">${sucursal.descripcion}</option>`);
        });
    },

    /**
     * Carga los tipos de documento
     */
    cargarTiposDocumento: function(tipos) {
        var $select = $('#nuevoTipoDoc');
        $select.empty().append('<option value="">Seleccionar...</option>');
        
        tipos.forEach(function(tipo) {
            $select.append(`<option value="${tipo.id}">${tipo.descripcion}</option>`);
        });
    },

    /**
     * Carga los estados
     */
    cargarEstados: function(estados) {
        // Los estados se usan para validación interna
    },

    /**
     * Carga los meses
     */
    cargarMeses: function(meses) {
        var $select = $('#cbMes');
        $select.empty().append('<option value="">Todos</option>');
        
        meses.forEach(function(mes) {
            $select.append(`<option value="${mes.numero}">${mes.nombre}</option>`);
        });
    },

    /**
     * Carga los años
     */
    cargarAnos: function(anos) {
        var $select = $('#cbAno');
        $select.empty().append('<option value="">Todos</option>');
        
        anos.forEach(function(ano) {
            $select.append(`<option value="${ano.ano}">${ano.ano}</option>`);
        });
    },

    /**
     * Inicializa el grid
     */
    inicializarGrid: function() {
        this.gridDocumentos = $('#gridDocumentos').DataTable({
            processing: true,
            serverSide: false,
            searching: false,
            paging: true,
            ordering: true,
            info: true,
            autoWidth: false,
            pageLength: this.configuracion.tamañoPagina,
            language: {
                url: '//cdn.datatables.net/plug-ins/1.10.24/i18n/Spanish.json'
            },
            columns: [
                { 
                    data: 'seleccionado', 
                    title: '', 
                    width: '30px',
                    orderable: false,
                    render: function(data, type, row) {
                        return `<input type="checkbox" class="chk-documento" data-id="${row.id}" ${data ? 'checked' : ''} />`;
                    }
                },
                { data: 'tipoDoc', title: 'Tipo Doc', width: '80px' },
                { data: 'numDoc', title: 'Número', width: '100px' },
                { 
                    data: 'fecha', 
                    title: 'Fecha', 
                    width: '100px',
                    render: function(data) {
                        return LibroRetenciones.formatearFecha(data);
                    }
                },
                { data: 'rut', title: 'RUT', width: '120px' },
                { data: 'nombre', title: 'Nombre', width: '200px' },
                { 
                    data: 'sucursal', 
                    title: 'Sucursal', 
                    width: '100px',
                    className: 'columna-sucursal',
                    visible: this.configuracion.mostrarSucursal
                },
                { 
                    data: 'bruto', 
                    title: 'Bruto', 
                    width: '100px',
                    className: 'text-right',
                    render: function(data) {
                        return LibroRetenciones.formatearMoneda(data);
                    }
                },
                { 
                    data: 'honorSinRet', 
                    title: 'Honor Sin Ret', 
                    width: '100px',
                    className: 'text-right',
                    render: function(data) {
                        return LibroRetenciones.formatearMoneda(data);
                    }
                },
                { 
                    data: 'pImpuesto', 
                    title: '% Imp', 
                    width: '80px',
                    className: 'text-right',
                    render: function(data) {
                        return (data * 100).toFixed(2) + '%';
                    }
                },
                { 
                    data: 'impuesto', 
                    title: 'Impuesto', 
                    width: '100px',
                    className: 'text-right',
                    render: function(data) {
                        return LibroRetenciones.formatearMoneda(data);
                    }
                },
                { 
                    data: 'ret3Porc', 
                    title: 'Ret 3%', 
                    width: '100px',
                    className: 'text-right',
                    render: function(data) {
                        return LibroRetenciones.formatearMoneda(data);
                    }
                },
                { 
                    data: 'neto', 
                    title: 'Neto', 
                    width: '100px',
                    className: 'text-right',
                    render: function(data) {
                        return LibroRetenciones.formatearMoneda(data);
                    }
                },
                { data: 'estado', title: 'Estado', width: '80px' },
                { 
                    data: 'dte', 
                    title: 'DTE', 
                    width: '100px',
                    className: 'columna-dte',
                    visible: this.configuracion.mostrarDTE
                },
                { data: 'observaciones', title: 'Observaciones', width: '150px' },
                { data: 'referencia', title: 'Referencia', width: '100px' },
                { data: 'numeroCheque', title: 'N° Cheque', width: '100px' },
                { 
                    data: 'fechaCheque', 
                    title: 'Fecha Cheque', 
                    width: '100px',
                    render: function(data) {
                        return data ? LibroRetenciones.formatearFecha(data) : '';
                    }
                },
                { data: 'banco', title: 'Banco', width: '100px' },
                { data: 'cuenta', title: 'Cuenta', width: '100px' }
            ],
            createdRow: function(row, data, dataIndex) {
                // Agregar atributos para identificar el documento
                $(row).attr('data-id-documento', data.id);
                
                // Agregar clases según el estado
                if (data.idEstado === 1) {
                    $(row).addClass('estado-pendiente');
                } else if (data.idEstado === 2) {
                    $(row).addClass('estado-aprobado');
                } else if (data.idEstado === 3) {
                    $(row).addClass('estado-anulado');
                }
            }
        });

        // Eventos del grid
        this.gridDocumentos.on('change', '.chk-documento', function() {
            LibroRetenciones.onDocumentoSeleccionado();
        });
    },

    /**
     * Configura las fechas por defecto
     */
    configurarFechas: function() {
        var hoy = new Date();
        var primerDia = new Date(hoy.getFullYear(), hoy.getMonth(), 1);
        var ultimoDia = new Date(hoy.getFullYear(), hoy.getMonth() + 1, 0);

        $('#fechaDesde').val(this.formatearFecha(primerDia));
        $('#fechaHasta').val(this.formatearFecha(ultimoDia));
    },

    /**
     * Busca los documentos
     */
    buscarDocumentos: function() {
        if (!this.validarFiltros()) {
            return;
        }

        var filtros = this.obtenerFiltros();
        
        $.ajax({
            url: '/LibroRetenciones/Listar',
            type: 'POST',
            data: filtros,
            beforeSend: function() {
                LibroRetenciones.mostrarCargando(true);
            },
            success: function(data) {
                if (data.success) {
                    LibroRetenciones.cargarDocumentos(data.data.documentos);
                    LibroRetenciones.cargarTotales(data.data.totales);
                    LibroRetenciones.habilitarHerramientas(true);
                    toastr.success(`Se encontraron ${data.data.totalRegistros} documentos`);
                } else {
                    toastr.error(data.message || 'Error al buscar documentos');
                }
            },
            error: function() {
                toastr.error('Error al buscar documentos');
            },
            complete: function() {
                LibroRetenciones.mostrarCargando(false);
            }
        });
    },

    /**
     * Valida los filtros antes de buscar
     */
    validarFiltros: function() {
        var fechaDesde = $('#fechaDesde').val();
        var fechaHasta = $('#fechaHasta').val();

        if (fechaDesde && fechaHasta) {
            if (new Date(fechaDesde) > new Date(fechaHasta)) {
                toastr.error('La fecha desde no puede ser mayor que la fecha hasta');
                return false;
            }
        }

        return true;
    },

    /**
     * Obtiene los filtros del formulario
     */
    obtenerFiltros: function() {
        return {
            FechaDesde: $('#fechaDesde').val() || null,
            FechaHasta: $('#fechaHasta').val() || null,
            IdEntidad: $('#cbEntidad').val() || null,
            IdSucursal: $('#cbSucursal').val() || null,
            Mes: $('#cbMes').val() || null,
            Ano: $('#cbAno').val() || null,
            VerDTE: $('#chVerDTE').is(':checked'),
            VerSucursal: $('#chVerSucursal').is(':checked'),
            AplicarRet3Porc: $('#chAplicarRet3Porc').is(':checked'),
            LibroOficial: $('#chLibOficial').is(':checked'),
            IncluirAnulados: true
        };
    },

    /**
     * Carga los documentos en el grid
     */
    cargarDocumentos: function(documentos) {
        this.gridDocumentos.clear();
        this.gridDocumentos.rows.add(documentos).draw();
    },

    /**
     * Carga los totales en el panel
     */
    cargarTotales: function(totales) {
        $('#totalBruto').text(this.formatearMoneda(totales.totalBruto));
        $('#totalHonorSinRet').text(this.formatearMoneda(totales.totalHonorSinRet));
        $('#totalImpuesto').text(this.formatearMoneda(totales.totalImpuesto));
        $('#totalRet3Porc').text(this.formatearMoneda(totales.totalRet3Porc));
        $('#totalNeto').text(this.formatearMoneda(totales.totalNeto));
        $('#cantidadDocumentos').text(totales.cantidadDocumentos);
    },

    /**
     * Limpia los filtros
     */
    limpiarFiltros: function() {
        $('#cbEntidad, #cbSucursal, #cbMes, #cbAno').val('');
        this.configurarFechas();
        this.gridDocumentos.clear().draw();
        this.limpiarTotales();
        this.habilitarHerramientas(false);
        this.documentosSeleccionados = [];
    },

    /**
     * Limpia los totales
     */
    limpiarTotales: function() {
        $('#totalBruto, #totalHonorSinRet, #totalImpuesto, #totalRet3Porc, #totalNeto').text('$0.00');
        $('#cantidadDocumentos').text('0');
    },

    /**
     * Habilita o deshabilita las herramientas
     */
    habilitarHerramientas: function(habilitar) {
        $('#btnCentralizar, #btnCentralizarFull, #btnVistaPrevia, #btnImprimir, #btnCopiarExcel').prop('disabled', !habilitar);
    },

    /**
     * Evento cuando se selecciona un documento
     */
    onDocumentoSeleccionado: function() {
        var selected = [];
        $('.chk-documento:checked').each(function() {
            selected.push(parseInt($(this).data('id')));
        });
        
        this.documentosSeleccionados = selected;
        
        if (selected.length > 0) {
            $('#btnCentralizar').prop('disabled', false);
        } else {
            $('#btnCentralizar').prop('disabled', true);
        }
    },

    /**
     * Selecciona todos los documentos
     */
    seleccionarTodos: function() {
        var isChecked = $('#chkSeleccionarTodos').is(':checked');
        $('.chk-documento').prop('checked', isChecked);
        this.onDocumentoSeleccionado();
    },

    /**
     * Abre el modal para nuevo documento
     */
    abrirModalNuevoDocumento: function() {
        $('#modalNuevoDocumento').modal('show');
    },

    /**
     * Guarda un nuevo documento
     */
    guardarDocumento: function() {
        var documento = {
            IdTipoDoc: parseInt($('#nuevoTipoDoc').val()),
            NumDoc: $('#nuevoNumDoc').val(),
            Fecha: $('#nuevoFecha').val(),
            IdEntidad: parseInt($('#nuevoEntidad').val()),
            IdSucursal: $('#nuevoSucursal').val() ? parseInt($('#nuevoSucursal').val()) : null,
            Bruto: parseFloat($('#nuevoBruto').val()) || 0,
            HonorSinRet: parseFloat($('#nuevoHonorSinRet').val()) || 0,
            PImpuesto: parseFloat($('#nuevoPImpuesto').val()) || 0,
            IdEstado: 1, // Estado pendiente
            Observaciones: $('#nuevoObservaciones').val(),
            Referencia: $('#nuevoReferencia').val(),
            IdUsuario: 1, // Usuario por defecto
            UsuarioCreacion: 'Usuario'
        };

        $.ajax({
            url: '/LibroRetenciones/CrearDocumento',
            type: 'POST',
            data: JSON.stringify(documento),
            contentType: 'application/json',
            success: function(data) {
                if (data.success) {
                    toastr.success('Documento creado correctamente');
                    $('#modalNuevoDocumento').modal('hide');
                    LibroRetenciones.buscarDocumentos();
                } else {
                    toastr.error(data.message || 'Error al crear documento');
                }
            },
            error: function() {
                toastr.error('Error al crear documento');
            }
        });
    },

    /**
     * Centraliza los documentos seleccionados
     */
    centralizarDocumentos: function() {
        if (this.documentosSeleccionados.length === 0) {
            toastr.warning('Debe seleccionar al menos un documento');
            return;
        }

        $.ajax({
            url: '/LibroRetenciones/CentralizarDocumentos',
            type: 'POST',
            data: JSON.stringify(this.documentosSeleccionados),
            contentType: 'application/json',
            success: function(data) {
                if (data.success) {
                    toastr.success(data.data.mensaje);
                    LibroRetenciones.buscarDocumentos();
                } else {
                    toastr.error(data.message || 'Error al centralizar documentos');
                }
            },
            error: function() {
                toastr.error('Error al centralizar documentos');
            }
        });
    },

    /**
     * Centraliza todos los documentos pendientes
     */
    centralizarCompleto: function() {
        if (!confirm('¿Está seguro que desea centralizar todos los documentos pendientes?')) {
            return;
        }

        var filtros = this.obtenerFiltros();
        
        $.ajax({
            url: '/LibroRetenciones/CentralizarCompleto',
            type: 'POST',
            data: filtros,
            success: function(data) {
                if (data.success) {
                    toastr.success(data.data.mensaje);
                    LibroRetenciones.buscarDocumentos();
                } else {
                    toastr.error(data.message || 'Error al centralizar documentos');
                }
            },
            error: function() {
                toastr.error('Error al centralizar documentos');
            }
        });
    },

    /**
     * Importa documentos desde archivo
     */
    importarDocumentos: function() {
        var input = $('<input type="file" accept=".txt,.csv" />');
        input.on('change', function(e) {
            var file = e.target.files[0];
            if (file) {
                var formData = new FormData();
                formData.append('archivo', file);
                
                $.ajax({
                    url: '/LibroRetenciones/ImportarDocumentos',
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(data) {
                        if (data.success) {
                            toastr.success(data.data.mensaje);
                            LibroRetenciones.buscarDocumentos();
                        } else {
                            toastr.error(data.message || 'Error al importar documentos');
                        }
                    },
                    error: function() {
                        toastr.error('Error al importar documentos');
                    }
                });
            }
        });
        input.click();
    },

    /**
     * Muestra la ayuda de importación
     */
    mostrarAyudaImportacion: function() {
        alert('Formato del archivo de importación:\n\n' +
              'Líneas separadas por saltos de línea\n' +
              'Campos separados por tabulaciones:\n' +
              '1. ID Tipo Documento\n' +
              '2. Número Documento\n' +
              '3. Fecha (YYYY-MM-DD)\n' +
              '4. ID Entidad\n' +
              '5. ID Sucursal (opcional)\n' +
              '6. Monto Bruto\n' +
              '7. Honorarios Sin Retención\n' +
              '8. ID Porcentaje Impuesto\n' +
              '9. Porcentaje Impuesto\n' +
              '10. Impuesto\n' +
              '11. Retención 3%\n' +
              '12. Neto');
    },

    /**
     * Elimina todos los documentos pendientes
     */
    eliminarTodosPendientes: function() {
        if (!confirm('¿Está seguro que desea eliminar todos los documentos pendientes?')) {
            return;
        }

        $.ajax({
            url: '/LibroRetenciones/EliminarTodosPendientes',
            type: 'POST',
            success: function(data) {
                if (data.success) {
                    toastr.success(data.message);
                    LibroRetenciones.buscarDocumentos();
                } else {
                    toastr.error(data.message || 'Error al eliminar documentos');
                }
            },
            error: function() {
                toastr.error('Error al eliminar documentos');
            }
        });
    },

    /**
     * Genera el resumen de retención 3%
     */
    generarResumen: function() {
        var filtros = this.obtenerFiltros();
        
        $.ajax({
            url: '/LibroRetenciones/ResumenRet3Porc',
            type: 'GET',
            data: filtros,
            success: function(data) {
                if (data.success) {
                    LibroRetenciones.mostrarResumen(data.data);
                } else {
                    toastr.error(data.message || 'Error al generar resumen');
                }
            },
            error: function() {
                toastr.error('Error al generar resumen');
            }
        });
    },

    /**
     * Muestra el resumen de retención 3%
     */
    mostrarResumen: function(resumen) {
        var mensaje = `Resumen Retención 3% Préstamo Solidario\n\n` +
                     `Total Bruto: ${LibroRetenciones.formatearMoneda(resumen.totalBruto)}\n` +
                     `Total Retención 3%: ${LibroRetenciones.formatearMoneda(resumen.totalRet3Porc)}\n` +
                     `Total Neto: ${LibroRetenciones.formatearMoneda(resumen.totalNeto)}\n` +
                     `Cantidad Documentos: ${resumen.cantidadDocumentos}\n\n` +
                     `Detalle por Entidad:\n`;
        
        resumen.items.forEach(function(item) {
            mensaje += `${item.nombre}: ${LibroRetenciones.formatearMoneda(item.ret3Porc)}\n`;
        });

        alert(mensaje);
    },

    /**
     * Muestra la vista previa
     */
    vistaPrevia: function() {
        var filtros = this.obtenerFiltros();
        
        $.ajax({
            url: '/LibroRetenciones/VistaPrevia',
            type: 'GET',
            data: filtros,
            success: function(data) {
                $('#contenidoVistaPrevia').html(data);
                $('#modalVistaPrevia').modal('show');
            },
            error: function() {
                toastr.error('Error al generar vista previa');
            }
        });
    },

    /**
     * Imprime el libro
     */
    imprimir: function() {
        var filtros = this.obtenerFiltros();
        
        $.ajax({
            url: '/LibroRetenciones/Imprimir',
            type: 'POST',
            data: filtros,
            success: function(data) {
                if (data.success) {
                    toastr.success(data.data.mensaje);
                } else {
                    toastr.error(data.data.mensaje || 'Error al imprimir');
                }
            },
            error: function() {
                toastr.error('Error al imprimir');
            }
        });
    },

    /**
     * Copia los datos a Excel
     */
    copiarExcel: function() {
        var filtros = this.obtenerFiltros();
        
        $.ajax({
            url: '/LibroRetenciones/CopiarExcel',
            type: 'POST',
            data: filtros,
            success: function(data) {
                if (data.success) {
                    toastr.success(data.data.mensaje);
                } else {
                    toastr.error(data.data.mensaje || 'Error al copiar a Excel');
                }
            },
            error: function() {
                toastr.error('Error al copiar a Excel');
            }
        });
    },

    /**
     * Toggle de la columna de sucursal
     */
    toggleColumnaSucursal: function() {
        this.configuracion.mostrarSucursal = $('#chVerSucursal').is(':checked');
        this.gridDocumentos.column('.columna-sucursal').visible(this.configuracion.mostrarSucursal);
    },

    /**
     * Toggle de la columna de DTE
     */
    toggleColumnaDTE: function() {
        this.configuracion.mostrarDTE = $('#chVerDTE').is(':checked');
        this.gridDocumentos.column('.columna-dte').visible(this.configuracion.mostrarDTE);
    },

    /**
     * Toggle de retención 3%
     */
    toggleRet3Porc: function() {
        this.configuracion.aplicarRet3Porc = $('#chAplicarRet3Porc').is(':checked');
        // Aquí se implementaría la lógica para recalcular retención 3%
    },

    /**
     * Toggle de libro oficial
     */
    toggleLibroOficial: function() {
        this.configuracion.libroOficial = $('#chLibOficial').is(':checked');
        // Aquí se implementaría la lógica para filtrar solo documentos aprobados
    },

    /**
     * Valida las fechas
     */
    validarFechas: function() {
        var fechaDesde = $('#fechaDesde').val();
        var fechaHasta = $('#fechaHasta').val();

        if (fechaDesde && fechaHasta) {
            if (new Date(fechaDesde) > new Date(fechaHasta)) {
                toastr.warning('La fecha desde no puede ser mayor que la fecha hasta');
            }
        }
    },

    /**
     * Cierra la página
     */
    cerrar: function() {
        if (confirm('¿Está seguro que desea cerrar el libro de retenciones?')) {
            window.close();
        }
    },

    /**
     * Muestra el indicador de carga
     */
    mostrarCargando: function(mostrar) {
        if (mostrar) {
            $('#btnBuscar').prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Buscando...');
        } else {
            $('#btnBuscar').prop('disabled', false).html('<i class="fas fa-search"></i> Buscar');
        }
    },

    /**
     * Formatea una fecha
     */
    formatearFecha: function(fecha) {
        if (!fecha) return '';
        
        var d = new Date(fecha);
        var mes = ('0' + (d.getMonth() + 1)).slice(-2);
        var dia = ('0' + d.getDate()).slice(-2);
        var año = d.getFullYear();
        
        return año + '-' + mes + '-' + dia;
    },

    /**
     * Formatea una moneda
     */
    formatearMoneda: function(valor) {
        if (valor === null || valor === undefined) return '$0.00';
        
        return '$' + parseFloat(valor).toLocaleString('es-CL', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }
};

// Inicializar cuando el documento esté listo
$(document).ready(function() {
    LibroRetenciones.init();
});









