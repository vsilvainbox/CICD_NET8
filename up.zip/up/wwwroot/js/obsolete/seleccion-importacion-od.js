/**
 * Funcionalidad para la selección de importación de otros documentos
 */
var SeleccionImportacionOD = (function() {
    'use strict';

    // Variables de configuración
    var config = {
        formId: '#formSeleccion',
        modalId: '#modalConfirmacion',
        tiposImportacion: [],
        configuracion: {}
    };

    // Elementos del DOM
    var elements = {
        form: null,
        modal: null,
        btnSeleccionar: null,
        btnCancelar: null,
        btnConfirmar: null,
        tiposRadio: null,
        tipoSeleccionadoNombre: null,
        detallesSeleccion: null
    };

    /**
     * Inicializa la funcionalidad
     */
    function init(options) {
        // Extender configuración
        if (options) {
            Object.assign(config, options);
        }

        // Obtener elementos del DOM
        initializeElements();

        // Configurar event listeners
        setupEventListeners();

        // Inicializar estado
        initializeState();

        console.log('SeleccionImportacionOD inicializado correctamente');
    }

    /**
     * Inicializa los elementos del DOM
     */
    function initializeElements() {
        elements.form = $(config.formId);
        elements.modal = $(config.modalId);
        elements.btnSeleccionar = $('#btnSeleccionar');
        elements.btnCancelar = $('#btnCancelar');
        elements.btnConfirmar = $('#btnConfirmar');
        elements.tiposRadio = $('input[name="TipoSeleccionado"]');
        elements.tipoSeleccionadoNombre = $('#tipoSeleccionadoNombre');
        elements.detallesSeleccion = $('#detallesSeleccion');
    }

    /**
     * Configura los event listeners
     */
    function setupEventListeners() {
        // Event listener para el botón de seleccionar
        elements.btnSeleccionar.on('click', function(e) {
            e.preventDefault();
            handleSeleccionarClick();
        });

        // Event listener para el botón de cancelar
        elements.btnCancelar.on('click', function() {
            handleCancelarClick();
        });

        // Event listener para el botón de confirmar en el modal
        elements.btnConfirmar.on('click', function() {
            handleConfirmarClick();
        });

        // Event listeners para los radio buttons
        elements.tiposRadio.on('change', function() {
            handleTipoChange($(this));
        });

        // Event listener para hacer clic en las tarjetas de tipo
        $('.tipo-importacion').on('click', function() {
            var tipoId = $(this).data('tipo');
            var radio = $(this).find('input[type="radio"]');
            radio.prop('checked', true).trigger('change');
        });

        // Event listener para el formulario
        elements.form.on('submit', function(e) {
            e.preventDefault();
            handleFormSubmit();
        });
    }

    /**
     * Inicializa el estado inicial
     */
    function initializeState() {
        // Seleccionar el primer tipo por defecto si no hay ninguno seleccionado
        if (elements.tiposRadio.filter(':checked').length === 0) {
            elements.tiposRadio.first().prop('checked', true);
        }

        // Actualizar la visualización
        updateVisualState();
    }

    /**
     * Maneja el clic en el botón de seleccionar
     */
    function handleSeleccionarClick() {
        var tipoSeleccionado = getTipoSeleccionado();
        
        if (!tipoSeleccionado) {
            showError('Debe seleccionar un tipo de importación');
            return;
        }

        // Mostrar modal de confirmación
        showModalConfirmacion(tipoSeleccionado);
    }

    /**
     * Maneja el clic en el botón de cancelar
     */
    function handleCancelarClick() {
        if (confirm('¿Está seguro de que desea cancelar la selección?')) {
            window.location.href = '/Home';
        }
    }

    /**
     * Maneja el clic en el botón de confirmar del modal
     */
    function handleConfirmarClick() {
        elements.modal.modal('hide');
        handleFormSubmit();
    }

    /**
     * Maneja el cambio de tipo seleccionado
     */
    function handleTipoChange(radio) {
        updateVisualState();
    }

    /**
     * Maneja el envío del formulario
     */
    function handleFormSubmit() {
        var tipoSeleccionado = getTipoSeleccionado();
        
        if (!tipoSeleccionado) {
            showError('Debe seleccionar un tipo de importación');
            return;
        }

        // Validar la selección
        if (config.configuracion.validacion && config.configuracion.validacion.validarEnCliente) {
            if (!validateSelection(tipoSeleccionado)) {
                return;
            }
        }

        // Enviar formulario
        elements.form[0].submit();
    }

    /**
     * Obtiene el tipo de importación seleccionado
     */
    function getTipoSeleccionado() {
        var radioSeleccionado = elements.tiposRadio.filter(':checked');
        if (radioSeleccionado.length === 0) {
            return null;
        }
        
        var tipoId = parseInt(radioSeleccionado.val());
        return config.tiposImportacion.find(t => t.id === tipoId);
    }

    /**
     * Actualiza el estado visual
     */
    function updateVisualState() {
        var tipoSeleccionado = getTipoSeleccionado();
        
        // Actualizar clases de las tarjetas
        $('.tipo-importacion').removeClass('selected');
        if (tipoSeleccionado) {
            $('.tipo-importacion[data-tipo="' + tipoSeleccionado.id + '"]').addClass('selected');
        }

        // Actualizar estado del botón
        elements.btnSeleccionar.prop('disabled', !tipoSeleccionado);
    }

    /**
     * Muestra el modal de confirmación
     */
    function showModalConfirmacion(tipo) {
        elements.tipoSeleccionadoNombre.text(tipo.nombre);
        
        // Crear detalles de la selección
        var detalles = '<div class="mt-3">';
        detalles += '<h6>Descripción:</h6>';
        detalles += '<p class="text-muted">' + tipo.descripcion + '</p>';
        
        if (tipo.caracteristicas && tipo.caracteristicas.length > 0) {
            detalles += '<h6>Características principales:</h6>';
            detalles += '<ul class="list-unstyled">';
            tipo.caracteristicas.slice(0, 3).forEach(function(caracteristica) {
                detalles += '<li><i class="fas fa-check text-success mr-1"></i> ' + caracteristica + '</li>';
            });
            detalles += '</ul>';
        }
        
        detalles += '</div>';
        
        elements.detallesSeleccion.html(detalles);
        elements.modal.modal('show');
    }

    /**
     * Valida la selección
     */
    function validateSelection(tipo) {
        if (!tipo) {
            showError('Debe seleccionar un tipo de importación');
            return false;
        }

        if (!tipo.disponible) {
            showError('El tipo de importación seleccionado no está disponible');
            return false;
        }

        return true;
    }

    /**
     * Muestra un mensaje de error
     */
    function showError(message) {
        // Crear o actualizar alerta de error
        var alertHtml = '<div class="alert alert-danger alert-dismissible fade show" role="alert">';
        alertHtml += '<i class="fas fa-exclamation-triangle mr-2"></i>';
        alertHtml += message;
        alertHtml += '<button type="button" class="close" data-dismiss="alert">';
        alertHtml += '<span>&times;</span>';
        alertHtml += '</button>';
        alertHtml += '</div>';

        // Remover alertas anteriores
        $('.alert-danger').remove();
        
        // Insertar nueva alerta
        elements.form.prepend(alertHtml);
        
        // Scroll al formulario
        $('html, body').animate({
            scrollTop: elements.form.offset().top - 100
        }, 500);
    }

    /**
     * Muestra un mensaje de éxito
     */
    function showSuccess(message) {
        // Crear o actualizar alerta de éxito
        var alertHtml = '<div class="alert alert-success alert-dismissible fade show" role="alert">';
        alertHtml += '<i class="fas fa-check-circle mr-2"></i>';
        alertHtml += message;
        alertHtml += '<button type="button" class="close" data-dismiss="alert">';
        alertHtml += '<span>&times;</span>';
        alertHtml += '</button>';
        alertHtml += '</div>';

        // Remover alertas anteriores
        $('.alert-success').remove();
        
        // Insertar nueva alerta
        elements.form.prepend(alertHtml);
    }

    /**
     * Obtiene información de un tipo por ID
     */
    function getTipoById(id) {
        return config.tiposImportacion.find(t => t.id === id);
    }

    /**
     * Actualiza la configuración
     */
    function updateConfig(newConfig) {
        Object.assign(config, newConfig);
    }

    // API pública
    return {
        init: init,
        getTipoSeleccionado: getTipoSeleccionado,
        getTipoById: getTipoById,
        updateConfig: updateConfig,
        showError: showError,
        showSuccess: showSuccess
    };
})();









