/**
 * JavaScript para la funcionalidad de selección de libros y documentos
 */
var SeleccionLibrosDocs = (function() {
    'use strict';

    // Variables globales
    var config = {};
    var opcionesLibros = [];
    var periodos = [];
    var configuracionSistema = {};

    // Inicialización
    function init(options) {
        config = Object.assign({
            incluirTodos: true,
            incluirPeriodo: false,
            tipoLibroSeleccionado: 1,
            mesSeleccionado: new Date().getMonth() + 1,
            anioSeleccionado: new Date().getFullYear(),
            puedeSeleccionar: true,
            configuracionValida: true,
            tieneErrores: false
        }, options);

        cargarDatosIniciales();
        configurarEventos();
        actualizarInformacionSeleccion();
    }

    // Cargar datos iniciales
    function cargarDatosIniciales() {
        cargarOpcionesLibros();
        cargarPeriodos();
        cargarConfiguracionSistema();
    }

    // Cargar opciones de libros
    function cargarOpcionesLibros() {
        fetch('/SeleccionLibrosDocs/GetOpcionesLibros?incluirTodos=' + config.incluirTodos)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    opcionesLibros = data.opciones;
                    actualizarOpcionesLibros();
                }
            })
            .catch(error => {
                console.error('Error al cargar opciones de libros:', error);
                mostrarError('Error al cargar opciones de libros');
            });
    }

    // Cargar períodos
    function cargarPeriodos() {
        fetch('/SeleccionLibrosDocs/GetPeriodos')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    periodos = data.periodos;
                    actualizarPeriodos();
                }
            })
            .catch(error => {
                console.error('Error al cargar períodos:', error);
                mostrarError('Error al cargar períodos');
            });
    }

    // Cargar configuración del sistema
    function cargarConfiguracionSistema() {
        fetch('/SeleccionLibrosDocs/GetConfiguracionSistema')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    configuracionSistema = data.configuracion;
                    validarConfiguracion();
                }
            })
            .catch(error => {
                console.error('Error al cargar configuración del sistema:', error);
            });
    }

    // Configurar eventos
    function configurarEventos() {
        // Eventos de opciones de libros
        document.querySelectorAll('.opcion-libro').forEach(radio => {
            radio.addEventListener('change', function() {
                if (this.checked) {
                    config.tipoLibroSeleccionado = parseInt(this.value);
                    actualizarInformacionSeleccion();
                    validarConfiguracionTipoLibro();
                }
            });
        });

        // Eventos de período
        document.getElementById('mes')?.addEventListener('change', function() {
            config.mesSeleccionado = parseInt(this.value);
            actualizarInformacionSeleccion();
        });

        document.getElementById('anio')?.addEventListener('change', function() {
            config.anioSeleccionado = parseInt(this.value);
            actualizarInformacionSeleccion();
        });

        // Evento del formulario
        document.getElementById('formSeleccionLibros')?.addEventListener('submit', function(e) {
            e.preventDefault();
            procesarSeleccion();
        });

        // Eventos de botones
        document.getElementById('btnCancelar')?.addEventListener('click', function() {
            cancelarSeleccion();
        });

        document.getElementById('btnConfirmarSeleccion')?.addEventListener('click', function() {
            confirmarSeleccion();
        });
    }

    // Actualizar opciones de libros
    function actualizarOpcionesLibros() {
        opcionesLibros.forEach(opcion => {
            const radio = document.getElementById('opcion_' + opcion.id);
            if (radio) {
                radio.disabled = !opcion.disponible;
                if (!opcion.disponible) {
                    radio.parentElement.classList.add('text-muted');
                }
            }
        });
    }

    // Actualizar períodos
    function actualizarPeriodos() {
        // Los períodos ya se cargan en el HTML
        // Aquí se pueden agregar validaciones adicionales
    }

    // Actualizar información de selección
    function actualizarInformacionSeleccion() {
        const opcion = opcionesLibros.find(o => o.id === config.tipoLibroSeleccionado);
        if (opcion) {
            document.getElementById('infoTipoLibro').textContent = opcion.nombre;
            document.getElementById('infoDescripcion').textContent = opcion.descripcion;
        }

        if (config.incluirPeriodo && config.mesSeleccionado && config.anioSeleccionado) {
            const mes = document.getElementById('mes')?.selectedOptions[0]?.text || '';
            document.getElementById('infoPeriodo').textContent = mes + ' ' + config.anioSeleccionado;
        } else {
            document.getElementById('infoPeriodo').textContent = 'No aplica';
        }
    }

    // Validar configuración
    function validarConfiguracion() {
        if (!configuracionSistema.cuentasBasicas?.configuradas) {
            mostrarAdvertencia('La configuración de cuentas básicas no está completa');
        }
    }

    // Validar configuración de tipo de libro
    function validarConfiguracionTipoLibro() {
        if (config.tipoLibroSeleccionado) {
            fetch('/SeleccionLibrosDocs/ValidarConfiguracion', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ tipoLibro: config.tipoLibroSeleccionado })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    if (!data.esValida) {
                        mostrarError('Configuración requerida no encontrada: ' + data.errores.join(', '));
                    }
                }
            })
            .catch(error => {
                console.error('Error al validar configuración:', error);
            });
        }
    }

    // Procesar selección
    function procesarSeleccion() {
        if (!validarSeleccion()) {
            return;
        }

        mostrarModalConfirmacion();
    }

    // Validar selección
    function validarSeleccion() {
        const tipoLibro = document.querySelector('input[name="tipoLibro"]:checked');
        if (!tipoLibro) {
            mostrarError('Debe seleccionar un tipo de libro');
            return false;
        }

        if (config.incluirPeriodo) {
            const mes = document.getElementById('mes')?.value;
            const anio = document.getElementById('anio')?.value;
            if (!mes || !anio) {
                mostrarError('Debe seleccionar un período');
                return false;
            }
        }

        return true;
    }

    // Mostrar modal de confirmación
    function mostrarModalConfirmacion() {
        const opcion = opcionesLibros.find(o => o.id === config.tipoLibroSeleccionado);
        const detalles = document.getElementById('detallesSeleccion');
        
        if (detalles && opcion) {
            detalles.innerHTML = `
                <div class="alert alert-info">
                    <strong>Tipo de Libro:</strong> ${opcion.nombre}<br>
                    <strong>Descripción:</strong> ${opcion.descripcion}<br>
                    ${config.incluirPeriodo ? `<strong>Período:</strong> ${document.getElementById('mes')?.selectedOptions[0]?.text} ${config.anioSeleccionado}<br>` : ''}
                    <strong>Formulario Destino:</strong> ${opcion.formularioDestino}
                </div>
            `;
        }

        const modal = new bootstrap.Modal(document.getElementById('modalConfirmacion'));
        modal.show();
    }

    // Confirmar selección
    function confirmarSeleccion() {
        const seleccion = {
            tipoLibro: config.tipoLibroSeleccionado,
            mes: config.incluirPeriodo ? config.mesSeleccionado : null,
            anio: config.incluirPeriodo ? config.anioSeleccionado : null,
            incluirPeriodo: config.incluirPeriodo,
            incluirTodos: config.incluirTodos,
            modoOperacion: 'editar'
        };

        mostrarCarga();

        fetch('/SeleccionLibrosDocs/Seleccionar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(seleccion)
        })
        .then(response => response.json())
        .then(data => {
            ocultarCarga();
            
            if (data.success) {
                // Navegar a la URL especificada
                if (data.urlNavegacion) {
                    window.location.href = data.urlNavegacion;
                } else {
                    mostrarError('No se pudo determinar la URL de navegación');
                }
            } else {
                mostrarError(data.message || 'Error al procesar la selección');
            }
        })
        .catch(error => {
            ocultarCarga();
            console.error('Error al procesar selección:', error);
            mostrarError('Error al procesar la selección');
        });
    }

    // Cancelar selección
    function cancelarSeleccion() {
        if (confirm('¿Está seguro de que desea cancelar la selección?')) {
            window.history.back();
        }
    }

    // Mostrar carga
    function mostrarCarga() {
        const modal = new bootstrap.Modal(document.getElementById('modalCarga'));
        modal.show();
    }

    // Ocultar carga
    function ocultarCarga() {
        const modal = bootstrap.Modal.getInstance(document.getElementById('modalCarga'));
        if (modal) {
            modal.hide();
        }
    }

    // Mostrar error
    function mostrarError(mensaje) {
        document.getElementById('mensajeError').textContent = mensaje;
        const modal = new bootstrap.Modal(document.getElementById('modalError'));
        modal.show();
    }

    // Mostrar advertencia
    function mostrarAdvertencia(mensaje) {
        // Crear alerta temporal
        const alerta = document.createElement('div');
        alerta.className = 'alert alert-warning alert-dismissible fade show position-fixed';
        alerta.style.top = '20px';
        alerta.style.right = '20px';
        alerta.style.zIndex = '9999';
        alerta.innerHTML = `
            <i class="fas fa-exclamation-triangle me-2"></i>
            ${mensaje}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(alerta);
        
        // Auto-remover después de 5 segundos
        setTimeout(() => {
            if (alerta.parentNode) {
                alerta.parentNode.removeChild(alerta);
            }
        }, 5000);
    }

    // Obtener estadísticas
    function obtenerEstadisticas(tipoLibro, mes, anio) {
        let url = '/SeleccionLibrosDocs/GetEstadisticasLibros?';
        if (tipoLibro) url += 'tipoLibro=' + tipoLibro + '&';
        if (mes) url += 'mes=' + mes + '&';
        if (anio) url += 'anio=' + anio + '&';
        
        fetch(url)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    actualizarEstadisticas(data.estadisticas);
                }
            })
            .catch(error => {
                console.error('Error al obtener estadísticas:', error);
            });
    }

    // Actualizar estadísticas
    function actualizarEstadisticas(estadisticas) {
        // Aquí se pueden actualizar las estadísticas en la UI
        console.log('Estadísticas:', estadisticas);
    }

    // API pública
    return {
        init: init,
        obtenerEstadisticas: obtenerEstadisticas
    };
})();









