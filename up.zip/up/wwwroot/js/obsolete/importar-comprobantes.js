$(document).ready(function() {
    // Variables globales
    let archivoSeleccionado = null;
    let rutaArchivo = null;
    let importId = null;
    let progressInterval = null;
    let mesSeleccionado = $('#cbMes').val();
    let anoSeleccionado = $('#txAno').val();

    // Inicializar
    inicializar();

    function inicializar() {
        configurarEventos();
        verificarEstadoMes();
    }

    function configurarEventos() {
        // Selección de archivo
        $('#archivoImportar').change(handleFileSelect);
        $('#btnSeleccionarArchivo').click(() => $('#archivoImportar').click());

        // Cambio de mes
        $('#cbMes').change(function() {
            mesSeleccionado = $(this).val();
            verificarEstadoMes();
        });

        // Botones principales
        $('#btnImportar').click(confirmarImportacion);
        $('#btnCancelar').click(cancelarImportacion);
        $('#btnVerFormato').click(mostrarFormato);
        $('#btnDescargarPlantilla').click(descargarPlantilla);
        $('#btnDescargarPlantillaModal').click(descargarPlantilla);

        // Confirmación de importación
        $('#btnConfirmarImportacion').click(ejecutarImportacion);
    }

    function handleFileSelect(event) {
        const archivo = event.target.files[0];
        if (!archivo) return;

        // Validar archivo
        if (!archivo.name.endsWith('.txt')) {
            mostrarError('El archivo debe ser de tipo .txt');
            return;
        }

        if (archivo.size === 0) {
            mostrarError('El archivo está vacío');
            return;
        }

        if (archivo.size > 10 * 1024 * 1024) {
            mostrarError('El archivo es demasiado grande (máximo 10MB)');
            return;
        }

        // Subir archivo
        subirArchivo(archivo);
    }

    function subirArchivo(archivo) {
        const formData = new FormData();
        formData.append('archivo', archivo);

        mostrarCargando('Validando archivo...');

        $.ajax({
            url: '/ImportarComprobantes/SelectFile',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                if (response.success) {
                    archivoSeleccionado = archivo;
                    rutaArchivo = response.filePath;
                    mostrarInfoArchivo(response.fileName, response.recordCount);
                    validarArchivo();
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al subir archivo');
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function validarArchivo() {
        if (!rutaArchivo) return;

        $.ajax({
            url: '/ImportarComprobantes/ValidateFile',
            type: 'POST',
            data: JSON.stringify({
                filePath: rutaArchivo,
                mes: parseInt(mesSeleccionado),
                ano: parseInt(anoSeleccionado)
            }),
            contentType: 'application/json',
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                mostrarValidacionArchivo(response);
                if (response.success) {
                    $('#btnImportar').prop('disabled', false);
                } else {
                    $('#btnImportar').prop('disabled', true);
                }
            },
            error: function() {
                mostrarError('Error al validar archivo');
            }
        });
    }

    function mostrarValidacionArchivo(response) {
        const container = $('#validacionArchivo');
        container.show();

        let html = '<div class="alert alert-' + (response.success ? 'success' : 'danger') + '">';
        html += '<h6><i class="fas fa-' + (response.success ? 'check-circle' : 'exclamation-circle') + '"></i> ';
        html += response.success ? 'Archivo válido' : 'Archivo con errores';
        html += '</h6>';
        html += '<p>' + response.message + '</p>';

        if (response.errors && response.errors.length > 0) {
            html += '<ul class="mb-0">';
            response.errors.forEach(error => {
                html += '<li>' + error + '</li>';
            });
            html += '</ul>';
        }

        if (response.warnings && response.warnings.length > 0) {
            html += '<div class="mt-2"><strong>Advertencias:</strong><ul class="mb-0">';
            response.warnings.forEach(warning => {
                html += '<li>' + warning + '</li>';
            });
            html += '</ul></div>';
        }

        html += '</div>';
        container.html(html);
    }

    function mostrarInfoArchivo(fileName, recordCount) {
        const info = $('#infoArchivo');
        info.html(`
            <div class="d-flex align-items-center">
                <i class="fas fa-file-text text-success mr-2"></i>
                <div>
                    <strong>${fileName}</strong><br>
                    <small class="text-muted">${recordCount} registros encontrados</small>
                </div>
            </div>
        `);
    }

    function verificarEstadoMes() {
        $.ajax({
            url: `/ImportarComprobantes/IsMesAbierto/${mesSeleccionado}/${anoSeleccionado}`,
            type: 'GET',
            success: function(response) {
                if (response.success) {
                    const estado = response.isAbierto ? 'abierto' : 'cerrado';
                    const clase = response.isAbierto ? 'success' : 'danger';
                    const icono = response.isAbierto ? 'check-circle' : 'times-circle';
                    
                    $('#estadoMes').html(`
                        <i class="fas fa-${icono}"></i>
                        El mes está <strong class="text-${clase}">${estado}</strong> para importación
                    `);
                }
            },
            error: function() {
                $('#estadoMes').html('<i class="fas fa-exclamation-triangle"></i> Error al verificar estado del mes');
            }
        });
    }

    function confirmarImportacion() {
        if (!archivoSeleccionado) {
            mostrarError('Debe seleccionar un archivo');
            return;
        }

        const mensaje = `Se importará el archivo: ${archivoSeleccionado.name}\n\n¿Desea continuar?`;
        $('#mensajeConfirmacion').text(mensaje);
        $('#modalConfirmar').modal('show');
    }

    function ejecutarImportacion() {
        $('#modalConfirmar').modal('hide');
        
        if (!rutaArchivo) {
            mostrarError('No hay archivo seleccionado');
            return;
        }

        mostrarCargando('Iniciando importación...');
        $('#btnImportar').prop('disabled', true);
        $('#btnCancelar').prop('disabled', false).show();

        $.ajax({
            url: '/ImportarComprobantes/Import',
            type: 'POST',
            data: JSON.stringify({
                filePath: rutaArchivo,
                mes: parseInt(mesSeleccionado),
                ano: parseInt(anoSeleccionado)
            }),
            contentType: 'application/json',
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                if (response.success) {
                    importId = response.importId;
                    iniciarSeguimientoProgreso();
                    mostrarExito('Importación iniciada correctamente');
                } else {
                    mostrarError(response.message);
                    $('#btnImportar').prop('disabled', false);
                    $('#btnCancelar').prop('disabled', true).hide();
                }
            },
            error: function() {
                mostrarError('Error al iniciar importación');
                $('#btnImportar').prop('disabled', false);
                $('#btnCancelar').prop('disabled', true).hide();
            },
            complete: function() {
                ocultarCargando();
            }
        });
    }

    function iniciarSeguimientoProgreso() {
        if (progressInterval) {
            clearInterval(progressInterval);
        }

        progressInterval = setInterval(function() {
            if (!importId) return;

            $.ajax({
                url: `/ImportarComprobantes/GetProgress/${importId}`,
                type: 'GET',
                success: function(response) {
                    if (response.success) {
                        actualizarProgreso(response.progress);
                        
                        if (response.isComplete) {
                            clearInterval(progressInterval);
                            mostrarResultados(response);
                            finalizarImportacion();
                        }
                    }
                },
                error: function() {
                    clearInterval(progressInterval);
                    mostrarError('Error al obtener progreso de importación');
                    finalizarImportacion();
                }
            });
        }, 1000);
    }

    function actualizarProgreso(progress) {
        $('#lbProceso').text(progress.message);
        $('#progressContainer').show();
        $('#progressBar').css('width', progress.progress + '%');
        $('#progressText').text(progress.progress + '%');
    }

    function mostrarResultados(progress) {
        const container = $('#resultadosContainer');
        const resultados = $('#resultadosImportacion');
        
        let html = '<div class="row">';
        html += '<div class="col-md-4"><div class="card bg-success text-white"><div class="card-body text-center">';
        html += '<h4>' + progress.importedCount + '</h4><p>Registros Importados</p></div></div></div>';
        html += '<div class="col-md-4"><div class="card bg-danger text-white"><div class="card-body text-center">';
        html += '<h4>' + progress.errorCount + '</h4><p>Errores</p></div></div></div>';
        html += '<div class="col-md-4"><div class="card bg-info text-white"><div class="card-body text-center">';
        html += '<h4>' + progress.totalCount + '</h4><p>Total Registros</p></div></div></div>';
        html += '</div>';

        if (progress.errors && progress.errors.length > 0) {
            html += '<div class="mt-3"><h6>Errores encontrados:</h6><ul class="list-group">';
            progress.errors.forEach(error => {
                html += '<li class="list-group-item">' + error + '</li>';
            });
            html += '</ul></div>';
        }

        resultados.html(html);
        container.show();
    }

    function finalizarImportacion() {
        $('#btnImportar').prop('disabled', false);
        $('#btnCancelar').prop('disabled', true).hide();
        $('#progressContainer').hide();
        $('#lbProceso').text('Importación completada');
        
        // Limpiar selección
        archivoSeleccionado = null;
        rutaArchivo = null;
        importId = null;
        $('#archivoImportar').val('');
        $('#infoArchivo').html('<i class="fas fa-file"></i> No se ha seleccionado ningún archivo');
        $('#validacionArchivo').hide();
    }

    function cancelarImportacion() {
        if (!importId) return;

        $.ajax({
            url: `/ImportarComprobantes/CancelImport/${importId}`,
            type: 'POST',
            headers: {
                'RequestVerificationToken': $('input[name="__RequestVerificationToken"]').val()
            },
            success: function(response) {
                if (response.success) {
                    mostrarInfo('Importación cancelada');
                    finalizarImportacion();
                } else {
                    mostrarError(response.message);
                }
            },
            error: function() {
                mostrarError('Error al cancelar importación');
            }
        });
    }

    function mostrarFormato() {
        $.ajax({
            url: '/ImportarComprobantes/GetFormat',
            type: 'GET',
            success: function(response) {
                $('#contenidoFormato').html(response);
                $('#modalFormato').modal('show');
            },
            error: function() {
                mostrarError('Error al cargar formato');
            }
        });
    }

    function descargarPlantilla() {
        window.location.href = '/ImportarComprobantes/DownloadTemplate';
    }

    function mostrarCargando(mensaje) {
        // Implementar indicador de carga
        console.log('Cargando: ' + mensaje);
    }

    function ocultarCargando() {
        // Ocultar indicador de carga
        console.log('Carga completada');
    }

    function mostrarError(mensaje) {
        toastr.error(mensaje);
    }

    function mostrarExito(mensaje) {
        toastr.success(mensaje);
    }

    function mostrarInfo(mensaje) {
        toastr.info(mensaje);
    }
});

