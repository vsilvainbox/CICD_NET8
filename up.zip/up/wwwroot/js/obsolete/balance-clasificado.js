/**
 * JavaScript para el balance clasificado
 */

document.addEventListener('DOMContentLoaded', function() {
    const filtrosForm = document.getElementById('filtrosForm');
    const balanceTable = document.getElementById('balanceTable');
    const selectAllCheckbox = document.getElementById('selectAll');
    const rowCheckboxes = document.querySelectorAll('.row-checkbox');
    const btnVerLibroMayor = document.getElementById('btnVerLibroMayor');
    const btnSumarMovimientos = document.getElementById('btnSumarMovimientos');
    const btnVistaPrevia = document.getElementById('btnVistaPrevia');
    const btnExportarExcel = document.getElementById('btnExportarExcel');
    const btnImprimir = document.getElementById('btnImprimir');
    const btnEmail = document.getElementById('btnEmail');
    const sumaModal = new bootstrap.Modal(document.getElementById('sumaModal'));
    
    let selectedRows = new Set();
    let currentRow = null;

    // Inicialización
    inicializar();

    function inicializar() {
        // Configurar date pickers
        configurarDatePickers();
        
        // Configurar eventos de la tabla
        configurarEventosTabla();
        
        // Configurar eventos de botones
        configurarEventosBotones();
        
        // Configurar eventos de checkboxes
        configurarEventosCheckboxes();
    }

    function configurarDatePickers() {
        // Configurar date picker para fecha desde
        const fechaDesdeInput = document.querySelector('input[name="Filtros.FechaDesde"]');
        const btnFechaDesde = document.getElementById('btnFechaDesde');
        
        if (fechaDesdeInput && btnFechaDesde) {
            btnFechaDesde.addEventListener('click', function() {
                mostrarDatePicker(fechaDesdeInput);
            });
        }

        // Configurar date picker para fecha hasta
        const fechaHastaInput = document.querySelector('input[name="Filtros.FechaHasta"]');
        const btnFechaHasta = document.getElementById('btnFechaHasta');
        
        if (fechaHastaInput && btnFechaHasta) {
            btnFechaHasta.addEventListener('click', function() {
                mostrarDatePicker(fechaHastaInput);
            });
        }
    }

    function mostrarDatePicker(input) {
        // Implementar date picker simple
        const fecha = prompt('Ingrese la fecha (dd/mm/aaaa):', input.value);
        if (fecha && validarFecha(fecha)) {
            input.value = fecha;
        }
    }

    function validarFecha(fecha) {
        const regex = /^\d{2}\/\d{2}\/\d{4}$/;
        if (!regex.test(fecha)) return false;
        
        const [dia, mes, año] = fecha.split('/').map(Number);
        const fechaObj = new Date(año, mes - 1, dia);
        
        return fechaObj.getDate() === dia && 
               fechaObj.getMonth() === mes - 1 && 
               fechaObj.getFullYear() === año;
    }

    function configurarEventosTabla() {
        if (!balanceTable) return;

        // Configurar eventos de filas
        const filas = balanceTable.querySelectorAll('tbody tr');
        filas.forEach(fila => {
            fila.addEventListener('click', function(e) {
                // No seleccionar si se hace clic en checkbox
                if (e.target.type === 'checkbox') return;
                
                // No seleccionar si es total o subtotal
                if (this.classList.contains('table-warning') || this.classList.contains('table-light')) return;
                
                seleccionarFila(this);
            });

            fila.addEventListener('dblclick', function(e) {
                // No navegar si se hace clic en checkbox
                if (e.target.type === 'checkbox') return;
                
                // No navegar si es total o subtotal
                if (this.classList.contains('table-warning') || this.classList.contains('table-light')) return;
                
                verLibroMayor(this);
            });
        });
    }

    function configurarEventosBotones() {
        if (btnVerLibroMayor) {
            btnVerLibroMayor.addEventListener('click', function() {
                if (currentRow) {
                    verLibroMayor(currentRow);
                }
            });
        }

        if (btnSumarMovimientos) {
            btnSumarMovimientos.addEventListener('click', function() {
                sumarMovimientos();
            });
        }

        if (btnVistaPrevia) {
            btnVistaPrevia.addEventListener('click', function() {
                generarVistaPrevia();
            });
        }

        if (btnExportarExcel) {
            btnExportarExcel.addEventListener('click', function() {
                exportarExcel();
            });
        }

        if (btnImprimir) {
            btnImprimir.addEventListener('click', function() {
                imprimir();
            });
        }

        if (btnEmail) {
            btnEmail.addEventListener('click', function() {
                enviarEmail();
            });
        }
    }

    function configurarEventosCheckboxes() {
        // Checkbox "Seleccionar todo"
        if (selectAllCheckbox) {
            selectAllCheckbox.addEventListener('change', function() {
                const checked = this.checked;
                rowCheckboxes.forEach(checkbox => {
                    checkbox.checked = checked;
                    if (checked) {
                        selectedRows.add(parseInt(checkbox.value));
                    } else {
                        selectedRows.delete(parseInt(checkbox.value));
                    }
                });
                actualizarBotones();
            });
        }

        // Checkboxes individuales
        rowCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const idCuenta = parseInt(this.value);
                if (this.checked) {
                    selectedRows.add(idCuenta);
                } else {
                    selectedRows.delete(idCuenta);
                }
                actualizarCheckboxSelectAll();
                actualizarBotones();
            });
        });
    }

    function seleccionarFila(fila) {
        // Remover selección anterior
        const filasSeleccionadas = balanceTable.querySelectorAll('tbody tr.table-active');
        filasSeleccionadas.forEach(f => f.classList.remove('table-active'));

        // Seleccionar nueva fila
        fila.classList.add('table-active');
        currentRow = fila;

        // Habilitar botón de ver libro mayor
        if (btnVerLibroMayor) {
            btnVerLibroMayor.disabled = false;
        }
    }

    function verLibroMayor(fila) {
        const idCuenta = fila.dataset.idCuenta;
        if (!idCuenta) return;

        const fechaDesde = document.querySelector('input[name="Filtros.FechaDesde"]').value;
        const fechaHasta = document.querySelector('input[name="Filtros.FechaHasta"]').value;
        const tipoAjuste = document.querySelector('select[name="Filtros.TipoAjuste"]').value;

        const url = `/BalanceClasificado/VerLibroMayor?idCuenta=${idCuenta}&fechaDesde=${fechaDesde}&fechaHasta=${fechaHasta}&tipoAjuste=${tipoAjuste}`;
        window.location.href = url;
    }

    function sumarMovimientos() {
        if (selectedRows.size === 0) {
            mostrarAlerta('Seleccione al menos una cuenta para sumar sus movimientos.', 'warning');
            return;
        }

        const fechaDesde = document.querySelector('input[name="Filtros.FechaDesde"]').value;
        const fechaHasta = document.querySelector('input[name="Filtros.FechaHasta"]').value;
        const tipoAjuste = document.querySelector('select[name="Filtros.TipoAjuste"]').value;

        const request = {
            IdsCuentas: Array.from(selectedRows),
            FechaDesde: fechaDesde,
            FechaHasta: fechaHasta,
            TipoAjuste: tipoAjuste ? parseInt(tipoAjuste) : null
        };

        fetch('/BalanceClasificado/SumarMovimientos', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(request)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                mostrarSumaMovimientos(data);
            } else {
                mostrarAlerta(data.message, 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            mostrarAlerta('Error al sumar movimientos', 'error');
        });
    }

    function mostrarSumaMovimientos(data) {
        document.getElementById('totalDebe').textContent = data.totalDebe.toLocaleString('es-CL', { minimumFractionDigits: 2 });
        document.getElementById('totalHaber').textContent = data.totalHaber.toLocaleString('es-CL', { minimumFractionDigits: 2 });
        document.getElementById('saldoNeto').textContent = data.saldo.toLocaleString('es-CL', { minimumFractionDigits: 2 });
        document.getElementById('infoSuma').textContent = `${data.cantidadCuentas} cuenta(s) seleccionada(s)`;
        
        sumaModal.show();
    }

    function generarVistaPrevia() {
        const request = obtenerFiltrosActuales();
        
        fetch('/BalanceClasificado/VistaPrevia', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(request)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Implementar vista previa
                mostrarAlerta('Vista previa generada exitosamente', 'success');
            } else {
                mostrarAlerta(data.message, 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            mostrarAlerta('Error al generar vista previa', 'error');
        });
    }

    function exportarExcel() {
        const request = obtenerFiltrosActuales();
        
        fetch('/BalanceClasificado/ExportarExcel', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(request)
        })
        .then(response => {
            if (response.ok) {
                return response.blob();
            }
            throw new Error('Error al exportar Excel');
        })
        .then(blob => {
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `BalanceClasificado_${request.fechaDesde}_${request.fechaHasta}.xlsx`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
        })
        .catch(error => {
            console.error('Error:', error);
            mostrarAlerta('Error al exportar Excel', 'error');
        });
    }

    function imprimir() {
        window.print();
    }

    function enviarEmail() {
        mostrarAlerta('Funcionalidad de envío por email en desarrollo', 'info');
    }

    function obtenerFiltrosActuales() {
        return {
            FechaDesde: document.querySelector('input[name="Filtros.FechaDesde"]').value,
            FechaHasta: document.querySelector('input[name="Filtros.FechaHasta"]').value,
            TipoAjuste: document.querySelector('select[name="Filtros.TipoAjuste"]').value ? parseInt(document.querySelector('select[name="Filtros.TipoAjuste"]').value) : null,
            AreaNegocio: document.querySelector('select[name="Filtros.AreaNegocio"]').value ? parseInt(document.querySelector('select[name="Filtros.AreaNegocio"]').value) : null,
            CentroCosto: document.querySelector('select[name="Filtros.CentroCosto"]').value ? parseInt(document.querySelector('select[name="Filtros.CentroCosto"]').value) : null,
            Nivel: document.querySelector('select[name="Filtros.Nivel"]').value ? parseInt(document.querySelector('select[name="Filtros.Nivel"]').value) : null,
            LibroOficial: document.querySelector('input[name="Filtros.LibroOficial"]').checked,
            VerSubTotales: document.querySelector('input[name="Filtros.VerSubTotales"]').checked,
            VerCodigoCuenta: document.querySelector('input[name="Filtros.VerCodigoCuenta"]').checked,
            ModoMensual: false,
            ModoComparativo: false
        };
    }

    function actualizarCheckboxSelectAll() {
        if (!selectAllCheckbox) return;
        
        const totalCheckboxes = rowCheckboxes.length;
        const checkedCheckboxes = document.querySelectorAll('.row-checkbox:checked').length;
        
        selectAllCheckbox.checked = totalCheckboxes > 0 && checkedCheckboxes === totalCheckboxes;
        selectAllCheckbox.indeterminate = checkedCheckboxes > 0 && checkedCheckboxes < totalCheckboxes;
    }

    function actualizarBotones() {
        if (btnSumarMovimientos) {
            btnSumarMovimientos.disabled = selectedRows.size === 0;
        }
    }

    function mostrarAlerta(mensaje, tipo) {
        const alertClass = tipo === 'error' ? 'alert-danger' : 
                          tipo === 'warning' ? 'alert-warning' : 
                          tipo === 'success' ? 'alert-success' : 'alert-info';
        
        const iconClass = tipo === 'error' ? 'fas fa-exclamation-triangle' : 
                         tipo === 'warning' ? 'fas fa-exclamation-triangle' : 
                         tipo === 'success' ? 'fas fa-check-circle' : 'fas fa-info-circle';
        
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert ${alertClass} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            <i class="${iconClass} me-2"></i>
            ${mensaje}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;
        
        const cardBody = document.querySelector('.card-body');
        cardBody.insertBefore(alertDiv, cardBody.firstChild);
        
        // Auto-dismiss después de 5 segundos
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.remove();
            }
        }, 5000);
    }

    // Exponer funciones globalmente si es necesario
    window.BalanceClasificado = {
        sumarMovimientos,
        generarVistaPrevia,
        exportarExcel,
        imprimir,
        enviarEmail
    };
});









