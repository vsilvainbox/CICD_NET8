/**
 * Funcionalidad de búsqueda del menú lateral
 * Sistema de Contabilidad HyperContabilidad
 */

document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('menu-search-input');

    if (!searchInput) {
        console.warn('[MenuSearch] Input de búsqueda no encontrado');
        return;
    }

    // Debounce para optimizar la búsqueda
    let debounceTimer;
    const debounceDelay = 300; // ms

    searchInput.addEventListener('input', function(e) {
        clearTimeout(debounceTimer);

        debounceTimer = setTimeout(() => {
            const query = e.target.value.toLowerCase().trim();
            filterMenu(query);
        }, debounceDelay);
    });

    // Atajo de teclado Cmd/Ctrl + K
    document.addEventListener('keydown', function(e) {
        if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
            e.preventDefault();
            searchInput.focus();
            searchInput.select();
        }

        // ESC para limpiar búsqueda
        if (e.key === 'Escape' && searchInput.value) {
            searchInput.value = '';
            filterMenu('');
            searchInput.blur();
        }
    });

    function filterMenu(query) {
        const nav = document.querySelector('nav[x-data]');
        if (!nav) return;

        const allItems = nav.querySelectorAll('[data-menu-item]');
        const allSections = nav.querySelectorAll('[data-menu-section]');

        if (query === '') {
            // Mostrar todo
            allItems.forEach(item => {
                item.style.display = '';
            });
            allSections.forEach(section => {
                section.style.display = '';
            });

            console.log(`[MenuSearch] Búsqueda limpiada - ${allItems.length} items visibles`);
            return;
        }

        // Ocultar todo primero
        allItems.forEach(item => {
            item.style.display = 'none';
        });
        allSections.forEach(section => {
            section.style.display = 'none';
        });

        let matchCount = 0;
        const expandedSections = new Set();

        // Mostrar solo coincidencias
        allItems.forEach(item => {
            const text = item.getAttribute('data-menu-item').toLowerCase();

            if (text.includes(query)) {
                item.style.display = '';
                matchCount++;

                // Mostrar la sección padre
                const parentSection = item.closest('[data-menu-section]');
                if (parentSection) {
                    parentSection.style.display = '';
                    const sectionName = parentSection.getAttribute('data-menu-section');
                    if (sectionName) {
                        expandedSections.add(sectionName);
                    }
                }
            }
        });

        // Auto-expandir secciones que tengan coincidencias
        if (window.Alpine) {
            expandedSections.forEach(sectionName => {
                // Intentar acceder al componente Alpine
                const sectionElement = nav.querySelector(`[data-menu-section="${sectionName}"]`);
                if (sectionElement) {
                    // Trigger Alpine.js para expandir
                    const expandEvent = new CustomEvent('expand-section', {
                        detail: { section: sectionName }
                    });
                    nav.dispatchEvent(expandEvent);
                }
            });
        }

        console.log(`[MenuSearch] Búsqueda: "${query}" - ${matchCount} resultados - ${expandedSections.size} secciones expandidas`);

        // Mostrar mensaje si no hay resultados
        showNoResultsMessage(matchCount, query);
    }

    function showNoResultsMessage(matchCount, query) {
        const nav = document.querySelector('nav[x-data]');
        if (!nav) return;

        // Eliminar mensaje anterior
        const existingMessage = nav.querySelector('#no-results-message');
        if (existingMessage) {
            existingMessage.remove();
        }

        if (matchCount === 0 && query !== '') {
            const message = document.createElement('div');
            message.id = 'no-results-message';
            message.className = 'px-4 py-8 text-center';
            message.innerHTML = `
                <svg class="mx-auto h-12 w-12 text-gray-400 dark:text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p class="mt-4 text-sm text-gray-500 dark:text-gray-400">
                    No se encontraron resultados para <strong>"${escapeHtml(query)}"</strong>
                </p>
                <p class="mt-2 text-xs text-gray-400 dark:text-gray-500">
                    Intenta con otros términos de búsqueda
                </p>
            `;

            const menuGroup = nav.querySelector('.flex.flex-col.gap-2.mb-6');
            if (menuGroup) {
                menuGroup.appendChild(message);
            }
        }
    }

    function escapeHtml(text) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, m => map[m]);
    }

    console.log('[MenuSearch] Inicializado correctamente');
});
