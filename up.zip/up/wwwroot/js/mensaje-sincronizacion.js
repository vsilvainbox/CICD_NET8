/**
 * Componente JavaScript reutilizable para postergación de sincronizaciones SII
 * Replica funcionalidad de FrmMsgSincronizacion.frm de VB6
 *
 * IMPORTANTE: Requiere configuración de endpoints en la vista:
 *
 *   <script>
 *       window.MENSAJE_SINCRONIZACION_ENDPOINTS = {
 *           actualizarContador: '@Url.Action("ActualizarContador", "MensajeSincronizacion")',
 *           actualizarMultiple: '@Url.Action("ActualizarContadorMultiple", "MensajeSincronizacion")'
 *       };
 *   </script>
 *   <script src="~/js/mensaje-sincronizacion.js"></script>
 *
 * Uso desde cualquier feature:
 *
 *   // Opción 1: Para una sola sincronización
 *   mostrarMensajeSincronizacion(idSincronizacion, function(resultado) {
 *       if (resultado.confirmado) {
 *           console.log('Se postergó ' + resultado.horasRetraso + ' horas');
 *           // Actualizar UI, recargar datos, etc.
 *       }
 *   });
 *
 *   // Opción 2: Para múltiples sincronizaciones
 *   mostrarMensajeSincronizacionMultiple([id1, id2, id3], function(resultado) {
 *       if (resultado.confirmado) {
 *           console.log('Se postergaron ' + resultado.sincronizacionesActualizadas + ' sincronizaciones');
 *       }
 *   });
 *
 * Replica exactamente el comportamiento del VB6:
 * - ComboBox con horas de 1 a 24
 * - Botones Aceptar y Cancelar
 * - Pregunta "¿Está Seguro?"
 * - Si acepta: HoraSeleccionada = cmbHora.ListIndex + 1
 * - Si cancela: HoraSeleccionada = 1 (default)
 */

// Validar que los endpoints estén configurados
if (typeof window.MENSAJE_SINCRONIZACION_ENDPOINTS === 'undefined') {
    console.error('ERROR: window.MENSAJE_SINCRONIZACION_ENDPOINTS no está definido. Ver documentación en mensaje-sincronizacion.js');
}

/**
 * Muestra el modal de postergación de sincronización (una sola)
 * Replica: FrmMsgSincronizacion.Show vbModal
 * 
 * @param {number} idSincronizacion - ID de la sincronización a postergar
 * @param {function} callback - Función llamada al cerrar: callback({ confirmado: bool, horasRetraso: int })
 */
window.mostrarMensajeSincronizacion = function(idSincronizacion, callback) {
    // Crear opciones del select (replica: For i = 1 To 24)
    let opcionesHoras = '';
    for (let i = 1; i <= 24; i++) {
        opcionesHoras += `<option value="${i}">${i}</option>`;
    }

    Swal.fire({
        title: 'Sincronización SII (Compras, Ventas y Retenciones)',
        html: `
            <div class="text-left space-y-4">
                <div class="flex items-center space-x-2">
                    <i class="fas fa-info-circle text-blue-600 text-2xl"></i>
                    <p class="text-sm text-gray-700">Sincronización se efectuará en</p>
                    <select id="swal-horas-sincro" class="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 text-base">
                        ${opcionesHoras}
                    </select>
                    <span class="text-sm text-gray-700">horas más</span>
                </div>
                <div class="mt-4 text-center">
                    <p class="text-lg font-semibold text-gray-900">¿Está Seguro?</p>
                </div>
            </div>
        `,
        icon: null,
        showCancelButton: true,
        confirmButtonColor: '#d64000',
        cancelButtonColor: '#6b7280',
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        customClass: {
            container: 'mensaje-sincronizacion-modal'
        },
        didOpen: () => {
            // Establecer valor inicial = 1 (replica: cmbHora.ListIndex = 0)
            document.getElementById('swal-horas-sincro').value = '1';
        }
    }).then((result) => {
        if (result.isConfirmed) {
            // Replica: HoraSeleccionada = cmbHora.ListIndex + 1
            const horasSeleccionadas = parseInt(document.getElementById('swal-horas-sincro').value);

            // Llamar MVC Controller proxy para actualizar contador
            // Replica: UPDATE ConfiguraSincronizacionSII SET Contador=X WHERE id=Y
            // Usa endpoint configurado en window.MENSAJE_SINCRONIZACION_ENDPOINTS
            const endpoint = window.MENSAJE_SINCRONIZACION_ENDPOINTS?.actualizarContador;
            if (!endpoint) {
                console.error('ERROR: MENSAJE_SINCRONIZACION_ENDPOINTS.actualizarContador no configurado');
                Swal.fire({
                    icon: 'error',
                    title: 'Error de Configuración',
                    text: 'Los endpoints de sincronización no están configurados correctamente',
                    confirmButtonColor: '#d64000'
                });
                return;
            }

            fetch(endpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    idSincronizacion: idSincronizacion,
                    horasRetraso: horasSeleccionadas
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Sincronización Postergada',
                        text: data.message,
                        confirmButtonColor: '#d64000'
                    });

                    // Callback con resultado exitoso
                    if (callback) {
                        callback({
                            confirmado: true,
                            horasRetraso: horasSeleccionadas,
                            idSincronizacion: idSincronizacion
                        });
                    }
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: data.message || 'Error al actualizar la sincronización',
                        confirmButtonColor: '#d64000'
                    });

                    // Callback con error
                    if (callback) {
                        callback({
                            confirmado: false,
                            error: data.message
                        });
                    }
                }
            })
            .catch(error => {
                console.error('Error al actualizar contador:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Error de Comunicación',
                    text: 'No se pudo conectar con el servidor',
                    confirmButtonColor: '#d64000'
                });

                // Callback con error de red
                if (callback) {
                    callback({
                        confirmado: false,
                        error: 'Error de red'
                    });
                }
            });

        } else {
            // Usuario canceló (replica: SeleccionAceptada = False)
            // En VB6 cuando cancela, se asigna HoraSeleccionada = 1 por defecto
            if (callback) {
                callback({
                    confirmado: false,
                    horasRetraso: 1,
                    idSincronizacion: idSincronizacion
                });
            }
        }
    });
};

/**
 * Muestra el modal de postergación para múltiples sincronizaciones
 * Replica el loop VB6 que actualiza varias sincronizaciones:
 *   Do While Not Rs.EOF
 *       UPDATE ConfiguraSincronizacionSII SET Contador=X WHERE id=Y
 *       Rs.MoveNext
 *   Loop
 * 
 * @param {number[]} idsSincronizacion - Array de IDs de sincronizaciones
 * @param {function} callback - Función llamada al cerrar
 */
window.mostrarMensajeSincronizacionMultiple = function(idsSincronizacion, callback) {
    if (!Array.isArray(idsSincronizacion) || idsSincronizacion.length === 0) {
        Swal.fire({
            icon: 'warning',
            title: 'Atención',
            text: 'No hay sincronizaciones para postergar',
            confirmButtonColor: '#d64000'
        });
        return;
    }

    // Crear opciones del select
    let opcionesHoras = '';
    for (let i = 1; i <= 24; i++) {
        opcionesHoras += `<option value="${i}">${i}</option>`;
    }

    const cantidadTexto = idsSincronizacion.length === 1 
        ? '1 sincronización' 
        : `${idsSincronizacion.length} sincronizaciones`;

    Swal.fire({
        title: 'Sincronización SII (Compras, Ventas y Retenciones)',
        html: `
            <div class="text-left space-y-4">
                <div class="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <p class="text-sm font-medium text-blue-900">
                        <i class="fas fa-list mr-2"></i>${cantidadTexto} pendiente(s)
                    </p>
                </div>
                <div class="flex items-center space-x-2">
                    <i class="fas fa-info-circle text-blue-600 text-2xl"></i>
                    <p class="text-sm text-gray-700">Todas se efectuarán en</p>
                    <select id="swal-horas-sincro-multi" class="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 text-base">
                        ${opcionesHoras}
                    </select>
                    <span class="text-sm text-gray-700">horas más</span>
                </div>
                <div class="mt-4 text-center">
                    <p class="text-lg font-semibold text-gray-900">¿Está Seguro?</p>
                </div>
            </div>
        `,
        icon: null,
        showCancelButton: true,
        confirmButtonColor: '#d64000',
        cancelButtonColor: '#6b7280',
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        customClass: {
            container: 'mensaje-sincronizacion-modal'
        },
        didOpen: () => {
            document.getElementById('swal-horas-sincro-multi').value = '1';
        }
    }).then((result) => {
        if (result.isConfirmed) {
            const horasSeleccionadas = parseInt(document.getElementById('swal-horas-sincro-multi').value);

            // Llamar MVC Controller proxy para actualizar múltiples contadores
            // Usa endpoint configurado en window.MENSAJE_SINCRONIZACION_ENDPOINTS
            const endpoint = window.MENSAJE_SINCRONIZACION_ENDPOINTS?.actualizarMultiple;
            if (!endpoint) {
                console.error('ERROR: MENSAJE_SINCRONIZACION_ENDPOINTS.actualizarMultiple no configurado');
                Swal.fire({
                    icon: 'error',
                    title: 'Error de Configuración',
                    text: 'Los endpoints de sincronización no están configurados correctamente',
                    confirmButtonColor: '#d64000'
                });
                return;
            }

            fetch(endpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    idsSincronizacion: idsSincronizacion,
                    horasRetraso: horasSeleccionadas
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Sincronizaciones Postergadas',
                        text: data.message,
                        confirmButtonColor: '#d64000'
                    });

                    if (callback) {
                        callback({
                            confirmado: true,
                            horasRetraso: horasSeleccionadas,
                            sincronizacionesActualizadas: data.sincronizacionesActualizadas,
                            idsSincronizacion: idsSincronizacion
                        });
                    }
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: data.message || 'Error al actualizar las sincronizaciones',
                        confirmButtonColor: '#d64000'
                    });

                    if (callback) {
                        callback({
                            confirmado: false,
                            error: data.message
                        });
                    }
                }
            })
            .catch(error => {
                console.error('Error al actualizar contadores:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Error de Comunicación',
                    text: 'No se pudo conectar con el servidor',
                    confirmButtonColor: '#d64000'
                });

                if (callback) {
                    callback({
                        confirmado: false,
                        error: 'Error de red'
                    });
                }
            });

        } else {
            // Usuario canceló
            if (callback) {
                callback({
                    confirmado: false,
                    horasRetraso: 1,
                    idsSincronizacion: idsSincronizacion
                });
            }
        }
    });
};

/**
 * Valida horas de retraso (1-24)
 * Replica validación del combobox VB6
 */
window.validarHorasSincronizacion = function(horas) {
    return horas >= 1 && horas <= 24;
};
