﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class ActFijoFicha
{
    public int IdFicha { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public int? IdActFijo { get; set; }

    public int? IdGrupo { get; set; }

    public double? PrecioFactura { get; set; }

    public double? DerechosIntern { get; set; }

    public double? Transporte { get; set; }

    public double? ObrasAdapt { get; set; }

    public double? PrecioAdquis { get; set; }

    public double? IVARecuperable { get; set; }

    public double? FormacionPers { get; set; }

    public double? ObrasReubic { get; set; }

    public double? TotalGastos { get; set; }

    public int? FechaIncorporacion { get; set; }

    public int? FechaDisponible { get; set; }

    public double? AdquiOtrosConceptos { get; set; }

    public double? GastoOtrosConceptos { get; set; }

    public bool? SinDetComps { get; set; }

    public int? IdFichaOldTmp { get; set; }

    public int? IdFichaOld { get; set; }
}
