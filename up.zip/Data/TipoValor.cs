﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class TipoValor
{
    public int idTValor { get; set; }

    public byte? TipoLib { get; set; }

    public byte? Codigo { get; set; }

    public string? Valor { get; set; }

    public string? Diminutivo { get; set; }

    public string? Atributo { get; set; }

    public bool? Multiple { get; set; }

    public short? CodF29 { get; set; }

    public short? CodF29_Adic { get; set; }

    public string? TipoDoc { get; set; }

    public string? Tit1 { get; set; }

    public string? Tit2 { get; set; }

    public string? CodImpSII { get; set; }

    public short? Orden { get; set; }

    public float? Tasa { get; set; }

    public bool? EsRecuperable { get; set; }

    public string? CodSIIDTE { get; set; }

    public string? TitCompleto { get; set; }

    public byte? TipoIVARetenido { get; set; }
}
