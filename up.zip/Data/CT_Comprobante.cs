﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class CT_Comprobante
{
    public int IdComp { get; set; }

    public int? IdEmpresa { get; set; }

    public int? Correlativo { get; set; }

    public string? Nombre { get; set; }

    public string? Descrip { get; set; }

    public int? Fecha { get; set; }

    public byte? Tipo { get; set; }

    public byte? Estado { get; set; }

    public string? Glosa { get; set; }

    public double? TotalDebe { get; set; }

    public double? TotalHaber { get; set; }

    public int? IdUsuario { get; set; }

    public int? IdCompOld { get; set; }
}
