﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class ActFijoCompsFicha
{
    public int IdCompFicha { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public int? IdActFijo { get; set; }

    public int? IdGrupo { get; set; }

    public int? IdComp { get; set; }

    public float? PjeDivComp { get; set; }

    public double? ValorCompra { get; set; }

    public double? ValorResidual { get; set; }

    public float? PjeAmortizacion { get; set; }

    public short? VidaUtil { get; set; }

    public double? CostosAdicionales { get; set; }

    public float? TasaDesc { get; set; }

    public double? CostoDesmant { get; set; }

    public double? ValActCostoDesmant { get; set; }

    public double? ValorBien { get; set; }

    public double? ValorRazonable_31_12 { get; set; }

    public bool? NoExisteValRazonable { get; set; }

    public double? OtrasDiferencias { get; set; }

    public double? DepAcum { get; set; }

    public double? VidaUtilDep { get; set; }

    public double? ReservaAcum { get; set; }

    public double? DepAcumuladaAnoAnt { get; set; }

    public short? VidaUtilYaDep { get; set; }

    public double? ReservaAcumAnt { get; set; }

    public int? IdCompFichaOldTmp { get; set; }

    public int? IdCompFichaOld { get; set; }

    public double? DepPeriodo { get; set; }

    public double? Factor { get; set; }

    public double? Revalorizacion { get; set; }
}
