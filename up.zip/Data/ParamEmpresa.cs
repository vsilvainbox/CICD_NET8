﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class ParamEmpresa
{
    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public string? Tipo { get; set; }

    public short? Codigo { get; set; }

    public string? Valor { get; set; }

    public string? ValorOld { get; set; }
}
