﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class tmp_CRISTINACASTILL_qc__4304
{
    public int IdCartola { get; set; }

    public int IdDetCartola { get; set; }

    public int? FDesde { get; set; }

    public int? Fecha { get; set; }

    public int? IdMov { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }
}
