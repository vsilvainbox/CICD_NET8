﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class PropIVA_TotMensual
{
    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public short? Mes { get; set; }

    public double? TotalAfecto { get; set; }

    public double? TotalExento { get; set; }
}
