﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class RazonesFin
{
    public int IdRazon { get; set; }

    public short? Tipo { get; set; }

    public bool? RazonFija { get; set; }

    public string? Nombre { get; set; }

    public string? UnidadRes { get; set; }

    public string? TxtNumerador { get; set; }

    public string? TxtDenominador { get; set; }

    public string? Operador { get; set; }

    public string? Glosa { get; set; }
}
