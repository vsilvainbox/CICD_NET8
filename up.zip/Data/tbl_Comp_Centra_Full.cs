﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class tbl_Comp_Centra_Full
{
    public int? IdComp { get; set; }

    public int? IdEmpresa { get; set; }

    public string? Tipo { get; set; }

    public int? Fecha { get; set; }

    public string? ano { get; set; }
}
