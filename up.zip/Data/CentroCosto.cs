﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class CentroCosto
{
    public int IdCCosto { get; set; }

    public int? IdEmpresa { get; set; }

    public string? Codigo { get; set; }

    public string? Descripcion { get; set; }

    public bool? Vigente { get; set; }
}
