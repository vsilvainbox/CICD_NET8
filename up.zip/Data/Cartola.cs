﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Cartola
{
    public int IdCartola { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public int? IdCuentaBco { get; set; }

    public short? Cartola1 { get; set; }

    public int? FDesde { get; set; }

    public int? FHasta { get; set; }

    public double? TotCargo { get; set; }

    public double? TotAbono { get; set; }

    public double? SaldoIni { get; set; }
}
