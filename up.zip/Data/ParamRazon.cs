﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class ParamRazon
{
    public int IdEmpresa { get; set; }

    public int IdRazon { get; set; }

    public int? CantDias { get; set; }
}
