﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Equivalencia
{
    public int? idMoneda { get; set; }

    public int? Fecha { get; set; }

    public double? Valor { get; set; }
}
