﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Socios
{
    public int IdSocio { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public string? RUT { get; set; }

    public string? Nombre { get; set; }

    public float? PjePart { get; set; }

    public double? MontoSuscrito { get; set; }

    public double? MontoPagado { get; set; }

    public int? IdCuentaAportes { get; set; }

    public int? IdCuentaRetiros { get; set; }

    public byte? IdTipoSocio { get; set; }

    public bool? Vigente { get; set; }

    public int? CantAcciones { get; set; }

    public double? MontoIngresadoUsuario { get; set; }

    public double? MontoATraspasar { get; set; }
}
