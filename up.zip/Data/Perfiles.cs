﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Perfiles
{
    public short? IdPerfil { get; set; }

    public string? Nombre { get; set; }

    public int? Privilegios { get; set; }

    public byte? IdApp { get; set; }
}
