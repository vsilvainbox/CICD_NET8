namespace App.Exceptions;

/// <summary>
/// Excepcion para operaciones que requieren confirmacion del usuario.
/// Se usa cuando una operacion puede continuar, pero necesita consentimiento explicito.
/// El middleware devuelve HTTP 409 (Conflict) con los codigos de confirmacion.
///
/// Uso:
///   throw new ConfirmationRequiredException("PLAN_EXISTE", "Esta empresa ya tiene un plan de cuentas...");
/// </summary>
public class ConfirmationRequiredException : Exception
{
    /// <summary>
    /// Codigo de confirmacion (ej: "PLAN_EXISTE", "NIVELES_NO_COINCIDEN")
    /// </summary>
    public string Code { get; }

    public ConfirmationRequiredException(string code, string message) : base(message)
    {
        Code = code;
    }
}
