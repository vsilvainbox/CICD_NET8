namespace App.Exceptions;

/// <summary>
/// Excepción para recursos no encontrados.
/// Estos errores se traducen a HTTP 404.
/// </summary>
public class NotFoundException : Exception
{
    public NotFoundException(string message) : base(message)
    {
    }

    public NotFoundException(string resourceType, object id) 
        : base($"{resourceType} con ID {id} no encontrado")
    {
    }
}
