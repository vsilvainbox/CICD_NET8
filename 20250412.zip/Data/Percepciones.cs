﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Percepciones
{
    public decimal IDPerc { get; set; }

    public decimal? IdComp { get; set; }

    public decimal? Orden { get; set; }

    public decimal? IdCuenta { get; set; }

    public decimal? IdEmpresa { get; set; }

    public int? Ano { get; set; }

    public int? Fecha { get; set; }

    public decimal? NumCertificado { get; set; }

    public decimal? RutEmpresa { get; set; }

    public decimal? Regimen { get; set; }

    public decimal? Contabilizacion { get; set; }

    public decimal? TasaTef { get; set; }

    public decimal? TasaTex { get; set; }

    public decimal? Percepciones1 { get; set; }
}
