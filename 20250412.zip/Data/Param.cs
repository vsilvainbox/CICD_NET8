﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Param
{
    public string Tipo { get; set; } = null!;

    public int Codigo { get; set; }

    public string? Valor { get; set; }

    public string? Diminutivo { get; set; }

    public string? Atributo { get; set; }
}
