﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Usuarios
{
    public int IdUsuario { get; set; }

    public string? Usuario { get; set; }

    public int? Clave { get; set; }

    public string? NombreLargo { get; set; }

    public byte? PrivAdm { get; set; }

    public bool? Activo { get; set; }

    public int? HabilitadoHasta { get; set; }

    public bool? ActivoOld { get; set; }

    public string? PasswordHash { get; set; }

    public bool RequiereCambioPassword { get; set; }
}
