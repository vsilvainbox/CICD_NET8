﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class DetPercepciones
{
    public decimal IDPerc { get; set; }

    public decimal CodDet { get; set; }

    public decimal? Valor { get; set; }
}
