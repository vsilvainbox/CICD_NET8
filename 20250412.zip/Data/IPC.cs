﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class IPC
{
    public int AnoMes { get; set; }

    public double? pIPC { get; set; }

    public double? vIPC { get; set; }

    public double? fCM { get; set; }

    public double? aIPC { get; set; }
}
