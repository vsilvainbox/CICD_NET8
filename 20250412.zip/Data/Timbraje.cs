﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Timbraje
{
    public int? idEmpresa { get; set; }

    public int? UltImpreso { get; set; }

    public int? FUltImpreso { get; set; }

    public int? UltTimbrado { get; set; }

    public int? FUltTimbrado { get; set; }

    public int? UltUsado { get; set; }

    public int? FUltUsado { get; set; }
}
