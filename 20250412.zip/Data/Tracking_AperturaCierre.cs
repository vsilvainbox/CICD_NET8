﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class Tracking_AperturaCierre
{
    public DateTime FechaHora { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }

    public int? Usuario { get; set; }

    public int? Tipo { get; set; }

    public string? Origen { get; set; }
}
