﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class vPrimeraDocCuota
{
    public int? IdDoc { get; set; }

    public short? NumCuota1 { get; set; }

    public int? IdEmpresa { get; set; }

    public short? Ano { get; set; }
}
