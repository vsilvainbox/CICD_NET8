﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class ErrorLog
{
    public int IdError { get; set; }

    public DateTime Timestamp { get; set; }

    public string Source { get; set; } = null!;

    public string Severity { get; set; } = null!;

    public string Message { get; set; } = null!;

    public string? StackTrace { get; set; }

    public string? Url { get; set; }

    public string? UserAgent { get; set; }

    public int? UsuarioId { get; set; }

    public int? EmpresaId { get; set; }

    public string? AdditionalData { get; set; }

    public string? IPAddress { get; set; }

    public string? ExceptionType { get; set; }

    public bool Resolved { get; set; }

    public int? ResolvedBy { get; set; }

    public DateTime? ResolvedAt { get; set; }

    public string? Notes { get; set; }

    public string? CorrelationId { get; set; }

    public string Origin { get; set; } = null!;
}
