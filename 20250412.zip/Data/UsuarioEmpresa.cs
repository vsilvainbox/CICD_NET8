﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class UsuarioEmpresa
{
    public int idUsuario { get; set; }

    public int idEmpresa { get; set; }

    public short? idPerfil { get; set; }
}
