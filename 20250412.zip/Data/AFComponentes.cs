﻿using System;
using System.Collections.Generic;

namespace App.Data;

public partial class AFComponentes
{
    public int IdComp { get; set; }

    public int? IdEmpresa { get; set; }

    public int? IdGrupo { get; set; }

    public string? NombComp { get; set; }
}
