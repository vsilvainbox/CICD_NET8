using App.Data;
using App.Exceptions;
using Microsoft.EntityFrameworkCore;

namespace App.Features.ConfiguracionPlanCuentas2019;

/// <summary>
/// Servicio para configuración de plan de cuentas 2019
/// Aplica el plan PERSONALIZADO basado en Plan Avanzado con configuraciones específicas para régimen 2019+
/// </summary>
public class ConfiguracionPlanCuentas2019Service(
    LpContabContext context,
    ILogger<ConfiguracionPlanCuentas2019Service> logger) : IConfiguracionPlanCuentas2019Service
{
    public async Task<ValidacionPrerequisitosResult> ValidarPrerequisitosAsync(int empresaId, short ano)
    {
        logger.LogInformation("Validating prerequisites for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        var result = new ValidacionPrerequisitosResult
        {
            PuedeAplicar = true,
            ExistePlanActual = false,
            CantidadCuentasActuales = 0,
            ExistenComprobantes = false,
            ExistenDocumentos = false
        };

        {
            // 1. Verificar si existen comprobantes con movimientos
            var existenComprobantes = await context.Comprobante
                .Join(context.MovComprobante,
                    c => c.IdComp,
                    m => m.IdComp,
                    (c, m) => new { c, m })
                .AnyAsync(x => x.c.IdEmpresa == empresaId && x.c.Ano == ano);

            if (existenComprobantes)
            {
                result.PuedeAplicar = false;
                result.ExistenComprobantes = true;
                result.MensajeError = "No es posible cambiar el plan de la empresa, hay comprobantes ya ingresados.";
                logger.LogWarning("Cannot apply plan: existing vouchers for empresaId: {EmpresaId}", empresaId);
                return result;
            }

            // 2. Verificar si existen documentos con cuentas asociadas
            var existenDocumentos = await context.MovDocumento
                .AnyAsync(m => m.IdEmpresa == empresaId &&
                              m.Ano == ano &&
                              m.IdCuenta != null &&
                              m.IdCuenta != 0);

            if (existenDocumentos)
            {
                result.PuedeAplicar = false;
                result.ExistenDocumentos = true;
                result.MensajeError = "No es posible cambiar el plan de la empresa, hay documentos ya ingresados que hacen referencia a cuentas de este plan.";
                logger.LogWarning("Cannot apply plan: existing documents with accounts for empresaId: {EmpresaId}", empresaId);
                return result;
            }

            // 3. Verificar si ya existe un plan de cuentas
            var cantidadCuentas = await context.Cuentas
                .CountAsync(c => c.IdEmpresa == empresaId && c.Ano == ano);

            if (cantidadCuentas > 0)
            {
                result.ExistePlanActual = true;
                result.CantidadCuentasActuales = cantidadCuentas;
                logger.LogInformation("Existing plan found with {Count} accounts for empresaId: {EmpresaId}", cantidadCuentas, empresaId);
            }

            logger.LogInformation("Prerequisites validation passed for empresaId: {EmpresaId}", empresaId);
            return result;
        }
    }

    public async Task<PreviewPlanResult> ObtenerVistaPreviaAsync()
    {
        logger.LogInformation("Getting plan preview");

        {
            var cuentas = await context.PlanAvanzado
                .OrderBy(c => c.Codigo)
                .Select(c => new CuentaPreviewDto
                {
                    Codigo = c.Codigo ?? "",
                    Nombre = c.Nombre ?? "",
                    Nivel = c.Nivel ?? 0,
                    Clasificacion = c.Clasificacion == 1 ? "Activo" :
                                   c.Clasificacion == 2 ? "Pasivo" :
                                   c.Clasificacion == 3 ? "Resultado" :
                                   c.Clasificacion == 4 ? "Orden" : "Otro",
                    CodigoPadre = context.PlanAvanzado
                        .Where(p => p.idCuenta == c.idPadre)
                        .Select(p => p.Codigo)
                        .FirstOrDefault()
                })
                .Take(100) // Limitar para preview
                .ToListAsync();

            var total = await context.PlanAvanzado.CountAsync();

            logger.LogInformation("Preview generated with {Count} accounts", cuentas.Count);

            return new PreviewPlanResult
            {
                Cuentas = cuentas,
                TotalCuentas = total,
                NombrePlan = "PERSONALIZADO"
            };
        }
    }

    public async Task<AplicarPlanResponse> AplicarPlanPersonalizadoAsync(int empresaId, short ano, bool confirmarSobreescritura)
    {
        logger.LogInformation("Applying PERSONALIZADO plan for empresaId: {EmpresaId}, ano: {Ano}, confirmOverwrite: {Confirm}", 
            empresaId, ano, confirmarSobreescritura);

        {
            // Validar prerequisitos
            var validacion = await ValidarPrerequisitosAsync(empresaId, ano);

            if (!validacion.PuedeAplicar)
            {
                throw new BusinessException(validacion.MensajeError ?? "No se puede aplicar el plan");
            }

            // Si existe plan actual y no se confirmó sobreescritura, lanzar excepción de confirmación
            if (validacion.ExistePlanActual && !confirmarSobreescritura)
            {
                throw new ConfirmationRequiredException(
                    "PLAN_EXISTE",
                    "Se requiere confirmación para sobreescribir el plan existente");
            }

            // Iniciar transacción
            using var transaction = await context.Database.BeginTransactionAsync();

            {
                // 1. Eliminar cuentas actuales
                await EliminarCuentasActualesAsync(empresaId, ano);

                // 2. Copiar plan desde PlanAvanzado
                var cuentasCreadas = await CopiarPlanDesdeAvanzadoAsync(empresaId, ano);

                // 3. Guardar tipo de plan
                await GuardarTipoPlanAsync(empresaId, ano, "PERSONALIZADO");

                // 4. Ajustar niveles
                await AjustarNivelesAsync(empresaId, ano);

                // 5. Setear cuentas básicas
                await SetearCuentasBasicasAsync(empresaId, ano);

                // 6. Asignar cuentas de libros
                await AsignarCuentasLibrosAsync(empresaId, ano);

                // 7. Agregar cuentas razón
                await AgregarCuentasRazonAsync(empresaId);

                // 8. Si año >= 2020, aplicar configuraciones específicas
                if (ano >= 2020)
                {
                    await ConfigurarAjustes2020Async(empresaId, ano);
                }

                await transaction.CommitAsync();

                logger.LogInformation("Successfully applied PERSONALIZADO plan for empresaId: {EmpresaId}, created {Count} accounts", 
                    empresaId, cuentasCreadas);

                return new AplicarPlanResponse
                {
                    CuentasCreadas = cuentasCreadas
                };
            }
        }
    }

    #region Private Helper Methods

    private async Task EliminarCuentasActualesAsync(int empresaId, short ano)
    {
        logger.LogInformation("Deleting current accounts for empresaId: {EmpresaId}", empresaId);

        // Eliminar Cuentas Básicas
        await context.CuentasBasicas
            .Where(c => c.IdEmpresa == empresaId && c.Ano == ano)
            .ExecuteDeleteAsync();

        // Eliminar Cuentas Razón
        await context.CuentasRazon
            .Where(c => c.IdEmpresa == empresaId)
            .ExecuteDeleteAsync();

        // Eliminar Cuentas Ajustes Extras RLI
        await context.CtasAjustesExContRLI
            .Where(c => c.IdEmpresa == empresaId && c.Ano == ano)
            .ExecuteDeleteAsync();

        // Eliminar Cuentas Ajustes Art. 14D LIR
        await context.CtasAjustesExCont
            .Where(c => c.IdEmpresa == empresaId && c.Ano == ano)
            .ExecuteDeleteAsync();

        // Eliminar todas las Cuentas
        await context.Cuentas
            .Where(c => c.IdEmpresa == empresaId && c.Ano == ano)
            .ExecuteDeleteAsync();

        logger.LogInformation("Current accounts deleted for empresaId: {EmpresaId}", empresaId);
    }

    private async Task<int> CopiarPlanDesdeAvanzadoAsync(int empresaId, short ano)
    {
        logger.LogInformation("Copying plan from PlanAvanzado for empresaId: {EmpresaId}", empresaId);

        var planAvanzado = await context.PlanAvanzado.ToListAsync();

        foreach (var cuenta in planAvanzado)
        {
            var nuevaCuenta = new Cuentas
            {
                IdEmpresa = empresaId,
                Ano = ano,
                idPadre = cuenta.idPadre,
                Codigo = cuenta.Codigo,
                Nombre = cuenta.Nombre,
                Descripcion = cuenta.Descripcion,
                CodFECU = cuenta.CodFECU,
                Nivel = cuenta.Nivel,
                Estado = cuenta.Estado,
                Clasificacion = cuenta.Clasificacion,
                Debe = cuenta.Debe,
                Haber = cuenta.Haber,
                MarcaApertura = cuenta.MarcaApertura,
                TipoCapPropio = cuenta.TipoCapPropio,
                CodF22 = cuenta.CodF22,
                Atrib1 = cuenta.Atrib1,
                Atrib2 = cuenta.Atrib2,
                Atrib3 = cuenta.Atrib3,
                Atrib4 = cuenta.Atrib4,
                Atrib5 = cuenta.Atrib5,
                Atrib6 = cuenta.Atrib6,
                Atrib7 = cuenta.Atrib7,
                Atrib8 = cuenta.Atrib8,
                Atrib9 = cuenta.Atrib9,
                Atrib10 = cuenta.Atrib10,
                CodIFRS_EstRes = cuenta.CodIFRS_EstRes,
                CodIFRS_EstFin = cuenta.CodIFRS_EstFin,
                CodIFRS = cuenta.CodIFRS,
                TipoPartida = cuenta.TipoPartida,
                CodCtaPlanSII = cuenta.CodCtaPlanSII,
                TipoPlan = "Personalizado"
            };

            context.Cuentas.Add(nuevaCuenta);
        }

        await context.SaveChangesAsync();

        logger.LogInformation("Copied {Count} accounts from PlanAvanzado", planAvanzado.Count);
        return planAvanzado.Count;
    }

    private async Task GuardarTipoPlanAsync(int empresaId, short ano, string tipoPlan)
    {
        logger.LogInformation("Saving plan type: {TipoPlan} for empresaId: {EmpresaId}", tipoPlan, empresaId);

        var exists = await context.ParamEmpresa
            .AnyAsync(p => p.Tipo == "PLANCTAS" && p.IdEmpresa == empresaId && p.Ano == ano);

        if (exists)
        {
            // Use ExecuteUpdate for keyless entity
            await context.ParamEmpresa
                .Where(p => p.Tipo == "PLANCTAS" && p.IdEmpresa == empresaId && p.Ano == ano)
                .ExecuteUpdateAsync(s => s.SetProperty(p => p.Valor, tipoPlan));
        }
        else
        {
            // Use raw SQL for insert
            await context.Database.ExecuteSqlRawAsync(
                "INSERT INTO ParamEmpresa (Tipo, Codigo, Valor, IdEmpresa, Ano) VALUES ({0}, {1}, {2}, {3}, {4})",
                "PLANCTAS", (short)0, tipoPlan, empresaId, ano);
        }
    }

    private async Task AjustarNivelesAsync(int empresaId, short ano)
    {
        logger.LogInformation("Adjusting levels for empresaId: {EmpresaId}", empresaId);

        var nivelesConfig = new Dictionary<string, int>
        {
            { "DIGNIV1", 1 },
            { "DIGNIV2", 2 },
            { "DIGNIV3", 2 },
            { "DIGNIV4", 2 },
            { "DIGNIV5", 0 },
            { "NIVELES", 4 }
        };

        foreach (var (tipo, valor) in nivelesConfig)
        {
            var exists = await context.ParamEmpresa
                .AnyAsync(p => p.Tipo == tipo && p.IdEmpresa == empresaId && p.Ano == ano);

            if (exists)
            {
                // Use ExecuteUpdate for keyless entity
                await context.ParamEmpresa
                    .Where(p => p.Tipo == tipo && p.IdEmpresa == empresaId && p.Ano == ano)
                    .ExecuteUpdateAsync(s => s.SetProperty(p => p.Valor, valor.ToString()));
            }
            else
            {
                // Use raw SQL for insert
                await context.Database.ExecuteSqlRawAsync(
                    "INSERT INTO ParamEmpresa (Tipo, Codigo, Valor, IdEmpresa, Ano) VALUES ({0}, {1}, {2}, {3}, {4})",
                    tipo, (short)0, valor.ToString(), empresaId, ano);
            }
        }
    }

    private async Task SetearCuentasBasicasAsync(int empresaId, short ano)
    {
        logger.LogInformation("Setting basic accounts for empresaId: {EmpresaId}", empresaId);
        // TODO: Implementar lógica de SetCtasBasDef
        // Esto requiere analizar más el código VB6 para entender qué hace exactamente
        await Task.CompletedTask;
    }

    private async Task AsignarCuentasLibrosAsync(int empresaId, short ano)
    {
        logger.LogInformation("Assigning book accounts for empresaId: {EmpresaId}", empresaId);

        var configuraciones = new List<CuentaBasicaLibroConfig>
        {
            // Compras
            new() { Libro = 1, Tipo = 1, CodigoCuenta = "1010801" },
            new() { Libro = 1, Tipo = 2, CodigoCuenta = "1010802" },
            new() { Libro = 1, Tipo = 3, CodigoCuenta = "2010601" },
            
            // Ventas
            new() { Libro = 2, Tipo = 1, CodigoCuenta = "3010101" },
            new() { Libro = 2, Tipo = 2, CodigoCuenta = "3010102" },
            new() { Libro = 2, Tipo = 3, CodigoCuenta = "1010401" },
            
            // Retenciones
            new() { Libro = 3, Tipo = 1, CodigoCuenta = "3010662" },
            new() { Libro = 3, Tipo = 2, CodigoCuenta = "3010608" },
            new() { Libro = 3, Tipo = 2, CodigoCuenta = "3010609" }
        };

        foreach (var config in configuraciones)
        {
            var cuenta = await context.Cuentas
                .FirstOrDefaultAsync(c => c.Codigo == config.CodigoCuenta &&
                                         c.IdEmpresa == empresaId &&
                                         c.Ano == ano);

            if (cuenta != null)
            {
                // Asignar cuenta básica
                context.CuentasBasicas.Add(new CuentasBasicas
                {
                    IdEmpresa = empresaId,
                    Ano = ano,
                    TipoLib = config.Libro,
                    Tipo = config.Tipo,
                    IdCuenta = cuenta.idCuenta
                });
            }
        }

        await context.SaveChangesAsync();
    }

    private async Task AgregarCuentasRazonAsync(int empresaId)
    {
        logger.LogInformation("Adding ratio accounts for empresaId: {EmpresaId}", empresaId);
        // TODO: Implementar AgregaCtasRazonGeneral
        await Task.CompletedTask;
    }

    private async Task ConfigurarAjustes2020Async(int empresaId, short ano)
    {
        logger.LogInformation("Configuring 2020+ adjustments for empresaId: {EmpresaId}", empresaId);

        // TODO: Validar franquicia tributaria antes de aplicar
        // If ValidaFranquiciaTributaria(1) Then AgregaCtasAjustesExtrasGeneral
        // If ValidaFranquiciaTributaria(2) Then AgregaCtasAjustes14DLIRGeneral

        // Actualizar atributos básicos
        await ActualizarAtributosBasicosAsync(empresaId, ano, "Atrib1", 1, "1010104");

        // Actualizar atrib3=1 para cuentas específicas
        var cuentasAtrib3 = new[]
        {
            "1020000", "1020100", "1020101", "1020102", "1020200", "1020201",
            "1020202", "1020203", "1020299", "1020300", "1020301", "1020302",
            "1020303", "1020304", "1020305", "1020306", "1020307", "1020399",
            "1020400", "1020401"
        };

        foreach (var codigo in cuentasAtrib3)
        {
            await ActualizarAtributosBasicosAsync(empresaId, ano, "Atrib3", 1, codigo);
        }

        // Actualizar datos de cuentas específicas
        await ActualizarDatosCuentaAsync(empresaId, ano, 2, 0, "2016100", 4, new[] { "2011207", "2011208" });
        
        var cuentasClasif3Tipo16 = new[]
        {
            "3010646", "3010647", "3010648", "3010649", "3010650", "3010651",
            "3010652", "3010653", "3010654", "3010656", "3010657", "3010658",
            "3010659", "3010661", "3010662"
        };
        await ActualizarDatosCuentaAsync(empresaId, ano, 3, 16, "3010300", 0, cuentasClasif3Tipo16);

        await ActualizarDatosCuentaAsync(empresaId, ano, 3, 14, "3010300", 0, new[] { "3010655" });
        await ActualizarDatosCuentaAsync(empresaId, ano, 3, 6, "3010300", 0, new[] { "3010660" });
        await ActualizarDatosCuentaAsync(empresaId, ano, 3, 3, "3010300", 0, new[] { "3020307", "3020308" });
        await ActualizarDatosCuentaAsync(empresaId, ano, 3, 4, "3010300", 0, new[] { "3020304", "3020305", "3020306", "3020309", "3020310" });

        logger.LogInformation("2020+ adjustments configured for empresaId: {EmpresaId}", empresaId);
    }

    private async Task ActualizarAtributosBasicosAsync(int empresaId, short ano, string campo, int valor, string codigo)
    {
        var cuenta = await context.Cuentas
            .FirstOrDefaultAsync(c => c.Codigo == codigo && c.IdEmpresa == empresaId && c.Ano == ano);

        if (cuenta != null)
        {
            switch (campo.ToLower())
            {
                case "atrib1":
                    cuenta.Atrib1 = (byte)valor;
                    break;
                case "atrib3":
                    cuenta.Atrib3 = (byte)valor;
                    break;
            }
            await context.SaveChangesAsync();
        }
    }

    private async Task ActualizarDatosCuentaAsync(int empresaId, short ano, int clasificacion, int tipoCapPropio,
        string codigoPadre, int nivel, string[] codigos)
    {
        foreach (var codigo in codigos)
        {
            var cuenta = await context.Cuentas
                .FirstOrDefaultAsync(c => c.Codigo == codigo && c.IdEmpresa == empresaId && c.Ano == ano);

            if (cuenta != null)
            {
                cuenta.Clasificacion = (byte)clasificacion;
                cuenta.TipoCapPropio = tipoCapPropio;
                // TODO: Actualizar idPadre basado en codigoPadre
                // Requiere buscar la cuenta padre y asignar su IdCuenta
            }
        }
        await context.SaveChangesAsync();
    }

    #endregion
}
