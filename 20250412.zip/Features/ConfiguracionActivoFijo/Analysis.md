# Análisis Exhaustivo: FrmConfigActFijo.frm

## 1. CONTROLES UI

### Controles Principales
| Control | Tipo | Nombre | Propósito |
|---------|------|--------|-----------|
| Ch_AFMesCompleto | CheckBox | Ch_AFMesCompleto | Configurar si considerar mes completo independiente de fecha inicio utilización |
| Bt_OK | CommandButton | Bt_OK | Guardar configuración |
| Bt_Cancel | CommandButton | Bt_Cancel | Cancelar sin guardar |
| Frame1 | Frame | Frame1 | Agrupación visual "Reporte de Control de Activo Fijo Financiero" |
| Picture2 | PictureBox | Picture2 | Icono decorativo |

### Propiedades UI Importantes
- **Caption del Form**: "Configurar Activo Fijo"
- **BorderStyle**: Fixed Dialog
- **MaxButton/MinButton**: False (no redimensionable)
- **StartUpPosition**: CenterOwner

## 2. EVENTOS

### Eventos de Botones
```vb
Private Sub Bt_OK_Click()
   Call SaveAll
   Unload Me
End Sub

Private Sub Bt_Cancel_Click()
   Unload Me
End Sub
```

### Evento de Carga
```vb
Private Sub Form_Load()
   Call EnableForm(Me, gEmpresa.FCierre = 0)
   Call LoadAll
   Call SetupPriv
End Sub
```

## 3. FUNCIONES Y PROCEDIMIENTOS

### LoadAll()
**Propósito**: Cargar la configuración actual del parámetro AFMESCOMPT
```vb
Private Sub LoadAll()
   Ch_AFMesCompleto = Abs(gAFMesCompleto)
End Sub
```
- Carga el valor de la variable global `gAFMesCompleto` al checkbox
- `Abs()` convierte boolean a entero

### SaveAll()
**Propósito**: Guardar la configuración del parámetro AFMESCOMPT
```vb
Private Sub SaveAll()
   Dim Q1 As String
   Dim Rs As Recordset
   Dim AFMesCompleto As Integer
   
   Set Rs = OpenRs(DbMain, "SELECT Valor FROM ParamEmpresa WHERE Tipo = 'AFMESCOMPT'")
   
   If Ch_AFMesCompleto <> Abs(gAFMesCompleto = True) Then 'cambió
      AFMesCompleto = False
      If Ch_AFMesCompleto <> 0 Then
         AFMesCompleto = True
      End If

      If Rs.EOF = False Then
         'actualizamos
         Call ExecSQL(DbMain, "UPDATE ParamEmpresa SET Codigo = 0, Valor = '" & AFMesCompleto & "' WHERE Tipo = 'AFMESCOMPT'")
      Else
         'insertamos
         Call ExecSQL(DbMain, "INSERT INTO ParamEmpresa (Tipo, Codigo, Valor) VALUES ('AFMESCOMPT', 0, '" & AFMesCompleto & "')")
      End If

      gAFMesCompleto = AFMesCompleto
   End If
   
   Call CloseRs(Rs)
End Sub
```

**Lógica**:
1. Verifica si existe el registro en `ParamEmpresa` con `Tipo = 'AFMESCOMPT'`
2. Detecta cambios comparando valor del checkbox con variable global
3. Si hay cambios:
   - Convierte el valor del checkbox a boolean
   - Si existe el registro → UPDATE
   - Si no existe → INSERT
   - Actualiza variable global `gAFMesCompleto`

### SetupPriv()
**Propósito**: Configurar privilegios de acceso
```vb
Private Function SetupPriv()
   If Not ChkPriv(PRV_CFG_EMP) Then
      Call EnableForm(Me, False)
   End If
End Function
```
- Verifica privilegio `PRV_CFG_EMP`
- Si no tiene privilegio, deshabilita todo el formulario

## 4. ACCESO A DATOS

### Tabla: ParamEmpresa
**Operaciones**:

#### SELECT
```sql
SELECT Valor FROM ParamEmpresa WHERE Tipo = 'AFMESCOMPT'
```
- Verifica si existe configuración previa

#### UPDATE
```sql
UPDATE ParamEmpresa SET Codigo = 0, Valor = '[AFMesCompleto]' WHERE Tipo = 'AFMESCOMPT'
```
- Actualiza configuración existente

#### INSERT
```sql
INSERT INTO ParamEmpresa (Tipo, Codigo, Valor) VALUES ('AFMESCOMPT', 0, '[AFMesCompleto]')
```
- Inserta nueva configuración

**Estructura de datos**:
- `Tipo`: 'AFMESCOMPT'
- `Codigo`: 0 (valor fijo)
- `Valor`: "0" (False) o "1" (True) como string

## 5. VALIDACIONES Y REGLAS DE NEGOCIO

### Validaciones
1. **Control de cierre**: Si `gEmpresa.FCierre <> 0`, deshabilita formulario
2. **Privilegios**: Requiere privilegio `PRV_CFG_EMP` para editar
3. **Detección de cambios**: Solo guarda si el valor cambió

### Reglas de Negocio
1. **Parámetro AFMESCOMPT**: Controla si en reportes de activo fijo se considera mes completo independiente de fecha inicio utilización
2. **Valor booleano**: Se almacena como string "0" o "1" en BD
3. **Ámbito**: Configuración a nivel de empresa (usa `IdEmpresa` implícito)

## 6. CÁLCULOS Y FÓRMULAS

No hay cálculos complejos. Solo conversiones:
- Checkbox value (0/1) → Boolean (False/True)
- Boolean → String ("0"/"1") para almacenamiento

## 7. NAVEGACIÓN Y FLUJO

### Flujo de Carga
```
Form_Load
  ↓
1. EnableForm (según FCierre)
  ↓
2. LoadAll (cargar configuración)
  ↓
3. SetupPriv (verificar permisos)
```

### Flujo de Guardado
```
Bt_OK_Click
  ↓
SaveAll
  ↓
1. Verificar si existe registro
  ↓
2. Detectar cambios
  ↓
3. UPDATE o INSERT
  ↓
4. Actualizar variable global
  ↓
Unload Me
```

### Navegación
- **Aceptar**: Guarda y cierra formulario
- **Cancelar**: Cierra sin guardar
- **Tecla ESC**: Vinculada a Cancelar (Cancel=True)

## 8. EXPORTACIONES Y REPORTES

No aplica. No genera exportaciones ni reportes.

## 9. DEPENDENCIAS EXTERNAS

### Variables Globales
- `gAFMesCompleto`: Variable global boolean que almacena el estado actual
- `gEmpresa.FCierre`: Control de cierre de empresa
- `gEmpresa.Id`: ID de empresa implícito en operaciones BD

### Funciones Globales
- `EnableForm()`: Habilitar/deshabilitar controles del formulario
- `ChkPriv()`: Verificar privilegios
- `OpenRs()`: Abrir recordset
- `ExecSQL()`: Ejecutar SQL
- `CloseRs()`: Cerrar recordset

### Constantes
- `PRV_CFG_EMP`: Privilegio requerido para configurar empresa

## 10. CASOS ESPECIALES Y EDGE CASES

1. **Primera vez**: Si no existe registro en ParamEmpresa, se crea con INSERT
2. **Sin cambios**: Si valor no cambió, no ejecuta SQL
3. **Sin privilegios**: Formulario se muestra en modo solo lectura
4. **Empresa cerrada**: Formulario se muestra en modo solo lectura
5. **Valor por defecto**: Si no existe, se asume False (0)

## 11. CONSIDERACIONES DE MIGRACIÓN .NET

### Mapeo de Entidades
- **ParamEmpresa**: Entidad existente en `\new\Data\ParamEmpresa.cs`
  - Verificar propiedades: `IdEmpresa`, `Ano`, `Tipo`, `Codigo`, `Valor`

### API Endpoints Necesarios
1. `GET /api/ConfiguracionActivoFijo/GetConfig` - Obtener configuración actual
2. `POST /api/ConfiguracionActivoFijo/SaveConfig` - Guardar configuración

### Seguridad
- Validar privilegio `PRV_CFG_EMP` en backend
- Validar que empresa no esté cerrada
- Validar IdEmpresa y Ano del contexto del usuario

### UI Moderna
- Checkbox con label descriptivo
- Botones Aceptar/Cancelar con iconos
- Mensaje de confirmación al guardar
- Diseño responsivo con Tailwind CSS

### Estado
- Usar contexto de empresa y año actuales del usuario logueado
- No usar variables globales, pasar por parámetros o contexto HTTP

