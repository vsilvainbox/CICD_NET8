using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Extensions;
using App.Helpers;

namespace App.Features.ConfiguracionActivoFijo;

public class ConfiguracionActivoFijoController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<ConfiguracionActivoFijoController> logger) : Controller
{
    /// <summary>
    /// Vista principal de configuracion de Activo Fijo
    /// </summary>
    public async Task<IActionResult> Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a la Configuración de Activo Fijo";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        var empresaId = SessionHelper.EmpresaId;
        var ano = (short)SessionHelper.Ano;

        // Cargar configuracion actual
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionActivoFijoApiController>(
            HttpContext,
            nameof(ConfiguracionActivoFijoApiController.GetConfig),
            new { empresaId, ano });

        var config = await client.GetFromApiAsync<ConfiguracionActivoFijoDto>(url!);

        var viewModel = new ConfiguracionActivoFijoViewModel
        {
            IdEmpresa = empresaId,
            Ano = ano,
            AFMesCompleto = config?.AFMesCompleto ?? false
        };

        return View(viewModel);
    }

    /// <summary>
    /// Guardar configuracion usando formulario POST con Tag Helpers
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Index(ConfiguracionActivoFijoViewModel model)
    {
        if (!ModelState.IsValid)
        {
            TempData["SwalError"] = "Datos del formulario invalidos";
            return View(model);
        }

        var client = httpClientFactory.CreateClient();

        var saveDto = new SaveConfiguracionActivoFijoDto
        {
            IdEmpresa = model.IdEmpresa,
            Ano = model.Ano,
            AFMesCompleto = model.AFMesCompleto
        };

        var url = linkGenerator.GetApiUrl<ConfiguracionActivoFijoApiController>(
            HttpContext,
            nameof(ConfiguracionActivoFijoApiController.SaveConfig));

        var (statusCode, content) = await client.ProxyRequestAsync(
            url!,
            JsonSerializer.SerializeToElement(saveDto),
            HttpMethod.Post);

        if (statusCode == 200)
        {
            TempData["SwalSuccess"] = "Configuracion guardada exitosamente";
            return RedirectToAction(nameof(Index));
        }
        else
        {
            TempData["SwalError"] = "Error al guardar la configuracion";
            return View(model);
        }
    }

    /// <summary>
    /// Proxy: Obtener configuracion de Activo Fijo
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetConfig(int empresaId, short ano)
    {
        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<ConfiguracionActivoFijoApiController>(
            HttpContext,
            nameof(ConfiguracionActivoFijoApiController.GetConfig),
            new { empresaId, ano });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Proxy: Guardar configuracion de Activo Fijo
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> SaveConfig([FromBody] JsonElement request)
    {
        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<ConfiguracionActivoFijoApiController>(
            HttpContext,
            nameof(ConfiguracionActivoFijoApiController.SaveConfig));
        var (statusCode, content) = await client.ProxyRequestAsync(
            url!,
            request!,
            HttpMethod.Post);
        return StatusCode(statusCode, content);
    }
}
