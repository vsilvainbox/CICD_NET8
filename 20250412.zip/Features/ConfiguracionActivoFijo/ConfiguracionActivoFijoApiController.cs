using Microsoft.AspNetCore.Mvc;

namespace App.Features.ConfiguracionActivoFijo;

[ApiController]
[Route("[controller]/[action]")]
public class ConfiguracionActivoFijoApiController(
    IConfiguracionActivoFijoService service,
    ILogger<ConfiguracionActivoFijoApiController> logger) : ControllerBase
{
    /// <summary>
    /// Obtiene la configuraciÃ³n actual de Activo Fijo
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<ConfiguracionActivoFijoDto>> GetConfig([FromQuery] int empresaId, [FromQuery] short ano)
    {
        var config = await service.GetConfiguracionAsync(empresaId, ano);
        return Ok(config);
    }

    /// <summary>
    /// Guarda la configuraciÃ³n de Activo Fijo
    /// </summary>
    [HttpPost]
    public async Task<ActionResult> SaveConfig([FromBody] SaveConfiguracionActivoFijoDto dto)
    {
        await service.SaveConfiguracionAsync(dto);
        return Ok(new { message = "Configuración guardada exitosamente" });
    }
}

