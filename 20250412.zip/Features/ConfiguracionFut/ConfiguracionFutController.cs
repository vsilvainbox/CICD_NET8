using Microsoft.AspNetCore.Mvc;
using App.Extensions;
using App.Helpers;

namespace App.Features.ConfiguracionFut;


public class ConfiguracionFutController(
    IHttpClientFactory httpClientFactory,
    ILogger<ConfiguracionFutController> logger, LinkGenerator linkGenerator) : Controller
{
    public async Task<IActionResult> Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Configuración FUT";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        // Extraer datos de HttpContext usando extensiones
        var empresaId = SessionHelper.EmpresaId;

        logger.LogInformation("Loading ConfiguracionFut index for empresaId: {EmpresaId}", empresaId);

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionFutApiController>(
            HttpContext,
            nameof(ConfiguracionFutApiController.GetConfiguracion),
            new { empresaId });
        var config = await client.GetFromApiAsync<ConfiguracionFutDto>(url);

        return View(config);
    }
}
