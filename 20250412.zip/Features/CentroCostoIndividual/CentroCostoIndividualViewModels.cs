namespace App.Features.CentroCostoIndividual;

/// <summary>
/// ViewModel para la vista de Centro de Costo Individual
/// Reemplaza el uso de ViewBag con propiedades tipadas
/// </summary>
public class CentroCostoIndividualViewModel
{
    /// <summary>
    /// Modo de operación de la vista
    /// </summary>
    public ModoVista Modo { get; set; } = ModoVista.Nuevo;

    /// <summary>
    /// Título de la página
    /// </summary>
    public string Titulo { get; set; } = string.Empty;

    /// <summary>
    /// Indica si la vista está en modo solo lectura
    /// </summary>
    public bool SoloLectura { get; set; } = false;

    /// <summary>
    /// Datos del centro de costo
    /// </summary>
    public CentroCostoDto CentroCosto { get; set; } = new();

    /// <summary>
    /// FormDto para los Tag Helpers de formulario
    /// </summary>
    public CentroCostoFormDto FormModel => new()
    {
        IdCCosto = CentroCosto.IdCCosto,
        Codigo = CentroCosto.Codigo ?? string.Empty,
        Descripcion = CentroCosto.Descripcion,
        Vigente = CentroCosto.Vigente ?? true
    };

    /// <summary>
    /// Indica si es modo nuevo
    /// </summary>
    public bool EsNuevo => Modo == ModoVista.Nuevo;

    /// <summary>
    /// Indica si es modo editar
    /// </summary>
    public bool EsEditar => Modo == ModoVista.Editar;

    /// <summary>
    /// Indica si es modo ver
    /// </summary>
    public bool EsVer => Modo == ModoVista.Ver;
}

/// <summary>
/// Enumeración para los modos de vista
/// </summary>
public enum ModoVista
{
    Nuevo,
    Editar,
    Ver
}
