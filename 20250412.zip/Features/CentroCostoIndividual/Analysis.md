# Análisis de Migración: Centro de Costo Individual (FrmCCosto.frm)

## 1. Información General

| Aspecto | Detalle |
|---------|---------|
| **Formulario VB6** | `FrmCCosto.frm` |
| **Propósito** | Formulario modal para crear, editar o ver un centro de costo individual |
| **Tipo** | Formulario de edición/alta individual (CRUD detail form) |
| **Namespace .NET** | `App.Features.CentroCostoIndividual` |

## 2. Análisis del Formulario VB6

### 2.1 Controles del Formulario

| Control VB6 | Tipo | Propósito | Mapeo .NET |
|------------|------|-----------|------------|
| `Tx_Codigo` | TextBox | Código del centro de costo (máx 15 chars) | Input text |
| `Tx_Descripcion` | TextBox | Descripción (máx 50 chars) | Input text |
| `Ch_Vigente` | CheckBox | Indica si está vigente | Checkbox |
| `Bt_OK` | CommandButton | Guardar cambios | Button submit |
| `Bt_Cancel` | CommandButton | Cancelar y cerrar | Button cancel |
| `Frame1` | Frame | Contenedor de campos | Fieldset/div |
| `Image1` | Image | Ícono decorativo | SVG icon |
| `Label1(0)` | Label | "Descripción:" | Label |
| `Label1(1)` | Label | "Código:" | Label |

### 2.2 Modos de Operación

El formulario soporta 3 modos:

```vb6
Const O_NEW = 1    ' Nuevo centro de costo
Const O_EDIT = 2   ' Editar existente
Const O_VIEW = 3   ' Solo visualización
```

| Modo | Caption | Campos Editables | Acción al Guardar |
|------|---------|------------------|-------------------|
| O_NEW | "Nuevo Centro de Gestión" | Todos | INSERT nuevo registro |
| O_EDIT | "Modificar Centro de Gestión" | Todos | UPDATE registro existente |
| O_VIEW | "Ver Centro de Gestión" | Ninguno (readonly) | No aplica |

### 2.3 Funciones Públicas

#### FNew()
```vb6
Friend Function FNew(CCosto As CCosto_t) As Integer
   Oper = O_NEW
   Me.Show vbModal
   CCosto = lCCosto
   FNew = lRc
End Function
```
- **Propósito**: Crear nuevo centro de costo
- **Input**: Estructura CCosto_t vacía
- **Output**: vbOK si se guardó, vbCancel si se canceló + datos del nuevo registro
- **Mapeo .NET**: POST /api/CentroCostoIndividual

#### FEdit()
```vb6
Friend Function FEdit(CCosto As CCosto_t) As Integer
   lCCosto = CCosto
   Oper = O_EDIT
   Me.Show vbModal
   CCosto = lCCosto
   FEdit = lRc
End Function
```
- **Propósito**: Editar centro de costo existente
- **Input**: CCosto_t con Id del registro
- **Output**: vbOK si se guardó, vbCancel si se canceló + datos actualizados
- **Mapeo .NET**: PUT /api/CentroCostoIndividual/{id}

#### FView()
```vb6
Friend Function FView(CCosto As CCosto_t) As Integer
   lCCosto = CCosto
   Oper = O_VIEW
   Me.Show vbModal
   FView = lRc
   CCosto = lCCosto
End Function
```
- **Propósito**: Ver centro de costo (solo lectura)
- **Input**: CCosto_t con Id del registro
- **Output**: vbCancel (no hay guardado)
- **Mapeo .NET**: GET /api/CentroCostoIndividual/{id} (view-only mode)

### 2.4 Lógica de Negocio

#### Form_Load()
```vb6
Private Sub Form_Load()
   lRc = vbCancel
   
   If Oper = O_NEW Then
      Caption = "Nuevo Centro de Gestión"
      Ch_Vigente = 1    ' Default: Vigente = True
   ElseIf Oper = O_EDIT Then
      Caption = "Modificar Centro de Gestión"
      Call LoadAll
   ElseIf Oper = O_VIEW Then
      Caption = "Ver Centro de Gestión"
      Call LoadAll
   End If
   
   Call SetupPriv
End Sub
```

**Reglas**:
- Modo nuevo: Ch_Vigente por defecto = 1 (true)
- Modo editar/ver: cargar datos existentes con LoadAll()
- Verificar privilegios con SetupPriv()

#### LoadAll()
```vb6
Private Sub LoadAll()
   Q1 = "SELECT Codigo, Descripcion, Vigente FROM CentroCosto"
   Q1 = Q1 & " WHERE idCCosto=" & lCCosto.Id
   
   Set Rs = OpenRs(DbMain, Q1)
   If Rs.EOF = False Then
      Tx_Codigo = vFld(Rs("Codigo"), True)
      Tx_Descripcion = vFld(Rs("Descripcion"), True)
      Ch_Vigente = IIf(vFld(Rs("Vigente")) <> 0, 1, 0)
   End If
   Call CloseRs(Rs)
End Sub
```

**Query SQL**:
```sql
SELECT Codigo, Descripcion, Vigente 
FROM CentroCosto 
WHERE idCCosto = @Id
```

**Mapeo EF Core**:
```csharp
var centroCosto = await _context.CentroCosto
    .Where(c => c.IdCCosto == id)
    .Select(c => new CentroCostoDto
    {
        IdCCosto = c.IdCCosto,
        Codigo = c.Codigo,
        Descripcion = c.Descripcion,
        Vigente = c.Vigente == -1 || c.Vigente == 1
    })
    .FirstOrDefaultAsync();
```

#### Valida()
```vb6
Private Function Valida() As Boolean
   Valida = False
   
   ' Validación 1: Código obligatorio
   If Tx_Codigo = "" Then
      MsgBox1 "Debe ingresar el código", vbExclamation
      Exit Function
   End If
   
   ' Validación 2: Código único (excepto el actual)
   Q1 = "SELECT idCCosto FROM CentroCosto WHERE Codigo='" & Tx_Codigo & "'"
   Q1 = Q1 & " AND idCCosto<>" & lCCosto.Id
   Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.Id

   Set Rs = OpenRs(DbMain, Q1)
   If Rs.EOF = False Then
      MsgBox1 "Código ya existe", vbExclamation
      Tx_Codigo.SetFocus
      Call CloseRs(Rs)
      Exit Function
   End If
   Call CloseRs(Rs)
   
   Valida = True
End Function
```

**Validaciones**:
1. **Código obligatorio**: No puede estar vacío
2. **Código único**: No puede duplicarse dentro de la misma empresa (excluyendo el registro actual en edición)

**Query SQL de validación**:
```sql
SELECT idCCosto 
FROM CentroCosto 
WHERE Codigo = @Codigo 
  AND idCCosto <> @Id 
  AND IdEmpresa = @EmpresaId
```

**Mapeo EF Core**:
```csharp
var existe = await _context.CentroCosto
    .AnyAsync(c => c.Codigo == codigo 
        && c.IdCCosto != id 
        && c.IdEmpresa == empresaId);
```

#### bt_OK_Click()
```vb6
Private Sub bt_OK_Click()
   If Valida() = False Then
      Exit Sub
   End If
   
   ' Si es nuevo, obtener nuevo ID
   If Oper = O_NEW Then
      lCCosto.Id = AdvTbAddNew(DbMain, "CentroCosto", "idCCosto", "IdEmpresa", gEmpresa.Id)
   End If
   
   ' UPDATE siempre (incluso en nuevo, después del INSERT)
   Q1 = "UPDATE CentroCosto SET Codigo='" & ParaSQL(Tx_Codigo) & "'"
   Q1 = Q1 & ", Descripcion='" & ParaSQL(Tx_Descripcion) & "'"
   Q1 = Q1 & ", Vigente = " & IIf(Ch_Vigente <> 0, -1, 0)
   Q1 = Q1 & " WHERE idCCosto=" & lCCosto.Id
   Q1 = Q1 & " AND IdEmpresa = " & gEmpresa.Id
   
   Call ExecSQL(DbMain, Q1)
   
   lCCosto.Codigo = Tx_Codigo
   lCCosto.Descrip = Tx_Descripcion
   
   lRc = vbOK
   Unload Me
End Sub
```

**Lógica de guardado**:

1. **Modo nuevo (O_NEW)**:
   - Llamar a `AdvTbAddNew()` que hace INSERT y retorna nuevo Id
   - Luego ejecutar UPDATE con los valores ingresados
   
2. **Modo editar (O_EDIT)**:
   - Ejecutar UPDATE directamente con los valores modificados

**Nota**: El patrón INSERT + UPDATE es peculiar del VB6. En .NET lo simplificaremos a:
- POST → `_context.Add()` + `SaveChanges()`
- PUT → Modificar entidad existente + `SaveChanges()`

**Query UPDATE**:
```sql
UPDATE CentroCosto 
SET Codigo = @Codigo,
    Descripcion = @Descripcion,
    Vigente = @Vigente
WHERE idCCosto = @Id
  AND IdEmpresa = @EmpresaId
```

**Conversión Vigente**:
- VB6: `IIf(Ch_Vigente <> 0, -1, 0)` → Checkbox checked = -1 (true), unchecked = 0 (false)
- .NET: `bool vigente` → true/false, almacenado como 1/0 en BD

#### Tx_Codigo_KeyPress()
```vb6
Private Sub Tx_Codigo_KeyPress(KeyAscii As Integer)
   Call KeyUpper(KeyAscii)
End Sub
```
- **Propósito**: Convertir a mayúsculas mientras se escribe
- **Mapeo .NET**: JavaScript `toUpperCase()` o CSS `text-transform: uppercase`

#### SetupPriv()
```vb6
Private Function SetupPriv()
   If Not ChkPriv(PRV_ADM_DEF) Then
      Call EnableForm(Me, False)
   End If
End Function
```
- **Propósito**: Deshabilitar formulario si usuario no tiene privilegio PRV_ADM_DEF
- **Mapeo .NET**: Verificación en backend y frontend, mostrar solo en modo view si no tiene permisos

### 2.5 Estructura CCosto_t

```vb6
Type CCosto_t
   Id As Long
   Codigo As String
   Descrip As String
   Vigente As Integer
End Type
```

**Mapeo .NET DTO**:
```csharp
public class CentroCostoDto
{
    public int IdCCosto { get; set; }
    public string? Codigo { get; set; }
    public string? Descripcion { get; set; }
    public bool Vigente { get; set; }
}
```

## 3. Mapeo a .NET

### 3.1 DTOs Necesarios

#### CentroCostoDto
```csharp
public class CentroCostoDto
{
    public int IdCCosto { get; set; }
    public string? Codigo { get; set; }
    public string? Descripcion { get; set; }
    public bool Vigente { get; set; }
    public int IdEmpresa { get; set; }
}
```

#### CrearCentroCostoDto
```csharp
public class CrearCentroCostoDto
{
    [Required(ErrorMessage = "El código es obligatorio")]
    [MaxLength(15, ErrorMessage = "El código no puede exceder 15 caracteres")]
    public string Codigo { get; set; } = string.Empty;
    
    [MaxLength(50, ErrorMessage = "La descripción no puede exceder 50 caracteres")]
    public string? Descripcion { get; set; }
    
    public bool Vigente { get; set; } = true;
}
```

#### ActualizarCentroCostoDto
```csharp
public class ActualizarCentroCostoDto
{
    [Required(ErrorMessage = "El código es obligatorio")]
    [MaxLength(15, ErrorMessage = "El código no puede exceder 15 caracteres")]
    public string Codigo { get; set; } = string.Empty;
    
    [MaxLength(50, ErrorMessage = "La descripción no puede exceder 50 caracteres")]
    public string? Descripcion { get; set; }
    
    public bool Vigente { get; set; }
}
```

### 3.2 Interface del Servicio

```csharp
public interface ICentroCostoIndividualService
{
    // Obtener centro de costo por ID
    Task<CentroCostoDto?> GetByIdAsync(int id, int empresaId);
    
    // Crear nuevo centro de costo
    Task<CentroCostoDto> CreateAsync(CrearCentroCostoDto dto, int empresaId);
    
    // Actualizar centro de costo existente
    Task<CentroCostoDto> UpdateAsync(int id, ActualizarCentroCostoDto dto, int empresaId);
    
    // Validar código único
    Task<bool> ExisteCodigoAsync(string codigo, int empresaId, int? excludeId = null);
}
```

### 3.3 Endpoints API

| Método | Ruta | Acción | Mapeo VB6 |
|--------|------|--------|-----------|
| GET | `/api/CentroCostoIndividual/{id}` | Obtener centro de costo | LoadAll() |
| POST | `/api/CentroCostoIndividual` | Crear nuevo | FNew() → bt_OK_Click() |
| PUT | `/api/CentroCostoIndividual/{id}` | Actualizar | FEdit() → bt_OK_Click() |
| GET | `/api/CentroCostoIndividual/validar-codigo` | Validar código único | Valida() |

### 3.4 Controlador MVC

```csharp
public class CentroCostoIndividualController : Controller
{
    // GET: /CentroCostoIndividual/Nuevo
    public IActionResult Nuevo() { }
    
    // GET: /CentroCostoIndividual/Editar/{id}
    public async Task<IActionResult> Editar(int id) { }
    
    // GET: /CentroCostoIndividual/Ver/{id}
    public async Task<IActionResult> Ver(int id) { }
}
```

### 3.5 Vista Razor

**Shared View**: `Views/Index.cshtml`
- Usada para Nuevo, Editar y Ver
- Modo determinado por ViewBag.Modo ("Nuevo", "Editar", "Ver")
- Campos deshabilitados en modo "Ver"

## 4. Queries SQL → EF Core

### Query 1: LoadAll - Cargar datos existentes
**VB6**:
```sql
SELECT Codigo, Descripcion, Vigente 
FROM CentroCosto 
WHERE idCCosto = @Id
```

**EF Core**:
```csharp
var centroCosto = await _context.CentroCosto
    .Where(c => c.IdCCosto == id)
    .FirstOrDefaultAsync();
```

### Query 2: Valida - Verificar código único
**VB6**:
```sql
SELECT idCCosto 
FROM CentroCosto 
WHERE Codigo = @Codigo 
  AND idCCosto <> @Id 
  AND IdEmpresa = @EmpresaId
```

**EF Core**:
```csharp
var existe = await _context.CentroCosto
    .AnyAsync(c => c.Codigo == codigo 
        && c.IdCCosto != excludeId 
        && c.IdEmpresa == empresaId);
```

### Query 3: bt_OK_Click - INSERT (implícito en AdvTbAddNew)
**VB6** (AdvTbAddNew hace):
```sql
INSERT INTO CentroCosto (IdEmpresa) VALUES (@EmpresaId)
SELECT @@IDENTITY
```

**EF Core**:
```csharp
var nuevoCentroCosto = new CentroCosto
{
    IdEmpresa = empresaId,
    Codigo = dto.Codigo,
    Descripcion = dto.Descripcion,
    Vigente = dto.Vigente ? 1 : 0
};
_context.CentroCosto.Add(nuevoCentroCosto);
await _context.SaveChangesAsync();
```

### Query 4: bt_OK_Click - UPDATE
**VB6**:
```sql
UPDATE CentroCosto 
SET Codigo = @Codigo,
    Descripcion = @Descripcion,
    Vigente = @Vigente
WHERE idCCosto = @Id 
  AND IdEmpresa = @EmpresaId
```

**EF Core**:
```csharp
var centroCosto = await _context.CentroCosto
    .FirstOrDefaultAsync(c => c.IdCCosto == id && c.IdEmpresa == empresaId);
    
centroCosto.Codigo = dto.Codigo;
centroCosto.Descripcion = dto.Descripcion;
centroCosto.Vigente = dto.Vigente ? 1 : 0;

await _context.SaveChangesAsync();
```

## 5. Validaciones

| Validación | Regla | Mensaje | Ubicación |
|------------|-------|---------|-----------|
| Código obligatorio | `Codigo != ""` | "Debe ingresar el código" | Backend + Frontend |
| Código único | No existe otro con mismo código en la empresa | "Código ya existe" | Backend |
| Código max length | <= 15 caracteres | "El código no puede exceder 15 caracteres" | Frontend (maxlength) |
| Descripción max length | <= 50 caracteres | "La descripción no puede exceder 50 caracteres" | Frontend (maxlength) |

## 6. Comportamiento UI

### Estados del Formulario

| Modo | Título | Campos | Botones | Al Guardar |
|------|--------|--------|---------|------------|
| Nuevo | "Nuevo Centro de Gestión" | Todos editables, Vigente=true | Aceptar, Cancelar | POST API |
| Editar | "Modificar Centro de Gestión" | Todos editables | Aceptar, Cancelar | PUT API |
| Ver | "Ver Centro de Gestión" | Todos readonly | Solo Cerrar | N/A |

### Flujo de Interacción

```
Usuario hace clic en "Nuevo" en CentrosCosto
  ↓
Abre modal CentroCostoIndividual (modo Nuevo)
  ↓
Usuario ingresa Código y Descripción
  ↓
Usuario hace clic en "Aceptar"
  ↓
Validación frontend (campos requeridos)
  ↓
POST /api/CentroCostoIndividual
  ↓
Backend valida código único
  ↓
Si OK: Guarda y retorna DTO con nuevo Id
  ↓
Modal se cierra y lista padre se refresca
```

## 7. Consideraciones Especiales

### 7.1 Vigente como Integer
- VB6 usa -1 (true) y 0 (false)
- .NET almacena 1 (true) y 0 (false)
- Conversión en Service:
  ```csharp
  entity.Vigente = dto.Vigente ? 1 : 0;  // Al guardar
  dto.Vigente = entity.Vigente == 1 || entity.Vigente == -1;  // Al leer
  ```

### 7.2 KeyUpper en Código
- VB6: KeyUpper convierte a mayúsculas en tiempo real
- .NET: Aplicar `style="text-transform: uppercase"` o `.toUpperCase()` en JavaScript

### 7.3 Privilegios
- VB6: SetupPriv() deshabilita todo si no tiene PRV_ADM_DEF
- .NET: Por ahora no implementaremos sistema de privilegios (TODO futuro)

### 7.4 Patrón INSERT + UPDATE del VB6
- VB6 hace INSERT vacío + UPDATE con datos
- .NET lo simplifica a un solo `Add()` con datos completos

## 8. Resumen de Implementación

### Archivos a Crear

1. `CentroCostoIndividualDto.cs` - DTOs
2. `ICentroCostoIndividualService.cs` - Interface
3. `CentroCostoIndividualService.cs` - Lógica de negocio
4. `CentroCostoIndividualApiController.cs` - API REST
5. `CentroCostoIndividualController.cs` - MVC Controller
6. `Views/Index.cshtml` - Vista compartida para Nuevo/Editar/Ver
7. `Views/_ViewImports.cshtml` - Imports

### Funcionalidades Clave

✅ Crear nuevo centro de costo  
✅ Editar centro de costo existente  
✅ Ver centro de costo (solo lectura)  
✅ Validación código obligatorio  
✅ Validación código único por empresa  
✅ Checkbox Vigente con valor por defecto true  
✅ MaxLength en campos  
✅ Conversión mayúsculas en código  
✅ Modal que se cierra y refresca lista padre  

### Integración con CentrosCosto

Este formulario es invocado desde `CentrosCosto/Index.cshtml`:
- Botón "Agregar" → Modal con modo Nuevo
- Botón "Editar" → Modal con modo Editar + datos cargados
- Doble clic en fila → Modal con modo Ver (readonly)

Al guardar exitosamente, el modal se cierra y dispara evento para que la lista padre se recargue.
