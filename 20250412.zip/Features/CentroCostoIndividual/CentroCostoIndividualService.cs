using App.Data;
using App.Exceptions;
using Microsoft.EntityFrameworkCore;

namespace App.Features.CentroCostoIndividual;

/// <summary>
/// Servicio para gestión individual de centros de costo
/// Basado en FrmCCosto.frm del sistema VB6
/// </summary>
public class CentroCostoIndividualService(
    LpContabContext context,
    ILogger<CentroCostoIndividualService> logger) : ICentroCostoIndividualService
{
    /// <summary>
    /// Obtiene un centro de costo por su ID
    /// Mapea: FrmCCosto.LoadAll()
    /// Query VB6: SELECT Codigo, Descripcion, Vigente FROM CentroCosto WHERE idCCosto=@Id
    /// </summary>
    public async Task<CentroCostoDto> GetByIdAsync(int id, int empresaId)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");

        logger.LogInformation("Obteniendo centro de costo Id={Id}, Empresa={EmpresaId}", id, empresaId);

        var centroCosto = await context.CentroCosto
            .Where(c => c.IdCCosto == id && c.IdEmpresa == empresaId)
            .Select(c => new CentroCostoDto
            {
                IdCCosto = c.IdCCosto,
                Codigo = c.Codigo,
                Descripcion = c.Descripcion,
                Vigente = c.Vigente ?? false,
                IdEmpresa = c.IdEmpresa ?? 0
            })
            .FirstOrDefaultAsync();

        if (centroCosto == null)
            throw new BusinessException("Centro de costo no encontrado");

        return centroCosto;
    }

    /// <summary>
    /// Crea un nuevo centro de costo
    /// Mapea: FrmCCosto.FNew() → bt_OK_Click()
    /// VB6 hace: AdvTbAddNew (INSERT) + UPDATE
    /// .NET simplifica a: Add + SaveChanges
    /// </summary>
    public async Task<CentroCostoDto> CreateAsync(CrearCentroCostoDto dto, int empresaId)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");

        if (string.IsNullOrWhiteSpace(dto.Codigo))
            throw new BusinessException("Debe ingresar el código");

        logger.LogInformation("Creando nuevo centro de costo: Codigo={Codigo}, Empresa={EmpresaId}",
            dto.Codigo, empresaId);

        // Validar código único
        var codigoExiste = await ExisteCodigoAsync(dto.Codigo, empresaId);
        if (codigoExiste)
        {
            logger.LogWarning("Código ya existe: {Codigo}", dto.Codigo);
            throw new BusinessException("Código ya existe");
        }

        // Crear nueva entidad
        var nuevoCentroCosto = new CentroCosto
        {
            IdEmpresa = empresaId,
            Codigo = dto.Codigo?.Trim().ToUpper(), // KeyUpper en VB6
            Descripcion = dto.Descripcion?.Trim(),
            Vigente = dto.Vigente
        };

        context.CentroCosto.Add(nuevoCentroCosto);
        await context.SaveChangesAsync();

        logger.LogInformation("Centro de costo creado exitosamente: Id={Id}", nuevoCentroCosto.IdCCosto);

        // Retornar DTO
        return new CentroCostoDto
        {
            IdCCosto = nuevoCentroCosto.IdCCosto,
            Codigo = nuevoCentroCosto.Codigo,
            Descripcion = nuevoCentroCosto.Descripcion,
            Vigente = nuevoCentroCosto.Vigente ?? false,
            IdEmpresa = empresaId
        };
    }

    /// <summary>
    /// Actualiza un centro de costo existente
    /// Mapea: FrmCCosto.FEdit() → bt_OK_Click()
    /// Query VB6: UPDATE CentroCosto SET Codigo=@Codigo, Descripcion=@Descripcion, Vigente=@Vigente 
    ///            WHERE idCCosto=@Id AND IdEmpresa=@EmpresaId
    /// </summary>
    public async Task<CentroCostoDto> UpdateAsync(int id, ActualizarCentroCostoDto dto, int empresaId)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");

        if (string.IsNullOrWhiteSpace(dto.Codigo))
            throw new BusinessException("Debe ingresar el código");

        logger.LogInformation("Actualizando centro de costo Id={Id}: Codigo={Codigo}",
            id, dto.Codigo);

        // Buscar entidad existente
        var centroCosto = await context.CentroCosto
            .FirstOrDefaultAsync(c => c.IdCCosto == id && c.IdEmpresa == empresaId);

        if (centroCosto == null)
        {
            logger.LogWarning("Centro de costo no encontrado para actualizar: Id={Id}", id);
            throw new BusinessException("Centro de costo no encontrado");
        }

        // Validar código único (excluyendo el actual)
        var codigoExiste = await ExisteCodigoAsync(dto.Codigo, empresaId, id);
        if (codigoExiste)
        {
            logger.LogWarning("Código ya existe: {Codigo}", dto.Codigo);
            throw new BusinessException("Código ya existe");
        }

        // Actualizar campos
        centroCosto.Codigo = dto.Codigo?.Trim().ToUpper(); // KeyUpper en VB6
        centroCosto.Descripcion = dto.Descripcion?.Trim();
        centroCosto.Vigente = dto.Vigente;

        await context.SaveChangesAsync();

        logger.LogInformation("Centro de costo actualizado exitosamente: Id={Id}", id);

        // Retornar DTO actualizado
        return new CentroCostoDto
        {
            IdCCosto = centroCosto.IdCCosto,
            Codigo = centroCosto.Codigo,
            Descripcion = centroCosto.Descripcion,
            Vigente = centroCosto.Vigente ?? false,
            IdEmpresa = empresaId
        };
    }

    /// <summary>
    /// Valida si un código ya existe en la empresa (excepto el ID especificado)
    /// Mapea: FrmCCosto.Valida()
    /// Query VB6: SELECT idCCosto FROM CentroCosto WHERE Codigo=@Codigo AND idCCosto NOT EQUAL @Id AND IdEmpresa=@EmpresaId
    /// </summary>
    public async Task<bool> ExisteCodigoAsync(string codigo, int empresaId, int? excludeId = null)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");

        if (string.IsNullOrWhiteSpace(codigo))
            throw new BusinessException("El código es requerido");

        var codigoUpper = codigo.Trim().ToUpper();

        var query = context.CentroCosto
            .Where(c => c.Codigo == codigoUpper && c.IdEmpresa == empresaId);

        if (excludeId.HasValue)
            query = query.Where(c => c.IdCCosto != excludeId.Value);

        var existe = await query.AnyAsync();

        if (existe)
            logger.LogDebug("Código ya existe: {Codigo} (excludeId={ExcludeId})", codigoUpper, excludeId);

        return existe;
    }
}
