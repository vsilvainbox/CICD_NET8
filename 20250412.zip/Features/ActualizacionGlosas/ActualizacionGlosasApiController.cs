using Microsoft.AspNetCore.Mvc;

namespace App.Features.ActualizacionGlosas;

[ApiController]
[Route("[controller]/[action]")]
public class ActualizacionGlosasApiController(
    IActualizacionGlosasService service,
    ILogger<ActualizacionGlosasApiController> logger) : ControllerBase
{
    [HttpPost]
    public async Task<ActionResult<GuardarGlosaResponse>> CreateGlosa([FromBody] GuardarGlosaRequest request)
    {
        logger.LogInformation("API: CreateGlosa called for empresaId: {EmpresaId}", request.IdEmpresa);

        var result = await service.CrearGlosaAsync(request.Glosa, request.IdEmpresa);
        return Ok(result);
    }

    [HttpGet]
    public async Task<ActionResult<List<GlosaDto>>> GetDatos([FromQuery] int empresaId)
    {
        logger.LogInformation("API: GetDatos called for empresaId: {EmpresaId}", empresaId);

        var glosas = await service.GetAllAsync(empresaId);
        return Ok(glosas);
    }

    [HttpPut]
    public async Task<ActionResult<GuardarGlosaResponse>> UpdateGlosa(int id, [FromBody] GuardarGlosaRequest request)
    {
        logger.LogInformation("API: UpdateGlosa called for idGlosa: {IdGlosa}, empresaId: {EmpresaId}",
            id, request.IdEmpresa);

        var result = await service.ActualizarGlosaAsync(id, request.Glosa, request.IdEmpresa, request.IdGlosa);
        return Ok(result);
    }

    [HttpGet]
    public async Task<ActionResult<GlosaDto>> ObtenerGlosa(int id, [FromQuery] int empresaId)
    {
        logger.LogInformation("API: ObtenerGlosa called for idGlosa: {IdGlosa}, empresaId: {EmpresaId}",
            id, empresaId);

        var glosa = await service.ObtenerGlosaAsync(id, empresaId);
        return Ok(glosa);
    }

    [HttpHead("{id}")]
    public async Task<ActionResult> ExisteGlosa(int id, [FromQuery] int empresaId)
    {
        logger.LogInformation("API: ExisteGlosa called for idGlosa: {IdGlosa}, empresaId: {EmpresaId}",
            id, empresaId);

        await service.ExisteGlosaAsync(id, empresaId);
        return Ok();
    }
}
