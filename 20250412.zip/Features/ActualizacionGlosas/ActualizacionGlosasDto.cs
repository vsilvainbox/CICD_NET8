using System.ComponentModel.DataAnnotations;

namespace App.Features.ActualizacionGlosas;

/// <summary>
/// Request para guardar (crear o actualizar) una glosa
/// </summary>
public class GuardarGlosaRequest
{
    /// <summary>
    /// ID de la glosa (null para crear nueva, valor para actualizar)
    /// </summary>
    public int? IdGlosa { get; set; }

    /// <summary>
    /// ID de la empresa propietaria
    /// </summary>
    [Required(ErrorMessage = "El ID de empresa es obligatorio")]
    public int IdEmpresa { get; set; }

    /// <summary>
    /// Texto de la glosa (máximo 250 caracteres)
    /// </summary>
    [Required(ErrorMessage = "Debe ingresar una glosa")]
    [StringLength(250, ErrorMessage = "La glosa no puede exceder 250 caracteres")]
    [Display(Name = "Glosa")]
    public string Glosa { get; set; } = string.Empty;
}

/// <summary>
/// Response de guardado de glosa
/// </summary>
public class GuardarGlosaResponse
{
    /// <summary>
    /// ID de la glosa (generado para nuevas, mismo para actualizaciones)
    /// </summary>
    public int IdGlosa { get; set; }
    
    /// <summary>
    /// Texto de la glosa guardada
    /// </summary>
    public string Glosa { get; set; } = string.Empty;
}

/// <summary>
/// DTO para obtener una glosa
/// </summary>
public class GlosaDto
{
    /// <summary>
    /// ID de la glosa
    /// </summary>
    public int IdGlosa { get; set; }

    /// <summary>
    /// ID de la empresa propietaria
    /// </summary>
    public int IdEmpresa { get; set; }

    /// <summary>
    /// Texto de la glosa
    /// </summary>
    public string Glosa { get; set; } = string.Empty;
}

#region ViewModels

public class ActualizacionGlosasIndexViewModel
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
}

#endregion
