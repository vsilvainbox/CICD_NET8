using App.Data;
using App.Helpers;
using App.Exceptions;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;
using OfficeOpenXml.Style;

namespace App.Features.AsistentePpm;

/// <summary>
/// Servicio para gestionar el Asistente de Reajuste de PPM (Pagos Provisionales Mensuales)
/// </summary>
public class AsistentePpmService(LpContabContext context, ILogger<AsistentePpmService> logger) : IAsistentePpmService
{
    private readonly LpContabContext _context = context ?? throw new ArgumentNullException(nameof(context));
    private readonly ILogger<AsistentePpmService> _logger = logger ?? throw new ArgumentNullException(nameof(logger));

    // Constantes de tipo y estado de comprobante (según VB6: HyperComun.bas)
    private const int TC_EGRESO = 1;       // Tipo Comprobante: Egreso
    private const int EC_APROBADO = 2;     // Estado Comprobante: Aprobado

    /// <inheritdoc/>
    public async Task<AsistentePpmObligatorioDto> GetPpmObligatorioAsync(int empresaId, short ano)
    {
        ValidarParametros(empresaId, ano);

        _logger.LogInformation("Obteniendo PPM Obligatorio para empresa {EmpresaId} año {Ano}", empresaId, ano);

        // Obtener configuración de cuenta PPM Obligatorio
        var paramCtaOblig = await _context.ParamEmpresa
            .Where(p => p.IdEmpresa == empresaId &&
                        p.Ano == ano &&
                        p.Tipo == "CTAPPMOBLI")
            .FirstOrDefaultAsync();

        if (paramCtaOblig == null || string.IsNullOrWhiteSpace(paramCtaOblig.Valor))
        {
            _logger.LogWarning("No existe configuración de cuenta PPM Obligatorio para empresa {EmpresaId} año {Ano}", empresaId, ano);
            return new AsistentePpmObligatorioDto();
        }

        if (!int.TryParse(paramCtaOblig.Valor, out var idCuentaOblig))
        {
            _logger.LogWarning("Valor de cuenta PPM Obligatorio no es un número válido: {Valor}", paramCtaOblig.Valor);
            return new AsistentePpmObligatorioDto();
        }

        // Obtener configuración de fecha 20/Enero
        var (excluirHasta20Enero, fecha20Enero) = await GetConfiguracionFecha20EneroAsync(empresaId, ano);

        // Cargar factores de actualización en memoria para mejor rendimiento
        var factoresCache = await CargarFactoresActualizacionAsync(ano);

        // Query principal: Comprobantes de egreso aprobados en la cuenta configurada
        var query = from mc in _context.MovComprobante
                    join c in _context.Comprobante on mc.IdComp equals c.IdComp
                    where mc.IdEmpresa == empresaId &&
                          mc.IdCuenta == idCuentaOblig &&
                          c.Tipo == TC_EGRESO &&
                          c.Estado == EC_APROBADO
                    orderby c.Fecha ascending
                    select new
                    {
                        Fecha = c.Fecha,
                        Debe = mc.Debe
                    };

        var resultados = await query.ToListAsync();

        // Verificar si hay registros excluidos (para mostrar botón de configuración)
        var hayRegistrosExcluidos = false;
        if (excluirHasta20Enero)
        {
            var fechaLimiteInt = DateHelper.ToDbDate(fecha20Enero);
            hayRegistrosExcluidos = resultados.Any(r => r.Fecha < fechaLimiteInt);
        }

        // Procesar registros
        var registros = new List<AsistentePpmRegistroDto>();
        decimal totalMonto = 0;
        decimal totalMontoActualizado = 0;

        foreach (var r in resultados)
        {
            if (r.Fecha == null || r.Debe == null)
                continue;

            var fechaPago = DateHelper.FromDbDate(r.Fecha.Value);

            // Aplicar filtro de fecha 20/Enero si corresponde
            if (excluirHasta20Enero && fechaPago < fecha20Enero)
                continue;

            var monto = (decimal)r.Debe.Value;

            // Buscar factor de actualización
            var factor = ObtenerFactorActualizacion(factoresCache, (short)fechaPago.Year, (byte)fechaPago.Month);
            var montoActualizado = monto * factor;

            registros.Add(new AsistentePpmRegistroDto
            {
                FechaPago = fechaPago,
                Monto = monto,
                MontoActualizado = montoActualizado
            });

            totalMonto += monto;
            totalMontoActualizado += montoActualizado;
        }

        var reajuste = totalMontoActualizado - totalMonto;

        _logger.LogInformation("PPM Obligatorio: {Count} registros, Total: {Total}, Reajuste: {Reajuste}",
            registros.Count, totalMonto, reajuste);

        return new AsistentePpmObligatorioDto
        {
            Registros = registros,
            TotalMonto = totalMonto,
            TotalMontoActualizado = totalMontoActualizado,
            Reajuste = reajuste,
            MostrarBotonConfiguracion = hayRegistrosExcluidos
        };
    }

    /// <inheritdoc/>
    public async Task<AsistentePpmVoluntarioDto> GetPpmVoluntarioAsync(int empresaId, short ano)
    {
        ValidarParametros(empresaId, ano);

        _logger.LogInformation("Obteniendo PPM Voluntario para empresa {EmpresaId} año {Ano}", empresaId, ano);

        // Obtener configuración de cuenta PPM Voluntario
        var paramCtaVolu = await _context.ParamEmpresa
            .Where(p => p.IdEmpresa == empresaId &&
                        p.Ano == ano &&
                        p.Tipo == "CTAPPMVOLU")
            .FirstOrDefaultAsync();

        if (paramCtaVolu == null || string.IsNullOrWhiteSpace(paramCtaVolu.Valor))
        {
            _logger.LogWarning("No existe configuración de cuenta PPM Voluntario para empresa {EmpresaId} año {Ano}", empresaId, ano);
            return new AsistentePpmVoluntarioDto();
        }

        if (!int.TryParse(paramCtaVolu.Valor, out var idCuentaVolu))
        {
            _logger.LogWarning("Valor de cuenta PPM Voluntario no es un número válido: {Valor}", paramCtaVolu.Valor);
            return new AsistentePpmVoluntarioDto();
        }

        // Cargar factores de actualización en memoria
        var factoresCache = await CargarFactoresActualizacionAsync(ano);

        // Query principal: Comprobantes de egreso aprobados en la cuenta configurada
        // Nota: PPM Voluntario NO aplica filtro de fecha 20/Enero
        var query = from mc in _context.MovComprobante
                    join c in _context.Comprobante on mc.IdComp equals c.IdComp
                    where mc.IdEmpresa == empresaId &&
                          mc.IdCuenta == idCuentaVolu &&
                          c.Tipo == TC_EGRESO &&
                          c.Estado == EC_APROBADO
                    orderby c.Fecha ascending
                    select new
                    {
                        Fecha = c.Fecha,
                        Debe = mc.Debe
                    };

        var resultados = await query.ToListAsync();

        // Procesar registros
        var registros = new List<AsistentePpmRegistroDto>();
        decimal totalMonto = 0;
        decimal totalMontoActualizado = 0;

        foreach (var r in resultados)
        {
            if (r.Fecha == null || r.Debe == null)
                continue;

            var fechaPago = DateHelper.FromDbDate(r.Fecha.Value);
            var monto = (decimal)r.Debe.Value;

            // Buscar factor de actualización
            var factor = ObtenerFactorActualizacion(factoresCache, (short)fechaPago.Year, (byte)fechaPago.Month);
            var montoActualizado = monto * factor;

            registros.Add(new AsistentePpmRegistroDto
            {
                FechaPago = fechaPago,
                Monto = monto,
                MontoActualizado = montoActualizado
            });

            totalMonto += monto;
            totalMontoActualizado += montoActualizado;
        }

        var reajuste = totalMontoActualizado - totalMonto;

        _logger.LogInformation("PPM Voluntario: {Count} registros, Total: {Total}, Reajuste: {Reajuste}",
            registros.Count, totalMonto, reajuste);

        return new AsistentePpmVoluntarioDto
        {
            Registros = registros,
            TotalMonto = totalMonto,
            TotalMontoActualizado = totalMontoActualizado,
            Reajuste = reajuste
        };
    }

    /// <inheritdoc/>
    public async Task<AsistentePpmTotalTraspasoDto> GetTotalTraspasoAsync(int empresaId, short ano)
    {
        // Nota: No se valida aquí porque GetPpmObligatorioAsync y GetPpmVoluntarioAsync ya validan
        _logger.LogInformation("Calculando total traspaso para empresa {EmpresaId} año {Ano}", empresaId, ano);

        var obligatorio = await GetPpmObligatorioAsync(empresaId, ano);
        var voluntario = await GetPpmVoluntarioAsync(empresaId, ano);

        var totalTraspaso = obligatorio.Reajuste + voluntario.Reajuste;

        _logger.LogInformation("Total traspaso: {Total} (Obligatorio: {Oblig}, Voluntario: {Volun})",
            totalTraspaso, obligatorio.Reajuste, voluntario.Reajuste);

        return new AsistentePpmTotalTraspasoDto
        {
            ReajusteObligatorio = obligatorio.Reajuste,
            ReajusteVoluntario = voluntario.Reajuste,
            TotalTraspaso = totalTraspaso
        };
    }

    /// <inheritdoc/>
    public async Task<AsistentePpmConfiguracionDto> GetConfiguracionAsync(int empresaId, short ano)
    {
        ValidarParametros(empresaId, ano);

        _logger.LogInformation("Obteniendo configuración para empresa {EmpresaId} año {Ano}", empresaId, ano);

        // Obtener configuración de fecha 20/Enero
        var paramPpm = await _context.ParamEmpresa
            .Where(p => p.IdEmpresa == empresaId &&
                        p.Ano == ano &&
                        p.Tipo == "PPM")
            .FirstOrDefaultAsync();

        var excluirHasta20Enero = paramPpm?.Valor == "1";

        // Obtener cuenta PPM Obligatorio
        var paramCtaOblig = await _context.ParamEmpresa
            .Where(p => p.IdEmpresa == empresaId &&
                        p.Ano == ano &&
                        p.Tipo == "CTAPPMOBLI")
            .FirstOrDefaultAsync();

        int? idCuentaOblig = int.TryParse(paramCtaOblig?.Valor, out var ctaOblig) ? ctaOblig : null;

        // Obtener cuenta PPM Voluntario
        var paramCtaVolu = await _context.ParamEmpresa
            .Where(p => p.IdEmpresa == empresaId &&
                        p.Ano == ano &&
                        p.Tipo == "CTAPPMVOLU")
            .FirstOrDefaultAsync();

        int? idCuentaVolu = int.TryParse(paramCtaVolu?.Valor, out var ctaVolu) ? ctaVolu : null;

        // Verificar si existen registros excluidos
        var existenRegistrosExcluidos = false;
        if (excluirHasta20Enero && idCuentaOblig.HasValue)
        {
            var fecha20Enero = new DateTime(ano, 1, 20);
            var fechaLimiteInt = DateHelper.ToDbDate(fecha20Enero);

            existenRegistrosExcluidos = await _context.MovComprobante
                .Join(_context.Comprobante, mc => mc.IdComp, c => c.IdComp, (mc, c) => new { mc, c })
                .AnyAsync(x => x.mc.IdEmpresa == empresaId &&
                               x.mc.IdCuenta == idCuentaOblig.Value &&
                               x.c.Tipo == TC_EGRESO &&
                               x.c.Estado == EC_APROBADO &&
                               x.c.Fecha < fechaLimiteInt);
        }

        return new AsistentePpmConfiguracionDto
        {
            ExcluirHasta20Enero = excluirHasta20Enero,
            IdCuentaObligatoria = idCuentaOblig,
            IdCuentaVoluntaria = idCuentaVolu,
            ExistenRegistrosExcluidos = existenRegistrosExcluidos
        };
    }

    /// <inheritdoc/>
    public async Task ActualizarConfiguracionAsync(int empresaId, short ano, bool excluirHasta20Enero)
    {
        ValidarParametros(empresaId, ano);

        _logger.LogInformation("Actualizando configuración PPM para empresa {EmpresaId} año {Ano}: Excluir={Excluir}",
            empresaId, ano, excluirHasta20Enero);

        // Buscar parámetro PPM existente
        var paramPpm = await _context.ParamEmpresa
            .Where(p => p.IdEmpresa == empresaId &&
                        p.Ano == ano &&
                        p.Tipo == "PPM")
            .FirstOrDefaultAsync();

        var nuevoValor = excluirHasta20Enero ? "1" : "0";

        if (paramPpm != null)
        {
            // Actualizar existente
            paramPpm.Valor = nuevoValor;
        }
        else
        {
            // Crear nuevo registro
            var nuevoParam = new App.Data.ParamEmpresa
            {
                IdEmpresa = empresaId,
                Ano = ano,
                Tipo = "PPM",
                Valor = nuevoValor
            };
            _context.ParamEmpresa.Add(nuevoParam);
        }

        var filasAfectadas = await _context.SaveChangesAsync();

        if (filasAfectadas == 0)
            throw new BusinessException("No se pudo actualizar la configuración");

        _logger.LogInformation("Configuración actualizada correctamente. Filas afectadas: {Filas}", filasAfectadas);
    }

    /// <inheritdoc/>
    public async Task<byte[]> ExportarExcelAsync(int empresaId, short ano)
    {
        // Nota: No se valida aquí porque GetPpmObligatorioAsync y GetPpmVoluntarioAsync ya validan
        _logger.LogInformation("Exportando reporte PPM a Excel para empresa {EmpresaId} año {Ano}", empresaId, ano);

        var obligatorio = await GetPpmObligatorioAsync(empresaId, ano);
        var voluntario = await GetPpmVoluntarioAsync(empresaId, ano);
        var totalTraspaso = await GetTotalTraspasoAsync(empresaId, ano);

        using var package = new ExcelPackage();
        var worksheet = package.Workbook.Worksheets.Add("Reajuste PPM");

        var filaActual = 1;

        // --- SECCIÓN PPM OBLIGATORIO ---
        worksheet.Cells[filaActual, 1].Value = "Reajuste PPM Obligatorio";
        worksheet.Cells[filaActual, 3].Value = $"Año {ano}";
        worksheet.Cells[filaActual, 1, filaActual, 3].Style.Font.Bold = true;
        worksheet.Cells[filaActual, 1, filaActual, 3].Style.Font.Size = 12;
        filaActual += 2;

        // Headers
        worksheet.Cells[filaActual, 1].Value = "FECHA PAGO";
        worksheet.Cells[filaActual, 2].Value = "MONTO";
        worksheet.Cells[filaActual, 3].Value = "MONTO ACTUALIZADO";
        worksheet.Cells[filaActual, 1, filaActual, 3].Style.Font.Bold = true;
        worksheet.Cells[filaActual, 1, filaActual, 3].Style.Fill.PatternType = ExcelFillStyle.Solid;
        worksheet.Cells[filaActual, 1, filaActual, 3].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightGray);
        filaActual++;

        // Datos
        foreach (var reg in obligatorio.Registros)
        {
            worksheet.Cells[filaActual, 1].Value = reg.FechaPago.ToString("dd/MM/yyyy");
            worksheet.Cells[filaActual, 2].Value = reg.Monto;
            worksheet.Cells[filaActual, 3].Value = reg.MontoActualizado;
            worksheet.Cells[filaActual, 2].Style.Numberformat.Format = "#,##0";
            worksheet.Cells[filaActual, 3].Style.Numberformat.Format = "#,##0";
            filaActual++;
        }

        // Totales
        filaActual++;
        worksheet.Cells[filaActual, 1].Value = "TOTALES";
        worksheet.Cells[filaActual, 2].Value = obligatorio.TotalMonto;
        worksheet.Cells[filaActual, 3].Value = obligatorio.TotalMontoActualizado;
        worksheet.Cells[filaActual, 1, filaActual, 3].Style.Font.Bold = true;
        worksheet.Cells[filaActual, 2].Style.Numberformat.Format = "#,##0";
        worksheet.Cells[filaActual, 3].Style.Numberformat.Format = "#,##0";
        filaActual += 2;

        // Reajuste
        worksheet.Cells[filaActual, 1].Value = "REAJUSTE";
        worksheet.Cells[filaActual, 3].Value = obligatorio.Reajuste;
        worksheet.Cells[filaActual, 1, filaActual, 3].Style.Font.Bold = true;
        worksheet.Cells[filaActual, 3].Style.Numberformat.Format = "#,##0";
        filaActual += 3;

        // --- SECCIÓN PPM VOLUNTARIO ---
        worksheet.Cells[filaActual, 1].Value = "Reajuste PPM Voluntario";
        worksheet.Cells[filaActual, 3].Value = $"Año {ano}";
        worksheet.Cells[filaActual, 1, filaActual, 3].Style.Font.Bold = true;
        worksheet.Cells[filaActual, 1, filaActual, 3].Style.Font.Size = 12;
        filaActual += 2;

        // Headers
        worksheet.Cells[filaActual, 1].Value = "FECHA PAGO";
        worksheet.Cells[filaActual, 2].Value = "MONTO";
        worksheet.Cells[filaActual, 3].Value = "MONTO ACTUALIZADO";
        worksheet.Cells[filaActual, 1, filaActual, 3].Style.Font.Bold = true;
        worksheet.Cells[filaActual, 1, filaActual, 3].Style.Fill.PatternType = ExcelFillStyle.Solid;
        worksheet.Cells[filaActual, 1, filaActual, 3].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightGray);
        filaActual++;

        // Datos
        foreach (var reg in voluntario.Registros)
        {
            worksheet.Cells[filaActual, 1].Value = reg.FechaPago.ToString("dd/MM/yyyy");
            worksheet.Cells[filaActual, 2].Value = reg.Monto;
            worksheet.Cells[filaActual, 3].Value = reg.MontoActualizado;
            worksheet.Cells[filaActual, 2].Style.Numberformat.Format = "#,##0";
            worksheet.Cells[filaActual, 3].Style.Numberformat.Format = "#,##0";
            filaActual++;
        }

        // Totales
        filaActual++;
        worksheet.Cells[filaActual, 1].Value = "TOTALES";
        worksheet.Cells[filaActual, 2].Value = voluntario.TotalMonto;
        worksheet.Cells[filaActual, 3].Value = voluntario.TotalMontoActualizado;
        worksheet.Cells[filaActual, 1, filaActual, 3].Style.Font.Bold = true;
        worksheet.Cells[filaActual, 2].Style.Numberformat.Format = "#,##0";
        worksheet.Cells[filaActual, 3].Style.Numberformat.Format = "#,##0";
        filaActual += 2;

        // Reajuste
        worksheet.Cells[filaActual, 1].Value = "REAJUSTE";
        worksheet.Cells[filaActual, 3].Value = voluntario.Reajuste;
        worksheet.Cells[filaActual, 1, filaActual, 3].Style.Font.Bold = true;
        worksheet.Cells[filaActual, 3].Style.Numberformat.Format = "#,##0";
        filaActual += 3;

        // --- TOTAL TRASPASO ---
        worksheet.Cells[filaActual, 1].Value = "Total a Traspasar";
        worksheet.Cells[filaActual, 2].Value = totalTraspaso.TotalTraspaso;
        worksheet.Cells[filaActual, 1, filaActual, 2].Style.Font.Bold = true;
        worksheet.Cells[filaActual, 1, filaActual, 2].Style.Font.Size = 12;
        worksheet.Cells[filaActual, 2].Style.Numberformat.Format = "#,##0";

        // Ajustar anchos de columna
        worksheet.Column(1).Width = 15;
        worksheet.Column(2).Width = 15;
        worksheet.Column(3).Width = 20;

        _logger.LogInformation("Reporte Excel generado exitosamente");

        return package.GetAsByteArray();
    }

    #region Métodos Privados

    /// <summary>
    /// Valida los parámetros comunes de empresa y año
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">Año fiscal</param>
    /// <exception cref="BusinessException">Si los parámetros no son válidos</exception>
    private void ValidarParametros(int empresaId, short ano)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");

        if (ano < 2000 || ano > 2100)
            throw new BusinessException("El año debe estar entre 2000 y 2100");
    }

    /// <summary>
    /// Obtiene la configuración de fecha 20/Enero y si debe excluir registros anteriores
    /// </summary>
    private async Task<(bool ExcluirHasta20Enero, DateTime Fecha20Enero)> GetConfiguracionFecha20EneroAsync(int empresaId, short ano)
    {
        var paramPpm = await _context.ParamEmpresa
            .Where(p => p.IdEmpresa == empresaId &&
                        p.Ano == ano &&
                        p.Tipo == "PPM")
            .FirstOrDefaultAsync();

        var excluirHasta20Enero = paramPpm?.Valor == "1";
        var fecha20Enero = new DateTime(ano, 1, 20);

        return (excluirHasta20Enero, fecha20Enero);
    }

    /// <summary>
    /// Carga factores de actualización en memoria para mejor rendimiento
    /// </summary>
    private async Task<Dictionary<(short ano, byte MesRow), double>> CargarFactoresActualizacionAsync(short ano)
    {
        var factores = await _context.FactorActAnual
            .Where(f => f.Ano == ano && f.MesCol == 12)  // Siempre actualizar a diciembre
            .Select(f => new
            {
                f.Ano,
                f.MesRow,
                f.Factor
            })
            .ToListAsync();

        var cache = new Dictionary<(short ano, byte MesRow), double>();

        foreach (var f in factores)
        {
            if (f.Ano.HasValue && f.MesRow.HasValue && f.Factor.HasValue)
            {
                cache[(f.Ano.Value, f.MesRow.Value)] = f.Factor.Value;
            }
        }

        _logger.LogDebug("Cargados {Count} factores de actualización para año {Ano}", cache.Count, ano);

        return cache;
    }

    /// <summary>
    /// Obtiene el factor de actualización para un año/mes desde el cache
    /// Si no existe, retorna 1.0 (sin actualización)
    /// </summary>
    private decimal ObtenerFactorActualizacion(Dictionary<(short ano, byte MesRow), double> cache, short ano, byte mes)
    {
        if (cache.TryGetValue((ano, mes), out var factor))
        {
            return (decimal)factor;
        }

        _logger.LogWarning("No existe factor de actualización para año {Ano} mes {Mes}. Usando factor 1.0", ano, mes);
        return 1.0m;
    }

    #endregion
}
