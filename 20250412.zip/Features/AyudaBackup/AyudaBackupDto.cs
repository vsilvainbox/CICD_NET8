namespace App.Features.AyudaBackup;

/// <summary>
/// DTO principal para el contenido de ayuda de backup
/// </summary>
public class AyudaBackupDto
{
    public string Titulo { get; set; } = string.Empty;
    public string ContenidoCompleto { get; set; } = string.Empty;
    public string ApplicationTitle { get; set; } = string.Empty;
    public string ApplicationPath { get; set; } = string.Empty;
    public string FechaFormateada { get; set; } = string.Empty;
    public bool EsBaseDatosMySQL { get; set; }
    public string MensajeEspecialMySQL { get; set; } = string.Empty;
}

/// <summary>
/// DTO para información de la aplicación
/// </summary>
public class ApplicationInfoDto
{
    public string Title { get; set; } = string.Empty;
    public string Path { get; set; } = string.Empty;
    public string Version { get; set; } = string.Empty;
}

/// <summary>
/// DTO para tipo de base de datos
/// </summary>
public class DatabaseTypeDto
{
    public string TipoBD { get; set; } = string.Empty;
    public bool EsMySQL { get; set; }
    public bool EsSQLite { get; set; }
    public bool EsSQLServer { get; set; }
}