using System.Text;

namespace App.Features.AyudaBackup;

/// <summary>
/// Servicio para gestión de ayuda de backup
/// Replica exactamente la funcionalidad del formulario VB6 FrmHlpBackup
/// </summary>
public class AyudaBackupService(IConfiguration configuration, ILogger<AyudaBackupService> logger) : IAyudaBackupService
{
    /// <inheritdoc/>
    public async Task<AyudaBackupDto> GetHelpContentAsync()
    {
        logger.LogInformation("Generating backup help content");

        {
            var appInfo = await GetApplicationInfoAsync();
            var dbType = await GetDatabaseTypeAsync();
            var fechaFormateada = await GetFormattedDateForBackupAsync();

            var contenido = await BuildHelpMessageAsync(appInfo, dbType, fechaFormateada);

            var result = new AyudaBackupDto
            {
                Titulo = "¿ Respaldó su información esta semana ?",
                ContenidoCompleto = contenido,
                ApplicationTitle = appInfo.Title,
                ApplicationPath = appInfo.Path,
                FechaFormateada = fechaFormateada,
                EsBaseDatosMySQL = dbType.EsMySQL,
                MensajeEspecialMySQL = dbType.EsMySQL ? 
                    "En esta versión la base de datos está en un servidor MySQL, debe solicitar la asistencia de un técnico para realizar el respado de los datos." : 
                    string.Empty
            };

            logger.LogInformation("Successfully generated backup help content for app: {AppTitle}", appInfo.Title);
            return result;
        }
    }

    /// <inheritdoc/>
    public async Task<ApplicationInfoDto> GetApplicationInfoAsync()
    {
        logger.LogInformation("Getting application information");

        {
            var result = new ApplicationInfoDto
            {
                Title = configuration["Application:Title"] ?? "HyperContabilidad",
                Path = configuration["Application:DataPath"] ?? Path.Combine(Directory.GetCurrentDirectory(), "Data"),
                Version = configuration["Application:Version"] ?? "9.0.0"
            };

            logger.LogInformation("Application info retrieved: {Title} at {Path}", result.Title, result.Path);
            return await Task.FromResult(result);
        }
    }

    /// <inheritdoc/>
    public async Task<DatabaseTypeDto> GetDatabaseTypeAsync()
    {
        logger.LogInformation("Detecting database type");

        {
            var connectionString = configuration.GetConnectionString("DefaultConnection") ?? string.Empty;
                
            var result = new DatabaseTypeDto();
                
            if (connectionString.ToLower().Contains("mysql"))
            {
                result.TipoBD = "MySQL";
                result.EsMySQL = true;
            }
            else if (connectionString.ToLower().Contains("sqlserver") || connectionString.ToLower().Contains("server="))
            {
                result.TipoBD = "SQL Server";
                result.EsSQLServer = true;
            }
            else
            {
                result.TipoBD = "SQLite";
                result.EsSQLite = true;
            }

            logger.LogInformation("Database type detected: {TipoBD}", result.TipoBD);
            return await Task.FromResult(result);
        }
    }

    /// <inheritdoc/>
    public async Task<string> GetFormattedDateForBackupAsync()
    {
        logger.LogInformation("Formatting current date for backup folder naming");

        {
            // Replica el formato VB6 FmtFecha(Now) - formato DD-MM-YYYY
            var fecha = DateTime.Now.ToString("dd-MM-yyyy");
                
            logger.LogInformation("Formatted date for backup: {Fecha}", fecha);
            return await Task.FromResult(fecha);
        }
    }

    /// <summary>
    /// Construye el mensaje de ayuda completo replicando exactamente el VB6
    /// </summary>
    private async Task<string> BuildHelpMessageAsync(ApplicationInfoDto appInfo, DatabaseTypeDto dbType, string fechaFormateada)
    {
        logger.LogInformation("Building complete help message");

        {
            var sb = new StringBuilder();

            // Título importante
            sb.AppendLine("* * *  IMPORTANTE  * * *");
            sb.AppendLine();

            // Párrafo sobre importancia
            sb.AppendLine("Es de suma importancia realizar respaldos de la información en forma periódica. Es responsabilidad del usuario o empresa definir una política adecuada al respecto.");
            sb.AppendLine();

            // Consecuencias de pérdida
            sb.AppendLine("En el caso de la pérdida de información debido al ataque de un virus, la falla de un disco, etc., la única forma de recuperar y no perder el trabajo de meses, es recurrir a los respaldos.");
            sb.AppendLine();

            // Programas vs datos
            sb.AppendLine("Los programas pueden ser instalados nuevamente, pero si no hay respaldos, la información ingresada se perderá irremediablemente.");
            sb.AppendLine();

            // Medios externos
            sb.AppendLine("Los respaldos deben se hechos en un medio externo, no deben ser hechos en el mismo disco o en el mismo equipo en que se encuentra la aplicación. Un virus puede destruir el contenido de todo el disco o los discos del equipo, o bien puede fallar el disco en que se hizo el respaldo.");
            sb.AppendLine();

            // Verificación y almacenamiento
            sb.AppendLine("Es importante verificar que los respaldos queden bien hechos, de modo que cuando se necesiten puedan ser utilizados. Para esto es bueno probar a recuperar un respaldo y ver si la información es la correcta.");
            sb.Append(" Los dispositivos donde se hace el respaldo (ej CDs), es recomendable que se almacenen fuera de la oficina.");
            sb.AppendLine();
            sb.AppendLine();

            // Medios recomendados
            sb.AppendLine("Una forma segura, sencilla y económica es utilizar CDs o DVDs. Estos permiten almacenar gran cantidad de información.");
            sb.AppendLine();

            // Carpeta específica - dinámico según aplicación
            sb.AppendLine($"Para nuestra aplicación {appInfo.Title}, usted debería respaldar toda la carpeta '{appInfo.Path}'.");
            sb.AppendLine();

            // Mensaje especial para MySQL
            if (dbType.EsMySQL)
            {
                sb.AppendLine("En esta versión la base de datos está en un servidor MySQL, debe solicitar la asistencia de un técnico para realizar el respado de los datos.");
                sb.AppendLine();
            }

            // Instrucciones con fecha dinámica
            sb.AppendLine($"Si el respaldo lo hace hoy, cree en el CD una carpeta llamada '{fechaFormateada}'. En esta carpeta agregue el contenido de la carpeta '{appInfo.Path}' y toda otra información importante para usted.");
            sb.AppendLine("En el siguiente respaldo, utilice otro CD, cree una carpeta con la nueva fecha y agregue en esta nueva carpeta su información.");
            sb.AppendLine();

            // Estrategia múltiples CDs
            sb.AppendLine("Si sólo respalda esta aplicación en el CD, seguramente podrá realizar varios respaldos en el mismo CD. Sin embargo, no sería recomendable tener más de cuatro respaldos seguidos en el mismo CD, porque si éste se daña se pierde toda su información.");
            sb.AppendLine();

            // Rotación de CDs
            sb.AppendLine("Se recomienda tener dos o más CDs (CD1, CD2, CD3, ...) e ir usando un CD distinto cada vez, primero el CD1, luego el CD2, después el CD3, ... luego nuevamente el CD1 y así. De ese modo si se daña un CD quedan los otros.");
            sb.AppendLine();

            // Recomendación final
            sb.AppendLine("Recuerde mantener actualizado su Antivirus y chequear periódicamente sus discos para reducir los riesgos.");

            var resultado = sb.ToString();
            logger.LogInformation("Successfully built help message with {Length} characters", resultado.Length);

            return await Task.FromResult(resultado);
        }
    }
}