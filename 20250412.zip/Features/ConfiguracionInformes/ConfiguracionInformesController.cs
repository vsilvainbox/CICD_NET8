﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Extensions;
using App.Helpers;

namespace App.Features.ConfiguracionInformes;

/// <summary>
/// MVC Controller para configuración de informes
/// </summary>
public class ConfiguracionInformesController(
    IHttpClientFactory httpClientFactory,
    ILogger<ConfiguracionInformesController> logger, LinkGenerator linkGenerator) : Controller
{
    /// <summary>
    /// Vista principal de configuración de informes
    /// </summary>
    public IActionResult Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a la Configuración de Informes";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        // Extraer datos de HttpContext usando extensiones
        var empresaId = SessionHelper.EmpresaId;
        int ano = SessionHelper.Ano;

        logger.LogInformation("Accediendo a configuración de informes. EmpresaId: {EmpresaId}, año: {Ano}",
            empresaId, ano);

        var viewModel = new ConfiguracionInformesIndexViewModel
        {
            EmpresaId = empresaId,
            Ano = ano
        };

        return View(viewModel);
    }

    /// <summary>
    /// Proxy: Obtener configuración de informes
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetConfiguracion(int empresaId, short ano)
    {
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionInformesApiController>(
            HttpContext,
            nameof(ConfiguracionInformesApiController.GetConfiguracion),
            new { empresaId, ano });

        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Proxy: Guardar configuración de informes
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Guardar([FromBody] JsonElement request)
    {
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionInformesApiController>(
            HttpContext,
            nameof(ConfiguracionInformesApiController.GuardarConfiguracion));

        var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
        return new ContentResult
        {
            Content = content,
            ContentType = "application/json",
            StatusCode = statusCode
        };
    }
}