using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Extensions;
using System.Linq;
using App.Helpers;

namespace App.Features.CentrosCosto;

/// <summary>
/// Controller MVC para Centros de Costo
/// Migración de FrmCentrosCosto.frm (VB6)
/// </summary>

public class CentrosCostoController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<CentrosCostoController> logger) : Controller
{
    /// <summary>
    /// Vista principal de Centros de Costo
    /// Mapeo VB6: FrmCentrosCosto.FEdit() - modo edición completa
    /// GET /CentrosCosto
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Centros de Costo";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        var empresaId = SessionHelper.EmpresaId;
        logger.LogInformation("Loading CentrosCosto index for empresaId: {EmpresaId}", empresaId);

        {
            // Cargar datos iniciales desde API interna
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<CentrosCostoApiController>(
                HttpContext,
                nameof(CentrosCostoApiController.GetAll),
                new { empresaId }
            );
            var centrosCosto = await client.GetFromApiAsync<List<CentrosCostoDto>>(url!);

            logger.LogInformation("Successfully loaded {Count} centros costo for empresaId: {EmpresaId}",
                centrosCosto?.Count ?? 0, empresaId);

            return View(centrosCosto ?? new List<CentrosCostoDto>());
        }
    }

    /// <summary>
    /// Proxy: Obtener todos los centros de costo
    /// GET /CentrosCosto/GetAll
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetAll(int empresaId)
    {
        logger.LogInformation("Proxy: GetAll centros costo for empresaId: {EmpresaId}", empresaId);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<CentrosCostoApiController>(
            HttpContext,
            nameof(CentrosCostoApiController.GetAll),
            new { empresaId }
        );
        var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
    }

    /// <summary>
    /// Proxy: Obtener centro de costo por ID
    /// GET /CentrosCosto/GetById
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetById(int id, int empresaId)
    {
        logger.LogInformation("Proxy: GetById centro costo {Id} for empresaId: {EmpresaId}", id, empresaId);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<CentrosCostoApiController>(
            HttpContext,
            nameof(CentrosCostoApiController.GetById),
            new { id, empresaId }
        );
        var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
    }

    /// <summary>
    /// Proxy: Verificar si puede eliminarse
    /// GET /CentrosCosto/CanDelete
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> CanDelete(int id, int empresaId)
    {
        logger.LogInformation("Proxy: CanDelete centro costo {Id} for empresaId: {EmpresaId}", id, empresaId);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<CentrosCostoApiController>(
            HttpContext,
            nameof(CentrosCostoApiController.CanDelete),
            new { id, empresaId }
        );
        var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
    }

    /// <summary>
    /// Proxy: Crear centro de costo
    /// POST /CentrosCosto/Create
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] JsonElement request)
    {
        var empresaId = SessionHelper.EmpresaId;
        logger.LogInformation("Proxy: Create centro costo for empresaId: {EmpresaId}", empresaId);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<CentrosCostoApiController>(
            HttpContext,
            nameof(CentrosCostoApiController.Create),
            new { empresaId }
        );
        var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return new ContentResult
            {
                Content = content,
                ContentType = "application/json",
                StatusCode = statusCode
            };
    }

    /// <summary>
    /// Proxy: Actualizar centro de costo
    /// PUT /CentrosCosto/Update
    /// </summary>
    [HttpPut]
    public async Task<IActionResult> Update(int id, [FromBody] JsonElement request)
    {
        var empresaId = SessionHelper.EmpresaId;
        logger.LogInformation("Proxy: Update centro costo {Id} for empresaId: {EmpresaId}", id, empresaId);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<CentrosCostoApiController>(
            HttpContext,
            nameof(CentrosCostoApiController.Update),
            new { id, empresaId }
        );
        var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Put);
            return new ContentResult
            {
                Content = content,
                ContentType = "application/json",
                StatusCode = statusCode
            };
    }

    /// <summary>
    /// Proxy: Eliminar centro de costo
    /// DELETE /CentrosCosto/Delete
    /// </summary>
    [HttpDelete]
    public async Task<IActionResult> Delete(int id, int empresaId)
    {
        logger.LogInformation("Proxy: Delete centro costo {Id} for empresaId: {EmpresaId}", id, empresaId);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<CentrosCostoApiController>(
            HttpContext,
            nameof(CentrosCostoApiController.Delete),
            new { id, empresaId }
        );
        var (statusCode, content) = await client.ProxyRequestAsync(url!, null, HttpMethod.Delete);
            return new ContentResult
            {
                Content = content,
                ContentType = "application/json",
                StatusCode = statusCode
            };
    }

    /// <summary>
    /// Guardar formulario con DTO tipado y validaciones automáticas
    /// POST /CentrosCosto/SaveForm
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> SaveForm([FromForm] CentrosCostoFormDto formDto)
    {
        var empresaId = SessionHelper.EmpresaId;
        logger.LogInformation("SaveForm centro costo for empresaId: {EmpresaId}, Id: {Id}",
            empresaId, formDto.IdCCosto);

        // Validar modelo con DataAnnotations
        if (!ModelState.IsValid)
        {
            logger.LogWarning("Validación fallida: {Errors}",
                string.Join(", ", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage)));
            return BadRequest(new {
                swalType = "warning",
                swalTitle = "Atención",
                errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage)
            });
        }

        var client = httpClientFactory.CreateClient();

        // Convertir a mayúsculas el código
        var data = new
        {
            codigo = formDto.Codigo.ToUpper(),
            descripcion = formDto.Descripcion,
            vigente = formDto.Vigente
        };

        // Determinar si es creación o actualización
        string? url;
        HttpMethod method;

        if (formDto.IdCCosto == 0)
        {
            // Crear nuevo
            url = linkGenerator.GetApiUrl<CentrosCostoApiController>(
                HttpContext,
                nameof(CentrosCostoApiController.Create),
                new { empresaId }
            );
            method = HttpMethod.Post;
        }
        else
        {
            // Actualizar existente
            url = linkGenerator.GetApiUrl<CentrosCostoApiController>(
                HttpContext,
                nameof(CentrosCostoApiController.Update),
                new { id = formDto.IdCCosto, empresaId }
            );
            method = HttpMethod.Put;
        }

        var (statusCode, content) = await client.ProxyRequestAsync(
            url!,
            JsonSerializer.SerializeToElement(data),
            method
        );

        return new ContentResult
        {
            Content = content,
            ContentType = "application/json",
            StatusCode = statusCode
        };
    }
}
