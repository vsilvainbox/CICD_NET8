using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Extensions;
using App.Helpers;

namespace App.Features.AreasNegocio;

/// <summary>
/// MVC Controller para gestión de Áreas de Negocio
/// Maneja la vista y actúa como proxy hacia la API
/// </summary>
public class AreasNegocioController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<AreasNegocioController> logger) : Controller
{
    /// <summary>
    /// Vista principal de Áreas de Negocio
    /// Carga el listado completo de áreas para la empresa en sesión
    /// </summary>
    public async Task<IActionResult> Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Áreas de Negocio";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        {
            // Obtener empresaId desde HttpContext usando extensión
            var empresaId = SessionHelper.EmpresaId;

            logger.LogInformation("Index: Cargando vista de áreas de negocio para empresaId={EmpresaId}", empresaId);

            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<AreasNegocioApiController>(
                HttpContext,
                nameof(AreasNegocioApiController.GetAll),
                new { empresaId }
            );
            var areas = await client.GetFromApiAsync<List<AreasNegocioDto>>(url!);

            logger.LogInformation("Index: Áreas de negocio cargadas exitosamente. Total: {Count}", areas?.Count ?? 0);
            return View(areas ?? new List<AreasNegocioDto>());
        }
    }

    // Proxy methods for JavaScript to call (Vista → MVC → API pattern)

    /// <summary>
    /// MVC Proxy: Obtiene un área de negocio por ID
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetById(int id)
    {
        {
            // Obtener empresaId desde HttpContext usando extensión
            var empresaId = SessionHelper.EmpresaId;

            logger.LogInformation("GetById: Proxy call for id={Id}, empresaId={EmpresaId}", id, empresaId);
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<AreasNegocioApiController>(
                HttpContext,
                nameof(AreasNegocioApiController.GetById),
                new { id, empresaId }
            );
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// MVC Proxy: Crea un área de negocio
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] AreasNegocioCreateDto dto)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        // Obtener empresaId desde HttpContext usando extensión
        var empresaId = SessionHelper.EmpresaId;

        logger.LogInformation("Create: Proxy call for empresaId={EmpresaId}", empresaId);
        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AreasNegocioApiController>(
            HttpContext,
            nameof(AreasNegocioApiController.Create),
            new { empresaId }
        );

        // Convertir DTO a JsonElement para mantener compatibilidad con ProxyRequestAsync
        var jsonString = JsonSerializer.Serialize(dto);
        var jsonElement = JsonDocument.Parse(jsonString).RootElement;

        var (statusCode, content) = await client.ProxyRequestAsync(url!, jsonElement, HttpMethod.Post);
        return new ContentResult
        {
            Content = content,
            ContentType = "application/json",
            StatusCode = statusCode
        };
    }

    /// <summary>
    /// MVC Proxy: Actualiza un área de negocio
    /// </summary>
    [HttpPut]
    public async Task<IActionResult> Update(int id, [FromBody] AreasNegocioUpdateDto dto)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        // Obtener empresaId desde HttpContext usando extensión
        var empresaId = SessionHelper.EmpresaId;

        logger.LogInformation("Update: Proxy call for id={Id}, empresaId={EmpresaId}", id, empresaId);
        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AreasNegocioApiController>(
            HttpContext,
            nameof(AreasNegocioApiController.Update),
            new { id, empresaId }
        );

        // Convertir DTO a JsonElement para mantener compatibilidad con ProxyRequestAsync
        var jsonString = JsonSerializer.Serialize(dto);
        var jsonElement = JsonDocument.Parse(jsonString).RootElement;

        var (statusCode, content) = await client.ProxyRequestAsync(url!, jsonElement, HttpMethod.Put);
        return new ContentResult
        {
            Content = content,
            ContentType = "application/json",
            StatusCode = statusCode
        };
    }

    /// <summary>
    /// MVC Proxy: Elimina un área de negocio
    /// </summary>
    [HttpDelete]
    public async Task<IActionResult> Delete(int id)
    {
        {
            // Obtener empresaId desde HttpContext usando extensión
            var empresaId = SessionHelper.EmpresaId;

            logger.LogInformation("Delete: Proxy call for id={Id}, empresaId={EmpresaId}", id, empresaId);
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<AreasNegocioApiController>(
                HttpContext,
                nameof(AreasNegocioApiController.Delete),
                new { id, empresaId }
            );
            var (statusCode, content) = await client.ProxyRequestAsync(url!, null, HttpMethod.Delete);
            return new ContentResult
            {
                Content = content,
                ContentType = "application/json",
                StatusCode = statusCode
            };
        }
    }

    /// <summary>
    /// MVC Proxy: Exporta áreas de negocio a Excel
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Export()
    {
        {
            // Obtener empresaId desde HttpContext usando extensión
            var empresaId = SessionHelper.EmpresaId;

            logger.LogInformation("Export: Exportando áreas de negocio para empresaId={EmpresaId}", empresaId);

            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<AreasNegocioApiController>(
                HttpContext,
                nameof(AreasNegocioApiController.ExportToExcel),
                new { empresaId }
            );

            var (fileBytes, contentType) = await client.DownloadFileAsync(url, HttpMethod.Get);
            var fileName = $"AreasNegocio_{empresaId}_{DateTime.Now:yyyyMMdd}.xlsx";

            logger.LogInformation("Export: Exportación exitosa");
            return File(fileBytes, contentType, fileName);
        }
    }
}
