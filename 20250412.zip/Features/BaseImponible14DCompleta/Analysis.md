# Legacy Analysis: BaseImponible14DCompleta

## 📄 Información del Formulario VB6

**Archivo VB6:** `old/Contabilidad70/HyperContabilidad/FrmBaseImponible14DFull.frm`
**Fecha Análisis:** 2025-09-30
**Analista:** IA
**Complejidad:** Alta

### Propósito del Formulario
Este formulario gestiona la Base Imponible Primera Categoría según el Régimen 14D del sistema tributario chileno. Permite calcular, visualizar y editar los valores de ingresos y egresos para determinar la base imponible tributaria con estructura jerárquica expandible/colapsable. Es un informe complejo con múltiples niveles de detalle y cálculos automáticos basados en datos contables.

---

## 🎨 CONTROLES UI IDENTIFICADOS

### Grilla Principal (FlexEdGrid)
| Control VB6 | Tipo | Propósito |
|-------------|------|-----------|
| Grid | FlexEdGrid3.FEd3Grid | Grilla principal con estructura jerárquica de ingresos/egresos |

#### Columnas de la Grilla
| Columna | Constante | Propósito | Visible |
|---------|----------|-----------|---------|
| IdTblBaseImp14D | C_IDTBLBASEIMP14D (0) | ID registro en BD | No |
| IdArrBaseImp14D | C_IDARRBASEIMP14D (1) | Índice array interno | No |
| Regimen | C_REGIMEN (2) | Régimen tributario | No |
| Nivel | C_NIVEL (3) | Nivel jerárquico (1-5) | No |
| Tipo | C_TIPO (4) | Tipo (Ingreso/Egreso) | No |
| Codigo | C_CODIGO (5) | Código del item | No |
| FormaIngreso | C_FORMAINGRESO (6) | Forma de ingreso de datos | No |
| OpenClose | C_OPENCLOSE (7) | Símbolo expandir/colapsar (+/-) | Sí |
| Descrip | C_DESCRIP (8) | Descripción del concepto | Sí |
| Valor | C_VALOR (9) | Monto del concepto | Sí |
| Fmt | C_FMT (10) | Formato de visualización | No |
| Update | C_UPDATE (11) | Marca de actualización | No |

### Frame de Herramientas
| Control VB6 | Tipo | Caption | Propósito |
|-------------|------|---------|-----------|
| Frame1 | Frame | - | Contenedor de botones de herramientas |

### Botones de Acción
| Botón VB6 | Caption | Habilitado Si | Acción | Mapeo .NET |
|-----------|---------|---------------|--------|------------|
| Bt_Preview | - | Siempre | Vista previa de impresión | PreviewAsync() |
| Bt_Print | - | Siempre | Imprimir reporte | PrintAsync() |
| Bt_CopyExcel | - | Siempre | Copiar a Excel | CopyToExcelAsync() |
| Bt_Sum | - | Siempre | Sumar valores seleccionados | ShowSumCalculatorAsync() |
| Bt_ConvMoneda | - | Siempre | Conversor de moneda | ShowCurrencyConverterAsync() |
| Bt_Calc | - | Siempre | Abrir calculadora | ShowCalculatorAsync() |
| Bt_Calendar | - | Siempre | Mostrar calendario | ShowCalendarAsync() |
| Bt_Expand | "Expandir Todo" | Siempre | Expandir todos los niveles | ExpandAllAsync() |
| Bt_SaldosVig | "Saldos Vigentes" | Siempre | Mostrar solo saldos con valores | ShowOnlyWithBalancesAsync() |
| Bt_OK | "Cerrar" | Siempre | Guardar y cerrar | SaveAndCloseAsync() |

---

## 🔘 EVENTOS IDENTIFICADOS

### Eventos de Formulario
| Evento VB6 | Cuándo Ocurre | Acciones | Mapeo .NET |
|------------|---------------|----------|------------|
| Form_Load | Al abrir form | Configura grilla, carga base, carga datos | InitializeAsync() |
| Form_Resize | Al cambiar tamaño | Ajusta altura de grilla | N/A (CSS responsive) |

### Eventos de Grilla
| Control.Evento | Trigger | Acción VB6 | Mapeo .NET |
|----------------|---------|------------|------------|
| Grid_DblClick | Doble click en celda | Expandir/colapsar o editar valor manual | HandleCellDoubleClickAsync() |
| Grid_AcceptValue | Al aceptar valor editado | Formatea y actualiza valor | UpdateCellValueAsync() |
| Grid_BeforeEdit | Antes de editar | Configura editor según tipo | N/A (validación cliente) |
| Grid_EditKeyPress | Al teclear en edición | Valida entrada numérica | N/A (input type="number") |

### Eventos de Botones
| Botón.Evento | Acción VB6 | Mapeo .NET |
|--------------|------------|------------|
| Bt_OK_Click | Valida, guarda todo, cierra | SaveAndCloseAsync() |
| Bt_Expand_Click | Expande todos los niveles | ExpandAllAsync() |
| Bt_SaldosVig_Click | Muestra solo con saldos | ShowOnlyWithBalancesAsync() |
| Bt_Preview_Click | Vista previa de impresión | PreviewAsync() |
| Bt_Print_Click | Imprime directamente | PrintAsync() |
| Bt_CopyExcel_Click | Copia grilla a clipboard | CopyToExcelAsync() |
| Bt_Sum_Click | Abre calculadora de suma | ShowSumCalculatorAsync() |
| Bt_ConvMoneda_Click | Abre conversor moneda | ShowCurrencyConverterAsync() |
| Bt_Calc_Click | Abre calculadora Windows | ShowCalculatorAsync() |
| Bt_Calendar_Click | Muestra calendario | ShowCalendarAsync() |

---

## 🔧 FUNCIONES Y PROCEDIMIENTOS VB6

### Funciones Públicas
```vb
' Función: FEdit
' Propósito: Función principal de edición modal del formulario
' Parámetros: BaseImponible As Double (ByRef)
' Retorno: Integer (vbOK o vbCancel)
' Llamado por: Formularios padre
' Mapeo .NET: ShowModalAsync() retorna BaseImponibleDto
Public Function FEdit(BaseImponible As Double) As Integer
   Me.Show vbModal
   ' Retorna BaseImponible calculada
End Function
```

### Funciones Privadas Principales

```vb
' Función: LoadBase
' Propósito: Carga estructura jerárquica desde array global gBaseImponible14D
' Mapeo .NET: LoadHierarchicalStructureAsync()
Private Sub LoadBase()
   ' Itera array gBaseImponible14D
   ' Crea filas con niveles 1-5
   ' Aplica formato según nivel (negrita, color, etc.)
End Sub
```

```vb
' Función: LoadAll
' Propósito: Carga valores desde BD y calcula traspasos automáticos
' Mapeo .NET: LoadValuesAndCalculateAsync()
Private Sub LoadAll()
   ' Lee BaseImponible14D de BD
   ' Calcula traspasos desde cuentas contables
   ' Actualiza valores en grilla
End Sub
```

```vb
' Función: SaveAll
' Propósito: Guarda todos los valores nivel 5 en BD
' Mapeo .NET: SaveAllValuesAsync()
Private Sub SaveAll()
   ' Recorre grilla
   ' Para nivel = 5: UPDATE o INSERT en BaseImponible14D
   ' Actualiza EmpresasAno con base imponible final
End Sub
```

```vb
' Función: CalcGrid
' Propósito: Recalcula totales jerárquicos (nivel 5→1)
' Mapeo .NET: RecalculateHierarchyAsync()
Private Sub CalcGrid()
   ' For Nivel = 4 To 1 Step -1
   ' Suma valores de nivel+1 para calcular nivel actual
End Sub
```

```vb
' Función: OpenCloseGrid
' Propósito: Expande/colapsa nivel jerárquico
' Mapeo .NET: ToggleNodeExpansionAsync()
Private Sub OpenCloseGrid()
   ' Si OpenClose = "-": oculta hijos (RowHeight = 0)
   ' Si OpenClose = "+": muestra hijos (RowHeight normal)
End Sub
```

```vb
' Función: ExpandAll
' Propósito: Expande todos los niveles de la jerarquía
' Mapeo .NET: ExpandAllNodesAsync()
Private Sub ExpandAll()
   ' Recorre todas las filas
   ' Muestra todas con RowHeight normal
   ' Actualiza símbolos +/-
End Sub
```

```vb
' Función: SaldosVigentes
' Propósito: Muestra solo items con valores != 0
' Mapeo .NET: FilterNonZeroValuesAsync()
Private Sub SaldosVigentes()
   ' Expande todo primero
   ' Oculta filas con valor = 0 (nivel > 2)
End Sub
```

```vb
' Función: GetIVAIrrecSaldoPagar
' Propósito: Calcula IVA irrecuperable saldo a pagar
' Retorno: Double
' Mapeo .NET: CalculateIVAIrrecuperableAsync()
Private Function GetIVAIrrecSaldoPagar() As Double
   ' Query compleja con tabla temporal
   ' Calcula IVA irrecuperable de compras
End Function
```

### Lista Completa de Funciones de Cálculo
| Función VB6 | Propósito | Mapeo .NET Method |
|-------------|-----------|-------------------|
| GetPercibidosPagados | Obtiene ingresos percibidos/pagados | GetPerceivedPaidIncomeAsync() |
| GetDevengadosAnteriores | Obtiene devengados anteriores | GetPreviousAccruedAsync() |
| ExistOInsumPagados | Obtiene existencias/insumos pagados | GetPaidInventoryAsync() |
| GetPercibidosPagadosCompras | Obtiene compras percibidas/pagadas | GetPerceivedPaidPurchasesAsync() |
| GetTotCta_CodF22_14Ter | Obtiene total cuenta código F22 | GetAccountTotalF22Async() |
| LoadValCuentasAjustes14D | Carga valores de ajustes | LoadAdjustmentValuesAsync() |
| GetValAjustesELC | Obtiene valores ajustes ELC | GetELCAdjustmentsAsync() |
| GetVal33Bis | Obtiene crédito art. 33 bis | GetCredit33BisAsync() |
| GetActivosFijosDepreciables | Obtiene activos fijos depreciables | GetDepreciableFixedAssetsAsync() |
| GetTotCta_CodF22_14Ter_NC | Obtiene notas de crédito | GetCreditNotesF22Async() |
| GetNCVParaExistencias | Obtiene NC para existencias | GetInventoryCreditNotesAsync() |
| GetValPpm | Obtiene reajuste PPM | GetPPMAdjustmentAsync() |
| GetPerdidaAnoAnterior | Obtiene pérdida año anterior | GetPreviousYearLossAsync() |

---

## 💾 ACCESO A DATOS VB6

### Query 1: Cargar Valores Guardados
```vb
' Ubicación: LoadAll
Q1 = "SELECT IdBaseImponible14D, Tipo, Nivel, Codigo, Valor "
Q1 = Q1 & " FROM BaseImponible14D "
Q1 = Q1 & " WHERE IdEmpresa = " & gEmpresa.Id & " AND Ano = " & gEmpresa.Ano
Q1 = Q1 & " ORDER BY Codigo"
```

**Mapeo Entity Framework:**
```csharp
await _context.BaseImponible14D
    .Where(b => b.IdEmpresa == empresaId && b.Ano == ano)
    .OrderBy(b => b.Codigo)
    .ToListAsync();
```

### Query 2: Guardar/Actualizar Valor
```vb
' Ubicación: SaveAll - UPDATE
Q1 = "UPDATE BaseImponible14D SET"
Q1 = Q1 & " Valor = " & vFmt(Grid.TextMatrix(i, C_VALOR))
Q1 = Q1 & " WHERE IdEmpresa = " & gEmpresa.Id & " AND Ano = " & gEmpresa.Ano
Q1 = Q1 & " AND IdBaseImponible14D = " & Grid.TextMatrix(i, C_IDTBLBASEIMP14D)
```

### Query 3: Insertar Nuevo Valor
```vb
' Ubicación: SaveAll - INSERT
Q1 = "INSERT INTO BaseImponible14D (IdEmpresa, Ano, Tipo, Nivel, Codigo, Fecha, Valor)"
Q1 = Q1 & " VALUES(" & gEmpresa.Id & "," & gEmpresa.Ano & "," & Tipo
Q1 = Q1 & ", " & Nivel & ", " & Codigo & ", 0, " & Valor & ")"
```

### Query 4: Actualizar Base Imponible en EmpresasAno
```vb
' Ubicación: SaveAll
Q1 = "UPDATE EmpresasAno SET "
If gEmpresa.ProPymeGeneral <> 0 Then
   Q1 = Q1 & "  CPS_BaseImpPrimCat_14DN3 = " & lBaseImponible
ElseIf gEmpresa.ProPymeTransp <> 0 Then
   Q1 = Q1 & "  CPS_BaseImpPrimCat_14DN8 = " & lBaseImponible
End If
Q1 = Q1 & " WHERE IdEmpresa = " & gEmpresa.Id & " AND Ano = " & gEmpresa.Ano
```

---

## ✅ VALIDACIONES Y REGLAS DE NEGOCIO

### Validaciones de Período
| Validación | Regla | Mensaje Error VB6 | Implementar en .NET |
|------------|-------|-------------------|---------------------|
| Período cerrado | FCierre != 0 | "Este período ya ha sido cerrado. No podrá modificar ingresos manuales." | CheckPeriodOpenAsync() |

### Reglas de Negocio

1. **Estructura Jerárquica de 5 Niveles**
   - Nivel 1: Base Imponible (total general)
   - Nivel 2: Secciones principales (INGRESOS/EGRESOS)
   - Nivel 3-4: Subsecciones
   - Nivel 5: Items editables (valores finales)
   **→ Implementar:** Modelo jerárquico con recursión

2. **Tipos de Ingreso de Datos (FormaIngreso)**
   - ING_MANUAL: Editable por usuario (doble click)
   - ING_TRASPASO: Calculado desde cuentas contables
   - ING_TRASPASOAJUSTE: Desde ajustes
   - ING_TRASPASOLIBCAJA: Desde libro de caja
   - ING_AMBOS: Manual o traspaso
   **→ Implementar:** Enum FormaIngreso con lógica de cálculo

3. **Régimen Tributario Condicional**
   - ProPymeGeneral: Usa régimen 14DN3
   - ProPymeTransp: Usa régimen 14DN8
   - Oculta/muestra items según régimen
   **→ Implementar:** FilterByTaxRegimeAsync()

4. **Cálculos Automáticos en Cascada**
   - Nivel 5: Valores editables o calculados
   - Niveles 4→1: Suma automática de hijos
   **→ Implementar:** RecalculateHierarchyAsync() bottom-up

5. **Items Espejo (códigos específicos)**
   - Código 8100 ↔ 8300: Valores espejo
   - Códigos 7400-7900 ↔ 10800-11300: Traspasos
   **→ Implementar:** UpdateMirrorValuesAsync()

---

## 🧮 CÁLCULOS Y FÓRMULAS

### Cálculo 1: Base Imponible Principal
```vb
' Ubicación: SaveAll
lBaseImponible = vFmt(Grid.TextMatrix(Grid.FixedRows, C_VALOR))
' Es el valor del primer registro (nivel 1)
```
**→ Implementar:** GetTotalTaxBaseAsync()

### Cálculo 2: Totales por Nivel
```vb
' Ubicación: CalcGrid
For Nivel = 4 To 1 Step -1
   ' Para cada fila de nivel N
   Tot = Sum(valores de nivel N+1)
   Grid.TextMatrix(Row, C_VALOR) = Format(Tot, NUMFMT)
Next
```
**→ Implementar:** CalculateLevelTotalsAsync(nivel)

### Cálculo 3: IVA Irrecuperable
- Query compleja con tabla temporal
- Suma pagos - (afecto + IVA + exento)
- Considera notas de crédito
**→ Implementar:** CalculateNonRecoverableVATAsync()

---

## 🚀 NAVEGACIÓN Y FLUJO

### Formularios Llamados
| Desde VB6 | Formulario Destino | Parámetros | Retorno | Mapeo .NET |
|-----------|-------------------|------------|---------|------------|
| Grid_DblClick | FrmDetBaseImponible14DFull | Tipo, Codigo, Descrip | Valor editado | Modal dialog o inline edit |
| Grid_DblClick (PPM) | FrmAsisPPM | - | - | PPM assistance modal |
| Bt_Sum_Click | FrmSumSimple | Grid | - | Sum calculator modal |
| Bt_ConvMoneda_Click | FrmConverMoneda | - | Valor convertido | Currency converter modal |
| Bt_Calendar_Click | FrmCalendar | - | Fecha seleccionada | Date picker modal |

### Flujo de Estados del Form
```
[Inicio] → Form_Load() → LoadBase() → LoadAll() → CalcGrid()
   ↓
[Visualización] → Usuario puede:
   - Expandir/Colapsar niveles
   - Editar valores manuales (doble click)
   - Ver saldos vigentes
   - Usar herramientas
   ↓
[Edición Manual] → Grid_DblClick() → FrmDetBaseImponible14DFull
   ↓
[Guardar] → Bt_OK_Click() → Valida() → SaveAll() → Unload
```

---

## 📊 EXPORTACIONES E IMPORTACIONES

### Exportación a Excel
```vb
' Botón: Bt_CopyExcel_Click
' Método: LP_FGr2Clip - Copia grilla al clipboard
' Formato: Tab-delimited con título y año
```
**→ Implementar:** ExportToExcelAsync() usando EPPlus

### Impresión
```vb
' Vista Previa: Bt_Preview_Click → FrmPrintPreview
' Impresión Directa: Bt_Print_Click → Printer
' Orientación: Vertical
```
**→ Implementar:** GeneratePrintPreviewAsync(), PrintAsync()

---

## 🎯 MAPEO FINAL: MÉTODOS .NET DETERMINADOS

### Interface del Service
```csharp
public interface IBaseImponible14DCompletaService
{
    // Carga principal
    Task<BaseImponible14DCompletaDto> GetByEmpresaAnoAsync(int empresaId, int ano);
    Task<IEnumerable<BaseImponible14DItemDto>> GetHierarchicalStructureAsync(int empresaId, int ano);

    // Operaciones CRUD
    Task<BaseImponible14DResultDto> SaveAsync(int empresaId, int ano, BaseImponible14DSaveDto dto);
    Task<BaseImponible14DItemDto> UpdateItemValueAsync(int empresaId, int ano, int codigo, decimal valor);

    // Cálculos
    Task<decimal> CalculateTotalTaxBaseAsync(int empresaId, int ano);
    Task RecalculateHierarchyAsync(int empresaId, int ano);
    Task<IEnumerable<BaseImponible14DItemDto>> CalculateAutomaticValuesAsync(int empresaId, int ano);

    // Valores específicos de cuentas
    Task<decimal> GetPerceivedPaidIncomeAsync(int empresaId, int ano, int tipoOperCaja, int regimen);
    Task<decimal> GetPaidInventoryAsync(int empresaId, int ano, int tipoOperCaja);
    Task<decimal> GetAccountTotalF22Async(int empresaId, int ano, int codigoF22, string tipo);
    Task<decimal> LoadAdjustmentValuesAsync(int empresaId, int ano, int tipoAjuste, int idItem);
    Task<decimal> GetELCAdjustmentsAsync(int empresaId, int ano, int tipoAjuste, int item);
    Task<decimal> GetCredit33BisAsync(int empresaId, int ano);
    Task<decimal> GetDepreciableFixedAssetsAsync(int empresaId, int ano, int tipoOperCaja);
    Task<decimal> CalculateNonRecoverableVATAsync(int empresaId, int ano);
    Task<decimal> GetPPMAdjustmentAsync(int empresaId, int ano);
    Task<decimal> GetPreviousYearLossAsync(int empresaId, int ano);

    // Filtros y vistas
    Task<IEnumerable<BaseImponible14DItemDto>> GetWithNonZeroValuesAsync(int empresaId, int ano);
    Task<IEnumerable<BaseImponible14DItemDto>> FilterByRegimeAsync(int empresaId, int ano, string regime);

    // Validaciones
    Task<ValidationResult> ValidateAsync(int empresaId, int ano);
    Task<bool> IsPeriodOpenAsync(int empresaId, int ano);

    // Exportación
    Task<byte[]> ExportToExcelAsync(int empresaId, int ano);
    Task<byte[]> GeneratePrintPreviewAsync(int empresaId, int ano);
}
```

### Resumen de Mapeo
| Funcionalidad VB6 | Método .NET | Complejidad | Prioridad |
|-------------------|-------------|-------------|-----------|
| Form_Load completo | GetByEmpresaAnoAsync() | Alta | Alta |
| LoadBase() | GetHierarchicalStructureAsync() | Media | Alta |
| LoadAll() | CalculateAutomaticValuesAsync() | Alta | Alta |
| SaveAll() | SaveAsync() | Media | Alta |
| CalcGrid() | RecalculateHierarchyAsync() | Media | Alta |
| Grid_DblClick edición | UpdateItemValueAsync() | Baja | Alta |
| ExpandAll() | Cliente-side JavaScript | Baja | Media |
| SaldosVigentes() | GetWithNonZeroValuesAsync() | Baja | Media |
| GetIVAIrrecSaldoPagar() | CalculateNonRecoverableVATAsync() | Alta | Alta |
| Bt_CopyExcel | ExportToExcelAsync() | Baja | Media |
| Bt_Print/Preview | GeneratePrintPreviewAsync() | Media | Baja |

---

## ⚠️ NOTAS IMPORTANTES Y OBSERVACIONES

### Peculiaridades del Form VB6
- Usa array global `gBaseImponible14D` con estructura predefinida
- Maneja 2 regímenes: ProPymeGeneral (14DN3) y ProPymeTransp (14DN8)
- Niveles jerárquicos con formato visual (negrita, colores, indentación)
- Grid con RowHeight = 0 para ocultar filas (simula colapso)
- Valores negativos para egresos (multiplicados por -1 al mostrar)
- Códigos espejo hardcodeados (8100↔8300, serie 7400-7900↔10800-11300)

### Decisiones de Diseño
- **Estructura jerárquica**: Implementar con modelo recursivo y TreeView o tabla expandible
- **Cálculos automáticos**: Service methods para cada tipo de traspaso
- **Edición inline**: Modal para valores manuales, automático para traspasos
- **Responsive**: TreeView colapsable en móvil, tabla completa en desktop

### Dependencias Externas
- Array global `gBaseImponible14D`: Crear configuración de estructura en BD o JSON
- Cuentas contables F22: Requiere integración con módulo de cuentas
- Ajustes ELC: Requiere tabla AjustesExtLibCaja
- Libro Caja: Requiere integración con LibroCaja
- PPM: Requiere formulario FrmAsisPPM (crear como modal separado)

---

## ✅ CHECKLIST DE COMPLETITUD DEL ANÁLISIS

- [x] Todos los controles UI documentados
- [x] Todos los botones y eventos mapeados
- [x] Todas las funciones VB6 identificadas
- [x] Todos los queries SQL traducidos a EF Core
- [x] Todas las validaciones documentadas
- [x] Todas las reglas de negocio identificadas
- [x] Todos los cálculos documentados
- [x] Navegación y flujos mapeados
- [x] Métodos .NET determinados
- [x] Interface del Service definida
- [x] Decisiones de diseño documentadas

---

**✅ ANÁLISIS COMPLETO - LISTO PARA IMPLEMENTACIÓN**