using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Extensions;
using App.Helpers;

namespace App.Features.AuditoriaGeneral;

public class AuditoriaGeneralController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<AuditoriaGeneralController> logger) : Controller
{
    public IActionResult Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Auditoría General";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        // Extraer datos de HttpContext (patrón estándar del proyecto)
        var empresaId = SessionHelper.EmpresaId;
        int ano = SessionHelper.Ano;

        logger.LogInformation("Loading AuditoriaGeneral Index view for empresaId: {EmpresaId}, año: {Ano}",
            empresaId, ano);

        var viewModel = new AuditoriaGeneralIndexViewModel
        {
            EmpresaId = empresaId,
            Ano = (short)ano
        };

        return View(viewModel);
    }

    // Método proxy: GetOperaciones
    [HttpGet]
    public async Task<IActionResult> GetOperaciones()
    {
        logger.LogInformation("Proxy: GetOperaciones");

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AuditoriaGeneralApiController>(
            HttpContext,
            nameof(AuditoriaGeneralApiController.GetOperaciones));
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    // Método proxy: GetUsuarios
    [HttpGet]
    public async Task<IActionResult> GetUsuarios()
    {
        logger.LogInformation("Proxy: GetUsuarios");

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AuditoriaGeneralApiController>(
            HttpContext,
            nameof(AuditoriaGeneralApiController.GetUsuarios));
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    // Método proxy: GetTiposComprobante
    [HttpGet]
    public async Task<IActionResult> GetTiposComprobante()
    {
        logger.LogInformation("Proxy: GetTiposComprobante");

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AuditoriaGeneralApiController>(
            HttpContext,
            nameof(AuditoriaGeneralApiController.GetTiposComprobante));
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    // Método proxy: CanDeleteImported
    [HttpPost]
    public async Task<IActionResult> CanDeleteImported([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: CanDeleteImported");

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AuditoriaGeneralApiController>(
            HttpContext,
            nameof(AuditoriaGeneralApiController.CanDeleteImported));
        var (statusCode, content) = await client.ProxyRequestAsync(
            url!,
            request!,
            HttpMethod.Post);
        return StatusCode(statusCode, content);
    }

    // Método proxy: DeleteImported
    [HttpPost]
    public async Task<IActionResult> DeleteImported([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: DeleteImported");

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AuditoriaGeneralApiController>(
            HttpContext,
            nameof(AuditoriaGeneralApiController.DeleteImported));
        var (statusCode, content) = await client.ProxyRequestAsync(
            url!,
            request!,
            HttpMethod.Post);
        return StatusCode(statusCode, content);
    }

    // Método proxy: GetAll (con parámetros de query)
    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        logger.LogInformation("Proxy: GetAll with querystring");

        var client = httpClientFactory.CreateClient();
        var queryString = Request.QueryString.ToString();

        var url = linkGenerator.GetApiUrl<AuditoriaGeneralApiController>(
            HttpContext,
            nameof(AuditoriaGeneralApiController.GetAll));
        // Append query string manually since it's dynamic
        var fullUrl = url + queryString;
        var datos = await client.GetFromApiAsync<object>(fullUrl);
        return Ok(datos);
    }
}