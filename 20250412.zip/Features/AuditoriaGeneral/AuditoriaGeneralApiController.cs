using Microsoft.AspNetCore.Mvc;

namespace App.Features.AuditoriaGeneral;

[ApiController]
[Route("[controller]/[action]")]
public class AuditoriaGeneralApiController(IAuditoriaGeneralService service, ILogger<AuditoriaGeneralApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetAll(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        [FromQuery] int? fechaOperDesde,
        [FromQuery] int? fechaOperHasta,
        [FromQuery] int? fechaCompDesde,
        [FromQuery] int? fechaCompHasta,
        [FromQuery] int? numeroComp,
        [FromQuery] int? idUsuario,
        [FromQuery] int? idOper,
        [FromQuery] int? tipoComp,
        [FromQuery] int? tipoAjuste)
    {
        logger.LogInformation("API: Getting auditoría general for empresa {EmpresaId}, año {Ano}", empresaId, ano);

        var filtros = new AuditoriaFiltrosDto
        {
            FechaOperDesde = fechaOperDesde,
            FechaOperHasta = fechaOperHasta,
            FechaCompDesde = fechaCompDesde,
            FechaCompHasta = fechaCompHasta,
            NumeroComp = numeroComp,
            IdUsuario = idUsuario,
            IdOper = idOper,
            TipoComp = tipoComp,
            TipoAjuste = tipoAjuste
        };

        var result = await service.GetAllAsync(empresaId, ano, filtros);
        return Ok(result);
    }

    [HttpGet]
    public async Task<IActionResult> GetUsuarios()
    {
        logger.LogInformation("API: Getting usuarios for combo");
        var result = await service.GetUsuariosAsync();
        return Ok(result);
    }

    [HttpGet]
    public async Task<IActionResult> GetOperaciones()
    {
        logger.LogInformation("API: Getting operaciones for combo");
        var result = await service.GetOperacionesAsync();
        return Ok(result);
    }

    [HttpGet]
    public async Task<IActionResult> GetTiposComprobante()
    {
        logger.LogInformation("API: Getting tipos comprobante for combo");
        var result = await service.GetTiposComprobanteAsync();
        return Ok(result);
    }

    [HttpGet]
    public async Task<IActionResult> GetTiposAjuste()
    {
        logger.LogInformation("API: Getting tipos ajuste for combo");
        var result = await service.GetTiposAjusteAsync();
        return Ok(result);
    }

    [HttpPost]
    public async Task<IActionResult> CanDeleteImported([FromBody] DeleteImportedRequestDto request)
    {
        await service.CanDeleteImportedAsync(request.IdComp, request.EmpresaId, request.Ano, request.ConfirmarAntiguo);
        return Ok();
    }

    [HttpPost]
    public async Task<IActionResult> DeleteImported([FromBody] DeleteImportedRequestDto request)
    {
        logger.LogInformation("API: Deleting imported comprobante {IdComp}", request.IdComp);
        await service.DeleteImportedAsync(request.IdComp, request.EmpresaId, request.Ano, request.IdUsuario, request.ConfirmarAntiguo);
        return Ok();
    }

    [HttpPost]
    public async Task<IActionResult> ExportToExcel([FromBody] AuditoriaGeneralRequestDto request)
    {
        logger.LogInformation("API: Exporting auditoría general to Excel for empresa {EmpresaId}, año {Ano}", request.EmpresaId, request.Ano);

        var result = await service.ExportToExcelAsync(request.EmpresaId, request.Ano, request.Filtros);
        var fileName = $"AuditoriaGeneral_{request.Ano}_{DateTime.Now:yyyyMMddHHmm}.xlsx";

        return File(result, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
    }
}