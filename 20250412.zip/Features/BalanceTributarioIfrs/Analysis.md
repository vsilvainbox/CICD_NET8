# Balance Tributario IFRS - Analysis

## Original VB6 Form: FrmBalTributarioIFRS.frm

### Purpose
Generates an 8-column General Balance report in IFRS format (Balance General 8 Columnas Formato IFRS). This is a comprehensive financial statement that displays account balances across multiple classification categories according to IFRS accounting standards.

### UI Components

#### Frame1 (Top Toolbar) - Line 33
- **Bt_Preview** (Button): Print preview
- **Bt_Print** (Button): Print report
- **Bt_CopyExcel** (Button): Copy to Excel with company header option
- **Bt_Sum** (Button): Sum selected movements
- **Bt_ConvMoneda** (Button): Currency converter
- **Bt_Calc** (Button): Calculator
- **Ch_VerCodCta** (CheckBox): Toggle account code visibility
- **Bt_Cerrar** (Button): Close form

#### Frame2 (Filter Panel) - Line 19
- **Tx_Desde** (TextBox): Start date filter
- **Bt_Fecha(0)** (Button): Calendar picker for start date
- **Tx_Hasta** (TextBox): End date filter
- **Bt_Fecha(1)** (Button): Calendar picker for end date
- **Cb_Nivel** (ComboBox): Account level filter (depth in chart of accounts)
- **Cb_AreaNeg** (ComboBox): Business area filter
- **Cb_CCosto** (ComboBox): Cost center filter
- **Bt_Buscar** (Button): Generate/List report

#### Grid (Main MSFlexGrid) - Line 104
13 columns displaying:
- C_CODIGO (0): Account code
- C_CUENTA (1): Account name
- C_DEBITOS (2): Debits
- C_CREDITOS (3): Credits
- C_DEUDOR (4): Debit balance
- C_ACREEDOR (5): Credit balance
- C_INVACTIVO (6): Inventory - Assets
- C_INVPASIVO (7): Inventory - Liabilities
- C_PERDIDA (8): Result - Loss
- C_GANANCIA (9): Result - Profit
- C_IDCUENTA (10): Hidden account ID
- C_CLASIF (11): Hidden classification
- C_NIVEL (12): Hidden level

#### GridTot (Footer Grids) - Lines 108, 118, 128
Three separate grids for totals:
- **GridTot(0)**: Subtotals
- **GridTot(1)**: Profit/Loss adjustment
- **GridTot(2)**: Final totals

### Key Functions and Events

#### Form_Load() - Line 215
1. Sets form caption from `gInformeIFRS(IFRS_BAL8COL)`
2. Determines current/last month with vouchers
3. Sets default date range (Jan 1 to end of current month)
4. Fills account level dropdown (default level 2)
5. Fills business area and cost center dropdowns
6. Sets default orientation to horizontal
7. Checks for valid chart of accounts plan (Básico, Intermedio, Avanzado, IFRS)
8. Warns if accounts lack IFRS classification
9. Shows warning that only APPROVED vouchers are included

#### Bt_Buscar_Click() - Line 209
1. Validates date range (Desde <= Hasta)
2. Sets mouse pointer to hourglass
3. Calls `LoadAll()` to generate report
4. Restores mouse pointer

#### LoadAll() - Line 417
**Main report generation logic:**
1. Gets selected level from Cb_Nivel
2. Builds WHERE clause for date range
3. Adds optional filters (AreaNeg, CCosto)
4. Filters by TipoAjuste (TAJUSTE_FINANCIERO or TAJUSTE_AMBOS)
5. Calls `GenQueryIFRSporNiveles()` to get hierarchical account data
6. Iterates through recordset building grid rows
7. Handles hierarchical levels with totals at each level
8. Calculates balances (Debit - Credit)
9. Classifies into columns based on account classification:
   - CLASCTA_ACTIVO/PASIVO/ORDEN → Inventory columns
   - CLASCTA_RESULTADO → Result columns
10. Hides rows not matching selected level or with zero movement
11. Calculates subtotals
12. Calculates profit/loss adjustment
13. Calculates final totals

**Key Variables:**
- `Total(MAX_NIVELES)`: Array tracking totals at each hierarchical level
- `CurNiv`: Current account level being processed
- `CurCta`: Current account code
- `SumTotal()`: Grand totals array

**Classification Logic (Line 491):**
```vb
Select Case Val(Grid.TextMatrix(Row, C_CLASIF))
   Case CLASCTA_ACTIVO, CLASCTA_PASIVO, CLASCTA_ORDEN
      If Deudor > 0 Then → InvActivo
      Else → InvPasivo
      
   Case CLASCTA_RESULTADO
      If Deudor > 0 Then → Perdida
      Else → Ganancia
End Select
```

**Total Calculation Logic (Lines 524-580):**
1. **Subtotal Row (GridTot(0))**: Sum all visible rows
2. **Adjustment Row (GridTot(1))**: Calculate differences
   - Debits - Credits difference
   - Deudor - Acreedor difference
   - InvActivo - InvPasivo difference
   - Perdida - Ganancia difference (determines "Utilidad" or "Pérdida" label)
3. **Final Total Row (GridTot(2))**: Subtotal + Adjustment

#### Bt_CopyExcel_Click() - Line 227
1. Validates report is generated
2. Converts grid to clipboard string using `LP_FGr2String()`
3. Optionally adds company header (RUT, name, address, giro, legal rep)
4. Appends three total grids
5. Copies to clipboard

#### Bt_Preview_Click() - Line 270
1. Validates report is generated
2. Calls `SetUpPrtGrid()` for print configuration
3. Creates FrmPrintPreview instance
4. Calls `gPrtLibros.PrtFlexGrid()` for preview rendering
5. Adds footer with `PrtPieBalanceFirma()`

#### Bt_Print_Click() - Line 300
1. Validates report is generated
2. Opens FrmPrtSetup for orientation and folio options
3. Calls `SetUpPrtGrid()` for print configuration
4. Prints using `gPrtLibros.PrtFlexGrid(Printer)`
5. Adds footer with `PrtPieBalance()`
6. Updates last used folio if using numbered paper

#### SetUpPrtGrid() - Line 586
Configures print layout:
1. Sets company header (if not using pre-printed paper)
2. Sets title and preliminary info flag
3. Sets date range header
4. Includes business area/cost center if filtered
5. Adjusts font sizes based on orientation:
   - Portrait: Arial 7pt, tighter columns
   - Landscape: Standard sizing
6. Builds column widths array
7. Builds totals array (3 rows)

#### Grid_DblClick() - Line 742
Opens detailed ledger (Libro Mayor) for clicked account:
- Only for IFRS plan
- Opens FrmLibMayor with date range and account ID
- Filtered by TAJUSTE_FINANCIERO

#### Ch_VerCodCta_Click() - Line 191
Toggles account code column visibility:
1. Shows/hides C_CODIGO column
2. Adjusts value column widths (G_VALWIDTH vs G_DVALWIDTH)
3. Synchronizes GridTot column widths

#### Form_Resize() - Line 263
Responsive layout:
1. Expands Grid width to form width
2. Expands Grid height to available space (leaving room for 3 total grids)
3. Positions three GridTot grids below main Grid
4. Maintains vertical scrollbar visibility

### Database Queries

#### GenQueryIFRSporNiveles() - External function
Generates hierarchical IFRS query with parameters:
- `Nivel`: Account depth level
- `WhFecha`: Date range WHERE clause
- `True`: Include all levels up to Nivel
- `0`: Additional parameter

**Expected columns:**
- Codigo: Account code (IFRS format)
- Descripcion: Account name
- Nivel: Hierarchical level
- Debe: Debit total
- Haber: Credit total
- idCuenta: Account ID
- Clasificacion: Account classification code

**Data Flow:**
```
MovComprobante → Joined with Comprobante (on IdComprob)
                → Joined with Cuentas (on IdCuenta)
                → Filtered by Estado = APROBADO
                → Filtered by TipoAjuste (FINANCIERO or AMBOS)
                → Grouped by IFRS code and hierarchical levels
                → Ordered by Codigo, Nivel
```

### Business Logic

#### IFRS Classification System
Accounts are classified by first digit of IFRS code:
- **1 = CLASCTA_ACTIVO**: Assets
- **2 = CLASCTA_PASIVO**: Liabilities
- **3 = CLASCTA_ORDEN**: Order accounts (memorandum)
- **4/5 = CLASCTA_RESULTADO**: Results (income/expenses)

#### 8-Column Structure
1. **Debits**: All debit movements
2. **Credits**: All credit movements
3. **Debit Balance**: Accounts with debit > credit
4. **Credit Balance**: Accounts with credit > debit
5. **Inventory - Assets**: Positive balances from asset/liability accounts
6. **Inventory - Liabilities**: Negative balances from asset/liability accounts
7. **Result - Loss**: Positive balances from result accounts
8. **Result - Profit**: Negative balances from result accounts

#### Hierarchical Totaling
Uses array `Total(MAX_NIVELES)` to track:
- Running totals at each level
- Line numbers for each level's total
- Cascading totals from child to parent levels

When level decreases, writes accumulated totals for higher levels.

#### Adjustment Types Filter
Only includes vouchers with:
- `TipoAjuste IS NULL` (no adjustment type)
- `TipoAjuste = TAJUSTE_FINANCIERO` (financial adjustment)
- `TipoAjuste = TAJUSTE_AMBOS` (both types)

Excludes purely tax adjustments.

#### Validations
1. **Date Range**: Start date must be <= End date
2. **Chart of Accounts**: Must be predefined plan (Básico, Intermedio, Avanzado, IFRS)
3. **IFRS Classification**: Warns if accounts have non-zero balance without IFRS classification
4. **Voucher State**: Only processes APPROVED vouchers

#### Print Options
- **Orientation**: Portrait or Landscape (default landscape)
- **Pre-printed Paper**: Uses folio numbering if enabled
- **Preliminary Info**: Adds "INFORMACION PRELIMINAR" watermark
- **Company Header**: Automatic unless using pre-printed paper

### Constants and Settings

```vb
Const C_CODIGO = 0
Const C_CUENTA = 1
Const C_DEBITOS = 2
Const C_CREDITOS = 3
Const C_DEUDOR = 4
Const C_ACREEDOR = 5
Const C_INVACTIVO = 6
Const C_INVPASIVO = 7
Const C_PERDIDA = 8
Const C_GANANCIA = 9
Const C_IDCUENTA = 10
Const C_CLASIF = 11
Const C_NIVEL = 12

Dim lOrientacion As Integer
Dim lPapelFoliado As Boolean
Dim lInfoPreliminar As Boolean
Dim lMes As Integer
Dim lWCodCta As Integer
```

### Helper Functions Referenced
- `GetTxDate()`: Extract date from textbox
- `GetMesActual()`: Get current active month
- `GetUltimoMesConComps()`: Get last month with vouchers
- `FirstLastMonthDay()`: Get first/last day of month
- `SetTxDate()`: Set textbox date value
- `FillNivel()`: Populate level dropdown
- `FillCbAreaNeg()`: Populate business area dropdown
- `FillCbCCosto()`: Populate cost center dropdown
- `FGrSetup()`: Setup grid formatting
- `FGrTotales()`: Setup total grids
- `FGrVRows()`: Recalculate visible rows
- `LP_FGr2String()`: Convert grid to clipboard string
- `PrtPieBalance()`: Print footer
- `PrtPieBalanceFirma()`: Print footer with signatures
- `UpdateUltUsado()`: Update last folio used
- `SaldosSinClasifIFRS()`: Check for unclassified accounts
- `Calculadora()`: Launch calculator utility
- `DtGotFocus()`, `DtLostFocus()`: Date textbox focus handlers
- `KeyDate()`: Date textbox key handler

### External Dependencies
- **gEmpresa**: Global company object
- **gInformeIFRS()**: IFRS report names array
- **gFmtCodigoIFRS**: IFRS code format string
- **gPrtLibros**: Global print library object
- **DbMain**: Main database connection
- **IFRS_BAL8COL**: Report type constant
- **ORIENT_HOR**: Horizontal orientation constant
- **TAJUSTE_FINANCIERO**: Financial adjustment type
- **TAJUSTE_AMBOS**: Both adjustment types
- **CLASCTA_ACTIVO**: Asset classification
- **CLASCTA_PASIVO**: Liability classification
- **CLASCTA_ORDEN**: Order classification
- **CLASCTA_RESULTADO**: Result classification
- **BL_NUMFMT**: Balance number format
- **NUMFMT**: Standard number format
- **MAX_NIVELES**: Maximum hierarchy levels
- **REP_INDENT**: Report indentation spaces

### .NET Migration Notes

#### Entity Requirements
- **Comprobante**: Main voucher entity (Estado, Fecha, TipoAjuste)
- **MovComprobante**: Voucher line items (IdCuenta, Debe, Haber, IdAreaNeg, IdCCosto)
- **Cuentas**: Chart of accounts (Codigo, Descripcion, Nivel, Clasificacion)
- **PlanCuentasSII**: IFRS classification mapping
- **AreaNegocio**: Business areas
- **CentroCosto**: Cost centers
- **Empresa**: Company master data
- **ParamEmpresa**: Company parameters (PLANCTAS)

**All entities exist in `App.Data` namespace.**

#### DTO Design
Request DTO:
- FechaDesde: DateTime
- FechaHasta: DateTime
- Nivel: int
- IdAreaNegocio: int? (nullable)
- IdCentroCosto: int? (nullable)
- VerCodigoCuenta: bool
- IncluirMembreteEmpresa: bool (for Excel export)

Response DTO:
- Cuentas: List of BalanceTributarioIfrsLineaDto
- Subtotales: BalanceTributarioIfrsLineaDto
- Ajuste: BalanceTributarioIfrsLineaDto
- Totales: BalanceTributarioIfrsLineaDto
- EsUtilidad: bool (vs Pérdida)

BalanceTributarioIfrsLineaDto:
- IdCuenta: long?
- Codigo: string
- Cuenta: string
- Nivel: int
- Clasificacion: string
- Debitos: decimal
- Creditos: decimal
- SaldoDeudor: decimal
- SaldoAcreedor: decimal
- InventarioActivo: decimal
- InventarioPasivo: decimal
- ResultadoPerdida: decimal
- ResultadoGanancia: decimal

#### Service Layer
`IBalanceTributarioIfrsService`:
- `GenerarAsync(request)`: Main report generation
- `ExportarExcelAsync(request)`: Excel export with optional header
- `ValidarPlanCuentasAsync()`: Validate chart of accounts type
- `ValidarClasificacionIfrsAsync()`: Check for unclassified accounts

**Business Logic:**
1. Query MovComprobante with joins to Comprobante and Cuentas
2. Filter by date range, approved state, adjustment types
3. Optional filters for business area and cost center
4. Group by IFRS codes with hierarchical rollup
5. Calculate balances and classify into 8 columns
6. Calculate subtotals and profit/loss adjustment
7. Return structured DTO

**Complex Logic:**
- Hierarchical totaling using recursive aggregation or CTEs
- Account classification based on first digit of IFRS code
- Balance distribution logic (assets/liabilities vs results)

#### API Controller
`BalanceTributarioIfrsApiController`:
- `POST /api/balance-tributario-ifrs/generar`: Generate report
- `POST /api/balance-tributario-ifrs/exportar-excel`: Export to Excel
- `GET /api/balance-tributario-ifrs/validar-plan`: Validate chart type
- `GET /api/balance-tributario-ifrs/validar-clasificacion`: Check IFRS classification

#### MVC Controller
`BalanceTributarioIfrsController`:
- `GET /balance-tributario-ifrs`: Index view
- `POST /balance-tributario-ifrs/generar`: Generate report (calls API)
- `POST /balance-tributario-ifrs/exportar`: Excel export action

#### UI Components (Razor + JavaScript)
**Index.cshtml:**
- Date range pickers (Desde/Hasta)
- Level dropdown (1-5)
- Business area dropdown (optional)
- Cost center dropdown (optional)
- "Ver Código Cuenta" checkbox
- "Listar" button
- Excel export button
- Print button

**Results Display:**
- Responsive table with 13 columns
- Two-row header (merged cells for groups)
- Hierarchical indentation based on Nivel
- Hide/show code column based on checkbox
- Three footer rows (Subtotal, Utilidad/Pérdida, Totales)
- Double-click row to open Libro Mayor (future feature)

**JavaScript:**
- AJAX form submission
- Dynamic table rendering
- Column show/hide toggle
- Excel export via downloadable blob
- Print functionality (window.print or PDF generation)

#### Validations
1. **Date Range**: FechaDesde <= FechaHasta
2. **Required Fields**: Both dates required, Nivel required
3. **Chart of Accounts**: Warn if not predefined plan
4. **IFRS Classification**: Warn if accounts missing classification
5. **Data Availability**: Show message if no movements in range

#### Special Considerations
1. **IFRS Code Format**: Use `gFmtCodigoIFRS` format (custom formatting)
2. **Approved Only**: Filter by `Estado = APROBADO`
3. **Adjustment Types**: Include FINANCIERO and AMBOS, exclude TRIBUTARIO
4. **Hierarchical Levels**: Support up to MAX_NIVELES (typically 5)
5. **Classification Constants**: Map VB6 CLASCTA_* to enums
6. **Number Formatting**: Chilean format (thousand separator, 2 decimals)
7. **Date Format**: Chilean format (DD/MM/YYYY)
8. **Company Header**: Include in Excel export if requested
9. **Profit/Loss Label**: "Utilidad" if Ganancia > Perdida, else "Pérdida"

#### Performance Optimization
- Use EF Core query optimization (AsNoTracking)
- Consider compiled queries for frequent use
- Implement caching for dropdown data (levels, areas, cost centers)
- Paginate results if dataset is very large (unlikely for balance sheet)
- Use database-side aggregation (GROUP BY, SUM)

#### Testing Requirements
- Unit tests for balance calculation logic
- Unit tests for hierarchical totaling
- Integration tests for database queries
- UI tests for form validation
- Test with different chart of accounts plans
- Test with missing IFRS classifications
- Test edge cases (no movements, single level, all levels)

### Migration Complexity: HIGH

**Reasons:**
1. Complex hierarchical query with recursive totaling
2. Multi-level aggregation logic
3. Account classification system
4. 8-column balance distribution
5. Three-tier totaling (Subtotal, Adjustment, Total)
6. IFRS-specific validations and warnings
7. Print layout complexity
8. Excel export with optional company header

**Estimated Effort:** 3-4 days

**Dependencies:**
- All referenced entities must exist
- IFRS configuration system must be in place
- Print/export infrastructure needed
- Libro Mayor feature (for drill-down)

### Migration Priority
**HIGH** - Core financial reporting feature for IFRS compliance.

