using Microsoft.AspNetCore.Mvc.Rendering;

namespace App.Features.BalanceTributarioIfrs;

/// <summary>
/// ViewModel para la vista Index de Balance Tributario IFRS.
/// </summary>
public class BalanceTributarioIfrsIndexViewModel
{
    /// <summary>
    /// Lista de niveles disponibles (1-5).
    /// </summary>
    public List<SelectListItem> Niveles { get; set; } = new();

    /// <summary>
    /// Lista de áreas de negocio disponibles.
    /// </summary>
    public List<SelectListItem> AreasNegocio { get; set; } = new();

    /// <summary>
    /// Lista de centros de costo disponibles.
    /// </summary>
    public List<SelectListItem> CentrosCosto { get; set; } = new();

    /// <summary>
    /// Indica si el plan de cuentas es válido (Básico, Intermedio, Avanzado o IFRS).
    /// </summary>
    public bool PlanValido { get; set; }

    /// <summary>
    /// Nombre del plan de cuentas actual.
    /// </summary>
    public string PlanActual { get; set; } = "Desconocido";

    /// <summary>
    /// Fecha inicial por defecto (primer día del año actual).
    /// </summary>
    public DateTime FechaDesde { get; set; }

    /// <summary>
    /// Fecha final por defecto (fecha actual).
    /// </summary>
    public DateTime FechaHasta { get; set; }
}
