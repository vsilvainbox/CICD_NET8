using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using App.Extensions;

namespace App.Features.AuditoriaCuentasDefinidas;

/// <summary>
/// Controller MVC para la vista de auditoría de cuentas definidas
/// </summary>
[Authorize]

public class AuditoriaCuentasDefinidasController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<AuditoriaCuentasDefinidasController> logger) : Controller
{
    /// <summary>
    /// Muestra la vista principal del reporte de auditoría
    /// </summary>
    public IActionResult Index()
    {
        logger.LogInformation("Vista AuditoriaCuentasDefinidas/Index cargada");

        // Crear ViewModel con el año actual
        var viewModel = new AuditoriaCuentasDefinidasIndexViewModel
        {
            CurrentYear = DateTime.Now.Year
        };

        return View(viewModel);
    }

    /// <summary>
    /// Método proxy: Obtiene la lista de empresas disponibles
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetEmpresas()
    {
        logger.LogInformation("MVC Proxy: GetEmpresas");
        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AuditoriaCuentasDefinidasApiController>(
            HttpContext,
            nameof(AuditoriaCuentasDefinidasApiController.GetEmpresas));
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Método proxy: Obtiene la lista de años disponibles
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetYears()
    {
        logger.LogInformation("MVC Proxy: GetYears");
        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AuditoriaCuentasDefinidasApiController>(
            HttpContext,
            nameof(AuditoriaCuentasDefinidasApiController.GetYears));
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Método proxy: Obtiene la lista de usuarios disponibles
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetUsuarios()
    {
        logger.LogInformation("MVC Proxy: GetUsuarios");
        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AuditoriaCuentasDefinidasApiController>(
            HttpContext,
            nameof(AuditoriaCuentasDefinidasApiController.GetUsuarios));
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Método proxy: Obtiene el reporte de auditoría con filtros opcionales
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetFiltered(
        [FromQuery] int? idEmpresa = null,
        [FromQuery] int? annio = null,
        [FromQuery] string? usuario = null,
        [FromQuery] DateTime? fechaDesde = null,
        [FromQuery] DateTime? fechaHasta = null)
    {
        logger.LogInformation("MVC Proxy: GetFiltered");

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AuditoriaCuentasDefinidasApiController>(
            HttpContext,
            nameof(AuditoriaCuentasDefinidasApiController.GetFiltered),
            new { idEmpresa, annio, usuario, fechaDesde, fechaHasta });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Método proxy: Exporta el reporte filtrado a Excel
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ExportExcel(
        [FromQuery] int? idEmpresa = null,
        [FromQuery] int? annio = null,
        [FromQuery] string? usuario = null,
        [FromQuery] DateTime? fechaDesde = null,
        [FromQuery] DateTime? fechaHasta = null)
    {
        logger.LogInformation("MVC Proxy: ExportExcel");

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AuditoriaCuentasDefinidasApiController>(
            HttpContext,
            nameof(AuditoriaCuentasDefinidasApiController.ExportExcel),
            new { idEmpresa, annio, usuario, fechaDesde, fechaHasta });
        var (fileBytes, contentType) = await client.DownloadFileAsync(url, HttpMethod.Get, null);
        var fileName = $"AuditoriaCuentasDefinidas_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx";

        return File(fileBytes, contentType, fileName);
    }
}