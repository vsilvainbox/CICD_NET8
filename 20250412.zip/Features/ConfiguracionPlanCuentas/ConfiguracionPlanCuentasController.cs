using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using App.Extensions;
using App.Helpers;

namespace App.Features.ConfiguracionPlanCuentas;

[Authorize]



public class ConfiguracionPlanCuentasController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<ConfiguracionPlanCuentasController> logger) : Controller
{
    [HttpGet]
    public Task<IActionResult> Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a la Configuración del Plan de Cuentas";
            TempData["SwalType"] = "warning";
            return Task.FromResult<IActionResult>(RedirectToAction("Index", "SeleccionarEmpresa"));
        }

        // Extraer datos de HttpContext usando extensiones
        var empresaId = SessionHelper.EmpresaId;
        int ano = SessionHelper.Ano;

        logger.LogInformation("Loading ConfiguracionPlanCuentas for empresaId: {EmpresaId}, ano: {Ano}",
            empresaId, ano);

        var viewModel = new ConfiguracionPlanCuentasIndexViewModel
        {
            EmpresaId = empresaId,
            Ano = ano
        };

        return Task.FromResult<IActionResult>(View(viewModel));
    }

    [HttpGet]
    public async Task<IActionResult> Franquicias()
    {
        logger.LogInformation("Proxy: Getting franquicias");

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionPlanCuentasApiController>(
            HttpContext,
            nameof(ConfiguracionPlanCuentasApiController.GetFranquicias));
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    [HttpGet]
    public async Task<IActionResult> FranquiciaActiva(int empresaId)
    {
        logger.LogInformation("Proxy: Getting franquicia activa for empresaId: {EmpresaId}", empresaId);

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionPlanCuentasApiController>(
            HttpContext,
            nameof(ConfiguracionPlanCuentasApiController.GetFranquiciaActiva),
            new { empresaId });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    [HttpGet]
    public async Task<IActionResult> Preview(int empresaId, int franquiciaId)
    {
        logger.LogInformation("Proxy: Getting preview for empresaId: {EmpresaId}, franquiciaId: {FranquiciaId}", empresaId, franquiciaId);

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionPlanCuentasApiController>(
            HttpContext,
            nameof(ConfiguracionPlanCuentasApiController.GetPreview),
            new { empresaId, franquiciaId });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    [HttpPost]
    public async Task<IActionResult> Aplicar([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: Applying plan de cuentas configuration");
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionPlanCuentasApiController>(
            HttpContext,
            nameof(ConfiguracionPlanCuentasApiController.Aplicar),
            new { userId = HttpContext.GetCurrentUserId() });
        var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }
}
