﻿namespace App.Features.ConfiguracionPlanCuentas;

/// <summary>
/// Servicio para configuración de plan de cuentas predefinido según franquicia tributaria
/// </summary>
public interface IConfiguracionPlanCuentasService
{
    // ======== Configuración de Franquicia ========

    /// <summary>
    /// Obtiene la configuración actual de franquicia de una empresa
    /// </summary>
    Task<ConfiguracionActualDto?> GetConfiguracionActualAsync(int empresaId);

    /// <summary>
    /// Obtiene el listado de franquicias tributarias disponibles
    /// </summary>
    Task<List<FranquiciaTributariaDto>> GetFranquiciasDisponiblesAsync();

    /// <summary>
    /// Obtiene el ID de la franquicia activa para una empresa (0-8, null si ninguna)
    /// </summary>
    Task<int?> GetFranquiciaActivaAsync(int empresaId);

    /// <summary>
    /// Valida y actualiza la franquicia tributaria seleccionada
    /// Resetea todas las franquicias y activa solo la seleccionada
    /// Lanza BusinessException si la franquicia o empresa no es válida
    /// </summary>
    Task ValidarYActualizarFranquiciaAsync(int empresaId, int franquiciaId);

    // ======== Plan de Cuentas Predefinido ========

    /// <summary>
    /// Genera preview del plan de cuentas predefinido sin aplicar cambios
    /// </summary>
    Task<PlanCuentasPreviewDto> PreviewPlanCuentasAsync(int empresaId, int franquiciaId);

    /// <summary>
    /// Aplica el plan de cuentas predefinido según franquicia seleccionada
    /// Actualiza franquicia y crea cuentas contables automáticamente
    /// </summary>
    Task<ResultadoAplicacionDto> AplicarPlanCuentasAsync(int empresaId, short ano, int franquiciaId, int userId, bool sobreescribir = false);

    /// <summary>
    /// Valida si se puede aplicar el plan de cuentas (verifica cuentas existentes)
    /// </summary>
    Task<ValidacionFranquiciaDto> ValidarAplicacionAsync(int empresaId, short ano, int franquiciaId);

    // ======== Cuentas Predefinidas ========

    /// <summary>
    /// Obtiene las cuentas predefinidas para una franquicia específica
    /// </summary>
    Task<List<CuentaPredefinidaDto>> GetCuentasPredefinidasAsync(int franquiciaId);

    /// <summary>
    /// Verifica si una cuenta ya existe en el plan actual
    /// </summary>
    Task<bool> CuentaExisteAsync(int empresaId, short ano, string codigoCuenta);
}
