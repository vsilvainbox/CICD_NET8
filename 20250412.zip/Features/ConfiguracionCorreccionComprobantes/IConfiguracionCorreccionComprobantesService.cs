﻿namespace App.Features.ConfiguracionCorreccionComprobantes;

/// <summary>
/// Servicio para gestionar la configuración de comprobantes contables
/// </summary>
public interface IConfiguracionCorreccionComprobantesService
{
    /// <summary>
    /// Obtiene la configuración actual de comprobantes para una empresa y año
    /// </summary>
    Task<ConfiguracionCorreccionComprobantesDto> GetConfiguracionAsync(int empresaId, short ano);
    
    /// <summary>
    /// Actualiza la configuración de comprobantes
    /// </summary>
    Task ActualizarConfiguracionAsync(ActualizarConfiguracionCorreccionComprobantesDto dto);
    
    /// <summary>
    /// Aplica la opción "Imprimir Resumido" a todos los comprobantes de centralización existentes
    /// </summary>
    Task<ActualizarResumidoCentralizacionResultDto> AplicarResumidoCentralizacionAsync(int empresaId, short ano);
}
