using System.ComponentModel.DataAnnotations;

namespace App.Features.ConfiguracionCorreccionComprobantes;

/// <summary>
/// DTO para obtener la configuraci�n actual de comprobantes
/// </summary>
public class ConfiguracionCorreccionComprobantesDto
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    
    // Correlativos
    public int TipoCorrelativo { get; set; }
    public int PeriodoCorrelativo { get; set; }
    
    // Opciones
    public bool ComprobanteAprobadoAutomaticamente { get; set; }
    public bool PermitirAbrirMesesParalelo { get; set; }
    public bool MostrarComprobantesAnuladosEnLibroDiario { get; set; }
    
    // Impresi�n
    public int OpcionImpresionDetalleMovimiento { get; set; }
    public bool ImprimirResumidoCentralizacion { get; set; }
    public bool IncluirTipoComprobanteEnTitulo { get; set; }
    
    // Fecha centralizaci�n
    public int OpcionFechaCentralizacion { get; set; }
    public int? DiaEspecificoCentralizacion { get; set; }
    
    // Estado
    public bool PermiteModificarCorrelativo { get; set; }
    public bool FuncionalidadComprobantesResumidosDisponible { get; set; }
}

/// <summary>
/// DTO para actualizar la configuraci�n de comprobantes
/// </summary>
public class ActualizarConfiguracionCorreccionComprobantesDto
{
    [Required]
    [Range(1, int.MaxValue, ErrorMessage = "EmpresaId debe ser mayor a 0")]
    public int EmpresaId { get; set; }
    
    [Required]
    [Range(2000, 2100, ErrorMessage = "A�o debe estar entre 2000 y 2100")]
    public short Ano { get; set; }
    
    // Correlativos
    [Required]
    [Range(1, 2, ErrorMessage = "Tipo correlativo debe ser 1 (�nico) o 2 (Por tipo)")]
    public int TipoCorrelativo { get; set; }
    
    [Required]
    [Range(1, 3, ErrorMessage = "Per�odo correlativo debe ser 1 (Mensual), 2 (Anual) o 3 (Continuo)")]
    public int PeriodoCorrelativo { get; set; }
    
    // Opciones
    public bool ComprobanteAprobadoAutomaticamente { get; set; }
    public bool PermitirAbrirMesesParalelo { get; set; }
    public bool MostrarComprobantesAnuladosEnLibroDiario { get; set; }
    
    // Impresi�n
    [Required]
    [Range(1, 4, ErrorMessage = "Opci�n impresi�n detalle movimiento debe estar entre 1 y 4")]
    public int OpcionImpresionDetalleMovimiento { get; set; }
    
    public bool ImprimirResumidoCentralizacion { get; set; }
    public bool IncluirTipoComprobanteEnTitulo { get; set; }
    
    // Fecha centralizaci�n
    [Required]
    [Range(1, 3, ErrorMessage = "Opci�n fecha centralizaci�n debe ser 1 (Predefinida), 2 (�ltimo d�a) o 3 (D�a espec�fico)")]
    public int OpcionFechaCentralizacion { get; set; }
    
    [Range(1, 30, ErrorMessage = "D�a espec�fico debe estar entre 1 y 30")]
    public int? DiaEspecificoCentralizacion { get; set; }
}

/// <summary>
/// DTO para el resultado de aplicar impresión resumida a centralizaciones existentes
/// </summary>
public class ActualizarResumidoCentralizacionResultDto
{
    public int ComprobantesActualizados { get; set; }
    public bool Exito { get; set; }
    public string? Mensaje { get; set; }
}
