using Microsoft.AspNetCore.Mvc;

namespace App.Features.ConfiguracionCorreccionComprobantes;

[ApiController]
[Route("[controller]/[action]")]
public class ConfiguracionCorreccionComprobantesApiController(
    IConfiguracionCorreccionComprobantesService service,
    ILogger<ConfiguracionCorreccionComprobantesApiController> logger) : ControllerBase
{
    /// <summary>
    /// Obtiene la configuraciÃ³n actual de comprobantes
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<ConfiguracionCorreccionComprobantesDto>> GetConfiguracion(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        var config = await service.GetConfiguracionAsync(empresaId, ano);
        return Ok(config);
    }
    
    /// <summary>
    /// Actualiza la configuración de comprobantes
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> ActualizarConfiguracion(
        [FromBody] ActualizarConfiguracionCorreccionComprobantesDto dto)
    {
        await service.ActualizarConfiguracionAsync(dto);
        return Ok();
    }
    
    /// <summary>
    /// Aplica la opciÃ³n "Imprimir Resumido" a todos los comprobantes de centralizaciÃ³n existentes
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<ActualizarResumidoCentralizacionResultDto>> AplicarResumidoCentralizacion(
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        var resultado = await service.AplicarResumidoCentralizacionAsync(empresaId, ano);
        return Ok(resultado);
    }
}
