namespace App.Features.BalanceClasificado;

/// <summary>
/// Interfaz para el servicio de Estado de Resultados por Función
/// </summary>
public interface IEstadoResultadosService
{
    /// <summary>
    /// Genera el estado de resultados por función
    /// </summary>
    Task<EstadoResultadosResponse> GenerarEstadoResultadosAsync(EstadoResultadosRequest request);

    /// <summary>
    /// Obtiene las funciones disponibles para clasificación
    /// </summary>
    Task<List<FuncionCuenta>> ObtenerFuncionesAsync();

    /// <summary>
    /// Exporta el estado de resultados a Excel o PDF
    /// </summary>
    Task<EstadoResultadosExportResponse> ExportarEstadoResultadosAsync(EstadoResultadosExportRequest request);

    /// <summary>
    /// Obtiene análisis vertical y horizontal
    /// </summary>
    Task<AnalisisEstadoResultados> ObtenerAnalisisAsync(EstadoResultadosRequest request);

    /// <summary>
    /// Obtiene datos para gráficos
    /// </summary>
    Task<EstadoResultadosGraficos> ObtenerGraficosAsync(EstadoResultadosRequest request);
}