using Microsoft.AspNetCore.Mvc;

namespace App.Features.BalanceClasificado;

/// <summary>
/// API Controller para Estado de Resultados por Función
/// Migrado de VB6 FrmBalanceClasificado.frm
/// </summary>
[ApiController]
[Route("[controller]/[action]")]
public class EstadoResultadosApiController(
    IEstadoResultadosService service,
    ILogger<EstadoResultadosApiController> logger) : ControllerBase
{
    /// <summary>
    /// Genera el estado de resultados por función
    /// POST /api/EstadoResultados/generar
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<EstadoResultadosResponse>> Generar([FromBody] EstadoResultadosRequest request)
    {
        logger.LogInformation("API: Generar estado de resultados para empresa {EmpresaId}, año {Ano}", 
            request.EmpresaId, request.Ano);

        {
            var resultado = await service.GenerarEstadoResultadosAsync(request);
            logger.LogInformation("API: Estado de resultados generado con {FilasCount} filas", 
                resultado.Filas?.Count ?? 0);
            return Ok(resultado);
        }
    }

    /// <summary>
    /// Exporta el estado de resultados a Excel o PDF
    /// POST /api/EstadoResultados/exportar
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Exportar([FromBody] EstadoResultadosExportRequest request)
    {
        logger.LogInformation("API: Exportar estado de resultados a {Formato}", request.Formato);

        {
            var result = await service.ExportarEstadoResultadosAsync(request);
            return File(result.FileContent, result.ContentType, result.FileName);
        }
    }

    /// <summary>
    /// Obtiene análisis vertical y horizontal del estado de resultados
    /// POST /api/EstadoResultados/analisis
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<AnalisisEstadoResultados>> ObtenerAnalisis([FromBody] EstadoResultadosRequest request)
    {
        logger.LogInformation("API: Obtener análisis para empresa {EmpresaId}, año {Ano}", 
            request.EmpresaId, request.Ano);

        {
            var analisis = await service.ObtenerAnalisisAsync(request);
            return Ok(analisis);
        }
    }

    /// <summary>
    /// Obtiene datos para gráficos del estado de resultados
    /// POST /api/EstadoResultados/graficos
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<EstadoResultadosGraficos>> ObtenerGraficos([FromBody] EstadoResultadosRequest request)
    {
        logger.LogInformation("API: Obtener gráficos para empresa {EmpresaId}, año {Ano}", 
            request.EmpresaId, request.Ano);

        {
            var graficos = await service.ObtenerGraficosAsync(request);
            return Ok(graficos);
        }
    }

    /// <summary>
    /// Obtiene las funciones disponibles para clasificación
    /// GET /api/EstadoResultados/funciones
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<List<FuncionCuenta>>> ObtenerFunciones()
    {
        logger.LogInformation("API: Obtener funciones disponibles");

        {
            var funciones = await service.ObtenerFuncionesAsync();
            return Ok(funciones);
        }
    }
}
