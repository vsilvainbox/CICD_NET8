using System.ComponentModel.DataAnnotations;

namespace App.Features.BalanceClasificado;

/// <summary>
/// DTO para solicitar un estado de resultados por función
/// </summary>
public class EstadoResultadosRequest
{
    [Required]
    public int EmpresaId { get; set; }

    [Required]
    public short Ano { get; set; }

    [Required]
    public DateTime FechaDesde { get; set; }

    [Required]
    public DateTime FechaHasta { get; set; }

    public byte? Nivel { get; set; }

    public byte? TipoAjuste { get; set; }

    public int? AreaNegocioId { get; set; }

    public int? CentroCostoId { get; set; }

    public bool SoloLibroOficial { get; set; } = false;

    public bool VerSubTotales { get; set; } = true;

    public bool VerCodigoCuenta { get; set; } = false;

    public bool MostrarComparativo { get; set; } = false;
}

/// <summary>
/// DTO para respuesta del estado de resultados
/// </summary>
public class EstadoResultadosResponse
{
    public List<EstadoResultadosFila> Filas { get; set; } = new();
    public EstadoResultadosTotales Totales { get; set; } = new();
    public EstadoResultadosFiltros Filtros { get; set; } = new();
    public DateTime FechaGeneracion { get; set; } = DateTime.Now;
}

/// <summary>
/// DTO para una fila del estado de resultados
/// </summary>
public class EstadoResultadosFila
{
    public byte Nivel { get; set; }
    public string CodigoCuenta { get; set; } = string.Empty;
    public string NombreCuenta { get; set; } = string.Empty;
    public string Funcion { get; set; } = string.Empty; // Administración, Ventas, Producción, etc.
    public double MontoActual { get; set; }
    public double MontoAnterior { get; set; } // Para comparativo
    public double Variacion { get; set; }
    public double VariacionPorcentaje { get; set; }
    public bool EsTotal { get; set; } = false;
    public bool EsSubTotal { get; set; } = false;
    public bool EsGrupo { get; set; } = false;
    public string TipoLinea { get; set; } = string.Empty; // Ingreso, Costo, Gasto, Resultado
    public int? IdCuenta { get; set; }
    public bool EsVisible { get; set; } = true;
}

/// <summary>
/// DTO para totales del estado de resultados
/// </summary>
public class EstadoResultadosTotales
{
    public double TotalIngresos { get; set; }
    public double TotalCostosVenta { get; set; }
    public double UtilidadBruta { get; set; }
    public double TotalGastosAdministracion { get; set; }
    public double TotalGastosVentas { get; set; }
    public double UtilidadOperacional { get; set; }
    public double TotalIngresosNoOperacionales { get; set; }
    public double TotalGastosNoOperacionales { get; set; }
    public double TotalGastosFinancieros { get; set; }
    public double ResultadoAntesImpuesto { get; set; }
    public double ImpuestoRenta { get; set; }
    public double ResultadoNeto { get; set; }

    // Indicadores
    public double MargenBruto => TotalIngresos != 0 ? (UtilidadBruta / TotalIngresos) * 100 : 0;
    public double MargenOperacional => TotalIngresos != 0 ? (UtilidadOperacional / TotalIngresos) * 100 : 0;
    public double MargenNeto => TotalIngresos != 0 ? (ResultadoNeto / TotalIngresos) * 100 : 0;
}

/// <summary>
/// DTO para filtros aplicados al estado de resultados
/// </summary>
public class EstadoResultadosFiltros
{
    public DateTime FechaDesde { get; set; }
    public DateTime FechaHasta { get; set; }
    public byte? Nivel { get; set; }
    public byte? TipoAjuste { get; set; }
    public string? AreaNegocio { get; set; }
    public string? CentroCosto { get; set; }
    public bool SoloLibroOficial { get; set; }
    public bool VerSubTotales { get; set; }
    public bool VerCodigoCuenta { get; set; }
    public bool MostrarComparativo { get; set; }
}

/// <summary>
/// DTO para clasificación de cuentas por función
/// </summary>
public class FuncionCuenta
{
    public int IdFuncion { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public string Descripcion { get; set; } = string.Empty;
    public int Orden { get; set; }
    public string TipoLinea { get; set; } = string.Empty; // Ingreso, Costo, Gasto
    public string RangoCuentasDesde { get; set; } = string.Empty;
    public string RangoCuentasHasta { get; set; } = string.Empty;
}

/// <summary>
/// DTO para exportar estado de resultados
/// </summary>
public class EstadoResultadosExportRequest
{
    [Required]
    public int EmpresaId { get; set; }

    [Required]
    public short Ano { get; set; }

    [Required]
    public DateTime FechaDesde { get; set; }

    [Required]
    public DateTime FechaHasta { get; set; }

    public byte? Nivel { get; set; }
    public byte? TipoAjuste { get; set; }
    public int? AreaNegocioId { get; set; }
    public int? CentroCostoId { get; set; }
    public bool SoloLibroOficial { get; set; } = false;
    public bool VerSubTotales { get; set; } = true;
    public bool VerCodigoCuenta { get; set; } = false;
    public bool MostrarComparativo { get; set; } = false;
    public string Formato { get; set; } = "Excel"; // Excel, PDF
}

/// <summary>
/// DTO para an�lisis vertical y horizontal
/// </summary>
public class AnalisisEstadoResultados
{
    public List<AnalisisVerticalItem> AnalisisVertical { get; set; } = new();
    public List<AnalisisHorizontalItem> AnalisisHorizontal { get; set; } = new();
    public RatiosFinancieros Ratios { get; set; } = new();
}

/// <summary>
/// DTO para an�lisis vertical (% sobre ingresos)
/// </summary>
public class AnalisisVerticalItem
{
    public string Concepto { get; set; } = string.Empty;
    public double Monto { get; set; }
    public double Porcentaje { get; set; }
}

/// <summary>
/// DTO para an�lisis horizontal (comparación per�odos)
/// </summary>
public class AnalisisHorizontalItem
{
    public string Concepto { get; set; } = string.Empty;
    public double MontoActual { get; set; }
    public double MontoAnterior { get; set; }
    public double Variacion { get; set; }
    public double VariacionPorcentaje { get; set; }
}

/// <summary>
/// DTO para ratios financieros calculados
/// </summary>
public class RatiosFinancieros
{
    public double MargenBruto { get; set; }
    public double MargenOperacional { get; set; }
    public double MargenNeto { get; set; }
    public double ROA { get; set; } // Return on Assets
    public double ROE { get; set; } // Return on Equity
    public double EBITDA { get; set; }
    public double MargenEBITDA { get; set; }
}

/// <summary>
/// DTO para gr�ficos y visualizaciones
/// </summary>
public class EstadoResultadosGraficos
{
    public List<GraficoDataPoint> IngresosPorFuncion { get; set; } = new();
    public List<GraficoDataPoint> GastosPorFuncion { get; set; } = new();
    public List<GraficoDataPoint> EvolucionMensual { get; set; } = new();
    public List<GraficoDataPoint> ComposicionIngresos { get; set; } = new();
    public List<GraficoDataPoint> ComposicionGastos { get; set; } = new();
}

/// <summary>
/// DTO para punto de datos en gr�ficos
/// </summary>
public class GraficoDataPoint
{
    public string Etiqueta { get; set; } = string.Empty;
    public double Valor { get; set; }
    public string Color { get; set; } = string.Empty;
}

/// <summary>
/// DTO para respuesta de exportación de estado de resultados
/// </summary>
public class EstadoResultadosExportResponse
{
    public byte[] FileContent { get; set; } = Array.Empty<byte>();
    public string ContentType { get; set; } = string.Empty;
    public string FileName { get; set; } = string.Empty;
}

