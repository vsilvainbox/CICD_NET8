# BalanceClasificado - Análisis VB6 - PARTE 3: LOADALL Y QUERY LOGIC

**Continúa de:** `Analysis-Part2-EventHandlers.md`

---

## 🔍 PROCEDIMIENTO LOADALL - GENERACIÓN DEL REPORTE

**Ubicación VB6:** FrmBalClasif.frm líneas 949-1583 (634 líneas)  
**Propósito:** Genera el balance clasificado consultando cuentas por niveles jerárquicos

### Estructura General de LoadAll

```vb6
Private Sub LoadAll()
  ' 1. Variables de control
  Dim Nivel As Integer
  Dim Rs As Recordset
  Dim Total(MAX_NIVELES) As RepNiv_t  ' Totales por nivel
  Dim TotalMes(MAX_NIVELES, 12) As RepNiv_t  ' Totales por mes
  Dim CurNiv As Integer  ' Nivel actual
  Dim CurCta As String   ' Cuenta actual
  Dim Row As Integer     ' Fila actual del Grid
  Dim ClasifPadre As Integer  ' Clasificación cuenta padre
  Dim TotClasif(MAX_CLASCTA) As Double  ' Totales por clasificación
  Dim LinTotClasif(MAX_CLASCTA) As Integer  ' Línea total clasificación
  Dim LinResEjercicio(MAX_NIVELES) As Integer  ' Línea resultado ejercicio
  Dim LinPatrimonio As Integer  ' Línea patrimonio
  
  ' 2. Obtener nivel seleccionado
  Nivel = Val(Cb_Nivel)  ' 2, 3, 4 o 5
  
  Grid.Redraw = False
  
  ' 3. Construir WHERE clause con filtros
  FDesde = GetTxDate(Tx_Desde)
  FHasta = GetTxDate(Tx_Hasta)
  WhFecha = "Comprobante.Fecha BETWEEN " & FDesde & " AND " & FHasta
  
  If ItemData(Cb_AreaNeg) > 0 Then
    Wh = Wh & " AND MovComprobante.IdAreaNeg = " & CbItemData(Cb_AreaNeg)
  End If
  
  If ItemData(Cb_CCosto) > 0 Then
    Wh = Wh & " AND MovComprobante.IdCCosto = " & ItemData(Cb_CCosto)
  End If
  
  If ItemData(Cb_TipoAjuste) > 0 Then
    If ItemData(Cb_TipoAjuste) = TAJUSTE_FINANCIERO Then
      Wh = Wh & " AND (Comprobante.TipoAjuste IS NULL OR " & _
                "Comprobante.TipoAjuste IN (1,3))"  ' FINANCIERO + AMBOS
    Else
      Wh = Wh & " AND Comprobante.TipoAjuste IN (2,3)"  ' TRIBUTARIO + AMBOS
    End If
  End If
  
  ' 4. QUERY PRINCIPAL: GenQueryPorNiveles
  Q1 = GenQueryPorNiveles(Nivel, WhFecha & Wh, Ch_LibOficial <> 0, _
                          lClasCta, lMensual)
  Set Rs = OpenRs(DbMain, Q1)
  
  ' 5. Inicializar totales
  For j = 0 To MAX_NIVELES
    Total(j).Debe = 0
    Total(j).Haber = 0
    Total(j).Linea = 0
    For k = 0 To 12
      TotalMes(j, k).Debe = 0
      TotalMes(j, k).Haber = 0
      TotalMes(j, k).Linea = 0
    Next k
  Next j
  
  ' 6. Configurar columnas mensuales si aplica
  If lMensual And Not lComparativo Then
    For k = 1 To 12
      Mes = C_INI_MES + k - 1
      Grid.ColWidth(Mes) = G_VALWIDTH + 100
      Grid.TextMatrix(0, Mes) = gNomMes(k)  ' "Enero", "Febrero", ...
    Next k
  End If
  
  Grid.rows = Grid.FixedRows
  i = Grid.rows - 1
  
  CurNiv = 0
  CurCta = ""
  CodPadre = ""
  NomPadre = ""
  
  ' 7. LOOP PRINCIPAL: Procesar recordset
  Do While Rs.EOF = False
    ' Detectar cambio de cuenta padre (nivel 1)
    If vFld(Rs("Nivel")) = 1 Then
      ' Agregar línea TOTAL del padre anterior
      If CodPadre <> "" Then
        ' ... (Ver sección 7.1 más abajo)
      End If
      
      ' Nueva cuenta de nivel 1 (ACTIVO, PASIVO, RESULTADO)
      CodPadre = vFld(Rs("Codigo"))
      NomPadre = vFld(Rs("Descripcion"))
      ClasifPadre = vFld(Rs("Clasificacion"))
      
      ' Resetear totales de nivel
      For j = 1 To MAX_NIVELES
        Total(j).Debe = 0
        Total(j).Haber = 0
        Total(j).Linea = 0
      Next j
      
      LinPatrimonio = i  ' Guardar línea para insertar Res.Ejercicio después
    End If
    
    ' Agregar fila de cuenta al grid
    i = i + 1
    Grid.rows = i + 1
    
    Grid.TextMatrix(i, C_IDCUENTA) = vFld(Rs("idCuenta"))
    Grid.TextMatrix(i, C_CODIGO) = vFld(Rs("Codigo"))
    Grid.TextMatrix(i, C_CUENTA) = vFld(Rs("Descripcion"))
    Grid.TextMatrix(i, C_NIVEL) = vFld(Rs("Nivel"))
    Grid.TextMatrix(i, C_CLASCTA) = vFld(Rs("Clasificacion"))
    
    ' Formatear valores
    Grid.TextMatrix(i, C_DEBITOS) = Format(vFld(Rs("Debe")), NEGNUMFMT)
    Grid.TextMatrix(i, C_CREDITOS) = Format(vFld(Rs("Haber")), NEGNUMFMT)
    
    ' Calcular saldo según clasificación
    If ClasifPadre = CLASCTA_ACTIVO Then
      Diff = vFld(Rs("Debe")) - vFld(Rs("Haber"))
    ElseIf ClasifPadre = CLASCTA_PASIVO Or ClasifPadre = CLASCTA_RESULTADO Then
      Diff = vFld(Rs("Haber")) - vFld(Rs("Debe"))
    End If
    
    Grid.TextMatrix(i, C_SALDO) = Format(Diff, NEGNUMFMT)
    
    ' Aplicar formato según nivel
    If vFld(Rs("Nivel")) = 1 Then
      Call FGrSetRowStyle(Grid, i, "BU")  ' Bold + Underline
    ElseIf vFld(Rs("Nivel")) = 2 Then
      Call FGrSetRowStyle(Grid, i, "B")   ' Bold
    End If
    
    ' Acumular totales por nivel
    For j = vFld(Rs("Nivel")) To 1 Step -1
      Total(j).Debe = Total(j).Debe + vFld(Rs("Debe"))
      Total(j).Haber = Total(j).Haber + vFld(Rs("Haber"))
    Next j
    
    Rs.MoveNext
  Loop
  
  ' 8. Agregar TOTAL del último padre
  ' ... (Similar a 7.1)
  
  ' 9. Cerrar recordset y finalizar
  Rs.Close
  Grid.Redraw = True
  
  Bt_Buscar.Enabled = False  ' Deshabilitar hasta nuevo cambio
End Sub
```

---

## 📊 SECCIÓN 7.1: AGREGADO DE LÍNEA TOTAL

```vb6
' Cuando cambia de cuenta padre, agrega línea TOTAL del padre anterior
If CodPadre <> "" Then
  ' Insertar Resultado del Ejercicio si es PASIVO
  If lBalClasif And ClasifPadre = CLASCTA_PASIVO Then
    Call AddResEjercicio(i, LinPatrimonio, LinResEjercicio)
  End If
  
  ' Agregar fila TOTAL
  i = i + 1
  Grid.rows = i + 1
  Call FGrSetRowStyle(Grid, i, "B")  ' Bold
  
  Grid.TextMatrix(i, C_CUENTA) = "TOTAL " & UCase(NomPadre)
  Grid.TextMatrix(i, C_IDCUENTA) = TOT_CUENTA  ' -1 (identificador)
  Grid.TextMatrix(i, C_CLASCTA) = ClasifPadre
  Grid.TextMatrix(i, C_FMT) = "B"
  
  ' Valores del total
  Grid.TextMatrix(i, C_DEBITOS) = Format(Total(1).Debe, NEGNUMFMT)
  Grid.TextMatrix(i, C_CREDITOS) = Format(Total(1).Haber, NEGNUMFMT)
  
  ' Calcular total según clasificación
  If ClasifPadre = CLASCTA_ACTIVO Then
    TotClasif(ClasifPadre) = Total(1).Debe - Total(1).Haber
  ElseIf ClasifPadre = CLASCTA_PASIVO Or ClasifPadre = CLASCTA_RESULTADO Then
    TotClasif(ClasifPadre) = Total(1).Haber - Total(1).Debe
  End If
  
  Grid.TextMatrix(i, C_SALDO) = Format(TotClasif(ClasifPadre), NEGNUMFMT)
  
  LinTotClasif(ClasifPadre) = i  ' Guardar línea del total
  
  ' Ocultar subtotales de RESULTADO si Ch_VerSubTot = 0
  If ClasifPadre = CLASCTA_RESULTADO Then
    If Ch_VerSubTot = 0 Then
      Grid.RowHeight(i) = 0
    End If
  End If
  
  ' Agregar columnas mensuales si aplica
  If lMensual Then
    For k = 1 To 12
      Mes = C_INI_MES + k - 1
      If ClasifPadre = CLASCTA_ACTIVO Then
        Grid.TextMatrix(i, Mes) = Format(TotalMes(1, k).Debe - TotalMes(1, k).Haber, NEGNUMFMT)
      Else
        Grid.TextMatrix(i, Mes) = Format(TotalMes(1, k).Haber - TotalMes(1, k).Debe, NEGNUMFMT)
      End If
    Next k
  End If
End If
```

---

## 🧮 ADDRESEJERCICIO - INSERTAR RESULTADO EJERCICIO

```vb6
Private Sub AddResEjercicio(i As Integer, LinPatrimonio As Integer, _
                            LinResEjercicio() As Integer)
  ' Insertar línea "Resultado del Ejercicio" en Balance Clasificado
  ' Solo aplica para Balance (no Estado de Resultados)
  ' Se inserta después de PASIVO y antes del TOTAL PATRIMONIO
  
  Dim ResEjercicio As Double
  Dim k As Integer, Mes As Integer
  
  ' Calcular Resultado = Ingresos - Gastos = Pasivo - Activo
  ResEjercicio = TotClasif(CLASCTA_PASIVO) - TotClasif(CLASCTA_ACTIVO)
  
  ' Insertar fila
  i = i + 1
  Grid.rows = i + 1
  
  Grid.TextMatrix(i, C_IDCUENTA) = 0
  Grid.TextMatrix(i, C_CODIGO) = ""
  Grid.TextMatrix(i, C_CUENTA) = "Resultado del Ejercicio"
  Grid.TextMatrix(i, C_NIVEL) = 1
  Grid.TextMatrix(i, C_CLASCTA) = CLASCTA_PASIVO
  Grid.TextMatrix(i, C_FMT) = "B"
  
  Grid.TextMatrix(i, C_DEBITOS) = ""
  Grid.TextMatrix(i, C_CREDITOS) = ""
  Grid.TextMatrix(i, C_SALDO) = Format(ResEjercicio, NEGNUMFMT)
  
  Call FGrSetRowStyle(Grid, i, "B")
  
  LinResEjercicio(1) = i
  
  ' Actualizar total PASIVO + Resultado
  TotClasif(CLASCTA_PASIVO) = TotClasif(CLASCTA_PASIVO) + ResEjercicio
  
  ' Columnas mensuales si aplica
  If lMensual Then
    For k = 1 To 12
      Mes = C_INI_MES + k - 1
      ' Calcular resultado mensual...
      Grid.TextMatrix(i, Mes) = Format(ResEjercicioMes(k), NEGNUMFMT)
    Next k
  End If
End Sub
```

---

## 🔍 GENQUERYPORNIVELES - QUERY SQL JERÁRQUICA

**Ubicación:** HyperCont.bas línea 3291  
**Propósito:** Genera query SQL que suma movimientos por niveles jerárquicos

### Firma de la Función

```vb6
Public Function GenQueryPorNiveles(
  ByVal Nivel As Integer,         ' Nivel de detalle (2-5)
  ByVal Where As String,          ' WHERE clause de filtros
  ByVal LibOficial As Boolean,    ' Solo APROBADOS?
  Optional ByVal ClasCta As String = "",  ' Clasificaciones ("1,2,3")
  Optional ByVal Mensual As Boolean = False,  ' Columnas mensuales?
  Optional ByVal TipoDesglose As String = "",  ' "CCOSTO" o "AREANEG"
  Optional ByVal WhDesglose As String = "",
  Optional ByVal Ano As Integer = 0,
  Optional ByVal ConOrderBy As Boolean = True
) As String
```

### Estructura de la Query

La función genera un UNION de hasta 6 queries:

1. **Query 1 (IdQ=1)**: Lista TODAS las cuentas del nivel solicitado y menores, con Debe=0, Haber=0  
   *Propósito*: Asegurar que cuentas sin movimientos aparezcan

2. **Query 2 (IdQ=2)**: Suma movimientos de cuentas del nivel exacto  
   *FROM*: Cuentas INNER JOIN MovComprobante INNER JOIN Comprobante  
   *GROUP BY*: Cuentas.idCuenta, Codigo, Nivel, Descripcion, Clasificacion

3. **Query 3 (IdQ=3)**: Suma movimientos de cuentas cuyo padre es del nivel solicitado  
   *JOIN adicional*: Cuentas_1 (padre)  
   *WHERE*: Cuentas_1.Nivel = [Nivel]

4. **Query 4 (IdQ=4)**: Suma movimientos de cuentas cuyo abuelo es del nivel solicitado  
   *JOIN adicional*: Cuentas_2 (abuelo)

5. **Query 5 (IdQ=5)**: Suma movimientos de cuentas cuyo bisabuelo es del nivel solicitado  
   *JOIN adicional*: Cuentas_3 (bisabuelo)

6. **Query 6 (IdQ=6)**: Suma movimientos de cuentas cuyo tatarabuelo es del nivel solicitado  
   *JOIN adicional*: Cuentas_4 (tatarabuelo)

### Ejemplo Query Nivel 3 (Simplificado)

```sql
-- Query 1: Cuentas sin movimientos
SELECT 1 as IdQ, idCuenta, Codigo, Nivel, Descripcion, 
       0 as Debe, 0 as Haber, Clasificacion
FROM Cuentas
WHERE Nivel <= 3 
  AND IdEmpresa = 1 AND Ano = 2025
  AND Clasificacion IN (1,2)  -- Si lClasCta especificado

UNION

-- Query 2: Cuentas nivel 3 con movimientos directos
SELECT 2 as IdQ, C.idCuenta, C.Codigo, C.Nivel, C.Descripcion,
       SUM(M.Debe) as Debe, SUM(M.Haber) as Haber, C.Clasificacion
FROM Cuentas C
INNER JOIN MovComprobante M ON C.idCuenta = M.IdCuenta
INNER JOIN Comprobante CO ON M.IdComp = CO.IdComp
WHERE C.Nivel <= 3
  AND CO.Fecha BETWEEN 20250101 AND 20251231
  AND CO.Estado IN (1,2)  -- APROBADO + PENDIENTE (si no es oficial)
  AND C.Clasificacion IN (1,2)
GROUP BY C.idCuenta, C.Codigo, C.Nivel, C.Descripcion, C.Clasificacion

UNION

-- Query 3: Padres de nivel 3 (suma de hijos nivel 4)
SELECT 3 as IdQ, C1.idCuenta, C1.Codigo, C1.Nivel, C1.Descripcion,
       SUM(M.Debe) as Debe, SUM(M.Haber) as Haber, C1.Clasificacion
FROM Cuentas C
INNER JOIN MovComprobante M ON C.idCuenta = M.IdCuenta
INNER JOIN Comprobante CO ON M.IdComp = CO.IdComp
INNER JOIN Cuentas C1 ON C.idPadre = C1.idCuenta  -- C1 es padre
WHERE C1.Nivel = 3  -- Queremos padres de nivel 3
  AND CO.Fecha BETWEEN 20250101 AND 20251231
  AND CO.Estado IN (1,2)
  AND C1.Clasificacion IN (1,2)
GROUP BY C1.idCuenta, C1.Codigo, C1.Nivel, C1.Descripcion, C1.Clasificacion

UNION

-- Query 4: Abuelos de nivel 3 (suma de nietos nivel 5)
SELECT 4 as IdQ, C2.idCuenta, C2.Codigo, C2.Nivel, C2.Descripcion,
       SUM(M.Debe) as Debe, SUM(M.Haber) as Haber, C2.Clasificacion
FROM Cuentas C
INNER JOIN MovComprobante M ON C.idCuenta = M.IdCuenta
INNER JOIN Comprobante CO ON M.IdComp = CO.IdComp
INNER JOIN Cuentas C1 ON C.idPadre = C1.idCuenta
INNER JOIN Cuentas C2 ON C1.idPadre = C2.idCuenta  -- C2 es abuelo
WHERE C2.Nivel = 3
  AND CO.Fecha BETWEEN 20250101 AND 20251231
  AND CO.Estado IN (1,2)
  AND C2.Clasificacion IN (1,2)
GROUP BY C2.idCuenta, C2.Codigo, C2.Nivel, C2.Descripcion, C2.Clasificacion

ORDER BY Codigo
```

### Lógica Clave: ¿Por qué 6 Queries?

Un plan de cuentas puede tener hasta 6 niveles:

```
Nivel 1: 1         (ACTIVO)
Nivel 2: 1.1       (ACTIVO CIRCULANTE)
Nivel 3: 1.1.01    (CAJA)
Nivel 4: 1.1.01.001 (CAJA PESOS)
Nivel 5: 1.1.01.001.01 (CAJA SUCURSAL 1)
Nivel 6: 1.1.01.001.01.001 (CAJA SUCURSAL 1 - EFECTIVO)
```

Si solicito Nivel 3, necesito:
- Cuentas nivel 3 con movimientos directos (Query 2)
- Suma de cuentas nivel 4 cuyo padre es nivel 3 (Query 3)
- Suma de cuentas nivel 5 cuyo abuelo es nivel 3 (Query 4)
- Suma de cuentas nivel 6 cuyo bisabuelo es nivel 3 (Query 5)

**Ejemplo:**  
Si "1.1.01.001.01.001" (nivel 6) tiene movimientos, esos movimientos deben sumarse a:
- Su padre "1.1.01.001.01" (nivel 5)
- Su abuelo "1.1.01.001" (nivel 4)
- Su bisabuelo "1.1.01" (nivel 3) ← ESTE ES EL QUE MOSTRAMOS

---

## 🎯 CONSTANTES DE CLASIFICACIÓN

```vb6
' Clasificación de Cuentas (Tabla Cuentas campo Clasificacion)
CLASCTA_ACTIVO = 1      ' Activos (Debe > Haber = saldo positivo)
CLASCTA_PASIVO = 2      ' Pasivos (Haber > Debe = saldo positivo)
CLASCTA_RESULTADO = 3   ' Resultado (Ingresos/Gastos)
CLASCTA_ORDEN = 4       ' Cuentas de Orden (memorándum)
```

### Lógica de Cálculo de Saldo

```vb6
If ClasifPadre = CLASCTA_ACTIVO Then
  Saldo = Debe - Haber  ' Activo aumenta con débito
ElseIf ClasifPadre = CLASCTA_PASIVO Or ClasifPadre = CLASCTA_RESULTADO Then
  Saldo = Haber - Debe  ' Pasivo/Resultado aumenta con crédito
End If
```

---

## 📋 TIPO DE DATOS RepNiv_t

```vb6
Type RepNiv_t
  Debe As Double
  Haber As Double
  Linea As Integer  ' Línea en el Grid
End Type
```

---

**CONTINÚA EN:** `Analysis-Part4-EFCoreMapping.md`

_(Siguiente parte mapeará GenQueryPorNiveles a EF Core LINQ)_
