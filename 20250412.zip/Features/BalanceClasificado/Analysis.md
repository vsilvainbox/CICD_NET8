# BalanceClasificado - Análisis Exhaustivo VB6

**Fecha Análisis:** 11 de Octubre de 2025  
**Formulario VB6:** `FrmBalClasif.frm` (1,840 líneas)  
**Analista:** Claude AI Code Agent  
**Estado:** ✅ ANÁLISIS COMPLETO

---

## 📋 ÍNDICE DE DOCUMENTACIÓN

Este análisis está dividido en 3 archivos por tamaño:

1. **[Analysis-Part1-Structure.md](./Analysis-Part1-Structure.md)** (430+ líneas)
   - Resumen ejecutivo
   - Variables globales y constantes
   - MSFlexGrid y columnas
   - Controles de filtros (ComboBoxes, TextBoxes, Buttons)
   - CheckBoxes de opciones
   - Botones del toolbar
   - Funciones públicas de entrada (FViewBalClasif, etc.)
   - Form_Load inicialización

2. **[Analysis-Part2-EventHandlers.md](./Analysis-Part2-EventHandlers.md)** (525+ líneas)
   - Bt_Buscar_Click() - Generación del reporte con validaciones
   - Bt_Print_Click() - Impresión con registro de libro oficial
   - Bt_Preview_Click() - Vista previa
   - Bt_VerLibMayor_Click() - Navegación a detalle
   - Grid_DblClick() - Acción doble click
   - Eventos de TextBoxes - Validación de fechas
   - Validaciones completas (fechas, estado previo, libro oficial)
   - Funciones auxiliares (SetUpGrid, EnableFrm, ReadResEje, SetupPriv)

3. **[Analysis-Part3-LoadAll.md](./Analysis-Part3-LoadAll.md)** (442+ líneas)
   - Procedimiento LoadAll completo (634 líneas VB6)
   - Construcción de WHERE clause con filtros
   - Loop principal de procesamiento de recordset
   - Agregado de líneas TOTAL por clasificación
   - AddResEjercicio() - Inserción de resultado del ejercicio
   - GenQueryPorNiveles() - Query SQL jerárquica (UNION de 6 queries)
   - Lógica de saldos por clasificación
   - Tipo de datos RepNiv_t

---

## 🎯 RESUMEN EJECUTIVO

### Funcionalidad Principal

**Balance General Clasificado** - Reporte financiero que muestra cuentas agrupadas por:
- **Clasificación**: ACTIVO, PASIVO, RESULTADO, ORDEN
- **Jerarquía**: Niveles 2-5 de plan de cuentas
- **Período**: Rango de fechas flexible
- **Filtros**: Tipo de ajuste, área de negocio, centro de costo
- **Modalidad**: Libro Oficial (APROBADOS) vs Provisorio (APROBADOS + PENDIENTES)

### Tipos de Reportes

| Función VB6 | Tipo Reporte | lBalClasif | lMensual | lComparativo | lClasCta |
|-------------|-------------|------------|----------|--------------|----------|
| `FViewBalClasif` | Balance General Clasificado | TRUE | FALSE | FALSE | "1,2" |
| `FViewEstResultClasif` | Estado Resultados Clasificado | FALSE | FALSE | FALSE | "3" |
| `FViewEstResultMensual` | Estado Resultados Mensual | FALSE | TRUE | FALSE | "3" |
| `FViewEstResultComparativo` | Estado Resultados Comparativo | FALSE | TRUE | TRUE | "3" |

---

## 🗂️ ESTRUCTURA DE DATOS

### Entidades SQLite Relacionadas

```csharp
// app/Data/Cuentas.cs
public class Cuentas
{
    public int IdCuenta { get; set; }
    public int IdEmpresa { get; set; }
    public int Ano { get; set; }
    public string Codigo { get; set; }
    public string Descripcion { get; set; }
    public int Nivel { get; set; }
    public int? IdPadre { get; set; }  // Jerarquía
    public int? Clasificacion { get; set; }  // 1=ACTIVO, 2=PASIVO, 3=RESULTADO, 4=ORDEN
    // ...
}

// app/Data/MovComprobante.cs
public class MovComprobante
{
    public long IdMov { get; set; }
    public long IdComp { get; set; }
    public int IdCuenta { get; set; }
    public double Debe { get; set; }
    public double Haber { get; set; }
    public int? idAreaNeg { get; set; }  // ⚠️ Nota: camelCase legacy
    public int? idCCosto { get; set; }   // ⚠️ Nota: camelCase legacy
    // ...
}

// app/Data/Comprobante.cs
public class Comprobante
{
    public long IdComp { get; set; }
    public int IdEmpresa { get; set; }
    public int Ano { get; set; }
    public int Fecha { get; set; }  // Formato: yyyyMMdd
    public int? Estado { get; set; }  // 1=APROBADO, 2=PENDIENTE, 3=ANULADO
    public int? TipoAjuste { get; set; }  // 1=FINANCIERO, 2=TRIBUTARIO, 3=AMBOS
    // ...
}

// app/Data/LogImpresion.cs (para registro de libro oficial)
public class LogImpresion
{
    public int IdLog { get; set; }
    public int IdLibro { get; set; }  // 8 = LIBOF_BALANCEGRAL
    public int IdEmpresa { get; set; }
    public int Ano { get; set; }
    public int? Mes { get; set; }
    public int FechaDesde { get; set; }
    public int FechaHasta { get; set; }
    public int Fecha { get; set; }  // Fecha de impresión
    public string Usuario { get; set; }
    public int? NumPagIni { get; set; }
    public int? NumPagFin { get; set; }
}
```

---

## 🔍 QUERY PRINCIPAL: GenQueryPorNiveles

### Propósito

Genera query SQL que suma movimientos contables agrupados por niveles jerárquicos del plan de cuentas. Usa UNION de hasta 6 queries para propagar sumas desde cuentas hijas hacia cuentas padres.

### Parámetros

```vb6
Function GenQueryPorNiveles(
  Nivel As Integer,           ' 2-5 (nivel de detalle)
  Where As String,            ' "Fecha BETWEEN x AND y AND ..."
  LibOficial As Boolean,      ' TRUE = solo EC_APROBADO
  Optional ClasCta As String, ' "1,2" o "3" (filtro clasificación)
  Optional Mensual As Boolean ' TRUE = agregar columna Mes
) As String
```

### Estructura UNION

```sql
-- Query 1: Cuentas sin movimientos (Debe=0, Haber=0)
SELECT 1 as IdQ, idCuenta, Codigo, Nivel, Descripcion, 
       0 as Debe, 0 as Haber, Clasificacion
FROM Cuentas
WHERE Nivel <= [Nivel] AND Clasificacion IN ([ClasCta])

UNION

-- Query 2: Movimientos directos de cuentas nivel X
SELECT 2 as IdQ, C.idCuenta, C.Codigo, C.Nivel, C.Descripcion,
       SUM(M.Debe), SUM(M.Haber), C.Clasificacion
FROM Cuentas C
JOIN MovComprobante M ON C.idCuenta = M.IdCuenta
JOIN Comprobante CO ON M.IdComp = CO.IdComp
WHERE C.Nivel <= [Nivel] AND [Where] AND CO.Estado IN (...)
GROUP BY C.idCuenta, C.Codigo, C.Nivel, C.Descripcion, C.Clasificacion

UNION

-- Query 3: Suma de hijos (padre es nivel X)
SELECT 3 as IdQ, C1.idCuenta, C1.Codigo, C1.Nivel, C1.Descripcion,
       SUM(M.Debe), SUM(M.Haber), C1.Clasificacion
FROM Cuentas C
JOIN MovComprobante M ON C.idCuenta = M.IdCuenta
JOIN Comprobante CO ON M.IdComp = CO.IdComp
JOIN Cuentas C1 ON C.idPadre = C1.idCuenta  -- C1 = padre
WHERE C1.Nivel = [Nivel] AND [Where]
GROUP BY C1.idCuenta, ...

-- Queries 4-6: Similar para abuelo, bisabuelo, tatarabuelo

ORDER BY Codigo
```

### Mapeo EF Core (Simplificado)

```csharp
// BalanceClasificadoService.GenerarQueryPorNivelesAsync()
private async Task<List<FilaBalance>> GenerarQueryPorNivelesAsync(
    int nivel, string whereClause, int empresaId, int ano)
{
    // Query 1: Cuentas base
    var cuentasBase = await _context.Cuentas
        .Where(c => c.IdEmpresa == empresaId && c.Ano == ano && c.Nivel <= nivel)
        .Select(c => new FilaBalance
        {
            IdCuenta = c.IdCuenta,
            Codigo = c.Codigo,
            Descripcion = c.Descripcion,
            Nivel = c.Nivel,
            Clasificacion = c.Clasificacion ?? 0,
            Debe = 0,
            Haber = 0
        })
        .ToListAsync();
    
    // Query 2: Movimientos directos
    var movDirectos = await (
        from c in _context.Cuentas
        join m in _context.MovComprobante on c.IdCuenta equals m.IdCuenta
        join co in _context.Comprobante on m.IdComp equals co.IdComp
        where c.IdEmpresa == empresaId && c.Ano == ano && c.Nivel <= nivel
              // Aplicar whereClause dinámico
        group m by new { c.IdCuenta, c.Codigo, c.Descripcion, c.Nivel, c.Clasificacion } into g
        select new FilaBalance
        {
            IdCuenta = g.Key.IdCuenta,
            Codigo = g.Key.Codigo,
            Descripcion = g.Key.Descripcion,
            Nivel = g.Key.Nivel,
            Clasificacion = g.Key.Clasificacion ?? 0,
            Debe = g.Sum(x => x.Debe),
            Haber = g.Sum(x => x.Haber)
        }
    ).ToListAsync();
    
    // Query 3-6: Joins jerárquicos (padre, abuelo, etc.)
    // ... (implementación similar con múltiples joins)
    
    // Combinar y agrupar resultados
    var resultado = cuentasBase
        .Union(movDirectos)
        .Union(movPadres)
        // ...
        .GroupBy(f => new { f.IdCuenta, f.Codigo, f.Descripcion, f.Nivel, f.Clasificacion })
        .Select(g => new FilaBalance
        {
            IdCuenta = g.Key.IdCuenta,
            Codigo = g.Key.Codigo,
            Descripcion = g.Key.Descripcion,
            Nivel = g.Key.Nivel,
            Clasificacion = g.Key.Clasificacion,
            Debe = g.Sum(x => x.Debe),
            Haber = g.Sum(x => x.Haber)
        })
        .OrderBy(f => f.Codigo)
        .ToList();
    
    return resultado;
}
```

---

## ⚖️ LÓGICA DE SALDOS

### Cálculo Según Clasificación

```csharp
public double CalcularSaldo(FilaBalance fila)
{
    if (fila.Clasificacion == CLASCTA_ACTIVO)
    {
        // Activo: Débitos aumentan, Créditos disminuyen
        return fila.Debe - fila.Haber;
    }
    else if (fila.Clasificacion == CLASCTA_PASIVO || 
             fila.Clasificacion == CLASCTA_RESULTADO)
    {
        // Pasivo/Resultado: Créditos aumentan, Débitos disminuyen
        return fila.Haber - fila.Debe;
    }
    else // CLASCTA_ORDEN
    {
        return 0;
    }
}
```

### Resultado del Ejercicio (Balance Clasificado)

```csharp
// Solo aplica si lBalClasif = TRUE y ClasifPadre = PASIVO
// Se inserta después de listar cuentas PASIVO y antes de TOTAL PATRIMONIO

double resEjercicio = TotalPasivo - TotalActivo;

var filaResEjercicio = new FilaBalance
{
    IdCuenta = 0,
    Codigo = "",
    Descripcion = "Resultado del Ejercicio",
    Nivel = 1,
    Clasificacion = CLASCTA_PASIVO,
    Debe = 0,
    Haber = 0,
    Saldo = resEjercicio
};

// Actualizar total Pasivo
TotalPasivo += resEjercicio;
```

---

## ✅ VALIDACIONES CRÍTICAS

### 1. Validación de Fechas (Bt_Buscar_Click)

```csharp
// Fecha inicio <= Fecha término
if (request.FechaDesde > request.FechaHasta)
    return ValidationResult.Error("Fecha de inicio es posterior a la fecha de término del reporte.");

// Ambas fechas deben pertenecer al año actual
if (request.FechaDesde.Year != request.Ano)
    return ValidationResult.Error("La fecha de inicio no corresponde al periodo actual.");

if (request.FechaHasta.Year != request.Ano)
    return ValidationResult.Error("La fecha de término no corresponde al periodo actual.");
```

### 2. Validación Estado Previo (Exports/Print)

```csharp
// UI debe deshabilitar botones hasta que se ejecute GenerarBalanceAsync()
<button id="btnExportExcel" disabled>Copiar a Excel</button>
<button id="btnPrint" disabled>Imprimir</button>
<button id="btnPreview" disabled>Vista Previa</button>

// Se habilitan después de cargar datos:
document.getElementById('btnExportExcel').disabled = false;
```

### 3. Validación Libro Oficial (Bt_Print_Click)

```csharp
if (request.LibroOficial)
{
    var logPrevio = await _context.LogImpresion
        .Where(l => l.IdLibro == LIBOF_BALANCEGRAL &&
                    l.IdEmpresa == request.IdEmpresa &&
                    l.Ano == request.Ano)
        .OrderByDescending(l => l.Fecha)
        .FirstOrDefaultAsync();
    
    if (logPrevio != null)
    {
        return new PrintValidationResult
        {
            RequiresConfirmation = true,
            Message = $"El Balance General Oficial ya ha sido impreso en papel foliado " +
                      $"el día {IntToDate(logPrevio.Fecha):dd/MM/yyyy} " +
                      $"por el usuario {logPrevio.Usuario}, para el período comprendido " +
                      $"entre el {IntToDate(logPrevio.FechaDesde):dd/MM/yyyy} y el " +
                      $"{IntToDate(logPrevio.FechaHasta):dd/MM/yyyy}. ¿Desea continuar?"
        };
    }
}
```

### 4. Advertencia Reporte Mensual

```csharp
if (request.Mensual && !request.Comparativo)
{
    // Mostrar warning en UI
    return new PrintValidationResult
    {
        IsWarning = true,
        Message = "Es muy probable que al imprimir este informe no quepan todas las columnas. " +
                  "Se sugiere copiarlo a Excel e imprimirlo desde ahí."
    };
}
```

---

## 📊 INTERFACE DEL SERVICE .NET

### IBalanceClasificadoService

```csharp
public interface IBalanceClasificadoService
{
    // Generar balance con filtros
    Task<BalanceClasificadoResponse> GenerarBalanceAsync(BalanceClasificadoRequest request);
    
    // Obtener opciones para filtros (dropdowns)
    Task<BalanceClasificadoOpciones> GetOpcionesFiltrosAsync(int empresaId, int ano);
    
    // Exportar a Excel
    Task<byte[]> ExportarExcelAsync(BalanceClasificadoDto balance);
    
    // Exportar a PDF
    Task<byte[]> ExportarPdfAsync(BalanceClasificadoDto balance, bool papelFoliado = false);
    
    // Verificar si libro oficial ya fue impreso
    Task<LogImpresionDto?> VerificarImpresionPreviaAsync(int empresaId, int ano, int idLibro);
    
    // Registrar impresión oficial
    Task RegistrarImpresionOficialAsync(LogImpresionDto log);
}
```

### DTOs

```csharp
public class BalanceClasificadoRequest
{
    public int IdEmpresa { get; set; }
    public int Ano { get; set; }
    public DateTime FechaDesde { get; set; }  // En .NET Date, en DB int yyyyMMdd
    public DateTime FechaHasta { get; set; }
    public int NivelDetalle { get; set; }  // 2-5
    public int? TipoAjuste { get; set; }  // 1=FIN, 2=TRIB, null=AMBOS
    public int? IdAreaNegocio { get; set; }
    public int? IdCentroCosto { get; set; }
    public bool LibroOficial { get; set; }  // true = solo EC_APROBADO
    public bool Mensual { get; set; }  // Columnas por mes
    public bool Comparativo { get; set; }
    public string TipoReporte { get; set; }  // "Balance", "EstadoResultados"
}

public class BalanceClasificadoDto
{
    public int IdEmpresa { get; set; }
    public int Ano { get; set; }
    public DateTime FechaCorte { get; set; }
    public List<FilaBalance> Filas { get; set; }
    public double TotalActivo { get; set; }
    public double TotalPasivo { get; set; }
    public double TotalPatrimonio { get; set; }
    public double ResultadoEjercicio => TotalPasivo - TotalActivo;
}

public class FilaBalance
{
    public int IdCuenta { get; set; }
    public string Codigo { get; set; }
    public string Descripcion { get; set; }
    public int Nivel { get; set; }
    public int Clasificacion { get; set; }  // 1=ACT, 2=PAS, 3=RES, 4=ORD
    public double Debe { get; set; }
    public double Haber { get; set; }
    public double Saldo { get; set; }
    public bool EsTotal { get; set; }  // IdCuenta = -1 indica fila TOTAL
    public string Formato { get; set; }  // "B", "BU", "I"
    
    // Para reporte mensual
    public Dictionary<int, double>? SaldosPorMes { get; set; }  // Mes (1-12) => Saldo
}
```

---

## 🔗 NAVEGACIÓN

### FrmBalClasif → FrmLibMayor

```vb6
' VB6: Bt_VerLibMayor_Click() / Grid_DblClick()
lIdCuenta = Val(Grid.TextMatrix(Grid.Row, C_IDCUENTA))
Set Frm = New FrmLibMayor
Call Frm.FView(lIdCuenta, FDesde, FHasta)
```

```csharp
// .NET MVC Controller
public IActionResult VerLibroMayor(int idCuenta, DateTime fechaDesde, DateTime fechaHasta)
{
    return RedirectToAction("Index", "LibroMayor", new 
    { 
        idCuenta, 
        desde = fechaDesde.ToString("yyyy-MM-dd"),
        hasta = fechaHasta.ToString("yyyy-MM-dd")
    });
}
```

---

## 📦 EXPORTACIONES

### Excel (LP_FGr2Clip_Membr)

**VB6:** Copia grid al portapapeles para pegar en Excel  
**Implementación .NET:** EPPlus para generar archivo .xlsx

```csharp
public async Task<byte[]> ExportarExcelAsync(BalanceClasificadoDto balance)
{
    using var package = new ExcelPackage();
    var worksheet = package.Workbook.Worksheets.Add("Balance Clasificado");
    
    // Header empresa
    worksheet.Cells[1, 1].Value = balance.NombreEmpresa;
    worksheet.Cells[2, 1].Value = $"Balance General Clasificado al {balance.FechaCorte:dd/MM/yyyy}";
    
    // Columnas
    int row = 4;
    worksheet.Cells[row, 1].Value = "Código";
    worksheet.Cells[row, 2].Value = "Cuenta";
    worksheet.Cells[row, 3].Value = "Débitos";
    worksheet.Cells[row, 4].Value = "Créditos";
    worksheet.Cells[row, 5].Value = "Saldo";
    
    // Datos
    row = 5;
    foreach (var fila in balance.Filas)
    {
        worksheet.Cells[row, 1].Value = fila.Codigo;
        worksheet.Cells[row, 2].Value = fila.Descripcion;
        worksheet.Cells[row, 3].Value = fila.Debe;
        worksheet.Cells[row, 4].Value = fila.Haber;
        worksheet.Cells[row, 5].Value = fila.Saldo;
        
        // Formato
        if (fila.Formato?.Contains("B") == true)
            worksheet.Cells[row, 1, row, 5].Style.Font.Bold = true;
        
        row++;
    }
    
    // Formato números
    worksheet.Cells[5, 3, row - 1, 5].Style.Numberformat.Format = "#,##0;-#,##0";
    
    return package.GetAsByteArray();
}
```

### PDF (gPrtLibros.PrtFlexGrid + PrtPieBalanceFirma)

**VB6:** Impresión a Printer object o FrmPrintPreview  
**Implementación .NET:** QuestPDF para generar PDF

```csharp
public async Task<byte[]> ExportarPdfAsync(BalanceClasificadoDto balance, bool papelFoliado)
{
    var document = Document.Create(container =>
    {
        container.Page(page =>
        {
            page.Size(PageSizes.Letter);
            page.Margin(2, Unit.Centimetre);
            
            page.Header().Element(header =>
            {
                header.Column(column =>
                {
                    column.Item().Text(balance.NombreEmpresa).FontSize(14).Bold();
                    column.Item().Text($"Balance General Clasificado al {balance.FechaCorte:dd/MM/yyyy}");
                });
            });
            
            page.Content().Element(content =>
            {
                content.Table(table =>
                {
                    table.ColumnsDefinition(columns =>
                    {
                        columns.RelativeColumn(2);  // Código
                        columns.RelativeColumn(5);  // Cuenta
                        columns.RelativeColumn(2);  // Débitos
                        columns.RelativeColumn(2);  // Créditos
                        columns.RelativeColumn(2);  // Saldo
                    });
                    
                    // Header
                    table.Header(header =>
                    {
                        header.Cell().Text("Código");
                        header.Cell().Text("Cuenta");
                        header.Cell().AlignRight().Text("Débitos");
                        header.Cell().AlignRight().Text("Créditos");
                        header.Cell().AlignRight().Text("Saldo");
                    });
                    
                    // Datos
                    foreach (var fila in balance.Filas)
                    {
                        table.Cell().Text(fila.Codigo);
                        table.Cell().Text(fila.Descripcion);
                        table.Cell().AlignRight().Text($"{fila.Debe:#,##0;-#,##0}");
                        table.Cell().AlignRight().Text($"{fila.Haber:#,##0;-#,##0}");
                        table.Cell().AlignRight().Text($"{fila.Saldo:#,##0;-#,##0}");
                    }
                });
            });
            
            page.Footer().Element(footer =>
            {
                if (papelFoliado)
                {
                    footer.Text($"Folio N° {balance.NumFolio}").AlignRight();
                }
                footer.Text("___________________    ___________________").AlignCenter();
                footer.Text("Gerente                           Contador").AlignCenter();
            });
        });
    });
    
    return document.GeneratePdf();
}
```

---

## ✅ CHECKLIST DE IMPLEMENTACIÓN .NET

### Estructura y Configuración
- [x] Variables globales mapeadas a propiedades DTO
- [x] Constantes de clasificación definidas en Service
- [x] Constantes de estado y tipo ajuste definidas

### UI y Controles
- [ ] Vista Index.cshtml con Tailwind CSS
- [ ] Filtros: Fecha Desde/Hasta (datepickers)
- [ ] ComboBox: Nivel (2-5)
- [ ] ComboBox: Tipo Ajuste (Financiero/Tributario)
- [ ] ComboBox: Área de Negocio (con "TODAS")
- [ ] ComboBox: Centro de Costo (con "TODOS")
- [ ] Checkbox: Libro Oficial
- [ ] Checkbox: Ver Código Cuenta
- [ ] Checkbox: Ver Subtotales (solo Estado Resultados)
- [ ] Botón: Listar (POST a GenerarBalanceAsync)
- [ ] Botón: Copiar Excel (deshabilitado hasta listar)
- [ ] Botón: Vista Previa (deshabilitado hasta listar)
- [ ] Botón: Imprimir (deshabilitado hasta listar, validar libro oficial)
- [ ] Grid/Tabla: MSFlexGrid equivalente (columnas ocultas con CSS)
- [ ] Navegación: Doble click → Ver Libro Mayor

### Lógica de Negocio
- [x] GenerarBalanceAsync() implementado
- [x] GenerarQueryPorNivelesAsync() con UNION queries
- [x] Cálculo de saldos según clasificación
- [ ] AddResEjercicio() - Insertar resultado del ejercicio
- [ ] Totales por clasificación (TOTAL ACTIVO, TOTAL PASIVO, etc.)
- [ ] Formato de filas (Bold para niveles 1-2)
- [ ] Columnas mensuales (si Mensual = true)

### Validaciones
- [x] Fecha inicio <= Fecha término
- [x] Fechas pertenecen al año actual
- [ ] UI: Deshabilitar exports hasta listar
- [ ] Verificar impresión previa (QryLogImpreso)
- [ ] Advertencia reporte mensual

### Exportaciones
- [ ] ExportarExcelAsync() con EPPlus
- [ ] ExportarPdfAsync() con QuestPDF
- [ ] Papel foliado (footer con número de folio)
- [ ] Pie con firmas (Gerente, Contador)

### Libro Oficial
- [ ] VerificarImpresionPreviaAsync()
- [ ] RegistrarImpresionOficialAsync()
- [ ] LogImpresion entity y DbSet
- [ ] Validación de confirmación si ya impreso

### Opciones y Combos
- [x] GetOpcionesFiltrosAsync() implementado
- [x] Áreas de Negocio
- [x] Centros de Costo
- [x] Niveles (2-5)
- [x] Tipos de Ajuste

---

## 📝 NOTAS IMPORTANTES

### Diferencias VB6 vs .NET

1. **Fechas**: VB6 usa Long (yyyyMMdd), .NET usa DateTime → Convertir con `DateToInt()` / `IntToDate()`
2. **Propiedades camelCase**: `idAreaNeg`, `idCCosto` en MovComprobante (legacy)
3. **Grid.TextMatrix**: En .NET usar modelo DTO + Razor/JavaScript
4. **MousePointer = vbHourglass**: En .NET usar spinner/loading UI
5. **MsgBox1**: En .NET usar modales JavaScript (SweetAlert2, etc.)
6. **Printer object**: En .NET generar PDF y enviar al browser

### Query Optimization

GenQueryPorNiveles en VB6 genera SQL con UNION de 6 queries. En EF Core:
- Considerar materializar queries parciales con `ToListAsync()` antes de Union
- O usar `FromSqlRaw()` para ejecutar SQL similar al VB6
- Evaluar performance con plan de cuentas grandes (500+ cuentas)

### Testing Requerido

1. Balance con nivel 2, 3, 4, 5
2. Balance con clasificación Activo+Pasivo vs solo Resultado
3. Balance con filtros (Área Negocio, Centro Costo, Tipo Ajuste)
4. Balance Mensual (12 columnas)
5. Libro Oficial vs Provisorio (estados comprobante)
6. Resultado del Ejercicio (solo Balance Clasificado)
7. Navegación a Libro Mayor
8. Exports Excel/PDF
9. Registro impresión oficial
10. Validación fechas y libro oficial

---

**FIN DEL ANÁLISIS**

Total líneas documentadas: ~1,397 líneas de análisis para 1,840 líneas VB6 ≈ 76% coverage