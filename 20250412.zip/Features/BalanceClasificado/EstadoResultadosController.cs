using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.BalanceClasificado;

/// <summary>
/// Controller para Estado de Resultados por Función
/// </summary>
public class EstadoResultadosController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<EstadoResultadosController> logger) : Controller
{
    /// <summary>
    /// Vista principal del estado de resultados
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder al Estado de Resultados";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        {
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<BalanceClasificadoApiController>(
                HttpContext,
                nameof(BalanceClasificadoApiController.GetOpcionesFiltros),
                new { empresaId = SessionHelper.EmpresaId, ano = SessionHelper.Ano });
            var opcionesFiltros = await client.GetFromApiAsync<BalanceClasificadoOpciones>(url!);

            var viewModel = new EstadoResultadosIndexViewModel
            {
                EmpresaId = SessionHelper.EmpresaId,
                Ano = SessionHelper.Ano,
                FechaDesde = new DateTime(SessionHelper.Ano, 1, 1).ToString("yyyy-MM-dd"),
                FechaHasta = DateTime.Now.ToString("yyyy-MM-dd"),
                OpcionesFiltros = opcionesFiltros ?? new BalanceClasificadoOpciones()
            };

            logger.LogInformation("Index: Opciones de filtros cargadas exitosamente para empresaId={EmpresaId}, ano={Ano}",
                SessionHelper.EmpresaId, SessionHelper.Ano);

            return View("~/Features/BalanceClasificado/Views/EstadoResultados/Index.cshtml", viewModel);
        }
    }

    /// <summary>
    /// Proxy: Genera el estado de resultados (POST a Index)
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Index([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: Generar estado de resultados via Index POST");

        {
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<EstadoResultadosApiController>(
                HttpContext,
                nameof(EstadoResultadosApiController.Generar));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// Obtiene las funciones disponibles para clasificación
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ObtenerFunciones()
    {
        {
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<EstadoResultadosApiController>(
                HttpContext,
                nameof(EstadoResultadosApiController.ObtenerFunciones));
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Proxy: Genera el estado de resultados (POST)
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Generar([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: Generar estado de resultados");

        {
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<EstadoResultadosApiController>(
                HttpContext,
                nameof(EstadoResultadosApiController.Generar));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// Proxy: Exporta el estado de resultados (POST)
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Exportar([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: Exportar estado de resultados");

        {
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<EstadoResultadosApiController>(
                HttpContext,
                nameof(EstadoResultadosApiController.Exportar));
            var (fileBytes, contentType) = await client.DownloadFileAsync(
                url,
                HttpMethod.Post,
                request);

            var fileName = "EstadoResultados.xlsx";
            return File(fileBytes, contentType, fileName);
        }
    }

    /// <summary>
    /// Proxy: Obtiene análisis del estado de resultados (POST)
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Analisis([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: Obtener análisis estado de resultados");

        {
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<EstadoResultadosApiController>(
                HttpContext,
                nameof(EstadoResultadosApiController.ObtenerAnalisis));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// Proxy: Obtiene gráficos del estado de resultados (POST)
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Graficos([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: Obtener gráficos estado de resultados");

        {
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<EstadoResultadosApiController>(
                HttpContext,
                nameof(EstadoResultadosApiController.ObtenerGraficos));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }
}