using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Extensions;
using App.Helpers;

namespace App.Features.BalanceClasificado;

/// <summary>
/// MVC Controller para Balance Clasificado
/// </summary>
public class BalanceClasificadoController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<BalanceClasificadoController> logger) : Controller
{
    /// <summary>
    /// Vista principal del balance clasificado
    /// </summary>
    public async Task<IActionResult> Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder al Balance Clasificado";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        var empresaId = SessionHelper.EmpresaId;
        var ano = (short)SessionHelper.Ano;

        // Cargar opciones de filtros
        var httpClient = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<BalanceClasificadoApiController>(
            HttpContext,
            nameof(BalanceClasificadoApiController.GetOpcionesFiltros),
            new { empresaId, ano });
        var opcionesResponse = await httpClient.GetFromApiAsync<BalanceClasificadoOpciones>(url!);

        // Crear ViewModel tipado en lugar de ViewBag
        var viewModel = new BalanceClasificadoIndexViewModel
        {
            OpcionesFiltros = opcionesResponse ?? new BalanceClasificadoOpciones(),
            Filtros = new BalanceClasificadoRequest
            {
                IdEmpresa = empresaId,
                Ano = ano,
                FechaDesde = new DateTime(ano, 1, 1),
                FechaCorte = new DateTime(ano, 12, 31),
                NivelDetalle = 5,
                LibroOficial = false,
                VerSubTotales = true,
                VerCodigoCuenta = false
            }
        };

        return View(viewModel);
    }

    /// <summary>
    /// Vista de exportación
    /// </summary>
    public IActionResult Exportar()
    {
        return View();
    }

    /// <summary>
    /// Vista de estad�sticas
    /// </summary>
    public IActionResult Estadisticas()
    {
        return View();
    }

    #region API Proxy Methods

    /// <summary>
    /// Proxy: Genera el balance clasificado
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Generar([FromBody] JsonElement request)
    {
        {
            logger.LogInformation("Proxy: Generar balance clasificado");
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<BalanceClasificadoApiController>(
                HttpContext,
                nameof(BalanceClasificadoApiController.GenerarBalance));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// Proxy: Obtiene vista previa del balance
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> VistaPrevia([FromBody] JsonElement request)
    {
        {
            logger.LogInformation("Proxy: Vista previa balance clasificado");
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<BalanceClasificadoApiController>(
                HttpContext,
                nameof(BalanceClasificadoApiController.GetVistaPrevia));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// Proxy: Exporta el balance a Excel
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> ExportarBalance([FromBody] JsonElement request)
    {
        {
            logger.LogInformation("Proxy: Exportar balance clasificado");
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<BalanceClasificadoApiController>(
                HttpContext,
                nameof(BalanceClasificadoApiController.ExportarBalance));
            var (fileBytes, contentType) = await client.DownloadFileAsync(
                url,
                HttpMethod.Post,
                request);
            return File(fileBytes, contentType);
        }
    }

    /// <summary>
    /// Proxy: Calcula suma de movimientos seleccionados
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> SumaMovimientos([FromBody] JsonElement request)
    {
        {
            logger.LogInformation("Proxy: Suma movimientos");
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<BalanceClasificadoApiController>(
                HttpContext,
                nameof(BalanceClasificadoApiController.CalcularSumaMovimientos));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// Proxy: Obtiene estadísticas del balance
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> ObtenerEstadisticas([FromBody] JsonElement request)
    {
        {
            logger.LogInformation("Proxy: Obtener estadísticas balance");
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<BalanceClasificadoApiController>(
                HttpContext,
                nameof(BalanceClasificadoApiController.GetEstadisticas));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    #endregion

    #region Partial View Endpoints - ASP.NET Core MVC Way

    /// <summary>
    /// Endpoint que retorna HTML renderizado para la tabla del balance
    /// Patrón: Server-Side Rendering con AJAX parcial
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> GenerarBalancePartial([FromBody] BalanceClasificadoRequest request)
    {
        try
        {
            logger.LogInformation("Generando balance clasificado (partial view)");

            // Llamar al API
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<BalanceClasificadoApiController>(
                HttpContext,
                nameof(BalanceClasificadoApiController.GenerarBalance));

            var response = await client.PostAsJsonAsync(url, request);

            if (!response.IsSuccessStatusCode)
            {
                return StatusCode((int)response.StatusCode, await response.Content.ReadAsStringAsync());
            }

            var result = await response.Content.ReadFromJsonAsync<BalanceClasificadoDto>();

            if (result == null)
            {
                return BadRequest(new { success = false, message = "Error generando balance" });
            }

            // Convertir DTO a ViewModel
            var viewModel = ConvertirAViewModel(result, request);

            // Retornar partial view con HTML renderizado
            return PartialView("_BalanceResultados", viewModel);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error generando balance clasificado");
            return StatusCode(500, new { success = false, message = "Error interno del servidor" });
        }
    }

    /// <summary>
    /// Endpoint para paginación - retorna solo la tabla con la página solicitada
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> CambiarPagina(int page = 1, int pageSize = 50)
    {
        try
        {
            // En un escenario real, los datos del balance estarían en Session o Cache
            // Por simplicidad, retornamos un modelo vacío
            // TODO: Implementar caché de resultados del balance

            var viewModel = new BalanceClasificadoViewModel
            {
                CurrentPage = page,
                PageSize = pageSize
            };

            return PartialView("_BalanceTabla", viewModel);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error cambiando página");
            return StatusCode(500, new { success = false, message = "Error interno del servidor" });
        }
    }

    /// <summary>
    /// Endpoint para calcular suma de movimientos - retorna HTML renderizado
    /// Patrón: Server-Side Rendering - Cálculos en el servidor, no en JavaScript
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> SumaMovimientosPartial([FromBody] SumaMovimientosRequest request)
    {
        try
        {
            logger.LogInformation("Calculando suma de movimientos (partial view)");

            // Llamar al API para obtener los datos
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<BalanceClasificadoApiController>(
                HttpContext,
                nameof(BalanceClasificadoApiController.CalcularSumaMovimientos));

            var response = await client.PostAsJsonAsync(url, request);

            if (!response.IsSuccessStatusCode)
            {
                return StatusCode((int)response.StatusCode, "<p class='text-red-600'>Error calculando suma</p>");
            }

            var apiResponse = await response.Content.ReadFromJsonAsync<SumaMovimientosResponse>();

            if (apiResponse == null)
            {
                return BadRequest("<p class='text-red-600'>Error calculando suma</p>");
            }

            // Convertir a ViewModel con propiedades calculadas y formateadas
            var viewModel = new SumaMovimientosViewModel
            {
                Codigos = request.Codigos ?? new List<string>(),
                Total = apiResponse.Total,
                MostrarDetalle = false
            };

            // Retornar partial view con HTML renderizado
            return PartialView("_SumaMovimientos", viewModel);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error calculando suma de movimientos");
            return StatusCode(500, "<p class='text-red-600'>Error interno del servidor</p>");
        }
    }

    /// <summary>
    /// Endpoint para obtener estadísticas - retorna HTML renderizado
    /// Patrón: Server-Side Rendering - Estadísticas calculadas en el servidor
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> EstadisticasPartial([FromBody] BalanceClasificadoRequest request)
    {
        try
        {
            logger.LogInformation("Obteniendo estadísticas del balance (partial view)");

            // Llamar al API
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<BalanceClasificadoApiController>(
                HttpContext,
                nameof(BalanceClasificadoApiController.GenerarBalance));

            var response = await client.PostAsJsonAsync(url, request);

            if (!response.IsSuccessStatusCode)
            {
                return StatusCode((int)response.StatusCode, "<p class='text-red-600'>Error obteniendo estadísticas</p>");
            }

            var result = await response.Content.ReadFromJsonAsync<BalanceClasificadoDto>();

            if (result == null)
            {
                return BadRequest("<p class='text-red-600'>Error obteniendo estadísticas</p>");
            }

            // Convertir a ViewModel (ya tiene propiedades calculadas de estadísticas)
            var viewModel = ConvertirAViewModel(result, request);

            // Retornar partial view con HTML renderizado
            return PartialView("_Estadisticas", viewModel);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error obteniendo estadísticas");
            return StatusCode(500, "<p class='text-red-600'>Error interno del servidor</p>");
        }
    }

    #endregion

    #region Helper Methods

    /// <summary>
    /// Convierte DTO a ViewModel con propiedades calculadas y formateadas
    /// </summary>
    private BalanceClasificadoViewModel ConvertirAViewModel(BalanceClasificadoDto dto, BalanceClasificadoRequest request)
    {
        var viewModel = new BalanceClasificadoViewModel
        {
            IdEmpresa = dto.IdEmpresa,
            Ano = dto.Ano,
            FechaCorte = dto.FechaCorte,
            FechaDesde = request.FechaDesde,
            NivelDetalle = request.NivelDetalle,
            IdAreaNegocio = request.IdAreaNegocio,
            IdCentroCosto = request.IdCentroCosto,
            TipoAjuste = request.TipoAjuste,
            LibroOficial = request.LibroOficial,
            VerSubTotales = request.VerSubTotales,
            VerCodigoCuenta = request.VerCodigoCuenta,
            TotalActivo = dto.TotalActivo,
            TotalPasivo = dto.TotalPasivo,
            TotalPatrimonio = dto.TotalPatrimonio,
            CurrentPage = 1,
            PageSize = 50
        };

        // Convertir filas DTO a ViewModels
        viewModel.Filas = dto.Filas.Select(f => new BalanceClasificadoFilaViewModel
        {
            Codigo = f.Codigo,
            Descripcion = f.Descripcion,
            Nivel = f.Nivel,
            Clasificacion = f.Clasificacion,
            Saldo = f.Saldo,
            EsTitulo = f.EsTitulo,
            MostrarCodigo = request.VerCodigoCuenta,
            EsLineaTotal = f.EsLineaTotal,
            EsResultadoEjercicio = f.EsResultadoEjercicio,
            EsNegrita = f.EsNegrita
        }).ToList();

        return viewModel;
    }

    #endregion
}