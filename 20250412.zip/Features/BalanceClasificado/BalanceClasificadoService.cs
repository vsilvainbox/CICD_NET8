using Microsoft.EntityFrameworkCore;
using App.Data;
using App.Exceptions;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Drawing;

namespace App.Features.BalanceClasificado;

public class BalanceClasificadoService(LpContabContext context, ILogger<BalanceClasificadoService> logger) : IBalanceClasificadoService
{
    // Constantes de clasificación de cuentas (VB6)
    private const byte CLASCTA_ACTIVO = 1;
    private const byte CLASCTA_PASIVO = 2;
    private const byte CLASCTA_RESULTADO = 3;
    private const byte CLASCTA_ORDEN = 4;

    // Estados de comprobantes (VB6)
    private const byte EC_APROBADO = 1;
    private const byte EC_PENDIENTE = 2;
    private const byte EC_ANULADO = 3;

    // Tipos de ajuste (VB6)
    private const byte TAJUSTE_FINANCIERO = 1;
    private const byte TAJUSTE_TRIBUTARIO = 2;
    private const byte TAJUSTE_AMBOS = 3;

    // ID de libro para auditoría (VB6)
    private const int LIBOF_BALANCEGRAL = 8;

    public async Task<BalanceClasificadoDto> GenerarBalanceAsync(BalanceClasificadoRequest request)
    {
        logger.LogInformation("Generando Balance Clasificado para empresa {EmpresaId}, a�o {Ano}, corte {FechaCorte}",
            request.IdEmpresa, request.Ano, request.FechaCorte);

        var fechaDesde = DateToInt(new DateTime(request.Ano, 1, 1));
        var fechaHasta = DateToInt(request.FechaCorte);

        logger.LogInformation("Filtros fecha: Desde={FechaDesde}, Hasta={FechaHasta}", fechaDesde, fechaHasta);

        // Construir filtros WHERE seg�n criterios VB6
        // NOTA: Las fechas en BD pueden estar en 2 formatos:
        // 1. YYYYMMDD (nuevo): ej. 20240101
        // 2. D�as OLE Automation (VB6 antiguo): ej. 45292
        // Por ahora filtramos solo por a�o del comprobante (validado en JOIN con co.Ano = c.Ano)
        var whereMovimientos = "1=1"; // Filtro base para MovComprobante

        // Filtros de �rea de negocio y centro de costo (aplican a MovComprobante)
        if (request.IdAreaNegocio.HasValue && request.IdAreaNegocio > 0)
        {
            whereMovimientos += $" AND m.IdAreaNeg = {request.IdAreaNegocio}";
        }

        if (request.IdCentroCosto.HasValue && request.IdCentroCosto > 0)
        {
            whereMovimientos += $" AND m.IdCCosto = {request.IdCentroCosto}";
        }

        // Filtro de TipoAjuste y Estado (aplican a Comprobante)
        var whereComprobante = "";

        if (request.TipoAjuste.HasValue && request.TipoAjuste > 0)
        {
            if (request.TipoAjuste == TAJUSTE_FINANCIERO)
            {
                whereComprobante += $" AND (co.TipoAjuste IS NULL OR co.TipoAjuste IN ({TAJUSTE_FINANCIERO}, {TAJUSTE_AMBOS}))";
            }
            else
            {
                whereComprobante += $" AND co.TipoAjuste IN ({TAJUSTE_TRIBUTARIO}, {TAJUSTE_AMBOS})";
            }
        }

        // Agregar filtro de estado seg�n LibroOficial
        if (request.LibroOficial)
        {
            whereComprobante += $" AND co.Estado = {EC_APROBADO}";
            logger.LogInformation("Libro Oficial: solo comprobantes APROBADOS");
        }
        else
        {
            whereComprobante += $" AND co.Estado IN ({EC_APROBADO}, {EC_PENDIENTE})";
        }

        // Combinar ambos filtros para usar en las consultas
        var whereClause = whereMovimientos + whereComprobante;

        // Generar query por niveles (VB6: GenQueryPorNiveles)
        var filas = await GenerarQueryPorNivelesAsync(request.NivelDetalle, whereClause, request.IdEmpresa, request.Ano);

        // Calcular totales por clasificación antes de agregar l�neas especiales
        var totalActivo = filas.Where(f => f.Clasificacion == CLASCTA_ACTIVO && !f.EsLineaTotal).Sum(f => f.Saldo);
        var totalPasivo = filas.Where(f => f.Clasificacion == CLASCTA_PASIVO && !f.EsLineaTotal).Sum(f => f.Saldo);
        var totalResultado = filas.Where(f => f.Clasificacion == CLASCTA_RESULTADO && !f.EsLineaTotal).Sum(f => f.Saldo);

        // Agregar l�neas TOTAL por clasificación (VB6: LinTotClasif)
        var filasConTotales = AgregarLineasTotales(filas, totalActivo, totalPasivo, totalResultado);

        // Agregar l�nea "Resultado del Ejercicio" para Balance Clasificado
        // Solo si no es Estado de Resultados (VB6: lBalClasif = TRUE)
        filasConTotales = AgregarResultadoEjercicio(filasConTotales, totalPasivo, totalActivo);

        var balance = new BalanceClasificadoDto
        {
            IdEmpresa = request.IdEmpresa,
            Ano = request.Ano,
            FechaCorte = request.FechaCorte,
            Filas = filasConTotales,
            TotalActivo = totalActivo,
            TotalPasivo = totalPasivo,
            TotalPatrimonio = totalResultado // En VB6 Resultado = Patrimonio para balance
        };

        logger.LogInformation("Balance generado exitosamente. Filas: {Count}, Total Activo: {TotalActivo}, Total Pasivo: {TotalPasivo}",
            filasConTotales.Count, totalActivo, totalPasivo);

        return balance;
    }

    public async Task<BalanceClasificadoOpciones> GetOpcionesFiltrosAsync(int empresaId, short ano)
    {
        logger.LogInformation("Obteniendo opciones de filtros para empresa {EmpresaId}, a�o {Ano}", empresaId, ano);

        // Obtener �reas de negocio
        var areasNegocio = await context.AreaNegocio
            .Where(a => a.IdEmpresa == empresaId)
            .OrderBy(a => a.Codigo)
            .Select(a => new { a.IdAreaNegocio, a.Codigo, a.Descripcion })
            .ToListAsync();

        // Obtener centros de costo
        var centrosCosto = await context.CentroCosto
            .Where(c => c.IdEmpresa == empresaId)
            .OrderBy(c => c.Codigo)
            .Select(c => new { c.IdCCosto, c.Codigo, c.Descripcion })
            .ToListAsync();

        return new BalanceClasificadoOpciones
        {
            Niveles = Enumerable.Range(2, 4).ToList(), // Niveles 2-5 (VB6 elimina nivel 1)
            Clasificaciones = new List<OpcionSelect>
            {
                new OpcionSelect { Id = CLASCTA_ACTIVO, Nombre = "ACTIVO" },
                new OpcionSelect { Id = CLASCTA_PASIVO, Nombre = "PASIVO" },
                new OpcionSelect { Id = CLASCTA_RESULTADO, Nombre = "RESULTADO" },
                new OpcionSelect { Id = CLASCTA_ORDEN, Nombre = "ORDEN" }
            },
            TiposAjuste = new List<OpcionSelect>
            {
                new OpcionSelect { Id = TAJUSTE_FINANCIERO, Nombre = "FINANCIERO" },
                new OpcionSelect { Id = TAJUSTE_TRIBUTARIO, Nombre = "TRIBUTARIO" }
            },
            AreasNegocio = areasNegocio.Select(a => new OpcionSelect
            {
                Id = a.IdAreaNegocio,
                Codigo = a.Codigo,
                Descripcion = a.Descripcion
            }).ToList(),
            CentrosCosto = centrosCosto.Select(c => new OpcionSelect
            {
                Id = c.IdCCosto,
                Codigo = c.Codigo,
                Descripcion = c.Descripcion
            }).ToList()
        };
    }

    private async Task<List<BalanceClasificadoFila>> GenerarQueryPorNivelesAsync(int nivel, string whereClause, int empresaId, short ano)
    {
        logger.LogInformation("Generando query por niveles. Nivel: {Nivel}, WhereClause: {WhereClause}, EmpresaId: {EmpresaId}, Ano: {Ano}",
            nivel, whereClause, empresaId, ano);

        // Dictionary para acumular saldos por c�digo de cuenta
        var saldosPorCuenta = new Dictionary<string, MovimientoCuenta>();

        // UNION 1: Lista de cuentas de nivel menor o igual (sin movimientos)
        var cuentasSinMov = await context.Cuentas
                .Where(c => c.IdEmpresa == empresaId && c.Ano == ano && c.Nivel <= nivel)
                .ToListAsync();

            logger.LogInformation("SQL1 (Cuentas sin movimientos): {Count} cuentas de nivel <= {Nivel}", cuentasSinMov.Count, nivel);

            foreach (var cuenta in cuentasSinMov)
            {
                var codigo = cuenta.Codigo ?? "";
                if (!saldosPorCuenta.ContainsKey(codigo))
                {
                    saldosPorCuenta[codigo] = new MovimientoCuenta
                    {
                        Codigo = codigo,
                        Descripcion = cuenta.Descripcion ?? "",
                        Nivel = cuenta.Nivel ?? 0,
                        Clasificacion = cuenta.Clasificacion ?? 0,
                        TotalDebe = 0,
                        TotalHaber = 0
                    };
                }
            }

            // UNION 2: Cuentas con movimientos directos (mismo nivel o menor)
            var sql2 = $@"
                SELECT c.Codigo, c.Descripcion, c.Nivel, c.Clasificacion,
                       SUM(COALESCE(m.Debe, 0)) as TotalDebe, 
                       SUM(COALESCE(m.Haber, 0)) as TotalHaber
                FROM Cuentas c
                INNER JOIN MovComprobante m ON c.IdCuenta = m.IdCuenta AND m.IdEmpresa = c.IdEmpresa
                INNER JOIN Comprobante co ON m.IdComp = co.IdComp AND co.IdEmpresa = m.IdEmpresa AND co.Ano = m.Ano
                WHERE c.IdEmpresa = {empresaId} AND c.Ano = {ano} AND c.Nivel <= {nivel} 
                  AND {whereClause} AND co.Ano = c.Ano
                GROUP BY c.IdCuenta, c.Codigo, c.Descripcion, c.Nivel, c.Clasificacion";

            var cuentasDirectas = await context.Database
                .SqlQueryRaw<MovimientoCuenta>(sql2)
                .ToListAsync();

            logger.LogInformation("SQL2 (Cuentas directas): {Count} registros. SQL: {Sql}", cuentasDirectas.Count, sql2);

            foreach (var cuenta in cuentasDirectas)
            {
                if (saldosPorCuenta.ContainsKey(cuenta.Codigo))
                {
                    saldosPorCuenta[cuenta.Codigo].TotalDebe += cuenta.TotalDebe;
                    saldosPorCuenta[cuenta.Codigo].TotalHaber += cuenta.TotalHaber;
                }
                else
                {
                    saldosPorCuenta[cuenta.Codigo] = cuenta;
                }
            }

            // UNION 3: Suma movimientos de hijos cuyo padre es del nivel solicitado
            // Esto agrega movimientos de cuentas nivel N+1 a sus padres de nivel N
            var sql3 = $@"
                SELECT c1.Codigo, c1.Descripcion, c1.Nivel, c1.Clasificacion,
                       SUM(COALESCE(m.Debe, 0)) as TotalDebe, 
                       SUM(COALESCE(m.Haber, 0)) as TotalHaber
                FROM Cuentas c
                INNER JOIN MovComprobante m ON c.IdCuenta = m.IdCuenta AND m.IdEmpresa = c.IdEmpresa
                INNER JOIN Comprobante co ON m.IdComp = co.IdComp AND co.IdEmpresa = m.IdEmpresa AND co.Ano = m.Ano
                INNER JOIN Cuentas c1 ON c.idPadre = c1.IdCuenta AND c.IdEmpresa = c1.IdEmpresa AND c.Ano = c1.Ano
                WHERE c1.Nivel = {nivel} AND c1.IdEmpresa = {empresaId} AND c1.Ano = {ano}
                  AND {whereClause} AND co.Ano = c.Ano
                GROUP BY c1.IdCuenta, c1.Codigo, c1.Descripcion, c1.Nivel, c1.Clasificacion";

            var cuentasPadre = await context.Database
                .SqlQueryRaw<MovimientoCuenta>(sql3)
                .ToListAsync();

            logger.LogInformation("SQL3 (Cuentas padre, nivel={Nivel}): {Count} registros. SQL: {Sql}", 
                nivel, cuentasPadre.Count, sql3);

            foreach (var cuenta in cuentasPadre)
            {
                if (saldosPorCuenta.ContainsKey(cuenta.Codigo))
                {
                    saldosPorCuenta[cuenta.Codigo].TotalDebe += cuenta.TotalDebe;
                    saldosPorCuenta[cuenta.Codigo].TotalHaber += cuenta.TotalHaber;
                }
                else
                {
                    saldosPorCuenta[cuenta.Codigo] = cuenta;
                }
            }

            // UNION 4: Suma movimientos de nietos cuyo abuelo es del nivel solicitado
            // Esto agrega movimientos de cuentas nivel N+2 a sus abuelos de nivel N
            var sql4 = $@"
                SELECT c2.Codigo, c2.Descripcion, c2.Nivel, c2.Clasificacion,
                       SUM(COALESCE(m.Debe, 0)) as TotalDebe, 
                       SUM(COALESCE(m.Haber, 0)) as TotalHaber
                FROM Cuentas c
                INNER JOIN MovComprobante m ON c.IdCuenta = m.IdCuenta AND m.IdEmpresa = c.IdEmpresa
                INNER JOIN Comprobante co ON m.IdComp = co.IdComp AND co.IdEmpresa = m.IdEmpresa AND co.Ano = m.Ano
                INNER JOIN Cuentas c1 ON c.idPadre = c1.IdCuenta AND c.IdEmpresa = c1.IdEmpresa AND c.Ano = c1.Ano
                INNER JOIN Cuentas c2 ON c1.idPadre = c2.IdCuenta AND c1.IdEmpresa = c2.IdEmpresa AND c1.Ano = c2.Ano
                WHERE c2.Nivel = {nivel} AND c2.IdEmpresa = {empresaId} AND c2.Ano = {ano}
                  AND {whereClause} AND co.Ano = c.Ano
                GROUP BY c2.IdCuenta, c2.Codigo, c2.Descripcion, c2.Nivel, c2.Clasificacion";

            var cuentasAbuelo = await context.Database
                .SqlQueryRaw<MovimientoCuenta>(sql4)
                .ToListAsync();

            logger.LogInformation("SQL4 (Cuentas abuelo, nivel={Nivel}): {Count} registros", nivel, cuentasAbuelo.Count);

            foreach (var cuenta in cuentasAbuelo)
            {
                if (saldosPorCuenta.ContainsKey(cuenta.Codigo))
                {
                    saldosPorCuenta[cuenta.Codigo].TotalDebe += cuenta.TotalDebe;
                    saldosPorCuenta[cuenta.Codigo].TotalHaber += cuenta.TotalHaber;
                }
                else
                {
                    saldosPorCuenta[cuenta.Codigo] = cuenta;
                }
            }

            // UNION 5: Suma movimientos de bisnietos cuyo bisabuelo es del nivel solicitado
            // Esto agrega movimientos de cuentas nivel N+3 a sus bisabuelos de nivel N
            var sql5 = $@"
                SELECT c3.Codigo, c3.Descripcion, c3.Nivel, c3.Clasificacion,
                       SUM(COALESCE(m.Debe, 0)) as TotalDebe, 
                       SUM(COALESCE(m.Haber, 0)) as TotalHaber
                FROM Cuentas c
                INNER JOIN MovComprobante m ON c.IdCuenta = m.IdCuenta AND m.IdEmpresa = c.IdEmpresa
                INNER JOIN Comprobante co ON m.IdComp = co.IdComp AND co.IdEmpresa = m.IdEmpresa AND co.Ano = m.Ano
                INNER JOIN Cuentas c1 ON c.idPadre = c1.IdCuenta AND c.IdEmpresa = c1.IdEmpresa AND c.Ano = c1.Ano
                INNER JOIN Cuentas c2 ON c1.idPadre = c2.IdCuenta AND c1.IdEmpresa = c2.IdEmpresa AND c1.Ano = c2.Ano
                INNER JOIN Cuentas c3 ON c2.idPadre = c3.IdCuenta AND c2.IdEmpresa = c3.IdEmpresa AND c2.Ano = c3.Ano
                WHERE c3.Nivel = {nivel} AND c3.IdEmpresa = {empresaId} AND c3.Ano = {ano}
                  AND {whereClause} AND co.Ano = c.Ano
                GROUP BY c3.IdCuenta, c3.Codigo, c3.Descripcion, c3.Nivel, c3.Clasificacion";

            var cuentasBisabuelo = await context.Database
                .SqlQueryRaw<MovimientoCuenta>(sql5)
                .ToListAsync();

            logger.LogInformation("SQL5 (Cuentas bisabuelo, nivel={Nivel}): {Count} registros", nivel, cuentasBisabuelo.Count);

            foreach (var cuenta in cuentasBisabuelo)
            {
                if (saldosPorCuenta.ContainsKey(cuenta.Codigo))
                {
                    saldosPorCuenta[cuenta.Codigo].TotalDebe += cuenta.TotalDebe;
                    saldosPorCuenta[cuenta.Codigo].TotalHaber += cuenta.TotalHaber;
                }
                else
                {
                    saldosPorCuenta[cuenta.Codigo] = cuenta;
                }
            }

            // UNION 6: Suma movimientos de tataranietos cuyo tatarabuelo es del nivel solicitado
            // Esto agrega movimientos de cuentas nivel N+4 a sus tatarabuelos de nivel N
            var sql6 = $@"
                SELECT c4.Codigo, c4.Descripcion, c4.Nivel, c4.Clasificacion,
                       SUM(COALESCE(m.Debe, 0)) as TotalDebe, 
                       SUM(COALESCE(m.Haber, 0)) as TotalHaber
                FROM Cuentas c
                INNER JOIN MovComprobante m ON c.IdCuenta = m.IdCuenta AND m.IdEmpresa = c.IdEmpresa
                INNER JOIN Comprobante co ON m.IdComp = co.IdComp AND co.IdEmpresa = m.IdEmpresa AND co.Ano = m.Ano
                INNER JOIN Cuentas c1 ON c.idPadre = c1.IdCuenta AND c.IdEmpresa = c1.IdEmpresa AND c.Ano = c1.Ano
                INNER JOIN Cuentas c2 ON c1.idPadre = c2.IdCuenta AND c1.IdEmpresa = c2.IdEmpresa AND c1.Ano = c2.Ano
                INNER JOIN Cuentas c3 ON c2.idPadre = c3.IdCuenta AND c2.IdEmpresa = c3.IdEmpresa AND c2.Ano = c3.Ano
                INNER JOIN Cuentas c4 ON c3.idPadre = c4.IdCuenta AND c3.IdEmpresa = c4.IdEmpresa AND c3.Ano = c4.Ano
                WHERE c4.Nivel = {nivel} AND c4.IdEmpresa = {empresaId} AND c4.Ano = {ano}
                  AND {whereClause} AND co.Ano = c.Ano
                GROUP BY c4.IdCuenta, c4.Codigo, c4.Descripcion, c4.Nivel, c4.Clasificacion";

            var cuentasTatarabuelo = await context.Database
                .SqlQueryRaw<MovimientoCuenta>(sql6)
                .ToListAsync();

            logger.LogInformation("SQL6 (Cuentas tatarabuelo, nivel={Nivel}): {Count} registros", nivel, cuentasTatarabuelo.Count);

            foreach (var cuenta in cuentasTatarabuelo)
            {
                if (saldosPorCuenta.ContainsKey(cuenta.Codigo))
                {
                    saldosPorCuenta[cuenta.Codigo].TotalDebe += cuenta.TotalDebe;
                    saldosPorCuenta[cuenta.Codigo].TotalHaber += cuenta.TotalHaber;
                }
                else
                {
                    saldosPorCuenta[cuenta.Codigo] = cuenta;
                }
            }

            // Convertir a filas de balance con saldos calculados
            var filas = new List<BalanceClasificadoFila>();
            var filasConMovimiento = 0;
            foreach (var kvp in saldosPorCuenta)
            {
                var cuenta = kvp.Value;
                var saldo = CalcularSaldoCuenta(cuenta.TotalDebe, cuenta.TotalHaber, (byte)cuenta.Clasificacion);
                
                if (cuenta.TotalDebe != 0 || cuenta.TotalHaber != 0)
                {
                    filasConMovimiento++;
                }
                
                filas.Add(new BalanceClasificadoFila
                {
                    Codigo = cuenta.Codigo,
                    Descripcion = cuenta.Descripcion,
                    Nivel = cuenta.Nivel,
                    Clasificacion = cuenta.Clasificacion,
                    Saldo = saldo,
                    EsTitulo = cuenta.TotalDebe == 0 && cuenta.TotalHaber == 0
                });
            }

        logger.LogInformation("Generadas {Count} filas totales, {ConMov} con movimientos (UNION 1-6)",
            filas.Count, filasConMovimiento);
        return filas.OrderBy(f => f.Codigo).ToList();
    }

    private decimal CalcularSaldoCuenta(decimal debe, decimal haber, byte clasificacion)
    {
        // VB6: C�lculo de saldo seg�n clasificación de cuenta
        switch (clasificacion)
        {
            case CLASCTA_ACTIVO:
            case CLASCTA_ORDEN:
                return debe - haber; // Activo y Orden: Debe - Haber
            case CLASCTA_PASIVO:
            case CLASCTA_RESULTADO:
                return haber - debe; // Pasivo y Resultado: Haber - Debe
            default:
                return debe - haber;
        }
    }

    private int DateToInt(DateTime fecha)
    {
        // Convertir DateTime a formato OLE/Excel
        return (int)fecha.ToOADate();
    }

    public async Task<BalanceClasificadoExportResponse> ExportarBalanceAsync(BalanceClasificadoExportRequest request)
    {
        logger.LogInformation("Exportando balance en formato {Formato}", request.Formato);

        var balance = await GenerarBalanceAsync(request.Request);

        // Generar contenido seg�n formato
        byte[] data;
        string contentType;
        string fileName;

        switch (request.Formato.ToUpper())
        {
            case "PDF":
                data = await GenerarPdfAsync(balance);
                contentType = "application/pdf";
                fileName = $"balance_clasificado_{request.Request.Ano}_{DateTime.Now:yyyyMMdd}.pdf";
                break;
            case "EXCEL":
                data = await GenerarExcelAsync(balance);
                contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                fileName = $"balance_clasificado_{request.Request.Ano}_{DateTime.Now:yyyyMMdd}.xlsx";
                break;
            default:
                throw new BusinessException($"Formato no soportado: {request.Formato}");
        }

        return new BalanceClasificadoExportResponse
        {
            Data = data,
            ContentType = contentType,
            FileName = fileName
        };
    }

    public async Task<SumaMovimientosResponse> CalcularSumaMovimientosAsync(SumaMovimientosRequest request)
    {
        {
            logger.LogInformation("Calculando suma de movimientos para {Count} cuentas", request.IdCuentas.Count);

            var movimientos = await context.MovComprobante
                .Where(m => m.IdEmpresa == request.IdEmpresa && 
                           request.IdCuentas.Contains(m.IdCuenta ?? 0))
                .Join(context.Comprobante,
                      m => new { IdComp = m.IdComp ?? 0, IdEmpresa = m.IdEmpresa ?? 0, Ano = m.Ano ?? 0 },
                      c => new { IdComp = c.IdComp, IdEmpresa = c.IdEmpresa ?? 0, Ano = c.Ano ?? 0 },
                      (m, c) => new { m, c })
                .Where(mc => mc.c.Ano == request.Ano)
                .GroupBy(mc => mc.m.IdCuenta)
                .Select(g => new
                {
                    IdCuenta = g.Key,
                    TotalDebe = g.Sum(x => x.m.Debe ?? 0),
                    TotalHaber = g.Sum(x => x.m.Haber ?? 0)
                })
                .ToListAsync();

            var total = movimientos.Sum(m => (decimal)(m.TotalDebe - m.TotalHaber));

            return new SumaMovimientosResponse
            {
                Total = total,
                Detalles = movimientos.Cast<object>().ToList()
            };
        }
    }

    public async Task<object> GetLibroMayorAsync(int empresaId, short ano, int idCuenta, DateTime fechaDesde, DateTime fechaHasta)
    {
        {
            logger.LogInformation("Obteniendo libro mayor para cuenta {IdCuenta}", idCuenta);

            var fechaDesdeInt = DateToInt(fechaDesde);
            var fechaHastaInt = DateToInt(fechaHasta);

            var movimientos = await (
                from m in context.MovComprobante
                join c in context.Comprobante on new { IdComp = m.IdComp ?? 0, IdEmpresa = m.IdEmpresa ?? 0, Ano = m.Ano ?? 0 } 
                    equals new { IdComp = c.IdComp, IdEmpresa = c.IdEmpresa ?? 0, Ano = c.Ano ?? 0 }
                where m.IdEmpresa == empresaId && m.IdCuenta == idCuenta && 
                      c.Fecha >= fechaDesdeInt && c.Fecha <= fechaHastaInt
                orderby c.Fecha, c.Correlativo
                select new
                {
                    c.Fecha,
                    c.Correlativo,
                    c.Glosa,
                    m.Debe,
                    m.Haber,
                    GlosaMov = m.Glosa
                }
            ).ToListAsync();

            return new { Movimientos = movimientos };
        }
    }

    public Task ValidarFiltrosAsync(BalanceClasificadoRequest request)
    {
        var errors = new List<string>();

        if (request.IdEmpresa <= 0)
            errors.Add("ID de empresa inválido");

        if (request.Ano < 2000 || request.Ano > DateTime.Now.Year + 1)
            errors.Add("A�o inválido");

        if (request.FechaCorte < new DateTime(request.Ano, 1, 1) ||
            request.FechaCorte > new DateTime(request.Ano, 12, 31))
            errors.Add("Fecha de corte debe estar dentro del a�o seleccionado");

        if (request.NivelDetalle < 1 || request.NivelDetalle > 5)
            errors.Add("Nivel de detalle debe estar entre 1 y 5");

        if (errors.Any())
            throw new BusinessException(string.Join(", ", errors));

        return Task.CompletedTask;
    }

    public async Task<BalanceClasificadoDto> GetVistaPreviaAsync(BalanceClasificadoRequest request)
    {
        // Vista previa usa la misma l�gica que generar balance
        return await GenerarBalanceAsync(request);
    }

    public async Task<object> GetEstadisticasAsync(BalanceClasificadoRequest request)
    {
        var balance = await GenerarBalanceAsync(request);

        var stats = new
        {
            TotalCuentas = balance.Filas.Count,
            CuentasConSaldo = balance.Filas.Count(f => f.Saldo != 0),
            TotalActivo = balance.TotalActivo,
            TotalPasivo = balance.TotalPasivo,
            TotalPatrimonio = balance.TotalPatrimonio,
            Balanceado = Math.Abs(balance.TotalActivo - (balance.TotalPasivo + balance.TotalPatrimonio)) < 0.01m
        };

        return stats;
    }

    private List<BalanceClasificadoFila> AgregarLineasTotales(List<BalanceClasificadoFila> filas,
        decimal totalActivo, decimal totalPasivo, decimal totalResultado)
    {
        // VB6: AddLinTotClasif - Agrega l�neas "TOTAL ACTIVO", "TOTAL PASIVO", etc.
        var resultado = new List<BalanceClasificadoFila>();
        byte? clasificacionActual = null;

        foreach (var fila in filas)
        {
            // Si cambia la clasificación, agregar l�nea TOTAL de la clasificación anterior
            if (clasificacionActual.HasValue && clasificacionActual != (byte)fila.Clasificacion)
            {
                resultado.Add(CrearLineaTotal(clasificacionActual.Value, totalActivo, totalPasivo, totalResultado));
            }

            resultado.Add(fila);
            clasificacionActual = (byte)fila.Clasificacion;
        }

        // Agregar �ltimo total si hay filas
        if (clasificacionActual.HasValue)
        {
            resultado.Add(CrearLineaTotal(clasificacionActual.Value, totalActivo, totalPasivo, totalResultado));
        }

        return resultado;
    }

    private BalanceClasificadoFila CrearLineaTotal(byte clasificacion, decimal totalActivo,
        decimal totalPasivo, decimal totalResultado)
    {
        // VB6: Analysis-Part3-LoadAll.md l�nea 180
        string descripcion;
        decimal total;

        switch (clasificacion)
        {
            case CLASCTA_ACTIVO:
                descripcion = "TOTAL ACTIVO";
                total = totalActivo;
                break;
            case CLASCTA_PASIVO:
                descripcion = "TOTAL PASIVO";
                total = totalPasivo;
                break;
            case CLASCTA_RESULTADO:
                descripcion = "TOTAL PATRIMONIO";
                total = totalResultado;
                break;
            case CLASCTA_ORDEN:
                descripcion = "TOTAL ORDEN";
                total = 0; // Cuentas de orden se compensan
                break;
            default:
                descripcion = "TOTAL";
                total = 0;
                break;
        }

        return new BalanceClasificadoFila
        {
            Codigo = "",
            Descripcion = descripcion,
            Nivel = 1,
            Clasificacion = clasificacion,
            Saldo = total,
            EsTitulo = false,
            EsLineaTotal = true,
            EsNegrita = true
        };
    }

    private List<BalanceClasificadoFila> AgregarResultadoEjercicio(List<BalanceClasificadoFila> filas,
        decimal totalPasivo, decimal totalActivo)
    {
        // VB6: AddResEjercicio - Analysis-Part3-LoadAll.md l�nea 220
        // Resultado del Ejercicio = Ingresos - Gastos = Pasivo - Activo (inversión de ecuación contable)
        // Se inserta despu�s de PASIVO y antes del TOTAL PATRIMONIO
        
        var resultado = new List<BalanceClasificadoFila>();
        var resEjercicio = totalPasivo - totalActivo;
        var agregado = false;

        for (var i = 0; i < filas.Count; i++)
        {
            var fila = filas[i];
            
            // Buscar la posición despu�s de TOTAL PASIVO
            if (!agregado && fila.EsLineaTotal && fila.Clasificacion == CLASCTA_PASIVO)
            {
                resultado.Add(fila);
                
                // Insertar l�nea Resultado del Ejercicio
                resultado.Add(new BalanceClasificadoFila
                {
                    Codigo = "",
                    Descripcion = "Resultado del Ejercicio",
                    Nivel = 1,
                    Clasificacion = CLASCTA_PASIVO, // Se clasifica como pasivo para el balance
                    Saldo = resEjercicio,
                    EsTitulo = false,
                    EsLineaTotal = false,
                    EsResultadoEjercicio = true,
                    EsNegrita = true
                });
                
                agregado = true;
                logger.LogInformation("Agregada l�nea Resultado del Ejercicio: {Monto}", resEjercicio);
            }
            else
            {
                resultado.Add(fila);
            }
        }

        return resultado;
    }

    private async Task<byte[]> GenerarPdfAsync(BalanceClasificadoDto balance)
    {
        {
            logger.LogInformation("Generando PDF del Balance Clasificado para empresa {EmpresaId}, a�o {Ano}", 
                balance.IdEmpresa, balance.Ano);

            // Obtener datos de la empresa
            var empresa = await context.Empresa
                .FirstOrDefaultAsync(e => e.Id == balance.IdEmpresa);

            if (empresa == null)
            {
                throw new BusinessException($"Empresa {balance.IdEmpresa} no encontrada");
            }

            var html = GenerarHtmlBalance(empresa, balance);
            return System.Text.Encoding.UTF8.GetBytes(html);
        }
    }

    private async Task<byte[]> GenerarExcelAsync(BalanceClasificadoDto balance)
    {
        {
            logger.LogInformation("Generando Excel del Balance Clasificado para empresa {EmpresaId}, a�o {Ano}", 
                balance.IdEmpresa, balance.Ano);

            // Configurar licencia EPPlus (no comercial)
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            // Obtener datos de la empresa
            var empresa = await context.Empresa
                .FirstOrDefaultAsync(e => e.Id == balance.IdEmpresa);

            if (empresa == null)
            {
                throw new BusinessException($"Empresa {balance.IdEmpresa} no encontrada");
            }

            using var package = new ExcelPackage();
            var worksheet = package.Workbook.Worksheets.Add("Balance Clasificado");

            var row = 1;

            // Encabezado - Nombre empresa
            worksheet.Cells[row, 1].Value = empresa.Nombre?.ToUpper();
            worksheet.Cells[row, 1, row, 5].Merge = true;
            worksheet.Cells[row, 1].Style.Font.Bold = true;
            worksheet.Cells[row, 1].Style.Font.Size = 14;
            worksheet.Cells[row, 1].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
            row++;

            // RUT empresa
            worksheet.Cells[row, 1].Value = $"RUT: {empresa.Rut}";
            worksheet.Cells[row, 1, row, 5].Merge = true;
            worksheet.Cells[row, 1].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
            row++;

            // T�tulo del reporte
            worksheet.Cells[row, 1].Value = "BALANCE GENERAL CLASIFICADO";
            worksheet.Cells[row, 1, row, 5].Merge = true;
            worksheet.Cells[row, 1].Style.Font.Bold = true;
            worksheet.Cells[row, 1].Style.Font.Size = 12;
            worksheet.Cells[row, 1].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
            row++;

            // Fecha de corte
            worksheet.Cells[row, 1].Value = $"Al: {balance.FechaCorte:dd/MM/yyyy}";
            worksheet.Cells[row, 1, row, 5].Merge = true;
            worksheet.Cells[row, 1].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
            row++;

            // L�nea en blanco
            row++;

            // Encabezados de columnas
            worksheet.Cells[row, 1].Value = "C�digo";
            worksheet.Cells[row, 2].Value = "Cuenta";
            worksheet.Cells[row, 3].Value = "Saldo";
            
            worksheet.Cells[row, 1, row, 3].Style.Font.Bold = true;
            worksheet.Cells[row, 1, row, 3].Style.Fill.PatternType = ExcelFillStyle.Solid;
            worksheet.Cells[row, 1, row, 3].Style.Fill.BackgroundColor.SetColor(Color.LightGray);
            worksheet.Cells[row, 1, row, 3].Style.Border.BorderAround(ExcelBorderStyle.Medium);
            row++;

            // Agrupar por clasificación
            var clasificacionActual = "";
            var startClassificationRow = row;

            foreach (var fila in balance.Filas)
            {
                // Determinar nombre de clasificación
                var nombreClasificacion = fila.Clasificacion switch
                {
                    CLASCTA_ACTIVO => "ACTIVO",
                    CLASCTA_PASIVO => "PASIVO",
                    CLASCTA_RESULTADO => "PATRIMONIO",
                    CLASCTA_ORDEN => "CUENTAS DE ORDEN",
                    _ => "OTROS"
                };

                // Si cambia la clasificación, agregar t�tulo de sección
                if (clasificacionActual != nombreClasificacion && !fila.EsLineaTotal && !fila.EsResultadoEjercicio)
                {
                    if (!string.IsNullOrEmpty(clasificacionActual))
                    {
                        row++; // L�nea en blanco entre clasificaciones
                    }

                    worksheet.Cells[row, 1].Value = nombreClasificacion;
                    worksheet.Cells[row, 1, row, 3].Merge = true;
                    worksheet.Cells[row, 1].Style.Font.Bold = true;
                    worksheet.Cells[row, 1].Style.Font.Size = 11;
                    worksheet.Cells[row, 1].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    worksheet.Cells[row, 1].Style.Fill.BackgroundColor.SetColor(Color.LightBlue);
                    row++;

                    clasificacionActual = nombreClasificacion;
                    startClassificationRow = row;
                }

                // C�digo (con indentación por nivel)
                if (!string.IsNullOrEmpty(fila.Codigo))
                {
                    var indent = new string(' ', (fila.Nivel - 1) * 2);
                    worksheet.Cells[row, 1].Value = indent + fila.Codigo;
                }

                // Descripción
                worksheet.Cells[row, 2].Value = fila.Descripcion;
                if (fila.EsNegrita || fila.EsLineaTotal || fila.EsResultadoEjercicio)
                {
                    worksheet.Cells[row, 2].Style.Font.Bold = true;
                }

                // Saldo
                if (fila.Saldo != 0 || fila.EsLineaTotal || fila.EsResultadoEjercicio)
                {
                    worksheet.Cells[row, 3].Value = fila.Saldo;
                    worksheet.Cells[row, 3].Style.Numberformat.Format = "#,##0";
                    worksheet.Cells[row, 3].Style.HorizontalAlignment = ExcelHorizontalAlignment.Right;
                }

                // Estilo especial para l�neas totales
                if (fila.EsLineaTotal)
                {
                    worksheet.Cells[row, 1, row, 3].Style.Font.Bold = true;
                    worksheet.Cells[row, 1, row, 3].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    worksheet.Cells[row, 1, row, 3].Style.Fill.BackgroundColor.SetColor(Color.Yellow);
                    worksheet.Cells[row, 1, row, 3].Style.Border.Top.Style = ExcelBorderStyle.Medium;
                    worksheet.Cells[row, 1, row, 3].Style.Border.Bottom.Style = ExcelBorderStyle.Medium;
                }

                // Estilo especial para Resultado del Ejercicio
                if (fila.EsResultadoEjercicio)
                {
                    worksheet.Cells[row, 1, row, 3].Style.Font.Bold = true;
                    worksheet.Cells[row, 1, row, 3].Style.Font.Italic = true;
                    worksheet.Cells[row, 1, row, 3].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    worksheet.Cells[row, 1, row, 3].Style.Fill.BackgroundColor.SetColor(Color.LightGreen);
                }

                row++;
            }

            // Ajustar anchos de columna
            worksheet.Column(1).Width = 15;  // C�digo
            worksheet.Column(2).Width = 50;  // Descripción
            worksheet.Column(3).Width = 18;  // Saldo

            // Configurar impresión
            worksheet.PrinterSettings.Orientation = eOrientation.Portrait;
            worksheet.PrinterSettings.FitToPage = true;
            worksheet.PrinterSettings.FitToWidth = 1;
            worksheet.PrinterSettings.FitToHeight = 0;

            logger.LogInformation("Exportación Excel completada: {Filas} filas, Total Activo: {TotalActivo}", 
                balance.Filas.Count, balance.TotalActivo);

            return package.GetAsByteArray();
        }
    }

    private string GenerarHtmlBalance(App.Data.Empresa empresa, BalanceClasificadoDto balance)
    {
        var html = new System.Text.StringBuilder();
        html.AppendLine("<!DOCTYPE html>");
        html.AppendLine("<html><head>");
        html.AppendLine("<meta charset='utf-8'>");
        html.AppendLine("<style>");
        html.AppendLine("body { font-family: Arial, sans-serif; font-size: 10pt; margin: 20px; }");
        html.AppendLine(".header { text-align: center; margin-bottom: 30px; }");
        html.AppendLine(".header h1 { margin: 5px 0; font-size: 16pt; }");
        html.AppendLine(".header h2 { margin: 5px 0; font-size: 14pt; font-weight: bold; }");
        html.AppendLine(".header p { margin: 3px 0; }");
        html.AppendLine("table { width: 100%; border-collapse: collapse; margin-bottom: 10px; }");
        html.AppendLine(".clasificacion-header { background-color: #d0e0f0; padding: 8px; font-weight: bold; font-size: 11pt; margin-top: 15px; border: 1px solid #000; }");
        html.AppendLine(".cuenta { padding: 4px 8px; }");
        html.AppendLine(".cuenta-nivel1 { font-weight: bold; margin-left: 0; }");
        html.AppendLine(".cuenta-nivel2 { margin-left: 15px; }");
        html.AppendLine(".cuenta-nivel3 { margin-left: 30px; }");
        html.AppendLine(".cuenta-nivel4 { margin-left: 45px; }");
        html.AppendLine(".cuenta-nivel5 { margin-left: 60px; }");
        html.AppendLine(".codigo { width: 120px; }");
        html.AppendLine(".descripcion { width: auto; }");
        html.AppendLine(".saldo { width: 150px; text-align: right; }");
        html.AppendLine(".linea-total { background-color: #ffff99; font-weight: bold; border-top: 2px solid #000; border-bottom: 2px solid #000; }");
        html.AppendLine(".resultado-ejercicio { background-color: #ccffcc; font-weight: bold; font-style: italic; }");
        html.AppendLine("@media print { body { margin: 10px; } .no-print { display: none; } }");
        html.AppendLine("</style>");
        html.AppendLine("</head><body>");

        // Encabezado
        html.AppendLine("<div class='header'>");
        html.AppendLine($"<h1>{empresa.Nombre?.ToUpper()}</h1>");
        html.AppendLine($"<p>RUT: {empresa.Rut}</p>");
        html.AppendLine("<h2>BALANCE GENERAL CLASIFICADO</h2>");
        html.AppendLine($"<p>Al: {balance.FechaCorte:dd/MM/yyyy}</p>");
        html.AppendLine("</div>");

        // Contenido del balance
        html.AppendLine("<table>");

        var clasificacionActual = "";
        foreach (var fila in balance.Filas)
        {
            // Determinar nombre de clasificación
            var nombreClasificacion = fila.Clasificacion switch
            {
                CLASCTA_ACTIVO => "ACTIVO",
                CLASCTA_PASIVO => "PASIVO",
                CLASCTA_RESULTADO => "PATRIMONIO",
                CLASCTA_ORDEN => "CUENTAS DE ORDEN",
                _ => "OTROS"
            };

            // Si cambia la clasificación, agregar t�tulo de sección
            if (clasificacionActual != nombreClasificacion && !fila.EsLineaTotal && !fila.EsResultadoEjercicio)
            {
                html.AppendLine($"<tr><td colspan='3' class='clasificacion-header'>{nombreClasificacion}</td></tr>");
                clasificacionActual = nombreClasificacion;
            }

            // Construir clase CSS seg�n nivel y tipo de l�nea
            var clasesCss = "cuenta";
            if (fila.EsLineaTotal)
            {
                clasesCss += " linea-total";
            }
            else if (fila.EsResultadoEjercicio)
            {
                clasesCss += " resultado-ejercicio";
            }
            else
            {
                clasesCss += $" cuenta-nivel{fila.Nivel}";
            }

            html.AppendLine("<tr>");
            html.AppendLine($"<td class='codigo {clasesCss}'>{fila.Codigo}</td>");
            html.AppendLine($"<td class='descripcion {clasesCss}'>{fila.Descripcion}</td>");
            
            var saldoFormateado = fila.Saldo != 0 || fila.EsLineaTotal || fila.EsResultadoEjercicio 
                ? fila.Saldo.ToString("N0") 
                : "";
            html.AppendLine($"<td class='saldo {clasesCss}'>{saldoFormateado}</td>");
            html.AppendLine("</tr>");
        }

        html.AppendLine("</table>");

        // Bot�n para imprimir (oculto en impresión)
        html.AppendLine("<div class='no-print' style='text-align: center; margin-top: 30px;'>");
        html.AppendLine("<button onclick='window.print()' style='padding: 10px 20px; font-size: 12pt;'>Imprimir</button>");
        html.AppendLine("</div>");

        html.AppendLine("</body></html>");

        return html.ToString();
    }

    // M�todos para Libro Oficial (VB6: QryLogImpreso y AddLogImpresion)
    
    public async Task<bool> VerificarLibroOficialAsync(int empresaId, short ano, DateTime fechaDesde, DateTime fechaHasta)
    {
        {
            var fechaDesdeInt = DateToInt(fechaDesde);
            var fechaHastaInt = DateToInt(fechaHasta);

            var logPrevio = await context.LogImpreso
                .Where(l => l.idInforme == LIBOF_BALANCEGRAL && 
                           l.IdEmpresa == empresaId && 
                           l.Ano == ano &&
                           l.FDesde == fechaDesdeInt &&
                           l.FHasta == fechaHastaInt)
                .OrderByDescending(l => l.Fecha)
                .FirstOrDefaultAsync();

            if (logPrevio != null)
            {
                logger.LogWarning("Balance Clasificado Oficial ya impreso el {Fecha}", 
                    IntToDate(logPrevio.Fecha ?? 0));
                return true;
            }

            return false;
        }
    }

    public async Task RegistrarImpresionOficialAsync(int empresaId, short ano, DateTime fechaDesde, 
        DateTime fechaHasta, string usuario, int? numPagIni = null, int? numPagFin = null)
    {
        {
            var fechaDesdeInt = DateToInt(fechaDesde);
            var fechaHastaInt = DateToInt(fechaHasta);
            var fechaActual = DateToInt(DateTime.Now);

            // Obtener ID de usuario si existe
            var usuarioEntity = await context.Usuarios
                .FirstOrDefaultAsync(u => u.Usuario == usuario);

            var logImpresion = new App.Data.LogImpreso
            {
                idInforme = LIBOF_BALANCEGRAL,
                IdEmpresa = empresaId,
                Ano = ano,
                Mes = null, // Balance anual no tiene mes espec�fico
                FDesde = fechaDesdeInt,
                FHasta = fechaHastaInt,
                Fecha = fechaActual,
                IdUsuario = usuarioEntity?.IdUsuario,
                CorrInicio = numPagIni,
                CorrFin = numPagFin,
                Estado = 1, // VB6: Estado activo
                Comentario = "Balance Clasificado Oficial"
            };

            context.LogImpreso.Add(logImpresion);
            await context.SaveChangesAsync();

            logger.LogInformation("Registrada impresión oficial del Balance Clasificado por {Usuario}. " +
                "Empresa: {EmpresaId}, A�o: {Ano}, Per�odo: {FechaDesde}-{FechaHasta}", 
                usuario, empresaId, ano, fechaDesde, fechaHasta);
        }
    }

    private DateTime IntToDate(int dateInt)
    {
        // Formato OLE/Excel ? DateTime
        return DateTime.FromOADate(dateInt);
    }
}

// Clase auxiliar para consultas SQL raw
public class MovimientoCuenta
{
    public string Codigo { get; set; } = "";
    public string Descripcion { get; set; } = "";
    public int Nivel { get; set; }
    public int Clasificacion { get; set; }
    public decimal TotalDebe { get; set; }
    public decimal TotalHaber { get; set; }
}
