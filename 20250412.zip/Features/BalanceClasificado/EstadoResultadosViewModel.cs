namespace App.Features.BalanceClasificado;

/// <summary>
/// ViewModel para la vista Index del Estado de Resultados
/// Reemplaza el uso de ViewBag con propiedades tipadas
/// </summary>
public class EstadoResultadosIndexViewModel
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public string FechaDesde { get; set; } = string.Empty;
    public string FechaHasta { get; set; } = string.Empty;
    public BalanceClasificadoOpciones OpcionesFiltros { get; set; } = new();
}
