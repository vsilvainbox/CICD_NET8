namespace App.Features.ComponentesActivoFijo;

public class ComponentesActivoFijoDto
{
    public int IdActFijo { get; set; }
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public int? IdGrupo { get; set; }
    public string? NombGrupo { get; set; }
    public string? Descripcion { get; set; }
    public int? Cantidad { get; set; }
    public bool? SinDetComps { get; set; }
    public bool? NoDepreciable { get; set; }
    public double? PrecioFactura { get; set; }
    public double? DerechosIntern { get; set; }
    public double? Transporte { get; set; }
    public double? ObrasAdapt { get; set; }
    public int? FImported { get; set; }
    public List<ComponenteDto> Componentes { get; set; } = new();
    public List<ComponenteDisponibleDto> ComponentesDisponibles { get; set; } = new();
}

public class ComponenteDto
{
    public int IdCompFicha { get; set; }
    public int? IdComp { get; set; }
    public string? NombComp { get; set; }
    public float? PjeDivComp { get; set; }
    public double? ValorCompra { get; set; }
    public double? ValorResidual { get; set; }
    public float? PjeAmortizacion { get; set; }
    public short? VidaUtil { get; set; }
    public double? CostosAdicionales { get; set; }
    public float? TasaDesc { get; set; }
    public double? CostoDesmant { get; set; }
    public double? ValActCostoDesmant { get; set; }
    public double? ValorBien { get; set; }
    public double? ValorRazonable_31_12 { get; set; }
    public bool? NoExisteValRazonable { get; set; }
    public double? OtrasDiferencias { get; set; }
}

public class ComponenteDisponibleDto
{
    public int IdComp { get; set; }
    public string? NombComp { get; set; }
}

public class GuardarComponenteDto
{
    public int IdActFijo { get; set; }
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public int IdGrupo { get; set; }
    public bool SinDetComps { get; set; }
    public ComponenteDto Componente { get; set; } = new();
}

#region ViewModels

public class ComponentesActivoFijoIndexViewModel
{
    public int IdActFijo { get; set; }
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
}

#endregion
