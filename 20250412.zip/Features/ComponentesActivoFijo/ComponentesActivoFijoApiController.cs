using Microsoft.AspNetCore.Mvc;

namespace App.Features.ComponentesActivoFijo;

[ApiController]
[Route("[controller]/[action]")]
public class ComponentesActivoFijoApiController(IComponentesActivoFijoService service, ILogger<ComponentesActivoFijoApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetDatos([FromQuery] int idActFijo, [FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: GetDatos called with IdActFijo: {IdActFijo}, EmpresaId: {EmpresaId}, Ano: {Ano}",
            idActFijo, empresaId, ano);

        var datos = await service.GetDatosActivoFijoAsync(idActFijo, empresaId, ano);
        return Ok(datos);
    }

    [HttpGet]
    public async Task<IActionResult> GetDisponibles([FromQuery] int idGrupo, [FromQuery] int idActFijo, [FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: GetDisponibles called for IdGrupo: {IdGrupo}", idGrupo);

        var disponibles = await service.GetComponentesDisponiblesAsync(idGrupo, idActFijo, empresaId, ano);
        return Ok(disponibles);
    }

    [HttpPost]
    public async Task<IActionResult> Guardar([FromBody] GuardarComponenteDto dto)
    {
        logger.LogInformation("API: Guardar called for IdActFijo: {IdActFijo}", dto.IdActFijo);

        var idCompFicha = await service.GuardarComponenteAsync(dto);
        return Ok(new { message = "Componente guardado correctamente", idCompFicha });
    }

    [HttpDelete]
    public async Task<IActionResult> Eliminar(int idCompFicha, [FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: Eliminar called for IdCompFicha: {IdCompFicha}", idCompFicha);

        await service.EliminarComponenteAsync(idCompFicha, empresaId, ano);
        return Ok(new { message = "Componente eliminado correctamente" });
    }

    [HttpPost]
    public async Task<IActionResult> ActualizarSinDetComps([FromBody] SinDetCompsRequest request)
    {
        logger.LogInformation("API: ActualizarSinDetComps called for IdActFijo: {IdActFijo}", request.IdActFijo);

        await service.ActualizarSinDetCompsAsync(request.IdActFijo, request.EmpresaId, request.Ano, request.SinDetComps);
        return Ok(new { message = "Actualizado correctamente" });
    }

}

public class SinDetCompsRequest
{
    public int IdActFijo { get; set; }
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public bool SinDetComps { get; set; }
}
