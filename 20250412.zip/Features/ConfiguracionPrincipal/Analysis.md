# Legacy Analysis: Configuración Principal

## 📄 Información del Formulario VB6

**Archivo VB6:** `old/Contabilidad70/HyperContabilidad/FrmConfig.frm`
**Fecha Análisis:** 2025-01-01
**Analista:** IA
**Complejidad:** Media

### Propósito del Formulario

El formulario `FrmConfig` permite configurar parámetros generales del sistema de contabilidad. Incluye configuraciones de:
- Formato de números y fechas
- Tipos de comprobantes predeterminados
- Opciones de impresión
- Configuración de monedas
- Parámetros de libros contables
- Opciones de interfaz

## 🎨 CONTROLES UI IDENTIFICADOS

### CheckBoxes (Opciones de Configuración)
| Control VB6 | Propiedad | Propósito |
|-------------|-----------|-----------|
| chkVerCodigoCta | Config | Mostrar código de cuenta en listados |
| chkImprimirLogo | Config | Imprimir logo en reportes |
| chkUsarMonedaExtranjera | Config | Habilitar moneda extranjera |
| chkLibroOficial | Config | Modo libro oficial |

### ComboBoxes (Listas de Selección)
| Control VB6 | Fuente Datos | Propósito |
|-------------|--------------|-----------|
| cmbTipoCompDefault | TipoComprobante | Tipo de comprobante por defecto |
| cmbMonedaPrincipal | Monedas | Moneda principal del sistema |

### TextBoxes (Campos de Entrada)
| Control VB6 | Tipo | Propósito |
|-------------|------|-----------|
| txtDecimales | Numeric | Número de decimales para montos |
| txtEmpresaDefecto | Numeric | ID empresa por defecto al iniciar |

### Botones de Acción
| Botón VB6 | Caption | Acción | Mapeo .NET |
|-----------|---------|--------|------------|
| cmdGuardar | "Guardar" | Guarda configuración | SaveAsync() |
| cmdCancelar | "Cancelar" | Cierra sin guardar | N/A (navegación) |
| cmdRestaurar | "Restaurar" | Restaura valores por defecto | RestoreDefaultsAsync() |

## 🔧 FUNCIONES Y PROCEDIMIENTOS VB6

### Form_Load
```vb
' Carga configuración actual
Private Sub Form_Load()
    CargarConfiguracion()
    CargarCombos()
End Sub
```
**→ Implementar:** GetConfigAsync() + LoadComboDataAsync()

### cmdGuardar_Click
```vb
' Guarda configuración
Private Sub cmdGuardar_Click()
    If ValidarDatos() Then
        GuardarConfiguracion()
        MsgBox "Configuración guardada exitosamente"
        Unload Me
    End If
End Sub
```
**→ Implementar:** SaveAsync()

## 💾 ACCESO A DATOS VB6

### Tabla Param (Parámetros Globales)
```vb
Q1 = "SELECT * FROM Param WHERE Tipo = 'CONFIG'"
```

### Tabla ParamEmpresa (Parámetros por Empresa)
```vb
Q1 = "SELECT * FROM ParamEmpresa WHERE IdEmpresa = " & gIdEmpresa
```

**Mapeo Entity Framework:**
```csharp
await _context.Param
    .Where(p => p.Tipo == "CONFIG")
    .ToListAsync();

await _context.ParamEmpresa
    .Where(p => p.IdEmpresa == empresaId)
    .ToListAsync();
```

## ✅ VALIDACIONES Y REGLAS DE NEGOCIO

| Campo | Regla | Mensaje Error VB6 |
|-------|-------|-------------------|
| Decimales | Entre 0 y 4 | "Decimales debe estar entre 0 y 4" |
| Empresa Defecto | Debe existir | "Empresa no existe" |

## 🎯 MAPEO FINAL: MÉTODOS .NET DETERMINADOS

### Interface del Service
```csharp
public interface IConfiguracionPrincipalService
{
    Task<ConfiguracionDto> GetConfigAsync(int? empresaId = null);
    Task SaveConfigAsync(ConfiguracionDto config);
    Task RestoreDefaultsAsync(int? empresaId = null);
    Task<IEnumerable<ComboItemDto>> GetTiposComprobanteAsync();
    Task<IEnumerable<ComboItemDto>> GetMonedasAsync();
}
```

### Endpoints API
```
GET  /api/ConfiguracionPrincipal?empresaId={id}  - Obtiene configuración
POST /api/ConfiguracionPrincipal                 - Guarda configuración
POST /api/ConfiguracionPrincipal/restaurar       - Restaura defaults
GET  /api/ConfiguracionPrincipal/tipos-comprobante - Lista tipos
GET  /api/ConfiguracionPrincipal/monedas          - Lista monedas
```

## 📋 CASOS DE USO PRINCIPALES

### CU1: Cargar Configuración
1. Usuario abre formulario
2. Sistema carga configuración actual
3. Sistema carga listas desplegables
4. Sistema muestra datos

### CU2: Guardar Configuración
1. Usuario modifica valores
2. Usuario hace click en "Guardar"
3. Sistema valida datos
4. Sistema guarda en BD
5. Sistema muestra confirmación

### CU3: Restaurar Valores por Defecto
1. Usuario hace click en "Restaurar"
2. Sistema confirma acción
3. Sistema restaura valores por defecto
4. Sistema recarga formulario

## 🔍 NOTAS DE MIGRACIÓN

1. **Parámetros Sistema vs Empresa:**
   - Param: Configuración global del sistema
   - ParamEmpresa: Configuración específica por empresa

2. **Estructura de Parámetros:**
   - Tipo: Categoría del parámetro (CONFIG, IMPR, etc.)
   - Codigo: ID del parámetro
   - Valor: Valor del parámetro

3. **Vista Simplificada:**
   - No migrar todas las configuraciones de una vez
   - Enfocarse en las más usadas
   - Permitir expansión futura

## ⚠️ COMPLEJIDAD ESTIMADA

- **Media**: Gestión de parámetros con validación
- **Tiempo estimado**: 4-6 horas de desarrollo + testing

