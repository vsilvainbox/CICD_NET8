using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.ConfiguracionPrincipal;

public class ConfiguracionPrincipalController(IHttpClientFactory httpClientFactory, ILogger<ConfiguracionPrincipalController> logger, LinkGenerator linkGenerator) : Controller
{
    public Task<IActionResult> Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a la Configuración Principal";
            TempData["SwalType"] = "warning";
            return Task.FromResult<IActionResult>(RedirectToAction("Index", "SeleccionarEmpresa"));
        }

        logger.LogInformation("Loading ConfiguracionPrincipal Index for empresaId: {EmpresaId}, ano: {Ano}", SessionHelper.EmpresaId, SessionHelper.Ano);

        return Task.FromResult<IActionResult>(View());
    }

    /// <summary>
    /// Proxy: GET /api/ConfiguracionPrincipal
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetConfiguracion(int? empresaId, short? ano)
    {
        logger.LogInformation("Proxy GetConfiguracion called for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionPrincipalApiController>(
            HttpContext,
            nameof(ConfiguracionPrincipalApiController.GetConfiguracion),
            new { empresaId, ano });

        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Proxy: GET /api/ConfiguracionPrincipalApi/tipos-comprobante
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetTiposComprobante()
    {
        logger.LogInformation("Proxy GetTiposComprobante called");

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionPrincipalApiController>(
            HttpContext,
            nameof(ConfiguracionPrincipalApiController.GetTiposComprobante));

        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Proxy: GET /api/ConfiguracionPrincipalApi/monedas
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetMonedas()
    {
        logger.LogInformation("Proxy GetMonedas called");

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionPrincipalApiController>(
            HttpContext,
            nameof(ConfiguracionPrincipalApiController.GetMonedas));

        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Guarda la configuración principal
    /// Soporta tanto form nativo (PRG pattern) como AJAX
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> SaveConfiguracion(GuardarConfiguracionDto dto)
    {
        logger.LogInformation("SaveConfiguracion called");

        // ✅ Validación del lado del servidor con Data Annotations
        if (!ModelState.IsValid)
        {
            logger.LogWarning("Modelo inválido para guardar configuración");
            if (Request.Headers["Accept"].ToString().Contains("application/json"))
            {
                return BadRequest(new { swalType = "warning", swalTitle = "Atención", errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).ToArray() });
            }
            return View("Index", dto.Configuracion);
        }

        // Asignar valores de sesión si no vienen en el DTO
        dto.EmpresaId ??= SessionHelper.EmpresaId;
        dto.Ano ??= SessionHelper.Ano;

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionPrincipalApiController>(
            HttpContext,
            nameof(ConfiguracionPrincipalApiController.SaveConfiguracion));

        var (statusCode, content) = await client.ProxyRequestAsync(url!, JsonSerializer.SerializeToElement(dto), HttpMethod.Post);
        
        if (statusCode >= 200 && statusCode < 300)
        {
            logger.LogInformation("Configuración guardada exitosamente");
            
            if (Request.Headers["Accept"].ToString().Contains("application/json"))
            {
                return new ContentResult { Content = content, ContentType = "application/json", StatusCode = statusCode };
            }
            
            // ✅ PRG Pattern
            TempData["SwalSuccess"] = "Configuración guardada exitosamente";
            return RedirectToAction("Index");
        }
        else
        {
            logger.LogWarning("Error al guardar configuración: {StatusCode}", statusCode);
            
            if (Request.Headers["Accept"].ToString().Contains("application/json"))
            {
                return new ContentResult { Content = content, ContentType = "application/json", StatusCode = statusCode };
            }
            
            ModelState.AddModelError("", "Error al guardar la configuración");
            return View("Index", dto.Configuracion);
        }
    }

    /// <summary>
    /// Proxy: POST /api/ConfiguracionPrincipal (para compatibilidad con llamadas AJAX legacy)
    /// </summary>
    [HttpPost("ConfiguracionPrincipal/SaveConfiguracionJson")]
    public async Task<IActionResult> SaveConfiguracionJson([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy SaveConfiguracionJson called");

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionPrincipalApiController>(
            HttpContext,
            nameof(ConfiguracionPrincipalApiController.SaveConfiguracion));

        var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
        return new ContentResult
        {
            Content = content,
            ContentType = "application/json",
            StatusCode = statusCode
        };
    }

    /// <summary>
    /// Proxy: POST /api/ConfiguracionPrincipalApi/restaurar
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> RestaurarDefectos(int? empresaId, short? ano)
    {
        logger.LogInformation("Proxy RestaurarDefectos called for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionPrincipalApiController>(
            HttpContext,
            nameof(ConfiguracionPrincipalApiController.RestaurarDefectos),
            new { empresaId, ano });

        var (statusCode, content) = await client.ProxyRequestAsync(url!, null, HttpMethod.Post);
        return new ContentResult
        {
            Content = content,
            ContentType = "application/json",
            StatusCode = statusCode
        };
    }
}