using Microsoft.AspNetCore.Mvc;

namespace App.Features.ConfiguracionPrincipal;

[ApiController]
[Route("[controller]/[action]")]
public class ConfiguracionPrincipalApiController(IConfiguracionPrincipalService service, ILogger<ConfiguracionPrincipalApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<ConfiguracionDto>> GetConfiguracion([FromQuery] int? empresaId = null, [FromQuery] short? ano = null)
    {
        logger.LogInformation("API: GetConfiguracion called for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var config = await service.GetConfigAsync(empresaId, ano);
            return Ok(config);
        }
    }

    [HttpPost]
    public async Task<IActionResult> SaveConfiguracion([FromBody] GuardarConfiguracionDto request)
    {
        logger.LogInformation("API: SaveConfiguracion called for empresaId: {EmpresaId}", request.EmpresaId);

        {
            await service.SaveConfigAsync(request);
            return Ok(new { message = "Configuración guardada exitosamente" });
        }
    }

    [HttpPost]
    public async Task<IActionResult> RestaurarDefectos([FromQuery] int? empresaId = null, [FromQuery] short? ano = null)
    {
        logger.LogInformation("API: RestaurarDefectos called for empresaId: {EmpresaId}", empresaId);

        {
            await service.RestoreDefaultsAsync(empresaId, ano);
            return Ok(new { message = "Valores por defecto restaurados exitosamente" });
        }
    }

    [HttpGet]
    public async Task<ActionResult> GetTiposComprobante()
    {
        logger.LogInformation("API: GetTiposComprobante called");

        {
            var tipos = await service.GetTiposComprobanteAsync();
            return Ok(tipos);
        }
    }

    [HttpGet]
    public async Task<ActionResult> GetMonedas()
    {
        logger.LogInformation("API: GetMonedas called");

        {
            var monedas = await service.GetMonedasAsync();
            return Ok(monedas);
        }
    }


}