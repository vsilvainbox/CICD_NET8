using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Text.Json;
using App.Extensions;

namespace App.Features.ConfiguracionImpresionCheques;

/// <summary>
/// Controller MVC para gestionar configuración de impresión de cheques
/// </summary>
[Authorize]

public class ConfiguracionImpresionChequesController(
    IHttpClientFactory httpClientFactory,
    ILogger<ConfiguracionImpresionChequesController> logger, LinkGenerator linkGenerator) : Controller
{
    /// <summary>
    /// Vista principal de configuración de impresión de cheques
    /// </summary>
    /// <returns>Vista Index</returns>
    public Task<IActionResult> Index()
    {
        {
            logger.LogInformation("Accediendo a ConfiguracionImpresionCheques/Index");

            return Task.FromResult<IActionResult>(View());
        }
    }

    /// <summary>
    /// Proxy para obtener tipo de papel actual
    /// GET /ConfiguracionImpresionCheques/GetTipoPapelActual
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetTipoPapelActual()
    {
        logger.LogInformation("ConfiguracionImpresionCheques: GetTipoPapelActual proxy called");

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionImpresionChequesApiController>(
            HttpContext,
            nameof(ConfiguracionImpresionChequesApiController.GetTipoPapelActual));

        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Proxy para obtener configuración por tipo de papel
    /// GET /ConfiguracionImpresionCheques/GetConfiguracion
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetConfiguracion(int tipoPapel)
    {
        logger.LogInformation("ConfiguracionImpresionCheques: GetConfiguracion proxy called for tipoPapel={TipoPapel}", tipoPapel);

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionImpresionChequesApiController>(
            HttpContext,
            nameof(ConfiguracionImpresionChequesApiController.GetConfiguracion),
            new { tipoPapel });

        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Proxy para guardar configuración
    /// POST /ConfiguracionImpresionCheques/Save
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Save([FromBody] JsonElement request)
    {
        logger.LogInformation("ConfiguracionImpresionCheques: Save proxy called");

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionImpresionChequesApiController>(
            HttpContext,
            nameof(ConfiguracionImpresionChequesApiController.SaveConfiguracion));

        var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }
}
