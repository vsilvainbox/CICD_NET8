using System.ComponentModel.DataAnnotations;

namespace App.Features.ConfiguracionImpresionCheques;

/// <summary>
/// DTO para consulta de configuración de impresión de cheques
/// </summary>
public class ConfiguracionChequesDto
{
    /// <summary>
    /// Tipo de papel: 1=Hoja Carta, 2=Papel Continuo
    /// </summary>
    public int TipoPapel { get; set; }

    /// <summary>
    /// Distancia desde borde superior (en twips)
    /// </summary>
    public int? BordeSuperior { get; set; }

    /// <summary>
    /// Distancia desde borde izquierdo (en twips)
    /// </summary>
    public int? BordeIzquierdo { get; set; }

    /// <summary>
    /// Bajar valor en dígitos - movimiento vertical (en twips)
    /// </summary>
    public int? BajarValorDigitos { get; set; }

    /// <summary>
    /// Mover valor en dígitos - movimiento horizontal (en twips)
    /// </summary>
    public int? MoverValorDigitos { get; set; }

    /// <summary>
    /// Bajar fecha - movimiento vertical (en twips)
    /// </summary>
    public int? BajarFecha { get; set; }

    /// <summary>
    /// Mover fecha - movimiento horizontal (en twips)
    /// </summary>
    public int? MoverFecha { get; set; }

    /// <summary>
    /// Omitir primeros 2 dígitos del año (20XX → XX)
    /// </summary>
    public bool Omitir2DigitosAno { get; set; }

    /// <summary>
    /// Mover año - movimiento horizontal (en twips)
    /// </summary>
    public int? MoverAno { get; set; }

    /// <summary>
    /// Bajar "Orden De" - movimiento vertical (en twips)
    /// </summary>
    public int? BajarOrdenDe { get; set; }

    /// <summary>
    /// Mover "Orden De" - movimiento horizontal (en twips)
    /// </summary>
    public int? MoverOrdenDe { get; set; }

    /// <summary>
    /// Borrar texto "a la Orden De" en cheque
    /// </summary>
    public bool BorrarALaOrden { get; set; }

    /// <summary>
    /// Borrar texto "al Portador" en cheque
    /// </summary>
    public bool BorrarAlPortador { get; set; }
}

/// <summary>
/// DTO para actualización de configuración de cheques
/// </summary>
public class ConfiguracionChequesUpdateDto
{
    /// <summary>
    /// Tipo de papel: 1=Hoja Carta, 2=Papel Continuo
    /// </summary>
    [Required(ErrorMessage = "El tipo de papel es obligatorio.")]
    [Range(1, 2, ErrorMessage = "El tipo de papel debe ser 1 (Hoja Carta) o 2 (Papel Continuo).")]
    public int TipoPapel { get; set; }

    /// <summary>
    /// Distancia desde borde superior (en twips)
    /// </summary>
    [Range(-50000, 50000, ErrorMessage = "El borde superior debe estar entre -50000 y 50000 twips.")]
    public int? BordeSuperior { get; set; }

    /// <summary>
    /// Distancia desde borde izquierdo (en twips)
    /// </summary>
    [Range(-50000, 50000, ErrorMessage = "El borde izquierdo debe estar entre -50000 y 50000 twips.")]
    public int? BordeIzquierdo { get; set; }

    /// <summary>
    /// Bajar valor en dígitos - movimiento vertical (en twips)
    /// </summary>
    [Range(-50000, 50000, ErrorMessage = "El valor debe estar entre -50000 y 50000 twips.")]
    public int? BajarValorDigitos { get; set; }

    /// <summary>
    /// Mover valor en dígitos - movimiento horizontal (en twips)
    /// </summary>
    [Range(-50000, 50000, ErrorMessage = "El valor debe estar entre -50000 y 50000 twips.")]
    public int? MoverValorDigitos { get; set; }

    /// <summary>
    /// Bajar fecha - movimiento vertical (en twips)
    /// </summary>
    [Range(-50000, 50000, ErrorMessage = "El valor debe estar entre -50000 y 50000 twips.")]
    public int? BajarFecha { get; set; }

    /// <summary>
    /// Mover fecha - movimiento horizontal (en twips)
    /// </summary>
    [Range(-50000, 50000, ErrorMessage = "El valor debe estar entre -50000 y 50000 twips.")]
    public int? MoverFecha { get; set; }

    /// <summary>
    /// Omitir primeros 2 dígitos del año (20XX → XX)
    /// </summary>
    public bool Omitir2DigitosAno { get; set; }

    /// <summary>
    /// Mover año - movimiento horizontal (en twips)
    /// </summary>
    [Range(-50000, 50000, ErrorMessage = "El valor debe estar entre -50000 y 50000 twips.")]
    public int? MoverAno { get; set; }

    /// <summary>
    /// Bajar "Orden De" - movimiento vertical (en twips)
    /// </summary>
    [Range(-50000, 50000, ErrorMessage = "El valor debe estar entre -50000 y 50000 twips.")]
    public int? BajarOrdenDe { get; set; }

    /// <summary>
    /// Mover "Orden De" - movimiento horizontal (en twips)
    /// </summary>
    [Range(-50000, 50000, ErrorMessage = "El valor debe estar entre -50000 y 50000 twips.")]
    public int? MoverOrdenDe { get; set; }

    /// <summary>
    /// Borrar texto "a la Orden De" en cheque
    /// </summary>
    public bool BorrarALaOrden { get; set; }

    /// <summary>
    /// Borrar texto "al Portador" en cheque
    /// </summary>
    public bool BorrarAlPortador { get; set; }
}

/// <summary>
/// Códigos para parámetros de cheques en tabla Param
/// </summary>
public static class ConfiguracionChequesCodigosParam
{
    // Código general
    public const int TipoPapel = 1;

    // Códigos para Hoja Carta (10-50)
    public const int Carta_BordeSuperior = 10;
    public const int Carta_BordeIzquierdo = 11;
    public const int Carta_BajarValorDigitos = 12;
    public const int Carta_MoverValorDigitos = 13;
    public const int Carta_BajarFecha = 14;
    public const int Carta_MoverFecha = 15;
    public const int Carta_Omitir2DigitosAno = 16;
    public const int Carta_MoverAno = 17;
    public const int Carta_BajarOrdenDe = 18;
    public const int Carta_MoverOrdenDe = 19;
    public const int Carta_BorrarALaOrden = 20;
    public const int Carta_BorrarAlPortador = 21;

    // Códigos para Papel Continuo (110-150)
    public const int Continuo_BordeSuperior = 110;
    public const int Continuo_BordeIzquierdo = 111;
    public const int Continuo_BajarValorDigitos = 112;
    public const int Continuo_MoverValorDigitos = 113;
    public const int Continuo_BajarFecha = 114;
    public const int Continuo_MoverFecha = 115;
    public const int Continuo_Omitir2DigitosAno = 116;
    public const int Continuo_MoverAno = 117;
    public const int Continuo_BajarOrdenDe = 118;
    public const int Continuo_MoverOrdenDe = 119;
    public const int Continuo_BorrarALaOrden = 120;
    public const int Continuo_BorrarAlPortador = 121;
}
