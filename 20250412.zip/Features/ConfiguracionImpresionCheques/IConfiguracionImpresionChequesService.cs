namespace App.Features.ConfiguracionImpresionCheques;

/// <summary>
/// Servicio para gestionar la configuración de impresión de cheques
/// </summary>
public interface IConfiguracionImpresionChequesService
{
    /// <summary>
    /// Obtiene la configuración de cheques para un tipo de papel
    /// </summary>
    /// <param name="tipoPapel">1=Hoja Carta, 2=Papel Continuo</param>
    /// <returns>Configuración de cheques</returns>
    Task<ConfiguracionChequesDto> GetAsync(int tipoPapel);

    /// <summary>
    /// Guarda la configuración de cheques
    /// </summary>
    /// <param name="dto">Datos de configuración a guardar</param>
    /// <returns>True si se guardó correctamente</returns>
    Task<bool> SaveAsync(ConfiguracionChequesUpdateDto dto);

    /// <summary>
    /// Obtiene el tipo de papel actual configurado
    /// </summary>
    /// <returns>1=Hoja Carta, 2=Papel Continuo</returns>
    Task<int> GetTipoPapelActualAsync();

    /// <summary>
    /// Establece el tipo de papel actual
    /// </summary>
    /// <param name="tipoPapel">1=Hoja Carta, 2=Papel Continuo</param>
    /// <returns>True si se guardó correctamente</returns>
    Task<bool> SetTipoPapelActualAsync(int tipoPapel);
}
