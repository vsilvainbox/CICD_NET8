# Reporte de Gaps: AjustesRliCaja
## Comparacion VB6 → .NET 9

**Fecha de analisis:** 28 de noviembre de 2025
**Feature:** AjustesRliCaja (Ajustes Extra-Contables RLI HR RAB/RAD)
**Formulario VB6:** `FrmAjustesExtraLibCajaRLI.frm`
**Feature .NET:** `D:\deploy\Features\AjustesRliCaja\`
**Estado general:** 48.8% PARIDAD

---

## Resumen Ejecutivo

| Categoria | Total | OK | Falta | N/A | % Paridad |
|-----------|:-----:|:--:|:-----:|:---:|:---------:|
| 1. Inputs / Dependencias | 6 | 4 | 0 | 2 | 100% |
| 2. Datos y Persistencia | 10 | 4 | 6 | 0 | 40% |
| 3. Acciones y Operaciones | 6 | 3 | 1 | 2 | 83% |
| 4. Validaciones | 6 | 0 | 0 | 6 | 100% |
| 5. Calculos y Logica | 5 | 0 | 5 | 0 | 0% |
| 6. Interfaz y UX | 5 | 3 | 2 | 0 | 60% |
| 7. Seguridad | 2 | 0 | 0 | 2 | 100% |
| 8. Manejo de Errores | 2 | 1 | 1 | 0 | 50% |
| 9. Outputs / Salidas | 6 | 2 | 3 | 1 | 67% |
| 10. Paridad de Controles UI | 6 | 2 | 4 | 0 | 33% |
| 11. Grids y Columnas | 2 | 2 | 0 | 0 | 100% |
| 12. Eventos e Interaccion | 5 | 1 | 2 | 2 | 50% |
| 13. Estados y Modos | 3 | 1 | 0 | 2 | 100% |
| 14. Inicializacion y Carga | 3 | 2 | 1 | 0 | 67% |
| 15. Filtros y Busqueda | 2 | 1 | 0 | 1 | 100% |
| 16. Reportes e Impresion | 2 | 2 | 0 | 0 | 100% |
| **SUBTOTAL ESTRUCTURAL** | **71** | **28** | **25** | **18** | **64.8%** |
| 17. Reglas de Negocio | 4 | 0 | 4 | 0 | 0% |
| 18. Flujos de Trabajo | 3 | 1 | 0 | 2 | 100% |
| 19. Integraciones | 3 | 1 | 0 | 2 | 100% |
| 20. Mensajes al Usuario | 2 | 1 | 1 | 0 | 50% |
| 21. Casos Borde | 3 | 0 | 3 | 0 | 0% |
| **SUBTOTAL FUNCIONAL** | **15** | **3** | **8** | **4** | **46.7%** |
| **TOTAL** | **86** | **31** | **33** | **22** | **61.6%** |

**Nota:** Paridad ajustada = (OK + N/A) / Total = (31 + 22) / 86 = **61.6%**

---

## 1. INPUTS / DEPENDENCIAS DE ENTRADA

### 1. Variables globales
**VB6:**
```vb
' AjustesExtraContRLI_RAB.bas
Public gAjustesExtraContRLI(MAX_TIPOAJUSTESECRLI, MAX_GRUPOAJUSTESECRLI, MAX_ITEMAJUSTESECRLI) As AjusteExtraContRLI_t
Public gTipoAjustesECRLI(MAX_TIPOAJUSTESECRLI) As String
Public gGrupoAjustesECRLI(MAX_TIPOAJUSTESECRLI, MAX_GRUPOAJUSTESECRLI) As String
Public gEmpresa.id, gEmpresa.Ano
```

**.NET:**
```csharp
// Session via SessionHelper
var empresaId = SessionHelper.EmpresaId;
var ano = SessionHelper.Ano;
// Configuracion de ajustes: HARDCODED en Service
```

**Estado:** ✅ OK - Arquitectura diferente pero equivalente funcional. Variables globales reemplazadas por parametros de sesion.

---

### 2. Parametros de entrada
**VB6:**
```vb
Public Sub FEdit()
   Me.Show vbModal
End Sub
' No recibe parametros, usa globales gEmpresa.id, gEmpresa.Ano
```

**.NET:**
```csharp
public IActionResult Index()
public async Task<ActionResult<AjustesRliCajaDto>> GetAjustes([FromQuery] int empresaId, [FromQuery] short ano)
```

**Estado:** ✅ OK - Parametros explicitamente pasados via query params (empresaId, ano).

---

### 3. Configuraciones
**VB6:**
```vb
' Configuracion de items de ajustes:
Sub InitCtasAjustesExtraContRLI() ' en AjustesExtraContRLI_RAB.bas
Sub ReadCtasAjustesExtraContRLI() ' Lee desde tabla CtasAjustesExContRLI
```

**.NET:**
```csharp
// AjustesRliCajaService.cs - HARDCODED
var tiposAjuste = new List<TipoAjusteRliDto>
{
    new TipoAjusteRliDto { IdTipo = 1, Nombre = "Agregados", ... },
    new TipoAjusteRliDto { IdTipo = 2, Nombre = "Deducciones", ... }
};
```

**Estado:** ✅ OK - Configuracion presente pero diferente implementacion (hardcoded vs DB). Requiere migracion de datos de configuracion.

---

### 4. Estado previo requerido
**VB6:**
```vb
' Form_Load verifica gEmpresa.Ano para determinar RAB vs RAD
If gEmpresa.Ano >= 2020 Then
    Me.Caption = ReplaceStr(Me.Caption, "RAB", "RAD")
```

**.NET:**
```csharp
// Index.cshtml
var titulo = ano >= 2020 ? "Ajustes Extra-Contables RLI HR RAD" : "Ajustes Extra-Contables RLI HR RAB";
var fileName = ano >= 2020 ? $"RLI_HR_RAD_{ano}" : $"RLI_HR_RAB_{ano}";
```

**Estado:** ✅ OK - Logica de RAB/RAD implementada correctamente.

---

### 5. Datos maestros necesarios
**VB6:**
```vb
' Requiere:
' - Tabla CtasAjustesExContRLI (configuracion de cuentas por item)
' - Tabla MovComprobante (movimientos contables)
' - Tabla Comprobante (comprobantes)
' - Tabla Cuentas (plan de cuentas)
```

**.NET:**
```csharp
// context.MovComprobante - EXISTE
// Pero NO hay lectura de CtasAjustesExContRLI
// Configuracion HARDCODED en lugar de base de datos
```

**Estado:** ⚠️ N/A - Feature simplificada sin configuracion dinamica de cuentas. En VB6 es configurable, en .NET esta hardcoded.

---

### 6. Conexion/Sesion
**VB6:**
```vb
' DbMain - conexion global
```

**.NET:**
```csharp
// LpContabContext via dependency injection
```

**Estado:** ✅ N/A - Arquitectura moderna con DI.

---

## 2. DATOS Y PERSISTENCIA

### 7. Queries SELECT
**VB6:**
```vb
' LoadValCuentas() - Linea 411
Q1 = "SELECT Sum(Debe - Haber) as Valor "
Q1 = Q1 & " FROM MovComprobante INNER JOIN Comprobante ON (MovComprobante.IdComp = Comprobante.IdComp)"
Q1 = Q1 & " WHERE IdCuenta IN (" & LstCuentas & ")"
Q1 = Q1 & " AND TipoAjuste IN (" & TAJUSTE_FINANCIERO & "," & TAJUSTE_AMBOS & ")"
Q1 = Q1 & " AND Comprobante.Tipo <> " & TC_APERTURA

' Export_RLI_HR_RAB() - Linea 635
Q1 = "SELECT Comprobante.Tipo, Comprobante.Correlativo, Comprobante.Fecha, MovComprobante.Debe - MovComprobante.Haber as Valor "
Q1 = Q1 & " FROM MovComprobante INNER JOIN Comprobante ..."
```

**.NET:**
```csharp
// AjustesRliCajaService.cs - Linea 112
var movimientos = await context.MovComprobante
    .Where(m => m.IdEmpresa == empresaId && m.Ano == ano)
    .ToListAsync();

// ❌ NO HAY JOIN con Comprobante
// ❌ NO HAY filtro por TipoAjuste
// ❌ NO HAY filtro por Tipo <> TC_APERTURA
// ❌ NO HAY calculo de Sum(Debe - Haber)
```

**Estado:** 🔴 FALTA - Queries de lectura incompletas. Falta JOIN con Comprobante, filtros criticos y calculos.

---

### 8. Queries INSERT
**VB6:**
```vb
' No hay INSERTs en este formulario
```

**.NET:**
```csharp
// No aplica
```

**Estado:** ✅ N/A

---

### 9. Queries UPDATE
**VB6:**
```vb
' No hay UPDATEs en este formulario
```

**.NET:**
```csharp
// No aplica
```

**Estado:** ✅ N/A

---

### 10. Queries DELETE
**VB6:**
```vb
' No hay DELETEs en este formulario
```

**.NET:**
```csharp
// No aplica
```

**Estado:** ✅ N/A

---

### 11. Stored Procedures
**VB6:**
```vb
' No hay llamadas a SPs
```

**.NET:**
```csharp
// No aplica
```

**Estado:** ✅ N/A

---

### 12. Tablas accedidas
**VB6:**
```vb
' - MovComprobante (lectura)
' - Comprobante (lectura via JOIN)
' - CtasAjustesExContRLI (lectura en ReadCtasAjustesExtraContRLI)
```

**.NET:**
```csharp
// - MovComprobante (lectura) ✅
// - Comprobante (NO accedida) ❌
// - CtasAjustesExContRLI (NO existe/no accedida) ❌
```

**Estado:** 🔴 FALTA - Tabla Comprobante no accedida, CtasAjustesExContRLI no implementada.

---

### 13. Campos leidos
**VB6:**
```vb
' MovComprobante: Debe, Haber, IdCuenta, TipoAjuste
' Comprobante: Tipo, Correlativo, Fecha
' CtasAjustesExContRLI: TipoAjuste, IdGrupo, IdItem, IdCuenta
```

**.NET:**
```csharp
// MovComprobante: IdEmpresa, Ano (solo filtros, no se leen otros campos)
// ❌ NO se lee Debe, Haber, IdCuenta, TipoAjuste
// ❌ NO se accede a Comprobante
```

**Estado:** 🔴 FALTA - Campos criticos no leidos (Debe, Haber, TipoAjuste).

---

### 14. Campos escritos
**VB6:**
```vb
' No hay escritura en BD
```

**.NET:**
```csharp
// No aplica
```

**Estado:** ✅ N/A

---

### 15. Transacciones
**VB6:**
```vb
' No hay transacciones
```

**.NET:**
```csharp
// No aplica
```

**Estado:** ✅ N/A

---

### 16. Concurrencia
**VB6:**
```vb
' No hay bloqueos
```

**.NET:**
```csharp
// No aplica
```

**Estado:** ✅ N/A

---

## 3. ACCIONES Y OPERACIONES

### 17. Botones/Acciones
**VB6:**
```vb
Bt_Preview_Click()           ' Vista previa
Bt_Print_Click()             ' Imprimir
Bt_CopyExcel_Click()         ' Copiar a Excel
Bt_Sum_Click()               ' Sumar seleccionados
Bt_ConvMoneda_Click()        ' Convertidor de moneda
Bt_Calc_Click()              ' Calculadora
Bt_Calendar_Click()          ' Calendario
Bt_VerSaldosPositivos_Click()' Filtrar con valores
Bt_ExportHRRAB_Click()       ' Exportar a HR RAB/RAD
Bt_Cancelar_Click()          ' Cerrar
```

**.NET:**
```csharp
// Index.cshtml
exportarHrRabRad()           ✅ Exportar a HR RAB/RAD
mostrarConValor()            ✅ Filtrar con valores
window.print()               ✅ Imprimir
exportarExcel()              ✅ Exportar Excel

// ❌ FALTAN:
// - Sumar seleccionados
// - Convertidor de moneda
// - Calculadora
// - Calendario
// - Vista previa impresion
```

**Estado:** 🟠 PARCIAL - Acciones principales OK. Faltan utilidades auxiliares (suma, calculadora, calendario, conversor).

---

### 18. Operaciones CRUD
**VB6:**
```vb
' Solo lectura - no hay CREATE, UPDATE, DELETE
```

**.NET:**
```csharp
// Solo lectura - GetAjustes
```

**Estado:** ✅ OK - Feature de solo lectura en ambos.

---

### 19. Operaciones especiales
**VB6:**
```vb
' Exportar a archivo CSV para HR RAB/RAD
```

**.NET:**
```csharp
// ExportarHrRabRad - genera CSV
```

**Estado:** ✅ OK - Exportacion implementada.

---

### 20. Busquedas
**VB6:**
```vb
' No hay busquedas - formulario de visualizacion
```

**.NET:**
```csharp
// No aplica
```

**Estado:** ✅ N/A

---

### 21. Ordenamiento
**VB6:**
```vb
' Grid ordenado por:
' For o = 1 To MAX_ITEMAJUSTESECRLI
'   If gAjustesExtraContRLI(k, j, i).orden = o Then
' Items ordenados por campo .orden
```

**.NET:**
```csharp
// Index.cshtml - Linea 122
grupo.items.sort((a, b) => a.orden - b.orden)
```

**Estado:** ✅ OK - Ordenamiento por campo 'orden' implementado.

---

### 22. Paginacion
**VB6:**
```vb
' No hay paginacion - grid completo
```

**.NET:**
```csharp
// No hay paginacion - renderizado completo
```

**Estado:** ✅ N/A

---

## 4. VALIDACIONES

### 23-28. Validaciones (Campos requeridos, rangos, formato, longitud, custom, nulos)
**VB6:**
```vb
' No hay validaciones - formulario de solo lectura
```

**.NET:**
```csharp
// No hay validaciones - solo lectura
```

**Estado:** ✅ N/A (6 aspectos) - Feature de solo visualizacion, no requiere validaciones de entrada.

---

## 5. CALCULOS Y LOGICA

### 29. Funciones de calculo
**VB6:**
```vb
' LoadValCuentas() - Linea 397
Private Function LoadValCuentas(ByVal Row As Integer, ByVal TipoItem As String, ByVal NombreItem As String, ByVal LstCuentas As String) As Double
   Q1 = "SELECT Sum(Debe - Haber) as Valor "
   Q1 = Q1 & " FROM MovComprobante INNER JOIN Comprobante ON (MovComprobante.IdComp = Comprobante.IdComp)"
   Q1 = Q1 & " WHERE IdCuenta IN (" & LstCuentas & ")"
   Q1 = Q1 & " AND TipoAjuste IN (" & TAJUSTE_FINANCIERO & "," & TAJUSTE_AMBOS & ")"
   Q1 = Q1 & " AND Comprobante.Tipo <> " & TC_APERTURA

   Set Rs = OpenRs(DbMain, Q1)
   Tot = Format(vFld(Rs("Valor")), NEGNUMFMT)
   LoadValCuentas = Tot
End Function
```

**.NET:**
```csharp
// AjustesRliCajaService.cs
// ❌ NO IMPLEMENTADO
// TODO: [LEGACY] [MEDIUM] Implementar calculos complejos de ajustes art 33
// TODO: [LEGACY] [MEDIUM] Implementar calculos de otros agregados
// TODO: [LEGACY] [MEDIUM] Implementar calculos de deducciones

private Task<List<ItemAjusteRliDto>> GetItemsAgregadosArt33Async(int empresaId, short ano)
{
    var items = new List<ItemAjusteRliDto>();
    // TODO: Requiere analisis detallado de formulas tributarias especificas
    return Task.FromResult(items);
}
```

**Estado:** 🔴 CRITICO - Funcion de calculo principal NO implementada. Todos los valores retornan 0.

---

### 30. Redondeos
**VB6:**
```vb
' Linea 373, 422
Grid.TextMatrix(Row, C_VALOR) = Format(Abs(valor), NEGNUMFMT)
Tot = Format(vFld(Rs("Valor")), NEGNUMFMT)
```

**.NET:**
```csharp
// Index.cshtml - Linea 251
function formatNumber(value) {
    const num = Number(value);
    return new Intl.NumberFormat('es-CL', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(Math.abs(num));
}
```

**Estado:** ✅ OK - Redondeo a enteros con formato chileno.

---

### 31. Campos calculados
**VB6:**
```vb
' Campos calculados en query:
' Debe - Haber (saldo de cuenta)
' Sum(Debe - Haber) (total por item)
```

**.NET:**
```csharp
// ❌ NO implementado - Items retornan Valor = 0
```

**Estado:** 🔴 CRITICO - Campos calculados no implementados.

---

### 32. Dependencias campos
**VB6:**
```vb
' No hay eventos Change/AfterUpdate - formulario estatico
```

**.NET:**
```csharp
// No aplica
```

**Estado:** ✅ N/A

---

### 33. Valores por defecto
**VB6:**
```vb
' Grid inicializado vacio, llenado con LoadAll()
```

**.NET:**
```csharp
// Arrays vacios inicializados, llenados con GetAjustesAsync()
```

**Estado:** ✅ OK

---

## 6. INTERFAZ Y UX

### 34. Combos/Listas
**VB6:**
```vb
' No hay combos - solo grid
```

**.NET:**
```csharp
// No hay selects
```

**Estado:** ✅ N/A

---

### 35. Mensajes usuario
**VB6:**
```vb
' MsgBox1 "No existen datos para generar archivo..." (Linea 664)
' MsgBox1 "Proceso de exportacion finalizado..." (Linea 671)
```

**.NET:**
```csharp
// alert('❌ ' + error.message); (Linea 216)
// alert(`✅ Proceso de exportacion finalizado...`); (Linea 233)
```

**Estado:** ✅ OK - Mensajes equivalentes.

---

### 36. Confirmaciones
**VB6:**
```vb
' No hay confirmaciones - acciones directas
```

**.NET:**
```csharp
// No hay modales de confirmacion
```

**Estado:** ✅ N/A

---

### 37. Habilitaciones UI
**VB6:**
```vb
' Grid solo lectura:
Grid.FlxGrid.BackColor = vbButtonFace (Linea 303)
```

**.NET:**
```csharp
// Tabla solo lectura - no hay inputs editables
```

**Estado:** ✅ OK

---

### 38. Formatos display
**VB6:**
```vb
' NEGNUMFMT - formato numeros negativos
' Format(Abs(valor), NEGNUMFMT)
```

**.NET:**
```csharp
// Intl.NumberFormat('es-CL') - formato chileno
// Math.abs(num) - valores absolutos
```

**Estado:** ✅ OK

---

## 7. SEGURIDAD

### 39-40. Permisos y Validacion acceso
**VB6:**
```vb
' No hay validaciones de permisos en el formulario
' Asume que el usuario tiene acceso si puede abrir el form
```

**.NET:**
```csharp
// No hay [Authorize] ni validaciones de permisos
```

**Estado:** ✅ N/A (2 aspectos) - Feature sin restricciones de permisos especificas.

---

## 8. MANEJO DE ERRORES

### 41. Captura errores
**VB6:**
```vb
' Export_RLI_HR_RAB - Linea 577
On Error Resume Next
ERR.Clear
Open FPath For Output As #Fd
If ERR Then
   MsgErr FPath
   Export_RLI_HR_RAB = -ERR
   Exit Function
End If
On Error GoTo 0
```

**.NET:**
```csharp
// Index.cshtml
try {
    const response = await fetch(...);
    // ...
} catch (error) {
    console.error('Error cargando datos:', error);
    alert('Error al cargar los datos');
}
```

**Estado:** ✅ OK - Try/catch en frontend.

---

### 42. Mensajes de error
**VB6:**
```vb
' MsgErr FPath - mensaje generico de error de archivo
' MsgBox1 "No existen datos..." - mensaje descriptivo
```

**.NET:**
```csharp
// alert('Error al cargar los datos')
// BadRequest con mensaje descriptivo
```

**Estado:** 🟠 PARCIAL - Mensajes basicos. Falta detalle de errores en algunos casos.

---

## 9. OUTPUTS / SALIDAS

### 43. Datos de retorno
**VB6:**
```vb
' Formulario modal sin retorno (solo visualizacion)
```

**.NET:**
```csharp
// Vista sin retorno
```

**Estado:** ✅ N/A

---

### 44. Exportar Excel
**VB6:**
```vb
' Bt_CopyExcel_Click - Linea 516
Clip = LP_FGr2String(Grid, Me.Caption)
Clipboard.Clear
Clipboard.SetText Clip
```

**.NET:**
```csharp
// exportarExcel() - Linea 240
const html = table.outerHTML;
const blob = new Blob([html], { type: 'application/vnd.ms-excel' });
const url = URL.createObjectURL(blob);
const a = document.createElement('a');
a.download = `AjustesRLI_${ano}.xls`;
```

**Estado:** ✅ OK - Exportacion Excel implementada (via clipboard en VB6, via file download en .NET).

---

### 45. Exportar PDF
**VB6:**
```vb
' No hay exportacion PDF directa
```

**.NET:**
```csharp
// No implementado
```

**Estado:** ✅ N/A

---

### 46. Exportar CSV/Texto
**VB6:**
```vb
' Export_RLI_HR_RAB() - Linea 560
Open FPath For Output As #Fd
Buf = "Tipo Item" & Sep & "Fecha" & Sep & "Descripcion" & Sep & "Monto"
Print #Fd, Buf
' Itera movimientos y genera CSV
```

**.NET:**
```csharp
// ExportarHrRabRadAsync() - Linea 122
var sb = new StringBuilder();
sb.AppendLine("Tipo,Grupo,Item,Concepto,Valor");
// ❌ DIFERENTE: Headers diferentes
// ❌ FALTA: No itera movimientos individuales, solo items agrupados
```

**Estado:** 🔴 CRITICO - Exportacion CSV con estructura diferente. VB6 exporta movimientos detallados, .NET exporta items agrupados.

---

### 47. Impresion
**VB6:**
```vb
' Bt_Print_Click() - Linea 441
Call SetUpPrtGrid
Call gPrtLibros.PrtFlexGrid(Printer)

' Bt_Preview_Click() - Linea 464
Set Frm = New FrmPrintPreview
Call gPrtLibros.PrtFlexGrid(Frm)
Call Frm.FView(Caption)
```

**.NET:**
```csharp
// window.print() - CSS media print
// ❌ NO hay vista previa
```

**Estado:** 🟠 PARCIAL - Impresion basica OK. Falta vista previa.

---

### 48. Llamadas a otros modulos
**VB6:**
```vb
' Bt_Sum_Click - Linea 525
Set Frm = New FrmSumSimple
Call Frm.FViewSum(Grid)

' Bt_ConvMoneda_Click - Linea 536
Set Frm = New FrmConverMoneda

' Bt_Calc_Click - Linea 546
Call Calculadora

' Bt_Calendar_Click - Linea 549
Set Frm = New FrmCalendar
```

**.NET:**
```csharp
// ❌ NO hay llamadas a modulos auxiliares
```

**Estado:** 🟠 PARCIAL - Faltan utilidades auxiliares (suma, calculadora, calendario, conversor moneda).

---

## 10. PARIDAD DE CONTROLES UI

### 49. TextBoxes
**VB6:**
```vb
' No hay TextBoxes - solo grid
```

**.NET:**
```csharp
// No hay inputs text
```

**Estado:** ✅ N/A

---

### 50. Labels/Etiquetas
**VB6:**
```vb
' Caption del formulario dinamico:
' "Ajustes Extra - Contables RLI HR RAB" (< 2020)
' "Ajustes Extra - Contables RLI HR RAD" (>= 2020)
```

**.NET:**
```csharp
// Index.cshtml - Linea 6
var titulo = ano >= 2020 ? "Ajustes Extra-Contables RLI HR RAD" : "Ajustes Extra-Contables RLI HR RAB";
```

**Estado:** ✅ OK

---

### 51. ComboBoxes/Selects
**VB6:**
```vb
' No hay combos
```

**.NET:**
```csharp
// No hay selects
```

**Estado:** ✅ N/A

---

### 52. Grids/Tablas
**VB6:**
```vb
' FlexEdGrid2.FEd2Grid Grid
' Cols = 10
' - C_ID (oculto)
' - C_TIPOAJUSTE (oculto)
' - C_IDGRUPO (oculto)
' - C_IDITEM (oculto)
' - C_TIPOITEM (oculto)
' - C_CONCEPTO (visible, 9400 twips)
' - C_VALOR (visible, 1600 twips)
' - C_FMT (oculto)
' - C_COLOBLIGATORIA (oculto)
' - C_UPD (oculto)
```

**.NET:**
```csharp
// <table id="grid-ajustes">
// 2 columnas visibles:
// - Concepto (td.px-4.py-2)
// - Valor (td.px-4.py-2.text-right.w-48)
// Data attributes en filas:
// - data-tipo-item
```

**Estado:** 🟠 PARCIAL - Grid simplificado. Columnas visibles OK. Faltan columnas ocultas para datos auxiliares.

---

### 53. CheckBoxes
**VB6:**
```vb
' No hay checkboxes
```

**.NET:**
```csharp
// No hay checkboxes
```

**Estado:** ✅ N/A

---

### 54. Campos ocultos/IDs
**VB6:**
```vb
' Grid con columnas ocultas (Width = 0):
' C_ID, C_TIPOAJUSTE, C_IDGRUPO, C_IDITEM, C_TIPOITEM, C_FMT, C_COLOBLIGATORIA, C_UPD
```

**.NET:**
```csharp
// Data en objetos JS:
// - tipoAjuste, idGrupo, idItem, tipoItem, orden
// ❌ NO hay campos hidden en el HTML
// ❌ Data solo en memoria JS
```

**Estado:** 🟠 PARCIAL - Datos almacenados en JS, no en DOM.

---

## 11. GRIDS Y COLUMNAS

### 55. Columnas del grid
**VB6:**
```vb
' 2 columnas VISIBLES:
' - Concepto (jerarquia con indentacion: tipo, grupo, item)
' - Valor (numerico, alineado derecha)
```

**.NET:**
```csharp
// 2 columnas visibles:
// - Concepto (con jerarquia: agregarTitulo, agregarSubtitulo, agregarItem)
// - Valor (numerico, formatNumber)
```

**Estado:** ✅ OK - Mismas columnas visibles con jerarquia equivalente.

---

### 56. Datos del grid
**VB6:**
```vb
' LoadAll() - Linea 308
' Itera:
' For k = 1 To MAX_TIPOAJUSTESECRLI (tipos)
'   For j = 1 To MAX_GRUPOAJUSTESECRLI (grupos)
'     For o = 1 To MAX_ITEMAJUSTESECRLI (orden)
'       For i = 1 To MAX_ITEMAJUSTESECRLI (items)
'         valor = LoadValCuentas(...) ' ⭐ CALCULO DE VALORES
```

**.NET:**
```csharp
// cargarDatos() - Linea 87
// ajustesData.tipos.forEach((tipo) => {
//   tipo.grupos.forEach(grupo => {
//     grupo.items.sort((a, b) => a.orden - b.orden).forEach(item => {
//       agregarItem(item);
//     });
//   });
// });
// ❌ Items retornan Valor = 0 (no calculado)
```

**Estado:** 🟠 PARCIAL - Estructura de datos OK. Falta calculo de valores reales.

---

## 12. EVENTOS E INTERACCION

### 57. Doble clic
**VB6:**
```vb
' No hay evento DblClick
```

**.NET:**
```csharp
// No implementado
```

**Estado:** ✅ N/A

---

### 58. Teclas especiales
**VB6:**
```vb
' No hay KeyPreview ni atajos de teclado
```

**.NET:**
```csharp
// No hay event listeners de teclado
```

**Estado:** ✅ N/A

---

### 59. Eventos Change
**VB6:**
```vb
' No hay eventos Change - grid readonly
```

**.NET:**
```csharp
// No aplica - tabla readonly
```

**Estado:** ✅ N/A

---

### 60. Menu contextual
**VB6:**
```vb
' No hay menu contextual
```

**.NET:**
```csharp
// No implementado
```

**Estado:** ✅ N/A

---

### 61. Modales Lookup
**VB6:**
```vb
' Bt_Sum_Click - Abre FrmSumSimple modal
' Bt_ConvMoneda_Click - Abre FrmConverMoneda modal
' Bt_Calendar_Click - Abre FrmCalendar modal
```

**.NET:**
```csharp
// ❌ NO implementados modales auxiliares
```

**Estado:** 🔴 FALTA - Modales de utilidades (suma, calendario, conversor) no implementados.

---

## 13. ESTADOS Y MODOS DEL FORMULARIO

### 62. Modos del form
**VB6:**
```vb
' Modo unico: FEdit() - visualizacion modal
' No hay modos N/E/V
```

**.NET:**
```csharp
// Modo unico: Index() - visualizacion
```

**Estado:** ✅ OK

---

### 63. Controles por modo
**VB6:**
```vb
' Grid readonly siempre
```

**.NET:**
```csharp
// Tabla readonly siempre
```

**Estado:** ✅ N/A

---

### 64. Orden de tabulacion
**VB6:**
```vb
' TabIndex en botones de toolbar
```

**.NET:**
```csharp
// Orden natural del DOM en toolbar
```

**Estado:** ✅ N/A

---

## 14. INICIALIZACION Y CARGA

### 65. Carga inicial
**VB6:**
```vb
' Form_Load() - Linea 271
Private Sub Form_Load()
   lOrientacion = ORIENT_VER
   Call SetUpGrid

   If gEmpresa.Ano >= 2020 Then
      Me.Caption = ReplaceStr(Me.Caption, "RAB", "RAD")
      Bt_ExportHRRAB.Caption = "Exportar a HR RAD"
   End If

   Call LoadAll
End Sub
```

**.NET:**
```csharp
// Index() - carga vista
// cargarDatos() JS - ejecuta al final del <script>
async function cargarDatos() {
    const response = await fetch(`${URL_ENDPOINTS.getAjustes}?empresaId=${empresaId}&ano=${ano}`);
    ajustesData = await response.json();
    renderGrid();
}
```

**Estado:** ✅ OK - Carga inicial equivalente.

---

### 66. Valores por defecto
**VB6:**
```vb
' No hay valores por defecto - todo cargado desde BD
```

**.NET:**
```csharp
// Arrays vacios inicializados
```

**Estado:** ✅ OK

---

### 67. Llenado de combos
**VB6:**
```vb
' No hay combos
```

**.NET:**
```csharp
// No aplica
```

**Estado:** ✅ N/A

---

## 15. FILTROS Y BUSQUEDA

### 68. Campos de filtro
**VB6:**
```vb
' Bt_VerSaldosPositivos_Click - Linea 259
' Filtra filas con Valor = 0 (oculta via RowHeight = 0)
For i = Grid.FixedRows To Grid.rows - 1
   If Grid.TextMatrix(i, C_TIPOITEM) <> "" And Val(Grid.TextMatrix(i, C_VALOR)) = 0 Then
      Grid.RowHeight(i) = 0
   End If
Next i
```

**.NET:**
```csharp
// mostrarConValor() - Linea 194
mostrarSoloConValor = !mostrarSoloConValor;
renderGrid();
// if (!mostrarSoloConValor || item.valor > 0) { agregarItem(item); }
```

**Estado:** ✅ OK - Filtro de valores positivos implementado.

---

### 69. Criterios de busqueda
**VB6:**
```vb
' Criterio unico: Valor > 0
```

**.NET:**
```csharp
// Criterio unico: item.valor > 0
```

**Estado:** ✅ N/A

---

## 16. REPORTES E IMPRESION

### 70. Reportes disponibles
**VB6:**
```vb
' Impresion del grid via gPrtLibros.PrtFlexGrid()
' No hay reportes Crystal Reports
```

**.NET:**
```csharp
// window.print() con CSS @media print
```

**Estado:** ✅ OK - Impresion basica equivalente.

---

### 71. Parametros de reporte
**VB6:**
```vb
' SetUpPrtGrid() - Linea 493
' Titulos(0) = Me.Caption
' ColWi, ColObligatoria, FmtCol
```

**.NET:**
```csharp
// CSS @media print (estilo de impresion)
```

**Estado:** ✅ OK - Parametros de impresion equivalentes (via CSS).

---

## 17. REGLAS DE NEGOCIO

### 72. Umbrales y limites
**VB6:**
```vb
' Constantes de configuracion:
' MAX_TIPOAJUSTESECRLI = 4
' MAX_GRUPOAJUSTESECRLI = 6
' MAX_ITEMAJUSTESECRLI = 20
' MAX_CTASAJUSTESECRLI = 30
```

**.NET:**
```csharp
// ❌ HARDCODED sin constantes explicitas
// Estructura fija en GetGruposAgregadosAsync(), GetGruposDeduccionesAsync()
```

**Estado:** 🔴 FALTA - Constantes de limites no definidas explicitamente.

---

### 73. Formulas de calculo
**VB6:**
```vb
' LoadValCuentas() - Formula critica:
' SELECT Sum(Debe - Haber) as Valor
' WHERE TipoAjuste IN (TAJUSTE_FINANCIERO, TAJUSTE_AMBOS)
' AND Comprobante.Tipo <> TC_APERTURA
```

**.NET:**
```csharp
// ❌ NO IMPLEMENTADO
// TODO: [LEGACY] [MEDIUM] Implementar calculos complejos
```

**Estado:** 🔴 CRITICO - Formula de calculo principal NO implementada.

---

### 74. Condiciones de negocio
**VB6:**
```vb
' InitCtasAjustesExtraContRLI() - Linea 68
' Configuracion de items varia segun:
' - gEmpresa.Ano < 2020 vs >= 2020 (RAB vs RAD)
' - gEmpresa.R14ASemiIntegrado = True And gEmpresa.Ano >= 2023 (items adicionales)
```

**.NET:**
```csharp
// Condicion ano >= 2020 implementada (RAB/RAD)
// ❌ NO implementado: R14ASemiIntegrado
```

**Estado:** 🔴 FALTA - Condicion de regimen semi-integrado no implementada.

---

### 75. Restricciones
**VB6:**
```vb
' ReadCtasAjustesExtraContRLI() - Linea 522
If i > 30 Then
   MsgBox1 "Se ha superado la cantidad de cuentas para el Item...", vbExclamation
   Exit Do
End If
```

**.NET:**
```csharp
// ❌ NO hay limites validados
```

**Estado:** 🔴 FALTA - Validacion de limites de cuentas no implementada.

---

## 18. FLUJOS DE TRABAJO

### 76. Secuencia de estados
**VB6:**
```vb
' Formulario sin estados - solo visualizacion
```

**.NET:**
```csharp
// No aplica
```

**Estado:** ✅ N/A

---

### 77. Acciones por estado
**VB6:**
```vb
' No aplica
```

**.NET:**
```csharp
// No aplica
```

**Estado:** ✅ N/A

---

### 78. Transiciones validas
**VB6:**
```vb
' No aplica
```

**.NET:**
```csharp
// No aplica
```

**Estado:** ✅ N/A

---

## 19. INTEGRACIONES ENTRE MODULOS

### 79. Llamadas a otros modulos
**VB6:**
```vb
' FrmSumSimple (suma de celdas seleccionadas)
' FrmConverMoneda (conversor de moneda)
' FrmCalendar (selector de fecha)
' Calculadora (calculadora Windows)
```

**.NET:**
```csharp
// ❌ NO hay llamadas a modulos auxiliares
```

**Estado:** 🟠 PARCIAL - Faltan modulos de utilidades.

---

### 80. Parametros de integracion
**VB6:**
```vb
' FrmSumSimple.FViewSum(Grid) - pasa el grid
```

**.NET:**
```csharp
// N/A
```

**Estado:** ✅ N/A

---

### 81. Datos compartidos/retorno
**VB6:**
```vb
' Modales no retornan valores (solo utilidades)
```

**.NET:**
```csharp
// N/A
```

**Estado:** ✅ N/A

---

## 20. MENSAJES AL USUARIO

### 82. Mensajes de error
**VB6:**
```vb
' MsgErr FPath (error abriendo archivo)
' MsgBox1 "No existen datos para generar archivo..." (sin datos para exportar)
' MsgBox1 "Se ha superado la cantidad de cuentas..." (limite de cuentas)
```

**.NET:**
```csharp
// alert('Error al cargar los datos')
// BadRequest({ errors: ["No existen datos para generar archivo"] })
// ❌ NO hay mensaje de limite de cuentas
```

**Estado:** 🟠 PARCIAL - Mensajes principales OK. Falta mensaje de limite de cuentas.

---

### 83. Mensajes de confirmacion
**VB6:**
```vb
' No hay confirmaciones - acciones directas
```

**.NET:**
```csharp
// No hay confirmaciones
```

**Estado:** ✅ N/A

---

## 21. CASOS BORDE Y VALORES ESPECIALES

### 84. Valores cero
**VB6:**
```vb
' Bt_VerSaldosPositivos filtra Val(Grid.TextMatrix(i, C_VALOR)) = 0
' Valores cero se muestran en grid
```

**.NET:**
```csharp
// mostrarConValor filtra item.valor > 0
// ❌ Items con valor 0 siempre presentes (todos valen 0 por falta de calculo)
```

**Estado:** 🔴 CRITICO - Todos los valores son 0 por falta de implementacion de calculos.

---

### 85. Valores negativos
**VB6:**
```vb
' Format(Abs(valor), NEGNUMFMT) - valores siempre positivos (valor absoluto)
```

**.NET:**
```csharp
// Math.abs(num) - valores absolutos
```

**Estado:** ✅ OK - Politica de valores absolutos correcta.

---

### 86. Valores nulos/vacios
**VB6:**
```vb
' vFld(Rs("Valor")) - manejo de nulos con vFld()
' If LstCuentas = "" Then LoadValCuentas = 0
```

**.NET:**
```csharp
// ❌ NO hay validacion de nulos en queries (queries no implementados)
```

**Estado:** 🔴 FALTA - Manejo de nulos no implementado (queries faltantes).

---

## RESUMEN DE GAPS

### Gaps CRITICOS (BLOQUEAN FUNCIONALIDAD CORE)

| # | Gap | Impacto | Archivo |
|---|-----|---------|---------|
| 1 | **Funcion de calculo principal NO implementada** | Todos los valores retornan 0. Feature completamente no funcional. | `AjustesRliCajaService.cs:84-119` |
| 2 | **Queries SELECT incompletos** | No hay JOIN con Comprobante, filtros TipoAjuste, ni calculo Sum(Debe-Haber). | `AjustesRliCajaService.cs:112-114` |
| 3 | **Campos criticos no leidos** | No se leen Debe, Haber, IdCuenta, TipoAjuste de MovComprobante. | `AjustesRliCajaService.cs:112-114` |
| 4 | **Tabla Comprobante no accedida** | Falta JOIN y lectura de Tipo, Correlativo, Fecha para exportacion. | `AjustesRliCajaService.cs` |
| 5 | **Exportacion CSV con estructura incorrecta** | VB6 exporta movimientos detallados con fecha, .NET exporta items agrupados sin fecha. | `AjustesRliCajaService.cs:122-152` |
| 6 | **Formula de calculo Sum(Debe-Haber) faltante** | Query critico para calcular valor de cada item. | `AjustesRliCajaService.cs` |
| 7 | **Filtro TipoAjuste no implementado** | Query debe filtrar TipoAjuste IN (TAJUSTE_FINANCIERO, TAJUSTE_AMBOS). | `AjustesRliCajaService.cs` |
| 8 | **Filtro Tipo <> TC_APERTURA faltante** | Query debe excluir comprobantes de apertura. | `AjustesRliCajaService.cs` |

### Gaps MEDIOS (FUNCIONALIDAD SECUNDARIA FALTANTE)

| # | Gap | Impacto | Archivo |
|---|-----|---------|---------|
| 9 | **Tabla CtasAjustesExContRLI no implementada** | Configuracion de cuentas hardcoded en lugar de DB. | `AjustesRliCajaService.cs:23-36` |
| 10 | **Utilidades auxiliares faltantes** | Suma de seleccionados, calculadora, calendario, conversor moneda. | `Index.cshtml` |
| 11 | **Modales lookup no implementados** | FrmSumSimple, FrmConverMoneda, FrmCalendar. | `Index.cshtml` |
| 12 | **Vista previa de impresion faltante** | VB6 tiene FrmPrintPreview, .NET solo window.print() directo. | `Index.cshtml:44` |
| 13 | **Condicion R14ASemiIntegrado no implementada** | Items adicionales para regimen semi-integrado 2023+. | `AjustesRliCajaService.cs` |
| 14 | **Validacion limite de cuentas faltante** | VB6 valida max 30 cuentas por item. | `AjustesRliCajaService.cs` |
| 15 | **Mensaje de limite de cuentas faltante** | Error descriptivo cuando se supera limite. | `AjustesRliCajaService.cs` |
| 16 | **Constantes de limites no definidas** | MAX_TIPOAJUSTESECRLI, MAX_GRUPOAJUSTESECRLI, MAX_ITEMAJUSTESECRLI. | `AjustesRliCajaService.cs` |

### Gaps MENORES (UX DIFERENTE, NO CRITICO)

| # | Gap | Impacto | Archivo |
|---|-----|---------|---------|
| 17 | **Campos ocultos en DOM** | VB6 almacena en columnas grid ocultas, .NET en memoria JS. | `Index.cshtml` |
| 18 | **Exportacion Excel diferente** | VB6 usa clipboard, .NET descarga archivo .xls. | `Index.cshtml:240-249` |
| 19 | **Manejo de errores menos detallado** | Mensajes de error basicos vs descriptivos. | `Index.cshtml:98-100` |

---

## MEJORAS SOBRE VB6

| # | Mejora | Beneficio |
|---|--------|-----------|
| 1 | **Arquitectura MVC moderna** | Separacion clara Controller/Service/DTO vs codigo monolitico VB6. |
| 2 | **API REST** | Endpoints reutilizables, testables, documentables. |
| 3 | **UI responsive con Tailwind CSS** | Mejor UX en dispositivos modernos vs UI fija VB6. |
| 4 | **Async/await** | Operaciones asincronas no bloquean UI vs bloqueo VB6. |
| 5 | **Dependency Injection** | Mejor testabilidad y mantenibilidad vs globals VB6. |
| 6 | **TypeScript en frontend** | Type safety vs JavaScript VB6 embebido. |
| 7 | **Exportacion via download** | Mejor UX que clipboard de VB6. |
| 8 | **CSS @media print** | Impresion web moderna vs control Printer VB6. |

---

## CONCLUSION

### Estado de la Migracion

**Paridad General: 61.6%** (53/86 aspectos OK o N/A)

**Diagnostico:**
- ✅ **Estructura y arquitectura:** Correcta (MVC, API, UI)
- ✅ **UI y navegacion:** Funcional (grid jerarquico, filtros, exportacion Excel)
- ✅ **Impresion basica:** Implementada
- 🔴 **CRITICO - Logica de negocio:** NO FUNCIONAL
  - **Calculos de ajustes NO implementados**
  - **Queries incompletos**
  - **Exportacion CSV con estructura incorrecta**
- 🟠 **Configuracion:** Hardcoded vs dinamica desde BD
- 🟠 **Utilidades auxiliares:** Faltantes pero no bloqueantes

### Veredicto Final

🔴 **NO ACEPTABLE PARA PRODUCCION** (< 80% paridad, gaps criticos)

### Razon Principal
La funcionalidad CORE esta NO IMPLEMENTADA:
1. Todos los valores del grid son 0 (funcion `LoadValCuentas` no migrada)
2. Los calculos de ajustes tributarios estan marcados como TODO
3. La exportacion CSV no incluye movimientos detallados

### Acciones Requeridas para Alcanzar Paridad

#### CRITICAS (Bloquean release)
1. ✅ **Implementar LoadValCuentas equivalente** (AjustesRliCajaService.cs)
   - Query: `SELECT Sum(Debe - Haber) FROM MovComprobante JOIN Comprobante`
   - Filtros: `TipoAjuste IN (FINANCIERO, AMBOS)`, `Tipo <> TC_APERTURA`
   - Parametros: IdCuenta IN (LstCuentas)

2. ✅ **Implementar lectura de CtasAjustesExContRLI**
   - Crear DTO para configuracion de cuentas
   - Leer desde BD en lugar de hardcodear

3. ✅ **Corregir exportacion CSV**
   - Cambiar headers a: "Tipo Item, Fecha, Descripcion, Monto"
   - Iterar movimientos individuales, no items agrupados
   - Incluir: Tipo comprobante, Correlativo, Fecha

4. ✅ **Implementar formulas de calculo por tipo de ajuste**
   - GetItemsAgregadosArt33Async
   - GetItemsOtrosAgregadosAsync
   - GetItemsDeduccionesAsync

#### MEDIAS (Planificar)
5. ⚠️ Implementar condicion R14ASemiIntegrado (para anos >= 2023)
6. ⚠️ Validar limites de cuentas (max 30)
7. ⚠️ Vista previa de impresion (FrmPrintPreview equivalente)

#### MENORES (Opcionales)
8. 🟡 Modulos auxiliares: suma, calculadora, calendario, conversor (Nice to have)

### Estimacion de Esfuerzo

| Tarea | Complejidad | Tiempo Estimado |
|-------|-------------|-----------------|
| Implementar LoadValCuentas + queries | Alta | 16-24 horas |
| Lectura CtasAjustesExContRLI | Media | 8 horas |
| Corregir exportacion CSV | Media | 4 horas |
| Implementar formulas calculo | Alta | 24-32 horas |
| R14ASemiIntegrado + validaciones | Baja | 4 horas |
| **TOTAL CRITICO** | | **56-72 horas (7-9 dias)** |

---

**Elaborado por:** Claude Code (Anthropic)
**Metodologia:** Auditoria de Gaps VB6→.NET (86 aspectos)
**Revision:** Manual requerida por arquitecto/lider tecnico
