namespace App.Features.BalanceComprobacion;

public interface IBalanceComprobacionService
{
    Task<BalanceComprobacionResponseDto> GenerarAsync(BalanceComprobacionRequestDto request, CancellationToken cancellationToken = default);

    Task<BalanceComprobacionExportResponseDto> ExportarExcelAsync(BalanceComprobacionExportRequestDto request, CancellationToken cancellationToken = default);

    Task<BalanceComprobacionOpcionesDto> ObtenerOpcionesAsync(int empresaId, CancellationToken cancellationToken = default);

    BalanceComprobacionFechasDefaultDto ObtenerFechasDefault(short ano);
}