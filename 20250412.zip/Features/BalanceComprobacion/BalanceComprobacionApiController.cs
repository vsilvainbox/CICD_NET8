using Microsoft.AspNetCore.Mvc;

namespace App.Features.BalanceComprobacion;

[ApiController]
[Route("[controller]/[action]")]
public class BalanceComprobacionApiController(
    IBalanceComprobacionService service,
    ILogger<BalanceComprobacionApiController> logger) : ControllerBase
{
    /// <summary>
    /// Genera el Balance de Comprobación según los parámetros especificados
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<BalanceComprobacionResponseDto>> Generar(
        [FromBody] BalanceComprobacionRequestDto request,
        CancellationToken cancellationToken = default)
    {
        {
            logger.LogInformation("Generando Balance de Comprobación para Empresa {EmpresaId}, año {Ano}",
                request.EmpresaId, request.Ano);

            var resultado = await service.GenerarAsync(request, cancellationToken);

            return Ok(resultado);
        }
    }

    /// <summary>
    /// Obtiene las opciones de filtros para el Balance de Comprobación
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<BalanceComprobacionOpcionesDto>> GetOpciones(
        [FromQuery] int empresaId,
        CancellationToken cancellationToken = default)
    {
        {
            logger.LogInformation("Obteniendo opciones de Balance de Comprobación para Empresa {EmpresaId}",
                empresaId);

            var opciones = await service.ObtenerOpcionesAsync(empresaId, cancellationToken);

            return Ok(opciones);
        }
    }

    /// <summary>
    /// Exporta el Balance de Comprobación a Excel
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> ExportarExcel(
        [FromBody] BalanceComprobacionExportRequestDto request,
        CancellationToken cancellationToken = default)
    {
        {
            logger.LogInformation("Exportando Balance de Comprobación a Excel para Empresa {EmpresaId}",
                request.EmpresaId);

            var resultado = await service.ExportarExcelAsync(request, cancellationToken);

            return File(resultado.Content, resultado.ContentType, resultado.FileName);
        }
    }

    /// <summary>
    /// Obtiene fechas por defecto para el Balance de Comprobación según el año
    /// </summary>
    [HttpGet]
    public ActionResult<BalanceComprobacionFechasDefaultDto> GetFechasDefault(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        CancellationToken cancellationToken = default)
    {
        {
            logger.LogInformation("Obteniendo fechas por defecto para Empresa {EmpresaId}, año {Ano}",
                empresaId, ano);

            var fechas = service.ObtenerFechasDefault(ano);

            return Ok(fechas);
        }
    }
}