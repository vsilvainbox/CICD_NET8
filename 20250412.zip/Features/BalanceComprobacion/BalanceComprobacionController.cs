using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Extensions;
using App.Helpers;

namespace App.Features.BalanceComprobacion;

public class BalanceComprobacionController(
    ILogger<BalanceComprobacionController> logger,
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator) : Controller
{
    /// <summary>
    /// Vista principal del Balance de Comprobación
    /// </summary>
    [HttpGet]
    public IActionResult Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder al Balance de Comprobación";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        var empresaId = SessionHelper.EmpresaId;
        var ano = (short)SessionHelper.Ano;

        logger.LogInformation("Cargando Balance de Comprobación para Empresa {EmpresaId}, Año {Ano}",
            empresaId, ano);

        // Crear modelo con valores iniciales
        var model = new BalanceComprobacionRequestDto
        {
            EmpresaId = empresaId,
            Ano = ano,
            FechaDesde = new DateTime(ano, 1, 1),
            FechaHasta = new DateTime(ano, 12, 31),
            Nivel = 2,
            TipoAjuste = 1,
            MostrarCodigoCuenta = true,
            SoloLibroOficial = false
        };

        return View(model);
    }

    /// <summary>
    /// Método proxy: Obtiene las opciones de filtros para el Balance de Comprobación
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Opciones(int empresaId)
    {
        logger.LogInformation("MVC Proxy: Obteniendo opciones para empresaId={EmpresaId}", empresaId);

        {
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<BalanceComprobacionApiController>(
                HttpContext,
                nameof(BalanceComprobacionApiController.GetOpciones),
                new { empresaId });

            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Método proxy: Genera el Balance de Comprobación según los parámetros especificados
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Generar([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: Generando Balance de Comprobación");

        {
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<BalanceComprobacionApiController>(
                HttpContext,
                nameof(BalanceComprobacionApiController.Generar));

            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// Método proxy: Exporta el Balance de Comprobación a Excel
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> ExportarExcel([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: Exportando Balance de Comprobación a Excel");

        {
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<BalanceComprobacionApiController>(
                HttpContext,
                nameof(BalanceComprobacionApiController.ExportarExcel));

            var (fileBytes, contentType) = await client.DownloadFileAsync(
                url,
                HttpMethod.Post,
                request);

            var fileName = "BalanceComprobacion.xlsx";
            return File(fileBytes, contentType, fileName);
        }
    }
}
