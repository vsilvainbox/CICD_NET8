using System.ComponentModel.DataAnnotations;

namespace App.Features.BalanceComprobacion;

/// <summary>
/// Request DTO para generar Balance de Comprobaci�n
/// VB6: FrmBalComprobacion - filtros desde formulario
/// </summary>
public class BalanceComprobacionRequestDto
{
    [Required]
    public int EmpresaId { get; set; }

    [Required]
    public short Ano { get; set; }

    [Required]
    public DateTime FechaDesde { get; set; }

    [Required]
    public DateTime FechaHasta { get; set; }

    [Range(1, 5)]
    public int Nivel { get; set; } = 2; // VB6: Cb_Nivel.ListIndex = 1 (nivel 2)

    public int? AreaNegocioId { get; set; }

    public int? CentroCostoId { get; set; }

    public bool SoloLibroOficial { get; set; } // VB6: Ch_LibOficial

    public bool MostrarCodigoCuenta { get; set; } = true; // VB6: Ch_VerCodCta

    public int TipoAjuste { get; set; } = 1; // 1=Financiero, 2=Tributario, 3=Ambos
}

/// <summary>
/// Response DTO con los datos del Balance de Comprobaci�n
/// </summary>
public class BalanceComprobacionResponseDto
{
    public List<BalanceComprobacionRowDto> Filas { get; set; } = new();
    public BalanceComprobacionTotalesDto Totales { get; set; } = new();
    public BalanceComprobacionFiltroAplicadoDto Filtros { get; set; } = new();
    public DateTime GeneradoEl { get; set; } = DateTime.UtcNow;
}

/// <summary>
/// Fila individual del Balance de Comprobaci�n
/// VB6: Grid con columnas C_CODIGO, C_CUENTA, C_DEBITOS, C_CREDITOS, C_DEUDOR, C_ACREEDOR
/// </summary>
public class BalanceComprobacionRowDto
{
    public int? IdCuenta { get; set; }
    public string Codigo { get; set; } = string.Empty;
    public string Nombre { get; set; } = string.Empty;
    public int Nivel { get; set; }
    public int? Clasificacion { get; set; }

    // Movimientos del Per�odo (VB6: C_DEBITOS, C_CREDITOS)
    public decimal Debitos { get; set; }
    public decimal Creditos { get; set; }

    // Saldos (VB6: C_DEUDOR, C_ACREEDOR)
    public decimal SaldoDeudor { get; set; }
    public decimal SaldoAcreedor { get; set; }

    public bool EsTotal { get; set; }
    public bool EsVisible { get; set; } = true;
}

/// <summary>
/// Totales del Balance de Comprobaci�n
/// VB6: GridTot(0) = Sub Total, GridTot(1) = Utilidad/P�rdida, GridTot(2) = TOTALES
/// </summary>
public class BalanceComprobacionTotalesDto
{
    // Sub Total (VB6: GridTot(0))
    public decimal SubTotalDebitos { get; set; }
    public decimal SubTotalCreditos { get; set; }
    public decimal SubTotalSaldoDeudor { get; set; }
    public decimal SubTotalSaldoAcreedor { get; set; }

    // Utilidad o P�rdida (VB6: GridTot(1))
    public decimal UtilidadPerdidaDebitos { get; set; }
    public decimal UtilidadPerdidaCreditos { get; set; }
    public decimal UtilidadPerdidaSaldoDeudor { get; set; }
    public decimal UtilidadPerdidaSaldoAcreedor { get; set; }

    // Totales (VB6: GridTot(2))
    public decimal TotalDebitos { get; set; }
    public decimal TotalCreditos { get; set; }
    public decimal TotalSaldoDeudor { get; set; }
    public decimal TotalSaldoAcreedor { get; set; }

    public bool EstaBalanceado =>
        Math.Round(TotalDebitos, 2) == Math.Round(TotalCreditos, 2) &&
        Math.Round(TotalSaldoDeudor, 2) == Math.Round(TotalSaldoAcreedor, 2);
}

/// <summary>
/// Filtros aplicados al Balance
/// </summary>
public class BalanceComprobacionFiltroAplicadoDto
{
    public DateTime FechaDesde { get; set; }
    public DateTime FechaHasta { get; set; }
    public int Nivel { get; set; }
    public string? AreaNegocio { get; set; }
    public string? CentroCosto { get; set; }
    public bool SoloLibroOficial { get; set; }
    public int TipoAjuste { get; set; }
}

/// <summary>
/// DTO para exportaci�n a Excel
/// </summary>
public class BalanceComprobacionExportRequestDto : BalanceComprobacionRequestDto
{
    public string? NombreArchivo { get; set; }
}

/// <summary>
/// Response para exportaci�n
/// </summary>
public class BalanceComprobacionExportResponseDto
{
    public string FileName { get; set; } = string.Empty;
    public string ContentType { get; set; } = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    public byte[] Content { get; set; } = Array.Empty<byte>();
}

/// <summary>
/// DTO para opciones de filtros
/// </summary>
public class BalanceComprobacionOpcionesDto
{
    public List<ComboItemDto> Niveles { get; set; } = new();
    public List<ComboItemDto> TiposAjuste { get; set; } = new();
    public List<ComboItemDto> AreasNegocio { get; set; } = new();
    public List<ComboItemDto> CentrosCosto { get; set; } = new();
}

public class ComboItemDto
{
    public int Value { get; set; }
    public string Text { get; set; } = string.Empty;
}

/// <summary>
/// DTO para fechas por defecto del Balance de Comprobación
/// </summary>
public class BalanceComprobacionFechasDefaultDto
{
    public DateTime FechaDesde { get; set; }
    public DateTime FechaHasta { get; set; }
}