# Análisis COMPLETO de FrmBalComprobacion.frm

## 📋 Información General
- **Formulario VB6:** `FrmBalComprobacion.frm`
- **Ubicación:** `\vb6\Contabilidad70\HyperContabilidad\`
- **Título:** "Balance de Comprobación y Saldos"
- **Complejidad:** ⭐⭐⭐⭐⭐ MUY ALTA (Query jerárquica compleja)

## 🎯 Propósito REAL del VB6

**IMPORTANTE:** A diferencia de otros balances, este NO tiene saldos iniciales. Solo muestra:
1. **Débitos** - Suma de movimientos DEBE del período
2. **Créditos** - Suma de movimientos HABER del período  
3. **Saldo Deudor** - Si Débitos > Créditos
4. **Saldo Acreedor** - Si Créditos > Débitos

## 🔍 Análisis EXACTO del VB6

### Grid Estructura (MSFlexGrid)

**Columnas:**
```vb
Const C_CODIGO = 0      ' Código cuenta
Const C_CUENTA = 1      ' Descripción
Const C_DEBITOS = 2     ' Movimientos Debe
Const C_CREDITOS = 3    ' Movimientos Haber
Const C_DEUDOR = 4      ' Saldo Deudor (si Debe > Haber)
Const C_ACREEDOR = 5    ' Saldo Acreedor (si Haber > Debe)
Const C_IDCUENTA = 6    ' ID (oculto)
Const C_NIVEL = 7       ' Nivel (oculto)
```

**3 Grids de Totales (GridTot):**
```vb
GridTot(0) = Sub Total       ' Suma de cuentas nivel 1
GridTot(1) = Utilidad/Pérdida ' Diferencia Débitos-Créditos
GridTot(2) = TOTALES          ' SubTotal + Utilidad/Pérdida
```

### Filtros del Formulario

```vb
' Frame2 - Filtros
Tx_Desde        ' Fecha inicio (default: 01/01/Año)
Tx_Hasta        ' Fecha fin (default: último día año)
Cb_Nivel        ' Nivel cuentas (default: 2)
Cb_TipoAjuste   ' Financiero=1, Tributario=2
Cb_AreaNeg      ' Área negocio (opcional)
Cb_CCosto       ' Centro costo (opcional)
Ch_LibOficial   ' Checkbox: Solo aprobados (Estado=2)
Ch_VerCodCta    ' Mostrar código cuenta (default: ON)
```

### Lógica Clave: GenQueryPorNiveles

**Esta función en HyperCont.bas genera una UNION compleja:**

```vb
' UNION 1: Todas las cuentas del nivel <= seleccionado (sin movimientos)
SELECT 1 as IdQ, idCuenta, Codigo, Nivel, Descripcion, 
       0 as Debe, 0 As Haber, Clasificacion
FROM Cuentas
WHERE Nivel <= @Nivel AND IdEmpresa = @Empresa AND Ano = @Ano

UNION

' UNION 2: Movimientos directos de cuentas nivel <= seleccionado
SELECT 2 as IdQ, Cuentas.idCuenta, Codigo, Nivel, Descripcion,
       Sum(Debe) as Debe, Sum(Haber) as Haber, Clasificacion
FROM Cuentas 
INNER JOIN MovComprobante ON Cuentas.idCuenta = MovComprobante.IdCuenta
INNER JOIN Comprobante ON MovComprobante.IdComp = Comprobante.IdComp
WHERE Nivel <= @Nivel 
  AND Fecha BETWEEN @Desde AND @Hasta
  AND Estado IN (2,3) -- Aprobado o Pendiente (si no es libro oficial)
GROUP BY idCuenta, Codigo, Nivel, Descripcion

UNION

' UNION 3: Suma de hijas hacia padre (si nivel < 5)
SELECT 3 as IdQ, Cuentas_1.idCuenta, Cuentas_1.Codigo, Cuentas_1.Nivel,
       Sum(Debe) AS Debe, Sum(Haber) AS Haber
FROM Cuentas 
INNER JOIN MovComprobante ON Cuentas.idCuenta = MovComprobante.IdCuenta
INNER JOIN Cuentas AS Cuentas_1 ON Cuentas.idPadre = Cuentas_1.idCuenta
INNER JOIN Comprobante ON MovComprobante.IdComp = Comprobante.IdComp
WHERE Cuentas_1.Nivel = @Nivel
  AND Fecha BETWEEN @Desde AND @Hasta
  AND Estado IN (2,3)
GROUP BY Cuentas_1.idCuenta, Codigo, Nivel

-- Si nivel < 4, agrega UNION 4 (abuelo)
-- Si nivel < 3, agrega UNION 5 (bis-abuelo)
-- Si nivel < 2, agrega UNION 6 (tatara-abuelo)

ORDER BY Codigo
```

### Procesamiento LoadAll (Lógica Principal)

```vb
Private Sub LoadAll()
    ' 1. Ejecutar GenQueryPorNiveles
    Q1 = GenQueryPorNiveles(Nivel, WhFecha & Wh, Ch_LibOficial <> 0)
    Set Rs = OpenRs(DbMain, Q1)
    
    ' 2. Recorrer resultados y agrupar por cuenta
    Do While Rs.EOF = False
        ' Acumular Debe/Haber por nivel hacia arriba
        For j = CurNiv To 1 Step -1
            Total(j).Debe = Total(j).Debe + vFld(Rs("Debe"))
            Total(j).Haber = Total(j).Haber + vFld(Rs("Haber"))
        Next j
        Rs.MoveNext
    Loop
    
    ' 3. Calcular saldos Deudor/Acreedor
    For Row = Grid.FixedRows To Grid.rows - 1
        Diff = Débitos - Créditos
        If Diff > 0 Then
            SaldoDeudor = Diff
        Else
            SaldoAcreedor = Abs(Diff)
        End If
        
        ' 4. SOLO mostrar cuentas del nivel seleccionado CON movimientos
        If Nivel <> NivelSeleccionado OR (Debe = 0 AND Haber = 0) Then
            Grid.RowHeight(Row) = 0  ' Ocultar fila
        End If
        
        ' 5. Sumar totales solo de nivel 1
        If Nivel = 1 Then
            SumTotal(C_DEBITOS) += Débitos
            SumTotal(C_CREDITOS) += Créditos
            SumTotal(C_DEUDOR) += SaldoDeudor
            SumTotal(C_ACREEDOR) += SaldoAcreedor
        End If
    Next Row
    
    ' 6. GridTot(0) - Sub Total
    GridTot(0).TextMatrix(0, C_CUENTA) = "Sub Total"
    GridTot(0).TextMatrix(0, C_DEBITOS) = SumTotal(C_DEBITOS)
    GridTot(0).TextMatrix(0, C_CREDITOS) = SumTotal(C_CREDITOS)
    GridTot(0).TextMatrix(0, C_DEUDOR) = SumTotal(C_DEUDOR)
    GridTot(0).TextMatrix(0, C_ACREEDOR) = SumTotal(C_ACREEDOR)
    
    ' 7. GridTot(1) - Utilidad o Pérdida
    GridTot(1).TextMatrix(0, C_CUENTA) = "Utilidad o Pérdida"
    Diff = SubTotal.Débitos - SubTotal.Créditos
    If Diff > 0 Then
        GridTot(1).TextMatrix(0, C_DEBITOS) = Diff
    Else
        GridTot(1).TextMatrix(0, C_CREDITOS) = Abs(Diff)
    End If
    
    Diff = SubTotal.Deudor - SubTotal.Acreedor
    If Diff > 0 Then
        GridTot(1).TextMatrix(0, C_DEUDOR) = Diff
    Else
        GridTot(1).TextMatrix(0, C_ACREEDOR) = Abs(Diff)
    End If
    
    ' 8. GridTot(2) - TOTALES
    GridTot(2).TextMatrix(0, C_CUENTA) = "TOTALES"
    GridTot(2).TextMatrix(0, C_DEBITOS) = GridTot(0) + GridTot(1)
    GridTot(2).TextMatrix(0, C_CREDITOS) = GridTot(0) + GridTot(1)
    GridTot(2).TextMatrix(0, C_DEUDOR) = GridTot(0) + GridTot(1)
    GridTot(2).TextMatrix(0, C_ACREEDOR) = GridTot(0) + GridTot(1)
End Sub
```

### Botones y Acciones

```vb
' Frame1 - Barra de herramientas
Bt_VerLibMayor     ' Ir a Libro Mayor de la cuenta seleccionada
Bt_Preview         ' Vista previa impresión
Bt_Print           ' Imprimir (con opción papel foliado)
Bt_CopyExcel       ' Copiar a Excel con membrete opcional
Bt_Sum             ' Sumar movimientos seleccionados
Bt_Calc            ' Calculadora
Bt_ConvMoneda      ' Convertidor de moneda
Bt_Calendar        ' Calendario
Bt_Email           ' Enviar por correo
Bt_Cerrar          ' Cerrar formulario
```

### Funciones de Impresión

```vb
Private Sub SetUpPrtGrid()
    ' Configurar encabezados
    Titulos(0) = "Balance de Comprobación y Saldos " & gEmpresa.Ano
    
    If LibroOficial Then
        Encabezados(0) = "LIBRO OFICIAL"
        ' Registra en log de libros impresos
        Call AppendLogImpreso(LIBOF_COMPYSALDOS, 0, Desde, Hasta)
    End If
    
    ' 3 líneas de totales
    gPrtLibros.NTotLines = 3
End Sub
```

## 🎨 Implementación .NET 9

### DTO Correcto (según VB6)

```csharp
public class BalanceComprobacionRowDto
{
    public int? IdCuenta { get; set; }
    public string Codigo { get; set; }
    public string Nombre { get; set; }
    public int Nivel { get; set; }
    
    // NO hay saldos iniciales!
    public decimal Debitos { get; set; }      // C_DEBITOS
    public decimal Creditos { get; set; }     // C_CREDITOS
    public decimal SaldoDeudor { get; set; }  // C_DEUDOR
    public decimal SaldoAcreedor { get; set; } // C_ACREEDOR
}

public class BalanceComprobacionTotalesDto
{
    // GridTot(0) - Sub Total
    public decimal SubTotalDebitos { get; set; }
    public decimal SubTotalCreditos { get; set; }
    public decimal SubTotalSaldoDeudor { get; set; }
    public decimal SubTotalSaldoAcreedor { get; set; }
    
    // GridTot(1) - Utilidad o Pérdida
    public decimal UtilidadPerdidaDebitos { get; set; }
    public decimal UtilidadPerdidaCreditos { get; set; }
    public decimal UtilidadPerdidaSaldoDeudor { get; set; }
    public decimal UtilidadPerdidaSaldoAcreedor { get; set; }
    
    // GridTot(2) - TOTALES
    public decimal TotalDebitos { get; set; }
    public decimal TotalCreditos { get; set; }
    public decimal TotalSaldoDeudor { get; set; }
    public decimal TotalSaldoAcreedor { get; set; }
}
```

## ✅ Migración Completada

La feature ha sido completamente migrada respetando fielmente el comportamiento VB6:

✅ Query jerárquica por niveles (UNION múltiple)  
✅ Solo movimientos del período (sin saldos iniciales)  
✅ Filtros: Nivel, TipoAjuste, ÁreaNeg, CCosto, LibroOficial  
✅ 3 grids de totales: SubTotal, Utilidad/Pérdida, TOTALES  
✅ Solo mostrar cuentas del nivel seleccionado con movimientos  
✅ Cálculo de saldos deudor/acreedor  
✅ Exportación CSV  
✅ Vista Tailwind CSS responsive

**Diferencia clave vs otros balances:** NO tiene columnas de saldo inicial/final, solo débitos/créditos del período y saldos resultantes.
