using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Extensions;
using App.Helpers;

namespace App.Features.BalanceDesglosado;

/// <summary>
/// MVC Controller para Balance Desglosado
/// </summary>
public class BalanceDesglosadoController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<BalanceDesglosadoController> logger) : Controller
{
    /// <summary>
    /// Vista principal del balance desglosado
    /// </summary>
    public IActionResult Index(string tipoDesglose = "AREANEG")
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder al Balance Desglosado";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        var empresaId = SessionHelper.EmpresaId;
        var ano = (short)SessionHelper.Ano;

        logger.LogInformation("Loading Balance Desglosado for empresaId: {EmpresaId}, año: {Ano}, tipo: {TipoDesglose}",
            empresaId, ano, tipoDesglose);

        var viewModel = new BalanceDesglosadoIndexViewModel
        {
            TipoDesglose = tipoDesglose,
            TipoDesgloseDescripcion = tipoDesglose == "AREANEG" ? "�rea de Negocio" : "Centro de Costo"
        };

        return View(viewModel);
    }

    /// <summary>
    /// Proxy: Obtener opciones de filtros (desgloses disponibles)
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetOpciones(int empresaId, short ano, string tipoDesglose)
    {
        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<BalanceDesglosadoApiController>(
            HttpContext,
            nameof(BalanceDesglosadoApiController.GetOpciones),
            new { empresaId, ano, tipoDesglose });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Proxy: Generar balance desglosado
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Generar([FromBody] JsonElement request)
    {
        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<BalanceDesglosadoApiController>(
            HttpContext,
            nameof(BalanceDesglosadoApiController.Generar));
        var (statusCode, content) = await client.ProxyRequestAsync(
            url!,
            request!,
            HttpMethod.Post);
        return StatusCode(statusCode, content);
    }

    /// <summary>
    /// Proxy: Exportar balance a Excel
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> ExportarExcel([FromBody] JsonElement request)
    {
        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<BalanceDesglosadoApiController>(
            HttpContext,
            nameof(BalanceDesglosadoApiController.ExportarExcel));
        var (fileBytes, contentType) = await client.DownloadFileAsync(
            url,
            HttpMethod.Post,
            request);
        return File(fileBytes, contentType);
    }
}