using Microsoft.AspNetCore.Mvc;

namespace App.Features.Comprobante;

[ApiController]
[Route("[controller]/[action]")]
public class ComprobanteApiController(
    IComprobanteService service,
    ILogger<ComprobanteApiController> logger) : ControllerBase
{
    [HttpPost]
    public async Task<ActionResult<ComprobanteDto>> Create([FromBody] ComprobanteCreateDto dto, [FromQuery] int empresaId, [FromQuery] int usuarioId)
    {
        logger.LogInformation("API: Create comprobante for empresa {EmpresaId}, usuarioId: {UsuarioId}", empresaId, usuarioId);

        // SmartExceptionFilter maneja automaticamente:
        // - BusinessException -> HTTP 400 + swalType: "warning"
        // - Exception -> HTTP 500 + swalType: "error" + log en BD
        var result = await service.CreateAsync(empresaId, usuarioId, dto);
        return Ok(result);
    }

    [HttpPut]
    public async Task<ActionResult<ComprobanteDto>> Update(int id, [FromBody] ComprobanteUpdateDto dto, [FromQuery] int usuarioId)
    {
        logger.LogInformation("API: Update comprobante {Id}", id);

        var result = await service.UpdateAsync(id, usuarioId, dto);
        return Ok(result);
    }

    [HttpGet]
    public async Task<ActionResult<ComprobanteDto>> GetById(int id)
    {
        logger.LogInformation("API: GetById {Id}", id);

        var result = await service.GetByIdAsync(id);
        return Ok(result);
    }

    [HttpDelete]
    public async Task<ActionResult> Delete(int id)
    {
        logger.LogInformation("API: Delete comprobante {Id}", id);

        await service.DeleteAsync(id);
        return Ok(new { message = "Comprobante eliminado (anulado) exitosamente" });
    }

    [HttpGet]
    public async Task<ActionResult<int>> GetNextCorrelative([FromQuery] int empresaId, [FromQuery] short ano, [FromQuery] int? tipo = null)
    {
        var result = await service.GetNextCorrelativeAsync(empresaId, ano, (byte?)tipo);
        return Ok(result);
    }

    [HttpPost]
    public async Task<ActionResult> Validate([FromBody] ComprobanteCreateDto dto)
    {
        // SmartExceptionFilter maneja BusinessException automáticamente
        await service.ValidateAsync(dto);
        return Ok(new { message = "Validación exitosa" });
    }

    [HttpGet]
    public async Task<ActionResult<TotalesDto>> CalculateTotals(int id)
    {
        var result = await service.CalculateTotalsAsync(id);
        return Ok(result);
    }

    [HttpPost]
    public async Task<ActionResult<MovimientoDto>> AddMovement(int id, [FromBody] MovimientoCreateDto dto)
    {
        logger.LogInformation("API: Add movement to comprobante {Id}", id);

        var result = await service.AddMovementAsync(id, dto);
        return Ok(result);
    }

    [HttpPut]
    public async Task<ActionResult<MovimientoDto>> UpdateMovement(int id, [FromBody] MovimientoUpdateDto dto)
    {
        logger.LogInformation("API: Update movement {Id}", id);

        var result = await service.UpdateMovementAsync(id, dto);
        return Ok(result);
    }

    [HttpDelete]
    public async Task<ActionResult> DeleteMovement(int id)
    {
        logger.LogInformation("API: Delete movement {Id}", id);

        await service.DeleteMovementAsync(id);
        return Ok(new { message = "Movimiento eliminado exitosamente" });
    }

    [HttpPost]
    public async Task<ActionResult<MovimientoDto>> DuplicateMovement(int id)
    {
        var result = await service.DuplicateMovementAsync(id);
        return Ok(result);
    }

    [HttpPost]
    public async Task<ActionResult> ReorderMovement(int id, [FromQuery] bool moveUp)
    {
        await service.ReorderMovementAsync(id, moveUp);
        return Ok(new { message = "Movimiento reordenado exitosamente" });
    }

    [HttpGet]
    public async Task<ActionResult<CuentaDto>> ValidateAccount([FromQuery] int empresaId, [FromQuery] short ano, [FromQuery] string? codigo)
    {
        logger.LogInformation("API: ValidateAccount called with empresaId={EmpresaId}, ano={Ano}, codigo={Codigo}",
            empresaId, ano, codigo);

        var result = await service.ValidateAccountAsync(empresaId, ano, codigo);
        logger.LogInformation("API: Account found - IdCuenta={IdCuenta}, Descripcion={Descripcion}",
            result.IdCuenta, result.Descripcion);
        return Ok(result);
    }

    [HttpGet]
    public async Task<ActionResult<List<CuentaDto>>> SearchAccounts([FromQuery] int empresaId, [FromQuery] short ano, [FromQuery] string? query)
    {
        var result = await service.SearchAccountsAsync(empresaId, ano, query);
        return Ok(result);
    }

    [HttpGet]
    public async Task<ActionResult<List<DocumentoDto>>> SearchDocuments([FromQuery] int empresaId, [FromQuery] DocumentoSearchDto searchDto)
    {
        var result = await service.SearchDocumentsAsync(empresaId, searchDto);
        return Ok(result);
    }

    [HttpPost]
    public async Task<ActionResult> AssignDocument(int id, [FromQuery] int idDocumento)
    {
        await service.AssignDocumentAsync(id, idDocumento);
        return Ok(new { message = "Documento asignado exitosamente" });
    }

    [HttpPost]
    public async Task<ActionResult> RemoveDocument(int id)
    {
        await service.RemoveDocumentAsync(id);
        return Ok(new { message = "Documento removido exitosamente" });
    }

    // ========== Nuevas funcionalidades migradas ==========

    [HttpPost]
    public async Task<ActionResult<ComprobanteDto>> GeneratePayment([FromQuery] int empresaId, [FromQuery] int usuarioId, [FromBody] GeneratePaymentDto dto)
    {
        logger.LogInformation("API: Generate payment for empresa {EmpresaId} with {Count} documents", empresaId, dto.IdDocumentos.Count);

        var result = await service.GeneratePaymentAsync(empresaId, usuarioId, dto.IdDocumentos);
        return Ok(result);
    }

    [HttpGet]
    public async Task<ActionResult> ExportToExcel(int id)
    {
        logger.LogInformation("API: Export comprobante {Id} to Excel", id);

        var fileBytes = await service.ExportToExcelAsync(id);
        var fileName = $"Comprobante_{id}_{DateTime.Now:yyyyMMdd}.xlsx";
        return File(fileBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
    }

    [HttpGet]
    public async Task<ActionResult> GenerateReport(int id, [FromQuery] bool resumido = false)
    {
        logger.LogInformation("API: Generate PDF report for comprobante {Id}, resumido={Resumido}", id, resumido);

        var pdfBytes = await service.GenerateReportAsync(id, resumido);
        var fileName = $"Comprobante_{id}_{DateTime.Now:yyyyMMdd}.pdf";
        return File(pdfBytes, "application/pdf", fileName);
    }

    [HttpPost]
    public async Task<ActionResult> GenerateCheque(int id, [FromBody] ChequeConfigDto config)
    {
        logger.LogInformation("API: Generate cheque PDF for comprobante {Id}", id);

        var pdfBytes = await service.GenerateChequePdfAsync(id, config);
        var fileName = $"Cheque_{id}_{DateTime.Now:yyyyMMdd}.pdf";
        return File(pdfBytes, "application/pdf", fileName);
    }

    [HttpPost]
    public async Task<ActionResult<ConversionMonedaDto>> ConvertCurrency([FromBody] ConvertCurrencyDto dto)
    {
        logger.LogInformation("API: Convert currency {From} to {To}, amount={Amount}", dto.FromCurrency, dto.ToCurrency, dto.Amount);

        var result = await service.ConvertCurrencyAsync(dto.Amount, dto.FromCurrency, dto.ToCurrency, dto.Date);
        return Ok(result);
    }

    [HttpGet]
    public async Task<ActionResult<List<GlosaDto>>> GetGlossaries([FromQuery] int empresaId)
    {
        logger.LogInformation("API: Get glossaries for empresa {EmpresaId}", empresaId);

        var result = await service.GetGlossariesAsync(empresaId);
        return Ok(result);
    }

    [HttpGet]
    public async Task<ActionResult<List<ComprobanteTipoDto>>> GetVoucherTypes([FromQuery] int empresaId)
    {
        logger.LogInformation("API: Get voucher types for empresa {EmpresaId}", empresaId);

        var result = await service.GetVoucherTypesAsync(empresaId);
        return Ok(result);
    }

    [HttpPost]
    public async Task<ActionResult<ComprobanteTipoDto>> CreateVoucherType([FromQuery] int empresaId, [FromBody] ComprobanteTipoCreateDto dto)
    {
        logger.LogInformation("API: Create voucher type '{Nombre}' for empresa {EmpresaId}", dto.Nombre, empresaId);

        var result = await service.CreateVoucherTypeAsync(empresaId, dto);
        return Ok(result);
    }

    [HttpPost]
    public async Task<ActionResult<ComprobanteTipoDto>> CreateVoucherTypeDirect([FromBody] ComprobanteTipoDirectCreateDto dto)
    {
        logger.LogInformation("API: Create voucher type directly '{Nombre}' for empresa {EmpresaId}",
            dto.Nombre, dto.EmpresaId);

        var result = await service.CreateVoucherTypeDirectAsync(dto);
        return Ok(result);
    }

    [HttpPost]
    public async Task<ActionResult<ComprobanteTipoDto>> CreateVoucherTypeFromCurrent([FromBody] CreateVoucherTypeFromCurrentDto dto)
    {
        logger.LogInformation("API: Create voucher type '{Nombre}' from comprobante {IdComp}", dto.Nombre, dto.IdComp);

        var result = await service.CreateVoucherTypeFromCurrentAsync(dto);
        return Ok(result);
    }

    [HttpGet]
    public async Task<ActionResult<ComprobanteDto>> LoadFromVoucherType(int id)
    {
        logger.LogInformation("API: Load comprobante from voucher type {Id}", id);

        var result = await service.LoadFromVoucherTypeAsync(id);
        return Ok(result);
    }

    [HttpGet]
    public async Task<ActionResult<CatalogsDto>> GetCatalogs([FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: GetCatalogs called with empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        var catalogs = await service.GetCatalogsAsync(empresaId, ano);
        logger.LogInformation("API: Returning catalogs with {AreasCount} areas and {CentrosCount} centros",
            catalogs.AreasNegocio.Count, catalogs.CentrosCosto.Count);
        return Ok(catalogs);
    }

    /// <summary>
    /// Asocia un documento a un movimiento de comprobante
    /// </summary>
    [HttpPut]
    public async Task<ActionResult> AsociarDocumentoAMovimiento(
        int idMov,
        [FromBody] AsociarDocumentoDto dto)
    {
        logger.LogInformation("API: AsociarDocumentoAMovimiento - idMov: {IdMov}, idDoc: {IdDoc}", idMov, dto.IdDoc);

        await service.AssignDocumentAsync(idMov, dto.IdDoc);
        return Ok(new { message = "Documento asociado correctamente al movimiento" });
    }

    // ========== Funcionalidades de Activo Fijo ==========
    // VB6: FrmComprobante.frm lines 1037-1066

    /// <summary>
    /// Verifica si una cuenta es de Activo Fijo
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<bool>> IsCuentaActivoFijo(int idCuenta)
    {
        logger.LogInformation("API: IsCuentaActivoFijo - idCuenta: {IdCuenta}", idCuenta);

        var result = await service.IsCuentaActivoFijoAsync(idCuenta);
        return Ok(new { isActivoFijo = result });
    }

    /// <summary>
    /// Obtiene los activos fijos asociados a un comprobante
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<List<ActivoFijoMovimientoDto>>> GetActivosFijos(
        int idComp,
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        logger.LogInformation("API: GetActivosFijos - idComp: {IdComp}, empresaId: {EmpresaId}, ano: {Ano}",
            idComp, empresaId, ano);

        var result = await service.GetActivosFijosAsync(idComp, empresaId, ano);
        return Ok(result);
    }

    /// <summary>
    /// Asigna un activo fijo a un movimiento
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<ActivoFijoMovimientoDto>> AsignarActivoFijo(int idMov, [FromBody] AsignarActivoFijoDto dto)
    {
        logger.LogInformation("API: AsignarActivoFijo - idMov: {IdMov}, idActFijo: {IdActFijo}", idMov, dto.IdActFijo);

        dto.IdMov = idMov;
        var result = await service.AsignarActivoFijoAsync(dto);
        return Ok(result);
    }

    /// <summary>
    /// Remueve un activo fijo de un movimiento
    /// </summary>
    [HttpDelete]
    public async Task<ActionResult> RemoverActivoFijo(int idCompFicha)
    {
        logger.LogInformation("API: RemoverActivoFijo - idCompFicha: {IdCompFicha}", idCompFicha);

        await service.RemoverActivoFijoAsync(idCompFicha);
        return Ok(new { message = "Activo fijo removido exitosamente" });
    }

    /// <summary>
    /// Cuenta los activos fijos asociados a un movimiento
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<int>> CountActivoFijo(int idMov)
    {
        logger.LogInformation("API: CountActivoFijo - idMov: {IdMov}", idMov);

        var count = await service.CountActivoFijoAsync(idMov);
        return Ok(new { count });
    }

    // ========== Crear Documento desde Movimiento ==========
    // VB6: FrmComprobante.frm lines 1615-1708

    /// <summary>
    /// Crea un documento desde un movimiento de comprobante
    /// VB6: FrmComprobante.Bt_NewDoc_Click() - Crea documento modal y lo asocia al movimiento
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<GestionDocumentos.DocumentoDto>> CreateDocumentFromMovimiento(int idMov, [FromBody] CreateDocumentoFromMovimientoDto dto)
    {
        logger.LogInformation("API: CreateDocumentFromMovimiento - idMov: {IdMov}, tipoLib: {TipoLib}", idMov, dto.TipoLib);

        var documento = await service.CreateDocumentFromMovimientoAsync(idMov, dto);
        return Ok(new
        {
            idDocumento = documento.IdDoc,
            numeroDoc = documento.NumDoc,
            tipoDocNombre = documento.TipoDocNombre,
            entidadNombre = documento.NombreEntidad,
            total = documento.Total,
            message = "Documento creado y asociado exitosamente"
        });
    }

    // ========== Validaciones ==========

    /// <summary>
    /// Verifica si una cuenta es de banco (conciliación)
    /// VB6: HyperCont.bas ValidIdCtaBanco()
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<bool>> IsCuentaBanco(int idCuenta)
    {
        logger.LogInformation("API: IsCuentaBanco - idCuenta: {IdCuenta}", idCuenta);

        var result = await service.IsCuentaBancoAsync(idCuenta);
        return Ok(new { isBanco = result });
    }

    /// <summary>
    /// Valida si un movimiento es editable (no est� centralizado ni es de pago)
    /// VB6: FrmComprobante.frm ValidarMovimientoEditable
    /// </summary>
    [HttpGet]
    public async Task<ActionResult> ValidateMovimientoEditable(int idMov)
    {
        logger.LogInformation("API: ValidateMovimientoEditable - idMov: {IdMov}", idMov);

        var result = await service.ValidarMovimientoEditable(idMov);
        return Ok(new { esEditable = result });
    }

    // ========== Notas de Movimientos ==========
    // VB6: M_AddNote_Click, M_EditNote_Click, M_ViewNote_Click, M_DelNote_Click (lines 4945-5020)

    /// <summary>
    /// Obtiene la nota de un movimiento
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<string?>> GetMovimientoNota(int idMov)
    {
        logger.LogInformation("API: GetMovimientoNota - idMov: {IdMov}", idMov);

        var nota = await service.GetMovimientoNotaAsync(idMov);
        return Ok(new { nota });
    }

    /// <summary>
    /// Guarda o actualiza la nota de un movimiento
    /// </summary>
    [HttpPut]
    public async Task<ActionResult> SaveMovimientoNota(int idMov, [FromBody] SaveNotaDto dto)
    {
        logger.LogInformation("API: SaveMovimientoNota - idMov: {IdMov}", idMov);

        await service.SaveMovimientoNotaAsync(idMov, dto.Nota);
        return Ok(new { message = "Nota guardada exitosamente" });
    }

    /// <summary>
    /// Elimina la nota de un movimiento
    /// </summary>
    [HttpDelete]
    public async Task<ActionResult> DeleteMovimientoNota(int idMov)
    {
        logger.LogInformation("API: DeleteMovimientoNota - idMov: {IdMov}", idMov);

        await service.DeleteMovimientoNotaAsync(idMov);
        return Ok(new { message = "Nota eliminada exitosamente" });
    }

    // ========== Ver Detalle de Documento ==========
    // VB6: Bt_DetMov_Click (lines 1382-1412)

    /// <summary>
    /// Obtiene el detalle completo del documento asociado a un movimiento
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<DocumentoDto>> GetDocumentoDetalleFromMovimiento(int idMov)
    {
        logger.LogInformation("API: GetDocumentoDetalleFromMovimiento - idMov: {IdMov}", idMov);

        var documento = await service.GetDocumentoDetalleFromMovimientoAsync(idMov);
        return Ok(documento);
    }

    // ========== Validaciones Avanzadas ==========
    // VB6: Valida() function (lines 4428-4832)

    /// <summary>
    /// Valida que el comprobante est� cuadrado (Debe = Haber)
    /// </summary>
    [HttpGet]
    public async Task<ActionResult> ValidateComprobanteCuadrado(int idComp)
    {
        logger.LogInformation("API: ValidateComprobanteCuadrado - idComp: {IdComp}", idComp);

        var (esValido, diferencia) = await service.ValidarComprobanteCuadradoAsync(idComp);
        return Ok(new
        {
            esValido,
            diferencia,
            mensaje = esValido ? "Comprobante cuadrado" : $"Comprobante descuadrado por {diferencia:N2}"
        });
    }

    /// <summary>
    /// Valida que todos los movimientos tengan cuenta asignada
    /// </summary>
    [HttpGet]
    public async Task<ActionResult> ValidateMovimientosTienenCuenta(int idComp)
    {
        logger.LogInformation("API: ValidateMovimientosTienenCuenta - idComp: {IdComp}", idComp);

        var (esValido, movimientosSinCuenta) = await service.ValidarMovimientosTienenCuentaAsync(idComp);
        return Ok(new
        {
            esValido,
            movimientosSinCuenta,
            mensaje = esValido ? "Todos los movimientos tienen cuenta" : $"Hay {movimientosSinCuenta.Count} movimientos sin cuenta"
        });
    }

    /// <summary>
    /// Valida que el comprobante tenga al menos un movimiento
    /// </summary>
    [HttpGet]
    public async Task<ActionResult> ValidateTieneMovimientos(int idComp)
    {
        logger.LogInformation("API: ValidateTieneMovimientos - idComp: {IdComp}", idComp);

        var esValido = await service.ValidarTieneMovimientosAsync(idComp);
        return Ok(new
        {
            esValido,
            mensaje = esValido ? "Comprobante tiene movimientos" : "Comprobante no tiene movimientos"
        });
    }

    /// <summary>
    /// Valida que la fecha est� en per�odo abierto
    /// </summary>
    [HttpGet]
    public async Task<ActionResult> ValidatePeriodoAbierto(
        [FromQuery] DateTime fecha,
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        logger.LogInformation("API: ValidatePeriodoAbierto - fecha: {Fecha}, empresaId: {EmpresaId}, ano: {Ano}",
            fecha, empresaId, ano);

        var esValido = await service.ValidarPeriodoAbiertoAsync(fecha, empresaId, ano);
        return Ok(new
        {
            esValido,
            mensaje = esValido ? "Período está abierto" : $"Período {fecha:MM/yyyy} está cerrado"
        });
    }

    /// <summary>
    /// Valida que la cuenta sea de banco para impresión de cheques
    /// </summary>
    [HttpGet]
    public async Task<ActionResult> ValidateCuentaBancoParaCheque(int idCuenta)
    {
        logger.LogInformation("API: ValidateCuentaBancoParaCheque - idCuenta: {IdCuenta}", idCuenta);

        var esValido = await service.ValidarCuentaBancoParaChequeAsync(idCuenta);
        return Ok(new
        {
            esValido,
            mensaje = esValido ? "Cuenta es de banco" : "Cuenta no es de tipo banco, no se puede imprimir cheque"
        });
    }

    // Navegación entre comprobantes (VB6: Bt_First, Bt_Prev, Bt_Next, Bt_Last)
    [HttpGet]
    public async Task<ActionResult> NavigateVoucher(
        [FromQuery] string? direction,
        [FromQuery] int? currentId,
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        logger.LogInformation("API: Navigate voucher direction={Direction}, currentId={CurrentId}", direction, currentId);

        var result = await service.NavigateVoucherAsync(direction, currentId, empresaId, ano);
        return Ok(result);
    }

    // Buscar comprobantes (VB6: Bt_Find)
    [HttpGet]
    public async Task<ActionResult> SearchVouchers(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        [FromQuery] int? correlativo = null,
        [FromQuery] int? tipo = null,
        [FromQuery] string? fechaDesde = null,
        [FromQuery] string? fechaHasta = null,
        [FromQuery] string? glosa = null,
        [FromQuery] int? estado = null)
    {
        logger.LogInformation("API: Search vouchers empresaId={EmpresaId}, ano={Ano}", empresaId, ano);

        var filters = new VoucherSearchFilters
        {
            EmpresaId = empresaId,
            Ano = ano,
            Correlativo = correlativo,
            Tipo = tipo,
            FechaDesde = fechaDesde,
            FechaHasta = fechaHasta,
            Glosa = glosa,
            Estado = estado
        };
        var results = await service.SearchVouchersAsync(filters);
        return Ok(results);
    }

    // ========== ENDPOINTS PARA INTEGRACión CON FEATURES EXISTENTES ==========

    /// <summary>
    /// Verifica si un movimiento tiene activo fijo asociado
    /// VB6: CountActFijo() - l�nea 6223
    /// Integración con: \app\Features\GestionActivoFijo
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<bool>> MovimientoTieneActivoFijo(int idMov)
    {
        var tieneActivo = await service.MovimientoTieneActivoFijoAsync(idMov);
        return Ok(tieneActivo);
    }

    /// <summary>
    /// Prepara datos para abrir GestionActivoFijo desde un movimiento
    /// VB6: Bt_ActivoFijo_Click() - l�nea 1802
    /// Integración con: \app\Features\GestionActivoFijo
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<ActivoFijoIntegrationDto>> PrepararActivoFijo(int idMov)
    {
        var data = await service.PrepararActivoFijoAsync(idMov);
        return Ok(data);
    }

    /// <summary>
    /// Prepara datos para imprimir cheque desde comprobante
    /// VB6: Bt_PrtCheque_Click() - l�nea 1908
    /// Integración con: \app\Features\ImpresionCheques
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<ChequeIntegrationDto>> PrepararImpresionCheque([FromBody] PrepararChequeDto dto)
    {
        var data = await service.PrepararImpresionChequeAsync(dto);
        return Ok(data);
    }

    /// <summary>
    /// Valida que los movimientos seleccionados puedan imprimir cheque
    /// VB6: Validaciones en Bt_PrtCheque_Click()
    /// Integración con: \app\Features\ImpresionCheques
    /// </summary>
    [HttpPost]
    public async Task<ActionResult> ValidarMovimientosParaCheque([FromBody] List<int> idMovimientos)
    {
        // SmartExceptionFilter maneja BusinessException automáticamente
        await service.ValidarMovimientosParaChequeAsync(idMovimientos);
        return Ok(new { message = "Movimientos válidos para impresión de cheque" });
    }

    /// <summary>
    /// Prepara datos para crear un nuevo documento desde un movimiento
    /// VB6: Bt_NewDoc_Click() - l�neas 1615-1706
    /// Integración con: \app\Features\GestionDocumentos
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<CrearDocumentoIntegrationDto>> PrepararCrearDocumento(int idMov)
    {
        var data = await service.PrepararCrearDocumentoAsync(idMov);
        return Ok(data);
    }

    /// <summary>
    /// Prepara datos para ver el detalle de un documento asociado a un movimiento
    /// VB6: Bt_DetMov_Click() - l�neas 1382-1410
    /// Integración con: \app\Features\GestionDocumentos
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<VerDocumentoIntegrationDto>> PrepararVerDocumento(int idMov)
    {
        var data = await service.PrepararVerDocumentoAsync(idMov);
        return Ok(data);
    }

    // ========== ENDPOINTS PARA CENTRALIZACIONES ==========

    /// <summary>
    /// Verifica si un comprobante es de centralización completa
    /// VB6: ValidaCompFull() - l�neas 6600-6619
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<bool>> EsCentralizacionFull(int idComp, [FromQuery] int empresaId, [FromQuery] short ano)
    {
        var result = await service.EsCentralizacionFullAsync(idComp, empresaId, ano);
        return Ok(result);
    }

    /// <summary>
    /// Marca un comprobante como centralización completa
    /// VB6: InsertComprCentraFull() - l�neas 6582-6598
    /// </summary>
    [HttpPost]
    public async Task<ActionResult> MarcarComoCentralizacionFull(int idComp, [FromQuery] int empresaId, [FromQuery] short ano)
    {
        await service.MarcarComoCentralizacionFullAsync(idComp, empresaId, ano);
        return Ok(new { message = "Comprobante marcado como centralización completa" });
    }

    /// <summary>
    /// Calcula los totales completos de un comprobante
    /// VB6: CalcTotFull() - l�neas 6526-6580
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<TotalesCentralizacionDto>> CalcularTotalesFull(int idComp, [FromQuery] int empresaId, [FromQuery] short ano)
    {
        var totales = await service.CalcularTotalesFullAsync(idComp, empresaId, ano);
        return Ok(totales);
    }

    /// <summary>
    /// Deja en cero todos los movimientos de un comprobante
    /// VB6: DejarEnCeroMovs() - l�neas 6337-6358
    /// </summary>
    [HttpPost]
    public async Task<ActionResult> DejarEnCeroMovimientos(int idComp, [FromQuery] int empresaId)
    {
        await service.DejarEnCeroMovimientosAsync(idComp, empresaId);
        return Ok(new { message = "Movimientos dejados en cero" });
    }

    /// <summary>
    /// Cuadra autom�ticamente un comprobante creando un movimiento de ajuste
    /// VB6: Bt_Cuadrar_Click - Cuadra autom�ticamente
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<ComprobanteDto>> BalanceVoucher(
        int idComp,
        [FromQuery] int movimientoIndex,
        [FromQuery] int idCuenta)
    {
        logger.LogInformation("API: BalanceVoucher - idComp: {IdComp}, movimientoIndex: {Index}, idCuenta: {IdCuenta}",
            idComp, movimientoIndex, idCuenta);

        var result = await service.BalanceVoucherAsync(idComp, movimientoIndex, idCuenta);
        return Ok(result);
    }

    /// <summary>
    /// Obtiene la fecha sugerida para un nuevo comprobante
    /// VB6: L�gica en FrmComprobante.frm l�neas 2443-2452
    /// GET /api/Comprobantee/fecha-sugerida?empresaId=1&amp;ano=2024
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<FechaSugeridaDto>> GetFechaSugerida([FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: GetFechaSugerida for empresa {EmpresaId}, ano {Ano}", empresaId, ano);

        var fecha = await service.GetFechaSugeridaAsync(empresaId, ano);
        var result = new FechaSugeridaDto { Fecha = fecha, FechaFormatted = fecha.ToString("dd/MM/yyyy") };
        return Ok(result);
    }

    /// <summary>
    /// Guarda un tipo de comprobante directamente
    /// </summary>
    [HttpPost]
    public Task<ActionResult> SaveVoucherTypeDirect([FromBody] object voucherTypeData)
    {
        logger.LogInformation("API: SaveVoucherTypeDirect");

        // TODO: Implementar lógica de guardado directo de tipo de comprobante
        return Task.FromResult<ActionResult>(Ok(new { message = "Método SaveVoucherTypeDirect pendiente de implementación", success = true }));
    }

    /// <summary>
    /// Valida un comprobante completo
    /// </summary>
    [HttpPost]
    public async Task<ActionResult> ValidateComprobante([FromBody] ComprobanteCreateDto dto)
    {
        logger.LogInformation("API: ValidateComprobante");

        // SmartExceptionFilter maneja BusinessException automáticamente
        await service.ValidateAsync(dto);
        return Ok(new { message = "Validación exitosa" });
    }

    // ========== ENDPOINTS PARA NUEVO DOCUMENTO ==========

    /// <summary>
    /// Obtiene los tipos de documento según el tipo de libro
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<List<TipoDocumentoDto>>> GetTiposDocumento([FromQuery] int tipoLib, [FromQuery] int empresaId)
    {
        logger.LogInformation("API: GetTiposDocumento - tipoLib: {TipoLib}", tipoLib);

        var tiposDoc = await service.GetTiposDocumentoAsync(tipoLib, empresaId);
        return Ok(tiposDoc);
    }

    /// <summary>
    /// Busca una entidad por RUT
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<EntidadBusquedaDto>> BuscarEntidadPorRut([FromQuery] string? rut, [FromQuery] int empresaId)
    {
        logger.LogInformation("API: BuscarEntidadPorRut - rut: {Rut}", rut);

        var entidad = await service.BuscarEntidadPorRutAsync(rut, empresaId);
        return Ok(entidad);
    }

    /// <summary>
    /// Crea un nuevo documento desde el modal de Comprobantee
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<DocumentoCreatedDto>> CrearDocumento([FromQuery] int empresaId, [FromQuery] short ano, [FromQuery] int usuarioId, [FromBody] CrearDocumentoDto dto)
    {
        logger.LogInformation("API: CrearDocumento - empresaId: {EmpresaId}, tipoLib: {TipoLib}", empresaId, dto.TipoLib);

        var documento = await service.CrearDocumentoAsync(empresaId, ano, usuarioId, dto);
        return Ok(documento);
    }
}

// DTOs adicionales

public class AsociarDocumentoDto
{
    public int IdDoc { get; set; }
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
}

public class SaveNotaDto
{
    public string? Nota { get; set; }
}

public class FechaSugeridaDto
{
    public DateTime Fecha { get; set; }
    public string FechaFormatted { get; set; } = string.Empty;
}
