using System.ComponentModel.DataAnnotations;

namespace App.Features.Comprobante;

/// <summary>
/// Constantes para tipos de comprobante (VB6: TC_*)
/// </summary>
public static class TipoComprobanteConstants
{
    public const byte Egreso = 1;
    public const byte Ingreso = 2;
    public const byte Traspaso = 3;
    public const byte Apertura = 4;

    public static readonly Dictionary<byte, string> Nombres = new()
    {
        { Egreso, "Egreso" },
        { Ingreso, "Ingreso" },
        { Traspaso, "Traspaso" },
        { Apertura, "Apertura" }
    };
}

/// <summary>
/// Constantes para estados de comprobante (VB6: EC_*)
/// </summary>
public static class EstadoComprobanteConstants
{
    public const byte Anulado = 1;
    public const byte Aprobado = 2;
    public const byte Pendiente = 3;
    public const byte Erroneo = 4;

    public static readonly Dictionary<byte, string> Nombres = new()
    {
        { Anulado, "Anulado" },
        { Aprobado, "Aprobado" },
        { Pendiente, "Pendiente" },
        { Erroneo, "Erróneo" }
    };
}

/// <summary>
/// Constantes para tipos de libro (VB6: LIB_*)
/// </summary>
public static class TipoLibroConstants
{
    public const int Compras = 1;
    public const int Ventas = 2;
    public const int Retenciones = 3;
    public const int Otros = 4;

    public static readonly Dictionary<int, string> Nombres = new()
    {
        { Compras, "Compras" },
        { Ventas, "Ventas" },
        { Retenciones, "Retenciones" },
        { Otros, "Otros" }
    };
}

/// <summary>
/// Constantes para estados de documento (VB6: ED_*)
/// </summary>
public static class EstadoDocumentoConstants
{
    public const int Pendiente = 0;
    public const int Pagado = 1;
    public const int Anulado = 2;
    public const int Centralizado = 3;

    public static readonly Dictionary<int, string> Nombres = new()
    {
        { Pendiente, "Pendiente" },
        { Pagado, "Pagado" },
        { Anulado, "Anulado" },
        { Centralizado, "Centralizado" }
    };
}

/// <summary>
/// Constantes para monedas (conversión)
/// </summary>
public static class MonedaConstants
{
    public const string PesoChileno = "$";
    public const string DolarUSA = "$US";
    public const string UF = "UF";
    public const string UTM = "UTM";

    public static readonly Dictionary<string, string> Nombres = new()
    {
        { PesoChileno, "Peso Chileno ($)" },
        { DolarUSA, "Dólar USA ($US)" },
        { UF, "UF" },
        { UTM, "UTM" }
    };
}

// Configuración de Correlativo (VB6: gTipoCorrComp y gPerCorrComp)
public class CorrelativoConfigDto
{
    public enum TipoCorrelativo
    {
        Unico = 1,      // TCC_UNICO - Correlativo �nico para todos los tipos
        PorTipo = 2     // TCC_TIPOCOMP - Correlativo separado por tipo de comprobante
    }
    
    public enum PeriodoCorrelativo
    {
        Continuo = 1,   // TCC_CONTINUO - No reinicia
        Anual = 2,      // TCC_ANUAL - Reinicia cada año (ya filtrado por Ano en WHERE)
        Mensual = 3     // TCC_MENSUAL - Reinicia cada mes
    }
    
    public TipoCorrelativo TipoCorr { get; set; } = TipoCorrelativo.PorTipo;      // Default: 2
    public PeriodoCorrelativo PeriodoCorr { get; set; } = PeriodoCorrelativo.Mensual;  // Default: 3
}

// DTOs principales
public class ComprobanteDto
{
    public int IdComp { get; set; }
    public int? IdEmpresa { get; set; }
    public int? Ano { get; set; }

    [Display(Name = "Correlativo")]
    public int? Correlativo { get; set; }

    [Required(ErrorMessage = "La fecha es obligatoria")]
    [Display(Name = "Fecha")]
    [DataType(DataType.Date)]
    public DateTime Fecha { get; set; }

    [Required(ErrorMessage = "El tipo es obligatorio")]
    [Display(Name = "Tipo")]
    public byte Tipo { get; set; }

    public string TipoDescripcion { get; set; } = string.Empty;

    [Required(ErrorMessage = "El estado es obligatorio")]
    [Display(Name = "Estado")]
    public byte Estado { get; set; }

    public string EstadoDescripcion { get; set; } = string.Empty;

    [Required(ErrorMessage = "La glosa es obligatoria")]
    [MaxLength(100, ErrorMessage = "La glosa no puede exceder 100 caracteres")]
    [Display(Name = "Glosa")]
    public string Glosa { get; set; } = string.Empty;
    
    public double? TotalDebe { get; set; }
    public double? TotalHaber { get; set; }
    public double? Diferencia { get; set; }  // Diferencia = TotalDebe - TotalHaber (VB6 txtDiferencia)
    
    public int? IdUsuario { get; set; }
    public string? NombreUsuario { get; set; }
    
    public DateTime? FechaCreacion { get; set; }
    
    public bool? ImpResumido { get; set; }
    public byte? TipoAjuste { get; set; }
    public bool? OtrosIngEg14TER { get; set; }
    
    public List<MovimientoDto> Movimientos { get; set; } = new List<MovimientoDto>();
}

// DTO para form HTML (patrón FormHandler)
public class ComprobanteFormDto
{
    [Required(ErrorMessage = "La fecha es obligatoria")]
    [Display(Name = "Fecha")]
    [DataType(DataType.Date)]
    public DateTime Fecha { get; set; }

    [Required(ErrorMessage = "El tipo es obligatorio")]
    [Display(Name = "Tipo")]
    public byte Tipo { get; set; }

    [Required(ErrorMessage = "El estado es obligatorio")]
    [Display(Name = "Estado")]
    public byte Estado { get; set; }

    [Required(ErrorMessage = "La glosa es obligatoria")]
    [MaxLength(100, ErrorMessage = "La glosa no puede exceder 100 caracteres")]
    [Display(Name = "Glosa")]
    public string Glosa { get; set; } = string.Empty;

    /// <summary>Correlativo sugerido (se conserva en postback)</summary>
    public int? Correlativo { get; set; }

    public bool ImpResumido { get; set; }
    public bool OtrosIngEg14TER { get; set; }

    /// <summary>Tipo de ajuste: 1=Financiero, 2=Tributario, 3=Ambos</summary>
    public byte? TipoAjuste { get; set; }

    public List<MovimientoFormDto> Movimientos { get; set; } = new();

    public ComprobanteDto ToComprobanteDto()
    {
        return new ComprobanteDto
        {
            Fecha = Fecha,
            Tipo = Tipo,
            Estado = Estado,
            Glosa = Glosa,
            ImpResumido = ImpResumido,
            OtrosIngEg14TER = OtrosIngEg14TER,
            TipoAjuste = TipoAjuste,
            Movimientos = Movimientos.Select(m => new MovimientoDto
            {
                IdMov = m.IdMov,
                IdCuenta = m.IdCuenta,
                Debe = m.Debe,
                Haber = m.Haber,
                Glosa = m.Glosa,
                IdDoc = m.IdDoc,
                IdCCosto = m.IdCCosto,
                IdAreaNegocio = m.IdAreaNegocio,
                IdDocCuota = m.IdDocCuota
            }).ToList()
        };
    }

    public ComprobanteViewModel ToComprobanteViewModel(int empresaId, int ano, int usuarioId)
    {
        return new ComprobanteViewModel
        {
            Fecha = Fecha,
            Tipo = Tipo,
            Estado = Estado,
            Glosa = Glosa,
            Correlativo = Correlativo,
            CorrelativoSugerido = Correlativo,
            ImpResumido = ImpResumido,
            OtrosIngEg14TER = OtrosIngEg14TER,
            TipoAjuste = TipoAjuste,
            EmpresaId = empresaId,
            Ano = ano,
            UsuarioId = usuarioId,
            TiposComprobante = TipoComprobanteConstants.Nombres,
            EstadosComprobante = EstadoComprobanteConstants.Nombres,
            TiposLibro = TipoLibroConstants.Nombres,
            EstadosDocumento = EstadoDocumentoConstants.Nombres,
            Monedas = MonedaConstants.Nombres,
            Movimientos = Movimientos.Select(m => new MovimientoItemViewModel
            {
                IdMov = m.IdMov,
                IdCuenta = m.IdCuenta,
                CodigoCuenta = m.CodigoCuenta,
                NombreCuenta = m.NombreCuenta,
                Debe = m.Debe,
                Haber = m.Haber,
                Glosa = m.Glosa,
                IdDoc = m.IdDoc,
                IdCCosto = m.IdCCosto,
                IdAreaNegocio = m.IdAreaNegocio,
                IdDocCuota = m.IdDocCuota,
                TipoDocumento = m.TipoDocumento,
                NumeroDocumento = m.NumeroDocumento,
                EntidadNombre = m.EntidadNombre
            }).ToList()
        };
    }
}

// DTO para movimiento en form HTML
public class MovimientoFormDto
{
    public int IdMov { get; set; }

    [Required(ErrorMessage = "La cuenta es obligatoria")]
    [Display(Name = "Cuenta")]
    public int IdCuenta { get; set; }

    // Campo auxiliar para búsqueda de cuenta (no se envía al servidor para guardar)
    public string? CodigoCuenta { get; set; }
    public string? NombreCuenta { get; set; }

    [Range(0, double.MaxValue, ErrorMessage = "El debe no puede ser negativo")]
    [Display(Name = "Debe")]
    public double Debe { get; set; }

    [Range(0, double.MaxValue, ErrorMessage = "El haber no puede ser negativo")]
    [Display(Name = "Haber")]
    public double Haber { get; set; }

    [MaxLength(255)]
    [Display(Name = "Glosa")]
    public string? Glosa { get; set; }

    public int? IdDoc { get; set; }
    public int? IdCCosto { get; set; }
    public int? IdAreaNegocio { get; set; }
    public int? IdDocCuota { get; set; }

    // Campos de solo lectura para mostrar info del documento asociado
    public string? TipoDocumento { get; set; }
    public string? NumeroDocumento { get; set; }
    public string? EntidadNombre { get; set; }
}

// DTO para crear un comprobante
public class ComprobanteCreateDto
{
    [Required]
    public int IdEmpresa { get; set; }
    
    [Required]
    public short Ano { get; set; }
    
    [Required]
    public DateTime Fecha { get; set; }
    
    [Required]
    public byte Tipo { get; set; }
    
    [Required]
    public byte Estado { get; set; }
    
    [Required]
    [MaxLength(100)]
    public string Glosa { get; set; } = string.Empty;
    
    public bool? ImpResumido { get; set; }
    public byte? TipoAjuste { get; set; }
    public bool? OtrosIngEg14TER { get; set; }
    
    public List<MovimientoCreateDto> Movimientos { get; set; } = new List<MovimientoCreateDto>();
}

// DTO para actualizar un comprobante
public class ComprobanteUpdateDto
{
    [Required]
    public DateTime Fecha { get; set; }
    
    [Required]
    public byte Tipo { get; set; }
    
    [Required]
    public byte Estado { get; set; }
    
    [Required]
    [MaxLength(100)]
    public string Glosa { get; set; } = string.Empty;
    
    public bool? ImpResumido { get; set; }
    public byte? TipoAjuste { get; set; }
    public bool? OtrosIngEg14TER { get; set; }
    
    public List<MovimientoUpdateDto> Movimientos { get; set; } = new List<MovimientoUpdateDto>();
}

// DTO de movimiento
public class MovimientoDto
{
    public int IdMov { get; set; }
    public int? IdEmpresa { get; set; }
    public int? Ano { get; set; }
    public int? IdComp { get; set; }
    public int? Orden { get; set; }
    
    public int? IdCuenta { get; set; }
    public string? CodigoCuenta { get; set; }
    public string? NombreCuenta { get; set; }
    
    [Range(0, double.MaxValue, ErrorMessage = "El debe no puede ser negativo")]
    public double? Debe { get; set; }

    [Range(0, double.MaxValue, ErrorMessage = "El haber no puede ser negativo")]
    public double? Haber { get; set; }
    
    [MaxLength(255)]
    public string? Glosa { get; set; }
    
    public int? IdCCosto { get; set; }
    public string? NombreCCosto { get; set; }
    
    public int? IdAreaNegocio { get; set; }
    public string? NombreAreaNegocio { get; set; }
    
    public int? IdDoc { get; set; }
    public string? NumDocumento { get; set; }
    public string? NombreEntidad { get; set; }
    public int? TipoLib { get; set; }
    public int? TipoDoc { get; set; }
    public string? TipoDocDiminutivo { get; set; }
    
    // Campos para cuotas de documentos
    public int? IdDocCuota { get; set; }
    public short? NumCuota { get; set; }
    public double? MontoCuota { get; set; }
    
    // Campos para Activo Fijo (VB6: C_DETACTFIJO)
    public int? IdActFijo { get; set; }
    public string? DescripcionActFijo { get; set; }
    public bool TieneActivoFijo { get; set; }

    // Flags especiales (VB6: C_DECENTRALIZ, C_DEPAGO)
    public bool DeCentralizacion { get; set; }
    public bool DePagoAutomatico { get; set; }

    // Campo para notas (VB6: C_NOTA)
    public string? Nota { get; set; }
}

// DTO para crear movimiento
public class MovimientoCreateDto
{
    [Required]
    public int IdCuenta { get; set; }

    [Range(0, double.MaxValue)]
    public double Debe { get; set; }

    [Range(0, double.MaxValue)]
    public double Haber { get; set; }
    
    [MaxLength(255)]
    public string? Glosa { get; set; }
    
    public int? IdCCosto { get; set; }
    public int? IdAreaNegocio { get; set; }
    public int? IdDoc { get; set; }
    public int? IdDocCuota { get; set; }
}

// DTO para actualizar movimiento
public class MovimientoUpdateDto
{
    public int IdMov { get; set; }

    [Required]
    public int IdCuenta { get; set; }

    [Range(0, double.MaxValue)]
    public double Debe { get; set; }

    [Range(0, double.MaxValue)]
    public double Haber { get; set; }
    
    [MaxLength(255)]
    public string? Glosa { get; set; }
    
    public int? IdCCosto { get; set; }
    public int? IdAreaNegocio { get; set; }
    public int? IdDoc { get; set; }
    public int? IdDocCuota { get; set; }
}

// DTO para totales
public class TotalesDto
{
    public double? TotalDebe { get; set; }
    public double? TotalHaber { get; set; }
    public double? Diferencia { get; set; }
    public bool Balanceado { get; set; }
}

// DTO para validación - ELIMINADO - Ahora se usa BusinessException

// DTO para cuenta
public class CuentaDto
{
    public int IdCuenta { get; set; }
    public string Codigo { get; set; } = string.Empty;
    public string Nombre { get; set; } = string.Empty;
    public string Descripcion { get; set; } = string.Empty;
    public int? Nivel { get; set; }
    public bool EsUltimoNivel { get; set; }
    public int? Clasificacion { get; set; }
}

// DTO para documento
public class DocumentoDto
{
    public int IdDoc { get; set; }
    public int? TipoLib { get; set; }
    public int? TipoDoc { get; set; }
    public string NumDoc { get; set; } = string.Empty;
    public string? RutEntidad { get; set; }
    public string? NombreEntidad { get; set; }
    public DateTime? FechaEmision { get; set; }
    public DateTime? FechaVencimiento { get; set; }
    public double? Total { get; set; }
    public double? SaldoDoc { get; set; }
    public bool DTE { get; set; }

    // Montos sugeridos para el movimiento contable (calculados por el backend)
    // Lógica VB6: Si SaldoDoc > 0 -> Haber, Si SaldoDoc < 0 -> Debe
    public double? MontoSugeridoDebe { get; set; }
    public double? MontoSugeridoHaber { get; set; }
}

// DTO para glosas predefinidas
public class GlosaDto
{
    public int IdGlosa { get; set; }
    public string Glosa { get; set; } = string.Empty;
}

// DTO para comprobante tipo (plantilla) - listado
public class ComprobanteTipoDto
{
    public int IdCompTipo { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public string Descripcion { get; set; } = string.Empty;
    public int Tipo { get; set; }
    public string Glosa { get; set; } = string.Empty;
    public List<MovimientoCreateDto> Movimientos { get; set; } = new List<MovimientoCreateDto>();
}

/// <summary>
/// DTO completo para edición de plantilla (CT_Comprobante + CT_MovComprobante)
/// </summary>
public class ComprobanteTipoDetailDto
{
    public int IdComp { get; set; }
    public int IdEmpresa { get; set; }
    public string? Nombre { get; set; }
    public string? Descrip { get; set; }
    public int? Tipo { get; set; }
    public string? Glosa { get; set; }
    public decimal? TotalDebe { get; set; }
    public decimal? TotalHaber { get; set; }
    public List<MovimientoPlantillaDetailDto> Movimientos { get; set; } = new();
}

/// <summary>
/// DTO para movimiento de plantilla con datos completos
/// </summary>
public class MovimientoPlantillaDetailDto
{
    public int IdMov { get; set; }
    public int? Orden { get; set; }
    public int? IdCuenta { get; set; }
    public string? CodCuenta { get; set; }
    public string? NombreCuenta { get; set; }
    public decimal? Debe { get; set; }
    public decimal? Haber { get; set; }
    public string? Glosa { get; set; }
    public int? IdCCosto { get; set; }
    public string? NombreCentroCosto { get; set; }
    public int? IdAreaNeg { get; set; }
    public string? NombreAreaNegocio { get; set; }
}

// DTO para crear comprobante tipo
public class ComprobanteTipoCreateDto
{
    [Required]
    [MaxLength(15)]
    public string Nombre { get; set; } = string.Empty;

    [MaxLength(40)]
    public string? Descripcion { get; set; }

    [Required]
    public int Tipo { get; set; }

    [MaxLength(100)]
    public string? Glosa { get; set; }

    public int IdComprobanteOrigen { get; set; }
}

// DTO para crear plantilla desde comprobante actual (VB6: Bt_NewCompTipo)
public class CreateVoucherTypeFromCurrentDto
{
    [Required]
    public int IdComp { get; set; }

    [Required]
    [MaxLength(15)]
    public string Nombre { get; set; } = string.Empty;

    [Required]
    [MaxLength(40)]
    public string Descripcion { get; set; } = string.Empty;

    [MaxLength(15)]
    public string? NombreCorto { get; set; }

    public bool ConValores { get; set; }

    public int Tipo { get; set; }

    [MaxLength(100)]
    public string? Glosa { get; set; }
}

// DTO para crear plantilla directamente con movimientos (desde formulario nuevo)
public class ComprobanteTipoDirectCreateDto
{
    public int EmpresaId { get; set; }

    [Required]
    [MaxLength(15)]
    public string Nombre { get; set; } = string.Empty;

    [MaxLength(40)]
    public string? Descripcion { get; set; }

    [Required]
    public int Tipo { get; set; }

    [MaxLength(100)]
    public string? Glosa { get; set; }

    [Required]
    public List<MovimientoPlantillaDto> Movimientos { get; set; } = new();
}

// DTO para movimiento en plantilla
public class MovimientoPlantillaDto
{
    public int IdCuenta { get; set; }
    public double Debe { get; set; }
    public double Haber { get; set; }
    public string? Glosa { get; set; }
}

// DTO para b�squeda de documentos
public class DocumentoSearchDto
{
    public int? TipoLib { get; set; }
    public int? TipoDoc { get; set; }
    public int? Estado { get; set; }
    public string? RutEntidad { get; set; }
    public DateTime? FechaDesde { get; set; }
    public DateTime? FechaHasta { get; set; }
}

// DTO para conversión de moneda
public class ConversionMonedaDto
{
    public double Monto { get; set; }
    public string MonedaOrigen { get; set; } = "CLP";
    public string MonedaDestino { get; set; } = "UF";
    public DateTime Fecha { get; set; }
    public double TasaCambio { get; set; }
    public double MontoConvertido { get; set; }
}

// DTO para generación de pagos
public class GeneratePaymentDto
{
    public List<int> IdDocumentos { get; set; } = new();
    public string? Glosa { get; set; }
    public DateTime? FechaPago { get; set; }
    public int? IdCuentaPago { get; set; }
}

// DTO para conversión de moneda (request)
public class ConvertCurrencyDto
{
    public double Amount { get; set; }
    public string FromCurrency { get; set; } = "CLP";
    public string ToCurrency { get; set; } = "UF";
    public DateTime Date { get; set; }
}

// DTO para cat�logos (dropdown data)
public class CatalogsDto
{
    public List<AreaNegocioDto> AreasNegocio { get; set; } = new();
    public List<CentroCostoDto> CentrosCosto { get; set; } = new();
}

// DTO para �rea de negocio
public class AreaNegocioDto
{
    public int IdAreaNeg { get; set; }
    public string Descripcion { get; set; } = string.Empty;
}

// DTO para centro de costo
public class CentroCostoDto
{
    public int IdCCosto { get; set; }
    public string Descripcion { get; set; } = string.Empty;
}

// ==================== DTOs para Activo Fijo ====================

// DTO para Activo Fijo asociado a movimiento
public class ActivoFijoMovimientoDto
{
    public int IdCompFicha { get; set; }
    public int IdActFijo { get; set; }
    public int? IdGrupo { get; set; }
    public string? NombreActivo { get; set; }
    public string? DescripcionGrupo { get; set; }
    public double? ValorCompra { get; set; }
    public double? PjeDivComp { get; set; }  // Porcentaje de división del comprobante
    public DateTime? FechaAdquisicion { get; set; }
}

// DTO para asociar activo fijo a movimiento
public class AsignarActivoFijoDto
{
    [Required]
    public int IdMov { get; set; }
    
    [Required]
    public int IdActFijo { get; set; }

    public int? IdGrupo { get; set; }

    [Range(0, 100)]
    public double? PjeDivComp { get; set; }

    public double? ValorCompra { get; set; }
    public double? ValorResidual { get; set; }
    public double? PjeAmortizacion { get; set; }
    public short? VidaUtil { get; set; }
}

// DTO para crear nuevo documento desde movimiento
public class CreateDocumentoFromMovimientoDto
{
    [Required]
    public int TipoLib { get; set; }  // LIB_COMPRAS o LIB_VENTAS

    public int? TipoDoc { get; set; }
    public int? IdEntidad { get; set; }
    public string? RutEntidad { get; set; }
    public DateTime? FechaEmision { get; set; }
    public DateTime? FechaVencimiento { get; set; }
    public string? NumDoc { get; set; }
    public string? Descripcion { get; set; }
}

// DTO para filtros de b�squeda de comprobantes (VB6: Bt_Find)
public class VoucherSearchFilters
{
    [Required]
    public int EmpresaId { get; set; }

    [Required]
    public short Ano { get; set; }

    public int? Correlativo { get; set; }
    public int? Tipo { get; set; }
    public string? FechaDesde { get; set; }
    public string? FechaHasta { get; set; }
    public string? Glosa { get; set; }
    public int? Estado { get; set; }
}

// DTO para resultado de b�squeda de comprobantes
public class VoucherSearchResultDto
{
    public int IdComp { get; set; }
    public int? Correlativo { get; set; }
    public string? Fecha { get; set; }
    public byte Tipo { get; set; }
    public string? Glosa { get; set; }
    public double? TotalDebe { get; set; }
    public double? TotalHaber { get; set; }
    public byte Estado { get; set; }
}

// ========== DTOs PARA INTEGRACión CON FEATURES EXISTENTES ==========

/// <summary>
/// DTO para integración con GestionActivoFijo
/// VB6: FrmComprobante.frm - ActivoFijo() (l�neas 6098-6222)
/// </summary>
public class ActivoFijoIntegrationDto
{
    public int IdMov { get; set; }
    public int IdEmpresa { get; set; }
    public short Ano { get; set; }
    public int? IdActivoFijo { get; set; }
    public bool TieneActivoAsociado { get; set; }

    // Datos del movimiento para pre-cargar
    public int? IdCuenta { get; set; }
    public double? Debe { get; set; }
    public double? Haber { get; set; }
    public string? Glosa { get; set; }
}

/// <summary>
/// DTO para preparar impresión de cheque
/// VB6: FrmComprobante.frm - Bt_PrtCheque_Click() (l�neas 1908-2024)
/// </summary>
public class PrepararChequeDto
{
    public int IdComp { get; set; }
    public List<int> IdMovimientos { get; set; } = new();
}

/// <summary>
/// DTO para integración con ImpresionCheques
/// VB6: FrmComprobante.frm - Bt_PrtCheque_Click()
/// </summary>
public class ChequeIntegrationDto
{
    public int IdComp { get; set; }
    public int IdEmpresa { get; set; }
    public DateTime Fecha { get; set; }
    public string? Glosa { get; set; }
    public double Monto { get; set; }
    public List<int> IdMovimientos { get; set; } = new();
    public int NumeroMovimientos { get; set; }
    public List<MovimientoChequeDto> DetalleMovimientos { get; set; } = new();
}

/// <summary>
/// DTO para detalle de movimiento en cheque
/// </summary>
public class MovimientoChequeDto
{
    public int IdMov { get; set; }
    public string? Glosa { get; set; }
    public double Monto { get; set; }
}

// ========== INTEGRACión CON GESTION DOCUMENTOS ==========

/// <summary>
/// DTO para preparar creación de documento desde movimiento
/// VB6: Bt_NewDoc_Click() - l�neas 1615-1706
/// </summary>
public class CrearDocumentoIntegrationDto
{
    public int IdMov { get; set; }
    public int IdComp { get; set; }
    public int IdEmpresa { get; set; }
    public short Ano { get; set; }
    public int Mes { get; set; }
    public double Monto { get; set; }
    public int? IdEntidad { get; set; }
    public byte? TipoLibEntidad { get; set; }
    public string? Glosa { get; set; }
}

/// <summary>
/// DTO para preparar visualización de documento desde movimiento
/// VB6: Bt_DetMov_Click() - l�neas 1382-1410
/// </summary>
public class VerDocumentoIntegrationDto
{
    public int IdDoc { get; set; }
    public int IdMov { get; set; }
    public int IdEmpresa { get; set; }
    public short Ano { get; set; }
    public byte TipoDoc { get; set; }
    public int? IdDocCuota { get; set; }
}

// ========== CENTRALIZACIONES ==========

/// <summary>
/// DTO para totales de centralización completa
/// VB6: CalcTotFull() - l�neas 6526-6580
/// </summary>
public class TotalesCentralizacionDto
{
    public double? TotalDebe { get; set; }
    public double? TotalHaber { get; set; }
    public double? Diferencia { get; set; }
    public bool EsCentralizacionFull { get; set; }
}

// ========== CENTRALIZACIONES ==========

/// <summary>
/// DTO para totales de centralización completa
/// VB6: CalcTotFull() - l�neas 6526-6580
/// </summary>
// public class TotalesCentralizacionDto
// {
//     public decimal TotalDebe { get; set; }
//     public decimal TotalHaber { get; set; }
//     public decimal Diferencia { get; set; }
//     public bool EsCentralizacionFull { get; set; }
// }

// ========== DTOs PARA NUEVO DOCUMENTO ==========

/// <summary>
/// DTO para tipo de documento
/// </summary>
public class TipoDocumentoDto
{
    public int TipoDoc { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public string Codigo { get; set; } = string.Empty;
}

/// <summary>
/// DTO para búsqueda de entidad
/// </summary>
public class EntidadBusquedaDto
{
    public int IdEntidad { get; set; }
    public string Rut { get; set; } = string.Empty;
    public string Nombre { get; set; } = string.Empty;
    public int? Clasificacion { get; set; }
}

/// <summary>
/// DTO para crear documento desde Comprobantee
/// </summary>
public class CrearDocumentoDto
{
    public int TipoLib { get; set; }
    public int TipoDoc { get; set; }
    public string NumDoc { get; set; } = string.Empty;
    public DateTime FechaEmision { get; set; }
    public int? IdEntidad { get; set; }
    public double Monto { get; set; }
    public int Estado { get; set; } = 1;
    public string? Observaciones { get; set; }
    public bool DTE { get; set; }
}

/// <summary>
/// DTO extendido para respuesta de creación de documento con nombres
/// </summary>
public class DocumentoCreatedDto
{
    public int IdDoc { get; set; }
    public int TipoLib { get; set; }
    public int TipoDoc { get; set; }
    public string TipoDocNombre { get; set; } = string.Empty;
    public string NumDoc { get; set; } = string.Empty;
    public DateTime FechaEmision { get; set; }
    public int? IdEntidad { get; set; }
    public string? RutEntidad { get; set; }
    public string? NombreEntidad { get; set; }
    public double Total { get; set; }
    public double SaldoDoc { get; set; }
    public bool DTE { get; set; }
}

// ==================== DTOs PARA LISTADO DE COMPROBANTES ====================

/// <summary>
/// DTO para item en listado de comprobantes
/// </summary>
public class ComprobanteListItemDto
{
    public int IdComp { get; set; }
    public int? Correlativo { get; set; }
    public DateTime? Fecha { get; set; }
    public string TipoDescripcion { get; set; } = "";
    public byte? Tipo { get; set; }
    public string EstadoDescripcion { get; set; } = "";
    public byte? Estado { get; set; }
    public decimal? TotalDebe { get; set; }
    public decimal? TotalHaber { get; set; }
    public string? Glosa { get; set; }
    public string TipoAjusteDescripcion { get; set; } = "";
    public byte? TipoAjuste { get; set; }
    public string? Usuario { get; set; }
    public DateTime? FechaImport { get; set; }
    public bool Selected { get; set; }
    public string FechaFormatted => Fecha?.ToString("dd/MM/yyyy") ?? "";
    public string FechaImportFormatted => FechaImport?.ToString("dd/MM/yyyy") ?? "";
    public string TotalDebeFormatted => TotalDebe?.ToString("N0") ?? "0";
    public string TotalHaberFormatted => TotalHaber?.ToString("N0") ?? "0";
}

/// <summary>
/// DTO para filtros de búsqueda en listado
/// </summary>
public class ComprobanteListFilterDto
{
    [Display(Name = "N° Comprobante")]
    public int? NumeroComprobante { get; set; }

    [Display(Name = "Tipo")]
    public byte? Tipo { get; set; }

    [Display(Name = "Estado")]
    public byte? Estado { get; set; }

    [Display(Name = "Tipo Ajuste")]
    public byte? TipoAjuste { get; set; }

    [Display(Name = "Fecha Desde")]
    [DataType(DataType.Date)]
    public DateTime? FechaDesde { get; set; }

    [Display(Name = "Fecha Hasta")]
    [DataType(DataType.Date)]
    public DateTime? FechaHasta { get; set; }

    [Display(Name = "Glosa")]
    [StringLength(500, ErrorMessage = "La glosa no puede exceder los 500 caracteres")]
    public string? Glosa { get; set; }

    [Display(Name = "Tipo Libro")]
    public byte? TipoLib { get; set; }

    [Display(Name = "Tipo Documento")]
    public byte? TipoDoc { get; set; }

    [Display(Name = "N° Documento")]
    [StringLength(20, ErrorMessage = "El número de documento no puede exceder los 20 caracteres")]
    public string? NumDoc { get; set; }

    [Display(Name = "Valor Movimiento")]
    [Range(0, double.MaxValue, ErrorMessage = "El valor debe ser mayor o igual a 0")]
    public decimal? Valor { get; set; }

    [Display(Name = "Cuenta")]
    public int? IdCuenta { get; set; }

    [Display(Name = "RUT Entidad")]
    [StringLength(12, ErrorMessage = "El RUT no puede exceder los 12 caracteres")]
    public string? Rut { get; set; }

    [Display(Name = "Entidad")]
    public int? IdEntidad { get; set; }

    [Display(Name = "Sucursal")]
    public int? IdSucursal { get; set; }

    [Display(Name = "Solo DTE")]
    public bool EsDTE { get; set; }

    public string SortBy { get; set; } = "Fecha";
    public bool SortDescending { get; set; } = false;
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 25;
}

/// <summary>
/// DTO para resultado paginado del listado
/// </summary>
public class ComprobanteListResultDto
{
    public List<ComprobanteListItemDto> Items { get; set; } = new();
    public int TotalCount { get; set; }
    public int Page { get; set; }
    public int PageSize { get; set; }
    public int TotalPages => (int)Math.Ceiling((double)TotalCount / PageSize);
    public bool HasNext => Page < TotalPages;
    public bool HasPrevious => Page > 1;
    public decimal TotalDebe { get; set; }
    public decimal TotalHaber { get; set; }
}

/// <summary>
/// DTO para detalle completo del comprobante
/// </summary>
public class ComprobanteDetalleDto
{
    public int IdComp { get; set; }
    public int? Correlativo { get; set; }
    public DateTime? Fecha { get; set; }
    public byte? Tipo { get; set; }
    public string TipoDescripcion { get; set; } = "";
    public byte? Estado { get; set; }
    public string EstadoDescripcion { get; set; } = "";
    public byte? TipoAjuste { get; set; }
    public string TipoAjusteDescripcion { get; set; } = "";
    public decimal? TotalDebe { get; set; }
    public decimal? TotalHaber { get; set; }
    public string? Glosa { get; set; }
    public string? Usuario { get; set; }
    public List<MovimientoDetalleDto> Movimientos { get; set; } = new();
}

/// <summary>
/// DTO para movimiento en detalle
/// </summary>
public class MovimientoDetalleDto
{
    public int IdMov { get; set; }
    public int? Orden { get; set; }
    public string? CodigoCuenta { get; set; }
    public string? NombreCuenta { get; set; }
    public decimal? Debe { get; set; }
    public decimal? Haber { get; set; }
    public string? Glosa { get; set; }
    public string? AreaNegocio { get; set; }
    public string? CentroCosto { get; set; }
    public string? NumDoc { get; set; }
    public string? TipoDoc { get; set; }
    public string? Entidad { get; set; }
}

/// <summary>
/// DTO para acciones masivas en listado
/// </summary>
public class ComprobanteListActionsDto
{
    public List<int> SelectedIds { get; set; } = new();
    public byte? NewEstado { get; set; }
    public bool ExportarConDetalle { get; set; }
    public int? MesDestino { get; set; }
}

/// <summary>
/// DTO para actualización masiva de glosas
/// </summary>
public class ActualizarGlosaMasivaDto
{
    public List<int> SelectedIds { get; set; } = new();
    public string NuevaGlosa { get; set; } = "";
}

/// <summary>
/// DTO para conversión de moneda masiva
/// </summary>
public class ConvertirMonedaMasivaDto
{
    public List<int> SelectedIds { get; set; } = new();
    public int IdMonedaDestino { get; set; }
    public decimal TipoCambio { get; set; }
}

/// <summary>
/// DTO para resultado de conversión
/// </summary>
public class ConversionResultDto
{
    public int ComprobantesAfectados { get; set; }
    public int MovimientosConvertidos { get; set; }
    public decimal TotalOriginal { get; set; }
    public decimal TotalConvertido { get; set; }
}

/// <summary>
/// DTO para tipo de comprobante (dropdown)
/// </summary>
public class TipoComprobanteListDto
{
    public byte Id { get; set; }
    public string Descripcion { get; set; } = "";
}

/// <summary>
/// DTO para estado de comprobante (dropdown)
/// </summary>
public class EstadoComprobanteListDto
{
    public byte Id { get; set; }
    public string Descripcion { get; set; } = "";
}

/// <summary>
/// DTO para tipo de ajuste (dropdown)
/// </summary>
public class TipoAjusteListDto
{
    public byte Id { get; set; }
    public string Descripcion { get; set; } = "";
}

#region ViewModels

/// <summary>
/// ViewModel para la vista Index de Comprobante
/// </summary>
public class ComprobanteIndexViewModel
{
    public int EmpresaId { get; set; }
    public int Ano { get; set; }
    public string Title { get; set; } = null!;
}

#endregion
