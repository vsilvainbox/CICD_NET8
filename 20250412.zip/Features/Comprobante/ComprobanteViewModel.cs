using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Microsoft.AspNetCore.Mvc;

namespace App.Features.Comprobante;

/// <summary>
/// ViewModel completo para la vista de Nuevo/Editar Comprobante
/// Incluye datos del formulario + datos precargados + validaciones de negocio
/// Soporta modo plantilla (CT_Comprobante) cuando IsTemplate=true
/// </summary>
public class ComprobanteViewModel : IValidatableObject
{
    // ==================== ESTADO ====================

    /// <summary>Indica si la vista es solo lectura (detalle)</summary>
    public bool IsReadOnly { get; set; }

    /// <summary>
    /// Indica si estamos trabajando con plantillas (CT_Comprobante) en lugar de comprobantes normales.
    /// VB6: FrmComprobante.FNew(True) / FrmComprobante.FEdit(IdComp, True)
    /// </summary>
    public bool IsTemplate { get; set; }

    /// <summary>Es nuevo si no tiene IdComp</summary>
    public bool IsNew => !IdComprobante.HasValue;

    /// <summary>Es edición si tiene IdComp y no es solo lectura</summary>
    public bool IsEdit => IdComprobante.HasValue && !IsReadOnly;

    /// <summary>Es vista de detalle si tiene IdComp y es solo lectura</summary>
    public bool IsView => IdComprobante.HasValue && IsReadOnly;

    /// <summary>ID del comprobante (solo en edicion/vista)</summary>
    public int? IdComprobante { get; set; }

    /// <summary>Alias para IdComprobante (compatibilidad con vistas)</summary>
    public int? IdComp
    {
        get => IdComprobante;
        set => IdComprobante = value;
    }

    /// <summary>Correlativo del comprobante</summary>
    public int? Correlativo { get; set; }

    // ==================== DATOS PRECARGADOS (GET) ====================

    /// <summary>Correlativo sugerido para nuevo comprobante</summary>
    public int? CorrelativoSugerido { get; set; }

    /// <summary>Fecha sugerida basada en último comprobante</summary>
    public DateTime FechaSugerida { get; set; } = DateTime.Today;

    /// <summary>Catálogo de tipos de comprobante</summary>
    public Dictionary<byte, string> TiposComprobante { get; set; } = new();

    /// <summary>Catálogo de estados de comprobante</summary>
    public Dictionary<byte, string> EstadosComprobante { get; set; } = new();

    /// <summary>Catálogo de tipos de libro</summary>
    public Dictionary<int, string> TiposLibro { get; set; } = new();

    /// <summary>Catálogo de estados de documento</summary>
    public Dictionary<int, string> EstadosDocumento { get; set; } = new();

    /// <summary>Catálogo de monedas</summary>
    public Dictionary<string, string> Monedas { get; set; } = new();

    /// <summary>Estado por defecto para nuevos comprobantes</summary>
    public byte EstadoDefault { get; set; } = 1;

    /// <summary>ID de empresa actual (de sesión)</summary>
    public int EmpresaId { get; set; }

    /// <summary>Año contable actual (de sesión)</summary>
    public int Ano { get; set; }

    /// <summary>ID de usuario actual (de sesión)</summary>
    public int UsuarioId { get; set; }

    // ==================== DATOS DEL FORMULARIO (POST) ====================

    /// <summary>
    /// Nombre de la plantilla. Solo requerido cuando IsTemplate=true.
    /// VB6: CT_Comprobante.Nombre
    /// </summary>
    [StringLength(50, ErrorMessage = "El nombre no puede exceder 50 caracteres")]
    [Display(Name = "Nombre de Plantilla")]
    public string? Nombre { get; set; }

    [DataType(DataType.Date)]
    [Display(Name = "Fecha")]
    public DateTime Fecha { get; set; } = DateTime.Today;

    [Required(ErrorMessage = "El tipo es obligatorio")]
    [Display(Name = "Tipo")]
    public byte Tipo { get; set; }

    [Display(Name = "Estado")]
    public byte Estado { get; set; }

    [StringLength(100, ErrorMessage = "La glosa no puede exceder 100 caracteres")]
    [Display(Name = "Glosa")]
    public string Glosa { get; set; } = string.Empty;

    [Display(Name = "Impresión Resumida")]
    public bool ImpResumido { get; set; }

    [Display(Name = "Otros Ingresos/Egresos 14 TER")]
    public bool OtrosIngEg14TER { get; set; }

    /// <summary>Tipo de ajuste: 1=Financiero, 2=Tributario, 3=Ambos</summary>
    [Display(Name = "Tipo de Ajuste")]
    public byte? TipoAjuste { get; set; }

    // ==================== MOVIMIENTOS ====================

    [MinLength(1, ErrorMessage = "Debe ingresar al menos un movimiento")]
    public List<MovimientoItemViewModel> Movimientos { get; set; } = new();

    // ==================== PROPIEDADES CALCULADAS ====================

    /// <summary>Total columna Debe</summary>
    public decimal TotalDebe => Movimientos.Sum(m => (decimal)m.Debe);

    /// <summary>Total columna Haber</summary>
    public decimal TotalHaber => Movimientos.Sum(m => (decimal)m.Haber);

    /// <summary>Diferencia entre Debe y Haber</summary>
    public decimal Diferencia => TotalDebe - TotalHaber;

    /// <summary>Indica si el comprobante está cuadrado</summary>
    public bool EstaCuadrado => Math.Abs(Diferencia) < 0.01m;

    /// <summary>Cantidad de movimientos</summary>
    public int CantidadMovimientos => Movimientos.Count;

    // ==================== URLS PARA JAVASCRIPT ====================

    /// <summary>URLs de endpoints para uso en JavaScript</summary>
    public ComprobanteUrlsViewModel Urls { get; set; } = new();

    // ==================== VALIDACION DE NEGOCIO ====================

    public IEnumerable<System.ComponentModel.DataAnnotations.ValidationResult> Validate(
        System.ComponentModel.DataAnnotations.ValidationContext validationContext)
    {
        var results = new List<System.ComponentModel.DataAnnotations.ValidationResult>();

        // 0. Si es plantilla, validar que tenga nombre
        if (IsTemplate && string.IsNullOrWhiteSpace(Nombre))
        {
            results.Add(new System.ComponentModel.DataAnnotations.ValidationResult(
                "El nombre de la plantilla es obligatorio",
                new[] { nameof(Nombre) }));
        }

        // 1. Validar que haya al menos un movimiento
        if (Movimientos == null || Movimientos.Count == 0)
        {
            results.Add(new System.ComponentModel.DataAnnotations.ValidationResult(
                "Debe ingresar al menos un movimiento",
                new[] { nameof(Movimientos) }));
            return results; // No continuar si no hay movimientos
        }

        // 2. Validar que el comprobante este cuadrado (solo para comprobantes normales, no plantillas)
        if (!IsTemplate && !EstaCuadrado)
        {
            results.Add(new System.ComponentModel.DataAnnotations.ValidationResult(
                $"El comprobante no esta cuadrado. Diferencia: {Diferencia:N2}",
                new[] { nameof(Movimientos) }));
        }

        // 3. Validar que todos los movimientos tengan cuenta valida
        var movimientosSinCuenta = Movimientos
            .Select((m, index) => new { Movimiento = m, Fila = index + 1 })
            .Where(x => x.Movimiento.IdCuenta == 0)
            .ToList();

        if (movimientosSinCuenta.Any())
        {
            var filas = string.Join(", ", movimientosSinCuenta.Select(x => x.Fila));
            results.Add(new System.ComponentModel.DataAnnotations.ValidationResult(
                $"Los siguientes movimientos no tienen cuenta valida: filas {filas}",
                new[] { nameof(Movimientos) }));
        }

        // 4. Validar que cada movimiento tenga Debe o Haber (no ambos, no ninguno)
        var movimientosInvalidos = Movimientos
            .Select((m, index) => new { Movimiento = m, Fila = index + 1 })
            .Where(x => (x.Movimiento.Debe == 0 && x.Movimiento.Haber == 0) ||
                       (x.Movimiento.Debe > 0 && x.Movimiento.Haber > 0))
            .ToList();

        if (movimientosInvalidos.Any())
        {
            var filas = string.Join(", ", movimientosInvalidos.Select(x => x.Fila));
            results.Add(new System.ComponentModel.DataAnnotations.ValidationResult(
                $"Cada movimiento debe tener Debe o Haber (no ambos ni vacio): filas {filas}",
                new[] { nameof(Movimientos) }));
        }

        return results;
    }

    // ==================== MÉTODOS DE CONVERSIÓN ====================

    /// <summary>Convierte a DTO para enviar a la API</summary>
    public object ToApiPayload()
    {
        return new
        {
            idEmpresa = EmpresaId,
            ano = Ano,
            fecha = Fecha.ToString("yyyy-MM-dd"),
            tipo = Tipo,
            estado = Estado,
            glosa = Glosa,
            impResumido = ImpResumido,
            otrosIngEg14TER = OtrosIngEg14TER,
            isTemplate = IsTemplate,
            nombre = Nombre,
            movimientos = Movimientos.Select(m => new
            {
                idMov = m.IdMov > 0 ? m.IdMov : (int?)null,
                idCuenta = m.IdCuenta,
                codigoCuenta = m.CodigoCuenta,
                debe = m.Debe,
                haber = m.Haber,
                glosa = m.Glosa,
                idDoc = m.IdDoc,
                idCCosto = m.IdCCosto,
                idAreaNegocio = m.IdAreaNegocio,
                idDocCuota = m.IdDocCuota
            }).ToList()
        };
    }
}

/// <summary>
/// ViewModel para cada movimiento/línea del comprobante
/// </summary>
public class MovimientoItemViewModel
{
    public int IdMov { get; set; }

    [Required(ErrorMessage = "La cuenta es obligatoria")]
    [Remote(action: "ValidarCuentaRemote", controller: "Comprobante",
            AdditionalFields = nameof(CodigoCuenta),
            ErrorMessage = "Cuenta no encontrada en el sistema")]
    [Display(Name = "Cuenta")]
    public int IdCuenta { get; set; }

    /// <summary>Código de cuenta para búsqueda (no se persiste)</summary>
    public string? CodigoCuenta { get; set; }

    /// <summary>Nombre de cuenta (solo display)</summary>
    public string? NombreCuenta { get; set; }

    [Range(0, double.MaxValue, ErrorMessage = "El debe no puede ser negativo")]
    [Display(Name = "Debe")]
    public double Debe { get; set; }

    [Range(0, double.MaxValue, ErrorMessage = "El haber no puede ser negativo")]
    [Display(Name = "Haber")]
    public double Haber { get; set; }

    [StringLength(255, ErrorMessage = "La glosa no puede exceder 255 caracteres")]
    [Display(Name = "Glosa")]
    public string? Glosa { get; set; }

    // Datos de documento asociado
    public int? IdDoc { get; set; }
    public string? TipoDocumento { get; set; }
    public string? NumeroDocumento { get; set; }
    public int? IdEntidad { get; set; }
    public string? EntidadNombre { get; set; }

    // Datos adicionales
    public int? IdCCosto { get; set; }
    public string? NombreCentroCosto { get; set; }
    public int? IdAreaNegocio { get; set; }
    public string? NombreAreaNegocio { get; set; }
    public int? IdDocCuota { get; set; }

    /// <summary>Indica si tiene activo fijo asociado</summary>
    public bool TieneActivoFijo { get; set; }
}

/// <summary>
/// URLs de endpoints para JavaScript
/// </summary>
public class ComprobanteUrlsViewModel
{
    public string GetMovimientoRow { get; set; } = string.Empty;
    public string ValidarCuenta { get; set; } = string.Empty;
    public string SearchAccounts { get; set; } = string.Empty;
    public string SearchDocuments { get; set; } = string.Empty;
    public string Home { get; set; } = string.Empty;
}
