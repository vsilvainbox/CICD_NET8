namespace App.Features.Comprobante;

/// <summary>
/// Servicio para verificación de permisos y privilegios de usuario
/// Mapeo VB6: ChkPriv() function
/// </summary>
public interface IPermisosService
{
    /// <summary>
    /// Verifica si el usuario tiene privilegio para anular comprobantes
    /// VB6: ChkPriv(PRV_ADM_COMP)
    /// </summary>
    /// <param name="idUsuario">ID del usuario a verificar</param>
    /// <param name="idEmpresa">ID de la empresa (para permisos por empresa)</param>
    /// <returns>True si tiene privilegio, False si no</returns>
    Task<bool> TienePrivilegioAnularAsync(int idUsuario, int idEmpresa);

    /// <summary>
    /// Verifica si el usuario es administrador del sistema
    /// VB6: PrivAdm = -1
    /// </summary>
    /// <param name="idUsuario">ID del usuario a verificar</param>
    /// <returns>True si es admin, False si no</returns>
    Task<bool> EsAdministradorAsync(int idUsuario);

    /// <summary>
    /// Obtiene los privilegios completos del usuario para una empresa
    /// VB6: Perfiles.Privilegios
    /// </summary>
    /// <param name="idUsuario">ID del usuario</param>
    /// <param name="idEmpresa">ID de la empresa</param>
    /// <returns>Máscara de bits con privilegios</returns>
    Task<int> GetPrivilegiosAsync(int idUsuario, int idEmpresa);
}