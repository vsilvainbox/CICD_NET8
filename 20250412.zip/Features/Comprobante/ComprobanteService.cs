using Microsoft.EntityFrameworkCore;
using App.Data;
using App.Exceptions;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using App.Features.GestionActivoFijo;
using App.Features.ImpresionCheques;
using App.Features.GestionDocumentos;
using App.Helpers;

namespace App.Features.Comprobante;

public class ComprobanteService(
    LpContabContext context,
    ILogger<ComprobanteService> logger,
    IPermisosService permisosService,
    IPdfReportService pdfReportService,
    IGestionActivoFijoService activoFijoService,
    IImpresionChequesService chequesService,
    IGestionDocumentosService documentosService) : IComprobanteService
{
    private readonly IGestionActivoFijoService _activoFijoService = activoFijoService;
    private readonly IImpresionChequesService _chequesService = chequesService;

    // ========== CRUD Principal ==========

    /// <summary>
    /// Crea un nuevo comprobante con asignaci?n de correlativo al final para minimizar gaps.
    ///
    /// NOTA SOBRE GAPS EN CORRELATIVOS:
    /// Este m?todo minimiza (pero no elimina completamente) los gaps en correlativos al asignar
    /// el n?mero lo m?s tarde posible en el proceso. Los gaps pueden a?n ocurrir si:
    /// 1. La transacci?n falla DESPU?S de asignar el correlativo pero ANTES del commit final
    /// 2. Dos usuarios crean comprobantes simult?neamente y uno hace rollback
    ///
    /// Los gaps son comportamiento est?ndar en sistemas transaccionales y son aceptables.
    /// </summary>
    public async Task<ComprobanteDto> CreateAsync(int empresaId, int usuarioId, ComprobanteCreateDto dto)
    {
        logger.LogInformation("Creating comprobante for empresa {EmpresaId}, usuario {UsuarioId}",
            empresaId, usuarioId);

        // ?? TRANSACCI?N SERIALIZABLE para prevenir race conditions en correlativo
        // VB6: BeginTrans ? Do While ? CommitTrans (l?neas 3732-3821)
        using var transaction = await context.Database.BeginTransactionAsync(
            System.Data.IsolationLevel.Serializable);

        {
            // ? PASO 1: VALIDAR ANTES de tocar la base de datos
            // Esto previene rollbacks por validaciones fallidas
            await ValidateAsync(dto, usuarioId, empresaId);

            // ? PASO 2: Crear comprobante con correlativo temporal -1 (a?n NO guardado)
            // VB6: Correlativo = -1 (marca temporal para evitar colisiones)
            var comprobante = new App.Data.Comprobante
            {
                IdEmpresa = empresaId,
                Ano = dto.Ano,
                Correlativo = -1, // ?? TEMPORAL - se actualizar? al final
                Fecha = DateToInt(dto.Fecha),
                Tipo = dto.Tipo,
                Estado = dto.Estado,
                Glosa = dto.Glosa,
                IdUsuario = usuarioId,
                FechaCreacion = DateToInt(DateTime.Now),
                ImpResumido = dto.ImpResumido,
                TipoAjuste = dto.TipoAjuste,
                OtrosIngEg14TER = dto.OtrosIngEg14TER
            };

            // Agregar a EF Core context (en memoria, no persiste a?n)
            context.Comprobante.Add(comprobante);

            // ? PASO 3: PRIMERA PERSISTENCIA - Guardar comprobante para obtener IdComp
            // IMPORTANTE: A?n con Correlativo=-1 temporal
            await context.SaveChangesAsync();

            logger.LogInformation("Comprobante created with temporary IdComp {IdComp}, Correlativo=-1 (temporal)",
                comprobante.IdComp);

            // ? PASO 4: Crear movimientos ahora que tenemos IdComp
            var orden = 1;
            double totalDebe = 0;
            double totalHaber = 0;

            foreach (var movDto in dto.Movimientos)
            {
                var movimiento = new App.Data.MovComprobante
                {
                    IdEmpresa = empresaId,
                    Ano = dto.Ano,
                    IdComp = comprobante.IdComp, // Ahora tenemos el IdComp
                    Orden = orden++,
                    IdCuenta = movDto.IdCuenta,
                    Debe = movDto.Debe,
                    Haber = movDto.Haber,
                    Glosa = movDto.Glosa,
                    idCCosto = movDto.IdCCosto,
                    idAreaNeg = movDto.IdAreaNegocio,
                    IdDoc = movDto.IdDoc,
                    IdDocCuota = movDto.IdDocCuota
                };

                context.MovComprobante.Add(movimiento);
                totalDebe += movDto.Debe;
                totalHaber += movDto.Haber;
            }

            // Actualizar totales
            comprobante.TotalDebe = totalDebe;
            comprobante.TotalHaber = totalHaber;

            // ? PASO 5: ASIGNACI?N DE CORRELATIVO (lo m?s tarde posible para minimizar gaps)
            // VB6: Do While loop con verificaci?n de duplicados (l?neas 3756-3813)
            var correlativoFinal = await GetNextCorrelativeWithLockAsync(
                empresaId, dto.Ano, dto.Tipo, comprobante.IdComp);

            // ? PASO 6: Actualizar con correlativo real y guardar movimientos
            comprobante.Correlativo = correlativoFinal;
            await context.SaveChangesAsync(); // Guarda correlativo Y movimientos

            logger.LogInformation("Comprobante {IdComp} assigned final Correlativo {Correlativo}",
                comprobante.IdComp, correlativoFinal);

            // ? PASO 7: COMMIT - Confirmar toda la transacci?n
            await transaction.CommitAsync();

            logger.LogInformation("Comprobante {IdComp} saved successfully with Correlativo {Correlativo}, {Count} movements, TotalDebe={TotalDebe}, TotalHaber={TotalHaber}",
                comprobante.IdComp, correlativoFinal, dto.Movimientos.Count, totalDebe, totalHaber);

            return await GetByIdAsync(comprobante.IdComp)
                ?? throw new BusinessException("Error retrieving created comprobante");
        }
    }

    public async Task<ComprobanteDto> UpdateAsync(int id, int usuarioId, ComprobanteUpdateDto dto)
    {
        logger.LogInformation("Updating comprobante {IdComp}", id);

        // ?? TRANSACCI?N para garantizar atomicidad en la actualizaci?n
        // Previene inconsistencias si falla despu?s de borrar movimientos
        using var transaction = await context.Database.BeginTransactionAsync(
            System.Data.IsolationLevel.ReadCommitted);

        {
            var comprobante = await context.Comprobante.FindAsync(id);
            if (comprobante == null)
            {
                throw new BusinessException($"Comprobante {id} not found");
            }

            // ===== VALIDACIONES B?SICAS (similares a CreateAsync) =====
            var errors = new List<string>();

            // Validar al menos un movimiento
            if (!dto.Movimientos.Any())
            {
                errors.Add("Debe ingresar al menos un movimiento");
            }

            // Validar balance
            var totalDebeValidacion = dto.Movimientos.Sum(m => m.Debe);
            var totalHaberValidacion = dto.Movimientos.Sum(m => m.Haber);

            if (Math.Abs(totalDebeValidacion - totalHaberValidacion) > 0.01)
            {
                errors.Add("Los totales de las columnas DEBE y HABER no son iguales");
            }

            // Validar atributos de cuentas
            var lineaNum = 1;
            foreach (var mov in dto.Movimientos)
            {
                if (mov.IdCuenta <= 0)
                {
                    errors.Add($"En la l?nea {lineaNum} falta ingresar la cuenta");
                    lineaNum++;
                    continue;
                }

                // Obtener atributos de cuenta
                var cuenta = await context.Cuentas
                    .FirstOrDefaultAsync(c => c.IdEmpresa == comprobante.IdEmpresa
                                           && c.Ano == comprobante.Ano
                                           && c.idCuenta == mov.IdCuenta);

                if (cuenta != null)
                {
                    // ATRIB_RUT = 1 (requiere documento/entidad) - VB6 l?neas 4655-4656, 4684-4691
                    // Solo aplica si NO es apertura y tiene monto
                    var tieneMontos = mov.Debe > 0 || mov.Haber > 0;
                    var noEsApertura = dto.Tipo != 4; // TC_APERTURA = 4

                    if (noEsApertura && tieneMontos && (cuenta.Atrib1 == (byte?)1 || cuenta.Atrib2 == (byte?)1))
                    {
                        if (!mov.IdDoc.HasValue || mov.IdDoc.Value == 0)
                        {
                            errors.Add($"En la l?nea {lineaNum} falta ingresar el detalle de documento asociado y entidad correspondiente");
                        }
                    }

                    // Validar ATRIB_AREANEG (requiere ?rea negocio)
                    if (cuenta.Atrib1 == (byte?)2 || cuenta.Atrib2 == (byte?)2)
                    {
                        if (!mov.IdAreaNegocio.HasValue || mov.IdAreaNegocio.Value == 0)
                        {
                            errors.Add($"En la l?nea {lineaNum} falta ingresar el ?rea de Negocio");
                        }
                    }

                    // Validar ATRIB_CCOSTO (requiere centro costo)
                    if (cuenta.Atrib1 == (byte?)3 || cuenta.Atrib2 == (byte?)3)
                    {
                        if (!mov.IdCCosto.HasValue || mov.IdCCosto.Value == 0)
                        {
                            errors.Add($"En la l?nea {lineaNum} falta ingresar el Centro de Costo");
                        }
                    }
                }

                lineaNum++;
            }

            if (errors.Any())
            {
                throw new BusinessException($"Validaci?n fallida: {string.Join("; ", errors)}");
            }

            // Update header
            comprobante.Fecha = DateToInt(dto.Fecha);
            comprobante.Tipo = dto.Tipo;
            comprobante.Estado = dto.Estado;
            comprobante.Glosa = dto.Glosa;
            comprobante.ImpResumido = dto.ImpResumido;
            comprobante.TipoAjuste = dto.TipoAjuste;
            comprobante.OtrosIngEg14TER = dto.OtrosIngEg14TER;

            // Delete existing movements
            var existingMovs = await context.MovComprobante
                .Where(m => m.IdComp == id)
                .ToListAsync();

            context.MovComprobante.RemoveRange(existingMovs);

            // Create new movements
            var orden = 1;
            double totalDebe = 0;
            double totalHaber = 0;

            foreach (var movDto in dto.Movimientos)
            {
                var movimiento = new App.Data.MovComprobante
                {
                    IdEmpresa = comprobante.IdEmpresa,
                    Ano = comprobante.Ano,
                    IdComp = comprobante.IdComp,
                    Orden = orden++,
                    IdCuenta = movDto.IdCuenta,
                    Debe = movDto.Debe,
                    Haber = movDto.Haber,
                    Glosa = movDto.Glosa,
                    idCCosto = movDto.IdCCosto,
                    idAreaNeg = movDto.IdAreaNegocio,
                    IdDoc = movDto.IdDoc,
                    IdDocCuota = movDto.IdDocCuota
                };

                context.MovComprobante.Add(movimiento);
                totalDebe += movDto.Debe;
                totalHaber += movDto.Haber;
            }

            // Update totals
            comprobante.TotalDebe = totalDebe;
            comprobante.TotalHaber = totalHaber;

            await context.SaveChangesAsync();

            // ? COMMIT: Confirmar todos los cambios
            await transaction.CommitAsync();

            logger.LogInformation("Comprobante {IdComp} updated successfully with {Count} movements, TotalDebe={TotalDebe}, TotalHaber={TotalHaber}",
                id, dto.Movimientos.Count, totalDebe, totalHaber);

            return await GetByIdAsync(id)
                ?? throw new BusinessException("Error retrieving updated comprobante");
        }
    }

    public async Task<ComprobanteDto?> GetByIdAsync(int id)
    {
        logger.LogInformation("Getting comprobante {IdComp}", id);

        var comprobante = await context.Comprobante
            .Where(c => c.IdComp == id)
            .FirstOrDefaultAsync();

        if (comprobante == null)
            throw new BusinessException($"Comprobante {id} no encontrado");

            var movimientos = await context.MovComprobante
                .Where(m => m.IdComp == id)
                .OrderBy(m => m.Orden)
                .ToListAsync();

            var dto = new ComprobanteDto
            {
                IdComp = comprobante.IdComp,
                IdEmpresa = comprobante.IdEmpresa,
                Ano = comprobante.Ano,
                Correlativo = comprobante.Correlativo,
                Fecha = IntToDate(comprobante.Fecha) ?? DateTime.Now,
                Tipo = comprobante.Tipo ?? 0,
                Estado = comprobante.Estado ?? 0,
                Glosa = comprobante.Glosa ?? string.Empty,
                TotalDebe = comprobante.TotalDebe,
                TotalHaber = comprobante.TotalHaber,
                IdUsuario = comprobante.IdUsuario,
                FechaCreacion = IntToDate(comprobante.FechaCreacion),
                ImpResumido = comprobante.ImpResumido,
                TipoAjuste = comprobante.TipoAjuste,
                OtrosIngEg14TER = comprobante.OtrosIngEg14TER
            };

            // Load movements with related data
            foreach (var mov in movimientos)
            {
                var cuenta = await context.Cuentas.FindAsync(mov.IdEmpresa, mov.Ano, mov.IdCuenta);

                var movDto = new MovimientoDto
                {
                    IdMov = mov.IdMov,
                    IdEmpresa = mov.IdEmpresa,
                    Ano = mov.Ano,
                    IdComp = mov.IdComp,
                    Orden = mov.Orden,
                    IdCuenta = mov.IdCuenta,
                    CodigoCuenta = cuenta?.Codigo,
                    NombreCuenta = cuenta?.Descripcion,
                    Debe = mov.Debe,
                    Haber = mov.Haber,
                    Glosa = mov.Glosa,
                    IdCCosto = mov.idCCosto,
                    IdAreaNegocio = mov.idAreaNeg,
                    IdDoc = mov.IdDoc,
                    IdDocCuota = mov.IdDocCuota,
                    Nota = mov.Nota,

                    // Flags especiales (VB6: C_DECENTRALIZ, C_DEPAGO)
                    DeCentralizacion = mov.DeCentraliz == true,
                    DePagoAutomatico = mov.DePago == true
                };

                // Load related entities if needed
                if (mov.idCCosto.HasValue)
                {
                    var cCosto = await context.CentroCosto.FindAsync(mov.idCCosto.Value);
                    movDto.NombreCCosto = cCosto?.Descripcion;
                }

                if (mov.idAreaNeg.HasValue)
                {
                    var areaNeg = await context.AreaNegocio.FindAsync(mov.idAreaNeg.Value);
                    movDto.NombreAreaNegocio = areaNeg?.Descripcion;
                }

                if (mov.IdDoc.HasValue)
                {
                    var doc = await context.Documento.FindAsync(mov.IdDoc.Value);
                    movDto.NumDocumento = doc?.NumDoc;
                    movDto.TipoLib = doc?.TipoLib;
                    movDto.TipoDoc = doc?.TipoDoc;
                    
                    // Get tipo documento diminutivo
                    if (doc?.TipoLib.HasValue == true && doc?.TipoDoc.HasValue == true)
                    {
                        var tipoDoc = await context.TipoDocs
                            .FirstOrDefaultAsync(t => t.TipoLib == doc.TipoLib && t.TipoDoc == doc.TipoDoc);
                        movDto.TipoDocDiminutivo = tipoDoc?.Diminutivo;
                    }
                    
                    if (doc?.IdEntidad.HasValue == true)
                    {
                        var entidad = await context.Entidades.FindAsync(doc.IdEntidad.Value);
                        movDto.NombreEntidad = entidad?.Nombre;
                    }
                    
                    // Get cuota info if exists
                    if (mov.IdDocCuota.HasValue)
                    {
                        var cuota = await context.DocCuotas
                            .FirstOrDefaultAsync(c => c.IdDoc == mov.IdDoc.Value && c.IdDocCuota == mov.IdDocCuota.Value);
                        if (cuota != null)
                        {
                            movDto.NumCuota = cuota.NumCuota;
                            movDto.MontoCuota = cuota.MontoCuota;
                        }
                    }
                }

                // Load Activo Fijo if exists (VB6: C_DETACTFIJO)
                var activoFijo = await context.MovActivoFijo
                    .FirstOrDefaultAsync(af => af.IdMovComp == mov.IdMov);

                if (activoFijo != null)
                {
                    movDto.IdActFijo = activoFijo.IdActFijo;
                    movDto.DescripcionActFijo = activoFijo.Descrip;
                    movDto.TieneActivoFijo = true;
                }
                else
                {
                    movDto.TieneActivoFijo = false;
                }

                dto.Movimientos.Add(movDto);
            }

            return dto;
    }

    public async Task DeleteAsync(int id)
    {
        logger.LogInformation("Deleting (soft) comprobante {IdComp}", id);

        var comprobante = await context.Comprobante.FindAsync(id);
        if (comprobante == null)
            throw new BusinessException($"Comprobante {id} no encontrado");

        // Soft delete: change state to Anulado (1)
        comprobante.Estado = (byte?)1;
        await context.SaveChangesAsync();

        logger.LogInformation("Comprobante {IdComp} marked as deleted (Estado=Anulado)", id);
    }

    // ========== Operaciones de Comprobante ==========

    /// <summary>
    /// Obtiene la configuraci?n de correlativo de la empresa
    /// VB6: HyperCont.bas l?neas 2092-2111 - gTipoCorrComp y gPerCorrComp
    /// </summary>
    private async Task<CorrelativoConfigDto> GetCorrelativoConfigAsync(int empresaId, short ano)
    {
        logger.LogDebug("Loading correlativo config for empresaId={EmpresaId}, ano={Ano}", empresaId, ano);
        
        var config = new CorrelativoConfigDto();
        
        // Obtener tipo correlativo (default: PorTipo = 2)
        // VB6: SELECT Valor FROM ParamEmpresa WHERE Tipo='TCORRCOMP'
        var tipoParam = await context.ParamEmpresa
            .FirstOrDefaultAsync(p => 
                p.IdEmpresa == empresaId && 
                p.Ano == ano && 
                p.Tipo == "TCORRCOMP");
        
        if (tipoParam != null && !string.IsNullOrEmpty(tipoParam.Valor))
        {
            if (int.TryParse(tipoParam.Valor, out var tipoVal))
            {
                config.TipoCorr = (CorrelativoConfigDto.TipoCorrelativo)tipoVal;
                logger.LogDebug("TipoCorr from DB: {TipoCorr}", config.TipoCorr);
            }
        }
        
        // Obtener per?odo correlativo (default: Mensual = 3)
        // VB6: SELECT Valor FROM ParamEmpresa WHERE Tipo='PCORRCOMP'
        var periodoParam = await context.ParamEmpresa
            .FirstOrDefaultAsync(p => 
                p.IdEmpresa == empresaId && 
                p.Ano == ano && 
                p.Tipo == "PCORRCOMP");
        
        if (periodoParam != null && !string.IsNullOrEmpty(periodoParam.Valor))
        {
            if (int.TryParse(periodoParam.Valor, out var periodoVal))
            {
                config.PeriodoCorr = (CorrelativoConfigDto.PeriodoCorrelativo)periodoVal;
                logger.LogDebug("PeriodoCorr from DB: {PeriodoCorr}", config.PeriodoCorr);
            }
        }
        
        logger.LogInformation("Correlativo config loaded: TipoCorr={TipoCorr}, PeriodoCorr={PeriodoCorr} (empresaId={EmpresaId}, ano={Ano})", 
            config.TipoCorr, config.PeriodoCorr, empresaId, ano);
        
        return config;
    }

    public async Task<int> GetNextCorrelativeAsync(int empresaId, short ano, byte? tipo = null)
    {
        logger.LogInformation("Getting next correlative for empresa {EmpresaId}, ano {Ano}, tipo {Tipo}",
            empresaId, ano, tipo);

        // ?? CARGAR CONFIGURACI?N DE EMPRESA (VB6: l?neas 2092-2111)
        var config = await GetCorrelativoConfigAsync(empresaId, ano);
        
        // Construir query base (ignorar temporales con Correlativo=-1)
        var query = context.Comprobante
            .Where(c => c.IdEmpresa == empresaId && c.Ano == ano && c.Correlativo > 0);

        // ?? APLICAR FILTRO SEG?N TIPO DE CORRELATIVO (VB6: l?neas 3743-3774)
        if (config.TipoCorr == CorrelativoConfigDto.TipoCorrelativo.PorTipo && tipo.HasValue)
        {
            // Correlativo separado por tipo de comprobante
            query = query.Where(c => c.Tipo == tipo.Value);
            logger.LogInformation("Using correlative by type: {Tipo} (TCC_TIPOCOMP)", tipo.Value);
        }
        else if (config.TipoCorr == CorrelativoConfigDto.TipoCorrelativo.Unico)
        {
            // Correlativo ?nico para todos los tipos (no filtrar por tipo)
            logger.LogInformation("Using unique correlative for all types (TCC_UNICO)");
        }

        // ?? APLICAR FILTRO SEG?N PER?ODO (VB6: l?neas 3747-3750)
        if (config.PeriodoCorr == CorrelativoConfigDto.PeriodoCorrelativo.Mensual)
        {
            // Reiniciar cada mes - filtrar por mes de la fecha actual
            var mesActual = DateTime.Now.Month;
            query = query.Where(c => 
                c.Fecha.HasValue && 
                (c.Fecha.Value / 100) % 100 == mesActual  // Extraer mes de formato yyyyMMdd
            );
            logger.LogInformation("Using monthly period, month: {Mes} (TCC_MENSUAL)", mesActual);
        }
        // TCC_ANUAL ya est? filtrado por el WHERE Ano = {ano}
        // TCC_CONTINUO no requiere filtro adicional

        var maxCorrelativo = await query
            .MaxAsync(c => c.Correlativo) ?? 0;

        var nextCorrelativo = maxCorrelativo + 1;
        
        logger.LogInformation("Next correlative: {Correlativo} (config: Tipo={TipoCorr}, Periodo={PeriodoCorr})",
            nextCorrelativo, config.TipoCorr, config.PeriodoCorr);

        return nextCorrelativo;
    }

    /// <summary>
    /// Obtiene el pr?ximo correlativo ?nico con protecci?n contra race conditions.
    /// Implementa algoritmo VB6 (l?neas 3732-3821) con Do While loop y verificaci?n de duplicados.
    /// DEBE ejecutarse dentro de una transacci?n Serializable.
    ///
    /// SOBRE GAPS EN NUMERACI?N:
    /// ---------------------------
    /// Este sistema minimiza pero NO elimina completamente los gaps en correlativos.
    /// Los gaps son comportamiento ESPERADO y EST?NDAR en sistemas transaccionales.
    ///
    /// ?Cu?ndo ocurren gaps?
    /// 1. Usuario A obtiene correlativo 100, luego hace ROLLBACK ? 100 queda sin usar
    /// 2. Falla de conexi?n DESPU?S de asignar pero ANTES de commit
    /// 3. Error de validaci?n DESPU?S de asignar correlativo
    ///
    /// ?Por qu? son aceptables?
    /// - Es el comportamiento est?ndar de SQL Server IDENTITY, PostgreSQL SERIAL, etc.
    /// - Los gaps son RAROS (solo cuando hay errores/cancelaciones)
    /// - No afecta la funcionalidad ni integridad de datos
    /// - La auditor?a de logs muestra qu? pas? con cada n?mero
    ///
    /// Optimizaci?n implementada (Opci?n 3):
    /// - Se asigna el correlativo LO M?S TARDE POSIBLE en CreateAsync()
    /// - Esto minimiza la ventana de tiempo donde podr?a haber rollback
    /// - Reduce significativamente (pero no elimina) la probabilidad de gaps
    /// </summary>
    /// <param name="empresaId">ID de la empresa</param>
    /// <param name="ano">A?o contable</param>
    /// <param name="tipo">Tipo de comprobante (opcional)</param>
    /// <param name="idCompActual">ID del comprobante actual (para excluir en verificaci?n)</param>
    /// <returns>Correlativo ?nico garantizado</returns>
    private async Task<int> GetNextCorrelativeWithLockAsync(int empresaId, short ano, byte? tipo, int idCompActual)
    {
        logger.LogInformation(
            "Getting unique correlative with lock for empresa {EmpresaId}, ano {Ano}, tipo {Tipo}, idComp {IdComp}",
            empresaId, ano, tipo, idCompActual);

        // ?? CARGAR CONFIGURACI?N DE EMPRESA
        var config = await GetCorrelativoConfigAsync(empresaId, ano);

        var correlativo = 0;
        var unicoEncontrado = false;
        var intentos = 0;
        const int MAX_INTENTOS = 100; // Prevenir loop infinito

        // ?? VB6: Do While True (l?neas 3756-3813)
        while (!unicoEncontrado && intentos < MAX_INTENTOS)
        {
            intentos++;

            // ?? PASO 1: Obtener m?ximo correlativo actual con filtros seg?n configuraci?n
            var query = context.Comprobante
                .Where(c => c.IdEmpresa == empresaId 
                         && c.Ano == ano 
                         && c.Correlativo > 0); // Ignorar correlativo=-1 (temporales)

            // ?? APLICAR FILTRO SEG?N TIPO DE CORRELATIVO
            if (config.TipoCorr == CorrelativoConfigDto.TipoCorrelativo.PorTipo && tipo.HasValue)
            {
                query = query.Where(c => c.Tipo == tipo.Value);
            }
            
            // ?? APLICAR FILTRO SEG?N PER?ODO
            if (config.PeriodoCorr == CorrelativoConfigDto.PeriodoCorrelativo.Mensual)
            {
                var mesActual = DateTime.Now.Month;
                query = query.Where(c => 
                    c.Fecha.HasValue && 
                    (c.Fecha.Value / 100) % 100 == mesActual
                );
            }

            var maxCorrelativo = await query
                .MaxAsync(c => c.Correlativo) ?? 0;

            correlativo = maxCorrelativo + 1;

            logger.LogDebug("Attempt {Intento}: Trying correlativo {Correlativo} (TipoCorr={TipoCorr}, PeriodoCorr={PeriodoCorr})", 
                intentos, correlativo, config.TipoCorr, config.PeriodoCorr);

            // ?? PASO 2: Verificar si ya existe este correlativo
            // VB6: SELECT idComp FROM Comprobante WHERE Correlativo = lCorrelativo
            var queryVerificar = context.Comprobante
                .Where(c => c.IdEmpresa == empresaId 
                         && c.Ano == ano 
                         && c.Correlativo == correlativo);
            
            // Aplicar mismos filtros de configuraci?n
            if (config.TipoCorr == CorrelativoConfigDto.TipoCorrelativo.PorTipo && tipo.HasValue)
            {
                queryVerificar = queryVerificar.Where(c => c.Tipo == tipo.Value);
            }
            
            if (config.PeriodoCorr == CorrelativoConfigDto.PeriodoCorrelativo.Mensual)
            {
                var mesActual = DateTime.Now.Month;
                queryVerificar = queryVerificar.Where(c => 
                    c.Fecha.HasValue && 
                    (c.Fecha.Value / 100) % 100 == mesActual
                );
            }

            var comprobantesConCorrelativo = await queryVerificar
                .Select(c => c.IdComp)
                .ToListAsync();

            if (!comprobantesConCorrelativo.Any())
            {
                // ? Correlativo disponible
                logger.LogInformation(
                    "Correlativo {Correlativo} is available (no duplicates found) after {Intentos} attempts",
                    correlativo, intentos);
                unicoEncontrado = true;
            }
            else
            {
                // ?? PASO 3: Verificar si alguno de los duplicados NO es nuestro comprobante
                // VB6: If vFld(Rs("idComp")) <> lidComp Then AddUniqueRecord = False
                var hayOtrosComprobantes = comprobantesConCorrelativo.Any(id => id != idCompActual);

                if (!hayOtrosComprobantes)
                {
                    // ? Solo nuestro comprobante tiene este correlativo
                    logger.LogInformation(
                        "Correlativo {Correlativo} only used by current comprobante {IdComp} after {Intentos} attempts",
                        correlativo, idCompActual, intentos);
                    unicoEncontrado = true;
                }
                else
                {
                    // ?? Otro comprobante ya tiene este correlativo - reintentar
                    logger.LogWarning(
                        "Correlativo {Correlativo} already taken by other comprobante(s): {IdComps}. Retrying... (attempt {Intento})",
                        correlativo, string.Join(", ", comprobantesConCorrelativo), intentos);
                    
                    // Peque?a pausa para reducir contenci?n (opcional)
                    await Task.Delay(10 * intentos); // Backoff exponencial suave
                }
            }
        }

        if (!unicoEncontrado)
        {
            var error = $"No se pudo obtener correlativo ?nico despu?s de {MAX_INTENTOS} intentos para empresa {empresaId}, a?o {ano}";
            logger.LogError(error);
            throw new BusinessException(error);
        }

        logger.LogInformation(
            "Final correlativo assigned: {Correlativo} for empresa {EmpresaId}, ano {Ano} after {Intentos} attempts (config: Tipo={TipoCorr}, Periodo={PeriodoCorr})",
            correlativo, empresaId, ano, intentos, config.TipoCorr, config.PeriodoCorr);

        return correlativo;
    }

    public async Task ValidateAsync(ComprobanteCreateDto dto, int? idUsuario = null, int? idEmpresa = null)
    {
        var errors = new List<string>();

        // ===== VALIDACIONES DE FECHA (VB6 l?neas 4522-4558) =====
        
        // 1. Fecha no vac?a
        if (dto.Fecha == default)
        {
            throw new BusinessException("Falta ingresar la fecha del comprobante");
        }

        // 2. A?o correcto
        if (dto.Fecha.Year != dto.Ano)
        {
            errors.Add("El a?o de la fecha del comprobante no corresponde al periodo actual");
        }

        // 3. Mes abierto (CR?TICO - VB6 l?neas 4534-4537)
        var estadoMes = await context.EstadoMes
            .FirstOrDefaultAsync(em => em.IdEmpresa == dto.IdEmpresa 
                                    && em.Ano == dto.Ano 
                                    && em.Mes == dto.Fecha.Month);

        if (estadoMes != null && estadoMes.Estado != (short?)1) // 1 = EM_ABIERTO
        {
            errors.Add("El mes correspondiente a la fecha del comprobante no est? abierto");
        }

        // 4. Si no es apertura, verificar fecha >= fecha comprobante apertura (VB6 l?neas 4544-4558)
        if (dto.Tipo != 4) // TC_APERTURA = 4
        {
            var fechaApertura = await context.Comprobante
                .Where(c => c.IdEmpresa == dto.IdEmpresa
                         && c.Ano == dto.Ano
                         && c.Tipo == 4) // TC_APERTURA
                .Select(c => c.Fecha)
                .FirstOrDefaultAsync();

            if (fechaApertura.HasValue && fechaApertura.Value > 0)
            {
                // Convertir fecha int a DateTime para comparar
                var fechaAperturaDate = IntToDate(fechaApertura.Value);
                if (fechaAperturaDate.HasValue && dto.Fecha < fechaAperturaDate.Value)
                {
                    errors.Add("La fecha del comprobante es anterior a la fecha del Comprobante de Apertura");
                }
            }
        }

        // ===== VALIDACIONES DE ESTADO (VB6 l?neas 4495-4508) =====
        
        if (dto.Estado <= 0)
        {
            errors.Add("Falta seleccionar el estado del comprobante");
        }

        // ===== VALIDACIONES DE TIPO (VB6 l?neas 4500-4503) =====
        
        if (dto.Tipo <= 0)
        {
            errors.Add("Falta seleccionar el tipo de comprobante");
        }

        // ===== VALIDACIONES DE GLOSA (VB6 l?neas 4505-4508) =====
        
        if (string.IsNullOrWhiteSpace(dto.Glosa))
        {
            errors.Add("Falta ingresar la glosa del comprobante");
        }

        // ===== VALIDACIONES DE PERMISOS DE ANULACI?N (VB6 l?neas 4559-4562) =====
        
        // Solo validar permisos si se est? intentando anular (Estado = 1) y tenemos los par?metros necesarios
        if (dto.Estado == 1 && idUsuario.HasValue && idEmpresa.HasValue) // EC_ANULADO = 1 en VB6
        {
            var tienePermiso = await permisosService.TienePrivilegioAnularAsync(idUsuario.Value, idEmpresa.Value);
            
            if (!tienePermiso)
            {
                logger.LogWarning("Usuario {IdUsuario} intent? anular comprobante sin privilegios en empresa {IdEmpresa}", 
                    idUsuario.Value, idEmpresa.Value);
                errors.Add("Este usuario no tiene el perfil requerido para anular un comprobante");
            }
        }

        // ===== VALIDACIONES DE COMPROBANTE APERTURA (VB6 l?neas 4581-4618) =====

        if (dto.Tipo == 4) // Nuevo comprobante de apertura (TC_APERTURA = 4)
        {
            // Solo un comprobante de apertura permitido
            var existeApertura = await context.Comprobante
                .AnyAsync(c => c.IdEmpresa == dto.IdEmpresa
                            && c.Ano == dto.Ano
                            && c.Tipo == 4);

            if (existeApertura)
            {
                errors.Add("Ya existe un comprobante de apertura. No es posible ingresar otro");
            }
        }

        // ===== VALIDACIONES DE MOVIMIENTOS (VB6 l?neas 4656-4848) =====
        
        if (!dto.Movimientos.Any())
        {
            errors.Add("Debe ingresar al menos un movimiento");
        }

        // Validar balance
        var totalDebe = dto.Movimientos.Sum(m => m.Debe);
        var totalHaber = dto.Movimientos.Sum(m => m.Haber);

        if (Math.Abs(totalDebe - totalHaber) > 0.01)
        {
            errors.Add("Los totales de las columnas DEBE y HABER no son iguales");

            // Sugerencia de cuadre si hay una l?nea vac?a (VB6 l?neas 4802-4815)
            var movVacios = dto.Movimientos.Count(m => m.Debe == 0 && m.Haber == 0);
            if (movVacios == 1)
            {
                var diff = totalDebe - totalHaber;
                if (diff < 0)
                {
                    errors.Add($"Para cuadrar el comprobante se sugiere valor en el DEBE: {Math.Abs(diff):N2}");
                }
                else
                {
                    errors.Add($"Para cuadrar el comprobante se sugiere valor en el HABER: {diff:N2}");
                }
            }
        }

        // Advertencia si comprobante no-apertura tiene valor 0 (VB6 l?neas 4573-4578)
        if (dto.Tipo != 4 && totalDebe == 0 && totalHaber == 0) // TC_APERTURA
        {
            errors.Add("El valor total del comprobante es cero");
        }

        // Validar cada movimiento
        var lineaNum = 1;
        var cuotasUsadas = new HashSet<int>();

        foreach (var mov in dto.Movimientos)
        {
            // Cuenta obligatoria (VB6 l?neas 4668-4672)
            if (mov.IdCuenta <= 0)
            {
                errors.Add($"En la l?nea {lineaNum} falta ingresar la cuenta");
                lineaNum++;
                continue;
            }

            // Debe XOR Haber (VB6 l?neas 4674-4678)
            if (mov.Debe > 0 && mov.Haber > 0)
            {
                errors.Add($"En la l?nea {lineaNum} los valores en las columnas DEBE y HABER son ambos mayores que 0");
            }

            // Obtener atributos de cuenta para validaciones avanzadas
            var cuenta = await context.Cuentas
                .FirstOrDefaultAsync(c => c.IdEmpresa == dto.IdEmpresa
                                       && c.Ano == dto.Ano
                                       && c.idCuenta == mov.IdCuenta);

            if (cuenta != null)
            {
                // ATRIB_RUT = 1 (requiere documento/entidad) - VB6 l?neas 4655-4656, 4684-4691
                // Solo aplica si NO es apertura y tiene monto
                var tieneMontos = mov.Debe > 0 || mov.Haber > 0;
                var noEsApertura = dto.Tipo != 4; // TC_APERTURA = 4

                if (noEsApertura && tieneMontos && (cuenta.Atrib1 == (byte?)1 || cuenta.Atrib2 == (byte?)1))
                {
                    if (!mov.IdDoc.HasValue || mov.IdDoc.Value == 0)
                    {
                        errors.Add($"En la l?nea {lineaNum} falta ingresar el detalle de documento asociado y entidad correspondiente");
                    }
                }

                // ATRIB_AREANEG = 2 (requiere ?rea negocio) - VB6 l?neas 4693-4697
                if (cuenta.Atrib1 == (byte?)2 || cuenta.Atrib2 == (byte?)2)
                {
                    if (!mov.IdAreaNegocio.HasValue || mov.IdAreaNegocio.Value == 0)
                    {
                        errors.Add($"En la l?nea {lineaNum} falta ingresar el ?rea de Negocio");
                    }
                }

                // ATRIB_CCOSTO = 3 (requiere centro costo) - VB6 l?neas 4699-4703
                if (cuenta.Atrib1 == (byte?)3 || cuenta.Atrib2 == (byte?)3)
                {
                    if (!mov.IdCCosto.HasValue || mov.IdCCosto.Value == 0)
                    {
                        errors.Add($"En la l?nea {lineaNum} falta ingresar el Centro de Gesti?n");
                    }
                }

                // ATRIB_CONCIL = 4 (cuenta bancaria debe coincidir con documento) - VB6 l?neas 4705-4709
                if ((cuenta.Atrib1 == (byte?)4 || cuenta.Atrib2 == (byte?)4) && mov.IdDoc.HasValue && mov.IdDoc.Value > 0)
                {
                    var documento = await context.Documento
                        .FirstOrDefaultAsync(d => d.IdDoc == mov.IdDoc.Value);

                    if (documento != null && documento.IdCtaBanco != cuenta.idCuenta)
                    {
                        errors.Add($"En la l?nea {lineaNum} la cuenta no es igual a la cuenta bancaria definida en el documento");
                    }
                }
            }

            // Validar cuotas no repetidas (VB6 l?neas 4850-4862)
            if (mov.IdDocCuota.HasValue && mov.IdDocCuota.Value > 0)
            {
                if (cuotasUsadas.Contains(mov.IdDocCuota.Value))
                {
                    errors.Add("Hay cuotas que est?n repetidas");
                }
                else
                {
                    cuotasUsadas.Add(mov.IdDocCuota.Value);
                }
            }

            lineaNum++;
        }

        // ===== VALIDACIONES OtrosIngEg14TER (VB6 l?neas 4823-4827) =====

        if (dto.OtrosIngEg14TER.GetValueOrDefault())
        {
            // Verificar que al menos una cuenta sea "disponible"
            var cuentasDisponibles = await context.CtasAjustesExCont
                .Where(c => c.IdEmpresa == dto.IdEmpresa)
                .Select(c => c.IdCuenta)
                .ToListAsync();

            var tieneCuentaDisponible = dto.Movimientos
                .Any(m => cuentasDisponibles.Contains(m.IdCuenta));

            if (!tieneCuentaDisponible)
            {
                var nombreCheckbox = dto.Ano >= 2020 
                    ? "Otros Ingresos/Egresos 14D" 
                    : "Otros Ingresos/Egresos 14TER";

                errors.Add($"Para marcar un comprobante como {nombreCheckbox} debe incluir al menos una cuenta configurada en Cuentas de Ajustes Extra-contables >> Disponibles >> Disponible Ingresos-Egresos");
            }
        }

        // ===== RESULTADO FINAL =====

        if (errors.Any())
        {
            throw new BusinessException(errors);
        }
    }

    public Task<bool> ValidateBalanceAsync(List<MovimientoDto> movimientos)
    {
        var totalDebe = movimientos.Sum(m => m.Debe ?? 0);
        var totalHaber = movimientos.Sum(m => m.Haber ?? 0);

        return Task.FromResult(Math.Abs(totalDebe - totalHaber) < 0.01);
    }

    public async Task<bool> ValidateOpenPeriodAsync(DateTime fecha, int empresaId)
    {
        // Migrado desde VB6: GetEstadoMes
        // Archivo: vb6/Contabilidad70/HyperContabilidad/HyperCont.bas l?neas 3950-3963
        
        const int EM_NOEXISTE = 0;
        const int EM_ABIERTO = 1;
        const int EM_CERRADO = 2;
        const int EM_ERRONEO = 3;

        {
            var ano = (short)fecha.Year;
            var mes = fecha.Month;

            // Buscar estado del mes en la tabla EstadoMes
            var estadoMes = await context.EstadoMes
                .FirstOrDefaultAsync(e => 
                    e.IdEmpresa == empresaId && 
                    e.Ano == ano && 
                    e.Mes == mes);

            if (estadoMes == null)
            {
                // El mes no existe en la tabla, se considera abierto por defecto
                logger.LogWarning(
                    "Mes {Mes}/{Ano} no existe en EstadoMes para empresa {EmpresaId}, se considera abierto",
                    mes, ano, empresaId);
                return true;
            }

            int estado = estadoMes.Estado ?? EM_ABIERTO;

            switch (estado)
            {
                case EM_ABIERTO:
                    return true;

                case EM_CERRADO:
                    logger.LogWarning(
                        "Intento de crear comprobante en mes cerrado: {Mes}/{Ano} para empresa {EmpresaId}",
                        mes, ano, empresaId);
                    return false;

                case EM_ERRONEO:
                    logger.LogWarning(
                        "Mes {Mes}/{Ano} est? en estado err?neo para empresa {EmpresaId}",
                        mes, ano, empresaId);
                    return false;

                case EM_NOEXISTE:
                default:
                    // Permitir si no existe registro
                    return true;
            }
        }
    }

    public async Task<ComprobanteDto> BalanceVoucherAsync(int id, int movimientoIndex, int idCuenta)
    {
        logger.LogInformation("Balancing comprobante {IdComp} at movement index {Index}",
            id, movimientoIndex);

        var comprobante = await GetByIdAsync(id);
        if (comprobante == null)
        {
            throw new BusinessException($"Comprobante {id} not found");
        }

        var totales = await CalculateTotalsAsync(id);
        var diferencia = totales.Diferencia;

        // Create balancing movement
        var movDto = new MovimientoCreateDto
        {
            IdCuenta = idCuenta,
            Debe = diferencia < 0 ? Math.Abs(diferencia.Value) : 0,
            Haber = diferencia > 0 ? diferencia.Value : 0,
            Glosa = "Cuadre autom?tico"
        };

        await AddMovementAsync(id, movDto);

        return await GetByIdAsync(id) 
            ?? throw new BusinessException("Error retrieving balanced comprobante");
    }

    // ========== Operaciones de Movimientos ==========

    public async Task<MovimientoDto> AddMovementAsync(int idComp, MovimientoCreateDto dto)
    {
        logger.LogInformation("Adding movement to comprobante {IdComp}", idComp);

        var comprobante = await context.Comprobante.FindAsync(idComp);
        if (comprobante == null)
        {
            throw new BusinessException($"Comprobante {idComp} not found");
        }

        var maxOrden = await context.MovComprobante
            .Where(m => m.IdComp == idComp)
            .MaxAsync(m => m.Orden) ?? 0;

        var movimiento = new App.Data.MovComprobante
        {
            IdEmpresa = comprobante.IdEmpresa,
            Ano = comprobante.Ano,
            IdComp = idComp,
            Orden = maxOrden + 1,
            IdCuenta = dto.IdCuenta,
            Debe = dto.Debe,
            Haber = dto.Haber,
            Glosa = dto.Glosa,
            idCCosto = dto.IdCCosto,
            idAreaNeg = dto.IdAreaNegocio,
            IdDoc = dto.IdDoc
        };

        context.MovComprobante.Add(movimiento);
        await context.SaveChangesAsync();

        // Update totals
        await UpdateTotalsAsync(idComp);

        var cuenta = await context.Cuentas.FindAsync(comprobante.IdEmpresa, comprobante.Ano, dto.IdCuenta);

        return new MovimientoDto
        {
            IdMov = movimiento.IdMov,
            IdComp = idComp,
            Orden = movimiento.Orden,
            IdCuenta = dto.IdCuenta,
            CodigoCuenta = cuenta?.Codigo,
            NombreCuenta = cuenta?.Descripcion,
            Debe = dto.Debe,
            Haber = dto.Haber,
            Glosa = dto.Glosa
        };
    }

    public async Task<MovimientoDto> UpdateMovementAsync(int id, MovimientoUpdateDto dto)
    {
        logger.LogInformation("Updating movement {IdMov}", id);

        var movimiento = await context.MovComprobante.FindAsync(id);
        if (movimiento == null)
        {
            throw new BusinessException($"Movement {id} not found");
        }

        movimiento.IdCuenta = dto.IdCuenta;
        movimiento.Debe = dto.Debe;
        movimiento.Haber = dto.Haber;
        movimiento.Glosa = dto.Glosa;
        movimiento.idCCosto = dto.IdCCosto;
        movimiento.idAreaNeg = dto.IdAreaNegocio;
        movimiento.IdDoc = dto.IdDoc;

        await context.SaveChangesAsync();

        // Update totals
        if (movimiento.IdComp.HasValue)
        {
            await UpdateTotalsAsync(movimiento.IdComp.Value);
        }

        var cuenta = await context.Cuentas.FindAsync(movimiento.IdEmpresa, movimiento.Ano, dto.IdCuenta);

        return new MovimientoDto
        {
            IdMov = id,
            IdCuenta = dto.IdCuenta,
            CodigoCuenta = cuenta?.Codigo,
            NombreCuenta = cuenta?.Descripcion,
            Debe = dto.Debe,
            Haber = dto.Haber,
            Glosa = dto.Glosa
        };
    }

    public async Task DeleteMovementAsync(int id)
    {
        logger.LogInformation("Deleting movement {IdMov}", id);

        var movimiento = await context.MovComprobante.FindAsync(id);
        if (movimiento == null)
            throw new BusinessException($"Movimiento {id} no encontrado");

        var idComp = movimiento.IdComp;
        context.MovComprobante.Remove(movimiento);
        await context.SaveChangesAsync();

        // Update totals
        if (idComp.HasValue)
        {
            await UpdateTotalsAsync(idComp.Value);
        }
    }

    public async Task<MovimientoDto> DuplicateMovementAsync(int id)
    {
        logger.LogInformation("Duplicating movement {IdMov}", id);

        var original = await context.MovComprobante.FindAsync(id);
        if (original == null)
        {
            throw new BusinessException($"Movement {id} not found");
        }

        var maxOrden = await context.MovComprobante
            .Where(m => m.IdComp == original.IdComp)
            .MaxAsync(m => m.Orden) ?? 0;

        var duplicate = new App.Data.MovComprobante
        {
            IdEmpresa = original.IdEmpresa,
            Ano = original.Ano,
            IdComp = original.IdComp,
            Orden = maxOrden + 1,
            IdCuenta = original.IdCuenta,
            Debe = original.Debe,
            Haber = original.Haber,
            Glosa = original.Glosa,
            idCCosto = original.idCCosto,
            idAreaNeg = original.idAreaNeg,
            IdDoc = original.IdDoc
        };

        context.MovComprobante.Add(duplicate);
        await context.SaveChangesAsync();

        // Update totals
        if (original.IdComp.HasValue)
        {
            await UpdateTotalsAsync(original.IdComp.Value);
        }

        var cuenta = await context.Cuentas.FindAsync(duplicate.IdEmpresa, duplicate.Ano, duplicate.IdCuenta);

        return new MovimientoDto
        {
            IdMov = duplicate.IdMov,
            IdComp = duplicate.IdComp,
            Orden = duplicate.Orden,
            IdCuenta = duplicate.IdCuenta,
            CodigoCuenta = cuenta?.Codigo,
            NombreCuenta = cuenta?.Descripcion,
            Debe = duplicate.Debe,
            Haber = duplicate.Haber,
            Glosa = duplicate.Glosa
        };
    }

    public async Task ReorderMovementAsync(int id, bool moveUp)
    {
        logger.LogInformation("Reordering movement {IdMov}, moveUp={MoveUp}", id, moveUp);

        var movimiento = await context.MovComprobante.FindAsync(id);
        if (movimiento == null || !movimiento.IdComp.HasValue)
            throw new BusinessException($"Movimiento {id} no encontrado");

        var movimientos = await context.MovComprobante
            .Where(m => m.IdComp == movimiento.IdComp)
            .OrderBy(m => m.Orden)
            .ToListAsync();

        var currentIndex = movimientos.FindIndex(m => m.IdMov == id);
        if (currentIndex == -1)
            throw new BusinessException("No se pudo encontrar el movimiento en la lista");

        var targetIndex = moveUp ? currentIndex - 1 : currentIndex + 1;
        if (targetIndex < 0 || targetIndex >= movimientos.Count)
            throw new BusinessException("No se pudo reordenar el movimiento (ya está en el límite)");

        // Swap orden
        var tempOrden = movimientos[currentIndex].Orden;
        movimientos[currentIndex].Orden = movimientos[targetIndex].Orden;
        movimientos[targetIndex].Orden = tempOrden;

        await context.SaveChangesAsync();
    }

    // ========== C?lculos ==========

    public async Task<TotalesDto> CalculateTotalsAsync(int idComp)
    {
        var movimientos = await context.MovComprobante
            .Where(m => m.IdComp == idComp)
            .ToListAsync();

        var totalDebe = movimientos.Sum(m => m.Debe ?? 0);
        var totalHaber = movimientos.Sum(m => m.Haber ?? 0);
        var diferencia = totalDebe - totalHaber;

        return new TotalesDto
        {
            TotalDebe = totalDebe,
            TotalHaber = totalHaber,
            Diferencia = diferencia,
            Balanceado = Math.Abs(diferencia) < 0.01
        };
    }

    public async Task<double> SumMovementsAsync(List<int> movimientosIds, bool sumDebe)
    {
        var movimientos = await context.MovComprobante
            .Where(m => movimientosIds.Contains(m.IdMov))
            .ToListAsync();

        if (sumDebe)
        {
            return movimientos.Sum(m => m.Debe ?? 0);
        }
        else
        {
            return movimientos.Sum(m => m.Haber ?? 0);
        }
    }

    // ========== Documentos ==========

    public async Task AssignDocumentAsync(int idMovimiento, int idDocumento)
    {
        var movimiento = await context.MovComprobante.FindAsync(idMovimiento);
        if (movimiento == null)
            throw new BusinessException($"Movimiento {idMovimiento} no encontrado");

        movimiento.IdDoc = idDocumento;
        await context.SaveChangesAsync();
    }

    public async Task RemoveDocumentAsync(int idMovimiento)
    {
        var movimiento = await context.MovComprobante.FindAsync(idMovimiento);
        if (movimiento == null)
            throw new BusinessException($"Movimiento {idMovimiento} no encontrado");

        movimiento.IdDoc = null;
        await context.SaveChangesAsync();
    }

    public async Task<List<DocumentoDto>> SearchDocumentsAsync(int empresaId, DocumentoSearchDto searchDto)
    {
        var query = context.Documento
            .Where(d => d.IdEmpresa == empresaId);

        if (searchDto.TipoLib.HasValue)
        {
            query = query.Where(d => d.TipoLib == searchDto.TipoLib.Value);
        }

        if (searchDto.TipoDoc.HasValue)
        {
            query = query.Where(d => d.TipoDoc == searchDto.TipoDoc.Value);
        }

        if (searchDto.Estado.HasValue)
        {
            query = query.Where(d => d.Estado == searchDto.Estado.Value);
        }

        if (!string.IsNullOrEmpty(searchDto.RutEntidad))
        {
            query = query.Where(d => d.RutEntidad == searchDto.RutEntidad);
        }

        var documentos = await query
            .Take(100)
            .ToListAsync();

        return documentos.Select(d => {
            var saldo = d.SaldoDoc ?? d.Total ?? 0;
            return new DocumentoDto
            {
                IdDoc = d.IdDoc,
                TipoLib = d.TipoLib,
                TipoDoc = d.TipoDoc,
                NumDoc = d.NumDoc ?? string.Empty,
                RutEntidad = d.RutEntidad,
                NombreEntidad = d.NombreEntidad,
                FechaEmision = IntToDate(d.FEmision),
                FechaVencimiento = IntToDate(d.FVenc),
                Total = d.Total,
                SaldoDoc = d.SaldoDoc,
                DTE =  d.DTE == true,
                // Calcular montos sugeridos seg?n l?gica VB6:
                // Si SaldoDoc > 0 -> va al HABER, Si SaldoDoc < 0 -> va al DEBE
                MontoSugeridoDebe = saldo < 0 ? Math.Abs(saldo) : null,
                MontoSugeridoHaber = saldo > 0 ? Math.Abs(saldo) : null
            };
        }).ToList();
    }

    public async Task<ComprobanteDto> GeneratePaymentAsync(int empresaId, int usuarioId, List<int> documentosIds)
    {
        logger.LogInformation("Generating automatic payment for empresaId={EmpresaId}, documentos={DocumentosIds}", 
            empresaId, string.Join(",", documentosIds));

        // 1. Validar y cargar documentos
        var documentos = await context.Documento
            .Where(d => documentosIds.Contains(d.IdDoc) && d.IdEmpresa == empresaId)
            .ToListAsync();

        if (!documentos.Any())
        {
            throw new BusinessException("No se encontraron documentos para generar pago");
        }

        // Validar que todos los documentos tengan saldo pendiente
        var documentosSinSaldo = documentos.Where(d => (d.SaldoDoc ?? 0) <= 0).ToList();
        if (documentosSinSaldo.Any())
        {
            throw new BusinessException($"Documentos sin saldo: {string.Join(", ", documentosSinSaldo.Select(d => d.NumDoc))}");
        }

        var ano = (short)DateTime.Now.Year;

        // 2. Obtener correlativo autom?tico (tipo 1 = Egreso para pagos)
        var correlativo = await GetNextCorrelativeAsync(empresaId, ano, (byte?)1);

        // 3. Calcular total de pago
        var totalPago = documentos.Sum(d => d.SaldoDoc ?? 0);

        // 4. Obtener cuenta por pagar desde primer documento (IdCuentaTotal)
        var cuentaPorPagarId = documentos.First().IdCuentaTotal;
        if (cuentaPorPagarId == null || cuentaPorPagarId == 0)
        {
            throw new BusinessException("No se pudo determinar la cuenta por pagar de los documentos");
        }

        // 5. Obtener cuenta banco desde CuentasBasicas (Tipo=1: Banco, TipoLib puede variar)
        var cuentaBanco = await context.CuentasBasicas
            .Where(cb => cb.IdEmpresa == empresaId && cb.Ano == ano && cb.Tipo == 1)
            .FirstOrDefaultAsync();

        if (cuentaBanco == null || cuentaBanco.IdCuenta == null)
        {
            throw new BusinessException("No se encontr? cuenta banco configurada en Cuentas B?sicas");
        }

        // 6. Crear comprobante de pago
        var comprobante = new App.Data.Comprobante
        {
            IdEmpresa = empresaId,
            Ano = ano,
            Correlativo = correlativo,
            Fecha = App.Helpers.DateHelper.ToDbDate(DateTime.Now),
            Tipo = (byte?)1, // Egreso
            Estado = 2, // Aprobado
            Glosa = $"Pago de {documentos.Count} documento(s)",
            IdUsuario = usuarioId,
            FechaCreacion = App.Helpers.DateHelper.ToDbDate(DateTime.Now),
            TotalDebe = totalPago,
            TotalHaber = totalPago,
            ImpResumido = false,
            OtrosIngEg14TER = false
        };

        context.Comprobante.Add(comprobante);
        await context.SaveChangesAsync();

        logger.LogInformation("Created comprobante IdComp={IdComp}, Correlativo={Correlativo}", 
            comprobante.IdComp, comprobante.Correlativo);

        // 7. Crear movimientos autom?ticos
        var movimientos = new List<App.Data.MovComprobante>();

        // Movimiento 1: Debe - Cuenta por Pagar (se descarga la deuda)
        var movDebe = new App.Data.MovComprobante
        {
            IdEmpresa = empresaId,
            Ano = ano,
            IdComp = comprobante.IdComp,
            Orden = 1,
            IdCuenta = cuentaPorPagarId.Value,
            Debe = totalPago,
            Haber = 0,
            Glosa = "Pago proveedores",
            DeCentraliz = false
        };
        movimientos.Add(movDebe);

        // Movimiento 2: Haber - Cuenta Banco (sale dinero)
        var movHaber = new App.Data.MovComprobante
        {
            IdEmpresa = empresaId,
            Ano = ano,
            IdComp = comprobante.IdComp,
            Orden = 2,
            IdCuenta = cuentaBanco.IdCuenta.Value,
            Debe = 0,
            Haber = totalPago,
            Glosa = "Pago mediante banco",
            DeCentraliz = false
        };
        movimientos.Add(movHaber);

        context.MovComprobante.AddRange(movimientos);
        await context.SaveChangesAsync();

        logger.LogInformation("Created {Count} movements for comprobante", movimientos.Count);

        // 8. Asignar documentos al primer movimiento (Debe - Cuenta por Pagar)
        foreach (var doc in documentos)
        {
            movDebe.IdDoc = doc.IdDoc;
            
            // Actualizar IdCompPago en el documento
            doc.IdCompPago = comprobante.IdComp;
        }

        await context.SaveChangesAsync();

        logger.LogInformation("Assigned {Count} documents to payment", documentos.Count);

        // 9. Retornar DTO del comprobante creado
        return await GetByIdAsync(comprobante.IdComp) 
            ?? throw new BusinessException("Error al recuperar comprobante creado");
    }

    // ========== Cuentas y Plan de Cuentas ==========

    public async Task<CuentaDto?> ValidateAccountAsync(int empresaId, short ano, string? codigo)
    {
        // Validación de negocio en Service
        if (string.IsNullOrWhiteSpace(codigo))
            throw new BusinessException("El código de cuenta es requerido");

        logger.LogInformation("Service: Validating account - empresaId={EmpresaId}, ano={Ano}, codigo='{Codigo}'",
            empresaId, ano, codigo);

        var cuenta = await context.Cuentas
            .FirstOrDefaultAsync(c =>
                c.IdEmpresa == empresaId &&
                c.Ano == ano &&
                c.Codigo == codigo);

        if (cuenta == null)
        {
            logger.LogWarning("Service: Account not found in database - empresaId={EmpresaId}, ano={Ano}, codigo='{Codigo}'",
                empresaId, ano, codigo);

            // Log sample accounts to help debugging
            var sampleAccounts = await context.Cuentas
                .Where(c => c.IdEmpresa == empresaId && c.Ano == ano)
                .Take(5)
                .Select(c => new { c.Codigo, c.Descripcion })
                .ToListAsync();

            logger.LogInformation("Service: Sample accounts for debugging: {Accounts}",
                string.Join(", ", sampleAccounts.Select(a => $"{a.Codigo}:{a.Descripcion}")));

            throw new BusinessException("Cuenta no encontrada");
        }

        logger.LogInformation("Service: Account found - idCuenta={IdCuenta}, Codigo='{Codigo}', Descripcion='{Descripcion}'",
            cuenta.idCuenta, cuenta.Codigo, cuenta.Descripcion);

        return new CuentaDto
        {
            IdCuenta = cuenta.idCuenta,
            Codigo = cuenta.Codigo ?? string.Empty,
            Nombre = cuenta.Nombre ?? string.Empty,
            Descripcion = cuenta.Descripcion ?? string.Empty,
            Nivel = cuenta.Nivel,
            EsUltimoNivel = cuenta.Nivel == 5, // Assume level 5 is last
            Clasificacion = cuenta.Clasificacion
        };
    }

    public async Task<List<CuentaDto>> SearchAccountsAsync(int empresaId, short ano, string? searchTerm)
    {
        // Validación de negocio en Service
        if (string.IsNullOrWhiteSpace(searchTerm))
            throw new BusinessException("El término de búsqueda es requerido");

        if (searchTerm.Length < 2)
            return new List<CuentaDto>();

        // Normalizar el término de búsqueda
        var searchTermUpper = searchTerm.ToUpper();
        
        var cuentas = await context.Cuentas
            .Where(c => c.IdEmpresa == empresaId && c.Ano == ano)
            .Where(c => 
                (c.Codigo != null && c.Codigo.ToUpper().Contains(searchTermUpper)) || 
                (c.Descripcion != null && c.Descripcion.ToUpper().Contains(searchTermUpper)))
            .ToListAsync();

        // Ordenar resultados: 
        // 1. Coincidencias exactas en c?digo primero
        // 2. C?digo que empieza con el t?rmino
        // 3. C?digo que contiene el t?rmino
        // 4. Descripci?n que contiene el t?rmino
        var ordenados = cuentas
            .OrderBy(c => {
                if (c.Codigo != null && c.Codigo.Equals(searchTerm, StringComparison.OrdinalIgnoreCase))
                    return 0; // Coincidencia exacta en c?digo
                if (c.Codigo != null && c.Codigo.StartsWith(searchTerm, StringComparison.OrdinalIgnoreCase))
                    return 1; // C?digo empieza con el t?rmino
                if (c.Codigo != null && c.Codigo.Contains(searchTerm, StringComparison.OrdinalIgnoreCase))
                    return 2; // C?digo contiene el t?rmino
                return 3; // Descripci?n contiene el t?rmino
            })
            .ThenBy(c => c.Codigo) // Ordenar por c?digo dentro de cada grupo
            .Take(50)
            .ToList();

        return ordenados.Select(c => new CuentaDto
        {
            IdCuenta = c.idCuenta,
            Codigo = c.Codigo ?? string.Empty,
            Nombre = c.Nombre ?? string.Empty,
            Descripcion = c.Descripcion ?? string.Empty,
            Nivel = c.Nivel,
            EsUltimoNivel = c.Nivel == 5,
            Clasificacion = c.Clasificacion
        }).ToList();
    }

    public async Task<CuentaDto?> GetAccountByIdAsync(int idCuenta, int empresaId, short ano)
    {
        var cuenta = await context.Cuentas.FindAsync(empresaId, ano, idCuenta);
        if (cuenta == null)
        {
            return null;
        }

        return new CuentaDto
        {
            IdCuenta = cuenta.idCuenta,
            Codigo = cuenta.Codigo ?? string.Empty,
            Nombre = cuenta.Nombre ?? string.Empty,
            Descripcion = cuenta.Descripcion ?? string.Empty,
            Nivel = cuenta.Nivel,
            EsUltimoNivel = cuenta.Nivel == 5,
            Clasificacion = cuenta.Clasificacion
        };
    }

    // ========== Utilitarios ==========

    public async Task<ConversionMonedaDto> ConvertCurrencyAsync(double amount, string fromCurrency, string toCurrency, DateTime fecha)
    {
        logger.LogInformation("Converting {Amount} from {FromCurrency} to {ToCurrency} on date {Fecha}", 
            amount, fromCurrency, toCurrency, fecha);

        // Si son la misma moneda, retornar sin conversi?n
        if (fromCurrency.Equals(toCurrency, StringComparison.OrdinalIgnoreCase))
        {
            return new ConversionMonedaDto
            {
                Monto = amount,
                MonedaOrigen = fromCurrency,
                MonedaDestino = toCurrency,
                Fecha = fecha,
                TasaCambio = 1.0,
                MontoConvertido = amount
            };
        }

        // Buscar monedas por s?mbolo (como en VB6: GetValMoneda busca por Simbolo)
        // Los s?mbolos vienen con espacios a la derecha en la BD, as? que usamos Contains/Trim
        var monedaOrigen = await context.Monedas
            .FirstOrDefaultAsync(m => m.Simbolo != null && m.Simbolo.Trim() == fromCurrency.Trim());
        
        var monedaDestino = await context.Monedas
            .FirstOrDefaultAsync(m => m.Simbolo != null && m.Simbolo.Trim() == toCurrency.Trim());

        if (monedaOrigen == null || monedaDestino == null)
        {
            logger.LogWarning("Currency not found in Monedas table: {FromCurrency} ({Found1}) or {ToCurrency} ({Found2})", 
                fromCurrency, monedaOrigen?.Descrip ?? "null", toCurrency, monedaDestino?.Descrip ?? "null");
            
            // Retornar conversi?n 1:1 si no se encuentran las monedas
            return new ConversionMonedaDto
            {
                Monto = amount,
                MonedaOrigen = fromCurrency,
                MonedaDestino = toCurrency,
                Fecha = fecha,
                TasaCambio = 1.0,
                MontoConvertido = amount
            };
        }

        logger.LogInformation("Found currencies: {From} (id={FromId}) -> {To} (id={ToId})", 
            monedaOrigen.Descrip, monedaOrigen.idMoneda, monedaDestino.Descrip, monedaDestino.idMoneda);

        // Buscar tasa de cambio en tabla Equivalencia
        var fechaDb = App.Helpers.DateHelper.ToDbDate(fecha);
        
        var equivalenciaOrigen = await context.Equivalencia
            .Where(e => e.idMoneda == monedaOrigen.idMoneda && e.Fecha == fechaDb)
            .FirstOrDefaultAsync();

        var equivalenciaDestino = await context.Equivalencia
            .Where(e => e.idMoneda == monedaDestino.idMoneda && e.Fecha == fechaDb)
            .FirstOrDefaultAsync();

        // Si no hay equivalencia para la fecha exacta, buscar la m?s cercana anterior
        if (equivalenciaOrigen == null)
        {
            equivalenciaOrigen = await context.Equivalencia
                .Where(e => e.idMoneda == monedaOrigen.idMoneda && e.Fecha <= fechaDb)
                .OrderByDescending(e => e.Fecha)
                .FirstOrDefaultAsync();
        }

        if (equivalenciaDestino == null)
        {
            equivalenciaDestino = await context.Equivalencia
                .Where(e => e.idMoneda == monedaDestino.idMoneda && e.Fecha <= fechaDb)
                .OrderByDescending(e => e.Fecha)
                .FirstOrDefaultAsync();
        }

        double tasaCambio;
        double montoConvertido;

        if (equivalenciaOrigen != null && equivalenciaDestino != null)
        {
            // Calcular tasa cruzada: (monto * tasa_origen) / tasa_destino
            var valorOrigen = equivalenciaOrigen.Valor ?? 1.0;
            var valorDestino = equivalenciaDestino.Valor ?? 1.0;

            tasaCambio = valorOrigen / valorDestino;
            montoConvertido = amount * tasaCambio;

            logger.LogInformation("Currency conversion successful: {Amount} * {TasaCambio} = {MontoConvertido}",
                amount, tasaCambio, montoConvertido);
        }
        else
        {
            logger.LogWarning("No exchange rate found in Equivalencia table for date {Fecha}", fecha);

            // Retornar conversi?n 1:1 si no hay datos
            tasaCambio = 1.0;
            montoConvertido = amount;
        }

        return new ConversionMonedaDto
        {
            Monto = amount,
            MonedaOrigen = fromCurrency,
            MonedaDestino = toCurrency,
            Fecha = fecha,
            TasaCambio = tasaCambio,
            MontoConvertido = montoConvertido
        };
    }

    /// <summary>
    /// Obtiene la fecha sugerida para un nuevo comprobante
    /// VB6: FrmComprobante.frm l?neas 2443-2452 (GetMesActual + GetUltimoMesConComps)
    /// </summary>
    public async Task<DateTime> GetFechaSugeridaAsync(int empresaId, short ano)
    {
        if (ano < 1900 || ano > 2100)
            throw new BusinessException("El año debe estar entre 1900 y 2100");

        logger.LogInformation("Getting suggested date for empresaId={EmpresaId}, ano={Ano}", empresaId, ano);

        // Usar helper para obtener la fecha sugerida
        var fechaSugerida = await Helpers.EstadoMesHelper.GetFechaSugeridaAsync(context, empresaId, ano);

        logger.LogInformation("Suggested date: {Fecha}", fechaSugerida.ToString("dd/MM/yyyy"));

        return fechaSugerida;
    }

    public async Task<List<GlosaDto>> GetGlossariesAsync(int empresaId)
    {
        logger.LogInformation("Getting glossaries for empresaId={EmpresaId}", empresaId);

        var glosas = await context.Glosas
            .Where(g => g.IdEmpresa == empresaId)
            .OrderBy(g => g.Glosa)
            .ToListAsync();

        return glosas.Select(g => new GlosaDto
        {
            IdGlosa = g.idGlosa,
            Glosa = g.Glosa ?? string.Empty
        }).ToList();
    }

    public async Task<byte[]> ExportToExcelAsync(int idComp)
    {
        logger.LogInformation("Exporting comprobante {IdComp} to Excel", idComp);

        var comprobante = await GetByIdAsync(idComp);
        if (comprobante == null)
        {
            throw new BusinessException($"Comprobante {idComp} no encontrado");
        }

        ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

        using var package = new ExcelPackage();
        var worksheet = package.Workbook.Worksheets.Add("Comprobante");

        // T?tulo
        worksheet.Cells["A1"].Value = "COMPROBANTE CONTABLE";
        worksheet.Cells["A1:H1"].Merge = true;
        worksheet.Cells["A1"].Style.Font.Bold = true;
        worksheet.Cells["A1"].Style.Font.Size = 14;
        worksheet.Cells["A1"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

        // Informaci?n del comprobante
        var row = 3;
        worksheet.Cells[$"A{row}"].Value = "N?mero:";
        worksheet.Cells[$"B{row}"].Value = comprobante.Correlativo;
        worksheet.Cells[$"D{row}"].Value = "Fecha:";
        worksheet.Cells[$"E{row}"].Value = comprobante.Fecha.ToString("dd/MM/yyyy");

        row++;
        worksheet.Cells[$"A{row}"].Value = "Tipo:";
        worksheet.Cells[$"B{row}"].Value = comprobante.TipoDescripcion;
        worksheet.Cells[$"D{row}"].Value = "Estado:";
        worksheet.Cells[$"E{row}"].Value = comprobante.EstadoDescripcion;

        row++;
        worksheet.Cells[$"A{row}"].Value = "Glosa:";
        worksheet.Cells[$"B{row}:H{row}"].Merge = true;
        worksheet.Cells[$"B{row}"].Value = comprobante.Glosa;

        // Encabezados de movimientos
        row += 2;
        var headerRow = row;
        worksheet.Cells[$"A{row}"].Value = "Orden";
        worksheet.Cells[$"B{row}"].Value = "C?digo Cuenta";
        worksheet.Cells[$"C{row}"].Value = "Nombre Cuenta";
        worksheet.Cells[$"D{row}"].Value = "Glosa";
        worksheet.Cells[$"E{row}"].Value = "Debe";
        worksheet.Cells[$"F{row}"].Value = "Haber";
        worksheet.Cells[$"G{row}"].Value = "?rea Negocio";
        worksheet.Cells[$"H{row}"].Value = "Centro Costo";

        // Estilo encabezados
        using (var range = worksheet.Cells[$"A{row}:H{row}"])
        {
            range.Style.Font.Bold = true;
            range.Style.Fill.PatternType = ExcelFillStyle.Solid;
            range.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightGray);
            range.Style.Border.Bottom.Style = ExcelBorderStyle.Thick;
        }

        // Datos de movimientos
        row++;
        foreach (var mov in comprobante.Movimientos)
        {
            worksheet.Cells[$"A{row}"].Value = mov.Orden;
            worksheet.Cells[$"B{row}"].Value = mov.CodigoCuenta;
            worksheet.Cells[$"C{row}"].Value = mov.NombreCuenta;
            worksheet.Cells[$"D{row}"].Value = mov.Glosa;
            worksheet.Cells[$"E{row}"].Value = mov.Debe;
            worksheet.Cells[$"E{row}"].Style.Numberformat.Format = "#,##0.00";
            worksheet.Cells[$"F{row}"].Value = mov.Haber;
            worksheet.Cells[$"F{row}"].Style.Numberformat.Format = "#,##0.00";
            worksheet.Cells[$"G{row}"].Value = mov.NombreAreaNegocio;
            worksheet.Cells[$"H{row}"].Value = mov.NombreCCosto;
            row++;
        }

        // Totales
        row++;
        worksheet.Cells[$"D{row}"].Value = "TOTALES:";
        worksheet.Cells[$"D{row}"].Style.Font.Bold = true;
        worksheet.Cells[$"E{row}"].Value = comprobante.TotalDebe;
        worksheet.Cells[$"E{row}"].Style.Numberformat.Format = "#,##0.00";
        worksheet.Cells[$"E{row}"].Style.Font.Bold = true;
        worksheet.Cells[$"E{row}"].Style.Border.Top.Style = ExcelBorderStyle.Double;
        worksheet.Cells[$"F{row}"].Value = comprobante.TotalHaber;
        worksheet.Cells[$"F{row}"].Style.Numberformat.Format = "#,##0.00";
        worksheet.Cells[$"F{row}"].Style.Font.Bold = true;
        worksheet.Cells[$"F{row}"].Style.Border.Top.Style = ExcelBorderStyle.Double;

        // Diferencia
        row++;
        var diferencia = (comprobante.TotalDebe ?? 0) - (comprobante.TotalHaber ?? 0);
        worksheet.Cells[$"D{row}"].Value = "Diferencia:";
        worksheet.Cells[$"E{row}"].Value = diferencia;
        worksheet.Cells[$"E{row}"].Style.Numberformat.Format = "#,##0.00";
        if (Math.Abs(diferencia) > 0.01)
        {
            worksheet.Cells[$"E{row}"].Style.Font.Color.SetColor(System.Drawing.Color.Red);
            worksheet.Cells[$"E{row}"].Style.Font.Bold = true;
        }

        // Ajustar anchos de columna
        worksheet.Column(1).Width = 8;  // Orden
        worksheet.Column(2).Width = 15; // C?digo
        worksheet.Column(3).Width = 35; // Nombre Cuenta
        worksheet.Column(4).Width = 30; // Glosa
        worksheet.Column(5).Width = 15; // Debe
        worksheet.Column(6).Width = 15; // Haber
        worksheet.Column(7).Width = 20; // ?rea Negocio
        worksheet.Column(8).Width = 20; // Centro Costo

        logger.LogInformation("Excel export completed for comprobante {IdComp}", idComp);

        return package.GetAsByteArray();
    }

    public async Task<byte[]> GenerateReportAsync(int idComp, bool resumido = false)
    {
        logger.LogInformation("Generating PDF report for comprobante {IdComp}, resumido={Resumido}", idComp, resumido);

        var comprobante = await GetByIdAsync(idComp);
        if (comprobante == null)
        {
            throw new BusinessException($"Comprobante {idComp} no encontrado");
        }

        // Usar servicio de PDF profesional con QuestPDF
        return pdfReportService.GenerateComprobantePdf(comprobante, resumido);
    }

    public async Task<byte[]> GenerateChequePdfAsync(int idComp, ChequeConfigDto config)
    {
        logger.LogInformation("Generating cheque PDF for comprobante {IdComp}", idComp);

        var comprobante = await GetByIdAsync(idComp);
        if (comprobante == null)
        {
            throw new BusinessException($"Comprobante {idComp} no encontrado");
        }

        // Validar que el comprobante tenga datos necesarios para cheque
        if (comprobante.TotalHaber <= 0)
        {
            throw new BusinessException("El comprobante no tiene monto v?lido para generar cheque");
        }

        // Si no se proporciona beneficiario, intentar obtenerlo del primer movimiento con documento
        if (string.IsNullOrEmpty(config.Beneficiario))
        {
            var movConEntidad = comprobante.Movimientos.FirstOrDefault(m => !string.IsNullOrEmpty(m.NombreEntidad));
            if (movConEntidad != null)
            {
                config.Beneficiario = movConEntidad.NombreEntidad!;
            }
            else
            {
                config.Beneficiario = "BENEFICIARIO NO ESPECIFICADO";
            }
        }

        return pdfReportService.GenerateChequePdf(comprobante, config);
    }

    // ========== Comprobantes Tipo (Plantillas) ==========

    public async Task<List<ComprobanteTipoDto>> GetVoucherTypesAsync(int empresaId)
    {
        logger.LogInformation("Getting voucher types for empresaId={EmpresaId}", empresaId);

        var comprobantes = await context.CT_Comprobante
            .Where(c => c.IdEmpresa == empresaId)
            .OrderBy(c => c.Nombre)
            .ToListAsync();

        var result = new List<ComprobanteTipoDto>();

        foreach (var comp in comprobantes)
        {
            // Cargar movimientos del comprobante tipo
            var movimientos = await context.CT_MovComprobante
                .Where(m => m.IdComp == comp.IdComp && m.IdEmpresa == empresaId)
                .OrderBy(m => m.Orden)
                .ToListAsync();

            var compTipoDto = new ComprobanteTipoDto
            {
                IdCompTipo = comp.IdComp,
                Nombre = comp.Nombre ?? string.Empty,
                Descripcion = comp.Descrip ?? string.Empty,
                Tipo = comp.Tipo ?? 1,
                Glosa = comp.Glosa ?? string.Empty,
                Movimientos = movimientos.Select(m => new MovimientoCreateDto
                {
                    IdCuenta = m.IdCuenta ?? 0,
                    Debe = m.Debe ?? 0,
                    Haber = m.Haber ?? 0,
                    Glosa = m.Glosa,
                    IdCCosto = m.IdCCosto,
                    IdAreaNegocio = m.IdAreaNeg
                }).ToList()
            };

            result.Add(compTipoDto);
        }

        logger.LogInformation("Found {Count} voucher types for empresaId={EmpresaId}", result.Count, empresaId);
        return result;
    }

    public async Task<ComprobanteTipoDetailDto?> GetVoucherTypeByIdAsync(int idComp, int empresaId)
    {
        logger.LogInformation("Getting voucher type detail for idComp={IdComp}, empresaId={EmpresaId}", idComp, empresaId);

        // Buscar primero solo por IdComp para debugging
        var existeEnBD = await context.CT_Comprobante.AnyAsync(c => c.IdComp == idComp);
        logger.LogInformation("Template {IdComp} exists in DB (without empresa filter): {Exists}", idComp, existeEnBD);

        var compTipo = await context.CT_Comprobante
            .FirstOrDefaultAsync(c => c.IdComp == idComp && c.IdEmpresa == empresaId);

        if (compTipo == null)
        {
            // Log adicional para debugging
            var templateSinFiltro = await context.CT_Comprobante.FirstOrDefaultAsync(c => c.IdComp == idComp);
            if (templateSinFiltro != null)
            {
                logger.LogWarning("Template {IdComp} found but has IdEmpresa={TemplateEmpresa}, requested empresaId={RequestedEmpresa}",
                    idComp, templateSinFiltro.IdEmpresa, empresaId);
            }
            else
            {
                logger.LogWarning("Voucher type {IdComp} not found at all in CT_Comprobante", idComp);
            }
            return null;
        }

        // Cargar movimientos con informaci?n de cuentas, centros de costo y ?reas de negocio
        var movimientos = await (from mov in context.CT_MovComprobante
                                 join cuenta in context.Cuentas
                                     on new { mov.IdCuenta, mov.IdEmpresa }
                                     equals new { IdCuenta = (int?)cuenta.idCuenta, IdEmpresa = (int?)cuenta.IdEmpresa }
                                     into cuentaJoin
                                 from cuenta in cuentaJoin.DefaultIfEmpty()
                                 join area in context.AreaNegocio
                                     on new { mov.IdAreaNeg, mov.IdEmpresa }
                                     equals new { IdAreaNeg = (int?)area.IdAreaNegocio, IdEmpresa = (int?)area.IdEmpresa }
                                     into areaJoin
                                 from area in areaJoin.DefaultIfEmpty()
                                 join centro in context.CentroCosto
                                     on new { mov.IdCCosto, mov.IdEmpresa }
                                     equals new { IdCCosto = (int?)centro.IdCCosto, IdEmpresa = centro.IdEmpresa }
                                     into centroJoin
                                 from centro in centroJoin.DefaultIfEmpty()
                                 where mov.IdComp == idComp && mov.IdEmpresa == empresaId
                                 orderby mov.Orden
                                 select new MovimientoPlantillaDetailDto
                                 {
                                     IdMov = mov.IdMov,
                                     Orden = mov.Orden,
                                     IdCuenta = mov.IdCuenta,
                                     CodCuenta = mov.CodCuenta ?? cuenta.Codigo,
                                     NombreCuenta = cuenta.Descripcion,
                                     Debe = (decimal?)(mov.Debe ?? 0),
                                     Haber = (decimal?)(mov.Haber ?? 0),
                                     Glosa = mov.Glosa,
                                     IdCCosto = mov.IdCCosto,
                                     NombreCentroCosto = centro.Descripcion,
                                     IdAreaNeg = mov.IdAreaNeg,
                                     NombreAreaNegocio = area.Descripcion
                                 }).ToListAsync();

        var result = new ComprobanteTipoDetailDto
        {
            IdComp = compTipo.IdComp,
            IdEmpresa = compTipo.IdEmpresa ?? 0,
            Nombre = compTipo.Nombre,
            Descrip = compTipo.Descrip,
            Tipo = compTipo.Tipo,
            Glosa = compTipo.Glosa,
            TotalDebe = (decimal?)(compTipo.TotalDebe ?? 0),
            TotalHaber = (decimal?)(compTipo.TotalHaber ?? 0),
            Movimientos = movimientos
        };

        logger.LogInformation("Found voucher type '{Nombre}' with {MovCount} movements", compTipo.Nombre, movimientos.Count);
        return result;
    }

    public async Task<ComprobanteTipoDetailDto> UpdateVoucherTypeAsync(int idComp, int empresaId, ComprobanteTipoDirectCreateDto dto)
    {
        logger.LogInformation("Updating voucher type {IdComp} for empresaId={EmpresaId}", idComp, empresaId);

        var compTipo = await context.CT_Comprobante
            .FirstOrDefaultAsync(c => c.IdComp == idComp && c.IdEmpresa == empresaId);

        if (compTipo == null)
        {
            throw new BusinessException($"Plantilla {idComp} no encontrada");
        }

        // Actualizar datos del comprobante tipo
        compTipo.Nombre = dto.Nombre;
        compTipo.Descrip = dto.Descripcion;
        compTipo.Tipo = (byte?)dto.Tipo;
        compTipo.Glosa = dto.Glosa;

        // Eliminar movimientos existentes
        var movimientosExistentes = context.CT_MovComprobante
            .Where(m => m.IdComp == idComp && m.IdEmpresa == empresaId);
        context.CT_MovComprobante.RemoveRange(movimientosExistentes);

        // Crear nuevos movimientos
        decimal totalDebe = 0;
        decimal totalHaber = 0;
        var orden = 1;

        foreach (var movDto in dto.Movimientos)
        {
            var mov = new App.Data.CT_MovComprobante
            {
                IdEmpresa = empresaId,
                IdComp = idComp,
                Orden = (short)orden++,
                IdCuenta = movDto.IdCuenta,
                Debe = movDto.Debe,
                Haber = movDto.Haber,
                Glosa = movDto.Glosa
            };

            context.CT_MovComprobante.Add(mov);
            totalDebe += (decimal)movDto.Debe;
            totalHaber += (decimal)movDto.Haber;
        }

        compTipo.TotalDebe = (double)totalDebe;
        compTipo.TotalHaber = (double)totalHaber;

        await context.SaveChangesAsync();

        logger.LogInformation("Updated voucher type {IdComp} with {MovCount} movements", idComp, dto.Movimientos.Count);

        // Retornar el DTO actualizado
        return await GetVoucherTypeByIdAsync(idComp, empresaId) ?? throw new BusinessException("Error al cargar plantilla actualizada");
    }

    public async Task<ComprobanteDto> LoadFromVoucherTypeAsync(int idCompTipo)
    {
        logger.LogInformation("Loading comprobante from voucher type {IdCompTipo}", idCompTipo);

        var compTipo = await context.CT_Comprobante
            .FirstOrDefaultAsync(c => c.IdComp == idCompTipo);

        if (compTipo == null)
        {
            throw new BusinessException($"Comprobante Tipo {idCompTipo} no encontrado");
        }

        // Cargar movimientos del comprobante tipo
        var movimientos = await context.CT_MovComprobante
            .Where(m => m.IdComp == idCompTipo)
            .OrderBy(m => m.Orden)
            .ToListAsync();

        // Crear DTO para el nuevo comprobante basado en la plantilla
        var dto = new ComprobanteDto
        {
            IdComp = 0, // Nuevo comprobante
            IdEmpresa = compTipo.IdEmpresa,
            Ano = DateTime.Now.Year,
            Correlativo = null, // Se asignar? autom?ticamente
            Fecha = DateTime.Now,
            Tipo = compTipo.Tipo ?? 1,
            TipoDescripcion = GetTipoDescripcion(compTipo.Tipo ?? 1),
            Estado = 2, // Aprobado por defecto
            EstadoDescripcion = "Aprobado",
            Glosa = compTipo.Glosa ?? string.Empty,
            TotalDebe = 0,
            TotalHaber = 0,
            ImpResumido = false,
            TipoAjuste = null,
            OtrosIngEg14TER = false,
            Movimientos = new List<MovimientoDto>()
        };

        // Cargar movimientos con informaci?n completa de cuentas
        foreach (var mov in movimientos)
        {
            var cuenta = await context.Cuentas
                .FirstOrDefaultAsync(c => c.idCuenta == mov.IdCuenta && c.IdEmpresa == compTipo.IdEmpresa);

            var movDto = new MovimientoDto
            {
                IdMov = 0,
                IdEmpresa = compTipo.IdEmpresa,
                Ano = DateTime.Now.Year,
                IdComp = 0,
                Orden = mov.Orden,
                IdCuenta = mov.IdCuenta,
                CodigoCuenta = cuenta?.Codigo ?? mov.CodCuenta,
                NombreCuenta = cuenta?.Descripcion ?? string.Empty,
                Debe = mov.Debe,
                Haber = mov.Haber,
                Glosa = mov.Glosa,
                IdCCosto = mov.IdCCosto,
                IdAreaNegocio = mov.IdAreaNeg
            };

            dto.Movimientos.Add(movDto);
            dto.TotalDebe += movDto.Debe;
            dto.TotalHaber += movDto.Haber;
        }

        logger.LogInformation("Loaded {Count} movements from voucher type {IdCompTipo}", dto.Movimientos.Count, idCompTipo);
        return dto;
    }

    public async Task<ComprobanteTipoDto> CreateVoucherTypeAsync(int empresaId, ComprobanteTipoCreateDto dto)
    {
        logger.LogInformation("Creating voucher type '{Nombre}' for empresaId={EmpresaId}", dto.Nombre, empresaId);

        // Obtener comprobante origen
        var comprobanteOrigen = await GetByIdAsync(dto.IdComprobanteOrigen);
        if (comprobanteOrigen == null)
        {
            throw new BusinessException($"Comprobante origen {dto.IdComprobanteOrigen} no encontrado");
        }

        // Crear comprobante tipo
        var compTipo = new App.Data.CT_Comprobante
        {
            IdEmpresa = empresaId,
            Nombre = dto.Nombre,
            Descrip = dto.Descripcion,
            Fecha = App.Helpers.DateHelper.ToDbDate(DateTime.Now),
            Tipo = (byte?)dto.Tipo,
            Estado = 2, // Aprobado
            Glosa = dto.Glosa ?? comprobanteOrigen.Glosa,
            TotalDebe = comprobanteOrigen.TotalDebe,
            TotalHaber = comprobanteOrigen.TotalHaber,
            IdUsuario = comprobanteOrigen.IdUsuario,
            IdCompOld = dto.IdComprobanteOrigen
        };

        context.CT_Comprobante.Add(compTipo);
        await context.SaveChangesAsync();

        logger.LogInformation("Created voucher type with IdComp={IdComp}", compTipo.IdComp);

        // Copiar movimientos
        var movimientos = new List<App.Data.CT_MovComprobante>();
        foreach (var mov in comprobanteOrigen.Movimientos)
        {
            var movTipo = new App.Data.CT_MovComprobante
            {
                IdEmpresa = empresaId,
                IdComp = compTipo.IdComp,
                Orden = (short?)mov.Orden,
                IdCuenta = mov.IdCuenta,
                CodCuenta = mov.CodigoCuenta,
                Debe = mov.Debe,
                Haber = mov.Haber,
                Glosa = mov.Glosa,
                IdCCosto = mov.IdCCosto,
                IdAreaNeg = mov.IdAreaNegocio
            };
            movimientos.Add(movTipo);
        }

        context.CT_MovComprobante.AddRange(movimientos);
        await context.SaveChangesAsync();

        logger.LogInformation("Copied {Count} movements to voucher type", movimientos.Count);

        // Retornar DTO
        return new ComprobanteTipoDto
        {
            IdCompTipo = compTipo.IdComp,
            Nombre = compTipo.Nombre ?? string.Empty,
            Descripcion = compTipo.Descrip ?? string.Empty,
            Tipo = compTipo.Tipo ?? 1,
            Glosa = compTipo.Glosa ?? string.Empty,
            Movimientos = movimientos.Select(m => new MovimientoCreateDto
            {
                IdCuenta = m.IdCuenta ?? 0,
                Debe = m.Debe ?? 0,
                Haber = m.Haber ?? 0,
                Glosa = m.Glosa,
                IdCCosto = m.IdCCosto,
                IdAreaNegocio = m.IdAreaNeg
            }).ToList()
        };
    }

    public async Task<ComprobanteTipoDto> CreateVoucherTypeFromCurrentAsync(CreateVoucherTypeFromCurrentDto dto)
    {
        logger.LogInformation("Creating voucher type '{Nombre}' from current comprobante {IdComp}", dto.Nombre, dto.IdComp);

        // Obtener comprobante actual
        var comprobante = await context.Comprobante
            .FirstOrDefaultAsync(c => c.IdComp == dto.IdComp);

        if (comprobante == null)
        {
            throw new BusinessException($"Comprobante {dto.IdComp} no encontrado");
        }

        // Obtener movimientos del comprobante
        var movimientosComprobante = await context.MovComprobante
            .Where(m => m.IdComp == dto.IdComp && m.IdEmpresa == comprobante.IdEmpresa && m.Ano == comprobante.Ano)
            .OrderBy(m => m.Orden)
            .ToListAsync();

        if (!movimientosComprobante.Any())
        {
            throw new BusinessException("El comprobante debe tener al menos un movimiento");
        }

        // Crear comprobante tipo (plantilla)
        var compTipo = new App.Data.CT_Comprobante
        {
            IdEmpresa = comprobante.IdEmpresa,
            Nombre = dto.Nombre,
            Descrip = dto.Descripcion,
            Fecha = App.Helpers.DateHelper.ToDbDate(DateTime.Now),
            Tipo = (byte?)dto.Tipo,
            Estado = 2, // Aprobado (plantilla activa)
            Glosa = dto.Glosa ?? comprobante.Glosa,
            TotalDebe = dto.ConValores ? (comprobante.TotalDebe ?? 0) : 0,
            TotalHaber = dto.ConValores ? (comprobante.TotalHaber ?? 0) : 0,
            IdUsuario = comprobante.IdUsuario,
            IdCompOld = dto.IdComp // Referencia al comprobante origen
        };

        context.CT_Comprobante.Add(compTipo);
        await context.SaveChangesAsync();

        logger.LogInformation("Created voucher type with IdComp={IdComp}", compTipo.IdComp);

        // Copiar movimientos (con o sin valores seg?n configuraci?n)
        var movimientos = new List<App.Data.CT_MovComprobante>();
        var orden = 1;

        foreach (var mov in movimientosComprobante)
        {
            // Obtener c?digo de cuenta si es necesario
            string? codCuenta = null;
            if (mov.IdCuenta.HasValue)
            {
                var cuenta = await context.Cuentas
                    .Where(c => c.idCuenta == mov.IdCuenta.Value)
                    .Select(c => c.Codigo)
                    .FirstOrDefaultAsync();
                codCuenta = cuenta;
            }

            var movTipo = new App.Data.CT_MovComprobante
            {
                IdEmpresa = comprobante.IdEmpresa,
                IdComp = compTipo.IdComp,
                Orden = (short?)orden++,
                IdCuenta = mov.IdCuenta,
                CodCuenta = codCuenta,
                Debe = dto.ConValores ? (mov.Debe ?? 0) : 0,
                Haber = dto.ConValores ? (mov.Haber ?? 0) : 0,
                Glosa = mov.Glosa,
                IdCCosto = mov.idCCosto,
                IdAreaNeg = mov.idAreaNeg,
                Conciliado = false
            };
            movimientos.Add(movTipo);
        }

        context.CT_MovComprobante.AddRange(movimientos);
        await context.SaveChangesAsync();

        logger.LogInformation("Copied {Count} movements to voucher type (ConValores={ConValores})",
            movimientos.Count, dto.ConValores);

        // Retornar DTO
        return new ComprobanteTipoDto
        {
            IdCompTipo = compTipo.IdComp,
            Nombre = compTipo.Nombre ?? string.Empty,
            Descripcion = compTipo.Descrip ?? string.Empty,
            Tipo = compTipo.Tipo ?? 1,
            Glosa = compTipo.Glosa ?? string.Empty,
            Movimientos = movimientos.Select(m => new MovimientoCreateDto
            {
                IdCuenta = m.IdCuenta ?? 0,
                Debe = m.Debe ?? 0,
                Haber = m.Haber ?? 0,
                Glosa = m.Glosa,
                IdCCosto = m.IdCCosto,
                IdAreaNegocio = m.IdAreaNeg
            }).ToList()
        };
    }

    /// <summary>
    /// Crear plantilla directamente con movimientos (desde formulario nuevo)
    /// NO requiere un comprobante existente como origen
    /// </summary>
    public async Task<ComprobanteTipoDto> CreateVoucherTypeDirectAsync(ComprobanteTipoDirectCreateDto dto)
    {
        logger.LogInformation("Creating voucher type directly: '{Nombre}' for empresaId={EmpresaId}",
            dto.Nombre, dto.EmpresaId);

        if (!dto.Movimientos.Any())
        {
            throw new BusinessException("La plantilla debe tener al menos un movimiento");
        }

        using var transaction = await context.Database.BeginTransactionAsync();
        {
            // Calcular totales
            var totalDebe = dto.Movimientos.Sum(m => m.Debe);
            var totalHaber = dto.Movimientos.Sum(m => m.Haber);

            // Crear comprobante tipo
            var compTipo = new App.Data.CT_Comprobante
            {
                IdEmpresa = dto.EmpresaId,
                Nombre = dto.Nombre,
                Descrip = dto.Descripcion,
                Fecha = App.Helpers.DateHelper.ToDbDate(DateTime.Now),
                Tipo = (byte?)dto.Tipo,
                Estado = 2, // Aprobado
                Glosa = dto.Glosa,
                TotalDebe = totalDebe,
                TotalHaber = totalHaber,
                IdUsuario = null, // Plantilla sin usuario espec?fico
                IdCompOld = null
            };

            context.CT_Comprobante.Add(compTipo);
            await context.SaveChangesAsync();

            logger.LogInformation("Created voucher type with IdComp={IdComp}", compTipo.IdComp);

            // Crear movimientos
            var movimientos = new List<App.Data.CT_MovComprobante>();
            var orden = 1;

            foreach (var movDto in dto.Movimientos)
            {
                // Obtener c?digo de cuenta
                var cuenta = await context.Cuentas
                    .FirstOrDefaultAsync(c => c.idCuenta == movDto.IdCuenta && c.IdEmpresa == dto.EmpresaId);

                var movTipo = new App.Data.CT_MovComprobante
                {
                    IdEmpresa = dto.EmpresaId,
                    IdComp = compTipo.IdComp,
                    Orden = (short?)orden++,
                    IdCuenta = movDto.IdCuenta,
                    CodCuenta = cuenta?.Codigo,
                    Debe = movDto.Debe,
                    Haber = movDto.Haber,
                    Glosa = movDto.Glosa,
                    IdCCosto = null,
                    IdAreaNeg = null,
                    Conciliado = false
                };
                movimientos.Add(movTipo);
            }

            context.CT_MovComprobante.AddRange(movimientos);
            await context.SaveChangesAsync();

            await transaction.CommitAsync();

            logger.LogInformation("Created voucher type '{Nombre}' with {Count} movements",
                dto.Nombre, movimientos.Count);

            // Retornar DTO
            return new ComprobanteTipoDto
            {
                IdCompTipo = compTipo.IdComp,
                Nombre = compTipo.Nombre ?? string.Empty,
                Descripcion = compTipo.Descrip ?? string.Empty,
                Tipo = compTipo.Tipo ?? 1,
                Glosa = compTipo.Glosa ?? string.Empty,
                Movimientos = movimientos.Select(m => new MovimientoCreateDto
                {
                    IdCuenta = m.IdCuenta ?? 0,
                    Debe = m.Debe ?? 0,
                    Haber = m.Haber ?? 0,
                    Glosa = m.Glosa,
                    IdCCosto = m.IdCCosto,
                    IdAreaNegocio = m.IdAreaNeg
                }).ToList()
            };
        }
    }

    private string GetTipoDescripcion(int tipo)
    {
        return tipo switch
        {
            1 => "Egreso",
            2 => "Ingreso",
            3 => "Traspaso",
            4 => "Apertura",
            _ => "Desconocido"
        };
    }

    // ========== Helper Methods ==========

    private async Task UpdateTotalsAsync(int idComp)
    {
        var comprobante = await context.Comprobante.FindAsync(idComp);
        if (comprobante == null)
        {
            return;
        }

        var totales = await CalculateTotalsAsync(idComp);
        comprobante.TotalDebe = totales.TotalDebe;
        comprobante.TotalHaber = totales.TotalHaber;

        await context.SaveChangesAsync();
    }

    private int DateToInt(DateTime date)
    {
        return (int)date.ToOADate();
    }

    private DateTime? IntToDate(int? dateInt)
    {
        if (!dateInt.HasValue || dateInt.Value == 0)
        {
            return null;
        }

        return DateTime.FromOADate(dateInt.Value);
    }

    public async Task<CatalogsDto> GetCatalogsAsync(int empresaId, short ano)
    {
        logger.LogInformation("Getting catalogs for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            // Obtener ?reas de negocio activas
            var areasNegocio = await context.AreaNegocio
                .Where(a => a.IdEmpresa == empresaId && a.Vigente == true)
                .OrderBy(a => a.Descripcion)
                .Select(a => new AreaNegocioDto
                {
                    IdAreaNeg = a.IdAreaNegocio,
                    Descripcion = a.Descripcion ?? string.Empty
                })
                .ToListAsync();

            // Obtener centros de costo activos
            var centrosCosto = await context.CentroCosto
                .Where(c => c.IdEmpresa == empresaId && c.Vigente == true)
                .OrderBy(c => c.Descripcion)
                .Select(c => new CentroCostoDto
                {
                    IdCCosto = c.IdCCosto,
                    Descripcion = c.Descripcion ?? string.Empty
                })
                .ToListAsync();

            logger.LogInformation("Found {AreasCount} areas de negocio and {CentrosCount} centros de costo", 
                areasNegocio.Count, centrosCosto.Count);

            return new CatalogsDto
            {
                AreasNegocio = areasNegocio,
                CentrosCosto = centrosCosto
            };
        }
    }

    // ========== Activo Fijo ==========

    public async Task<bool> IsCuentaActivoFijoAsync(int idCuenta)
    {
        logger.LogInformation("Checking if cuenta {IdCuenta} is Activo Fijo", idCuenta);

        {
            var cuenta = await context.Cuentas
                .Where(c => c.idCuenta == idCuenta)
                .FirstOrDefaultAsync();

            if (cuenta == null)
            {
                return false;
            }

            // VB6: ATRIB_ACTIVOFIJO = 3, busca en Atrib3 <> 0
            // La cuenta es de Activo Fijo si Atrib3 es distinto de 0
            var isActivoFijo = cuenta.Atrib3.HasValue && cuenta.Atrib3.Value != 0;

            logger.LogInformation("Cuenta {IdCuenta} is Activo Fijo: {IsActivoFijo} (Atrib3={Atrib3})",
                idCuenta, isActivoFijo, cuenta.Atrib3);
            return isActivoFijo;
        }
    }

    public async Task<List<ActivoFijoMovimientoDto>> GetActivosFijosAsync(int idComp, int empresaId, short ano)
    {
        logger.LogInformation("Getting Activos Fijos for comprobante {IdComp}", idComp);

        {
            // VB6: Query ActFijoCompsFicha INNER JOIN ActFijoFicha
            var activosFijos = await context.ActFijoCompsFicha
                .Where(af => af.IdComp == idComp && af.IdEmpresa == empresaId && af.Ano == ano)
                .Select(af => new ActivoFijoMovimientoDto
                {
                    IdCompFicha = af.IdCompFicha,
                    IdActFijo = af.IdActFijo ?? 0,
                    IdGrupo = af.IdGrupo,
                    ValorCompra = af.ValorCompra,
                    PjeDivComp = af.PjeDivComp
                })
                .ToListAsync();

            logger.LogInformation("Found {Count} Activos Fijos for comprobante {IdComp}", 
                activosFijos.Count, idComp);

            return activosFijos;
        }
    }

    public async Task<ActivoFijoMovimientoDto> AsignarActivoFijoAsync(AsignarActivoFijoDto dto)
    {
        logger.LogInformation("Assigning Activo Fijo {IdActFijo} to movimiento {IdMov}", 
            dto.IdActFijo, dto.IdMov);

        {
            // Obtener el movimiento para saber el IdComp, IdEmpresa y Ano
            var movimiento = await context.MovComprobante
                .Where(m => m.IdMov == dto.IdMov)
                .FirstOrDefaultAsync();

            if (movimiento == null)
            {
                throw new BusinessException($"Movimiento {dto.IdMov} no encontrado");
            }

            // Verificar que la cuenta sea de Activo Fijo
            if (movimiento.IdCuenta.HasValue)
            {
                var isActivoFijo = await IsCuentaActivoFijoAsync(movimiento.IdCuenta.Value);
                if (!isActivoFijo)
                {
                    throw new BusinessException("La cuenta del movimiento no es de Activo Fijo");
                }
            }

            // Crear registro en ActFijoCompsFicha
            var compFicha = new App.Data.ActFijoCompsFicha
            {
                IdEmpresa = movimiento.IdEmpresa,
                Ano = movimiento.Ano,
                IdActFijo = dto.IdActFijo,
                IdGrupo = dto.IdGrupo,
                IdComp = movimiento.IdComp,
                PjeDivComp = (float?)(dto.PjeDivComp ?? 100), // Default 100%
                ValorCompra = (double?)(dto.ValorCompra ?? 0),
                ValorResidual = (double?)(dto.ValorResidual ?? 0),
                PjeAmortizacion = (float?)(dto.PjeAmortizacion ?? 0),
                VidaUtil = (short?)dto.VidaUtil
            };

            context.ActFijoCompsFicha.Add(compFicha);
            await context.SaveChangesAsync();

            logger.LogInformation("Activo Fijo {IdActFijo} assigned successfully with IdCompFicha {IdCompFicha}", 
                dto.IdActFijo, compFicha.IdCompFicha);

            return new ActivoFijoMovimientoDto
            {
                IdCompFicha = compFicha.IdCompFicha,
                IdActFijo = dto.IdActFijo,
                IdGrupo = dto.IdGrupo,
                ValorCompra = dto.ValorCompra,
                PjeDivComp = dto.PjeDivComp
            };
        }
    }

    public async Task RemoverActivoFijoAsync(int idCompFicha)
    {
        logger.LogInformation("Removing Activo Fijo association {IdCompFicha}", idCompFicha);

        var compFicha = await context.ActFijoCompsFicha
            .Where(af => af.IdCompFicha == idCompFicha)
            .FirstOrDefaultAsync();

        if (compFicha == null)
        {
            logger.LogWarning("ActFijoCompsFicha {IdCompFicha} not found", idCompFicha);
            throw new BusinessException("Activo fijo no encontrado");
        }

        context.ActFijoCompsFicha.Remove(compFicha);
        await context.SaveChangesAsync();

        logger.LogInformation("Activo Fijo association {IdCompFicha} removed successfully", idCompFicha);
    }

    public async Task<int> CountActivoFijoAsync(int idComp)
    {
        // VB6: CountActFijo() - l?neas 6173-6193
        {
            var count = await context.ActFijoCompsFicha
                .Where(af => af.IdComp == idComp)
                .CountAsync();

            return count;
        }
    }

    // ========== Crear Documento desde Movimiento ==========

    public async Task<GestionDocumentos.DocumentoDto> CreateDocumentFromMovimientoAsync(int idMov, CreateDocumentoFromMovimientoDto dto)
    {
        logger.LogInformation("Creating document from movimiento {IdMov}, TipoLib={TipoLib}",
            idMov, dto.TipoLib);

        {
            // Obtener datos del movimiento
            var movimiento = await context.MovComprobante
                .Where(m => m.IdMov == idMov)
                .FirstOrDefaultAsync();

            if (movimiento == null)
            {
                throw new BusinessException($"Movimiento {idMov} no encontrado");
            }

            // VB6: Validar que no sea de centralizaci?n o pago autom?tico
            if (movimiento.DeCentraliz == true)
            {
                throw new BusinessException(
                    "El movimiento seleccionado proviene de una centralizaci?n de documentos. " +
                    "No es posible cambiar la identificaci?n del documento asociado.");
            }

            if (movimiento.DePago == true)
            {
                throw new BusinessException(
                    "El movimiento seleccionado proviene de una generaci?n de pago autom?tico. " +
                    "No es posible cambiar la identificaci?n del documento asociado.");
            }

            // Obtener datos de preparaci?n (monto, entidad, etc.)
            var prepData = await PrepararCrearDocumentoAsync(idMov);

            // VB6: Crear DTO para GestionDocumentos usando datos pre-llenados
            var createDocDto = new App.Features.GestionDocumentos.DocumentoCreateDto
            {
                TipoLib = (byte)dto.TipoLib,
                TipoDoc = (byte)(dto.TipoDoc ?? 0),
                NumDoc = dto.NumDoc ?? string.Empty,
                FEmision =  dto.FechaEmision ?? DateTime.Now,
                FVenc =  dto.FechaVencimiento,
                Total = prepData.Monto, // VB6: Abs(Debe - Haber)
                IdEntidad = dto.IdEntidad ?? prepData.IdEntidad,
                TipoRelEnt = (short?)prepData.TipoLibEntidad,
                Descrip = prepData.Glosa ?? dto.Descripcion,
                Estado = 1, // ED_PENDIENTE
                DTE = false,
                DocOtrosEnAnalitico = false
            };

            // Crear documento usando GestionDocumentosService
            var idDoc = await documentosService.CreateAsync(
                prepData.IdEmpresa,
                prepData.Ano,
                0, // userId - se obtiene del servicio
                createDocDto);

            logger.LogInformation("Document {IdDoc} created successfully from movimiento {IdMov}", idDoc, idMov);

            // VB6: AsignarDoc(IdDoc, 0) - Asociar documento al movimiento
            movimiento.IdDoc = idDoc;
            await context.SaveChangesAsync();

            logger.LogInformation("Document {IdDoc} associated to movimiento {IdMov}", idDoc, idMov);

            // Obtener documento completo para retornar
            var documento = await documentosService.GetByIdAsync(idDoc, prepData.IdEmpresa, prepData.Ano);

            if (documento == null)
            {
                throw new BusinessException($"No se pudo obtener el documento creado con ID {idDoc}");
            }

            return documento;
        }
    }

    // ========== Validaciones Adicionales ==========

    public async Task<bool> IsCuentaBancoAsync(int idCuenta)
    {
        logger.LogInformation("Checking if cuenta {IdCuenta} is Banco", idCuenta);

        {
            var cuenta = await context.Cuentas
                .Where(c => c.idCuenta == idCuenta)
                .FirstOrDefaultAsync();

            if (cuenta == null)
            {
                return false;
            }

            // VB6: ValidIdCtaBanco() - l?nea 6286
            // ATRIB_CONCILIACION es bit 0 (valor 1) en Atrib1
            const int ATRIB_CONCILIACION = 1;
            var isBanco = (cuenta.Atrib1.HasValue && (cuenta.Atrib1.Value & ATRIB_CONCILIACION) != 0);

            logger.LogInformation("Cuenta {IdCuenta} is Banco: {IsBanco}", idCuenta, isBanco);
            return isBanco;
        }
    }

    public async Task<bool> ValidarMovimientoEditable(int idMov)
    {
        logger.LogInformation("Validating if movimiento {IdMov} is editable", idMov);

        {
            var movimiento = await context.MovComprobante
                .Where(m => m.IdMov == idMov)
                .FirstOrDefaultAsync();

            if (movimiento == null)
            {
                throw new BusinessException($"Movimiento {idMov} no encontrado");
            }

            // VB6: Validaciones en Bt_BuscarDoc_Click y Bt_DelDoc_Click
            var esEditable = true;
            var razon = "";

            if (movimiento.DeCentraliz == true)
            {
                esEditable = false;
                razon = "El movimiento proviene de una centralizaci?n de documentos";
            }

            if (movimiento.DePago == true)
            {
                esEditable = false;
                razon = "El movimiento proviene de una generaci?n de pago autom?tico";
            }

            if (!esEditable)
            {
                logger.LogWarning("Movimiento {IdMov} is not editable: {Reason}", idMov, razon);
            }

            return esEditable;
        }
    }

    // ========== Notas de Movimientos ==========
    // VB6: M_AddNote_Click, M_EditNote_Click, M_ViewNote_Click, M_DelNote_Click (lines 4945-5020)

    public async Task<string?> GetMovimientoNotaAsync(int idMov)
    {
        logger.LogInformation("Getting nota for movimiento {IdMov}", idMov);

        {
            var movimiento = await context.MovComprobante
                .Where(m => m.IdMov == idMov)
                .Select(m => m.Nota)
                .FirstOrDefaultAsync();

            return movimiento;
        }
    }

    public async Task SaveMovimientoNotaAsync(int idMov, string? nota)
    {
        logger.LogInformation("Saving nota for movimiento {IdMov}", idMov);

        var movimiento = await context.MovComprobante
            .Where(m => m.IdMov == idMov)
            .FirstOrDefaultAsync();

        if (movimiento == null)
        {
            logger.LogWarning("Movimiento {IdMov} not found", idMov);
            throw new BusinessException($"Movimiento {idMov} no encontrado");
        }

        movimiento.Nota = nota;
        await context.SaveChangesAsync();

        logger.LogInformation("Nota saved successfully for movimiento {IdMov}", idMov);
    }

    public async Task DeleteMovimientoNotaAsync(int idMov)
    {
        logger.LogInformation("Deleting nota for movimiento {IdMov}", idMov);

        var movimiento = await context.MovComprobante
            .Where(m => m.IdMov == idMov)
            .FirstOrDefaultAsync();

        if (movimiento == null)
        {
            logger.LogWarning("Movimiento {IdMov} not found", idMov);
            throw new BusinessException($"Movimiento {idMov} no encontrado");
        }

        movimiento.Nota = null;
        await context.SaveChangesAsync();

        logger.LogInformation("Nota deleted successfully for movimiento {IdMov}", idMov);
    }

    // ========== Ver Detalle de Documento ==========
    // VB6: Bt_DetMov_Click (lines 1382-1412)

    public async Task<DocumentoDto?> GetDocumentoDetalleFromMovimientoAsync(int idMov)
    {
        logger.LogInformation("Getting documento detalle from movimiento {IdMov}", idMov);

        var movimiento = await context.MovComprobante
            .Where(m => m.IdMov == idMov)
            .FirstOrDefaultAsync();

        if (movimiento == null)
        {
            logger.LogWarning("Movimiento {IdMov} not found", idMov);
            throw new BusinessException($"Movimiento {idMov} no encontrado");
        }

        if (movimiento.IdDoc == null)
        {
            logger.LogWarning("Movimiento {IdMov} has no documento assigned", idMov);
            throw new BusinessException("Movimiento sin documento asignado");
        }

        // Obtener el documento de la tabla Documento
        var documento = await context.Documento
            .Where(d => d.IdDoc == movimiento.IdDoc)
            .FirstOrDefaultAsync();

        if (documento == null)
        {
            logger.LogWarning("Documento {IdDoc} not found", movimiento.IdDoc);
            throw new BusinessException("Documento no encontrado");
        }

        // Mapear a DTO
        var dto = new DocumentoDto
        {
            IdDoc = documento.IdDoc,
            TipoLib = documento.TipoLib,
            TipoDoc = documento.TipoDoc,
            NumDoc = documento.NumDoc ?? string.Empty,
            RutEntidad = documento.RutEntidad,
            NombreEntidad = documento.NombreEntidad,
            FechaEmision = App.Helpers.DateHelper.FromVB6Date(documento.FEmision),
            FechaVencimiento = App.Helpers.DateHelper.FromVB6Date(documento.FVenc),
            Total = documento.Total,
            SaldoDoc = documento.SaldoDoc,
            DTE =  documento.DTE == true
        };

        logger.LogInformation("Documento {IdDoc} retrieved successfully", documento.IdDoc);
        return dto;
    }

    // ========== Validaciones Avanzadas ==========
    // VB6: Valida() function (lines 4428-4832)

    public async Task<(bool esValido, double diferencia)> ValidarComprobanteCuadradoAsync(int idComp)
    {
        logger.LogInformation("Validating if comprobante {IdComp} is balanced", idComp);

        var movimientos = await context.MovComprobante
            .Where(m => m.IdComp == idComp)
            .ToListAsync();

        var totalDebe = movimientos.Sum(m => m.Debe ?? 0);
        var totalHaber = movimientos.Sum(m => m.Haber ?? 0);
        var diferencia = Math.Abs(totalDebe - totalHaber);

        // Tolerancia de 1 peso (como VB6)
        const double TOLERANCIA = 1.0;
        var esValido = diferencia <= TOLERANCIA;

        logger.LogInformation("Comprobante {IdComp} balance: Debe={Debe}, Haber={Haber}, Diferencia={Diferencia}, Valido={Valido}",
            idComp, totalDebe, totalHaber, diferencia, esValido);

        return (esValido, diferencia);
    }

    public async Task<(bool esValido, List<int> movimientosSinCuenta)> ValidarMovimientosTienenCuentaAsync(int idComp)
    {
        logger.LogInformation("Validating if all movements have cuenta for comprobante {IdComp}", idComp);

        {
            var movimientosSinCuenta = await context.MovComprobante
                .Where(m => m.IdComp == idComp && (m.IdCuenta == null || m.IdCuenta == 0))
                .Select(m => m.IdMov)
                .ToListAsync();

            var esValido = !movimientosSinCuenta.Any();

            if (!esValido)
            {
                logger.LogWarning("Comprobante {IdComp} has {Count} movements without cuenta",
                    idComp, movimientosSinCuenta.Count);
            }

            return (esValido, movimientosSinCuenta);
        }
    }

    public async Task<bool> ValidarTieneMovimientosAsync(int idComp)
    {
        logger.LogInformation("Validating if comprobante {IdComp} has movements", idComp);

        {
            var count = await context.MovComprobante
                .Where(m => m.IdComp == idComp)
                .CountAsync();

            var esValido = count > 0;

            if (!esValido)
            {
                logger.LogWarning("Comprobante {IdComp} has no movements", idComp);
            }

            return esValido;
        }
    }

    public async Task<bool> ValidarPeriodoAbiertoAsync(DateTime fecha, int empresaId, short ano)
    {
        logger.LogInformation("Validating if period is open for fecha={Fecha}, empresa={EmpresaId}, ano={Ano}",
            fecha, empresaId, ano);

        {
            var mes = fecha.Month;

            // Verificar en tabla EstadoMes
            var estadoMes = await context.EstadoMes
                .Where(e => e.IdEmpresa == empresaId && e.Ano == ano && e.Mes == mes)
                .FirstOrDefaultAsync();

            if (estadoMes == null)
            {
                logger.LogWarning("EstadoMes not found for empresa={EmpresaId}, ano={Ano}, mes={Mes}", empresaId, ano, mes);
                return false;
            }

            // Estado 1 = Abierto, 2 = Cerrado
            var estaAbierto = estadoMes.Estado == (short?)1;

            if (!estaAbierto)
            {
                logger.LogWarning("Period is closed for empresa={EmpresaId}, ano={Ano}, mes={Mes}", empresaId, ano, mes);
            }

            return estaAbierto;
        }
    }

    public async Task<bool> ValidarCuentaBancoParaChequeAsync(int idCuenta)
    {
        logger.LogInformation("Validating if cuenta {IdCuenta} is banco for cheque", idCuenta);

        {
            // Reutilizar el m?todo IsCuentaBancoAsync que ya implementamos
            var esBanco = await IsCuentaBancoAsync(idCuenta);

            if (!esBanco)
            {
                logger.LogWarning("Cuenta {IdCuenta} is not tipo banco, cannot print cheque", idCuenta);
            }

            return esBanco;
        }
    }

    /// <summary>
    /// Navega entre comprobantes (first, prev, next, last)
    /// VB6: FrmComprobante.frm - Bt_First_Click, Bt_Prev_Click, Bt_Next_Click, Bt_Last_Click
    /// </summary>
    public async Task<object> NavigateVoucherAsync(string? direction, int? currentId, int empresaId, short ano)
    {
        // Validación de negocio en Service
        if (string.IsNullOrWhiteSpace(direction))
            throw new BusinessException("La dirección de navegación es requerida");

        logger.LogInformation("Navigating voucher: direction={Direction}, currentId={CurrentId}, empresaId={EmpresaId}, ano={Ano}",
            direction, currentId, empresaId, ano);

        {
            int? targetId = null;

            switch (direction.ToLower())
            {
                case "first":
                    // Primer comprobante del a?o/empresa
                    targetId = await context.Comprobante
                        .Where(c => c.IdEmpresa == empresaId && c.Ano == ano && c.Estado != (byte?)1) // Excluir anulados
                        .OrderBy(c => c.Fecha)
                        .ThenBy(c => c.Correlativo)
                        .Select(c => c.IdComp)
                        .FirstOrDefaultAsync();
                    break;

                case "prev":
                    if (!currentId.HasValue) return new { idComp = (int?)null };

                    // Comprobante anterior
                    var current = await context.Comprobante.FindAsync(currentId.Value);
                    if (current == null) return new { idComp = (int?)null };

                    targetId = await context.Comprobante
                        .Where(c => c.IdEmpresa == empresaId &&
                                    c.Ano == ano &&
                                    c.Estado != (byte?)1 &&
                                    (c.Fecha < current.Fecha ||
                                     (c.Fecha == current.Fecha && c.Correlativo < current.Correlativo)))
                        .OrderByDescending(c => c.Fecha)
                        .ThenByDescending(c => c.Correlativo)
                        .Select(c => c.IdComp)
                        .FirstOrDefaultAsync();
                    break;

                case "next":
                    if (!currentId.HasValue) return new { idComp = (int?)null };

                    // Comprobante siguiente
                    var currentNext = await context.Comprobante.FindAsync(currentId.Value);
                    if (currentNext == null) return new { idComp = (int?)null };

                    targetId = await context.Comprobante
                        .Where(c => c.IdEmpresa == empresaId &&
                                    c.Ano == ano &&
                                    c.Estado != (byte?)1 &&
                                    (c.Fecha > currentNext.Fecha ||
                                     (c.Fecha == currentNext.Fecha && c.Correlativo > currentNext.Correlativo)))
                        .OrderBy(c => c.Fecha)
                        .ThenBy(c => c.Correlativo)
                        .Select(c => c.IdComp)
                        .FirstOrDefaultAsync();
                    break;

                case "last":
                    // ?ltimo comprobante del a?o/empresa
                    targetId = await context.Comprobante
                        .Where(c => c.IdEmpresa == empresaId && c.Ano == ano && c.Estado != (byte?)1)
                        .OrderByDescending(c => c.Fecha)
                        .ThenByDescending(c => c.Correlativo)
                        .Select(c => c.IdComp)
                        .FirstOrDefaultAsync();
                    break;

                default:
                    throw new BusinessException($"Invalid navigation direction: {direction}");
            }

            logger.LogInformation("Navigation result: targetId={TargetId}", targetId);
            return new { idComp = targetId };
        }
    }

    /// <summary>
    /// Busca comprobantes con filtros
    /// VB6: FrmComprobante.frm - Bt_Find_Click
    /// </summary>
    public async Task<List<VoucherSearchResultDto>> SearchVouchersAsync(VoucherSearchFilters filters)
    {
        logger.LogInformation("Searching vouchers with filters: empresaId={EmpresaId}, ano={Ano}, correlativo={Correlativo}",
            filters.EmpresaId, filters.Ano, filters.Correlativo);

        {
            var query = context.Comprobante
                .Where(c => c.IdEmpresa == filters.EmpresaId && c.Ano == filters.Ano);

            // Aplicar filtros opcionales
            if (filters.Correlativo.HasValue)
            {
                query = query.Where(c => c.Correlativo == filters.Correlativo.Value);
            }

            if (filters.Tipo.HasValue)
            {
                query = query.Where(c => c.Tipo == filters.Tipo.Value);
            }

            if (filters.Estado.HasValue)
            {
                query = query.Where(c => c.Estado == filters.Estado.Value);
            }
            else
            {
                // Por defecto, excluir anulados
                query = query.Where(c => c.Estado != (byte?)1);
            }

            if (!string.IsNullOrEmpty(filters.FechaDesde))
            {
                if (DateTime.TryParse(filters.FechaDesde, out var fechaDesde))
                {
                    var fechaDesdeDb = App.Helpers.DateHelper.ToDbDate(fechaDesde);
                    query = query.Where(c => c.Fecha >= fechaDesdeDb);
                }
            }

            if (!string.IsNullOrEmpty(filters.FechaHasta))
            {
                if (DateTime.TryParse(filters.FechaHasta, out var fechaHasta))
                {
                    var fechaHastaDb = App.Helpers.DateHelper.ToDbDate(fechaHasta);
                    query = query.Where(c => c.Fecha <= fechaHastaDb);
                }
            }

            if (!string.IsNullOrEmpty(filters.Glosa))
            {
                query = query.Where(c => c.Glosa != null && c.Glosa.Contains(filters.Glosa));
            }

            // Ordenar por fecha y correlativo descendente (m?s recientes primero)
            var results = await query
                .OrderByDescending(c => c.Fecha)
                .ThenByDescending(c => c.Correlativo)
                .Take(100) // Limitar a 100 resultados
                .Select(c => new VoucherSearchResultDto
                {
                    IdComp = c.IdComp,
                    Correlativo = c.Correlativo,
                    Fecha = c.Fecha.HasValue ? App.Helpers.DateHelper.FromDbDate(c.Fecha.Value).ToString("dd/MM/yyyy") : null,
                    Tipo = c.Tipo ?? 0,
                    Glosa = c.Glosa,
                    TotalDebe = c.TotalDebe,
                    TotalHaber = c.TotalHaber,
                    Estado = c.Estado ?? 0
                })
                .ToListAsync();

            logger.LogInformation("Found {Count} vouchers matching filters", results.Count);
            return results;
        }
    }

    // ========== INTEGRACI?N CON ACTIVO FIJO ==========
    // VB6: FrmComprobante.frm - ActivoFijo() (l?neas 6098-6222)
    // Integraci?n con feature existente: \app\Features\GestionActivoFijo

    /// <summary>
    /// Verifica si un movimiento tiene un activo fijo asociado
    /// VB6: CountActFijo() - l?nea 6223
    /// </summary>
    public async Task<bool> MovimientoTieneActivoFijoAsync(int idMov)
    {
        {
            logger.LogInformation("Checking if movement {IdMov} has associated fixed asset", idMov);

            // Obtener el movimiento
            var movimiento = await context.MovComprobante
                .FirstOrDefaultAsync(m => m.IdMov == idMov);

            if (movimiento == null)
            {
                logger.LogWarning("Movement {IdMov} not found", idMov);
                return false;
            }

            // Verificar si existe un activo fijo asociado a este movimiento
            // La tabla MovActivoFijo tiene IdMovComp como referencia
            var tieneActivo = await context.Set<App.Data.MovActivoFijo>()
                .AnyAsync(af => af.IdMovComp == idMov && af.IdEmpresa == movimiento.IdEmpresa);

            logger.LogInformation("Movement {IdMov} has fixed asset: {HasAsset}", idMov, tieneActivo);
            return tieneActivo;
        }
    }

    /// <summary>
    /// Obtiene el ID del activo fijo asociado a un movimiento
    /// VB6: GridActivoFijo() - l?nea 6098
    /// </summary>
    public async Task<int?> GetIdActivoFijoByMovimientoAsync(int idMov)
    {
        {
            logger.LogInformation("Getting fixed asset ID for movement {IdMov}", idMov);

            var movimiento = await context.MovComprobante
                .FirstOrDefaultAsync(m => m.IdMov == idMov);

            if (movimiento == null)
            {
                logger.LogWarning("Movement {IdMov} not found", idMov);
                return null;
            }

            var activoFijo = await context.Set<App.Data.MovActivoFijo>()
                .Where(af => af.IdMovComp == idMov && af.IdEmpresa == movimiento.IdEmpresa)
                .Select(af => af.IdActFijo)
                .FirstOrDefaultAsync();

            logger.LogInformation("Fixed asset ID for movement {IdMov}: {IdActFijo}", idMov, activoFijo);
            return activoFijo > 0 ? activoFijo : null;
        }
    }

    /// <summary>
    /// Prepara los datos para abrir la gesti?n de activo fijo desde un movimiento
    /// VB6: Bt_ActivoFijo_Click() - l?nea 1802
    /// </summary>
    public async Task<ActivoFijoIntegrationDto> PrepararActivoFijoAsync(int idMov)
    {
        {
            logger.LogInformation("Preparing fixed asset integration for movement {IdMov}", idMov);

            var movimiento = await context.MovComprobante
                .FirstOrDefaultAsync(m => m.IdMov == idMov);

            if (movimiento == null)
            {
                throw new BusinessException($"Movimiento {idMov} no encontrado");
            }

            // Verificar si ya tiene activo fijo asociado
            var idActivoFijo = await GetIdActivoFijoByMovimientoAsync(idMov);

            var result = new ActivoFijoIntegrationDto
            {
                IdMov = idMov,
                IdEmpresa = movimiento.IdEmpresa ?? 0,
                Ano = movimiento.Ano ?? 0,
                IdActivoFijo = idActivoFijo,
                TieneActivoAsociado = idActivoFijo.HasValue,
                // Datos del movimiento para pre-cargar en GestionActivoFijo
                IdCuenta = movimiento.IdCuenta,
                Debe = movimiento.Debe,
                Haber = movimiento.Haber,
                Glosa = movimiento.Glosa
            };

            logger.LogInformation("Fixed asset integration prepared: {Data}", result);
            return result;
        }
    }

    // ========== INTEGRACI?N CON IMPRESI?N DE CHEQUES ==========
    // VB6: FrmComprobante.frm - Bt_PrtCheque_Click() (l?neas 1908-2024)
    // Integraci?n con feature existente: \app\Features\ImpresionCheques

    /// <summary>
    /// Prepara los datos para imprimir cheque desde comprobante
    /// VB6: Bt_PrtCheque_Click() - l?nea 1908
    /// </summary>
    public async Task<ChequeIntegrationDto> PrepararImpresionChequeAsync(PrepararChequeDto dto)
    {
        logger.LogInformation("Preparing check printing for voucher {IdComp}, movements: {Movements}",
            dto.IdComp, string.Join(",", dto.IdMovimientos));

        // Validar movimientos primero
        await ValidarMovimientosParaChequeAsync(dto.IdMovimientos);

        // Obtener comprobante
        var comprobante = await context.Comprobante
            .FirstOrDefaultAsync(c => c.IdComp == dto.IdComp);

        if (comprobante == null)
            throw new BusinessException($"Comprobante {dto.IdComp} no encontrado");

        // Obtener movimientos seleccionados
        var movimientos = await context.MovComprobante
            .Where(m => dto.IdMovimientos.Contains(m.IdMov) && m.IdComp == dto.IdComp)
            .ToListAsync();

        if (!movimientos.Any())
            throw new BusinessException("No se encontraron movimientos seleccionados");

            // Calcular total
            var totalCheque = movimientos.Sum(m => m.Haber ?? 0);

            var result = new ChequeIntegrationDto
            {
                IdComp = dto.IdComp,
                IdEmpresa = comprobante.IdEmpresa ?? 0,
                Fecha = comprobante.Fecha.HasValue ? App.Helpers.DateHelper.FromDbDate(comprobante.Fecha.Value) : DateTime.Now,
                Glosa = comprobante.Glosa,
                Monto = totalCheque,
                IdMovimientos = dto.IdMovimientos,
                // Datos para ImpresionCheques
                NumeroMovimientos = movimientos.Count,
                DetalleMovimientos = movimientos.Select(m => new MovimientoChequeDto
                {
                    IdMov = m.IdMov,
                    Glosa = m.Glosa,
                    Monto = m.Haber ?? 0
                }).ToList()
            };

        logger.LogInformation("Check printing prepared: Total={Total}, Movements={Count}",
            totalCheque, movimientos.Count);
        return result;
    }

    /// <summary>
    /// Valida que los movimientos seleccionados puedan imprimir cheque
    /// VB6: Validaciones en Bt_PrtCheque_Click()
    /// </summary>
    public async Task ValidarMovimientosParaChequeAsync(List<int> idMovimientos)
    {
        logger.LogInformation("Validating movements for check printing: {Movements}",
            string.Join(",", idMovimientos));

        if (!idMovimientos.Any())
        {
            throw new BusinessException("Debe seleccionar al menos un movimiento");
        }

        var movimientos = await context.MovComprobante
            .Where(m => idMovimientos.Contains(m.IdMov))
            .ToListAsync();

        if (movimientos.Count != idMovimientos.Count)
        {
            throw new BusinessException("Algunos movimientos no fueron encontrados");
        }

        // Validar que todos los movimientos tengan Haber (son egresos)
        var movimientosSinHaber = movimientos.Where(m => (m.Haber ?? 0) <= 0).ToList();
        if (movimientosSinHaber.Any())
        {
            throw new BusinessException("Los movimientos seleccionados deben tener valor en Haber (egresos)");
        }

        // Validar que todos sean del mismo comprobante
        var idComps = movimientos.Select(m => m.IdComp).Distinct().ToList();
        if (idComps.Count > 1)
        {
            throw new BusinessException("Todos los movimientos deben pertenecer al mismo comprobante");
        }

        logger.LogInformation("Movements validated successfully for check printing");
    }

    // ========== INTEGRACI?N CON GESTION DOCUMENTOS ==========

    /// <summary>
    /// Prepara datos para crear un nuevo documento desde un movimiento
    /// VB6: Bt_NewDoc_Click() - l?neas 1615-1706
    /// Integraci?n con: \app\Features\GestionDocumentos
    /// </summary>
    public async Task<CrearDocumentoIntegrationDto> PrepararCrearDocumentoAsync(int idMov)
    {
        {
            logger.LogInformation("Preparing to create document from movement {IdMov}", idMov);

            // Obtener el movimiento
            var movimiento = await context.MovComprobante
                .FirstOrDefaultAsync(m => m.IdMov == idMov);

            if (movimiento == null)
            {
                throw new BusinessException($"Movimiento {idMov} no encontrado");
            }

            // Obtener el comprobante
            var comprobante = await context.Comprobante
                .FirstOrDefaultAsync(c => c.IdComp == movimiento.IdComp);

            if (comprobante == null)
            {
                throw new BusinessException("Comprobante no encontrado");
            }

            // Validar que el movimiento no venga de centralizaci?n
            if (movimiento.DeCentraliz == true)
            {
                throw new BusinessException("El movimiento proviene de una centralizaci?n. No es posible crear documento asociado.");
            }

            // Validar que el movimiento no venga de pago autom?tico
            if (movimiento.DePago == true) // NEW_DEPAGO
            {
                throw new BusinessException("El movimiento proviene de un pago autom?tico. No es posible crear documento asociado.");
            }

            // Calcular el monto del documento (diferencia entre Debe y Haber)
            var monto = Math.Abs((movimiento.Debe ?? 0) - (movimiento.Haber ?? 0));

            // Intentar obtener datos de la fila anterior (para cheques de pago)
            int? idEntidad = null;
            int? tipoLibEntidad = null;

            // Buscar movimientos del mismo comprobante ordenados
            var movimientos = await context.MovComprobante
                .Where(m => m.IdComp == movimiento.IdComp && m.IdEmpresa == movimiento.IdEmpresa)
                .OrderBy(m => m.Orden)
                .ToListAsync();

            var indexActual = movimientos.FindIndex(m => m.IdMov == idMov);
            if (indexActual > 0)
            {
                var movAnterior = movimientos[indexActual - 1];
                if (movAnterior.IdDoc.HasValue && movAnterior.IdDoc > 0)
                {
                    // Obtener datos del documento anterior
                    var docAnterior = await context.Set<App.Data.Documento>()
                        .Where(d => d.IdDoc == movAnterior.IdDoc && d.IdEmpresa == movimiento.IdEmpresa)
                        .FirstOrDefaultAsync();

                    if (docAnterior != null)
                    {
                        idEntidad = docAnterior.IdEntidad;
                        tipoLibEntidad = docAnterior.TipoLib;
                    }
                }
            }

            var result = new CrearDocumentoIntegrationDto
            {
                IdMov = idMov,
                IdComp = movimiento.IdComp ?? 0,
                IdEmpresa = movimiento.IdEmpresa ?? 0,
                Ano = comprobante.Ano ?? 0,
                Mes = comprobante.Fecha.HasValue ? DateHelper.FromDbDate(comprobante.Fecha.Value).Month : DateTime.Now.Month,
                Monto = monto,
                IdEntidad = idEntidad,
                TipoLibEntidad = (byte?)tipoLibEntidad,
                Glosa = movimiento.Glosa
            };

            logger.LogInformation("Document creation prepared for movement {IdMov}, amount: {Monto}", idMov, monto);
            return result;
        }
    }

    /// <summary>
    /// Prepara datos para ver el detalle de un documento asociado a un movimiento
    /// VB6: Bt_DetMov_Click() - l?neas 1382-1410
    /// Integraci?n con: \app\Features\GestionDocumentos
    /// </summary>
    public async Task<VerDocumentoIntegrationDto> PrepararVerDocumentoAsync(int idMov)
    {
        {
            logger.LogInformation("Preparing to view document from movement {IdMov}", idMov);

            // Obtener el movimiento
            var movimiento = await context.MovComprobante
                .FirstOrDefaultAsync(m => m.IdMov == idMov);

            if (movimiento == null)
            {
                throw new BusinessException($"Movimiento {idMov} no encontrado");
            }

            if (!movimiento.IdDoc.HasValue || movimiento.IdDoc <= 0)
            {
                throw new BusinessException("El movimiento no tiene un documento asociado");
            }

            // Obtener el documento para determinar el tipo
            var documento = await context.Set<App.Data.Documento>()
                .Where(d => d.IdDoc == movimiento.IdDoc && d.IdEmpresa == movimiento.IdEmpresa)
                .FirstOrDefaultAsync();

            int tipoDoc = documento?.TipoDoc ?? 0;

            var result = new VerDocumentoIntegrationDto
            {
                IdDoc = movimiento.IdDoc.Value,
                IdMov = idMov,
                IdEmpresa = movimiento.IdEmpresa ?? 0,
                Ano = (byte)tipoDoc,
                TipoDoc = (byte)tipoDoc,
                IdDocCuota = movimiento.IdDocCuota
            };

            logger.LogInformation("Document view prepared for movement {IdMov}, IdDoc: {IdDoc}", idMov, result.IdDoc);
            return result;
        }
    }

    private async Task<int> GetAnoFromMovimientoAsync(int idMov)
    {
        var comprobante = await (from m in context.MovComprobante
                                 join c in context.Comprobante on m.IdComp equals c.IdComp
                                 where m.IdMov == idMov
                                 select c.Ano).FirstOrDefaultAsync();

        return comprobante ?? DateTime.Now.Year;
    }

    // ========== CENTRALIZACIONES ==========

    /// <summary>
    /// Verifica si un comprobante es de centralizaci?n completa
    /// VB6: ValidaCompFull() - l?neas 6600-6619
    /// </summary>
    public async Task<bool> EsCentralizacionFullAsync(int idComp, int empresaId, short ano)
    {
        {
            logger.LogInformation("Checking if voucher {IdComp} is full centralization", idComp);

            var count = await context.Set<App.Data.tbl_Comp_Centra_Full>()
                .Where(c => c.IdComp == idComp && c.IdEmpresa == empresaId && c.ano == ano.ToString())
                .CountAsync();

            return count == 1;
        }
    }

    /// <summary>
    /// Marca un comprobante como centralizaci?n completa
    /// VB6: InsertComprCentraFull() - l?neas 6582-6598
    /// </summary>
    public async Task MarcarComoCentralizacionFullAsync(int idComp, int empresaId, short ano)
    {
        {
            logger.LogInformation("Marking voucher {IdComp} as full centralization", idComp);

            // Verificar si ya existe
            var existe = await EsCentralizacionFullAsync(idComp, empresaId, ano);
            if (existe)
            {
                logger.LogWarning("Voucher {IdComp} is already marked as full centralization", idComp);
                return;
            }

            // Insertar registro
            var registro = new App.Data.tbl_Comp_Centra_Full
            {
                IdComp = idComp,
                IdEmpresa = empresaId,
                Tipo = "1",
                Fecha = DateHelper.ToDbDate(DateTime.Now),
                ano = ano.ToString()
            };

            context.Set<App.Data.tbl_Comp_Centra_Full>().Add(registro);
            await context.SaveChangesAsync();

            logger.LogInformation("Voucher {IdComp} marked as full centralization", idComp);
        }
    }

    /// <summary>
    /// Calcula los totales completos de un comprobante (incluyendo todos los movimientos guardados)
    /// VB6: CalcTotFull() - l?neas 6526-6580
    /// </summary>
    public async Task<TotalesCentralizacionDto> CalcularTotalesFullAsync(int idComp, int empresaId, short ano)
    {
        {
            logger.LogInformation("Calculating full totals for voucher {IdComp}", idComp);

            // Sumar todos los movimientos guardados en la base de datos
            var totales = await context.MovComprobante
                .Where(m => m.IdComp == idComp && m.IdEmpresa == empresaId)
                .GroupBy(m => 1)
                .Select(g => new
                {
                    TotalDebe = g.Sum(m => m.Debe ?? 0),
                    TotalHaber = g.Sum(m => m.Haber ?? 0)
                })
                .FirstOrDefaultAsync();

            var result = new TotalesCentralizacionDto
            {
                TotalDebe = totales?.TotalDebe,
                TotalHaber = totales?.TotalHaber,
                Diferencia = (totales?.TotalDebe ?? 0) - (totales?.TotalHaber ?? 0),
                EsCentralizacionFull = await EsCentralizacionFullAsync(idComp, empresaId, ano)
            };

            logger.LogInformation("Full totals calculated: Debe={Debe}, Haber={Haber}", result.TotalDebe, result.TotalHaber);
            return result;
        }
    }

    /// <summary>
    /// Deja en cero todos los movimientos de un comprobante (usado al anular)
    /// VB6: DejarEnCeroMovs() - l?neas 6337-6358
    /// </summary>
    public async Task DejarEnCeroMovimientosAsync(int idComp, int empresaId)
    {
        {
            logger.LogInformation("Setting all movements to zero for voucher {IdComp}", idComp);

            var movimientos = await context.MovComprobante
                .Where(m => m.IdComp == idComp && m.IdEmpresa == empresaId)
                .ToListAsync();

            foreach (var mov in movimientos)
            {
                mov.Debe = 0;
                mov.Haber = 0;
            }

            await context.SaveChangesAsync();

            logger.LogInformation("All movements set to zero for voucher {IdComp}", idComp);
        }
    }


    // ========== NUEVO DOCUMENTO (Modal Inline) ==========

    /// <summary>
    /// Obtiene tipos de documento filtrados por tipo de libro
    /// VB6: FrmDoc - carga de combo TipoDoc basado en TipoLib
    /// </summary>
    public async Task<List<TipoDocumentoDto>> GetTiposDocumentoAsync(int tipoLib, int empresaId)
    {
        logger.LogInformation("Getting document types for TipoLib={TipoLib}, EmpresaId={EmpresaId}", tipoLib, empresaId);

        var tiposDoc = await context.TipoDocs
            .Where(td => td.TipoLib == tipoLib)
            .OrderBy(td => td.TipoDoc)
            .Select(td => new TipoDocumentoDto
            {
                TipoDoc = td.TipoDoc ?? 0,
                Nombre = td.Nombre ?? string.Empty,
                Codigo = td.Diminutivo ?? string.Empty
            })
            .ToListAsync();

        logger.LogInformation("Found {Count} document types", tiposDoc.Count);
        return tiposDoc;
    }

    /// <summary>
    /// Busca una entidad por RUT
    /// VB6: FrmDoc - b?squeda en entidades para autocompletar nombre
    /// </summary>
    public async Task<EntidadBusquedaDto?> BuscarEntidadPorRutAsync(string? rut, int empresaId)
    {
        // Validación de negocio en Service
        if (string.IsNullOrWhiteSpace(rut))
            throw new BusinessException("El RUT es requerido");

        // Normalizar RUT (quitar puntos y gui?n)
        var rutNormalizado = rut.Replace(".", "").Replace("-", "").Trim().ToUpper();

        logger.LogInformation("Searching entity by RUT={Rut}, EmpresaId={EmpresaId}", rutNormalizado, empresaId);

        var entidad = await context.Entidades
            .Where(e => e.IdEmpresa == empresaId &&
                        e.Rut != null &&
                        e.Rut.Replace(".", "").Replace("-", "").ToUpper() == rutNormalizado)
            .Select(e => new EntidadBusquedaDto
            {
                IdEntidad = e.IdEntidad,
                Rut = e.Rut ?? string.Empty,
                Nombre = e.Nombre ?? string.Empty,
                Clasificacion = e.Clasif0
            })
            .FirstOrDefaultAsync();

        if (entidad != null)
        {
            logger.LogInformation("Entity found: {IdEntidad} - {Nombre}", entidad.IdEntidad, entidad.Nombre);
        }
        else
        {
            logger.LogInformation("Entity not found for RUT={Rut}", rutNormalizado);
        }

        return entidad;
    }

    /// <summary>
    /// Crea un nuevo documento desde el modal inline
    /// VB6: FrmDoc.FNew() - Crea documento y retorna para asociar a movimiento
    /// </summary>
    public async Task<DocumentoCreatedDto> CrearDocumentoAsync(int empresaId, short ano, int usuarioId, CrearDocumentoDto dto)
    {
        logger.LogInformation("Creating new document for EmpresaId={EmpresaId}, Ano={Ano}", empresaId, ano);

        // Obtener nombre de entidad si existe
        string? entidadNombre = null;
        string? entidadRut = null;
        if (dto.IdEntidad.HasValue)
        {
            var entidad = await context.Entidades
                .Where(e => e.IdEntidad == dto.IdEntidad.Value)
                .Select(e => new { e.Nombre, e.Rut })
                .FirstOrDefaultAsync();

            entidadNombre = entidad?.Nombre;
            entidadRut = entidad?.Rut;
        }

        // Crear el documento
        var documento = new App.Data.Documento
        {
            IdEmpresa = empresaId,
            Ano = ano,
            TipoLib = (byte)dto.TipoLib,
            TipoDoc = (byte)dto.TipoDoc,
            NumDoc = dto.NumDoc,
            FEmision =  DateToInt(dto.FechaEmision),
            IdEntidad = dto.IdEntidad,
            RutEntidad = entidadRut,
            NombreEntidad = entidadNombre,
            Total = dto.Monto,
            SaldoDoc = dto.Monto,
            Estado = (short)dto.Estado,
            Descrip = dto.Observaciones,
            DTE =  dto.DTE,
            FechaCreacion = DateToInt(DateTime.Now),
            IdUsuario = usuarioId
        };

        context.Documento.Add(documento);
        await context.SaveChangesAsync();

        logger.LogInformation("Document created with IdDoc={IdDoc}", documento.IdDoc);

        // Obtener nombre del tipo de documento
        var tipoDocNombre = await context.TipoDocs
            .Where(td => td.TipoLib == dto.TipoLib && td.TipoDoc == dto.TipoDoc)
            .Select(td => td.Nombre)
            .FirstOrDefaultAsync() ?? string.Empty;

        return new DocumentoCreatedDto
        {
            IdDoc = documento.IdDoc,
            TipoLib = dto.TipoLib,
            TipoDoc = dto.TipoDoc,
            TipoDocNombre = tipoDocNombre,
            NumDoc = dto.NumDoc,
            FechaEmision = dto.FechaEmision,
            IdEntidad = dto.IdEntidad,
            RutEntidad = entidadRut,
            NombreEntidad = entidadNombre,
            Total = dto.Monto,
            SaldoDoc = dto.Monto, // Nuevo documento, saldo = monto
            DTE =  dto.DTE         };
    }
}
