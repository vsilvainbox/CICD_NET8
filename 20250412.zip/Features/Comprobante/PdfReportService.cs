using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace App.Features.Comprobante;

/// <summary>
/// Servicio de generación de reportes PDF profesionales para comprobantes
/// Migrado desde VB6: FPrtComp(), PrtFooterMembreteRight(), PrtFooterMembreteLeft()
/// </summary>
public class PdfReportService : IPdfReportService
{
    private readonly ILogger<PdfReportService> _logger;

    public PdfReportService(ILogger<PdfReportService> logger)
    {
        _logger = logger;
        
        // Configurar licencia de QuestPDF (Community License)
        QuestPDF.Settings.License = LicenseType.Community;
    }

    public byte[] GenerateComprobantePdf(ComprobanteDto comprobante, bool resumido = false)
    {
        _logger.LogInformation("Generating PDF report for comprobante {IdComp}, resumido={Resumido}", 
            comprobante.IdComp, resumido);

        {
            var document = Document.Create(container =>
            {
                container.Page(page =>
                {
                    page.Size(PageSizes.Letter);
                    page.Margin(1, Unit.Centimetre);
                    page.PageColor(Colors.White);
                    page.DefaultTextStyle(x => x.FontSize(10).FontFamily("Arial"));

                    // Header
                    page.Header().Element(c => ComposeHeader(c, comprobante));

                    // Content
                    page.Content().Element(c => ComposeContent(c, comprobante, resumido));

                    // Footer
                    page.Footer().Element(c => ComposeFooter(c, comprobante));
                });
            });

            return document.GeneratePdf();
        }
    }

    private void ComposeHeader(IContainer container, ComprobanteDto comprobante)
    {
        container.Column(column =>
        {
            // Título principal
            column.Item().AlignCenter().PaddingBottom(5).Text("COMPROBANTE CONTABLE")
                .FontSize(16)
                .Bold()
                .FontColor(Colors.Blue.Darken2);

            column.Item().PaddingBottom(10).LineHorizontal(2).LineColor(Colors.Blue.Darken2);

            // Información del comprobante
            column.Item().Row(row =>
            {
                // Columna izquierda
                row.RelativeItem().Column(leftColumn =>
                {
                    leftColumn.Item().Text(text =>
                    {
                        text.Span("Número: ").Bold();
                        text.Span($"{comprobante.Correlativo}");
                    });

                    leftColumn.Item().Text(text =>
                    {
                        text.Span("Tipo: ").Bold();
                        text.Span($"{comprobante.TipoDescripcion}");
                    });

                    leftColumn.Item().Text(text =>
                    {
                        text.Span("Estado: ").Bold();
                        text.Span($"{comprobante.EstadoDescripcion}");
                    });
                });

                // Columna derecha
                row.RelativeItem().Column(rightColumn =>
                {
                    rightColumn.Item().AlignRight().Text(text =>
                    {
                        text.Span("Fecha: ").Bold();
                        text.Span($"{comprobante.Fecha:dd/MM/yyyy}");
                    });

                    rightColumn.Item().AlignRight().Text(text =>
                    {
                        text.Span("Empresa: ").Bold();
                        text.Span($"{comprobante.IdEmpresa}");
                    });

                    rightColumn.Item().AlignRight().Text(text =>
                    {
                        text.Span("Año: ").Bold();
                        text.Span($"{comprobante.Ano}");
                    });
                });
            });

            // Glosa
            column.Item().PaddingTop(10).Text(text =>
            {
                text.Span("Glosa: ").Bold();
                text.Span($"{comprobante.Glosa}");
            });

            column.Item().PaddingTop(10).LineHorizontal(1).LineColor(Colors.Grey.Lighten2);
        });
    }

    private void ComposeContent(IContainer container, ComprobanteDto comprobante, bool resumido)
    {
        container.PaddingTop(10).Column(column =>
        {
            // Título de sección
            column.Item().PaddingBottom(5).Text("DETALLE DE MOVIMIENTOS")
                .FontSize(12)
                .Bold();

            if (!resumido)
            {
                // Tabla de movimientos detallada
                column.Item().Table(table =>
                {
                    // Definir columnas
                    table.ColumnsDefinition(columns =>
                    {
                        columns.ConstantColumn(40);  // Orden
                        columns.ConstantColumn(80);  // Código Cuenta
                        columns.RelativeColumn(3);   // Nombre Cuenta
                        columns.RelativeColumn(2);   // Glosa
                        columns.ConstantColumn(80);  // Debe
                        columns.ConstantColumn(80);  // Haber
                    });

                    // Header de tabla
                    table.Header(header =>
                    {
                        header.Cell().Element(CellStyle).Text("Ord").Bold();
                        header.Cell().Element(CellStyle).Text("Código").Bold();
                        header.Cell().Element(CellStyle).Text("Cuenta").Bold();
                        header.Cell().Element(CellStyle).Text("Glosa").Bold();
                        header.Cell().Element(CellStyle).AlignRight().Text("Debe").Bold();
                        header.Cell().Element(CellStyle).AlignRight().Text("Haber").Bold();

                        static IContainer CellStyle(IContainer c) => c
                            .Background(Colors.Grey.Lighten3)
                            .Padding(5)
                            .BorderBottom(1)
                            .BorderColor(Colors.Grey.Medium);
                    });

                    // Filas de datos
                    foreach (var mov in comprobante.Movimientos)
                    {
                        table.Cell().Element(DataCellStyle).Text($"{mov.Orden}");
                        table.Cell().Element(DataCellStyle).Text($"{mov.CodigoCuenta}");
                        table.Cell().Element(DataCellStyle).Text($"{mov.NombreCuenta}");
                        table.Cell().Element(DataCellStyle).Text($"{mov.Glosa}");
                        table.Cell().Element(DataCellStyle).AlignRight().Text($"{mov.Debe:N2}");
                        table.Cell().Element(DataCellStyle).AlignRight().Text($"{mov.Haber:N2}");

                        static IContainer DataCellStyle(IContainer c) => c
                            .Padding(5)
                            .BorderBottom(0.5f)
                            .BorderColor(Colors.Grey.Lighten2);
                    }
                });
            }
            else
            {
                // Vista resumida
                column.Item().PaddingVertical(10).Text($"Total de movimientos: {comprobante.Movimientos.Count}")
                    .FontSize(11);
            }

            // Totales
            column.Item().PaddingTop(15).Table(table =>
            {
                table.ColumnsDefinition(columns =>
                {
                    columns.RelativeColumn();
                    columns.ConstantColumn(80);
                    columns.ConstantColumn(80);
                });

                // Fila de totales
                table.Cell().Element(TotalCellStyle).AlignRight().Text("TOTALES:").Bold();
                table.Cell().Element(TotalCellStyle).AlignRight()
                    .Text($"{comprobante.TotalDebe:N2}").Bold().FontSize(11);
                table.Cell().Element(TotalCellStyle).AlignRight()
                    .Text($"{comprobante.TotalHaber:N2}").Bold().FontSize(11);

                static IContainer TotalCellStyle(IContainer c) => c
                    .Background(Colors.Grey.Lighten3)
                    .Padding(8)
                    .BorderTop(2)
                    .BorderColor(Colors.Grey.Medium);
            });

            // Diferencia (si existe)
            var diferencia = (comprobante.TotalDebe ?? 0) - (comprobante.TotalHaber ?? 0);
            if (Math.Abs(diferencia) > 0.01)
            {
                column.Item().PaddingTop(5).AlignRight().Text(text =>
                {
                    text.Span("Diferencia: ").Bold();
                    text.Span($"{diferencia:N2}")
                        .FontColor(Colors.Red.Medium)
                        .Bold();
                });

                column.Item().PaddingTop(5).AlignRight()
                    .Text("⚠ ADVERTENCIA: El comprobante NO está cuadrado")
                    .FontSize(9)
                    .FontColor(Colors.Red.Medium)
                    .Bold();
            }
            else
            {
                column.Item().PaddingTop(5).AlignRight()
                    .Text("✓ Comprobante CUADRADO correctamente")
                    .FontSize(9)
                    .FontColor(Colors.Green.Darken2);
            }
        });
    }

    private void ComposeFooter(IContainer container, ComprobanteDto comprobante)
    {
        container.Column(column =>
        {
            column.Item().PaddingTop(20).LineHorizontal(0.5f).LineColor(Colors.Grey.Lighten2);

            column.Item().PaddingTop(10).Row(row =>
            {
                // Información izquierda
                row.RelativeItem().Text(text =>
                {
                    text.Span("Usuario: ").FontSize(8).FontColor(Colors.Grey.Darken1);
                    text.Span($"{comprobante.IdUsuario}").FontSize(8);
                });

                // Información centro
                row.RelativeItem().AlignCenter().Text(text =>
                {
                    text.Span("Fecha Creación: ").FontSize(8).FontColor(Colors.Grey.Darken1);
                    text.Span($"{comprobante.FechaCreacion?.ToString("dd/MM/yyyy HH:mm") ?? "-"}").FontSize(8);
                });

                // Información derecha
                row.RelativeItem().AlignRight().Text(text =>
                {
                    text.Span("Generado: ").FontSize(8).FontColor(Colors.Grey.Darken1);
                    text.Span($"{DateTime.Now:dd/MM/yyyy HH:mm:ss}").FontSize(8);
                });
            });

            // Página
            column.Item().AlignCenter().Text(text =>
            {
                text.CurrentPageNumber().FontSize(8);
                text.Span(" / ").FontSize(8);
                text.TotalPages().FontSize(8);
            });
        });
    }

    public byte[] GenerateChequePdf(ComprobanteDto comprobante, ChequeConfigDto config)
    {
        _logger.LogInformation("Generating cheque PDF for comprobante {IdComp}", comprobante.IdComp);

        {
            var document = Document.Create(container =>
            {
                container.Page(page =>
                {
                    // Tamaño de cheque estándar (8.5" x 3.5")
                    page.Size(new PageSize(8.5f, 3.5f, Unit.Inch));
                    page.Margin(0.5f, Unit.Centimetre);
                    page.PageColor(Colors.White);
                    page.DefaultTextStyle(x => x.FontSize(11).FontFamily("Courier New"));

                    page.Content().Element(c => ComposeCheque(c, comprobante, config));
                });
            });

            return document.GeneratePdf();
        }
    }

    private void ComposeCheque(IContainer container, ComprobanteDto comprobante, ChequeConfigDto config)
    {
        container.Column(column =>
        {
            // Fecha (esquina superior derecha)
            column.Item().AlignRight().PaddingBottom(10).Text($"{comprobante.Fecha:dd/MM/yyyy}");

            // Beneficiario (PÁGUESE A LA ORDEN DE)
            column.Item().PaddingTop(15).Text(text =>
            {
                text.Span("PÁGUESE A LA ORDEN DE: ").Bold();
                text.Span($"{config.Beneficiario}");
            });

            // Monto en números
            column.Item().PaddingTop(10).AlignRight().Text(text =>
            {
                text.Span("$ ").Bold();
                text.Span($"{comprobante.TotalHaber:N2}").Bold().FontSize(14);
            });

            // Monto en letras
            column.Item().PaddingTop(10).Text(text =>
            {
                text.Span("SON: ").Bold();
                text.Span($"{NumeroALetras(comprobante.TotalHaber ?? 0)}");
            });

            // Glosa/Concepto
            column.Item().PaddingTop(15).Text(text =>
            {
                text.Span("CONCEPTO: ");
                text.Span($"{comprobante.Glosa}");
            });

            // Firma (línea)
            column.Item().PaddingTop(30).PaddingHorizontal(100).Column(sigColumn =>
            {
                sigColumn.Item().LineHorizontal(1).LineColor(Colors.Black);
                sigColumn.Item().AlignCenter().PaddingTop(5).Text("FIRMA AUTORIZADA")
                    .FontSize(9);
            });
        });
    }

    private string NumeroALetras(double numero)
    {
        // Implementación simplificada de conversión de número a letras
        // En producción, usar una librería especializada
        
        if (numero == 0) return "CERO PESOS";

        var parteEntera = (long)Math.Floor(numero);
        var parteDecimal = (int)Math.Round((numero - parteEntera) * 100);

        var letras = ConvertirEnteroALetras(parteEntera);
        
        if (parteDecimal > 0)
        {
            return $"{letras} PESOS CON {parteDecimal:00}/100";
        }
        else
        {
            return $"{letras} PESOS";
        }
    }

    private string ConvertirEnteroALetras(long numero)
    {
        // Implementación básica - en producción usar librería completa
        if (numero == 0) return "CERO";
        if (numero == 1) return "UN";
        if (numero < 10) return numero.ToString();
        
        // Para números mayores, simplificar
        return numero.ToString("#,##0", new System.Globalization.CultureInfo("es-CL"));
    }
}

public interface IPdfReportService
{
    byte[] GenerateComprobantePdf(ComprobanteDto comprobante, bool resumido = false);
    byte[] GenerateChequePdf(ComprobanteDto comprobante, ChequeConfigDto config);
}

public class ChequeConfigDto
{
    public string Beneficiario { get; set; } = string.Empty;
    public string NumeroCheque { get; set; } = string.Empty;
    public string Banco { get; set; } = string.Empty;
    public string CuentaCorriente { get; set; } = string.Empty;
}
