# Análisis de Migración: Ayuda Crédito 33 bis (FrmHelpCred33bis.frm)

## 📋 INFORMACIÓN GENERAL

**Formulario VB6:** `FrmHelpCred33bis.frm`  
**Ubicación:** `\old\Contabilidad70\HyperContabilidad\FrmHelpCred33bis.frm`  
**Propósito:** Ventana de ayuda informativa sobre el Crédito por Activo Fijo según Art. 33 bis de la Ley de Renta  
**Tipo:** Diálogo Modal de Información/Ayuda

---

## 🎯 FUNCIONALIDAD PRINCIPAL

Este formulario es una **ventana de ayuda informativa** que muestra las reglas tributarias para calcular el **Crédito por Inversión en Activo Fijo** según el Art. 33 bis de la Ley de Renta chilena.

**Características:**
- Formulario modal de solo lectura
- Una grilla MSFlexGrid con 7 filas de datos tributarios
- Información segmentada por fecha de adquisición, ventas anuales y tasas aplicables
- Datos estáticos basados en legislación tributaria

---

## 🖼️ CONTROLES DEL FORMULARIO VB6

### Controles Principales

| Control | Tipo | Propósito |
|---------|------|-----------|
| `Grid` | MSFlexGrid | Tabla con reglas de crédito 33 bis |

**Características del Grid:**
- 8 filas totales (1 encabezado + 7 filas de datos)
- 4 columnas: Fecha Adquisición, Promedio Ventas, Tasa Crédito, Tope

---

## 📊 ESTRUCTURA DE LA GRILLA

### Columnas

| Índice | Nombre | Ancho | Descripción |
|--------|--------|-------|-------------|
| C_FECHA (0) | Fecha de Adquisición | 3000 | Período de adquisición del activo |
| C_VENTAS (1) | Promedio de Ventas | 3500 | Rango de ventas anuales en UF |
| C_TASA (2) | Tasa de Crédito | 3170 | Porcentaje o fórmula del crédito |
| C_TOPE (3) | Tope | 700 | Restricciones aplicables |

### Contenido de la Grilla (7 escenarios tributarios)

| # | Fecha de Adquisición | Promedio de Ventas | Tasa de Crédito | Tope |
|---|---------------------|-------------------|-----------------|------|
| 1 | Hasta 30/09/2014 | No importa | 4% | - |
| 2 | Desde 01/10/2014 hasta 30/09/2015 | Menor o igual a 25.000 UF | 8% | - |
| 3 | Desde 01/10/2014 hasta 30/09/2015 | Superior a 25.000 y menor o igual a 100.000 UF | 8% * (100.000 - Ventas Anuales) / 75.000 | Mín. 4% |
| 4 | Desde 01/10/2014 hasta 30/09/2015 | Superior a 100.000 UF | 4% | - |
| 5 | A contar del 01/10/2015 | Menor o igual a 25.000 UF | 6% | - |
| 6 | A contar del 01/10/2015 | Superior a 25.000 y menor o igual a 100.000 UF | 6% * (100.000 - Ventas Anuales) / 75.000 | Mín. 4% |
| 7 | A contar del 01/10/2015 | Superior a 100.000 UF | 4% | - |

---

## 🔄 EVENTOS Y FUNCIONES

### 1. **Form_Load**

```vb6
Private Sub Form_Load()
   Call SetUpGrid
   Call FillGrid
End Sub
```

**Lógica:** Inicializa la grilla y la puebla con datos

---

### 2. **SetUpGrid** - Configuración de Grilla

```vb6
Private Sub SetUpGrid()
   Grid.Cols = 4  ' NCOLS + 1
   Grid.rows = 8  ' 1 header + 7 data rows
   
   ' Configurar anchos de columna
   Grid.ColWidth(C_FECHA) = 3000
   Grid.ColWidth(C_VENTAS) = 3500
   Grid.ColWidth(C_TASA) = 3170
   Grid.ColWidth(C_TOPE) = 700
   
   ' Aumentar altura de filas
   For i = 0 To Grid.rows - 1
      Grid.RowHeight(i) = Grid.RowHeight(i) * 2
   Next i
   
   ' Encabezados
   Grid.TextMatrix(0, C_FECHA) = "Fecha de Adquisición"
   Grid.TextMatrix(0, C_VENTAS) = "Promedio de Ventas"
   Grid.TextMatrix(0, C_TASA) = "Tasa de Crédito"
   Grid.TextMatrix(0, C_TOPE) = "Tope"
End Sub
```

**Lógica:**
- Configura 4 columnas y 8 filas
- Establece anchos específicos
- Aumenta altura de filas (x2) para mejor legibilidad
- Define encabezados de columna

---

### 3. **FillGrid** - Carga de Datos

```vb6
Private Sub FillGrid()
   ' 7 escenarios tributarios basados en:
   ' - Fecha de adquisición del activo fijo
   ' - Promedio anual de ventas en UF
   ' - Tasa de crédito aplicable
   ' - Topes mínimos
   
   ' Escenario 1: Hasta 30/09/2014
   Grid.TextMatrix(1, C_FECHA) = "Hasta 30/09/2014"
   Grid.TextMatrix(1, C_VENTAS) = "No importa"
   Grid.TextMatrix(1, C_TASA) = "4%"
   
   ' ... 6 escenarios adicionales (ver tabla arriba)
End Sub
```

**Lógica:**
- Puebla la grilla con datos estáticos
- Información basada en normativa tributaria chilena vigente
- 7 reglas de cálculo diferentes según fecha y ventas

---

## 📝 DATOS ESTÁTICOS

Los datos de este formulario son **completamente estáticos** y basados en la **Ley de Renta chilena, Art. 33 bis** (Crédito por Inversión en Activo Fijo). 

**No se consultan desde base de datos.**

**Contexto tributario:**
- Art. 33 bis establece un crédito contra el Impuesto de Primera Categoría
- El crédito se aplica sobre la inversión en activos fijos
- Las tasas varían según fecha de adquisición y nivel de ventas de la empresa
- Empresas con menores ventas obtienen tasas más favorables

---

## 🎨 MIGRACIÓN A .NET 9 MVC

### Enfoque de Migración

Este es un formulario **puramente informativo** similar a `InformacionAyuda`, que se migra como:

1. **Controller MVC:** Vista simple sin parámetros
2. **Vista Razor:** Tabla HTML con las 7 reglas tributarias
3. **NO requiere:** API Controller, Service, DTOs, base de datos

**Complejidad:** ⭐ Muy Baja (formulario estático de ayuda)

---

### Componentes .NET

**1. AyudaCredito33bisController.cs**

```csharp
public class AyudaCredito33bisController : Controller
{
    private readonly ILogger<AyudaCredito33bisController> _logger;

    public AyudaCredito33bisController(ILogger<AyudaCredito33bisController> logger)
    {
        _logger = logger;
    }

    [HttpGet]
    public IActionResult Index()
    {
        _logger.LogInformation("Accediendo a Ayuda Crédito 33 bis");
        return View();
    }
}
```

**2. Views/Index.cshtml**

```html
@{
    ViewData["Title"] = "Ayuda para Crédito Activo Fijo (Art. 33 Bis)";
    Layout = "~/Features/Shared/_Layout.cshtml";
}

<div class="container">
    <h1>Ayuda para Crédito Activo Fijo (Art. 33 Bis Ley de Renta)</h1>
    
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Fecha de Adquisición</th>
                <th>Promedio de Ventas</th>
                <th>Tasa de Crédito</th>
                <th>Tope</th>
            </tr>
        </thead>
        <tbody>
            <!-- 7 filas con las reglas tributarias -->
            <tr>
                <td>Hasta 30/09/2014</td>
                <td>No importa</td>
                <td>4%</td>
                <td></td>
            </tr>
            <!-- ... más filas -->
        </tbody>
    </table>
    
    <div class="alert alert-info">
        <strong>Nota:</strong> El Art. 33 bis de la Ley de Renta establece un crédito 
        contra el Impuesto de Primera Categoría por inversiones en activos fijos.
    </div>
</div>
```

---

## 📊 ESTRUCTURA DE ARCHIVOS .NET

```
\new\Features\AyudaCredito33bis\
├── Analysis.md (este archivo)
├── AyudaCredito33bisController.cs
└── Views\
    ├── Index.cshtml
    └── _ViewImports.cshtml
```

**NO se requiere:**
- DTOs (datos estáticos)
- Service (sin lógica de negocio)
- API Controller (no hay endpoints REST)
- Base de datos (datos hardcodeados)

---

## 🎯 CONSIDERACIONES ESPECIALES

### Normativa Tributaria

Los datos mostrados corresponden a la normativa vigente al momento de desarrollo del sistema VB6. 

**Importante:**
- Las tasas y fechas son históricas
- El Art. 33 bis puede haber sido modificado en reformas tributarias posteriores
- Se recomienda validar vigencia con SII o actualizar según legislación actual

### Fórmulas de Cálculo

Para empresas con ventas entre 25.000 y 100.000 UF, se aplican fórmulas progresivas:

**Período 2014-2015:**
```
Tasa = 8% × (100.000 - Ventas Anuales) / 75.000
Tope mínimo = 4%
```

**Período 2015 en adelante:**
```
Tasa = 6% × (100.000 - Ventas Anuales) / 75.000
Tope mínimo = 4%
```

### Actualización de Datos

Si se requiere actualizar las reglas tributarias en el futuro:

1. **Opción 1:** Editar directamente el HTML de la vista
2. **Opción 2:** Migrar a tabla de base de datos si se vuelve muy dinámico
3. **Opción 3:** Configurar como parámetros del sistema

---

## ✅ CHECKLIST DE MIGRACIÓN

- [ ] Crear `AyudaCredito33bisController.cs`
- [ ] Crear `Views/Index.cshtml` con tabla de 7 reglas
- [ ] Incluir encabezados de columnas
- [ ] Incluir las 7 filas de datos tributarios
- [ ] Agregar nota explicativa sobre Art. 33 bis
- [ ] Aplicar estilos Tailwind CSS
- [ ] Agregar icono de ayuda
- [ ] Crear `_ViewImports.cshtml`
- [ ] NO crear Service/DTO (no necesarios)
- [ ] Agregar enlace en menú
- [ ] Actualizar `features.md`

---

## 🎨 DISEÑO UI

**Layout:**

```
┌─────────────────────────────────────────────────────────────┐
│ [Icono] Ayuda para Crédito Activo Fijo (Art. 33 Bis)       │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│ El Art. 33 bis de la Ley de Renta establece un crédito     │
│ contra el Impuesto de Primera Categoría por inversiones     │
│ en activos fijos. Las tasas aplicables son:                 │
│                                                              │
│ ┌────────────────────────────────────────────────────────┐ │
│ │ Fecha Adq. │ Promedio Ventas │ Tasa Crédito │ Tope   │ │
│ ├────────────┼─────────────────┼──────────────┼────────┤ │
│ │ Hasta      │ No importa      │ 4%           │        │ │
│ │ 30/09/2014 │                 │              │        │ │
│ ├────────────┼─────────────────┼──────────────┼────────┤ │
│ │ 01/10/2014 │ ≤ 25.000 UF     │ 8%           │        │ │
│ │ 30/09/2015 │                 │              │        │ │
│ ├────────────┼─────────────────┼──────────────┼────────┤ │
│ │ 01/10/2014 │ 25.000-100.000  │ Fórmula      │ Mín.   │ │
│ │ 30/09/2015 │ UF              │ progresiva   │ 4%     │ │
│ │ ...        │ ...             │ ...          │ ...    │ │
│ └────────────────────────────────────────────────────────┘ │
│                                                              │
│ ┌──────────────────────────────────────────────────────┐   │
│ │ ℹ️ Nota: Las tasas varían según fecha de adquisición │   │
│ │   del activo y el nivel de ventas anuales de la      │   │
│ │   empresa. Consulte con su asesor tributario.        │   │
│ └──────────────────────────────────────────────────────┘   │
│                                                              │
│ [Cerrar]                                                    │
└─────────────────────────────────────────────────────────────┘
```

---

## 📝 NOTAS FINALES

- **Formulario muy simple:** Solo muestra información estática
- **Sin lógica de negocio:** Datos hardcodeados
- **Contexto tributario:** Normativa chilena específica (Art. 33 bis)
- **Actualización:** Si cambia la ley, editar la vista HTML
- **Uso típico:** Ayuda para usuarios al calcular créditos de activo fijo

---

**Migración:** Directa y sencilla - solo Controller + Vista Razor con tabla HTML.
