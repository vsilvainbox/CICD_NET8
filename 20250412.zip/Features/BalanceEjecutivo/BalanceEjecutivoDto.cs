using System.ComponentModel.DataAnnotations;

namespace App.Features.BalanceEjecutivo;

public class BalanceEjecutivoFiltrosDto
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }

    [Display(Name = "Fecha Desde")]
    [DataType(DataType.Date)]
    public DateTime FechaDesde { get; set; }

    [Display(Name = "Fecha Hasta")]
    [DataType(DataType.Date)]
    public DateTime FechaHasta { get; set; }

    [Display(Name = "Tipo Ajuste")]
    public int TipoAjuste { get; set; } // 1=Financiero, 2=Tributario, 3=Ambos

    [Display(Name = "Área Negocio")]
    public int? IdAreaNegocio { get; set; }

    [Display(Name = "Centro Costo")]
    public int? IdCentroCosto { get; set; }

    [Display(Name = "Nivel de Cuentas")]
    public int Nivel { get; set; } // 2-5

    [Display(Name = "Libro Oficial")]
    public bool LibroOficial { get; set; }

    [Display(Name = "Solo Saldos Vigentes")]
    public bool SaldosVigentes { get; set; } // true = ocultar cuentas con saldo 0
}

public class CuentaBalanceDto
{
    public int IdCuenta { get; set; }
    public string Codigo { get; set; } = string.Empty;
    public string Descripcion { get; set; } = string.Empty;
    public int Nivel { get; set; }
    public int Clasificacion { get; set; } // 1=Activo, 2=Pasivo, 3=Resultado
    public decimal Debe { get; set; }
    public decimal Haber { get; set; }
    public decimal Saldo { get; set; }
    public bool EsTotal { get; set; }
    public string Formato { get; set; } = string.Empty; // "B" = Bold
    public int Color { get; set; } // Color RGB para el nivel
}

public class BalanceEjecutivoResultadoDto
{
    public List<CuentaBalanceParalelaDto> Filas { get; set; } = new();
    public decimal TotalActivos { get; set; }
    public decimal TotalPasivos { get; set; }
    public decimal ResultadoEjercicio { get; set; }
    public string Titulo { get; set; } = string.Empty;
    public string RangoFechas { get; set; } = string.Empty;
    public string Filtros { get; set; } = string.Empty;
}

public class CuentaBalanceParalelaDto
{
    // Lado Activo (izquierdo)
    public CuentaBalanceDto? Activo { get; set; }

    // Lado Pasivo (derecho)
    public CuentaBalanceDto? Pasivo { get; set; }
}

#region ViewModels

public class BalanceEjecutivoIndexViewModel
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
}

#endregion