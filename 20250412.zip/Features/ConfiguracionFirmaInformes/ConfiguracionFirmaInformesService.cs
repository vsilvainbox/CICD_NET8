using Microsoft.EntityFrameworkCore;
using App.Data;
using App.Exceptions;

namespace App.Features.ConfiguracionFirmaInformes;

public class ConfiguracionFirmaInformesService(
    LpContabContext context,
    ILogger<ConfiguracionFirmaInformesService> logger,
    IWebHostEnvironment environment) : IConfiguracionFirmaInformesService
{
    public async Task<ConfiguracionFirmaInformesDto> GetConfiguracionAsync(int empresaId, short ano)
    {
        logger.LogInformation("Getting firmas configuration for empresa {EmpresaId}, año {Ano}", empresaId, ano);

        var empresa = await context.Empresa
            .Where(e => e.Id == empresaId && e.Ano == ano)
            .Select(e => new { e.Rut, e.RutContador, e.RutRepLegal1, e.RutRepLegal2 })
            .FirstOrDefaultAsync();

        if (empresa == null)
        {
            logger.LogWarning("Empresa {EmpresaId} año {Ano} not found", empresaId, ano);
            throw new BusinessException($"No se encontró la empresa {empresaId} para el año {ano}");
        }

        var firmas = await context.Firmas
            .Where(f => f.IdEmpresa == empresaId && f.ano == ano.ToString())
            .ToListAsync();

        var config = new ConfiguracionFirmaInformesDto
        {
            EmpresaId = empresaId,
            Ano = ano,
            RutEmpresa = empresa.Rut,
            TieneContador = !string.IsNullOrEmpty(empresa.RutContador),
            TieneRepLegal1 = !string.IsNullOrEmpty(empresa.RutRepLegal1) && empresa.RutRepLegal1 != "0",
            TieneRepLegal2 = !string.IsNullOrEmpty(empresa.RutRepLegal2) && empresa.RutRepLegal2 != "0"
        };

        config.FirmaContador = GetFirmaDto(firmas, "Contador", config.TieneContador);
        config.FirmaRepLegal1 = GetFirmaDto(firmas, "RepLegal1", config.TieneRepLegal1);
        config.FirmaRepLegal2 = GetFirmaDto(firmas, "RepLegal2", config.TieneRepLegal2);

        logger.LogInformation("Found {Count} firmas for empresa {EmpresaId}", firmas.Count, empresaId);
        return config;
    }

    private FirmaDto GetFirmaDto(List<App.Data.Firmas> firmas, string tipo, bool habilitado)
    {
        var firma = firmas.FirstOrDefault(f => f.Tipo == tipo);
        
        return new FirmaDto
        {
            Tipo = tipo,
            RutaArchivo = firma?.Patch,
            NombreArchivo = firma != null ? Path.GetFileName(firma.Patch ?? "") : null,
            Existe = firma != null && !string.IsNullOrEmpty(firma.Patch),
            Habilitado = habilitado
        };
    }

    public async Task<object> SaveFirmaAsync(int empresaId, short ano, string? tipo, string? base64Image, string? fileName)
    {
        logger.LogInformation("Saving firma {Tipo} for empresa {EmpresaId}, año {Ano}", tipo, empresaId, ano);

        // Aplicar valor por defecto para fileName si es null
        var fileNameToUse = fileName ?? "firma.jpg";

        {
            var empresa = await context.Empresa
                .Where(e => e.Id == empresaId && e.Ano == ano)
                .Select(e => e.Rut)
                .FirstOrDefaultAsync();

            if (string.IsNullOrEmpty(empresa))
            {
                logger.LogWarning("Empresa {EmpresaId} not found", empresaId);
                throw new BusinessException($"No se encontró la empresa {empresaId}");
            }

            // Crear directorio si no existe
            var firmasDir = Path.Combine(environment.WebRootPath, "firmas");
            if (!Directory.Exists(firmasDir))
            {
                Directory.CreateDirectory(firmasDir);
                logger.LogInformation("Created firmas directory: {Path}", firmasDir);
            }

            // Generar nombre de archivo
            var extension = Path.GetExtension(fileNameToUse)?.ToLower() ?? ".jpg";
            var nombreArchivo = $"{empresa}_fir{tipo}_{ano}{extension}";
            var rutaCompleta = Path.Combine(firmasDir, nombreArchivo);
            var rutaRelativa = $"/firmas/{nombreArchivo}";

            // Guardar imagen desde base64
            var base64Data = base64Image!.Contains(",") ? base64Image.Split(',')[1] : base64Image;
            var imageBytes = Convert.FromBase64String(base64Data);
            await File.WriteAllBytesAsync(rutaCompleta, imageBytes);
            logger.LogInformation("Saved image file: {Path}", rutaCompleta);

            // Guardar/actualizar en BD
            var firmaExistente = await context.Firmas
                .FirstOrDefaultAsync(f =>
                    f.IdEmpresa == empresaId &&
                    f.Tipo == tipo &&
                    f.ano == ano.ToString());

            if (firmaExistente != null)
            {
                // Eliminar archivo anterior si existe y es diferente
                if (!string.IsNullOrEmpty(firmaExistente.Patch) && firmaExistente.Patch != rutaRelativa)
                {
                    var archivoAnterior = Path.Combine(environment.WebRootPath, firmaExistente.Patch.TrimStart('/'));
                    if (File.Exists(archivoAnterior))
                    {
                        File.Delete(archivoAnterior);
                        logger.LogInformation("Deleted old file: {Path}", archivoAnterior);
                    }
                }

                firmaExistente.Patch = rutaRelativa;
                logger.LogInformation("Updated existing firma record");
            }
            else
            {
                var nuevaFirma = new App.Data.Firmas
                {
                    IdEmpresa = empresaId,
                    Tipo = tipo,
                    ano = ano.ToString(),
                    Patch = rutaRelativa
                };
                context.Firmas.Add(nuevaFirma);
                logger.LogInformation("Created new firma record");
            }

            await context.SaveChangesAsync();
            return new { message = "Firma guardada correctamente" };
        }
    }

    public async Task<object> DeleteFirmaAsync(int empresaId, short ano, string tipo)
    {
        logger.LogInformation("Deleting firma {Tipo} for empresa {EmpresaId}, año {Ano}", tipo, empresaId, ano);

        {
            var firma = await context.Firmas
                .FirstOrDefaultAsync(f =>
                    f.IdEmpresa == empresaId &&
                    f.Tipo == tipo &&
                    f.ano == ano.ToString());

            if (firma == null)
            {
                logger.LogWarning("Firma {Tipo} not found for empresa {EmpresaId}", tipo, empresaId);
                throw new BusinessException($"No se encontró la firma {tipo} para la empresa {empresaId}");
            }

            // Eliminar archivo físico
            if (!string.IsNullOrEmpty(firma.Patch))
            {
                var rutaCompleta = Path.Combine(environment.WebRootPath, firma.Patch.TrimStart('/'));
                if (File.Exists(rutaCompleta))
                {
                    File.Delete(rutaCompleta);
                    logger.LogInformation("Deleted file: {Path}", rutaCompleta);
                }
            }

            // Eliminar registro de BD
            context.Firmas.Remove(firma);
            await context.SaveChangesAsync();

            logger.LogInformation("Successfully deleted firma {Tipo}", tipo);
            return new { message = "Firma eliminada correctamente" };
        }
    }
}
