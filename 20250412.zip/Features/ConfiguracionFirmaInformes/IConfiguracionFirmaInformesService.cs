﻿namespace App.Features.ConfiguracionFirmaInformes;

public interface IConfiguracionFirmaInformesService
{
    Task<ConfiguracionFirmaInformesDto> GetConfiguracionAsync(int empresaId, short ano);
    Task<object> SaveFirmaAsync(int empresaId, short ano, string? tipo, string? base64Image, string? fileName);
    Task<object> DeleteFirmaAsync(int empresaId, short ano, string tipo);
}
