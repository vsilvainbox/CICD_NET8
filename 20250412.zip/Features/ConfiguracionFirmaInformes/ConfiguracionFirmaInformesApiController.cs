using Microsoft.AspNetCore.Mvc;

namespace App.Features.ConfiguracionFirmaInformes;

[ApiController]
[Route("[controller]/[action]")]
public class ConfiguracionFirmaInformesApiController(
    IConfiguracionFirmaInformesService service,
    ILogger<ConfiguracionFirmaInformesApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<ConfiguracionFirmaInformesDto>> GetConfiguracion([FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: GetConfiguracion called for empresa {EmpresaId}, año {Ano}", empresaId, ano);

        var config = await service.GetConfiguracionAsync(empresaId, ano);
        return Ok(config);
    }

    [HttpPost]
    public async Task<ActionResult> UploadFirma([FromBody] UploadFirmaDto dto)
    {
        logger.LogInformation("API: UploadFirma called for empresa {EmpresaId}, tipo {Tipo}", dto.EmpresaId, dto.Tipo);

        var result = await service.SaveFirmaAsync(
            dto.EmpresaId,
            dto.Ano,
            dto.Tipo,
            dto.Base64Image,
            dto.FileName);

        return Ok(result);
    }

    [HttpDelete]
    public async Task<ActionResult> DeleteFirma([FromQuery] int empresaId, [FromQuery] short ano, [FromQuery] string tipo)
    {
        logger.LogInformation("API: DeleteFirma called for empresa {EmpresaId}, tipo {Tipo}", empresaId, tipo);

        var result = await service.DeleteFirmaAsync(empresaId, ano, tipo);
        return Ok(result);
    }
}
