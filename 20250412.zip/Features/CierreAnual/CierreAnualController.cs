using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Extensions;
using App.Helpers;
using App.Exceptions;

namespace App.Features.CierreAnual;

/// <summary>
/// MVC Controller para cierre anual (cierre de ejercicio)
/// Migrado desde VB6 FrmCierreAnual.frm
/// </summary>
public class CierreAnualController(
    ILogger<CierreAnualController> logger,
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator) : Controller
{
    /// <summary>
    /// Vista principal del cierre anual
    /// Muestra el año a cerrar y permite ejecutar el proceso
    /// </summary>
    public IActionResult Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder al Cierre Anual";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        var empresaId = SessionHelper.EmpresaId;
        int ano = SessionHelper.Ano;
        logger.LogInformation("Loading CierreAnual Index view for empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        return View();
    }

    /// <summary>
    /// M�todo proxy: Obtener estado del cierre anual
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetStatus(int empresaId, short ano)
    {
        logger.LogInformation("Proxy: GetStatus for empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<CierreAnualApiController>(
                HttpContext,
                nameof(CierreAnualApiController.GetStatus),
                new { empresaId, ano });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// M�todo proxy: Obtener vista previa del cierre anual
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetPreview(int empresaId, short ano)
    {
        logger.LogInformation("Proxy: GetPreview for empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<CierreAnualApiController>(
                HttpContext,
                nameof(CierreAnualApiController.GetPreview),
                new { empresaId, ano });
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// M�todo proxy: Ejecutar cierre anual
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> ExecuteClose([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: ExecuteClose");

        {
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<CierreAnualApiController>(
                HttpContext,
                nameof(CierreAnualApiController.Execute));
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }
}