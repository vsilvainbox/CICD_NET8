using App.Data;
using App.Exceptions;
using App.Helpers;
using Microsoft.EntityFrameworkCore;
using App.Features.AbrirCerrarMes;
using App.Features.SeguimientoCierreApertura;

namespace App.Features.CierreAnual;

/// <summary>
/// Servicio para cierre anual (cierre de ejercicio)
/// Migrado desde VB6 FrmCierreAnual.frm
/// </summary>
public class CierreAnualService(
    LpContabContext context,
    ILogger<CierreAnualService> logger,
    IAbrirCerrarMesService abrirCerrarMesService,
    ISeguimientoCierreAperturaService seguimientoService) : ICierreAnualService
{
    // Estados de mes (constants from VB6)
    private const int EM_CERRADO = 0;
    private const int EM_ABIERTO = 1;

    // Tipos de libros (from VB6 constants)
    private const int LIB_COMPRAS = 1;
    private const int LIB_VENTAS = 2;

    // Tipos de valor libro (from VB6 constants)
    private const int LIBCOMPRAS_IVAIRREC = 15;
    private const int LIBCOMPRAS_IVAIRREC1 = 1015;
    private const int LIBCOMPRAS_IVAIRREC2 = 2015;
    private const int LIBCOMPRAS_IVAIRREC3 = 3015;
    private const int LIBCOMPRAS_IVAIRREC4 = 4015;
    private const int LIBCOMPRAS_IVAIRREC9 = 9015;
    private const int LIBCOMPRAS_IMPESPDIESEL = 46;
    private const int LIBCOMPRAS_IMPESPDIESELTRANS = 47;

    // Tipos de IVA Retenido (from VB6 constants)
    private const int IVARET_PARCIAL = 1;
    private const int IVARET_TOTAL = 2;

    /// <summary>
    /// Obtiene el estado del cierre anual
    /// Mapea a: Form_Load() en VB6
    /// </summary>
    public async Task<CierreAnualStatusDto> GetCloseStatusAsync(int empresaId, short ano)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");
        if (ano <= 0)
            throw new BusinessException("Debe seleccionar un año");

        logger.LogInformation("Getting close status for empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        var empresa = await context.Empresas
            .FirstOrDefaultAsync(e => e.IdEmpresa == empresaId);

        var empresaAno = await context.EmpresasAno
            .FirstOrDefaultAsync(ea => ea.idEmpresa == empresaId && ea.Ano == ano);

        var isClosed = empresaAno?.FCierre != null && empresaAno.FCierre > 0;
        var fechaCierre = isClosed ? ParseDateFromInt(empresaAno!.FCierre!.Value) : null;

        // TODO: [PERMISSION_CHECK] Verificar privilegio PRV_ADM_EMPRESA
        var canClose = !isClosed; // Simplified: can close if not already closed

        var warningMessage = string.Empty;
        if (isClosed)
        {
            warningMessage = $"El año {ano} ya fue cerrado el {fechaCierre:dd/MM/yyyy}. No se pueden modificar datos.";
        }

        return new CierreAnualStatusDto
        {
            EmpresaId = empresaId,
            Ano = ano,
            NombreEmpresa = empresa?.NombreCorto ?? "N/A",
            IsClosed = isClosed,
            FechaCierre = fechaCierre,
            CanClose = canClose,
            WarningMessage = warningMessage
        };
    }

    /// <summary>
    /// Valida si los libros anuales han sido impresos
    /// Mapea a: LibAnualesImpresos(True) en VB6
    /// </summary>
    public async Task<ValidationResult> ValidateAnnualBooksPrintedAsync(int empresaId, short ano)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");
        if (ano <= 0)
            throw new BusinessException("Debe seleccionar un año");

        logger.LogInformation("Validating annual books printed for empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        // Check if any libro has been marked as printed (Impreso = 1) in EstadoMes
        var printedMonths = await context.EstadoMes
            .Where(e => e.IdEmpresa == empresaId && e.Ano == ano && e.Impreso == 1)
            .CountAsync();

        if (printedMonths > 0)
        {
            logger.LogInformation("{Count} months have printed books marked", printedMonths);
            return new ValidationResult
            {
                Message = $"{printedMonths} meses tienen libros marcados como impresos."
            };
        }

        // If no printed books found, return warning but allow to continue
        // User must manually confirm in the UI (via checkboxes)
        logger.LogWarning("No printed books found - user must confirm manually");
        return new ValidationResult
        {
            Message = "ADVERTENCIA: No se encontraron registros de libros impresos. Asegúrese de haber impreso los libros requeridos antes del cierre."
        };
    }

    /// <summary>
    /// Ejecuta el proceso completo de cierre anual
    /// Mapea a: Bt_CerrarAno_Click() en VB6
    /// </summary>
    public async Task<CierreAnualResultDto> ExecuteAnnualCloseAsync(int empresaId, short ano, IProgress<CierreAnualProgressDto>? progress = null)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");
        if (ano <= 0)
            throw new BusinessException("Debe seleccionar un año");

        // Verificar si ya está cerrado
        var status = await GetCloseStatusAsync(empresaId, ano);
        if (status.IsClosed)
            throw new BusinessException($"El año {ano} ya fue cerrado el {status.FechaCierre:dd/MM/yyyy}");

        logger.LogInformation("Starting annual close for empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        var result = new CierreAnualResultDto
        {
            FechaCierre = DateTime.Now
        };

        // Progress: 0%
        progress?.Report(new CierreAnualProgressDto
        {
            Percentage = 0,
            CurrentStep = "Iniciando cierre anual..."
        });

        // STEP 1: Validate books printed
        progress?.Report(new CierreAnualProgressDto { Percentage = 10, CurrentStep = "Validando libros impresos..." });
        var booksValidation = await ValidateAnnualBooksPrintedAsync(empresaId, ano);
        result.ProcessDetails.Add($"Libros: {booksValidation.Message}");

        // STEP 2: Get last correlativos
        progress?.Report(new CierreAnualProgressDto { Percentage = 20, CurrentStep = "Obteniendo últimos correlativos..." });
        var lastCorrelativos = await GetLastCorrelativosAsync(empresaId, ano);
        result.LastCorrelativos = lastCorrelativos;
        result.ProcessDetails.Add($"Correlativos almacenados: {lastCorrelativos.NumLastCompUnico ?? 0}");

        // STEP 3: Close all open months
        progress?.Report(new CierreAnualProgressDto { Percentage = 35, CurrentStep = "Cerrando meses abiertos..." });
        var closeMonthsCount = await CloseAllOpenMonthsAsync(empresaId, ano);
        result.MonthsClosed = closeMonthsCount;
        result.ProcessDetails.Add($"Meses cerrados: {result.MonthsClosed}");

        // STEP 4: Calculate IVA remainder
        progress?.Report(new CierreAnualProgressDto { Percentage = 50, CurrentStep = "Calculando remanente IVA..." });
        var remIVAUTM = await CalculateIvaRemainderAsync(empresaId, ano);
        result.RemIVAUTM = remIVAUTM;
        result.ProcessDetails.Add($"Remanente IVA UTM: {remIVAUTM:N2}");

        // STEP 5: Calculate Libro Caja balance
        progress?.Report(new CierreAnualProgressDto { Percentage = 65, CurrentStep = "Calculando saldo Libro Caja..." });
        var saldoLibroCaja = await CalculateFinalLibroCajaBalanceAsync(empresaId, ano);
        result.SaldoLibroCaja = saldoLibroCaja;
        result.ProcessDetails.Add($"Saldo Libro Caja: {saldoLibroCaja:N2}");

        // STEP 6: Update EmpresasAno table
        progress?.Report(new CierreAnualProgressDto { Percentage = 80, CurrentStep = "Actualizando registro de cierre..." });
        await UpdateEmpresasAnoCloseAsync(empresaId, ano, lastCorrelativos, remIVAUTM, saldoLibroCaja);
        result.ProcessDetails.Add("Registro de cierre actualizado");

        // STEP 7: Transfer SII configurations
        progress?.Report(new CierreAnualProgressDto { Percentage = 90, CurrentStep = "Traspasando configuraciones SII..." });
        var siiConfigsTransferred = await TransferSiiConfigurationsAsync(empresaId, ano);
        result.ProcessDetails.Add($"Configuraciones SII traspasadas: {siiConfigsTransferred}");

        // STEP 8: Audit log
        progress?.Report(new CierreAnualProgressDto { Percentage = 95, CurrentStep = "Registrando auditoría..." });
        // Register audit: SeguimientoCierreApertura(2, "Cierre Anual") from VB6
        await seguimientoService.RegisterAuditAsync(
            empresaId,
            ano,
            SessionHelper.UsuarioId,
            2, // TIPO_CIERRE = 2
            "Cierre Anual");
        logger.LogInformation("Annual close completed for empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        // Progress: 100%
        progress?.Report(new CierreAnualProgressDto
        {
            Percentage = 100,
            CurrentStep = "Cierre anual completado",
            IsCompleted = true
        });

        return result;
    }

    /// <summary>
    /// Obtiene los últimos correlativos de comprobantes
    /// Mapea a: STEP 3 en Bt_CerrarAno_Click()
    /// </summary>
    public async Task<LastCorrelativosDto> GetLastCorrelativosAsync(int empresaId, short ano)
    {
        logger.LogInformation("Getting last correlativos for empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        {
            // TODO: [CONFIGURATION] Check gPerCorrComp and gTipoCorrComp configuration
            // For now, get both unique and by-type correlativos

            var result = new LastCorrelativosDto();

            // Get max correlativo único
            var maxCorrUnico = await context.Comprobante
                .Where(c => c.IdEmpresa == empresaId && c.Ano == ano)
                .MaxAsync(c => c.Correlativo);

            result.NumLastCompUnico = maxCorrUnico;

            // Get max correlativo by type
            var corrByType = await context.Comprobante
                .Where(c => c.IdEmpresa == empresaId && c.Ano == ano)
                .GroupBy(c => c.Tipo)
                .Select(g => new
                {
                    Tipo = g.Key,
                    MaxCorr = g.Max(c => c.Correlativo)
                })
                .ToListAsync();

            foreach (var item in corrByType)
            {
                switch (item.Tipo)
                {
                    case 1: // Ingreso
                        result.NumLastCompI = item.MaxCorr;
                        break;
                    case 2: // Egreso
                        result.NumLastCompE = item.MaxCorr;
                        break;
                    case 3: // Traspaso
                        result.NumLastCompT = item.MaxCorr;
                        break;
                    case 4: // Apertura
                        result.NumLastCompA = item.MaxCorr;
                        break;
                }
            }

            logger.LogInformation("Last correlativos: Unico={Unico}, I={I}, E={E}, T={T}, A={A}",
                result.NumLastCompUnico ?? 0, result.NumLastCompI ?? 0, result.NumLastCompE ?? 0, result.NumLastCompT ?? 0, result.NumLastCompA ?? 0);

            return result;
        }
    }

    /// <summary>
    /// Calcula el remanente de IVA crédito en UTM
    /// Mapea a: STEP 5 en Bt_CerrarAno_Click() - CÁLCULO MUY COMPLEJO
    /// </summary>
    public async Task<double?> CalculateIvaRemainderAsync(int empresaId, short ano)
    {
        logger.LogInformation("Calculating IVA remainder for empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        {
            double remIVAUTM = 0;
            double vTotalRemMesAnt = 0;
            var remMesAnt = false;
            double totRemMesAnt = 0;

            // Loop through all months (1-12)
            for (var mes = 1; mes <= 12; mes++)
            {
                logger.LogDebug("Processing month {Mes} for IVA calculation", mes);

                // Reset previous month remainder for month 1 or if no remainder
                if (mes == 1 || !remMesAnt)
                {
                    totRemMesAnt = 0;
                }

                if (vTotalRemMesAnt > 0)
                {
                    vTotalRemMesAnt = 0;
                }

                // Get IVA summary for month
                var ivaSummary = await GetResIVAAsync(empresaId, ano, mes);

                // Get other taxes (IVA Irrecuperable, IVA Retenido)
                var otherTaxes = await GetOtherTaxesForMonthAsync(empresaId, ano, mes);

                // Get UTM value for next month (VB6: DateSerial(ano, mes + 1, 1))
                var fechaUtm = new DateTime(ano, Math.Min(mes + 1, 12), 1);
                var valUTM = await GetUTMValueAsync(fechaUtm);

                if (valUTM.HasValue && valUTM.Value > 0)
                {
                    totRemMesAnt = 0; // Will be calculated if needed
                }

                // Adjust IVA totals
                var totIVACred = ivaSummary.TotalCredito - otherTaxes.IVAIrrecuperable;
                var totIVADeb = ivaSummary.TotalDebito - otherTaxes.IVARetenidoParcial - otherTaxes.IVARetenidoTotal;

                // Get monthly IVA adjustment
                var ajusteIvaMen = await GetAjusteIVAMensualAsync(empresaId, ano, mes);

                // Calculate net IVA for month
                // VB6: vTotalRemMesAnt = TotIVADeb - (TotIVACred + TotIEPDGen + TotIEPDTransp + TotRemMesAnt + vFmt(AjusteIvaMen))
                vTotalRemMesAnt = totIVADeb - (totIVACred + ivaSummary.TotalIEPDGen + ivaSummary.TotalIEPDTransp + totRemMesAnt + ajusteIvaMen);

                logger.LogDebug("Month {Mes}: IVADeb={Deb}, IVACred={Cred}, IEPD={IEPD}, Ajuste={Ajuste}, Net={Net}",
                    mes, totIVADeb, totIVACred, ivaSummary.TotalIEPDGen + ivaSummary.TotalIEPDTransp, ajusteIvaMen, vTotalRemMesAnt);

                // Determine if there's a remainder (negative = credit)
                remMesAnt = vTotalRemMesAnt < 0;
            }

            // Convert final remainder to UTM (December value)
            var fechaUtmFinal = new DateTime(ano, 12, 31);
            var valUTMFinal = await GetUTMValueAsync(fechaUtmFinal);

            if (!valUTMFinal.HasValue || valUTMFinal.Value == 0)
            {
                logger.LogWarning("UTM value not found for {Fecha} - cannot calculate IVA remainder", fechaUtmFinal);
                throw new BusinessException($"No se encontró el valor de la UTM para la fecha {fechaUtmFinal:dd/MM/yyyy}. No se puede calcular el remanente de IVA.");
            }

            if (remMesAnt) // If there's a credit remainder
            {
                remIVAUTM = Math.Abs(vTotalRemMesAnt) / valUTMFinal.Value;
                logger.LogInformation("IVA Remainder calculated: {RemIVA} UTM (${Amount} / ${UTM})",
                    remIVAUTM, Math.Abs(vTotalRemMesAnt), valUTMFinal.Value);
            }
            else
            {
                logger.LogInformation("No IVA credit remainder for year {Ano}", ano);
            }

            return Math.Round(remIVAUTM, 2);
        }
    }

    /// <summary>
    /// Calcula el saldo final del Libro de Caja
    /// Mapea a: STEP 6 en Bt_CerrarAno_Click()
    /// </summary>
    public async Task<double?> CalculateFinalLibroCajaBalanceAsync(int empresaId, short ano)
    {
        logger.LogInformation("Calculating final Libro Caja balance for empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        {
            // VB6: SELECT Sum(Ingreso) as Ingresos, Sum(Egreso) as Egresos FROM LibroCaja
            var summary = await context.LibroCaja
                .Where(lc => lc.IdEmpresa == empresaId && lc.Ano == ano)
                .GroupBy(lc => 1)
                .Select(g => new
                {
                    TotalIngresos = g.Sum(lc => lc.Ingreso),
                    TotalEgresos = g.Sum(lc => lc.Egreso)
                })
                .FirstOrDefaultAsync();

            var saldoFinal = summary != null ? (summary.TotalIngresos ?? 0) - (summary.TotalEgresos ?? 0) : (double?)null;

            logger.LogInformation("Libro Caja balance: Ingresos={Ingresos}, Egresos={Egresos}, Saldo={Saldo}",
                summary?.TotalIngresos ?? 0, summary?.TotalEgresos ?? 0, saldoFinal ?? 0);

            return saldoFinal;
        }
    }

    /// <summary>
    /// Cierra todos los meses abiertos del año
    /// Mapea a: STEP 4 en Bt_CerrarAno_Click()
    /// </summary>
    public async Task<int> CloseAllOpenMonthsAsync(int empresaId, short ano)
    {
        logger.LogInformation("Closing all open months for empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        {
            // Get all open months using AbrirCerrarMes service
            var monthStates = await abrirCerrarMesService.GetMonthStatesAsync(empresaId, ano);
            var openMonths = monthStates.Where(m => m.Estado == EM_ABIERTO).ToList();

            logger.LogInformation("Found {Count} open months to close", openMonths.Count);

            var monthsClosed = 0;

            // Close each open month using the dedicated service
            foreach (var monthState in openMonths)
            {
                try
                {
                    await abrirCerrarMesService.CloseMonthAsync(empresaId, ano, monthState.Mes);
                    monthsClosed++;
                    logger.LogInformation("Successfully closed month {Mes}", monthState.Mes);
                }
                catch (BusinessException ex)
                {
                    // El mes ya estaba cerrado, continuar con el siguiente
                    logger.LogWarning("Failed to close month {Mes}: {Message}", monthState.Mes, ex.Message);
                }
            }

            logger.LogInformation("Closed {Count} months successfully for empresaId: {EmpresaId}, año: {Ano}",
                monthsClosed, empresaId, ano);

            return monthsClosed;
        }
    }

    /// <summary>
    /// Obtiene vista previa del cierre sin ejecutarlo
    /// </summary>
    public async Task<CierreAnualPreviewDto> GetClosePreviewAsync(int empresaId, short ano)
    {
        if (empresaId <= 0)
            throw new BusinessException("Debe seleccionar una empresa");
        if (ano <= 0)
            throw new BusinessException("Debe seleccionar un año");

        logger.LogInformation("Getting close preview for empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        var preview = new CierreAnualPreviewDto
        {
            Ano = ano
        };

        // Get open months
        var openMonths = await context.EstadoMes
            .Where(e => e.IdEmpresa == empresaId && e.Ano == ano && e.Estado == EM_ABIERTO && e.Mes.HasValue)
            .Select(e => e.Mes.Value)
            .ToListAsync();

        preview.MesesACerrar = openMonths;

        // Get last correlativos (preview)
        preview.UltimosCorrelativos = await GetLastCorrelativosAsync(empresaId, ano);

        // Get estimated IVA remainder
        preview.RemIVAUTMEstimado = await CalculateIvaRemainderAsync(empresaId, ano);

        // Get estimated Libro Caja balance
        preview.SaldoLibroCajaEstimado = await CalculateFinalLibroCajaBalanceAsync(empresaId, ano);

        // Add warnings
        if (openMonths.Count == 0)
        {
            preview.Advertencias.Add("No hay meses abiertos para cerrar.");
        }

        preview.Advertencias.Add("ADVERTENCIA: El cierre anual es IRREVERSIBLE. No podrá modificar datos después del cierre.");

        return preview;
    }

    /// <summary>
    /// Traspasa configuraciones SII de diciembre a enero del próximo año
    /// Mapea a: STEP 8 en Bt_CerrarAno_Click()
    /// </summary>
    public async Task<int> TransferSiiConfigurationsAsync(int empresaId, short ano)
    {
        logger.LogInformation("Transferring SII configurations for empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        {
            // Note: ConfiguraSincronizacionSII uses string dates, not DateTime
            // VB6: WHERE MONTH(Fecha_Sincroniza)=12 AND YEAR(Fecha_Sincroniza)=YEAR(GETDATE())

            // Get December configurations
            var decemberConfigs = await context.ConfiguraSincronizacionSII
                .Where(c => c.IdEmpresa == empresaId &&
                           c.Fecha_Sincroniza != null &&
                           c.Fecha_Sincroniza.Value.Year == ano &&
                           c.Fecha_Sincroniza.Value.Month == 12)
                .ToListAsync();

            var configsTransferred = 0;

            foreach (var config in decemberConfigs)
            {
                if (config.Fecha_Sincroniza.HasValue)
                {
                    var newConfig = new App.Data.ConfiguraSincronizacionSII
                    {
                        IdEmpresa = config.IdEmpresa,
                        Tipo_Libro = config.Tipo_Libro,
                        Contador = config.Contador,
                        Fecha_Sincroniza = config.Fecha_Sincroniza.Value.AddMonths(1),
                        Fecha_Ejecucion = config.Fecha_Ejecucion,
                        Fecha_Creacion = DateTime.Now,
                        IdUsuario = config.IdUsuario
                    };

                    context.ConfiguraSincronizacionSII.Add(newConfig);
                    configsTransferred++;
                }
            }

            await context.SaveChangesAsync();

            logger.LogInformation("Transferred {Count} SII configurations for empresaId: {EmpresaId}", configsTransferred, empresaId);

            return configsTransferred;
        }
    }

    /// <summary>
    /// Actualiza el registro EmpresasAno con los datos del cierre
    /// Mapea a: STEP 7 en Bt_CerrarAno_Click()
    /// </summary>
    private async Task UpdateEmpresasAnoCloseAsync(int empresaId, short ano, LastCorrelativosDto correlativos, double? remIVAUTM, double? saldoLibroCaja)
    {
        logger.LogInformation("Updating EmpresasAno close record for empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        var empresaAno = await context.EmpresasAno
            .FirstOrDefaultAsync(ea => ea.idEmpresa == empresaId && ea.Ano == ano);

        if (empresaAno == null)
        {
            logger.LogWarning("EmpresasAno record not found for empresaId: {EmpresaId}, año: {Ano} - creating new", empresaId, ano);
            empresaAno = new App.Data.EmpresasAno
            {
                idEmpresa = empresaId,
                Ano = ano
            };
            context.EmpresasAno.Add(empresaAno);
        }

        // Update close date
        empresaAno.FCierre = GetDateAsInt(DateTime.Now);

        // Update correlativos
        empresaAno.NumLastCompUnico = correlativos.NumLastCompUnico;
        empresaAno.NumLastCompI = correlativos.NumLastCompI;
        empresaAno.NumLastCompE = correlativos.NumLastCompE;
        empresaAno.NumLastCompT = correlativos.NumLastCompT;
        empresaAno.NumLastCompA = correlativos.NumLastCompA;

        // Update IVA remainder and Libro Caja balance
        empresaAno.RemIVAUTM = remIVAUTM;
        empresaAno.SaldoLibroCaja = saldoLibroCaja;

        context.EmpresasAno.Update(empresaAno);
        await context.SaveChangesAsync();

        logger.LogInformation("EmpresasAno updated with close date: {FCierre}", empresaAno.FCierre);
    }

    /// <summary>
    /// Convierte DateTime a int en formato OLE/Excel
    /// </summary>
    private int GetDateAsInt(DateTime date)
    {
        return (int)date.ToOADate();
    }

    /// <summary>
    /// Convierte int formato OLE/Excel a DateTime
    /// </summary>
    private DateTime? ParseDateFromInt(int dateInt)
    {
        return DateTime.FromOADate(dateInt);
    }

    #region Private Helper Methods for IVA Calculation

    /// <summary>
    /// Obtiene resumen de IVA para un mes
    /// Mapea a: GetResIVA() en HyperCont.bas
    /// </summary>
    private async Task<IvaSummaryDto> GetResIVAAsync(int empresaId, short ano, int mes)
    {
        var summary = new IvaSummaryDto();

        {
            // Calculate IVA Crédito and IVA Débito
            // VB6 Query: SELECT TipoLib, EsRebaja, Sum(IVA) FROM Documento WHERE TipoLib IN (1,2) GROUP BY TipoLib, EsRebaja
            var ivaData = await (from d in context.Documento
                                join t in context.TipoDocs on new { TipoLib = (short?)d.TipoLib, TipoDoc = (short?)d.TipoDoc } equals new { TipoLib = t.TipoLib, TipoDoc = t.TipoDoc }
                                where d.IdEmpresa == empresaId &&
                                      d.Ano == ano &&
                                      (d.TipoLib == LIB_COMPRAS || d.TipoLib == LIB_VENTAS) &&
                                      d.FEmision.HasValue &&
                                      DateTime.FromOADate(d.FEmision.Value).Month == mes
                                group new { d, t } by new { d.TipoLib, t.EsRebaja } into g
                                select new
                                {
                                    TipoLib = g.Key.TipoLib,
                                    EsRebaja = g.Key.EsRebaja,
                                    SumIVA = g.Sum(x => x.d.IVA ?? 0)
                                }).ToListAsync();

            foreach (var item in ivaData)
            {
                if (item.TipoLib == LIB_COMPRAS)
                {
                    if (item.EsRebaja == true)
                        summary.TotalCredito -= item.SumIVA;
                    else
                        summary.TotalCredito += item.SumIVA;
                }
                else // LIB_VENTAS
                {
                    if (item.EsRebaja == true)
                        summary.TotalDebito -= item.SumIVA;
                    else
                        summary.TotalDebito += item.SumIVA;
                }
            }

            // Calculate IEPD (Impuesto Específico Petróleo Diesel)
            var iepdData = await (from m in context.MovDocumento
                                 join d in context.Documento on new { IdDoc = m.IdDoc, IdEmpresa = m.IdEmpresa, Ano = m.Ano }
                                                              equals new { IdDoc = (int?)d.IdDoc, d.IdEmpresa, d.Ano }
                                 join t in context.TipoDocs on new { TipoLib = (short?)d.TipoLib, TipoDoc = (short?)d.TipoDoc } equals new { TipoLib = t.TipoLib, TipoDoc = t.TipoDoc }
                                 where d.IdEmpresa == empresaId &&
                                       d.Ano == ano &&
                                       d.TipoLib == LIB_COMPRAS &&
                                       (m.IdTipoValLib == LIBCOMPRAS_IMPESPDIESEL || m.IdTipoValLib == LIBCOMPRAS_IMPESPDIESELTRANS) &&
                                       m.EsRecuperable == true &&
                                       d.FEmision.HasValue &&
                                       DateTime.FromOADate(d.FEmision.Value).Month == mes
                                 group new { m, t } by new { t.EsRebaja, m.IdTipoValLib } into g
                                 select new
                                 {
                                     EsRebaja = g.Key.EsRebaja,
                                     IdTipoValLib = g.Key.IdTipoValLib,
                                     SumMov = g.Sum(x => (x.m.Debe ?? 0) - (x.m.Haber ?? 0))
                                 }).ToListAsync();

            foreach (var item in iepdData)
            {
                var absMov = Math.Abs(item.SumMov);

                if (item.IdTipoValLib == LIBCOMPRAS_IMPESPDIESEL)
                {
                    if (item.EsRebaja == true)
                        summary.TotalIEPDGen -= absMov;
                    else
                        summary.TotalIEPDGen += absMov;
                }
                else if (item.IdTipoValLib == LIBCOMPRAS_IMPESPDIESELTRANS)
                {
                    if (item.EsRebaja == true)
                        summary.TotalIEPDTransp -= absMov;
                    else
                        summary.TotalIEPDTransp += absMov;
                }
            }

            logger.LogDebug("IVA Summary for month {Mes}: Crédito={Cred}, Débito={Deb}, IEPDGen={Gen}, IEPDTransp={Transp}",
                mes, summary.TotalCredito, summary.TotalDebito, summary.TotalIEPDGen, summary.TotalIEPDTransp);
        }

        return summary;
    }

    /// <summary>
    /// Obtiene otros impuestos para un mes (IVA Irrecuperable, IVA Retenido)
    /// Mapea a: GenResOImp() en ImpExpF29.bas
    /// </summary>
    private async Task<OtherTaxesDto> GetOtherTaxesForMonthAsync(int empresaId, short ano, int mes)
    {
        var taxes = new OtherTaxesDto();

        {
            // Query for IVA Irrecuperable and IVA Retenido
            var taxData = await (from m in context.MovDocumento
                                join d in context.Documento on new { IdDoc = m.IdDoc, IdEmpresa = m.IdEmpresa, Ano = m.Ano }
                                                             equals new { IdDoc = (int?)d.IdDoc, d.IdEmpresa, d.Ano }
                                join tv in context.TipoValor on new { TipoLib = d.TipoLib, Codigo = m.IdTipoValLib } equals new { TipoLib = tv.TipoLib, Codigo = (short?)tv.Codigo } into tvJoin
                                from tv in tvJoin.DefaultIfEmpty()
                                where d.IdEmpresa == empresaId &&
                                      d.Ano == ano &&
                                      d.FEmision.HasValue &&
                                      DateTime.FromOADate(d.FEmision.Value).Month == mes
                                group new { d, m, tv } by new { d.TipoLib, m.IdTipoValLib, TipoIVARetenido = tv != null ? tv.TipoIVARetenido : null } into g
                                select new
                                {
                                    TipoLib = g.Key.TipoLib,
                                    IdTipoValLib = g.Key.IdTipoValLib,
                                    TipoIVARetenido = g.Key.TipoIVARetenido,
                                    Valor = g.Sum(x => (x.m.Debe ?? 0) - (x.m.Haber ?? 0))
                                }).ToListAsync();

            foreach (var item in taxData)
            {
                // IVA Irrecuperable (LIB_COMPRAS)
                if (item.TipoLib == LIB_COMPRAS &&
                    (item.IdTipoValLib == LIBCOMPRAS_IVAIRREC ||
                     item.IdTipoValLib == LIBCOMPRAS_IVAIRREC1 ||
                     item.IdTipoValLib == LIBCOMPRAS_IVAIRREC2 ||
                     item.IdTipoValLib == LIBCOMPRAS_IVAIRREC3 ||
                     item.IdTipoValLib == LIBCOMPRAS_IVAIRREC4 ||
                     item.IdTipoValLib == LIBCOMPRAS_IVAIRREC9))
                {
                    taxes.IVAIrrecuperable += Math.Abs(item.Valor);
                }

                // IVA Retenido Parcial (LIB_VENTAS)
                if (item.TipoLib == LIB_VENTAS && item.TipoIVARetenido == IVARET_PARCIAL)
                {
                    taxes.IVARetenidoParcial += Math.Abs(item.Valor);
                }

                // IVA Retenido Total (LIB_VENTAS)
                if (item.TipoLib == LIB_VENTAS && item.TipoIVARetenido == IVARET_TOTAL)
                {
                    taxes.IVARetenidoTotal += Math.Abs(item.Valor);
                }
            }

            logger.LogDebug("Other taxes for month {Mes}: IVAIrrec={Irrec}, IVARetParc={RetParc}, IVARetTot={RetTot}",
                mes, taxes.IVAIrrecuperable, taxes.IVARetenidoParcial, taxes.IVARetenidoTotal);
        }

        return taxes;
    }

    /// <summary>
    /// Obtiene el ajuste mensual de IVA desde tabla AjusteIVAMensual
    /// Mapea a: GetAjusteIVAMensual() en HyperCont.bas
    /// </summary>
    private async Task<double> GetAjusteIVAMensualAsync(int empresaId, short ano, int mes)
    {
        {
            if (mes <= 0) return 0;

            var ajuste = await context.AjusteIVAMensual
                .Where(a => a.IdEmpresa == empresaId && a.Ano == ano && a.Mes == mes)
                .Select(a => a.Valor)
                .FirstOrDefaultAsync();

            logger.LogDebug("Monthly IVA adjustment for month {Mes}: {Valor}", mes, ajuste ?? 0);

            return ajuste ?? 0;
        }
    }

    /// <summary>
    /// Obtiene el valor de la UTM para una fecha específica
    /// Mapea a: GetValMoneda("UTM", ...) en VB6
    /// </summary>
    private async Task<double?> GetUTMValueAsync(DateTime fecha)
    {
        {
            // Look for UTM value in Equivalencia table
            // First, get UTM currency id from Monedas
            var utmMoneda = await context.Monedas
                .Where(m => m.Descrip != null && m.Descrip.Contains("UTM"))
                .Select(m => m.idMoneda)
                .FirstOrDefaultAsync();

            if (utmMoneda == 0)
            {
                logger.LogWarning("UTM currency not found in Monedas table");
                throw new BusinessException("No se encontró la moneda UTM en el sistema. Verifique la configuración de monedas.");
            }

            var fechaInt = GetDateAsInt(fecha);

            // Try to find exact date or closest previous date in Equivalencia
            var utm = await context.Equivalencia
                .Where(e => e.idMoneda == utmMoneda && e.Fecha <= fechaInt)
                .OrderByDescending(e => e.Fecha)
                .Select(e => e.Valor)
                .FirstOrDefaultAsync();

            if (!utm.HasValue || utm.Value == 0)
            {
                logger.LogWarning("UTM value not found for date {Fecha}", fecha);
                throw new BusinessException($"No se encontró el valor de la UTM para la fecha {fecha:dd/MM/yyyy}.");
            }

            logger.LogDebug("UTM value for {Fecha}: ${Valor}", fecha, utm);
            return utm;
        }
    }

    #endregion

    #region Helper DTOs for IVA Calculation

    private class IvaSummaryDto
    {
        public double TotalCredito { get; set; }
        public double TotalDebito { get; set; }
        public double TotalIEPDGen { get; set; }
        public double TotalIEPDTransp { get; set; }
    }

    private class OtherTaxesDto
    {
        public double IVAIrrecuperable { get; set; }
        public double IVARetenidoParcial { get; set; }
        public double IVARetenidoTotal { get; set; }
    }

    #endregion
}
