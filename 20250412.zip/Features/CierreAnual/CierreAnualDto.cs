namespace App.Features.CierreAnual;

/// <summary>
/// DTO para el estado del cierre anual
/// </summary>
public class CierreAnualStatusDto
{
    /// <summary>
    /// ID de la empresa
    /// </summary>
    public int EmpresaId { get; set; }

    /// <summary>
    /// año a cerrar
    /// </summary>
    public short Ano { get; set; }

    /// <summary>
    /// Nombre de la empresa
    /// </summary>
    public string NombreEmpresa { get; set; } = string.Empty;

    /// <summary>
    /// Indica si el año ya est� cerrado
    /// </summary>
    public bool IsClosed { get; set; }

    /// <summary>
    /// Fecha de cierre (si ya est� cerrado)
    /// </summary>
    public DateTime? FechaCierre { get; set; }

    /// <summary>
    /// Indica si se puede cerrar (permisos y estado)
    /// </summary>
    public bool CanClose { get; set; }

    /// <summary>
    /// Mensaje de advertencia si no se puede cerrar
    /// </summary>
    public string WarningMessage { get; set; } = string.Empty;
}

/// <summary>
/// DTO para el resultado del cierre anual
/// </summary>
public class CierreAnualResultDto
{
    /// <summary>
    /// Fecha del cierre
    /// </summary>
    public DateTime FechaCierre { get; set; }

    /// <summary>
    /// Remanente de IVA cr�dito en UTM para pr�ximo año
    /// </summary>
    public double? RemIVAUTM { get; set; }

    /// <summary>
    /// Saldo final del Libro de Caja
    /// </summary>
    public double? SaldoLibroCaja { get; set; }

    /// <summary>
    /// N�mero de meses cerrados
    /// </summary>
    public int MonthsClosed { get; set; }

    /// <summary>
    /// �ltimos correlativos almacenados
    /// </summary>
    public LastCorrelativosDto LastCorrelativos { get; set; } = new LastCorrelativosDto();

    /// <summary>
    /// Detalles adicionales del proceso
    /// </summary>
    public List<string> ProcessDetails { get; set; } = new List<string>();
}

/// <summary>
/// DTO para los �ltimos correlativos de comprobantes
/// </summary>
public class LastCorrelativosDto
{
    /// <summary>
    /// �ltimo correlativo �nico (si aplica)
    /// </summary>
    public int? NumLastCompUnico { get; set; }

    /// <summary>
    /// �ltimo correlativo tipo Ingreso
    /// </summary>
    public int? NumLastCompI { get; set; }

    /// <summary>
    /// �ltimo correlativo tipo Egreso
    /// </summary>
    public int? NumLastCompE { get; set; }

    /// <summary>
    /// �ltimo correlativo tipo Traspaso
    /// </summary>
    public int? NumLastCompT { get; set; }

    /// <summary>
    /// �ltimo correlativo tipo Apertura
    /// </summary>
    public int? NumLastCompA { get; set; }
}

/// <summary>
/// DTO de solicitud para ejecutar cierre anual
/// </summary>
public class CierreAnualRequestDto
{
    /// <summary>
    /// ID de la empresa
    /// </summary>
    public int EmpresaId { get; set; }

    /// <summary>
    /// año a cerrar
    /// </summary>
    public short Ano { get; set; }

    /// <summary>
    /// Confirmación de que se revisaron los libros impresos
    /// </summary>
    public bool ConfirmarLibrosImpresos { get; set; }

    /// <summary>
    /// Confirmación de que entiende que el proceso es irreversible
    /// </summary>
    public bool ConfirmarIrreversible { get; set; }
}

/// <summary>
/// DTO para vista previa del cierre (sin ejecutar)
/// </summary>
public class CierreAnualPreviewDto
{
    /// <summary>
    /// año a cerrar
    /// </summary>
    public short Ano { get; set; }

    /// <summary>
    /// Meses que se cerrar�n (actualmente abiertos)
    /// </summary>
    public List<short> MesesACerrar { get; set; } = new List<short>();

    /// <summary>
    /// �ltimos correlativos que se almacenar�n
    /// </summary>
    public LastCorrelativosDto UltimosCorrelativos { get; set; } = new LastCorrelativosDto();

    /// <summary>
    /// Remanente de IVA UTM calculado (estimado)
    /// </summary>
    public double? RemIVAUTMEstimado { get; set; }

    /// <summary>
    /// Saldo final Libro Caja calculado
    /// </summary>
    public double? SaldoLibroCajaEstimado { get; set; }

    /// <summary>
    /// Advertencias o mensajes informativos
    /// </summary>
    public List<string> Advertencias { get; set; } = new List<string>();
}

/// <summary>
/// DTO de resultado de validación
/// </summary>
public class ValidationResult
{
    /// <summary>
    /// Mensaje de validación
    /// </summary>
    public string Message { get; set; } = string.Empty;

    /// <summary>
    /// Detalles adicionales de validación
    /// </summary>
    public List<string> Details { get; set; } = new List<string>();
}

/// <summary>
/// DTO para progreso del cierre anual
/// </summary>
public class CierreAnualProgressDto
{
    /// <summary>
    /// Porcentaje de progreso (0-100)
    /// </summary>
    public int Percentage { get; set; }

    /// <summary>
    /// Mensaje del paso actual
    /// </summary>
    public string CurrentStep { get; set; } = string.Empty;

    /// <summary>
    /// Indica si el proceso termin�
    /// </summary>
    public bool IsCompleted { get; set; }
}
