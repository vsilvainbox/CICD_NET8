﻿namespace App.Features.CapitalPropioSimplificado;

public interface ICapitalPropioSimplificadoService
{
    Task<CapitalPropioSimplificadoDto> ObtenerCPSAsync(int empresaId, short ano, TipoInformeCPS tipoInforme);
    Task<GuardarCPSResultado> GuardarCPSAsync(CapitalPropioSimplificadoDto datos);
    Task<decimal> CalcularTotalCPSAsync(CapitalPropioSimplificadoDto datos);
}

public class GuardarCPSResultado
{
    public string Message { get; set; } = string.Empty;
}