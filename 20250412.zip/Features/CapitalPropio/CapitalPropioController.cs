using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.CapitalPropio;

[Authorize]

public class CapitalPropioController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<CapitalPropioController> logger) : Controller
{
    public IActionResult Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Capital Propio";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        // Obtener empresaId y ano desde la sesión
        var empresaId = SessionHelper.EmpresaId;
        var ano = SessionHelper.Ano;

        logger.LogInformation("Loading Capital Propio for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        var viewModel = new CapitalPropioIndexViewModel
        {
            EmpresaId = empresaId,
            Ano = (short)ano
        };

        return View(viewModel);
    }

    // Método proxy para Calculate
    [HttpGet]
    public async Task<IActionResult> Calculate(int empresaId, short ano)
    {
        logger.LogInformation("MVC Proxy: Calculate Capital Propio for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<CapitalPropioApiController>(
            HttpContext,
            nameof(CapitalPropioApiController.Calculate),
            new { empresaId, ano });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    // Método proxy para Save
    [HttpPost]
    public async Task<IActionResult> Save([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: Save Capital Propio");

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<CapitalPropioApiController>(
            HttpContext,
            nameof(CapitalPropioApiController.Save));
        var (statusCode, content) = await client.ProxyRequestAsync(
            url!,
            request!,
            HttpMethod.Post);
        return StatusCode(statusCode, content);
    }
}
