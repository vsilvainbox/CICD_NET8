using Microsoft.AspNetCore.Mvc;

namespace App.Features.CapitalPropio;

[ApiController]
[Route("[controller]/[action]")]
public class CapitalPropioApiController(ICapitalPropioService service, ILogger<CapitalPropioApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<CapitalPropioResultDto>> Calculate([FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: Calculate Capital Propio for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var result = await service.CalculateCapitalPropioAsync(empresaId, ano);
            return Ok(result);
        }
    }

    [HttpPost]
    public async Task<ActionResult> Save([FromBody] SaveCapitalPropioRequest request)
    {
        logger.LogInformation("API: Save Capital Propio: {Total}", request.Total);

        {
            await service.SaveCapitalPropioAsync(request.EmpresaId, request.Ano, request.Total);
            return Ok(new { message = "Capital Propio guardado exitosamente" });
        }
    }

    [HttpGet]
    public async Task<ActionResult<decimal>> GetCapitalEfectivo([FromQuery] int empresaId, [FromQuery] short ano)
    {
        {
            var result = await service.GetCapitalEfectivoAsync(empresaId, ano);
            return Ok(result);
        }
    }
}

public class SaveCapitalPropioRequest
{
    public int EmpresaId { get; set; }
    public short Ano { get; set; }
    public decimal Total { get; set; }
}