using Microsoft.EntityFrameworkCore;
using App.Data;
using App.Models.Auth;

namespace App.Features.Auth.Services;

public class PasswordService(
    LpContabContext context,
    ILogger<PasswordService> logger) : IPasswordService
{
    public Task<PasswordValidationResult> ValidatePasswordAsync(
        Usuarios usuario,
        string password)
    {
        var result = new PasswordValidationResult();

        // 1. Prioridad: Validar con bcrypt si existe PasswordHash
        if (!string.IsNullOrEmpty(usuario.PasswordHash))
        {
            logger.LogDebug("Validating with bcrypt for user {Usuario}", usuario.Usuario);
            {
                result.IsValid = BCrypt.Net.BCrypt.Verify(password, usuario.PasswordHash);
                result.UsedModernHash = true;
                result.RequiresMigration = false;

                if (result.IsValid)
                {
                    logger.LogInformation("Login successful (bcrypt) for user {Usuario}", usuario.Usuario);
                }
            }

            return Task.FromResult(result);
        }

        // 2. Fallback: Validar con GenClave simulado (VB6 legacy)
        if (usuario.Clave.HasValue)
        {
            logger.LogInformation("Validating with VB6 GenClave for user {Usuario}, Clave={Clave}", 
                usuario.Usuario, usuario.Clave.Value);
            
            // Primero intentar validar con GenClave (password original)
            var claveGenerada = SimularGenClave(usuario.Usuario ?? "", password);
            logger.LogInformation("Generated clave: {Generated}, Expected: {Expected}", 
                claveGenerada, usuario.Clave.Value);
            
            result.IsValid = claveGenerada == usuario.Clave.Value;
            
            // Fallback adicional: Si el usuario ingresa directamente el número de Clave
            if (!result.IsValid && int.TryParse(password, out var passwordAsNumber))
            {
                result.IsValid = passwordAsNumber == usuario.Clave.Value;
                if (result.IsValid)
                {
                    logger.LogInformation(
                        "User {Usuario} authenticated with direct Clave number",
                        usuario.Usuario);
                }
            }
            
            result.UsedModernHash = false;
            result.RequiresMigration = result.IsValid; // Si es válida, migrar

            if (result.IsValid)
            {
                logger.LogWarning(
                    "Login successful with LEGACY password for user {Usuario}. Migration will occur.",
                    usuario.Usuario);
            }
            else
            {
                logger.LogWarning(
                    "Login failed for user {Usuario}. Generated: {Generated}, Expected: {Expected}",
                    usuario.Usuario, claveGenerada, usuario.Clave.Value);
            }

            return Task.FromResult(result);
        }

        // 3. Sin password configurada
        logger.LogError("User {Usuario} has no password configured", usuario.Usuario);
        result.IsValid = false;
        result.ErrorMessage = "Usuario sin contraseña configurada";
        return Task.FromResult(result);
    }

    public string HashPassword(string password)
    {
        // Usar work factor 11 (balance seguridad/performance)
        return BCrypt.Net.BCrypt.HashPassword(password, workFactor: 11);
    }

    public bool VerifyPassword(string password, string hash)
    {
        {
            return BCrypt.Net.BCrypt.Verify(password, hash);
        }
    }

    public int SimularGenClave(string username, string password)
    {
        // Implementación exacta de GenClave VB6 de Pam.bas
        // GenClave(LCase(Usuario & Password), AppSeed = 0)
        var buf = (username + password).ToLower();
        long appSeed = 0;
        
        var ln = buf.Length;
        var l = 134537 + appSeed;
        
        for (var i = 1; i <= ln; i++)
        {
            var c = buf[i - 1]; // VB6 es 1-based, C# es 0-based
            long ascii = c;
            l = l + ((ascii * (i + 111)) % 9765);
        }
        
        long m = 87731 + 131 * ln + 7;
        var clave = l % m;
        
        logger.LogInformation("GenClave({usuario}, ***) = {clave} [buf length: {length}]", 
            username, clave, ln);
        
        return (int)clave;
    }

    public async Task<bool> MigrarPasswordAsync(int idUsuario, string password)
    {
        {
            var usuario = await context.Usuarios
                .FirstOrDefaultAsync(u => u.IdUsuario == idUsuario);

            if (usuario == null)
                return false;

            // Generar hash bcrypt
            var newHash = HashPassword(password);

            // Actualizar BD
            usuario.PasswordHash = newHash;
            usuario.RequiereCambioPassword = false; // Ya no requiere cambio

            await context.SaveChangesAsync();

            logger.LogInformation(
                "Password migrated to bcrypt for user {Usuario} (ID: {Id})",
                usuario.Usuario, idUsuario);

            return true;
        }
    }
}
