using App.Data;
using App.Models.Auth;

namespace App.Features.Auth.Services;

/// <summary>
/// Servicio de encriptación y validación de contraseñas
/// Implementa sistema híbrido: VB6 GenClave (legacy) + bcrypt (moderno)
/// </summary>
public interface IPasswordService
{
    /// <summary>
    /// Valida password contra usuario (híbrido: VB6 o bcrypt)
    /// </summary>
    Task<PasswordValidationResult> ValidatePasswordAsync(Usuarios usuario, string password);

    /// <summary>
    /// Genera hash bcrypt moderna
    /// </summary>
    string HashPassword(string password);

    /// <summary>
    /// Verifica password contra hash bcrypt
    /// </summary>
    bool VerifyPassword(string password, string hash);

    /// <summary>
    /// Simula GenClave VB6 (para compatibilidad temporal)
    /// </summary>
    int SimularGenClave(string username, string password);

    /// <summary>
    /// Migra password de VB6 a bcrypt
    /// </summary>
    Task<bool> MigrarPasswordAsync(int idUsuario, string password);
}
