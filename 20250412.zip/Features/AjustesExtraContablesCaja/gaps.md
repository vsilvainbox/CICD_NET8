# 📊 Reporte de Gaps: AjustesExtraContablesCaja
## Comparación VB6 → .NET 9

**Fecha de análisis:** 28 de noviembre de 2025
**Feature:** Ajuste Extra Libro de Caja
**VB6 Source:** `D:\vb6\Contabilidad70\HyperContabilidad\FrmAjustesExtraLibCaja.frm`
**NET Source:** `D:\deploy\Features\AjustesExtraContablesCaja\`
**Estado general:** **68.6%** PARIDAD (59/86 aspectos OK)

---

## 📋 Resumen Ejecutivo

| Categoría | Total Aspectos | ✅ OK | ⚠️ Parcial | ❌ Gap | % Paridad |
|-----------|:--------------:|:-----:|:----------:|:------:|:---------:|
| **AUDITORÍA ESTRUCTURAL** | **71** | **50** | **8** | **13** | **70.4%** |
| 1. Inputs / Dependencias | 6 | 5 | 0 | 1 | 83.3% |
| 2. Datos y Persistencia | 10 | 7 | 1 | 2 | 80.0% |
| 3. Acciones y Operaciones | 6 | 3 | 0 | 3 | 50.0% |
| 4. Validaciones | 6 | 1 | 0 | 5 | 16.7% |
| 5. Cálculos y Lógica | 5 | 1 | 2 | 2 | 60.0% |
| 6. Interfaz y UX | 5 | 3 | 1 | 1 | 80.0% |
| 7. Seguridad | 2 | 2 | 0 | 0 | 100.0% |
| 8. Manejo de Errores | 2 | 1 | 1 | 0 | 100.0% |
| 9. Outputs / Salidas | 6 | 2 | 1 | 3 | 50.0% |
| 10. Paridad de Controles UI | 6 | 5 | 0 | 1 | 83.3% |
| 11. Grids y Columnas | 2 | 2 | 0 | 0 | 100.0% |
| 12. Eventos e Interacción | 5 | 4 | 1 | 0 | 100.0% |
| 13. Estados y Modos | 3 | 3 | 0 | 0 | 100.0% |
| 14. Inicialización y Carga | 3 | 2 | 1 | 0 | 100.0% |
| 15. Filtros y Búsqueda | 2 | 2 | 0 | 0 | 100.0% |
| 16. Reportes e Impresión | 2 | 1 | 0 | 1 | 50.0% |
| **AUDITORÍA FUNCIONAL** | **15** | **9** | **2** | **4** | **60.0%** |
| 17. Reglas de Negocio | 4 | 2 | 1 | 1 | 75.0% |
| 18. Flujos de Trabajo | 3 | 2 | 0 | 1 | 66.7% |
| 19. Integraciones | 3 | 2 | 1 | 0 | 100.0% |
| 20. Mensajes al Usuario | 2 | 1 | 0 | 1 | 50.0% |
| 21. Casos Borde | 3 | 2 | 0 | 1 | 66.7% |
| **TOTAL** | **86** | **59** | **10** | **17** | **68.6%** |

---

## AUDITORÍA ESTRUCTURAL (71 aspectos)

---

## 1️⃣ INPUTS / DEPENDENCIAS DE ENTRADA (6 aspectos)

### ✅ Aspecto 1: Variables globales
- **VB6:** `gEmpresa`, `gUsuario`, `gAño` (líneas 517, 580, etc.)
- **NET:** `SessionHelper.EmpresaId`, `SessionHelper.Ano` (Controller línea 16, 23)
- **Estado:** ✅ **OK** - Migrado a Session/Claims correctamente

### ✅ Aspecto 2: Parámetros de entrada
- **VB6:** `FEdit()` método público (línea 288)
- **NET:** Acción `Index()` sin parámetros (Controller línea 14)
- **Estado:** ✅ **OK** - No requiere parámetros de entrada adicionales

### ✅ Aspecto 3: Configuraciones
- **VB6:** Constantes `NEGNUMFMT`, `ORIENT_VER`, `COLOR_GRISLT` (hardcoded)
- **NET:** Configuración en JS inline (formatNumber, estilos CSS)
- **Estado:** ✅ **OK** - Configuración migrada, aunque inline en vez de archivo config

### ✅ Aspecto 4: Estado previo requerido
- **VB6:** No hay validaciones previas específicas
- **NET:** Valida `SessionHelper.EmpresaId > 0` (Controller línea 16)
- **Estado:** ✅ **OK** - Mejora sobre VB6 con validación explícita

### ✅ Aspecto 5: Datos maestros necesarios
- **VB6:**
  - Tabla `AjustesExtLibCaja` (línea 578)
  - Tabla `LibroCaja` (línea 514)
  - Tabla `EmpresasAno` para UTM
  - Tabla `IPC` para ajustes
- **NET:**
  - Acceso a `context.LibroCaja` (Service línea 42)
  - Acceso a `context.EmpresasAno` (Service línea 48)
  - Acceso a `context.IPC` (Service línea 127)
  - ❌ **FALTA** acceso a tabla `AjustesExtLibCaja` (no se lee en GetAjustesAsync)
- **Estado:** ⚠️ **GAP MEDIO** - Falta lectura de valores guardados desde BD

### ❌ Aspecto 6: Conexión/Sesión
- **VB6:** `DbMain` global (línea 522, 539, 582)
- **NET:** `LpContabContext` inyectado (Service línea 8)
- **Estado:** ✅ **OK** - DbContext correctamente inyectado

---

## 2️⃣ DATOS Y PERSISTENCIA (10 aspectos)

### ✅ Aspecto 7: Queries SELECT
**VB6:**
```vb
Q1 = "SELECT Sum(Pagado) as TotIngreso FROM LibroCaja..." (línea 514)
Q1 = "SELECT Sum(SaldoDoc) as Saldo FROM Documento..." (línea 599)
Q1 = "SELECT IdAjustesExtLibCaja, Valor FROM AjustesExtLibCaja..." (línea 578)
```
**NET:**
```csharp
var libroCaja = await context.LibroCaja.Where(...).ToListAsync() (Service línea 42)
```
- **Estado:** ⚠️ **PARCIAL** - Solo implementa query básica de LibroCaja, faltan queries complejas:
  - ❌ Query de saldos por entidades relacionadas (línea 599-613 VB6)
  - ❌ Query ingresos no percibidos a 12 meses desde emisión (línea 622-643 VB6)
  - ❌ Query ingresos no percibidos a 12 meses desde exigibilidad (línea 652-674 VB6)

### ✅ Aspecto 8: Queries INSERT
**VB6:**
```vb
Q1 = "INSERT INTO AjustesExtLibCaja (IdAjustesExtLibCaja, TipoAjuste, IdItemAjuste, Valor, IdEmpresa, Ano)
      VALUES(MaxId, TipoAjuste, IdItemAjuste, Valor, gEmpresa.id, gEmpresa.Ano)" (línea 783-784)
```
**NET:**
```csharp
// TODO: [LEGACY] [MEDIUM] Implementar guardado de ajustes (Service línea 21)
return Task.FromResult(true); // NO IMPLEMENTADO
```
- **Estado:** ❌ **GAP CRÍTICO** - El guardado no está implementado

### ❌ Aspecto 9: Queries UPDATE
**VB6:**
```vb
Q1 = "UPDATE AjustesExtLibCaja SET Valor = valor WHERE IdAjustesExtLibCaja = id" (línea 769)
```
**NET:**
```csharp
// TODO: No implementado
```
- **Estado:** ❌ **GAP CRÍTICO** - El update no está implementado

### ✅ Aspecto 10: Queries DELETE
- **VB6:** No hay operación DELETE en este formulario
- **NET:** N/A
- **Estado:** ✅ **N/A** - No aplica

### ✅ Aspecto 11: Stored Procedures
- **VB6:** No usa stored procedures
- **NET:** N/A
- **Estado:** ✅ **N/A** - No aplica

### ✅ Aspecto 12: Tablas accedidas
**VB6:**
- `LibroCaja` (líneas 514, 531)
- `AjustesExtLibCaja` (línea 578, 769, 783)
- `Documento` (línea 600)
- `Entidades` (línea 600)
- `DocCuotas` (línea 654)
- `IPC` (implícito en `GetValUTM()`)
- `EmpresasAno` (implícito)

**NET:**
- `LibroCaja` ✅ (Service línea 42)
- `EmpresasAno` ✅ (Service línea 48)
- `DocCuotas` ✅ (Service línea 105)
- `IPC` ✅ (Service línea 127)
- ❌ **FALTA** `AjustesExtLibCaja` - No se lee al cargar
- ❌ **FALTA** `Documento` - No se consulta
- ❌ **FALTA** `Entidades` - No se consulta

- **Estado:** ⚠️ **PARCIAL** - 4 de 7 tablas accedidas (57%)

### ✅ Aspecto 13: Campos leídos
**VB6 - LibroCaja:**
- `FechaIngresoLibro`, `Pagado`, `TipoOper`, `TipoLib`, `TipoDoc`, `IdEmpresa`, `Ano`

**NET - LibroCaja:**
- `IdDoc`, `TipoLib`, `TipoDoc`, `NumDoc`, `FechaOperacion`, `RutEntidad`, `NombreEntidad`, `Total`, `IdEmpresa`, `Ano`, `ConEntRel`

- **Estado:** ✅ **OK** - Campos principales migrados

### ✅ Aspecto 14: Campos escritos
**VB6:**
- `IdAjustesExtLibCaja`, `TipoAjuste`, `IdItemAjuste`, `Valor`, `IdEmpresa`, `Ano`

**NET:**
- ❌ **NO IMPLEMENTADO** - No escribe en BD

- **Estado:** ❌ **GAP CRÍTICO** - No escribe datos

### ❌ Aspecto 15: Transacciones
- **VB6:** No usa transacciones explícitas
- **NET:** No implementado
- **Estado:** ✅ **OK** - No requiere transacciones complejas

### ✅ Aspecto 16: Concurrencia
- **VB6:** No maneja concurrencia
- **NET:** No implementado
- **Estado:** ✅ **OK** - No crítico para este formulario

---

## 3️⃣ ACCIONES Y OPERACIONES (6 aspectos)

### ✅ Aspecto 17: Botones/Acciones
**VB6:**
- `Bt_OK_Click()` - Guardar (línea 279)
- `Bt_Cancelar_Click()` - Cancelar (línea 247)
- `Bt_Print_Click()` - Imprimir (línea 812)
- `Bt_Preview_Click()` - Vista previa (línea 869)
- `Bt_CopyExcel_Click()` - Copiar a Excel (línea 955)
- `Bt_DetDoc_Click()` - Detalle documento (línea 252)
- `Bt_Sum_Click()` - Sumar (línea 988)
- `Bt_Calc_Click()` - Calculadora (línea 1009)
- `Bt_ConvMoneda_Click()` - Conversor moneda (línea 999)
- `Bt_Calendar_Click()` - Calendario (línea 1012)

**NET:**
- ✅ `guardarAjustes()` - Aceptar (View línea 218)
- ❌ **FALTA** Cancelar - No hay botón explícito
- ⚠️ `window.print()` - Imprimir (View línea 39) - Usa funcionalidad del navegador
- ❌ **FALTA** Vista previa - No hay botón
- ✅ `exportarExcel()` - Excel (View línea 258)
- ❌ **FALTA** Detalle documento - No implementado
- ❌ **FALTA** Sumar - No implementado
- ❌ **FALTA** Calculadora - No implementado
- ❌ **FALTA** Conversor moneda - No implementado
- ❌ **FALTA** Calendario - No implementado

- **Estado:** ⚠️ **GAP MEDIO** - Solo 3 de 10 acciones implementadas (30%)

### ✅ Aspecto 18: Operaciones CRUD
- **VB6:** Read (cargar), Update (guardar valores editados)
- **NET:** Read parcial (no lee valores guardados), Update NO implementado
- **Estado:** ❌ **GAP CRÍTICO** - CRUD incompleto

### ❌ Aspecto 19: Operaciones especiales
- **VB6:**
  - Abrir formularios modales: `FrmLibCaja.FView()` (línea 261), `FrmRepActivoFijo.FView()` (línea 270)
  - Sumatoria de movimientos seleccionados (línea 988)
- **NET:** No implementado
- **Estado:** ❌ **GAP MEDIO** - Funcionalidades auxiliares faltantes

### ✅ Aspecto 20: Búsquedas
- **VB6:** No hay funcionalidad de búsqueda
- **NET:** N/A
- **Estado:** ✅ **N/A** - No aplica

### ✅ Aspecto 21: Ordenamiento
- **VB6:** No hay ordenamiento explícito (carga en orden de estructura fija)
- **NET:** `.OrderBy(lc => lc.FechaOperacion)` (Service línea 44)
- **Estado:** ✅ **OK** - Ordenamiento por fecha implementado

### ✅ Aspecto 22: Paginación
- **VB6:** No hay paginación (formulario de un solo uso)
- **NET:** N/A
- **Estado:** ✅ **N/A** - No aplica

---

## 4️⃣ VALIDACIONES (6 aspectos)

### ❌ Aspecto 23: Campos requeridos
- **VB6:** Validación en `valida()` (línea 795) - Función vacía, siempre retorna True
- **NET:** No hay validaciones
- **Estado:** ✅ **OK** - No requiere validaciones de campos requeridos

### ❌ Aspecto 24: Validación de rangos
- **VB6:**
  - Gastos presuntos: Min 1 UTM, Max 15 UTM (líneas 722-730)
  - Porcentaje 0.5% (línea 717)
- **NET:** NO implementado
- **Estado:** ❌ **GAP CRÍTICO** - Regla de negocio no migrada (gastos presuntos)

### ❌ Aspecto 25: Validación de formato
- **VB6:** `KeyNumPos()` en grid (línea 985) - Solo números positivos
- **NET:** `soloNumeros()` en inputs (View línea 279) - Solo números
- **Estado:** ⚠️ **PARCIAL** - Permite negativos en .NET, VB6 solo positivos

### ❌ Aspecto 26: Validación de longitud
- **VB6:** No hay validaciones de longitud
- **NET:** No hay validaciones
- **Estado:** ✅ **N/A** - No aplica

### ❌ Aspecto 27: Validaciones custom
- **VB6:**
  - Cálculo automático gastos presuntos con límites UTM (líneas 714-733)
  - Validación 12 meses emisión/exigibilidad (líneas 628-633, 660-664)
- **NET:**
  - ❌ **NO IMPLEMENTADO** - Cálculo gastos presuntos
  - ⚠️ **PARCIAL** - Código para DateDiff presente pero no usado (Service línea 129-131)
- **Estado:** ❌ **GAP CRÍTICO** - Validaciones de negocio faltantes

### ❌ Aspecto 28: Manejo de nulos
- **VB6:** `vFld()` función para manejar nulls (líneas 525, 542, 585, etc.)
- **NET:** Uso de `??` y `?.` operators (Service línea 65-73)
- **Estado:** ✅ **OK** - Manejo de nulls adecuado

---

## 5️⃣ CÁLCULOS Y LÓGICA (5 aspectos)

### ❌ Aspecto 29: Funciones de cálculo
**VB6:**
- `CalcTot()` - Calcula totales de saldos, agregados, deducciones, base imponible (línea 699)
- `CalcSaldosIngEgr()` - Calcula saldos de ingresos y egresos (línea 506)
- `GetVal33Bis()` - Crédito art 33 Bis (línea 403)
- `GetIngNoPercibRel()` - Ingresos no percibidos relacionadas (línea 593)
- `GetIngNoPercib12MesesEmiNoRel()` - Ingresos >12 meses emisión (línea 616)
- `GetIngNoPercib12MesesExigNoRel()` - Ingresos >12 meses exigibilidad (línea 646)
- `GetIngEgrDevengados()` - Ingresos/egresos devengados (línea 678)
- `LoadValCuentasAjustes()` - Carga valor de cuentas asociadas (línea 397, 465)

**NET:**
```javascript
// En View línea 210-212 - Solo recalcula totales básicos
ajustesData.totalAgregados = ajustesData.agregados.reduce((sum, a) => sum + a.valor, 0);
ajustesData.totalDeducciones = ajustesData.deducciones.reduce((sum, d) => sum + d.valor, 0);
ajustesData.baseImponible = ajustesData.saldoFinalCaja + ajustesData.totalAgregados - ajustesData.totalDeducciones;
```
- ❌ **NO IMPLEMENTADAS** las 8 funciones de cálculo complejas
- ✅ Solo suma básica implementada en frontend

- **Estado:** ❌ **GAP CRÍTICO** - Lógica de negocio compleja no migrada

### ⚠️ Aspecto 30: Redondeos
- **VB6:**
  - `Format(valor, NEGNUMFMT)` (múltiples líneas)
  - `vFmt(Format(15 * lValUTM, NUMFMT))` - Redondeo para límites UTM (línea 722)
- **NET:**
  - `formatNumber()` en JS (View línea 269) - Solo formatting, no redondeo
  - ❌ **FALTA** redondeo para límites UTM
- **Estado:** ⚠️ **PARCIAL** - Formatting OK, falta redondeo de cálculos

### ❌ Aspecto 31: Campos calculados
**VB6:**
- `SaldoFinalCaja = SaldoIngresos - SaldoEgresos` (línea 711)
- `TotalAgregados = Sum(agregados)` (línea 737)
- `TotalDeducciones = Sum(deducciones)` (línea 744)
- `BaseImponible = SaldoFinal + Agregados - Deducciones` (línea 749)
- `GastosPresuntos = Min(Max(SaldoIngresos * 0.005, 1*UTM), 15*UTM)` (líneas 715-733)

**NET:**
- ✅ Implementados en frontend (View línea 210-212)
- ❌ **FALTA** cálculo de GastosPresuntos
- ❌ **FALTA** cálculos en backend

- **Estado:** ⚠️ **PARCIAL** - Cálculos básicos OK, falta GastosPresuntos

### ✅ Aspecto 32: Dependencias campos
- **VB6:**
  - `Grid_AcceptValue()` recalcula totales al cambiar valor (línea 969)
  - `CalcTot()` llamado al editar (línea 969)
- **NET:**
  - `actualizarValor()` recalcula y re-renderiza (View línea 200)
- **Estado:** ✅ **OK** - Recálculo automático implementado

### ⚠️ Aspecto 33: Valores por defecto
- **VB6:**
  - `lOrientacion = ORIENT_VER` (línea 292)
  - Valores cargados desde BD o funciones de cálculo
- **NET:**
  - Valores inicializados en 0 (DTO línea 7-14)
  - ❌ **FALTA** carga de valores desde BD
- **Estado:** ⚠️ **PARCIAL** - Estructura OK, falta carga de BD

---

## 6️⃣ INTERFAZ Y UX (5 aspectos)

### ✅ Aspecto 34: Combos/Listas
- **VB6:** No hay combos en este formulario
- **NET:** N/A
- **Estado:** ✅ **N/A** - No aplica

### ✅ Aspecto 35: Mensajes usuario
**VB6:**
- No hay mensajes `MsgBox` explícitos (formulario de solo visualización/edición)

**NET:**
- `alert('✅ ' + result.message)` (View línea 248)
- `alert('❌ ' + result.message)` (View línea 250)
- `TempData["SwalError"]` con validación empresa (Controller línea 18)

- **Estado:** ✅ **OK** - Mensajes implementados, mejora sobre VB6

### ✅ Aspecto 36: Confirmaciones
- **VB6:** No hay confirmaciones
- **NET:** No implementado
- **Estado:** ✅ **N/A** - No aplica

### ⚠️ Aspecto 37: Habilitaciones UI
**VB6:**
- Celdas editables solo si `TipoIngreso = TIA_INGDIRECTO` (línea 975)
  ```vb
  If Val(Grid.TextMatrix(Row, C_TIPOING)) = TIA_INGDIRECTO And Col = C_VALOR Then
      EdType = FEG_Edit
  Else
      Call Bt_DetDoc_Click  'Abre detalle en vez de editar
  End If
  ```

**NET:**
- Celdas editables si `item.editable = true` (View línea 168)
  ```html
  if (item.editable) {
      <input ...>
  } else {
      texto plano
  }
  ```
- ❌ **FALTA** lógica de abrir detalle al hacer clic en celda no editable

- **Estado:** ⚠️ **PARCIAL** - Habilitación OK, falta acción alternativa

### ✅ Aspecto 38: Formatos display
**VB6:**
- `Format(valor, NEGNUMFMT)` - Números negativos con paréntesis (múltiples líneas)

**NET:**
- `formatNumber(value)` - Números negativos con paréntesis (View línea 269-277)
  ```javascript
  return num < 0 ? `(${formatted})` : formatted;
  ```

- **Estado:** ✅ **OK** - Formato idéntico a VB6

---

## 7️⃣ SEGURIDAD (2 aspectos)

### ✅ Aspecto 39: Permisos requeridos
- **VB6:** No hay validación de permisos explícita
- **NET:** Validación de empresa seleccionada (Controller línea 16)
- **Estado:** ✅ **OK** - Mejora sobre VB6

### ✅ Aspecto 40: Validación acceso
- **VB6:** No implementado
- **NET:** Redirección si no hay empresa (Controller línea 20)
- **Estado:** ✅ **OK** - Mejora sobre VB6

---

## 8️⃣ MANEJO DE ERRORES (2 aspectos)

### ✅ Aspecto 41: Captura errores
- **VB6:** No usa `On Error GoTo` en este formulario
- **NET:**
  - `try/catch` en frontend (View línea 80, 219)
  - Logging en backend (Service múltiples líneas)
- **Estado:** ✅ **OK** - Mejora sobre VB6

### ⚠️ Aspecto 42: Mensajes de error
- **VB6:** No hay manejo de errores explícito
- **NET:**
  - `console.error()` + `alert()` (View línea 90, 253)
  - Mensajes genéricos
- **Estado:** ⚠️ **PARCIAL** - Mejora sobre VB6 pero mensajes genéricos

---

## 9️⃣ OUTPUTS / SALIDAS (6 aspectos)

### ✅ Aspecto 43: Datos de retorno
- **VB6:** Formulario modal, no retorna datos
- **NET:** N/A
- **Estado:** ✅ **N/A** - No aplica

### ✅ Aspecto 44: Exportar Excel
**VB6:**
- `Bt_CopyExcel_Click()` - Copia a clipboard (línea 955)
  ```vb
  Clip = LP_FGr2String(Grid, Me.Caption)
  Clipboard.SetText Clip
  ```

**NET:**
- `exportarExcel()` - Descarga archivo .xls (View línea 258)
  ```javascript
  const blob = new Blob([html], { type: 'application/vnd.ms-excel' });
  ```

- **Estado:** ⚠️ **PARCIAL** - Funcionalidad similar pero implementación diferente

### ❌ Aspecto 45: Exportar PDF
- **VB6:** No implementado
- **NET:** No implementado
- **Estado:** ✅ **N/A** - No aplica

### ❌ Aspecto 46: Exportar CSV/Texto
- **VB6:** No implementado
- **NET:** No implementado
- **Estado:** ✅ **N/A** - No aplica

### ❌ Aspecto 47: Impresión
**VB6:**
- `Bt_Print_Click()` - Impresión completa con configuración (línea 812)
  - Setup de impresora: orientación, papel foliado (línea 819)
  - Títulos personalizados (línea 916)
  - Pie de página con firma (línea 830)
  - Control de folios (línea 843)

**NET:**
- `window.print()` - Impresión básica del navegador (View línea 39)
- ❌ **FALTA** configuración de impresora
- ❌ **FALTA** papel foliado
- ❌ **FALTA** encabezado personalizado
- ❌ **FALTA** pie con firmas
- ❌ **FALTA** control de folios

- **Estado:** ❌ **GAP MEDIO** - Impresión muy básica vs completa en VB6

### ❌ Aspecto 48: Llamadas a otros módulos
**VB6:**
- `Set Frm = New FrmLibCaja; Call Frm.FView(-1)` (línea 260-261)
- `Set Frm = New FrmRepActivoFijo; Call Frm.FView` (línea 269-270)
- `Set Frm = New FrmSumSimple` (línea 991)
- `Set Frm = New FrmConverMoneda` (línea 1003)
- `Set Frm = New FrmCalendar` (línea 1016)
- `Set Frm = New FrmPrtSetup` (línea 818)
- `Set Frm = New FrmPrintPreview` (línea 880)

**NET:**
- ❌ **NO IMPLEMENTADAS** todas las llamadas a módulos auxiliares

- **Estado:** ❌ **GAP MEDIO** - 0 de 7 integraciones implementadas

---

## 🔟 PARIDAD DE CONTROLES UI (6 aspectos)

### ✅ Aspecto 49: TextBoxes
**VB6:**
- No hay TextBoxes de entrada (solo grid editable)

**NET:**
- Inputs dinámicos dentro del grid (View línea 169-177)

- **Estado:** ✅ **OK** - Equivalente funcional

### ✅ Aspecto 50: Labels/Etiquetas
**VB6:**
- No hay labels estáticos (todo en grid)

**NET:**
- Headers y textos en grid (View línea 19, 21)

- **Estado:** ✅ **OK** - Equivalente

### ✅ Aspecto 51: ComboBoxes/Selects
- **VB6:** No hay combos
- **NET:** N/A
- **Estado:** ✅ **N/A** - No aplica

### ✅ Aspecto 52: Grids/Tablas
**VB6:**
- `FlexEdGrid2.FEd2Grid` (línea 16)
- Columnas: ID, TIPOAJUSTE, IDITEM, CONCEPTO, VALOR, SUBTOTAL, TIPOING, FMT, COLOBLIGATORIA, UPD (líneas 220-231)

**NET:**
- `<table id="grid-ajustes">` (View línea 53)
- Columnas: Concepto (60%), Valor (20%), Subtotal (20%) (View línea 137-147)

- **Estado:** ✅ **OK** - Grid equivalente, columnas ocultas no mostradas (correcto)

### ✅ Aspecto 53: CheckBoxes
- **VB6:** No hay checkboxes
- **NET:** N/A
- **Estado:** ✅ **N/A** - No aplica

### ❌ Aspecto 54: Campos ocultos/IDs
**VB6:**
- `C_ID`, `C_TIPOAJUSTE`, `C_IDITEM`, `C_TIPOING`, `C_FMT`, `C_COLOBLIGATORIA`, `C_UPD` (ColWidth = 0)

**NET:**
- ❌ **FALTA** campos ocultos en grid para tracking de cambios
- Datos almacenados en objeto JS `ajustesData` (View línea 71)

- **Estado:** ⚠️ **DIFERENTE** - Enfoque diferente (objeto JS vs columnas ocultas), funcional pero diferente

---

## 1️⃣1️⃣ GRIDS Y COLUMNAS (2 aspectos)

### ✅ Aspecto 55: Columnas del grid
**VB6:**
```vb
Grid.ColWidth(C_CONCEPTO) = 9000   '~60% del ancho
Grid.ColWidth(C_VALOR) = 1600      '~20% del ancho
Grid.ColWidth(C_SUBTOTAL) = 1600   '~20% del ancho
Grid.ColAlignment(C_VALOR) = flexAlignRightCenter
Grid.ColAlignment(C_SUBTOTAL) = flexAlignRightCenter
```

**NET:**
```javascript
tdConcepto.style.width = '60%';
tdValor.style.width = '20%';
tdSubtotal.style.width = '20%';
tdValor.className = 'text-right';
tdSubtotal.className = 'text-right';
```

- **Estado:** ✅ **OK** - Columnas idénticas con mismas proporciones y alineación

### ✅ Aspecto 56: Datos del grid
**VB6:**
- Saldo Ingresos (línea 340)
- Saldo Egresos (línea 348)
- Saldo Final (línea 356)
- Separador (línea 364)
- Agregados header (línea 370)
- Items agregados (loop 378-429)
- Separador (línea 431)
- Deducciones header (línea 438)
- Items deducciones (loop 446-482)
- Separador (línea 484)
- Base Imponible (línea 491)

**NET:**
- ✅ Saldo Ingresos (View línea 100)
- ✅ Saldo Egresos (View línea 101)
- ✅ Saldo Final (View línea 102)
- ✅ Separador (View línea 105)
- ✅ Agregados header (View línea 108)
- ✅ Items agregados (View línea 109-111)
- ✅ Separador (View línea 114)
- ✅ Deducciones header (View línea 117)
- ✅ Items deducciones (View línea 118-120)
- ✅ Separador (View línea 123)
- ✅ Base Imponible (View línea 126)

- **Estado:** ✅ **OK** - Estructura de datos idéntica

---

## 1️⃣2️⃣ EVENTOS E INTERACCIÓN (5 aspectos)

### ✅ Aspecto 57: Doble clic
**VB6:**
- No implementado doble clic

**NET:**
- No implementado

- **Estado:** ✅ **OK** - No requerido

### ✅ Aspecto 58: Teclas especiales
- **VB6:** No implementado `KeyPreview`
- **NET:** No implementado
- **Estado:** ✅ **OK** - No requerido para este formulario

### ✅ Aspecto 59: Eventos Change
**VB6:**
- `Grid_AcceptValue()` al editar celda (línea 964)
  ```vb
  Grid.TextMatrix(Row, Col) = Value
  Call FGrModRow(Grid, Row, FGR_U, C_ID, C_UPD)
  Call CalcTot
  ```

**NET:**
- `actualizarValor()` en `onblur` (View línea 175, 200)
  ```javascript
  onblur="actualizarValor('${tipo}', ${index}, this.value)"
  // Recalcula totales y re-renderiza
  ```

- **Estado:** ✅ **OK** - Evento equivalente implementado

### ⚠️ Aspecto 60: Menú contextual
- **VB6:** No implementado
- **NET:** No implementado
- **Estado:** ✅ **N/A** - No aplica

### ⚠️ Aspecto 61: Modales Lookup
**VB6:**
- Click en celda no editable abre detalle (línea 978)
  ```vb
  Else
      Call Bt_DetDoc_Click  'Abre FrmLibCaja o FrmRepActivoFijo
  End If
  ```

**NET:**
- ❌ **NO IMPLEMENTADO** - Click en celda no editable no hace nada

- **Estado:** ⚠️ **GAP MENOR** - Funcionalidad auxiliar faltante

---

## 1️⃣3️⃣ ESTADOS Y MODOS DEL FORMULARIO (3 aspectos)

### ✅ Aspecto 62: Modos del form
- **VB6:** Modo único: Edición (`FEdit()` línea 288)
- **NET:** Modo único: Visualización/Edición (`Index()`)
- **Estado:** ✅ **OK** - Un solo modo, equivalente

### ✅ Aspecto 63: Controles por modo
**VB6:**
- Celdas editables: solo `TipoIngreso = TIA_INGDIRECTO` (línea 975)
- Resto de celdas: solo lectura o abren detalle

**NET:**
- Celdas editables: `item.editable = true` (View línea 168)
- Resto: solo lectura

- **Estado:** ✅ **OK** - Lógica equivalente

### ✅ Aspecto 64: Orden de tabulación
- **VB6:** No usa `TabIndex` explícito en grid
- **NET:** No usa `tabindex`
- **Estado:** ✅ **OK** - No crítico para grid

---

## 1️⃣4️⃣ INICIALIZACIÓN Y CARGA (3 aspectos)

### ✅ Aspecto 65: Carga inicial
**VB6:**
- `Form_Load()` (línea 291)
  - `SetUpGrid()` (línea 294)
  - `LoadAll()` (línea 295)

**NET:**
- `cargarDatos()` llamado al final del script (View línea 287)
  - Fetch de datos vía API (View línea 81)
  - `renderGrid()` (View línea 86)

- **Estado:** ✅ **OK** - Equivalente, patrón moderno async

### ⚠️ Aspecto 66: Valores por defecto
**VB6:**
- `lOrientacion = ORIENT_VER` (línea 292)
- Valores calculados dinámicamente desde BD

**NET:**
- ❌ **FALTA** valores desde BD (no lee tabla `AjustesExtLibCaja`)
- Valores calculados parcialmente

- **Estado:** ⚠️ **GAP MEDIO** - No carga valores guardados previamente

### ✅ Aspecto 67: Llenado de combos
- **VB6:** No hay combos
- **NET:** N/A
- **Estado:** ✅ **N/A** - No aplica

---

## 1️⃣5️⃣ FILTROS Y BÚSQUEDA (2 aspectos)

### ✅ Aspecto 68: Campos de filtro
- **VB6:** No hay filtros (formulario de vista única por empresa/año)
- **NET:** Filtro por `empresaId` y `ano` (automático desde sesión)
- **Estado:** ✅ **OK** - Equivalente

### ✅ Aspecto 69: Criterios de búsqueda
**VB6:**
```vb
WHERE IdEmpresa = gEmpresa.id AND Ano = gEmpresa.Ano
```

**NET:**
```csharp
.Where(lc => lc.IdEmpresa == empresaId && lc.Ano == ano)
```

- **Estado:** ✅ **OK** - Equivalente

---

## 1️⃣6️⃣ REPORTES E IMPRESIÓN (2 aspectos)

### ⚠️ Aspecto 70: Reportes disponibles
**VB6:**
- Impresión configurada con:
  - Orientación vertical (línea 292, 937)
  - Títulos personalizados (línea 916)
  - Pie con firmas (`PrtPieBalance`) (línea 830, 887)
  - Opción papel foliado (línea 244, 914, 933)
  - Información preliminar (línea 245, 918)

**NET:**
- ✅ Impresión básica del navegador (View línea 39)
- ❌ **FALTA** configuración de orientación
- ❌ **FALTA** títulos personalizados
- ❌ **FALTA** pie de página con firmas
- ❌ **FALTA** papel foliado
- ❌ **FALTA** marca de agua "Preliminar"

- **Estado:** ❌ **GAP MEDIO** - Impresión muy simplificada

### ❌ Aspecto 71: Parámetros de reporte
**VB6:**
- `FrmPrtSetup` para configurar impresión (línea 818)
  - Orientación
  - Papel foliado
  - Info preliminar

**NET:**
- ❌ **NO IMPLEMENTADO**

- **Estado:** ❌ **GAP MEDIO** - Sin configuración de impresión

---

## AUDITORÍA FUNCIONAL (15 aspectos)

---

## 1️⃣7️⃣ REGLAS DE NEGOCIO (4 aspectos)

### ⚠️ Aspecto 72: Umbrales y límites
**VB6:**
```vb
'R: Gastos presuntos equivalente al 0,5% de los ingresos brutos (Min UTM, Max 15 UTM)
Tot = (SaldoIngresos + IngFEmision + IngFExigibilidad) * 0.005    '0.5%
MaxR = 15 * lValUTM
MinR = lValUTM
If Tot > MaxR Then Tot = MaxR
ElseIf Tot < MinR Then Tot = MinR
```
(líneas 714-733)

**NET:**
- ❌ **NO IMPLEMENTADO** - Cálculo de gastos presuntos completo falta

- **Estado:** ❌ **GAP CRÍTICO** - Regla tributaria importante no migrada

### ⚠️ Aspecto 73: Fórmulas de cálculo
**VB6:**
- **Gastos Presuntos:** `(SaldoIngresos + Ing12MesesEmi + Ing12MesesExig) * 0.005` limitado entre `[1 UTM, 15 UTM]` (líneas 715-733)
- **Base Imponible:** `SaldoFinal + TotalAgregados - TotalDeducciones` (línea 749)
- **Saldo Final:** `SaldoIngresos - SaldoEgresos` (línea 711)

**NET:**
- ✅ Base Imponible (View línea 212)
- ✅ Saldo Final calculado en backend (parcial)
- ❌ **FALTA** Gastos Presuntos con UTM

- **Estado:** ⚠️ **PARCIAL** - Fórmulas básicas OK, falta fórmula compleja

### ✅ Aspecto 74: Condiciones de negocio
**VB6:**
```vb
'K: Solo empresas relacionadas
AND NOT Entidades.EntRelacionada IS NULL AND Entidades.EntRelacionada <> 0
(línea 604)

'L: Solo no relacionadas, al contado, >12 meses desde emisión
AND (Entidades.EntRelacionada IS NULL OR Entidades.EntRelacionada = 0)
AND (NumCuotas IS NULL OR NumCuotas = 0)
AND DateDiff(month, FEmisionOri, FechaCierre) > 12
(líneas 626-630)

'M: Solo no relacionadas, a crédito, >12 meses desde emisión, no pagadas
AND (Entidades.EntRelacionada IS NULL OR Entidades.EntRelacionada = 0)
AND (FechaIngPercibido IS NULL or FechaIngPercibido = 0)
AND DateDiff(month, FEmisionOri, FechaCierre) > 12
(líneas 657-661)
```

**NET:**
```csharp
// Código presente pero no ejecutado (Service líneas 99-150)
// TODO: [LEGACY] [HIGH] Implementar cálculo de ajustes extracontables
```

- **Estado:** ❌ **GAP CRÍTICO** - Condiciones tributarias complejas no implementadas

### ❌ Aspecto 75: Restricciones
- **VB6:** Solo permite editar valores de tipo `TIA_INGDIRECTO` (línea 975)
- **NET:** Solo permite editar valores marcados `editable = true` (View línea 168)
- **Estado:** ✅ **OK** - Restricción equivalente

---

## 1️⃣8️⃣ FLUJOS DE TRABAJO (3 aspectos)

### ✅ Aspecto 76: Secuencia de estados
- **VB6:** Formulario sin estados (vista única)
- **NET:** Vista única
- **Estado:** ✅ **N/A** - No aplica

### ✅ Aspecto 77: Acciones por estado
**VB6:**
- Siempre permite: Ver, Editar valores directos, Guardar, Cancelar, Imprimir
- No permite: Eliminar, Nuevo

**NET:**
- Permite: Ver, Editar valores, Guardar, Exportar Excel, Imprimir básico

- **Estado:** ✅ **OK** - Acciones equivalentes

### ❌ Aspecto 78: Transiciones válidas
- **VB6:**
  - Abrir → Editar → Guardar → Cerrar
  - Abrir → Cancelar → Cerrar
- **NET:**
  - Abrir → Editar → Guardar → Cerrar
  - Abrir → Cerrar (sin botón Cancelar explícito)
- **Estado:** ⚠️ **GAP MENOR** - Falta botón Cancelar explícito

---

## 1️⃣9️⃣ INTEGRACIONES ENTRE MÓDULOS (3 aspectos)

### ✅ Aspecto 79: Llamadas a otros módulos
**VB6:**
```vb
' Abrir Libro de Caja (línea 260-264)
Set Frm = New FrmLibCaja
Call Frm.FView(-1)

' Abrir Reporte Activo Fijo (línea 269-272)
If InStr(LCase(Grid.TextMatrix(Row, C_CONCEPTO)), "33 bis") > 0 Then
    Set Frm = New FrmRepActivoFijo
    Call Frm.FView
End If
```

**NET:**
- ❌ **NO IMPLEMENTADO** - No abre módulos relacionados

- **Estado:** ⚠️ **GAP MEDIO** - Integraciones faltantes pero no críticas

### ✅ Aspecto 80: Parámetros de integración
**VB6:**
- `FrmLibCaja.FView(-1)` - Parámetro -1 indica vista completa
- `FrmRepActivoFijo.FView` - Sin parámetros, usa empresa/año global

**NET:**
- N/A (no implementado)

- **Estado:** ✅ **N/A** - Pendiente de implementación de integraciones

### ⚠️ Aspecto 81: Datos compartidos/retorno
**VB6:**
- Formularios auxiliares no retornan datos, solo visualización

**NET:**
- N/A

- **Estado:** ✅ **N/A** - No requiere retorno de datos

---

## 2️⃣0️⃣ MENSAJES AL USUARIO (2 aspectos)

### ✅ Aspecto 82: Mensajes de error
**VB6:**
- No hay mensajes de error explícitos (función `valida()` siempre retorna True)

**NET:**
```javascript
alert('Error al cargar los datos') (View línea 91)
alert('Error al guardar los datos') (View línea 254)
```

- **Estado:** ✅ **OK** - Mejora sobre VB6

### ❌ Aspecto 83: Mensajes de confirmación
**VB6:**
- No hay confirmaciones antes de guardar

**NET:**
- No hay confirmación antes de guardar
- ❌ **FALTA** "¿Está seguro de guardar los ajustes?"

- **Estado:** ⚠️ **GAP MENOR** - Sería buena práctica agregar confirmación

---

## 2️⃣1️⃣ CASOS BORDE Y VALORES ESPECIALES (3 aspectos)

### ✅ Aspecto 84: Valores cero
**VB6:**
- Permite valores 0 en campos editables
- `vFmt()` convierte vacío a 0

**NET:**
- `parseFloat(value) || 0` (View línea 201)

- **Estado:** ✅ **OK** - Manejo equivalente

### ✅ Aspecto 85: Valores negativos
**VB6:**
- `KeyNumPos()` - SOLO permite números positivos (línea 985)
- Formato muestra negativos con paréntesis (NEGNUMFMT)

**NET:**
- `soloNumeros()` - Permite números sin signo (View línea 279)
- ⚠️ **PERMITE NEGATIVOS** (no valida signo)
- Formato muestra negativos con paréntesis (View línea 276)

- **Estado:** ⚠️ **GAP MENOR** - Permite negativos cuando VB6 no lo permite

### ❌ Aspecto 86: Valores nulos/vacíos
**VB6:**
- `vFld(Rs("campo"))` maneja nulls de BD (líneas 525, 542, 585)
- `vFmt(Grid.TextMatrix())` convierte string a número (línea 711)

**NET:**
- Uso de `??` operators (Service línea 65-73)
- `|| 0` en parsing (View línea 201)

- **Estado:** ✅ **OK** - Manejo adecuado de nulls

---

## 📊 RESUMEN DE GAPS

### 🔴 Gaps Críticos (Bloquean funcionalidad core)

| # | Gap | Impacto | Ubicación VB6 | Solución Requerida |
|---|-----|---------|---------------|-------------------|
| 1 | **Guardado no implementado** | 🔴 CRÍTICO | Líneas 757-792 | Implementar INSERT/UPDATE en `GuardarAjustesAsync()` |
| 2 | **No lee valores guardados desde BD** | 🔴 CRÍTICO | Línea 578 | Leer tabla `AjustesExtLibCaja` en `GetAjustesAsync()` |
| 3 | **Cálculo Gastos Presuntos faltante** | 🔴 CRÍTICO | Líneas 714-733 | Implementar cálculo con límites UTM (Min 1, Max 15) |
| 4 | **Funciones de cálculo complejas no migradas** | 🔴 CRÍTICO | Líneas 593-697 | Implementar 8 funciones: GetVal33Bis, GetIngNoPercibRel, GetIngNoPercib12MesesEmi/Exig, GetIngEgrDevengados, LoadValCuentasAjustes |
| 5 | **Queries complejas faltantes** | 🔴 CRÍTICO | Líneas 599-674 | Migrar queries de entidades relacionadas, ingresos >12 meses |
| 6 | **Validaciones de negocio no implementadas** | 🔴 CRÍTICO | Múltiples líneas | Implementar condiciones tributarias (relacionadas, 12 meses, etc.) |

### 🟠 Gaps Medios (Funcionalidad secundaria)

| # | Gap | Impacto | Ubicación VB6 | Solución Requerida |
|---|-----|---------|---------------|-------------------|
| 7 | **Impresión simplificada** | 🟠 MEDIO | Líneas 812-953 | Agregar configuración, títulos, pie con firmas, papel foliado |
| 8 | **Botones auxiliares faltantes** | 🟠 MEDIO | Líneas 252, 988, 999, 1009, 1012 | Implementar: DetDoc, Sum, ConvMoneda, Calc, Calendar |
| 9 | **No abre formularios relacionados** | 🟠 MEDIO | Líneas 260, 269 | Implementar navegación a LibCaja y RepActivoFijo |
| 10 | **Valores previos no se cargan** | 🟠 MEDIO | Línea 66 (Aspecto 33) | Cargar valores default desde BD al abrir |

### 🟡 Gaps Menores (UX diferente, no crítico)

| # | Gap | Impacto | Ubicación VB6 | Solución Requerida |
|---|-----|---------|---------------|-------------------|
| 11 | **Permite valores negativos** | 🟡 MENOR | Línea 985 | Cambiar `soloNumeros()` para rechazar negativos |
| 12 | **Sin botón Cancelar explícito** | 🟡 MENOR | Línea 247 | Agregar botón Cancelar en toolbar |
| 13 | **Click en celda no editable no hace nada** | 🟡 MENOR | Línea 978 | Abrir detalle al hacer click en celda calculada |
| 14 | **Sin confirmación al guardar** | 🟡 MENOR | N/A en VB6 | Agregar modal "¿Confirma guardar?" |
| 15 | **Vista previa faltante** | 🟡 MENOR | Línea 869 | Implementar preview antes de imprimir |

### ✅ Mejoras sobre VB6

| # | Mejora | Beneficio |
|---|--------|-----------|
| 1 | **Validación de empresa al inicio** | Evita errores de contexto |
| 2 | **Try/catch con logging** | Mejor diagnóstico de errores |
| 3 | **Mensajes de error informativos** | Mejor UX |
| 4 | **Exportar a archivo Excel** | Más fácil que clipboard |
| 5 | **UI responsive moderna** | Mejor experiencia visual |

---

## ✅ CONCLUSIÓN

### Estado General: **68.6% PARIDAD** ⚠️

**Veredicto:** 🟠 **NO ACEPTABLE PARA PRODUCCIÓN** - Requiere completar migración

### Bloqueadores Críticos para Producción:

1. ❌ **Persistencia no funcional** - No guarda ni lee datos de BD
2. ❌ **Lógica de negocio incompleta** - Faltan cálculos tributarios esenciales (Art. 14 ter)
3. ❌ **Queries complejas faltantes** - No calcula ajustes por entidades relacionadas ni plazos >12 meses

### Próximos Pasos Recomendados:

#### FASE 1 - Crítico (1-2 semanas)
1. Implementar persistencia completa (INSERT/UPDATE/SELECT)
2. Migrar cálculo de Gastos Presuntos con límites UTM
3. Implementar queries de ingresos no percibidos (relacionadas, 12 meses)
4. Migrar funciones de cálculo: GetVal33Bis, GetIngNoPercibRel, etc.

#### FASE 2 - Importante (1 semana)
5. Implementar botones auxiliares (DetDoc, Sum, Calc, etc.)
6. Mejorar impresión (títulos, pie, papel foliado)
7. Agregar validación de negativos
8. Implementar navegación a formularios relacionados

#### FASE 3 - Opcional (mejoras UX)
9. Agregar confirmación al guardar
10. Implementar vista previa de impresión
11. Agregar botón Cancelar
12. Implementar acción al click en celdas calculadas

### Estimación de Esfuerzo:

- **Fase 1 (Crítico):** 60-80 horas
- **Fase 2 (Importante):** 30-40 horas
- **Fase 3 (Opcional):** 10-15 horas
- **TOTAL:** 100-135 horas (2.5 - 3.5 semanas de desarrollo)

### Riesgos:

⚠️ **ALTO** - Feature clave para régimen tributario Art. 14 ter no está funcional
⚠️ **ALTO** - Datos no se persisten, pérdida de información
⚠️ **MEDIO** - Cálculos tributarios incorrectos podrían generar problemas con SII

---

**Fecha reporte:** 28 de noviembre de 2025
**Analista:** Claude Code
**Versión:** 1.0
