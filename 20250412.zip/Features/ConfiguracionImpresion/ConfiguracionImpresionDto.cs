using System.ComponentModel.DataAnnotations;

namespace App.Features.ConfiguracionImpresion;

/// <summary>
/// DTO para la configuración de impresión de documentos y libros contables
/// </summary>
public class ConfiguracionImpresionDto
{
    /// <summary>
    /// Orientación del papel: Vertical (Portrait) u Horizontal (Landscape)
    /// </summary>
    [Required]
    [Display(Name = "Orientación Papel")]
    public OrientacionPapel Orientacion { get; set; } = OrientacionPapel.Vertical;

    /// <summary>
    /// Indica si se imprime en papel foliado (pre-timbrado y numerado)
    /// Requiere privilegio PRV_IMP_LIBOF para habilitarse
    /// </summary>
    [Display(Name = "Papel Foliado")]
    public bool PapelFoliado { get; set; } = false;

    /// <summary>
    /// Indica si el documento es un informe preliminar/borrador
    /// Generalmente agrega marca de agua o nota indicando que es preliminar
    /// </summary>
    [Display(Name = "Informe Preliminar")]
    public bool InfoPreliminar { get; set; } = false;
}

/// <summary>
/// Enumeración de orientaciones de papel
/// </summary>
public enum OrientacionPapel
{
    /// <summary>
    /// Orientación vertical (Portrait) - Valor por defecto
    /// </summary>
    Vertical = 1,

    /// <summary>
    /// Orientación horizontal (Landscape)
    /// </summary>
    Horizontal = 2
}

/// <summary>
/// DTO con información de privilegios del usuario para impresión
/// </summary>
public class PrivilegiosImpresionDto
{
    /// <summary>
    /// Indica si el usuario tiene privilegio para imprimir libros oficiales
    /// (PRV_IMP_LIBOF) y habilitar la opción de papel foliado
    /// </summary>
    public bool PuedeImprimirLibrosOficiales { get; set; } = false;

    /// <summary>
    /// Mensaje informativo sobre los privilegios
    /// </summary>
    public string? Mensaje { get; set; }
}

/// <summary>
/// DTO para el resultado de aplicar la configuración de impresión
/// </summary>
public class ResultadoConfiguracionDto
{
    public ConfiguracionImpresionDto? Configuracion { get; set; }
}

#region ViewModels

public class ConfiguracionImpresionIndexViewModel
{
    public ConfiguracionImpresionDto Config { get; set; } = null!;
    public PrivilegiosImpresionDto Privilegios { get; set; } = null!;
}

#endregion
