using App.Data;
using App.Exceptions;

namespace App.Features.ConfiguracionImpresion;

/// <summary>
/// Servicio para gestionar la configuración de impresión de documentos y libros contables
/// </summary>
public class ConfiguracionImpresionService(
    LpContabContext context,
    ILogger<ConfiguracionImpresionService> logger,
    IHttpContextAccessor httpContextAccessor) : IConfiguracionImpresionService
{
    private readonly LpContabContext _context = context;

    // Código del privilegio para imprimir libros oficiales
    private const string PRV_IMP_LIBOF = "PRV_IMP_LIBOF";

    /// <summary>
    /// Obtiene la configuración de impresión por defecto
    /// </summary>
    public async Task<ConfiguracionImpresionDto> GetConfiguracionDefaultAsync()
    {
        {
            logger.LogInformation("Obteniendo configuración de impresión por defecto");

            // Intentar obtener configuración guardada del usuario
            var configuracionGuardada = await GetConfiguracionGuardadaAsync();
            
            if (configuracionGuardada != null)
            {
                logger.LogInformation("Retornando configuración guardada del usuario");
                return configuracionGuardada;
            }

            // Retornar configuración por defecto
            return new ConfiguracionImpresionDto
            {
                Orientacion = OrientacionPapel.Vertical,
                PapelFoliado = false,
                InfoPreliminar = false
            };
        }
    }

    /// <summary>
    /// Valida los privilegios del usuario actual para opciones de impresión
    /// </summary>
    public async Task<PrivilegiosImpresionDto> ValidarPrivilegiosUsuarioAsync()
    {
        {
            logger.LogInformation("Validando privilegios de usuario para impresión");

            // TODO: Implementar lógica real de validación de privilegios
            // Por ahora, retornar privilegio concedido para desarrollo
            // En producción, esto debería consultar la tabla de privilegios del usuario

            // Ejemplo de lógica (comentado hasta tener sistema de privilegios):
            /*
            var userId = _httpContextAccessor.HttpContext?.User?.Identity?.Name;
            
            if (string.IsNullOrEmpty(userId))
            {
                return new PrivilegiosImpresionDto
                {
                    PuedeImprimirLibrosOficiales = false,
                    Mensaje = "Usuario no autenticado"
                };
            }

            var tienePrivilegio = await _context.PcUsr
                .Where(u => u.Usuario == userId)
                .SelectMany(u => u.Privilegios)
                .AnyAsync(p => p.Codigo == PRV_IMP_LIBOF);

            return new PrivilegiosImpresionDto
            {
                PuedeImprimirLibrosOficiales = tienePrivilegio,
                Mensaje = tienePrivilegio 
                    ? "Usuario autorizado para imprimir libros oficiales" 
                    : "Usuario no tiene privilegio para imprimir libros oficiales"
            };
            */

            // Por ahora, retornar privilegio concedido (desarrollo)
            await Task.CompletedTask;
            
            return new PrivilegiosImpresionDto
            {
                PuedeImprimirLibrosOficiales = true,
                Mensaje = "Privilegios validados correctamente"
            };
        }
    }

    /// <summary>
    /// Guarda la configuración de impresión en la sesión del usuario
    /// </summary>
    public async Task<ConfiguracionImpresionDto> GuardarConfiguracionAsync(ConfiguracionImpresionDto configuracion)
    {
        {
            logger.LogInformation("Guardando configuración de impresión en sesión");

            // Validar privilegios si se intenta usar papel foliado
            if (configuracion.PapelFoliado)
            {
                var privilegios = await ValidarPrivilegiosUsuarioAsync();

                if (!privilegios.PuedeImprimirLibrosOficiales)
                {
                    logger.LogWarning("Usuario intenta usar papel foliado sin privilegios");
                    throw new BusinessException("No tiene privilegios para imprimir en papel foliado");
                }
            }

            // Guardar en sesión
            var session = httpContextAccessor.HttpContext?.Session;
            if (session != null)
            {
                session.SetString("ConfigImpresion_Orientacion", configuracion.Orientacion.ToString());
                session.SetString("ConfigImpresion_PapelFoliado", configuracion.PapelFoliado.ToString());
                session.SetString("ConfigImpresion_InfoPreliminar", configuracion.InfoPreliminar.ToString());
            }

            logger.LogInformation("Configuración de impresión guardada exitosamente");

            return configuracion;
        }
    }

    /// <summary>
    /// Obtiene la configuración de impresión guardada en la sesión del usuario
    /// </summary>
    public async Task<ConfiguracionImpresionDto?> GetConfiguracionGuardadaAsync()
    {
        {
            var session = httpContextAccessor.HttpContext?.Session;
            
            if (session == null)
            {
                return null;
            }

            var orientacionStr = session.GetString("ConfigImpresion_Orientacion");
            var papelFoliadoStr = session.GetString("ConfigImpresion_PapelFoliado");
            var infoPreliminarStr = session.GetString("ConfigImpresion_InfoPreliminar");

            // Si no hay configuración guardada, retornar null
            if (string.IsNullOrEmpty(orientacionStr))
            {
                return null;
            }

            // Parsear valores
            var orientacion = Enum.TryParse<OrientacionPapel>(orientacionStr, out var o) 
                ? o 
                : OrientacionPapel.Vertical;
            
            var papelFoliado = bool.TryParse(papelFoliadoStr, out var pf) && pf;
            var infoPreliminar = bool.TryParse(infoPreliminarStr, out var ip) && ip;

            await Task.CompletedTask;

            return new ConfiguracionImpresionDto
            {
                Orientacion = orientacion,
                PapelFoliado = papelFoliado,
                InfoPreliminar = infoPreliminar
            };
        }
    }
}
