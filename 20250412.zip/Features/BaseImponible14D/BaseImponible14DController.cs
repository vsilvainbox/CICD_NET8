using Microsoft.AspNetCore.Mvc;
using App.Helpers;
using App.Extensions;

namespace App.Features.BaseImponible14D;

public class BaseImponible14DController(
    IHttpClientFactory httpClientFactory,
    ILogger<BaseImponible14DController> logger,
    LinkGenerator linkGenerator) : Controller
{
    public async Task<IActionResult> Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Base Imponible 14D";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        logger.LogInformation("Loading Base Imponible 14D index for empresaId: {EmpresaId}, ano: {Ano}", SessionHelper.EmpresaId, SessionHelper.Ano);

        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<BaseImponible14DApiController>(HttpContext, nameof(BaseImponible14DApiController.Get), new { empresaId = SessionHelper.EmpresaId, ano = SessionHelper.Ano });
            var data = await client.GetFromApiAsync<BaseImponible14DDto>(url!);

            logger.LogInformation("Successfully loaded Base Imponible 14D for empresaId: {EmpresaId}, ano: {Ano}", SessionHelper.EmpresaId, SessionHelper.Ano);

            return View(data);
        }
    }

    /// <summary>
    /// Proxy method para exportar a Excel (evita llamada directa Vista ? API)
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ExportExcel(int empresaId, short ano)
    {
        logger.LogInformation("Exporting Base Imponible 14D to Excel for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<BaseImponible14DApiController>(HttpContext, nameof(BaseImponible14DApiController.ExportExcel), new { empresaId, ano });
            var (fileBytes, contentType) = await client.DownloadFileAsync(
                url!,
                HttpMethod.Get,
                null);

            var fileName = $"BaseImponible14D_{ano}.xlsx";
            return File(fileBytes, contentType, fileName);
        }
    }
        
    /// <summary>
    /// Proxy method para exportar a PDF
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ExportPdf(int empresaId, short ano)
    {
        logger.LogInformation("Exporting Base Imponible 14D to PDF for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<BaseImponible14DApiController>(HttpContext, nameof(BaseImponible14DApiController.ExportPdf), new { empresaId, ano });
            var (fileBytes, contentType) = await client.DownloadFileAsync(
                url!,
                HttpMethod.Get,
                null);

            var fileName = $"BaseImponible14D_{ano}.pdf";
            return File(fileBytes, contentType, fileName);
        }
    }
        
    /// <summary>
    /// Proxy method para traspasar p�rdida del año anterior
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> TraspasarPerdidaAnterior(int empresaId, short ano)
    {
        logger.LogInformation("Traspasando p�rdida año anterior for empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient();
            var url = linkGenerator.GetApiUrl<BaseImponible14DApiController>(HttpContext, nameof(BaseImponible14DApiController.TraspasarPerdidaAnterior), new { empresaId, ano });
            await client.PostToApiAsync(url!, (object?)null);

            return Ok(new { message = "P�rdida traspasada exitosamente" });
        }
    }
}