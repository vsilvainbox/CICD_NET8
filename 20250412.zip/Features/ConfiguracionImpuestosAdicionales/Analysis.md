# Análisis: Configuración Impuestos Adicionales

## 📋 Resumen
Formulario que permite configurar los impuestos adicionales para el Libro de Compras/Ventas, asignando cuentas contables y tasas a cada tipo de impuesto adicional.

## 🎯 Funcionalidad VB6 Original

### FrmConfigImpAdic.frm
**Propósito:** Gestión de impuestos adicionales e IVA retenido del Libro de Compras

**Características principales:**
1. **Dos modos de operación:**
   - `O_CONFIG` (1): Configuración de impuestos para la empresa
   - `O_SELECT` (2): Selección de impuestos para agregar a documento

2. **Grid con columnas:**
   - Código SII
   - Tipo de Impuesto Adicional e IVA Retenido
   - Tasa (editable según configuración)
   - Recuperable (Si/No)
   - Código Cuenta
   - Cuenta (descripción)
   - Columna de selección (>>)
   - Columna de aplicación (checkbox)

3. **Funcionalidades:**
   - Asignar cuenta contable a cada impuesto
   - Configurar tasa (si es editable)
   - Marcar como recuperable/no recuperable
   - Eliminar configuración de impuesto
   - Copiar a Excel
   - Copiar configuración de otra empresa
   - Ocultar impuestos descontinuados
   - Ver manual IEC (Libro Electrónico de Compras)

4. **Validaciones:**
   - Cuenta obligatoria si impuesto está marcado
   - Tasa obligatoria o advertencia si está vacía
   - Verificar que impuesto aplique al tipo de documento
   - Solo cuentas de último nivel

5. **Reglas de negocio:**
   - Si tasa está en blanco: editable para la empresa (azul)
   - Si tasa está fija: no editable (negro)
   - Si tasa está en blanco en selección: editable para documento (verde)
   - Si no hay cuenta asignada: impuesto no aplica

## 📊 Tablas Involucradas

### Principales
- `ImpAdic`: Configuración de impuestos adicionales
  - IdImpAdic, IdEmpresa, Ano, TipoLib, TipoValor
  - IdCuenta, CodCuenta, Tasa, EsRecuperable

- `TipoValor`: Catálogo de tipos de valores/impuestos
  - idTValor, TipoLib, Codigo, Valor, CodSIIDTE
  - Tasa, TasaFija, EsRecuperable, TipoDoc, Atributo

- `Cuentas`: Plan de cuentas contables
  - IdCuenta, Codigo, Descripcion, Nivel

## 🔄 Flujo de Usuario

### Modo Configuración (O_CONFIG):
1. Abre formulario desde menú de configuración
2. Muestra todos los tipos de impuestos adicionales disponibles
3. Usuario asigna cuenta contable (doble click o >>)
4. Usuario marca/desmarca checkbox "Aplica"
5. Usuario configura tasa si es editable
6. Usuario marca/desmarca "Recuperable"
7. Opcionalmente: copiar configuración de otra empresa
8. Guardar configuración

### Modo Selección (O_SELECT):
1. Abre desde detalle de documento
2. Muestra solo impuestos configurados para tipo documento
3. Usuario selecciona impuestos con checkbox
4. Usuario puede ajustar tasa si es editable para documento
5. Devuelve array de impuestos seleccionados

## 🎨 Interfaz de Usuario

### Elementos principales:
- Grid editable con toda la configuración
- Botones: Aceptar, Cancelar, Cuentas, Eliminar, Copiar a Excel
- Botón "Copiar Configuración de otra Empresa"
- Checkbox "Ocultar Impuestos Adicionales descontinuados"
- Notas explicativas sobre colores y edición de tasas
- Botón "Manual IEC" (visible según contexto)

### Colores semánticos:
- **Azul**: Tasa editable para la empresa
- **Verde**: Tasa editable para el documento
- **Negro**: Tasa fija (no editable)
- **Rojo**: Textos de ayuda/advertencias

## 🔌 Integración

### Entrada:
- `TipoLib`: Tipo de libro (Compras/Ventas)
- `TipoDoc`: Tipo de documento (solo en modo selección)
- `EmpresaId`, `Ano`: Contexto de empresa y año

### Salida (modo selección):
- Array de `ImpAdic_t` con impuestos seleccionados
   - Incluye: TipoLib, CodTipoValor, TipoValor, IdCuenta, CodCuenta, Cuenta, Tasa, EsRecuperable

## 📝 Notas de Migración

1. **Dos modos en una vista:** Crear dos vistas separadas o componente reutilizable
2. **Grid editable:** Implementar con DataTables o componente similar
3. **Selector de cuentas:** Integrar con modal de Plan de Cuentas
4. **Colores de tasa:** Implementar con clases CSS según reglas
5. **Copiar de otra empresa:** Implementar servicio de copia
6. **Validaciones:** Implementar en cliente y servidor
7. **Parámetro empresa:** Gestionar desde configuración global
8. **Filtros por atributos:** Excluir "SINUSO", "IVAIRREC", "IVAACTFIJO"

## 🚀 Prioridad
**ALTA** - Configuración crítica para gestión de impuestos en documentos de compra/venta
