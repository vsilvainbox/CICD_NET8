using Microsoft.AspNetCore.Mvc;

namespace App.Features.ConfiguracionImpuestosAdicionales;

/// <summary>
/// API Controller para configuración de impuestos adicionales
/// </summary>
[ApiController]
[Route("[controller]/[action]")]
public class ConfiguracionImpuestosAdicionalesApiController(
    IConfiguracionImpuestosAdicionalesService service,
    ILogger<ConfiguracionImpuestosAdicionalesApiController> logger) : ControllerBase
{
    /// <summary>
    /// Obtiene la configuración de impuestos adicionales
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<ConfiguracionImpuestosResponse>> GetImpuestosAdicionales(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        [FromQuery] byte tipoLib)
    {
        logger.LogInformation("API: GetImpuestosAdicionales - EmpresaId={EmpresaId}, Ano={Ano}, TipoLib={TipoLib}",
            empresaId, ano, tipoLib);

        var request = new GetConfiguracionRequest
        {
            EmpresaId = empresaId,
            Ano = ano,
            TipoLib = tipoLib
        };

        var response = await service.GetConfiguracionAsync(request);
        return Ok(response);
    }

    /// <summary>
    /// Guarda la configuración de impuestos adicionales
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<ConfiguracionImpuestosResponse>> GuardarConfiguracion(
        [FromBody] SaveConfiguracionRequest request)
    {
        logger.LogInformation("API: GuardarConfiguracion - EmpresaId={EmpresaId}, Ano={Ano}",
            request.EmpresaId, request.Ano);

        var response = await service.SaveConfiguracionAsync(request);
        return Ok(response);
    }

    /// <summary>
    /// Obtiene los tipos de valores disponibles para configurar
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<List<TipoValorDisponibleDto>>> GetTiposValores(
        [FromQuery] byte tipoLib)
    {
        logger.LogInformation("API: GetTiposValores - TipoLib={TipoLib}", tipoLib);

        var tiposValores = await service.GetTiposValoresDisponiblesAsync(tipoLib);
        return Ok(tiposValores);
    }

    /// <summary>
    /// Obtiene los impuestos para selección en documento
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<List<ImpuestoAdicionalDto>>> GetImpuestosParaSeleccion(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        [FromQuery] byte tipoLib,
        [FromQuery] byte tipoDoc)
    {
        logger.LogInformation("API: GetImpuestosParaSeleccion - EmpresaId={EmpresaId}, Ano={Ano}, TipoLib={TipoLib}, TipoDoc={TipoDoc}",
            empresaId, ano, tipoLib, tipoDoc);

        var request = new SeleccionarImpuestosRequest
        {
            EmpresaId = empresaId,
            Ano = ano,
            TipoLib = tipoLib,
            TipoDoc = tipoDoc
        };

        var impuestos = await service.GetImpuestosParaSeleccionAsync(request);
        return Ok(impuestos);
    }

    /// <summary>
    /// Asigna una cuenta contable a un tipo de impuesto
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<ConfiguracionImpuestosResponse>> AsignarCuenta(
        [FromBody] AsignarCuentaRequest request)
    {
        logger.LogInformation("API: AsignarCuenta - EmpresaId={EmpresaId}, Ano={Ano}, TipoLib={TipoLib}, TipoValor={TipoValor}",
            request.EmpresaId, request.Ano, request.TipoLib, request.TipoValor);

        var response = await service.AsignarCuentaAsync(request);
        return Ok(response);
    }

    /// <summary>
    /// Elimina la configuración de un impuesto
    /// </summary>
    [HttpDelete]
    public async Task<ActionResult<ConfiguracionImpuestosResponse>> EliminarImpuesto(
        int idImpAdic,
        [FromQuery] int empresaId,
        [FromQuery] short ano)
    {
        logger.LogInformation("API: EliminarImpuesto - IdImpAdic={IdImpAdic}, EmpresaId={EmpresaId}, Ano={Ano}",
            idImpAdic, empresaId, ano);

        var request = new EliminarImpuestoRequest
        {
            IdImpAdic = idImpAdic,
            EmpresaId = empresaId,
            Ano = ano
        };

        var response = await service.EliminarImpuestoAsync(request);
        return Ok(response);
    }

    /// <summary>
    /// Copia la configuración de una empresa a otra
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<ConfiguracionImpuestosResponse>> CopiarConfiguracion(
        [FromBody] CopiarConfiguracionRequest request)
    {
        logger.LogInformation("API: CopiarConfiguracion - OrigenId={OrigenId}, DestinoId={DestinoId}, Ano={Ano}, TipoLib={TipoLib}",
            request.EmpresaOrigenId, request.EmpresaDestinoId, request.Ano, request.TipoLib);

        var response = await service.CopiarConfiguracionAsync(request);
        return Ok(response);
    }

    /// <summary>
    /// Valida la configuración de un impuesto
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<object>> ValidarImpuesto(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        [FromQuery] byte tipoLib,
        [FromQuery] short tipoValor)
    {
        logger.LogInformation("API: ValidarImpuesto - EmpresaId={EmpresaId}, Ano={Ano}, TipoLib={TipoLib}, TipoValor={TipoValor}",
            empresaId, ano, tipoLib, tipoValor);

        var (isValid, message) = await service.ValidarImpuestoAsync(empresaId, ano, tipoLib, tipoValor);

        return Ok(new
        {
            isValid,
            message
        });
    }
}