﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Extensions;
using App.Helpers;

namespace App.Features.ConfiguracionImpuestosAdicionales;

/// <summary>
/// MVC Controller para configuración de impuestos adicionales
/// </summary>
public class ConfiguracionImpuestosAdicionalesController(
    IHttpClientFactory httpClientFactory,
    ILogger<ConfiguracionImpuestosAdicionalesController> logger, LinkGenerator linkGenerator) : Controller
{
    /// <summary>
    /// Vista principal de configuración
    /// </summary>
    public IActionResult Index(int tipoLib = 1)
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a la Configuración de Impuestos Adicionales";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        // Extraer datos de HttpContext usando extensiones
        var empresaId = SessionHelper.EmpresaId;
        int ano = SessionHelper.Ano;

        logger.LogInformation("Accediendo a configuración de impuestos adicionales. EmpresaId: {EmpresaId}, año: {Ano}, TipoLib: {TipoLib}",
            empresaId, ano, tipoLib);

        var viewModel = new ConfiguracionImpuestosAdicionalesIndexViewModel
        {
            EmpresaId = empresaId,
            Ano = ano,
            TipoLib = tipoLib,
            TipoLibNombre = tipoLib == 1 ? "Compras" : "Ventas"
        };

        return View(viewModel);
    }

    /// <summary>
    /// Vista para seleccionar impuestos en documento
    /// </summary>
    public IActionResult Seleccionar(int tipoLib = 1, int tipoDoc = 30)
    {
        // Extraer datos de HttpContext usando extensiones
        var empresaId = SessionHelper.EmpresaId;
        int ano = SessionHelper.Ano;

        logger.LogInformation("Seleccionando impuestos para documento. EmpresaId: {EmpresaId}, TipoLib: {TipoLib}, TipoDoc: {TipoDoc}",
            empresaId, tipoLib, tipoDoc);

        var viewModel = new ConfiguracionImpuestosAdicionalesSeleccionarViewModel
        {
            EmpresaId = empresaId,
            Ano = ano,
            TipoLib = tipoLib,
            TipoDoc = tipoDoc,
            TipoLibNombre = tipoLib == 1 ? "Compras" : "Ventas"
        };

        return View(viewModel);
    }

    /// <summary>
    /// Proxy: Obtener impuestos adicionales
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetImpuestos(int empresaId, short ano, int tipoLib)
    {
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionImpuestosAdicionalesApiController>(
            HttpContext,
            nameof(ConfiguracionImpuestosAdicionalesApiController.GetImpuestosAdicionales),
            new { empresaId, ano, tipoLib });
        var datos = await client.GetFromApiAsync<object>(url!);
        return Ok(datos);
    }

    /// <summary>
    /// Proxy: Guardar configuración
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Guardar([FromBody] JsonElement request)
    {
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionImpuestosAdicionalesApiController>(
            HttpContext,
            nameof(ConfiguracionImpuestosAdicionalesApiController.GuardarConfiguracion));
        var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }

    /// <summary>
    /// Proxy: Copiar configuración de otra empresa
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Copiar([FromBody] JsonElement request)
    {
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionImpuestosAdicionalesApiController>(
            HttpContext,
            nameof(ConfiguracionImpuestosAdicionalesApiController.CopiarConfiguracion));
        var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }

    /// <summary>
    /// Proxy: Eliminar configuración de impuesto
    /// </summary>
    [HttpDelete]
    public async Task<IActionResult> Eliminar(int id, int empresaId, short ano)
    {
        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<ConfiguracionImpuestosAdicionalesApiController>(
            HttpContext,
            nameof(ConfiguracionImpuestosAdicionalesApiController.EliminarImpuesto),
            new { idImpAdic = id, empresaId, ano });
        var (statusCode, content) = await client.ProxyRequestAsync(url!, null, HttpMethod.Delete);
        return StatusCode(statusCode, content);
    }
}