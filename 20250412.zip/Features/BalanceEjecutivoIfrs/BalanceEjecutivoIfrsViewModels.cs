namespace App.Features.BalanceEjecutivoIfrs;

/// <summary>
/// ViewModel para la vista Index de Balance Ejecutivo IFRS.
/// Elimina ViewBag.AreasNegocio, ViewBag.CentrosCosto, ViewBag.FechaDesde, ViewBag.FechaHasta
/// </summary>
public class BalanceEjecutivoIfrsIndexViewModel
{
    /// <summary>
    /// Lista de áreas de negocio para el combo.
    /// </summary>
    public List<Shared.ComboItemDto> AreasNegocio { get; set; } = new();

    /// <summary>
    /// Lista de centros de costo para el combo.
    /// </summary>
    public List<Shared.ComboItemDto> CentrosCosto { get; set; } = new();

    /// <summary>
    /// Fecha desde por defecto (primer día del mes actual).
    /// </summary>
    public DateTime FechaDesde { get; set; }

    /// <summary>
    /// Fecha hasta por defecto (hoy).
    /// </summary>
    public DateTime FechaHasta { get; set; }
}
