namespace App.Features.AyudaImportacionCartola;

public class AyudaImportacionCartolaService(ILogger<AyudaImportacionCartolaService> logger) : IAyudaImportacionCartolaService
{
    // Datos estáticos que replican exactamente el contenido del formulario VB6
    private static readonly List<CampoFormatoDto> _camposEstaticos = new()
    {
        new CampoFormatoDto { Campo = "Fecha", Formato = "dd/mm/yyyy, por ejemplo: 16/07/2006." },
        new CampoFormatoDto { Campo = "Detalle", Formato = "Texto de descripción." },
        new CampoFormatoDto { Campo = "Nro. Doc.", Formato = "Número del documento, sin puntos." },
        new CampoFormatoDto { Campo = "Cargo", Formato = "Valor numérico." },
        new CampoFormatoDto { Campo = "Abono", Formato = "Valor numérico." }
    };

    public async Task<AyudaImportacionCartolaDto> GetAyudaImportacionAsync()
    {
        logger.LogInformation("Getting ayuda importacion cartola data");

        {
            var ayuda = new AyudaImportacionCartolaDto
            {
                Titulo = "Formato Importación Cartolas Bancarias",
                Instrucciones = "Columnas o campos del archivo:",
                Nota = "NOTA:",
                DetalleNota = "Los archivos de importación deben seguir exactamente el formato especificado para garantizar una importación correcta de los datos bancarios. Verifique que las fechas estén en formato dd/mm/yyyy y que los valores numéricos no contengan caracteres especiales.",
                Campos = _camposEstaticos
            };

            logger.LogInformation("Successfully retrieved ayuda importacion data with {Count} campos", _camposEstaticos.Count);
                
            return await Task.FromResult(ayuda);
        }
    }

    public async Task<string> GenerateClipboardTextAsync()
    {
        logger.LogInformation("Generating clipboard text for ayuda importacion cartola");

        {
            var headers = "Campo de Información\tFormato";
            var rows = _camposEstaticos.Select(c => $"{c.Campo}\t{c.Formato}");
            var clipboardText = headers + "\n" + string.Join("\n", rows);

            logger.LogInformation("Successfully generated clipboard text with {RowCount} rows", _camposEstaticos.Count);
                
            return await Task.FromResult(clipboardText);
        }
    }

    public async Task<IEnumerable<CampoFormatoDto>> GetCamposFormatoAsync()
    {
        logger.LogInformation("Getting campos formato for ayuda importacion cartola");

        {
            logger.LogInformation("Successfully retrieved {Count} campos formato", _camposEstaticos.Count);
            return await Task.FromResult(_camposEstaticos.AsEnumerable());
        }
    }

    public async Task<ClipboardResponseDto> GenerateClipboardResponseAsync()
    {
        logger.LogInformation("Generating clipboard response for ayuda importacion cartola");

        var clipboardText = await GenerateClipboardTextAsync();
        var response = new ClipboardResponseDto
        {
            ClipboardText = clipboardText
        };

        logger.LogInformation("Successfully generated clipboard response");
        return response;
    }
}