# Legacy Analysis: AyudaImportacionCartola

## 📄 Información del Formulario VB6

**Archivo VB6:** `old/Contabilidad70/HyperContabilidad/FrmHelpImpCartola.frm`
**Fecha Análisis:** 2025-10-03
**Analista:** AI Assistant
**Complejidad:** Baja

### Propósito del Formulario
Este formulario es una ventana de ayuda estática que muestra el formato requerido para importar cartolas bancarias al sistema. Funciona como documentación interactiva donde el usuario puede ver los campos necesarios y sus formatos, además de poder copiar la información a Excel.

---

## 🎨 CONTROLES UI IDENTIFICADOS

### Frame (Contenedor de Botones)
| Control VB6 | Propósito | Ubicación |
|-------------|-----------|-----------|
| Frame1 | Contenedor de botones de acción | Top = 0, Width = 9255, Height = 615 |

### Botones de Acción
| Botón VB6 | Caption | Habilitado Si | Acción | Mapeo .NET |
|-----------|---------|---------------|--------|------------|
| Bt_CopyExcel | (Sin texto, solo icono) | Siempre | Copia contenido de la grilla al clipboard para Excel | CopyToClipboardAsync() |
| Bt_Close | "Cerrar" | Siempre | Cierra el formulario | N/A (navegación) |

### MSFlexGrid (Grilla de Información)
| Control VB6 | Fuente Datos | Columnas | Eventos | Acciones |
|-------------|--------------|----------|---------|----------|
| Grid | Datos estáticos hardcodeados | 2 cols: "Campo de Información", "Formato" | KeyDown | KeyDown → Ctrl+C = CopyExcel |

**Configuración de la Grilla:**
- **Filas fijas**: 1 (header)
- **Columnas fijas**: 0
- **Ancho columna 0**: 2400 (Campo de Información)
- **Ancho columna 1**: 6200 (Formato)
- **AllowUserResizing**: 1 (permite redimensionar)

**Contenido de la Grilla (Datos Estáticos):**
| Campo de Información | Formato |
|---------------------|---------|
| Fecha | dd/mm/yyyy, por ejemplo: 16/07/2006. |
| Detalle | Texto de descripción. |
| Nro. Doc. | Número del documento, sin puntos. |
| Cargo | Valor numérico. |
| Abono | Valor numérico. |

### Labels Informativos
| Control VB6 | Caption/Texto | Propósito |
|-------------|---------------|-----------|
| Label2 | "Columnas o campos del archivo:" | Título descriptivo de la grilla |
| Label3 | "NOTA:" | Encabezado de nota informativa |
| Label1 | (Texto largo desde .frx) | Nota explicativa adicional |

---

## 🔘 EVENTOS IDENTIFICADOS

### Eventos de Formulario
| Evento VB6 | Cuándo Ocurre | Acciones | Mapeo .NET |
|------------|---------------|----------|------------|
| Form_Load | Al abrir formulario | SetUpGrid(), LoadGrid() | OnPageLoad (JavaScript) |

### Eventos de Botones
| Botón.Evento | Trigger | Acción VB6 | Mapeo .NET |
|--------------|---------|------------|------------|
| Bt_Close_Click | Click en "Cerrar" | Unload Me | window.close() o navegación |
| Bt_CopyExcel_Click | Click en botón copiar | FGr2Clip(Grid, Me.Caption) | copyGridToClipboard() |

### Eventos de Controles
| Control.Evento | Trigger | Acción VB6 | Mapeo .NET |
|----------------|---------|------------|------------|
| Grid_KeyDown | Tecla presionada en grilla | KeyCopy() → Bt_CopyExcel_Click | addEventListener('keydown') → Ctrl+C |

---

## 🔧 FUNCIONES Y PROCEDIMIENTOS VB6

### Procedimientos Privados
```vb
' Procedimiento: Form_Load
' Propósito: Inicializar formulario al cargarse
' Parámetros: Ninguno
' Retorno: Void
' Llamado por: Sistema VB6 al abrir form
' Mapeo .NET: JavaScript onload o DOMContentLoaded
Private Sub Form_Load()
    Call SetUpGrid    ' Configurar estructura de grilla
    Call LoadGrid     ' Cargar datos estáticos
End Sub
```

```vb
' Procedimiento: SetUpGrid
' Propósito: Configurar estructura y encabezados de la grilla
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: setupGrid() en JavaScript
Private Sub SetUpGrid()
    Call FGrSetup(Grid)    ' Función auxiliar para setup básico
    Grid.ColWidth(C_CAMPO) = 2400      ' Ancho columna Campo
    Grid.ColWidth(C_FORMATO) = 6200    ' Ancho columna Formato
    Grid.TextMatrix(0, C_CAMPO) = "Campo de Información"    ' Header col 0
    Grid.TextMatrix(0, C_FORMATO) = "Formato"               ' Header col 1
End Sub
```

```vb
' Procedimiento: LoadGrid
' Propósito: Cargar datos estáticos de ayuda en la grilla
' Parámetros: Ninguno
' Retorno: Void
' Mapeo .NET: loadGridData() en JavaScript
Private Sub LoadGrid()
    Dim Row As Integer
    Grid.rows = Grid.FixedRows    ' Reset a solo header
    Row = 1
    
    ' Agregar filas de datos hardcodeados
    Row = AddGrid("Fecha", "dd/mm/yyyy, por ejemplo: 16/07/2006.", Row)
    Row = AddGrid("Detalle", "Texto de descripción.", Row)
    Row = AddGrid("Nro. Doc.", "Número del documento, sin puntos.", Row)
    Row = AddGrid("Cargo", "Valor numérico.", Row)
    Row = AddGrid("Abono", "Valor numérico.", Row)
    
    Call FGrVRows(Grid)    ' Ajustar filas visibles
End Sub
```

```vb
' Función: AddGrid
' Propósito: Agregar una fila de datos a la grilla
' Parámetros: Campo (String), Formato (String), Row (Integer)
' Retorno: Integer (siguiente número de fila)
' Mapeo .NET: addGridRow() en JavaScript
Private Function AddGrid(Campo As String, Formato As String, Row As Integer) As Integer
    Grid.rows = Row + 1                     ' Agregar nueva fila
    Grid.TextMatrix(Row, C_CAMPO) = Campo   ' Asignar valor columna 0
    Grid.TextMatrix(Row, C_FORMATO) = Formato   ' Asignar valor columna 1
    Row = Row + 1                           ' Incrementar contador
    AddGrid = Row                           ' Retornar siguiente fila
End Function
```

### Funciones Auxiliares (de librerías VB6)
```vb
' Función: FGr2Clip (de PamFGrid.bas)
' Propósito: Copiar contenido de grilla al clipboard
' Parámetros: Grid (Control), Title (String opcional)
' Retorno: Long
' Mapeo .NET: copyTableToClipboard() usando Clipboard API
```

```vb
' Función: KeyCopy (de Pam.bas)
' Propósito: Detectar si se presionó Ctrl+C o Ctrl+Insert
' Parámetros: KeyCode (Integer), Shift (Integer)
' Retorno: Boolean
' Mapeo .NET: detectCopyKeyCombo() en JavaScript
Function KeyCopy(ByVal KeyCode As Integer, ByVal Shift As Integer) As Integer
   KeyCopy = (Shift = vbCtrlMask And (UCase(Chr(KeyCode)) = "C" Or KeyCode = vbKeyInsert))
End Function
```

### Lista Completa de Funciones
| Función VB6 | Tipo | Propósito | Mapeo .NET Method |
|-------------|------|-----------|-------------------|
| Form_Load() | Private Sub | Inicializar form | initializePageAsync() |
| SetUpGrid() | Private Sub | Configurar grilla | setupGrid() |
| LoadGrid() | Private Sub | Cargar datos estáticos | loadGridData() |
| AddGrid() | Private Function→Integer | Agregar fila a grilla | addGridRow() |
| Bt_Close_Click() | Private Sub | Cerrar formulario | closeWindow() |
| Bt_CopyExcel_Click() | Private Sub | Copiar a clipboard | copyToClipboardAsync() |
| Grid_KeyDown() | Private Sub | Manejar teclas en grilla | handleGridKeyDown() |

---

## 💾 ACCESO A DATOS VB6

**IMPORTANTE: Este formulario NO accede a base de datos**

Este formulario es completamente estático y no realiza consultas SQL ni accede a ninguna tabla. Toda la información se presenta hardcodeada como ayuda al usuario.

**Datos Estáticos Presentados:**
- Lista de campos requeridos para importación de cartolas
- Formato específico de cada campo
- Ejemplos de formato de fecha

**Mapeo Entity Framework:** N/A - No hay acceso a datos

---

## ✅ VALIDACIONES Y REGLAS DE NEGOCIO

**IMPORTANTE: Este formulario NO tiene validaciones**

Al ser un formulario de ayuda estático, no tiene:
- Validaciones de campos (no hay campos editables)
- Reglas de negocio (no hay lógica de negocio)
- Validaciones de entrada (es solo lectura)

**Única "validación":** Verificar que el clipboard tenga permisos para escritura al copiar

---

## 🧮 CÁLCULOS Y FÓRMULAS

**IMPORTANTE: Este formulario NO realiza cálculos**

No hay fórmulas matemáticas, algoritmos de cálculo, ni procesamientos numéricos.

**Única lógica de procesamiento:**
- Formateo del contenido de la grilla para clipboard (conversión tabla → texto)

---

## 🚀 NAVEGACIÓN Y FLUJO

### Formularios Llamados
**IMPORTANTE: Este formulario NO llama otros formularios**

| Desde VB6 | Formulario Destino | Parámetros | Retorno | Mapeo .NET |
|-----------|-------------------|------------|---------|------------|
| N/A | N/A | N/A | N/A | N/A |

### Flujo de Estados del Form
```
[Inicio] → Form_Load() → SetUpGrid() → LoadGrid() → [Estado: Mostrando Ayuda]
  ↓
[Bt_Close] → Unload Me → [Formulario Cerrado]
  ↓
[Bt_CopyExcel] → FGr2Clip() → [Datos en Clipboard] → [Estado: Mostrando Ayuda]
  ↓
[Grid KeyDown Ctrl+C] → Bt_CopyExcel_Click → [Datos en Clipboard] → [Estado: Mostrando Ayuda]
```

**Estados del formulario:**
1. **Mostrando Ayuda**: Estado principal y único, muestra información estática
2. **Cerrado**: Formulario se cierra, termina la sesión

---

## 📊 EXPORTACIONES E IMPORTACIONES

### Exportación a Clipboard
```vb
' Función: Bt_CopyExcel_Click / FGr2Clip
' Formato: Texto tabulado para Excel
' Incluye: Headers + todas las filas de datos
' Separador: Tab (\t) entre columnas, salto línea (\n) entre filas
```

**Formato de salida esperado:**
```
Campo de Información	Formato
Fecha	dd/mm/yyyy, por ejemplo: 16/07/2006.
Detalle	Texto de descripción.
Nro. Doc.	Número del documento, sin puntos.
Cargo	Valor numérico.
Abono	Valor numérico.
```

**→ Implementar:** `copyTableToClipboardAsync()` usando Clipboard API

### Sin Importaciones
Este formulario no tiene funcionalidades de importación.

---

## 🎯 MAPEO FINAL: MÉTODOS .NET DETERMINADOS

### Interfaz del Servicio (Minimal - Solo para consistencia)
```csharp
public interface IAyudaImportacionCartolaService
{
    // Método para obtener datos estáticos de ayuda
    Task<IEnumerable<CampoFormatoDto>> GetCamposFormatoAsync();
}
```

### DTOs Necesarios
```csharp
public class CampoFormatoDto
{
    public string Campo { get; set; } = string.Empty;
    public string Formato { get; set; } = string.Empty;
}

public class AyudaImportacionCartolaDto
{
    public string Titulo { get; set; } = "Formato Importación Cartolas Bancarias";
    public string Instrucciones { get; set; } = "Columnas o campos del archivo:";
    public string Nota { get; set; } = "NOTA:";
    public string DetalleNota { get; set; } = string.Empty; // Texto del Label1
    public IEnumerable<CampoFormatoDto> Campos { get; set; } = new List<CampoFormatoDto>();
}
```

### Métodos del Controlador API
```csharp
[HttpGet]
public async Task<ActionResult<AyudaImportacionCartolaDto>> GetAyudaImportacion()
{
    var ayuda = await _service.GetAyudaImportacionAsync();
    return Ok(ayuda);
}

[HttpPost("copy-to-clipboard")]
public async Task<ActionResult<string>> GetClipboardData()
{
    var clipboardText = await _service.GenerateClipboardTextAsync();
    return Ok(new { clipboardText });
}
```

### Resumen de Mapeo
| Funcionalidad VB6 | Método .NET | Complejidad | Prioridad |
|-------------------|-------------|-------------|-----------|
| Form_Load → SetUpGrid + LoadGrid | GetAyudaImportacionAsync() | Baja | Alta |
| Bt_CopyExcel → FGr2Clip | GenerateClipboardTextAsync() | Baja | Media |
| Grid_KeyDown → KeyCopy | JavaScript keydown event | Baja | Media |
| Bt_Close → Unload | JavaScript window close/navigation | Baja | Alta |
| Mostrar datos estáticos | GetCamposFormatoAsync() | Baja | Alta |

---

## ⚠️ NOTAS IMPORTANTES Y OBSERVACIONES

### Peculiaridades del Form VB6
- **Formulario modal**: BorderStyle = 3 (Fixed Dialog), no redimensionable
- **Sin base de datos**: Todos los datos son estáticos hardcodeados
- **Funcionalidad mínima**: Solo mostrar información y copiar a clipboard
- **Icono personalizado**: Usa "FrmHelpImpCartola.frx":0000 (archivo de recursos)
- **Centrado en pantalla**: StartUpPosition = 2 (CenterScreen)
- **Sin botones min/max**: MaxButton = 0, MinButton = 0
- **No en taskbar**: ShowInTaskbar = 0

### Decisiones de Diseño
- **Sin acceso a BD**: Mantener datos estáticos en el servicio, no usar tablas
- **Clipboard moderno**: Usar Clipboard API de navegadores modernos
- **Responsive**: Hacer la tabla responsive para móviles
- **Modal o página**: Implementar como modal popup para mantener comportamiento original

### Limitaciones VB6 vs .NET
- **Clipboard automático**: VB6 podía escribir directo al clipboard, en web necesita interacción del usuario
- **Modal nativo**: VB6 tenía modales nativas, en web usar overlays/modals CSS
- **MSFlexGrid**: Reemplazar con tabla HTML estilizada con Tailwind

### Funcionalidades Específicas a Migrar
1. **✅ MIGRAR**: Mostrar tabla de campos y formatos
2. **✅ MIGRAR**: Botón "Cerrar" que cierre la ventana/modal
3. **✅ MIGRAR**: Funcionalidad de copiar tabla al clipboard
4. **✅ MIGRAR**: Atajo de teclado Ctrl+C para copiar
5. **✅ MIGRAR**: Título "Formato Importación Cartolas Bancarias"
6. **✅ MIGRAR**: Texto explicativo "Columnas o campos del archivo:"
7. **✅ MIGRAR**: Sección "NOTA:" con información adicional

### Componentes VB6 que NO se migran
- **Icono del formulario**: No crítico para funcionalidad web
- **Posicionamiento exacto**: Web usa layouts responsivos
- **MSFlexGrid específico**: Usar tabla HTML moderna

---

## ✅ CHECKLIST DE COMPLETITUD DEL ANÁLISIS

- [x] Todos los controles UI documentados
- [x] Todos los botones y eventos mapeados
- [x] **TODOS los botones tienen "Mapeo .NET" definido** (Bt_Close → navegación, Bt_CopyExcel → función)
- [x] **Botones completamente funcionales** (ambos se implementarán completamente)
- [x] Todas las funciones VB6 identificadas
- [x] **No hay acceso a datos** - formulario estático documentado
- [x] **No hay validaciones** - formulario de solo lectura documentado
- [x] **No hay reglas de negocio** - formulario de ayuda documentado
- [x] **No hay cálculos** - formulario estático documentado
- [x] Navegación y flujos mapeados (minimal: mostrar → cerrar)
- [x] Métodos .NET determinados (minimal service para datos estáticos)
- [x] Interface del Service definida
- [x] **No hay excepciones** - toda funcionalidad VB6 es migrable a web

---

**✅ ANÁLISIS COMPLETO - LISTO PARA IMPLEMENTACIÓN**

**Resumen Ejecutivo:**
- **Complejidad**: BAJA - Formulario estático de ayuda
- **Funcionalidades**: 2 botones, 1 tabla estática, 1 función de clipboard
- **Datos**: Completamente estáticos, sin base de datos
- **Migración**: 100% factible, sin limitaciones técnicas
- **Prioridad**: Media - Es funcionalidad de ayuda/documentación