using Microsoft.AspNetCore.Mvc;

namespace App.Features.CapitalSimpleAcumulado;

[ApiController]
[Route("[controller]/[action]")]
public class CapitalSimpleAcumuladoApiController(
    ICapitalSimpleAcumuladoService service,
    ILogger<CapitalSimpleAcumuladoApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<CapitalSimpleAcumuladoResponseDto>> Obtener(
        [FromQuery] int empresaId,
        [FromQuery] int anoActual,
        [FromQuery] byte tipoDetCPS)
    {
        logger.LogInformation("API: Obtener valores anuales");

        {
            var datos = await service.ObtenerValoresAnualesAsync(empresaId, anoActual, tipoDetCPS);
            return Ok(datos);
        }
    }

    [HttpPost]
    public async Task<IActionResult> Guardar([FromBody] CapitalSimpleAcumuladoRequestDto request)
    {
        logger.LogInformation("API: Guardar valores anuales");

        {
            await service.GuardarValoresAnualesAsync(request.EmpresaId, request.TipoDetCPS, request.Valores);
            return Ok(new { message = "Datos guardados exitosamente" });
        }
    }
}

