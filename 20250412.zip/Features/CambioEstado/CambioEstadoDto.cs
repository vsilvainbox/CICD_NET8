using System.ComponentModel.DataAnnotations;

namespace App.Features.CambioEstado;

/// <summary>
/// DTO para el formulario de cambio de estado (Vista)
/// </summary>
public class CambioEstadoFormDto
{
    [Required(ErrorMessage = "Debe ingresar al menos un ID de comprobante")]
    [Display(Name = "IDs de Comprobantes")]
    public string IdComprobantes { get; set; } = string.Empty;

    [Required(ErrorMessage = "Debe seleccionar un estado")]
    [Range(1, 3, ErrorMessage = "El estado debe ser 1 (Aprobado), 2 (Pendiente) o 3 (Anulado)")]
    [Display(Name = "Nuevo Estado")]
    public byte NuevoEstado { get; set; } = 2; // Pendiente por defecto
}

/// <summary>
/// DTO para la petición a la API
/// </summary>
public class CambioEstadoRequestDto
{
    [Required]
    public int EmpresaId { get; set; }

    [Required]
    public short Ano { get; set; }

    [Required]
    public List<int> IdComprobantes { get; set; } = new();

    [Required]
    [Range(1, 3)] // 1=Aprobado, 2=Pendiente, 3=Anulado
    public byte NuevoEstado { get; set; }
}

public class CambioEstadoResponseDto
{
    public int ComprobantesActualizados { get; set; }
}