using Microsoft.AspNetCore.Mvc;

namespace App.Features.CambioEstado;

[ApiController]
[Route("[controller]/[action]")]
public class CambioEstadoApiController(ICambioEstadoService service) : ControllerBase
{
    [HttpPost]
    public async Task<ActionResult<CambioEstadoResponseDto>> CambiarEstado([FromBody] CambioEstadoRequestDto request, CancellationToken cancellationToken = default)
    {
        var resultado = await service.CambiarEstadoAsync(request, cancellationToken);
        return Ok(resultado);
    }
}