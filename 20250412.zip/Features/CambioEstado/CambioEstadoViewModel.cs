using System.ComponentModel.DataAnnotations;

namespace App.Features.CambioEstado;

/// <summary>
/// ViewModel tipado para la vista Index de CambioEstado
/// Contiene tanto el formulario como los datos de contexto (empresa, año, permisos)
/// </summary>
public class CambioEstadoViewModel
{
    /// <summary>
    /// ID de la empresa actual de la sesión
    /// </summary>
    public int EmpresaId { get; set; }

    /// <summary>
    /// Año contable actual de la sesión
    /// </summary>
    public short Ano { get; set; }

    /// <summary>
    /// Indica si el usuario tiene permiso PRV_ADM_COMP para administrar comprobantes
    /// </summary>
    public bool HasAdmCompPermission { get; set; }

    /// <summary>
    /// IDs de comprobantes ingresados por el usuario (textarea)
    /// </summary>
    [Required(ErrorMessage = "Debe ingresar al menos un ID de comprobante")]
    [Display(Name = "IDs de Comprobantes")]
    public string IdComprobantes { get; set; } = string.Empty;

    /// <summary>
    /// Nuevo estado a asignar a los comprobantes
    /// 1 = Aprobado, 2 = Pendiente, 3 = Anulado
    /// </summary>
    [Required(ErrorMessage = "Debe seleccionar un estado")]
    [Range(1, 3, ErrorMessage = "El estado debe ser 1 (Aprobado), 2 (Pendiente) o 3 (Anulado)")]
    [Display(Name = "Nuevo Estado")]
    public byte NuevoEstado { get; set; } = 2; // Pendiente por defecto
}
