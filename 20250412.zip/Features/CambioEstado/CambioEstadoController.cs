using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.CambioEstado;

public class CambioEstadoController(
    IHttpClientFactory httpClientFactory,
    ILogger<CambioEstadoController> logger,
    LinkGenerator linkGenerator) : Controller
{
    [HttpGet]
    public IActionResult Index([FromQuery] string? ids = null)
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Cambio de Estado";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        // Verificar permiso PRV_ADM_COMP para cambiar estado de comprobantes
        var hasAdmCompPermission = SessionHelper.HasPrivilege(SessionHelper.Privileges.PRV_ADM_COMP);

        // Crear ViewModel tipado con todos los datos necesarios para la vista
        var model = new CambioEstadoViewModel
        {
            EmpresaId = SessionHelper.EmpresaId,
            Ano = SessionHelper.Ano,
            HasAdmCompPermission = hasAdmCompPermission,
            IdComprobantes = ids ?? string.Empty,
            NuevoEstado = 2 // Pendiente por defecto
        };

        return View(model);
    }

    /// <summary>
    /// Método que recibe el formulario con Tag Helpers
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Index(CambioEstadoViewModel viewModel)
    {
        // Verificar permiso antes de permitir cambio
        if (!SessionHelper.HasPrivilege(SessionHelper.Privileges.PRV_ADM_COMP))
        {
            logger.LogWarning("User attempted to change voucher status without permission");
            ModelState.AddModelError(string.Empty, "No tiene permisos para cambiar el estado de comprobantes. Requiere permiso: Administrar Comprobantes");

            // Repoblar datos de contexto en el ViewModel
            viewModel.EmpresaId = SessionHelper.EmpresaId;
            viewModel.Ano = SessionHelper.Ano;
            viewModel.HasAdmCompPermission = false;
            return View(viewModel);
        }

        if (!ModelState.IsValid)
        {
            // Repoblar datos de contexto en el ViewModel
            viewModel.EmpresaId = SessionHelper.EmpresaId;
            viewModel.Ano = SessionHelper.Ano;
            viewModel.HasAdmCompPermission = true;
            return View(viewModel);
        }

        // Parsear IDs del textarea
        var ids = ParsearIds(viewModel.IdComprobantes);
        if (ids.Count == 0)
        {
            ModelState.AddModelError(nameof(viewModel.IdComprobantes), "Debe ingresar al menos un ID de comprobante válido");

            // Repoblar datos de contexto en el ViewModel
            viewModel.EmpresaId = SessionHelper.EmpresaId;
            viewModel.Ano = SessionHelper.Ano;
            viewModel.HasAdmCompPermission = true;
            return View(viewModel);
        }

        // Crear request para la API
        var request = new CambioEstadoRequestDto
        {
            EmpresaId = SessionHelper.EmpresaId,
            Ano = SessionHelper.Ano,
            IdComprobantes = ids,
            NuevoEstado = viewModel.NuevoEstado
        };

        logger.LogInformation("MVC: CambiarEstado called with {Count} vouchers", ids.Count);

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<CambioEstadoApiController>(
            HttpContext,
            nameof(CambioEstadoApiController.CambiarEstado));

        var (statusCode, content) = await client.ProxyRequestAsync(
            url!,
            JsonSerializer.SerializeToElement(request),
            HttpMethod.Post);

        logger.LogInformation("MVC: API response status {StatusCode}", statusCode);

        if (statusCode == 200)
        {
            var response = JsonSerializer.Deserialize<CambioEstadoResponseDto>(content);
            TempData["SwalSuccess"] = $"Se cambió el estado de {response?.ComprobantesActualizados ?? 0} comprobante(s) exitosamente";
            return RedirectToAction(nameof(Index));
        }
        else
        {
            ModelState.AddModelError(string.Empty, "Error al comunicarse con la API");
        }

        // Repoblar datos de contexto en el ViewModel
        viewModel.EmpresaId = SessionHelper.EmpresaId;
        viewModel.Ano = SessionHelper.Ano;
        viewModel.HasAdmCompPermission = true;
        return View(viewModel);
    }

    /// <summary>
    /// Método proxy para cambiar estado de comprobantes (Vista → MVC → API)
    /// VB6: No verifica permisos, pero debería verificar PRV_ADM_COMP
    /// Mantener para compatibilidad con JavaScript si se necesita
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> CambiarEstado([FromBody] JsonElement request)
    {
        logger.LogInformation("MVC Proxy: CambiarEstado called");

        // Verificar permiso antes de permitir cambio
        if (!SessionHelper.HasPrivilege(SessionHelper.Privileges.PRV_ADM_COMP))
        {
            logger.LogWarning("User attempted to change voucher status without permission");
            return Json(new
            {
                swalType = "warning",
                swalTitle = "Atención",
                errors = new[] { "No tiene permisos para cambiar el estado de comprobantes. Requiere permiso: Administrar Comprobantes" }
            });
        }

        var client = httpClientFactory.CreateClient();
        var url = linkGenerator.GetApiUrl<CambioEstadoApiController>(
            HttpContext,
            nameof(CambioEstadoApiController.CambiarEstado));
        var (statusCode, content) = await client.ProxyRequestAsync(
            url!,
            request,
            HttpMethod.Post);

        logger.LogInformation("MVC Proxy: API response status {StatusCode}", statusCode);

        return StatusCode(statusCode, content);
    }

    /// <summary>
    /// Parsea IDs del textarea (separados por coma o línea nueva)
    /// </summary>
    private static List<int> ParsearIds(string texto)
    {
        if (string.IsNullOrWhiteSpace(texto)) return new List<int>();

        return texto.Split(new[] { '\n', ',' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(s => s.Trim())
            .Where(s => int.TryParse(s, out _))
            .Select(int.Parse)
            .ToList();
    }
}
