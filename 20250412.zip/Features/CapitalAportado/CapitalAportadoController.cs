using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.CapitalAportado;

public class CapitalAportadoController(
    ILogger<CapitalAportadoController> logger,
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator) : Controller
{
    public IActionResult Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Capital Aportado";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        logger.LogInformation("CapitalAportado index accessed");

        var viewModel = new CapitalAportadoIndexViewModel
        {
            EmpresaId = SessionHelper.EmpresaId,
            Ano = SessionHelper.Ano
        };

        return View(viewModel);
    }

    [HttpGet]
    public async Task<IActionResult> GetData(int empresaId, short ano)
    {
        logger.LogInformation("GetData called with empresaId: {EmpresaId}, ano: {Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<CapitalAportadoApiController>(
                HttpContext,
                nameof(CapitalAportadoApiController.Get),
                new { empresaId, ano }
            );
            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    [HttpPost]
    public async Task<IActionResult> Save([FromBody] JsonElement request)
    {
        logger.LogInformation("Save called");

        {
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<CapitalAportadoApiController>(
                HttpContext,
                nameof(CapitalAportadoApiController.Save)
            );
            var (statusCode, content) = await client.ProxyRequestAsync(
                url!,
                request!,
                HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }
}