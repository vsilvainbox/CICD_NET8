using Microsoft.AspNetCore.Mvc;

namespace App.Features.CompraVenta;

[ApiController]
[Route("[controller]/[action]")]
public class CompraVentaApiController(
    ICompraVentaService service,
    ILogger<CompraVentaApiController> logger) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IEnumerable<CompraVentaDto>>> GetAll(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        [FromQuery] byte? tipoLib = null,
        [FromQuery] int? mes = null)
    {
        logger.LogInformation("API: GetAll called with empresaId: {EmpresaId}, año: {Ano}, tipoLib: {TipoLib}, mes: {Mes}",
            empresaId, ano, tipoLib, mes);

        var documentos = await service.GetAllAsync(empresaId, ano, tipoLib, mes);
        logger.LogInformation("API: Returning {Count} documents", documentos.Count());
        return Ok(documentos);
    }

    [HttpGet]
    public async Task<ActionResult<CompraVentaDto>> GetById(int id)
    {
        logger.LogInformation("API: GetById called with id: {Id}", id);

        var documento = await service.GetByIdAsync(id);
        return Ok(documento);
    }

    [HttpPost]
    public async Task<ActionResult<CompraVentaDto>> Create([FromBody] CompraVentaCreateDto dto)
    {
        logger.LogInformation("API: Create called for empresaId: {EmpresaId}, tipoDoc: {TipoDoc}",
            dto.IdEmpresa, dto.TipoDoc);

        var result = await service.CreateAsync(dto);

        return Ok(result);
    }

    [HttpPut]
    public async Task<ActionResult<CompraVentaDto>> Update(int id, [FromBody] CompraVentaUpdateDto dto)
    {
        logger.LogInformation("API: Update called for id: {Id}", id);

        dto.IdDoc = id;
        var result = await service.UpdateAsync(dto);
        logger.LogInformation("API: Document {Id} updated successfully", id);
        return Ok(result);
    }

    [HttpDelete]
    public async Task<ActionResult<bool>> Delete(int id)
    {
        logger.LogInformation("API: Delete called for id: {Id}", id);

        var result = await service.DeleteAsync(id);
        logger.LogInformation("API: Document {Id} deleted successfully", id);
        return Ok(new { success = result, message = "Documento eliminado exitosamente" });
    }

    [HttpGet]
    public ActionResult<IEnumerable<TipoDocumentoInfo>> GetTiposDocumento()
    {
        logger.LogInformation("API: GetTiposDocumento called");

        var tipos = service.GetTiposDocumento();
        return Ok(tipos);
    }

    [HttpPost]
    public Task<IActionResult> Centralizar(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        [FromQuery] byte tipoLib,
        [FromQuery] int mes)
    {
        logger.LogInformation("API: Centralizar called - empresaId: {EmpresaId}, ano: {Ano}, tipoLib: {TipoLib}, mes: {Mes}",
            empresaId, ano, tipoLib, mes);

        // TODO: Implement centralization functionality
        return Task.FromResult<IActionResult>(StatusCode(501, new { swalType = "warning", swalTitle = "Atención", errors = new[] { "Funcionalidad de centralización no implementada aún" } }));
    }

    [HttpGet]
    public async Task<IActionResult> Exportar(
        [FromQuery] int empresaId,
        [FromQuery] short ano,
        [FromQuery] byte tipoLib,
        [FromQuery] int mes)
    {
        logger.LogInformation(
            "API: Exportar called - empresaId: {EmpresaId}, ano: {Ano}, tipoLib: {TipoLib}, mes: {Mes}",
            empresaId, ano, tipoLib, mes);

        var (excelBytes, fileName) = await service.ExportToExcelAsync(empresaId, ano, tipoLib, mes);

        logger.LogInformation("API: Excel generado exitosamente - {FileName}", fileName);
        return File(excelBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
    }
}
