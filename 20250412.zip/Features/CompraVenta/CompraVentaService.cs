﻿using Microsoft.EntityFrameworkCore;
using App.Data;
using App.Exceptions;

namespace App.Features.CompraVenta;

/// <summary>
/// Interface del servicio para gestión de libros de compra/venta
/// Basado en FrmCompraVenta.frm (10,066 líneas VB6)
/// Nota: FrmCompraVenta es realmente un LIBRO DE COMPRAS/VENTAS completo,
/// no una simple gestión de documentos individuales
/// </summary>
public interface ICompraVentaService
{
    /// <summary>
    /// Obtiene todos los documentos del libro de compras/ventas
    /// Mapea LoadGrid() del VB6
    /// </summary>
    Task<IEnumerable<CompraVentaDto>> GetAllAsync(int empresaId, short ano, byte? tipoLib = null, int? mes = null, byte? tipoDoc = null, short? estado = null);

    /// <summary>
    /// Obtiene un documento por ID
    /// </summary>
    Task<CompraVentaDto> GetByIdAsync(int id);

    /// <summary>
    /// Obtiene los tipos de documento disponibles
    /// Mapea FillCombo de tipos de documento
    /// </summary>
    Task<IEnumerable<TipoDocumentoInfo>> GetTiposDocumentoAsync(short? tipoLib = null);

    /// <summary>
    /// Obtiene listado de meses con movimientos
    /// Mapea FillMes() del VB6
    /// </summary>
    Task<IEnumerable<MesInfo>> GetMesesConMovimientosAsync(int empresaId, short ano, byte? tipoLib = null);
    
    /// <summary>
    /// Crea un nuevo documento
    /// </summary>
    Task<CompraVentaDto> CreateAsync(CompraVentaCreateDto dto);
    
    /// <summary>
    /// Actualiza un documento existente
    /// </summary>
    Task<CompraVentaDto> UpdateAsync(CompraVentaUpdateDto dto);
    
    /// <summary>
    /// Elimina un documento
    /// </summary>
    Task<bool> DeleteAsync(int id);
    
    /// <summary>
    /// Obtiene tipos de documento sin filtro (para compatibility)
    /// </summary>
    List<TipoDocumentoInfo> GetTiposDocumento();
    
    /// <summary>
    /// Exporta los documentos a Excel
    /// </summary>
    Task<(byte[] FileBytes, string FileName)> ExportToExcelAsync(int empresaId, short ano, byte tipoLib, int mes);
}

public class CompraVentaService(LpContabContext context, ILogger<CompraVentaService> logger) : ICompraVentaService
{
    // Constantes de TipoLib según VB6 (HyperComun.bas)
    private const short LIB_COMPRAS = 1;
    private const short LIB_VENTAS = 2;

    /// <summary>
    /// Obtiene documentos del libro de compras/ventas con filtros
    /// Mapea LoadGrid() de FrmCompraVenta.frm
    /// </summary>
    public async Task<IEnumerable<CompraVentaDto>> GetAllAsync(int empresaId, short ano, byte? tipoLib = null, int? mes = null, byte? tipoDoc = null, short? estado = null)
    {
        logger.LogInformation("Getting documentos for empresaId: {EmpresaId}, año: {Ano}, tipoLib: {TipoLib}, mes: {Mes}, tipoDoc: {TipoDoc}, estado: {Estado}",
            empresaId, ano, tipoLib, mes, tipoDoc, estado);

        {
            var query = context.Documento
                .Where(d => d.IdEmpresa == empresaId && d.Ano == ano);

            // Filtro por tipo de libro (Compras/Ventas)
            if (tipoLib.HasValue)
            {
                query = query.Where(d => d.TipoLib == tipoLib);
            }

            // Filtro por mes basándose en FEmision (formato OLE/Excel)
            if (mes.HasValue && mes.Value > 0)
            {
                query = query.Where(d => d.FEmision.HasValue &&
                    DateTime.FromOADate(d.FEmision.Value).Month == mes.Value);
            }

            // Filtro por tipo de documento
            if (tipoDoc.HasValue)
            {
                query = query.Where(d => d.TipoDoc == tipoDoc);
            }

            // Filtro por estado
            if (estado.HasValue)
            {
                query = query.Where(d => d.Estado == estado);
            }
            
            // First, get the raw data from database
            var documentosRaw = await query
                .OrderBy(d => d.FEmision)
                .ThenBy(d => d.NumDoc)
                .Select(d => new 
                {
                    d.IdDoc,
                    d.IdEmpresa,
                    d.Ano,
                    d.TipoLib,
                    d.TipoDoc,
                    d.NumDoc,
                    d.IdEntidad,
                    d.RutEntidad,
                    d.NombreEntidad,
                    d.FEmision,
                    d.FVenc,
                    d.Descrip,
                    d.Estado,
                    d.Exento,
                    d.Afecto,
                    d.IVA,
                    d.OtroImp,
                    d.Total
                })
                .ToListAsync();
            
            // Then, convert to DTOs with formatting (in-memory)
            var documentos = documentosRaw.Select(d => new CompraVentaDto
            {
                IdDoc = d.IdDoc,
                IdEmpresa = d.IdEmpresa,
                Ano = d.Ano,
                TipoLib = d.TipoLib,
                TipoDoc = d.TipoDoc,
                NumDoc = d.NumDoc,
                IdEntidad = d.IdEntidad,
                RutEntidad = d.RutEntidad,
                NombreEntidad = d.NombreEntidad,
                RazonSocial = d.NombreEntidad,  // Alias para JavaScript
                FEmision =  d.FEmision,
                FVenc =  d.FVenc,
                Descrip = d.Descrip,
                Estado = d.Estado,
                Exento = d.Exento,
                Afecto = d.Afecto,
                IVA =  d.IVA,
                OtroImp = d.OtroImp,
                Total = d.Total,
                // Formateo para UI (done in-memory after database query)
                FechaEmisionTexto = d.FEmision.HasValue ? ConvertirFechaVB6(d.FEmision.Value) : "",
                TotalTexto = d.Total.HasValue ? FormatearMoneda(d.Total.Value) : "",
                TipoDocNombre = "", // Se completará desde TipoDocs si es necesario
                FEmisionDate = d.FEmision.HasValue ? ConvertirFechaVB6ToDateTime(d.FEmision.Value) : null
            }).ToList();
            
            logger.LogInformation("Found {Count} documentos", documentos.Count);
            return documentos;
        }
    }

    public async Task<CompraVentaDto> GetByIdAsync(int id)
    {
        logger.LogInformation("Getting documento by id: {Id}", id);
        
        {
            var documento = await context.Documento.FindAsync(id);
            if (documento == null)
            {
                logger.LogWarning("Documento {Id} not found", id);
                throw new BusinessException($"Documento con ID {id} no encontrado");
            }
            
            return new CompraVentaDto
            {
                IdDoc = documento.IdDoc,
                IdEmpresa = documento.IdEmpresa,
                Ano = documento.Ano,
                TipoLib = documento.TipoLib,
                TipoDoc = documento.TipoDoc,
                NumDoc = documento.NumDoc,
                IdEntidad = documento.IdEntidad,
                RutEntidad = documento.RutEntidad,
                NombreEntidad = documento.NombreEntidad,
                FEmision =  documento.FEmision,
                FVenc =  documento.FVenc,
                Descrip = documento.Descrip,
                Estado = documento.Estado,
                Exento = documento.Exento,
                Afecto = documento.Afecto,
                IVA =  documento.IVA,
                OtroImp = documento.OtroImp,
                Total = documento.Total,
                FechaEmisionTexto = documento.FEmision.HasValue ? ConvertirFechaVB6(documento.FEmision.Value) : "",
                TotalTexto = documento.Total.HasValue ? FormatearMoneda(documento.Total.Value) : ""
            };
        }
    }

    public async Task<IEnumerable<TipoDocumentoInfo>> GetTiposDocumentoAsync(short? tipoLib = null)
    {
        logger.LogInformation("Getting tipos de documento for tipoLib: {TipoLib}", tipoLib);

        {
            var query = context.TipoDocs.AsQueryable();

            if (tipoLib.HasValue)
            {
                query = query.Where(t => t.TipoLib == tipoLib);
            }

            var tipos = await query
                .OrderBy(t => t.TipoLib)
                .ThenBy(t => t.TipoDoc)
                .Select(t => new TipoDocumentoInfo
                {
                    Codigo = t.TipoDoc,
                    Nombre = t.Nombre ?? "",  // TipoDocs usa 'Nombre' no 'Descrip'
                    TipoLibro = t.TipoLib == LIB_COMPRAS ? "Compra" : "Venta",
                    TipoLib = t.TipoLib
                })
                .ToListAsync();

            return tipos;
        }
    }

    public async Task<IEnumerable<MesInfo>> GetMesesConMovimientosAsync(int empresaId, short ano, byte? tipoLib = null)
    {
        logger.LogInformation("Getting meses con movimientos for empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        {
            var query = context.Documento
                .Where(d => d.IdEmpresa == empresaId
                    && d.Ano == ano
                    && d.FEmision.HasValue
                    && DateTime.FromOADate(d.FEmision.Value).Year == ano);  // Year(FEmision) = ano

            if (tipoLib.HasValue)
            {
                query = query.Where(d => d.TipoLib == tipoLib);
            }

            // First, get distinct months from database
            var mesesNumeros = await query
                .Select(d => new { Mes = DateTime.FromOADate(d.FEmision!.Value).Month })
                .Distinct()
                .OrderBy(m => m.Mes)
                .Select(m => m.Mes)
                .ToListAsync();
            
            // Then, convert to MesInfo with names (in-memory)
            var meses = mesesNumeros.Select(mes => new MesInfo
            {
                NumeroMes = mes,
                NombreMes = ObtenerNombreMes(mes)
            }).ToList();
            
            return meses;
        }
    }

    /// <summary>
    /// Convierte fecha en formato OLE/Excel a string legible
    /// Ejemplo: 45000 => "15/03/2023"
    /// </summary>
    private static string ConvertirFechaVB6(int fechaOA)
    {
        {
            var fecha = DateTime.FromOADate(fechaOA);
            return fecha.ToString("dd/MM/yyyy");
        }
    }

    /// <summary>
    /// Convierte fecha en formato OLE/Excel a DateTime
    /// Ejemplo: 45000 => DateTime(2023, 3, 15)
    /// </summary>
    private static DateTime? ConvertirFechaVB6ToDateTime(int fechaOA)
    {
        {
            return DateTime.FromOADate(fechaOA);
        }
    }

    public async Task<CompraVentaDto> CreateAsync(CompraVentaCreateDto dto)
    {
        {
            var documento = new App.Data.Documento
            {
                IdEmpresa = dto.IdEmpresa,
                Ano = dto.Ano,
                TipoLib = dto.TipoLib,
                TipoDoc = dto.TipoDoc,
                NumDoc = dto.NumDoc,
                IdEntidad = dto.IdEntidad,
                RutEntidad = dto.RutEntidad,
                NombreEntidad = dto.NombreEntidad,
                FEmision =  dto.FEmision,
                FVenc =  dto.FVenc,
                Descrip = dto.Descrip,
                Estado = dto.Estado,
                Exento = dto.Exento,
                Afecto = dto.Afecto,
                IVA  =  dto.IVA,
                OtroImp = dto.OtroImp,
                Total = dto.Total
            };
            
            context.Documento.Add(documento);
            await context.SaveChangesAsync();
            
            return await GetByIdAsync(documento.IdDoc) ?? new CompraVentaDto();
        }
    }

    public async Task<CompraVentaDto> UpdateAsync(CompraVentaUpdateDto dto)
    {
        {
            // Validar que el ID esté presente
            if (dto.IdDoc <= 0)
                throw new BusinessException("El ID del documento es requerido para actualizar");

            var documento = await context.Documento.FindAsync(dto.IdDoc);
            if (documento == null)
                throw new BusinessException($"Documento {dto.IdDoc} no encontrado");

            documento.TipoDoc = dto.TipoDoc;
            documento.NumDoc = dto.NumDoc;
            documento.IdEntidad = dto.IdEntidad;
            documento.RutEntidad = dto.RutEntidad;
            documento.NombreEntidad = dto.NombreEntidad;
            documento.FEmision =  dto.FEmision;
            documento.FVenc =  dto.FVenc;
            documento.Descrip = dto.Descrip;
            documento.Estado = dto.Estado;
            documento.Exento = dto.Exento;
            documento.Afecto = dto.Afecto;
            documento.IVA =  dto.IVA;
            documento.OtroImp = dto.OtroImp;
            documento.Total = dto.Total;
            
            await context.SaveChangesAsync();
            
            return await GetByIdAsync(documento.IdDoc) ?? new CompraVentaDto();
        }
    }

    public async Task<bool> DeleteAsync(int id)
    {
        {
            var documento = await context.Documento.FindAsync(id);
            if (documento == null)
                throw new BusinessException($"Documento con ID {id} no encontrado");
            
            context.Documento.Remove(documento);
            await context.SaveChangesAsync();
            
            return true;
        }
    }

    public List<TipoDocumentoInfo> GetTiposDocumento()
    {
        return GetTiposDocumentoAsync(null).GetAwaiter().GetResult().ToList();
    }

    /// <summary>
    /// Formatea valor monetario
    /// </summary>
    private static string FormatearMoneda(double valor)
    {
        return valor.ToString("N0");  // Sin decimales, con separador de miles
    }

    /// <summary>
    /// Obtiene nombre del mes en español
    /// </summary>
    private static string ObtenerNombreMes(int mes)
    {
        var meses = new[] { "", "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
                            "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre" };
        return mes >= 1 && mes <= 12 ? meses[mes] : mes.ToString();
    }

    /// <summary>
    /// Exporta los documentos a Excel
    /// </summary>
    public async Task<(byte[] FileBytes, string FileName)> ExportToExcelAsync(int empresaId, short ano, byte tipoLib, int mes)
    {
        logger.LogInformation("Exportando a Excel: empresaId={EmpresaId}, ano={Ano}, tipoLib={TipoLib}, mes={Mes}",
            empresaId, ano, tipoLib, mes);

        if (tipoLib != LIB_COMPRAS && tipoLib != LIB_VENTAS)
            throw new BusinessException("Tipo de libro inválido. Debe ser 1 (Compras) o 2 (Ventas)");

        if (mes < 1 || mes > 12)
            throw new BusinessException("El mes debe estar entre 1 y 12");

        if (ano < 2000 || ano > DateTime.Now.Year + 1)
            throw new BusinessException($"El año debe estar entre 2000 y {DateTime.Now.Year + 1}");

        // Obtener los documentos
        var documentos = await GetAllAsync(empresaId, ano, tipoLib, mes);

        if (!documentos.Any())
        {
            logger.LogWarning("No hay documentos para exportar");
            throw new BusinessException("No hay documentos para exportar en el período seleccionado");
        }

        // Crear el paquete Excel usando EPPlus
        using var package = new OfficeOpenXml.ExcelPackage();
        var worksheet = package.Workbook.Worksheets.Add($"Libro {(tipoLib == LIB_COMPRAS ? "Compras" : "Ventas")}");

        // Encabezados
        var headers = new[]
        {
            "Tipo Doc", "N° Documento", "Fecha Emisión", "RUT", "Razón Social",
            "Exento", "Afecto", "IVA", "Otro Imp.", "Total", "Estado"
        };

        for (var i = 0; i < headers.Length; i++)
        {
            worksheet.Cells[1, i + 1].Value = headers[i];
            worksheet.Cells[1, i + 1].Style.Font.Bold = true;
            worksheet.Cells[1, i + 1].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
            worksheet.Cells[1, i + 1].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightGray);
        }

        // Datos
        var row = 2;
        foreach (var doc in documentos)
        {
            worksheet.Cells[row, 1].Value = doc.TipoDocNombre;
            worksheet.Cells[row, 2].Value = doc.NumDoc;
            worksheet.Cells[row, 3].Value = doc.FechaEmisionTexto;
            worksheet.Cells[row, 4].Value = doc.RutEntidad;
            worksheet.Cells[row, 5].Value = doc.NombreEntidad;
            worksheet.Cells[row, 6].Value = doc.Exento;
            worksheet.Cells[row, 7].Value = doc.Afecto;
            worksheet.Cells[row, 8].Value = doc.IVA;
            worksheet.Cells[row, 9].Value = doc.OtroImp;
            worksheet.Cells[row, 10].Value = doc.Total;
            worksheet.Cells[row, 11].Value = doc.Estado == 0 ? "Vigente" : "Anulado";
            row++;
        }

        // Formato de moneda para las columnas numéricas
        for (var col = 6; col <= 10; col++)
        {
            worksheet.Column(col).Style.Numberformat.Format = "#,##0";
        }

        // Auto-ajustar columnas
        worksheet.Cells[worksheet.Dimension.Address].AutoFitColumns();

        // Generar nombre de archivo según lógica de negocio
        var fileName = $"LibroCompraVenta_{tipoLib}_{ano}_{mes:D2}.xlsx";

        logger.LogInformation("Excel generado con {Count} registros - {FileName}", documentos.Count(), fileName);
        return (package.GetAsByteArray(), fileName);
    }
}
