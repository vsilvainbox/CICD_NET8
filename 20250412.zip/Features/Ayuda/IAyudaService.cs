namespace App.Features.Ayuda;

/// <summary>
/// Interface para el servicio de sistema de ayuda
/// Proporciona contenido de ayuda estático para diferentes contextos del sistema
/// </summary>
public interface IAyudaService
{
    /// <summary>
    /// Obtiene el contenido de ayuda para ajustes de aumentos (14D3)
    /// </summary>
    /// <param name="contexto">Contexto desde donde se llama la ayuda</param>
    /// <returns>Contenido de ayuda con ejemplos de ajustes de aumentos</returns>
    Task<AyudaContentDto> GetAjustesAumentosAsync(string contexto = "");

    /// <summary>
    /// Obtiene el contenido de ayuda para ajustes de disminuciones (14D8)
    /// </summary>
    /// <param name="contexto">Contexto desde donde se llama la ayuda</param>
    /// <returns>Contenido de ayuda con ejemplos de ajustes de disminuciones</returns>
    Task<AyudaContentDto> GetAjustesDisminucionesAsync(string contexto = "");

    /// <summary>
    /// Obtiene todos los tipos de ayuda disponibles en el sistema
    /// </summary>
    /// <returns>Lista de tipos de ayuda disponibles</returns>
    Task<IEnumerable<AyudaTipoDto>> GetTiposAyudaAsync();

    /// <summary>
    /// Obtiene contenido de ayuda por tipo específico
    /// </summary>
    /// <param name="tipoAyuda">Tipo de ayuda solicitada</param>
    /// <param name="contexto">Contexto desde donde se llama</param>
    /// <returns>Contenido de ayuda correspondiente</returns>
    Task<AyudaContentDto> GetContenidoPorTipoAsync(TipoAyuda tipoAyuda, string contexto = "");

    /// <summary>
    /// Verifica si un tipo de ayuda existe y está disponible
    /// </summary>
    /// <param name="tipo">Código del tipo de ayuda a verificar</param>
    /// <returns>True si el tipo de ayuda existe</returns>
    Task<bool> ExisteTipoAyudaAsync(int tipo);
}