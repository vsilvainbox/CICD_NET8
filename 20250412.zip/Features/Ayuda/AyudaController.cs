using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using App.Extensions;

namespace App.Features.Ayuda;

/// <summary>
/// Controlador MVC para el sistema de ayuda
/// Proporciona vistas para mostrar contenido de ayuda contextual
/// </summary>
[Authorize]

public class AyudaController(
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator,
    ILogger<AyudaController> logger) : Controller
{
    /// <summary>
    /// Vista principal del sistema de ayuda
    /// Muestra índice con todos los tipos de ayuda disponibles
    /// </summary>
    public async Task<IActionResult> Index()
    {
        logger.LogInformation("Loading Ayuda index page");

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AyudaApiController>(
            HttpContext,
            nameof(AyudaApiController.GetTiposAyuda));
        var tiposAyuda = await client.GetFromApiAsync<List<AyudaTipoDto>>(url!);

        logger.LogInformation("Successfully loaded ayuda index with {Count} help types", tiposAyuda?.Count ?? 0);
        return View(tiposAyuda ?? new List<AyudaTipoDto>());
    }

    /// <summary>
    /// Muestra ayuda para ajustes de aumentos
    /// Replica la funcionalidad FViewOtrosAjustesAumentos del VB6
    /// </summary>
    /// <param name="contexto">Contexto desde donde se llama la ayuda</param>
    public async Task<IActionResult> Aumentos(string contexto = "")
    {
        logger.LogInformation("Loading Ajustes Aumentos help for context: {Contexto}", contexto);

        var client = httpClientFactory.CreateClient();

        var values = !string.IsNullOrEmpty(contexto)
            ? new { contexto }
            : null;

        var url = linkGenerator.GetApiUrl<AyudaApiController>(
            HttpContext,
            nameof(AyudaApiController.GetAjustesAumentos),
            values);
        var content = await client.GetFromApiAsync<AyudaContentDto>(url!);

        var viewModel = new AyudaModalViewModel(content, "aumentos", contexto);
        logger.LogInformation("Successfully loaded ajustes aumentos help content");
        return View("Modal", viewModel);
    }

    /// <summary>
    /// Muestra ayuda para ajustes de disminuciones
    /// Replica la funcionalidad FViewOtrosAjustesDismin del VB6
    /// </summary>
    /// <param name="contexto">Contexto desde donde se llama la ayuda</param>
    public async Task<IActionResult> Disminuciones(string contexto = "")
    {
        logger.LogInformation("Loading Ajustes Disminuciones help for context: {Contexto}", contexto);

        var client = httpClientFactory.CreateClient();

        var values = !string.IsNullOrEmpty(contexto)
            ? new { contexto }
            : null;

        var url = linkGenerator.GetApiUrl<AyudaApiController>(
            HttpContext,
            nameof(AyudaApiController.GetAjustesDisminuciones),
            values);
        var content = await client.GetFromApiAsync<AyudaContentDto>(url!);

        var viewModel = new AyudaModalViewModel(content, "disminuciones", contexto);
        logger.LogInformation("Successfully loaded ajustes disminuciones help content");
        return View("Modal", viewModel);
    }

    /// <summary>
    /// Muestra ayuda por tipo específico
    /// </summary>
    /// <param name="tipo">Tipo de ayuda (1=Aumentos, 2=Disminuciones)</param>
    /// <param name="contexto">Contexto desde donde se llama</param>
    public async Task<IActionResult> Tipo(int tipo, string contexto = "")
    {
        logger.LogInformation("Loading help by type: {Tipo}, context: {Contexto}", tipo, contexto);

        // Validar tipo
        if (!Enum.IsDefined(typeof(TipoAyuda), tipo))
        {
            logger.LogWarning("Invalid help type requested: {Tipo}", tipo);
            var errorViewModel = new AyudaModalViewModel(
                null,
                "general",
                contexto,
                $"Tipo de ayuda no válido: {tipo}");
            return View("Modal", errorViewModel);
        }

        var client = httpClientFactory.CreateClient();

        var values = !string.IsNullOrEmpty(contexto)
            ? new { tipo, contexto = (string?)contexto }
            : new { tipo, contexto = (string?)null };

        var url = linkGenerator.GetApiUrl<AyudaApiController>(
            HttpContext,
            nameof(AyudaApiController.GetContenidoPorTipo),
            values);
        var content = await client.GetFromApiAsync<AyudaContentDto>(url!);

        var viewModel = new AyudaModalViewModel(
            content,
            ((TipoAyuda)tipo).ToString().ToLower(),
            contexto);
        logger.LogInformation("Successfully loaded help content for type: {Tipo}", tipo);
        return View("Modal", viewModel);
    }

    /// <summary>
    /// Endpoint para mostrar ayuda en modal via AJAX
    /// </summary>
    /// <param name="tipo">Tipo de ayuda</param>
    /// <param name="contexto">Contexto</param>
    /// <returns>Vista parcial para modal</returns>
    [HttpGet]
    public async Task<IActionResult> ModalPartial(int tipo, string contexto = "")
    {
        logger.LogInformation("Loading modal partial for type: {Tipo}, context: {Contexto}", tipo, contexto);

        var client = httpClientFactory.CreateClient();

        var values = !string.IsNullOrEmpty(contexto)
            ? new { tipo, contexto = (string?)contexto }
            : new { tipo, contexto = (string?)null };

        var url = linkGenerator.GetApiUrl<AyudaApiController>(
            HttpContext,
            nameof(AyudaApiController.GetContenidoPorTipo),
            values);
        var content = await client.GetFromApiAsync<AyudaContentDto>(url!);

        var viewModel = new AyudaModalViewModel(
            content,
            ((TipoAyuda)tipo).ToString().ToLower(),
            contexto);
        return PartialView("_ModalContent", viewModel);
    }
}