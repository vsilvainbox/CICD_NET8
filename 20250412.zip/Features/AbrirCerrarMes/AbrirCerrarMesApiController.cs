using Microsoft.AspNetCore.Mvc;

namespace App.Features.AbrirCerrarMes;

/// <summary>
/// API Controller para gestión de períodos contables (Abrir/Cerrar Mes)
/// Migrado desde VB6 FrmEstadoMeses.frm
/// </summary>
[ApiController]
[Route("[controller]/[action]")]
public class AbrirCerrarMesApiController(IAbrirCerrarMesService service, ILogger<AbrirCerrarMesApiController> logger) : ControllerBase
{
    /// <summary>
    /// Obtiene los estados de todos los meses (1-12) para una empresa y año
    /// GET /api/AbrirCerrarMes/estados?empresaId=1&amp;ano=2024
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<IEnumerable<EstadoMesDto>>> Estados([FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: Estados called with empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        var monthStates = await service.GetMonthStatesAsync(empresaId, ano);
        return Ok(monthStates);
    }

    /// <summary>
    /// Obtiene el último mes con movimientos (comprobantes)
    /// GET /api/AbrirCerrarMes/ultimo-mes-movimientos?empresaId=1&amp;ano=2024
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<int>> GetLastMonthWithMovements([FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: GetLastMonthWithMovements called with empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        var lastMonth = await service.GetLastMonthWithMovementsAsync(empresaId, ano);
        return Ok(lastMonth);
    }

    /// <summary>
    /// Abre un mes para permitir edición de comprobantes
    /// POST /api/AbrirCerrarMes/abrir
    /// Body: { "empresaId": 1, "ano": 2024, "mes": 3 }
    /// </summary>
    [HttpPost]
    public async Task<ActionResult> Abrir([FromBody] AbrirCerrarMesRequestDto request)
    {
        logger.LogInformation("API: Abrir called with empresaId: {EmpresaId}, año: {Ano}, mes: {Mes}",
            request.EmpresaId, request.Ano, request.Mes);

        await service.OpenMonthAsync(request.EmpresaId, request.Ano, request.Mes);
        return Ok(new { message = "Mes abierto correctamente" });
    }

    /// <summary>
    /// Cierra un mes para prevenir edición de comprobantes
    /// POST /api/AbrirCerrarMes/cerrar
    /// Body: { "empresaId": 1, "ano": 2024, "mes": 3 }
    /// </summary>
    [HttpPost]
    public async Task<ActionResult> Cerrar([FromBody] AbrirCerrarMesRequestDto request)
    {
        logger.LogInformation("API: Cerrar called with empresaId: {EmpresaId}, año: {Ano}, mes: {Mes}",
            request.EmpresaId, request.Ano, request.Mes);

        await service.CloseMonthAsync(request.EmpresaId, request.Ano, request.Mes);
        return Ok(new { message = "Mes cerrado correctamente" });
    }

    /// <summary>
    /// Obtiene la configuración de gestión de meses
    /// GET /api/AbrirCerrarMes/configuracion?empresaId=1&amp;ano=2024
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<EstadoMesesConfigDto>> Configuracion([FromQuery] int empresaId, [FromQuery] short ano)
    {
        logger.LogInformation("API: Configuracion called with empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        var config = await service.GetConfigurationAsync(empresaId, ano);
        return Ok(config);
    }
}
