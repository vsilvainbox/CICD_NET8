using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using App.Helpers;
using App.Extensions;

namespace App.Features.AbrirCerrarMes;

/// <summary>
/// MVC Controller para gestión de períodos contables (Abrir/Cerrar Mes)
/// Migrado desde VB6 FrmEstadoMeses.frm
/// Refactorizado siguiendo patron ASP.NET Core MVC way (server-side rendering)
/// </summary>
public class AbrirCerrarMesController(
    ILogger<AbrirCerrarMesController> logger,
    IHttpClientFactory httpClientFactory,
    LinkGenerator linkGenerator) : Controller
{
    /// <summary>
    /// Vista principal del control de períodos contables
    /// Muestra los 12 meses del año con sus estados (ABIERTO/CERRADO)
    /// Carga inicial con datos del servidor (no vacia)
    /// </summary>
    public async Task<IActionResult> Index()
    {
        if (SessionHelper.EmpresaId <= 0)
        {
            TempData["SwalError"] = "Debe seleccionar una empresa para acceder a Abrir/Cerrar Mes";
            TempData["SwalType"] = "warning";
            return RedirectToAction("Index", "SeleccionarEmpresa");
        }

        logger.LogInformation("Loading AbrirCerrarMes Index view for empresaId: {EmpresaId}, año: {Ano}", SessionHelper.EmpresaId, SessionHelper.Ano);

        // Cargar datos iniciales server-side
        var viewModel = await CargarViewModelAsync(SessionHelper.EmpresaId, SessionHelper.Ano);

        return View(viewModel);
    }

    /// <summary>
    /// Metodo helper para cargar el ViewModel desde la API
    /// </summary>
    private async Task<AbrirCerrarMesViewModel> CargarViewModelAsync(int empresaId, short ano)
    {
        var client = httpClientFactory.CreateClient();

        // Cargar configuracion
        var urlConfig = linkGenerator.GetApiUrl<AbrirCerrarMesApiController>(
            HttpContext,
            nameof(AbrirCerrarMesApiController.Configuracion),
            new { empresaId, ano });

        var config = await client.GetFromApiAsync<EstadoMesesConfigDto>(urlConfig!);

        // Cargar estados de meses
        var urlEstados = linkGenerator.GetApiUrl<AbrirCerrarMesApiController>(
            HttpContext,
            nameof(AbrirCerrarMesApiController.Estados),
            new { empresaId, ano });

        var estadosDtos = await client.GetFromApiAsync<List<EstadoMesDto>>(urlEstados!);

        // Mapear a ViewModel
        var viewModel = new AbrirCerrarMesViewModel
        {
            Configuracion = config,
            Meses = estadosDtos.Select(MesEstadoItem.FromDto).ToList()
        };

        return viewModel;
    }

    /// <summary>
    /// Proxy para obtener configuración de la empresa y año
    /// GET /AbrirCerrarMes/Configuracion?empresaId=1&amp;ano=2024
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Configuracion(int empresaId, short ano)
    {
        logger.LogInformation("Proxy: GetConfiguration called with empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<AbrirCerrarMesApiController>(
                HttpContext,
                nameof(AbrirCerrarMesApiController.Configuracion),
                new { empresaId, ano });

            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Proxy para obtener estados de todos los meses
    /// GET /AbrirCerrarMes/Estados?empresaId=1&amp;ano=2024
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Estados(int empresaId, short ano)
    {
        logger.LogInformation("Proxy: GetEstados called with empresaId: {EmpresaId}, año: {Ano}", empresaId, ano);

        {
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<AbrirCerrarMesApiController>(
                HttpContext,
                nameof(AbrirCerrarMesApiController.Estados),
                new { empresaId, ano });

            var datos = await client.GetFromApiAsync<object>(url!);
            return Ok(datos);
        }
    }

    /// <summary>
    /// Proxy para abrir un mes
    /// POST /AbrirCerrarMes/Abrir
    /// Body: { "empresaId": 1, "ano": 2024, "mes": 3 }
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Abrir([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: Abrir called");

        {
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<AbrirCerrarMesApiController>(
                HttpContext,
                nameof(AbrirCerrarMesApiController.Abrir));

            var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    /// <summary>
    /// Proxy para cerrar un mes
    /// POST /AbrirCerrarMes/Cerrar
    /// Body: { "empresaId": 1, "ano": 2024, "mes": 3 }
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Cerrar([FromBody] JsonElement request)
    {
        logger.LogInformation("Proxy: Cerrar called");

        {
            var client = httpClientFactory.CreateClient();

            var url = linkGenerator.GetApiUrl<AbrirCerrarMesApiController>(
                HttpContext,
                nameof(AbrirCerrarMesApiController.Cerrar));

            var (statusCode, content) = await client.ProxyRequestAsync(url!, request, HttpMethod.Post);
            return StatusCode(statusCode, content);
        }
    }

    // ==================================================================================
    // NUEVOS ENDPOINTS REFACTORIZADOS - Retornan HTML en lugar de JSON
    // ==================================================================================

    /// <summary>
    /// Obtiene la tabla de meses renderizada como HTML
    /// GET /AbrirCerrarMes/GetMesesHtml?empresaId=1&ano=2024
    /// Reemplaza el endpoint Estados que retornaba JSON
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetMesesHtml(int? empresaId = null, short? ano = null)
    {
        try
        {
            var empId = empresaId ?? SessionHelper.EmpresaId;
            var year = ano ?? SessionHelper.Ano;

            logger.LogInformation("GetMesesHtml called with empresaId: {EmpresaId}, año: {Ano}", empId, year);

            var viewModel = await CargarViewModelAsync(empId, year);

            // Retornar partial view que renderiza solo el tbody
            return PartialView("_MesesLista", viewModel);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error loading meses HTML");
            return Content("<tr><td colspan='4' class='px-6 py-8 text-center text-red-500'><i class='fas fa-exclamation-circle text-3xl mb-2'></i><p>Error al cargar los estados de meses</p></td></tr>");
        }
    }

    /// <summary>
    /// Abre un mes usando Model Binding en lugar de JSON
    /// POST /AbrirCerrarMes/AbrirMes
    /// Reemplaza JSON.stringify con form data
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> AbrirMes([FromForm] AbrirCerrarMesRequest request)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(new { message = "Datos inválidos" });
        }

        logger.LogInformation("AbrirMes called with empresaId: {EmpresaId}, año: {Ano}, mes: {Mes}",
            request.EmpresaId, request.Ano, request.Mes);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AbrirCerrarMesApiController>(
            HttpContext,
            nameof(AbrirCerrarMesApiController.Abrir));

        // Mapear request a DTO
        var dto = new AbrirCerrarMesRequestDto
        {
            EmpresaId = request.EmpresaId,
            Ano = request.Ano,
            Mes = request.Mes
        };

        var (statusCode, content) = await client.ProxyRequestAsync(url!, dto, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }

    /// <summary>
    /// Cierra un mes usando Model Binding en lugar de JSON
    /// POST /AbrirCerrarMes/CerrarMes
    /// Reemplaza JSON.stringify con form data
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> CerrarMes([FromForm] AbrirCerrarMesRequest request)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(new { message = "Datos inválidos" });
        }

        logger.LogInformation("CerrarMes called with empresaId: {EmpresaId}, año: {Ano}, mes: {Mes}",
            request.EmpresaId, request.Ano, request.Mes);

        var client = httpClientFactory.CreateClient();

        var url = linkGenerator.GetApiUrl<AbrirCerrarMesApiController>(
            HttpContext,
            nameof(AbrirCerrarMesApiController.Cerrar));

        // Mapear request a DTO
        var dto = new AbrirCerrarMesRequestDto
        {
            EmpresaId = request.EmpresaId,
            Ano = request.Ano,
            Mes = request.Mes
        };

        var (statusCode, content) = await client.ProxyRequestAsync(url!, dto, HttpMethod.Post);
        return StatusCode(statusCode, content);
    }
}
