namespace App.Features.AcercaDelSistema;

public class AcercaDelSistemaDto
{
    public string Version { get; set; } = string.Empty;
    public string TipoBaseDatos { get; set; } = "SQLite";
    public bool EsDemo { get; set; } = false;
    public string Empresa { get; set; } = "Thomson Reuters";
    public string Telefono { get; set; } = "(56 2) 2483 8600";
    public string Website { get; set; } = "https://www.thomsonreuters.cl";
    public string Email { get; set; } = "soporte.chile@thomsonreuters.com";
    public string NivelProducto { get; set; } = "Profesional";
    public string FechaVersion { get; set; } = string.Empty;
    public string VersionBD { get; set; } = string.Empty;
}