﻿namespace App.Features.AsistenteImportacionPrimeraCategoria;

public interface IAsistenteImportacionPrimeraCategoriaService
{
    // Obtener Datos
    Task<IEnumerable<AsistenteImportacionPrimeraCategoriaDto>> GetAllItemsAsync(int empresaId, short ano);
    Task<AsistenteImportacionPrimeraCategoriaDto?> GetByIdAsync(int id);
        
    // Guardar (Create/Update masivo)
    Task SaveAllAsync(int empresaId, short ano, List<AsistenteImportacionPrimeraCategoriaDto> items);
        
    // Cálculos
    Task<CalculationResult> CalculateTotalsAsync(int empresaId, short ano, List<AsistenteImportacionPrimeraCategoriaDto> items);
    Task<double> GetFactorActualizacionAsync(int anoAnterior);
    Task<double> GetBaseImponibleIDPCAsync(int empresaId, short ano);
    Task<double> GetMayorValorEnajenacionAsync(int empresaId, short ano);
    Task<double> GetCredito33bisAsync(int empresaId, short ano);
    Task<double> GetValorUTMAsync(short ano);
        
    // Validaciones
    Task<ValidationResult> ValidateAsync(List<AsistenteImportacionPrimeraCategoriaDto> items);
        
    // Exportaciones
    Task<byte[]> ExportToPdfAsync(int empresaId, short ano);
    Task<string> ExportToClipboardAsync(int empresaId, short ano);
}