namespace App.Features.ConfiguracionActivoFijoIfrs;

public class ConfiguracionActivoFijoIfrsIndexViewModel
{
    public int EmpresaId { get; set; }
}
