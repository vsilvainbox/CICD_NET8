using System.Security.Claims;

namespace App.Extensions;

/// <summary>
/// Extensiones para acceder fácilmente a los Claims del usuario autenticado.
/// Uso: HttpContext.User.GetEmpresaId() o User.GetEmpresaId() en Controllers
/// </summary>
public static class ClaimsExtensions
{
    // ========== HTTPCONTEXT SHORTCUTS ==========

    /// <summary>
    /// Obtiene el ID del usuario actual desde HttpContext
    /// </summary>
    public static int GetCurrentUserId(this HttpContext context)
        => context.User.GetUsuarioId();

    /// <summary>
    /// Verifica si el usuario actual es admin desde HttpContext
    /// </summary>
    public static bool IsCurrentUserAdmin(this HttpContext context)
        => context.User.EsAdmin();

    // ========== EMPRESA ==========

    /// <summary>
    /// Obtiene el ID de la empresa seleccionada
    /// </summary>
    public static int GetEmpresaId(this ClaimsPrincipal user)
        => int.TryParse(user.FindFirst("EmpresaId")?.Value, out var id) ? id : 0;

    /// <summary>
    /// Obtiene el año seleccionado
    /// </summary>
    public static short GetAno(this ClaimsPrincipal user)
        => short.TryParse(user.FindFirst("Ano")?.Value, out var ano) ? ano : (short)DateTime.Now.Year;

    /// <summary>
    /// Obtiene el nombre de la empresa seleccionada
    /// </summary>
    public static string GetEmpresaNombre(this ClaimsPrincipal user)
        => user.FindFirst("EmpresaNombre")?.Value ?? string.Empty;

    /// <summary>
    /// Obtiene el RUT de la empresa seleccionada
    /// </summary>
    public static string GetEmpresaRut(this ClaimsPrincipal user)
        => user.FindFirst("EmpresaRut")?.Value ?? string.Empty;

    /// <summary>
    /// Verifica si hay una empresa seleccionada
    /// </summary>
    public static bool HasEmpresaSeleccionada(this ClaimsPrincipal user)
        => user.GetEmpresaId() > 0;

    // ========== USUARIO ==========

    /// <summary>
    /// Obtiene el ID del usuario actual
    /// </summary>
    public static int GetUsuarioId(this ClaimsPrincipal user)
        => int.TryParse(user.FindFirst(ClaimTypes.NameIdentifier)?.Value, out var id) ? id : 0;

    /// <summary>
    /// Obtiene el nombre de usuario
    /// </summary>
    public static string GetUsuarioNombre(this ClaimsPrincipal user)
        => user.FindFirst(ClaimTypes.Name)?.Value ?? string.Empty;

    /// <summary>
    /// Obtiene el nombre largo del usuario
    /// </summary>
    public static string GetUsuarioNombreLargo(this ClaimsPrincipal user)
        => user.FindFirst(ClaimTypes.GivenName)?.Value ?? string.Empty;

    /// <summary>
    /// Verifica si el usuario es administrador
    /// </summary>
    public static bool EsAdmin(this ClaimsPrincipal user)
        => user.FindFirst("EsAdmin")?.Value == "True";

    // ========== PERMISOS ==========

    /// <summary>
    /// Obtiene el ID del perfil actual
    /// </summary>
    public static int? GetIdPerfil(this ClaimsPrincipal user)
        => int.TryParse(user.FindFirst("IdPerfil")?.Value, out var id) ? id : null;

    /// <summary>
    /// Obtiene los privilegios como entero
    /// </summary>
    public static int GetPrivilegios(this ClaimsPrincipal user)
        => int.TryParse(user.FindFirst("Privilegios")?.Value, out var priv) ? priv : 0;

    /// <summary>
    /// Verifica si el usuario tiene un privilegio específico
    /// </summary>
    public static bool HasPrivilege(this ClaimsPrincipal user, int privilegeValue)
    {
        var privilegios = user.GetPrivilegios();
        return (privilegios & privilegeValue) == privilegeValue;
    }
}
