namespace App.Extensions;

/// <summary>
/// Extension methods para HttpRequest que facilitan la construcción de URLs de API internas.
/// </summary>
public static class HttpRequestExtensions
{
    /// <summary>
    /// Construye una URL completa para llamar a una API interna de la misma aplicación.
    /// Incluye automáticamente el Scheme, Host y PathBase correcto según el contexto.
    /// </summary>
    /// <param name="request">Request actual</param>
    /// <param name="apiPath">Path relativo de la API (ej: "api/SeleccionarEmpresa/companies")</param>
    /// <returns>URL completa lista para usar con HttpClient</returns>
    /// <example>
    /// // En desarrollo: http://localhost:5000/api/SeleccionarEmpresa/companies
    /// // En producción IIS con PathBase "/hc": https://productostr.thomsonreuters.cl/hc/api/SeleccionarEmpresa/companies
    /// var apiUrl = Request.GetApiUrl("api/SeleccionarEmpresa/companies?sortByRut=true");
    /// </example>
    public static string GetApiUrl(this HttpRequest request, string apiPath)
    {
        // Obtener PathBase (ej: "/hc" en producción, "" en desarrollo)
        var pathBase = request.PathBase.Value ?? string.Empty;

        // Construir URL base completa con scheme, host y pathBase
        var baseUrl = $"{request.Scheme}://{request.Host}{pathBase}";

        // Normalizar apiPath: quitar "/" inicial si existe para evitar doble slash
        apiPath = apiPath.TrimStart('/');

        // Retornar URL completa
        return $"{baseUrl}/{apiPath}";
    }
}
