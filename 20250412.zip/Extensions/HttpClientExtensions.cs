using System.Text.Json;
using App.Exceptions;

namespace App.Extensions;

/// <summary>
/// Extension methods para HttpClient con manejo de errores y deserialización automática
/// </summary>
public static class HttpClientExtensions
{
    /// <summary>
    /// Procesa errores de API y lanza la excepción apropiada
    /// - HTTP 4xx con "errors" -> BusinessException (validación de negocio)
    /// - HTTP 5xx -> HttpRequestException (error de sistema)
    /// </summary>
    private static void ThrowApiException(System.Net.HttpStatusCode statusCode, string errorContent)
    {
        // HTTP 4xx = error de validación (BusinessException)
        if ((int)statusCode >= 400 && (int)statusCode < 500)
        {
            try
            {
                using var doc = JsonDocument.Parse(errorContent);
                var root = doc.RootElement;

                var errors = new List<string>();

                // Buscar campo "errors" (array de strings)
                if (root.TryGetProperty("errors", out var errorsElement) &&
                    errorsElement.ValueKind == JsonValueKind.Array)
                {
                    foreach (var error in errorsElement.EnumerateArray())
                    {
                        errors.Add(error.GetString() ?? "Error desconocido");
                    }
                }
                // Fallback: buscar campo "message"
                else if (root.TryGetProperty("message", out var messageElement))
                {
                    errors.Add(messageElement.GetString() ?? "Error desconocido");
                }

                if (errors.Count > 0)
                {
                    throw new BusinessException(errors);
                }
            }
            catch (BusinessException)
            {
                throw;
            }
            catch
            {
                // Si no se puede parsear, lanzar BusinessException genérica
                throw new BusinessException("Error de validación");
            }
        }

        // HTTP 5xx = error de sistema
        throw new HttpRequestException(
            $"API returned {statusCode}: {errorContent}",
            null,
            statusCode
        );
    }

    /// <summary>
    /// GET con deserialización automática y manejo de errores
    /// </summary>
    public static async Task<T> GetFromApiAsync<T>(this HttpClient client, string requestUri)
    {
        var request = new HttpRequestMessage(HttpMethod.Get, requestUri);
        request.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        var response = await client.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            ThrowApiException(response.StatusCode, errorContent);
        }

        var content = await response.Content.ReadAsStringAsync();

        // Manejar contenido vacío
        if (string.IsNullOrWhiteSpace(content))
        {
            return default!;
        }

        return JsonSerializer.Deserialize<T>(content, new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        }) ?? default!;
    }

    /// <summary>
    /// POST con deserialización automática y manejo de errores
    /// </summary>
    public static async Task<TResponse> PostToApiAsync<TRequest, TResponse>(
        this HttpClient client,
        string requestUri,
        TRequest data)
    {
        var json = JsonSerializer.Serialize(data);
        var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

        var request = new HttpRequestMessage(HttpMethod.Post, requestUri) { Content = content };
        request.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        var response = await client.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            ThrowApiException(response.StatusCode, errorContent);
        }

        var responseContent = await response.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<TResponse>(responseContent, new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        }) ?? throw new InvalidOperationException("Deserialización devolvió null");
    }

    /// <summary>
    /// POST sin respuesta (para endpoints que devuelven 204 No Content)
    /// </summary>
    public static async Task PostToApiAsync<TRequest>(
        this HttpClient client,
        string requestUri,
        TRequest data)
    {
        var json = JsonSerializer.Serialize(data);
        var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

        var request = new HttpRequestMessage(HttpMethod.Post, requestUri) { Content = content };
        request.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        var response = await client.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            ThrowApiException(response.StatusCode, errorContent);
        }
    }

    /// <summary>
    /// PUT con deserialización automática y manejo de errores
    /// </summary>
    public static async Task<TResponse> PutToApiAsync<TRequest, TResponse>(
        this HttpClient client,
        string requestUri,
        TRequest data)
    {
        var json = JsonSerializer.Serialize(data);
        var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

        var request = new HttpRequestMessage(HttpMethod.Put, requestUri) { Content = content };
        request.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        var response = await client.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            ThrowApiException(response.StatusCode, errorContent);
        }

        var responseContent = await response.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<TResponse>(responseContent, new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        }) ?? throw new InvalidOperationException("Deserialización devolvió null");
    }

    /// <summary>
    /// DELETE con manejo de errores
    /// </summary>
    public static async Task DeleteFromApiAsync(this HttpClient client, string requestUri)
    {
        var request = new HttpRequestMessage(HttpMethod.Delete, requestUri);
        request.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        var response = await client.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            ThrowApiException(response.StatusCode, errorContent);
        }
    }

    /// <summary>
    /// Método proxy - reenvía la respuesta tal cual (para JavaScript)
    /// Útil cuando el frontend necesita manejar el status code
    /// </summary>
    public static async Task<(int StatusCode, string Content)> ProxyRequestAsync(
        this HttpClient client,
        string requestUri,
        object? data = null,
        HttpMethod? method = null)
    {
        method ??= HttpMethod.Get;

        var request = new HttpRequestMessage(method, requestUri);
        request.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

        if (data != null && (method == HttpMethod.Post || method == HttpMethod.Put))
        {
            var json = JsonSerializer.Serialize(data);
            request.Content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
        }

        var response = await client.SendAsync(request);
        var content = await response.Content.ReadAsStringAsync();

        return ((int)response.StatusCode, content);
    }

    /// <summary>
    /// Sobrecarga específica para JsonElement - reenvía la respuesta tal cual
    /// </summary>
    public static async Task<(int StatusCode, string Content)> ProxyRequestAsync(
        this HttpClient client,
        string requestUri,
        System.Text.Json.JsonElement data,
        HttpMethod? method = null)
    {
        method ??= HttpMethod.Get;

        var request = new HttpRequestMessage(method, requestUri);
        request.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

        if (method == HttpMethod.Post || method == HttpMethod.Put)
        {
            // JsonElement ya está en formato JSON, usarlo directamente
            var json = data.GetRawText();
            request.Content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
        }

        var response = await client.SendAsync(request);
        var content = await response.Content.ReadAsStringAsync();

        return ((int)response.StatusCode, content);
    }

    /// <summary>
    /// Descarga de archivos (Excel, PDF, etc.)
    /// </summary>
    public static async Task<(byte[] FileBytes, string ContentType)> DownloadFileAsync(
        this HttpClient client,
        string requestUri,
        HttpMethod method,
        object? data = null)
    {
        var request = new HttpRequestMessage(method, requestUri);
        request.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

        if (data != null && (method == HttpMethod.Post || method == HttpMethod.Put))
        {
            var json = JsonSerializer.Serialize(data);
            request.Content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
        }

        var response = await client.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            ThrowApiException(response.StatusCode, errorContent);
        }

        var fileBytes = await response.Content.ReadAsByteArrayAsync();
        var contentType = response.Content.Headers.ContentType?.ToString()
            ?? "application/octet-stream";

        return (fileBytes, contentType);
    }
}
